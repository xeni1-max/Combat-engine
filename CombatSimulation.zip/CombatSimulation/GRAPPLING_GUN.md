# 1E2 grappling gun and explicit world targets

Implemented and verified2026-11-09 after resumption. The actual hook, two paid
phases, terrain rope and native body contacts execute in shared combat.
[Evidence and reproduction](results/grappling-gun/README.md).

The unchanged primary `1E2.odt` supplies these zero-based paragraphs: p7 gives
directional self-launch, rope30 m and cooldown12 s; p95/p97 firing G160/A60;
p99 hook speed40 m/s; p101/p102 firing self O135/U135; p104 firing Db1.5;
p106 release after firing; p108 intrinsic momentary. Launch p114/p115 supplies
self O300/U350, arrival p117/p118 self O305/U355, and p121 separate launch Db1.5.
No launch speed or separate launch-control duration is supplied in this section.

The following are **delegated implementation decisions**, not author confirmations:

- Reuse the two-hand gun grip, left-hand origin and 2 cm sphere. The hook has
  no HP damage or target statuses. Preserve intrinsic momentary firing;
  classify the separate physical launch intrinsic momentary.
- Pay firing Db1.5 at release and start the12 s cooldown there. Pay launch Db1.5
  only on actual launch through the shared payment/capacity gate. Add no stock.
  Launch uses the existing Active-start payment anchor for its separate phase.
  Waiting for the hook is not Active exertion; ordinary status/movement recovery
  conditions determine the dyspnea value when launch is checked.
- Per-ability `ability_targets` can select a world_point or registered surface.
  Freeze point/provenance at action request, including when no enemy exists.
  Intent never substitutes for collision. Default enemy targeting is retained.
- Real solid terrain contact projects the projectile centre onto the actual
  registered face. Body, Block and non-solid intercepts create no terrain anchor.
  Source life/control, surface revision and30 m range must remain valid after
  the ordinary damage/death wave.
- The hook uses the existing moving source-distance envelope. Flight keeps
  hands/weapon ownership. Launch acquires locomotion by atomic registry transfer;
  conflicting ownership or capacity rejects it without an extra debit.
- Body launch speed is4 × base running speed:25.6 m/s for1E2. This reversible
  default is distinct from the authored hook speed. Use the fastest ballistic
  arc to the real anchor under shared gravity. Native sweeps decide contact.
  Explicit horizontal/downward launches preserve prior jump/dash obligations.
- The ordinary30 m fixed-endpoint rope ends at first physical arrival contact,
  loss of control/anchor/life or nominal free-flight arrival deadline. A deadline
  releases control and rope without fabricating arrival. Already launched motion
  and its life-bound first-contact self effects persist after cancellation;
  death retires them.
  A generic distance-end observer notifies the owner at the actual destruction/
  expiry clock, including within continuous heat integration. A real beam
  regression guards the formerly delayed130.343 ms control release.
- Released copies remain projectile entities. One owned action performs its
  launch continuation once; duplicate contacts cannot pay/launch it twice.

All2560 methods pass, including34 new physical/phase/life tests. Sixteen complete
API/CLI/hash/numerical captures pass and reproduce immutably; sixteen preceding
complete traces remain exact. The initial68-method prototype subset did not
activate these paths; its result is not substituted for the new verification.
Historical captures and both author source versions are preserved. The subsequent
[body proportions](CHARACTER_GEOMETRY.md) and [basic9 Dodge](DODGING.md) are now
imported and separately verified. The new fence parts remain an outstanding
source import.

An explicit target can be supplied per selected physical projectile:

```json
"ability_targets": {
  "3": {
    "kind": "surface",
    "collider_id": "hookwall",
    "part": "panel",
    "point_m": [7.9, -20, 1.2]
  }
}
```

`world_point` needs only kind and point_m. Surface definitions are validated
against initial geometry and retain that provenance as a scripted intent;
each action pins its own copy. If that surface later disappears, the shot
continues toward the old point and can hit another real receiver. Default
nearest-enemy/torso behavior remains available. Body/Block interception, source
death, accuracy and faster-arc compensation use the ordinary shared pipeline.
