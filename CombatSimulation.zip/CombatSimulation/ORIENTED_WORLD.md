# Fixed oriented world materials

2026-11-13. Native material integration builds on
[upright frames and true box geometry](ORIENTED_GEOMETRY.md). The changes are
verified in [this checkpoint](results/oriented-world/README.md).
[Fixed initial actor yaw](ACTOR_FACING.md) now extends the actor consumers too;
continuous angular motion and the author's [whole-body turn](TURNING.md)
remain unfinished.

## Representation and admission

These are delegated engineering choices. They preserve the six characters,
their abilities, the finite ground, ordinary cubes and existing material HP/
damage policies. A fixed collider part may specify optional `yaw_degrees`:

```json
{"part":"panel", "centre_m":[2,-20,1.5], "size_m":[0.2,4,3], "yaw_degrees":45}
```

Material yaw rotates the original world X/Y dimensions about Z. Zero retains
their original directions; positive angles proceed from +X toward +Y. Size
derivatives, where a query accepts them, follow the part's local axes. The
body-frame convention describes forward heading instead, so material parsing
uses heading `yaw_degrees + 90`. Explicit yaw zero creates an oriented shape;
omitting yaw retains the original axis-aligned shape and serialization.

The immutable frame retains rational c/s with c²+s² exactly one, selected at
the world's declared precision. Records include local dimensions, centre and
the exact frame. Minimum/maximum coordinates remain enclosing AABB bounds,
not an enlarged collision solid. Native admission requires the current
`finite_faces_v2` support/contact rules. Single-part rotated climbable blocks
use the existing climb ability and path; compound climbable objects remain
outside the existing climb contract.

## Shared world behavior

`box_motion.py` describes fixed-frame separating-axis polynomials, true
footprints and physical surfaces. It neither moves bodies nor chooses their
response. The complete two-box axis set supports quadratic translation and
local resizing through the existing contact solver. Actual one-sided entry
normals feed native response and retained contact planes. As the author
specified for obstacles, collision direction is perpendicular to the surface.
Tangential velocity survives; status amounts use relative normal speed.
Rigid links share projected motion while contact statuses belong to the
actually contacting characters.

Owned ability volumes use the same real contact metric and tolerance. Their
rational projection comparison converts the Decimal tolerance exactly into
that rational domain. Real charge-hand wall fracture, descending foot contact
and slash/material damage exercise the existing deliveries without adding an
ability or altering its output.

Support requires real positive footprint overlap beyond contact resolution,
including partial support. Departure is solved on the same projected overlap
bands. The existing support-loss/flight transaction retains movement, forces,
links and landing debt. Expiry, destruction or geometry revision invalidates
the same support and anchor lifetimes. New occupancy and collider creation/
reshape reject actual penetration atomically. Empty enclosing-box corners
remain usable space.

Curved projectiles view their original immutable trajectory in the fixed local
frame. They retain world arc distance, gravity, release attribution and the
existing numerical contact enclosure/tangency policy. Contact events and hook
anchors use real material faces. No new flight integration is introduced.

Sphere, column and box membership use the real solid. Continuous field cells
partition at polynomial boundaries, including actual rotated cover footprints;
midpoint predicates classify intervals between roots rather than sampling
motion at a fixed time step. One material HP pool receives an area hit once
across its parts. Cover remains the existing explicit per-collider policy:
the author's ordinary cubes do not block beam/blast damage. Custom cover in
the verification scenarios explicitly enables area blocking. Beam visibility
retains the existing rule that any eligible visible body part admits exposure.

Climb range measures from character origin to the actual material surface at
Active start, using the author's 0.5 m range. The accepted path still goes up
to the top, then across to its centre. This integration does not change climb
timing or add a character ability.

## Scope and next work

Fixed geometry can be replaced through the existing discrete reshape API,
subject to occupancy checks and revision invalidation. This supplies no
continuously rotating platform or instantaneous substitute for a body turn.
Pose/hand, heading consumers and dynamic body planes are now migrated for
fixed initial actor yaw. Continuous angular prediction and owned timed turns
remain unfinished. Translation keeps one shared writer.
Prescribed linked climbing and final cross-kit/5v5 verification remain.
Advanced NPC, mass experiments and balancing automation stay deferred.

An ordinary walk/fire example is
[oriented_material_walk_fire.json](scenarios/oriented_material_walk_fire.json).
Run `python3 -B -m combat_sim run scenarios/oriented_material_walk_fire.json`.
