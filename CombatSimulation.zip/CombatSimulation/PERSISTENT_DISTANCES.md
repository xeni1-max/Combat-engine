# Persistent distance limits on shared body paths

**Ground reaction correction verified, 2026-11-14:** joint constraint
planning now supplies native gravity once for supported, uncontrolled actors
instead of using their independently cancelled grounded acceleration. Contact
constraints solve the actual reaction. An attached climber exposed repeated
tiny floor launches when weak upward rope pressure acted on an otherwise
weightless grounded driver. Prescribed routes keep their controlled acceleration;
native flight already supplies gravity and receives no duplicate term.

The saved curve also preserves stationary contact normals between its initial
projected velocity and endpoint. The exact midpoint projection closes that
normal when both end conditions are stationary, preventing an invented
intermediate hop; genuine outgoing velocity or endpoint lift remains legal.
The whole-interval distance certificate is still checked after construction.
Original and corrected traces/pure cases,3344 passing methods,17 complete new
controls and59 reviewed prior controls are in [results/linked-climb](results/linked-climb/README.md).
These are delegated engineering corrections; character abilities are unchanged.
The taut400ms case completes but remains expensive, with no universal temporal,
energy or rational-growth bound claimed.

**Angular integration, 2026-11-13:** [active linked turns](ANGULAR_LINKS.md)
keep the reference endpoint metric and current finite planner. Horizontal
reference-only resting planes are suspended during yaw; cached contact tokens
retire at actual departure even on slack leases. Native actual impacts keep
their pre-response motion. Static vertical reactions retain their real footprint.

**Voluntary transport,2026-11-09:** [portal transport](PORTALS.md) preflight
checks affected moving/fixed limits against proposed upright references. It
rejects exceeded limits atomically; a tether alone does not carry its remote
endpoint. External imposed relocation retains `external_separation` below.
Exact-boundary destinations remain legal and keep their live row.

2026-11-09 correction, exercised during authored body-size integration: a
grounded actor retaining transmitted inertia stores physical velocity minus
its own unprojected motor request. The next free driver adds that request once.
Subtracting the projected motor share repeatedly added part of running speed
at every lease. A real unequal-height3E5 chain/body-support interaction reached
over500 m/s and left the floor before this correction. Original failures and
current verification are preserved in results/body-scales. The fix retains the
existing ground and distance certificates.

The resulting near-tangent case also exercises the certified shared-velocity
fallback described in [distance paths](DISTANCE_PATHS.md). Selected per-force
responses include its feasible anchor, preserving released common motion.

The current compiler also admits [living-body contact graphs](BODY_SUPPORT.md)
without inventing distance bindings. Life/part witnesses contribute unilateral
planes alongside real grapples, static contacts and taut moving/fixed tethers.
They retain the same saved path writer, step limits and per-force accounting.
Vertical body planes belong to those pose-aware witnesses rather than also
remaining in the generic reference-only resting cache.

Delegated architecture and numerical decisions, 2026-11-02. Current locomotion
inputs select `distance_constraints.mode=persistent_distance_v1`. The live
coordinator now uses the [finite planner](DISTANCE_PATHS.md) through the
[saved body-path writer](BODY_PATHS.md). Body, terrain, projectile, Block and
area/field queries consume those same committed quadratic paths.
[Implementation](combat_sim/persistent_distances.py) ·
[Evidence and reproduction](results/persistent-distances/README.md).

The controller supports explicit engineering attachments and now serves
[3E5's actual chain cast](CHAIN_CAST.md), including real projectile contact,
spatial binding and common Break. The controller itself invents no character
ability, cost or cooldown.

The later [1E1 ground chain](GROUND_CHAIN.md) extends the same controller with
typed constant terrain points. Fixed endpoints are neither solver variables
nor fake fighters, and do not join knock-resistance stats. Surface identity,
source-independent lifetime, support destruction and bounded numerical
reconciliation are documented there. Moving-pair traces retain their prior
record format and numeric path.

## Attachment and lifetime

`world.distance_constraints.attach(first, second, maximum_m=...,
expires_at_ms=..., source=..., expected_lives=...)` requires two distinct living
endpoints, both expected life generations, a positive length exceeding the
numerical inset, a future finite expiry and a source identity. Initial upright
reference separation must already fit the length. Invalid attachment fails
before changing rows, events or motion.

Rows have independent identities and clocks, including duplicate/overlapping
limits. Release/expiry retains already transmitted momentum. Either endpoint's
death ends that row; revival inherits no old attachment. External relocation
beyond the limit ends it as `external_separation`, instead of snapping the other
endpoint or silently moving the relocated actor back. The authored
[3E5 chain](CHAIN_CAST.md) pins those endpoint lives and links release to binding
end/Break; other deliveries must specify their own attachment policy.

The endpoints are upright translation references. Crouching changes pose and
body origin without using chain length. This is a delegated first attachment
model; hand/socket offsets can later use the same path interface.

## Slack, curvature and deterministic knots

Inward and permitted tangential motion remain legal. A slack row does not pull
early because a future endpoint would exceed its length. Exact quartic
distance polynomials locate its first outward crossing. After constraining a
connected row, slack neighbors are checked against that resulting candidate,
so coupled activation uses the motion the world will actually commit.

Only taut participants enter the solver, expanded through actual grapple groups
and resolved touching-body contacts. Unrelated/slack actors keep their existing
paths exactly. Joint constraints combine finite distances, grapple equalities,
static contacts and relative body-contact planes. Existing positive individual
maximum-HP/current-armor weights share this response.

Each constrained lease is at most **5 ms**, shortened when free relative travel
would exceed **0.001 times the distance limit**, or by an earlier semantic phase,
contact, force, support or life event. These controls are independent of samples.
Observation prefixes slice the saved polynomial and evaluate its original
coefficients; they do not reapply response or compound force transport.

The planner certifies all five degree-four Bernstein coefficients of squared
distance minus the limit squared as nonpositive. Its exact rational certificate
applies to the full planned interval; the world may commit only a prefix.
The reported last plan includes that committed endpoint and life identities.
It is a compact final diagnostic, not an archived certificate for every step.

Decimal state uses owned world precision. Clock conversion rounds down before
returning to rational time, preventing a rounded endpoint from exceeding its
exact lease. A **1e-30 m** inward reconciliation about the weighted centre is
bounded below **1e-22 m**, versus the existing **1e-20 m** geometry tolerance.
Larger disagreement raises an error. This addresses numerical roundoff without
inventing a physical collision or repeated positional correction.

## Drivers, finite forces and contacts

Desired ground pace remains separate from physical inertia: a blocked motor
does not permanently lose its request. Transmitted ground inertia is additive,
survives release and can be consumed by the existing special stop, movement
transition or jump. Airborne state retains the actual path derivative and
native gravity. Zero imposed-velocity metadata is normalized so it cannot
change an otherwise identical body's response.

Each finite knock component passes through the same selected linear response
and path blend as total velocity. The affine curvature/acceleration offset
belongs to base motion once. It is not added to every force component. Each
force retains its original life and expiry; expiry removes its current retained
and transmitted shares once. This selected component accounting is not the
nonlinear solver's Jacobian or a general physical conservation theorem.
[Implementation](combat_sim/mechanics/constraint_response.py).

These internal physics commits do not use external velocity replacement, which
intentionally cancels control and retires replaced forces. A redirected native
launch keeps its paid landing obligation and motion cause but discards an
obsolete pre-launch ground-pace restoration. Compatible native launches keep
their restoration; transferred inertia survives a subsequent basic jump.

The existing support model cancels gravity for a supported grounded body; a
positive transmitted vertical velocity launches it into native gravity.
Real floor contacts use the actual quadratic acceleration. Only already
resolved contacts, plus native grounded support, enter resting constraint
planes. The first real impact still receives its pre-impact velocity and
individual collision penalties. A departed contact leaves the resting cache;
terrain revisions and life changes invalidate it. Tension alone does not give
collision statuses to a body that did not collide.
Cache identity is initialized before admitting a new resolved contact, including
contacts made while every row is slack; first tension cannot erase that history
and charge a second impact without separation.

Compatible prescribed climbing is retained. Before a future constrained path
is consumed, a changed prescribed route retires through native climb interruption
at the current position. Its own input stays behind the shared projection so
momentum is not averaged twice. The tether remains live; no attachment loss is
fabricated before actual displacement. Legal gunfire, Block, fields and
upper-body freezing keep their independent action/effect owners.

## Author rule and evidence limits

The author's [grapple knock rule](KNOCKBACK.md), reaffirmed 2026-11-02, is
unchanged: sum maximum HP and current armor of actual grapple participants
before nonlinear knock resistance, then knock them together without a second
sharing-weight division. A distance-only attachment does not join that grapple
resistance group. Knock away/back are synonyms; up/down specify direction.

Verification covers radial/slack/curved paths, coupled neighbors, duplicate
lifetimes, inward freedom, ground/air/support, actual hold/heavy punch, force
expiry, terrain/body contacts, controls, climb, gun/Block, beam/pause/freeze,
death/restoration and paid dash landing. A free equal-weight orbit is compared
with its analytic solution at 5/2.5/1.25 ms; position error decreases under
refinement. The recorded energy and velocity errors describe that case only.
Whole-interval geometric feasibility does not prove a universal ODE error bound
or exact energy conservation. Advanced NPCs and mass experiments remain deferred.

[3E5 ability 2](CHAIN_CAST.md) now uses this controller through the existing
projectile, action, effort, cooldown and binding/Break systems. Distance-row
release ends its spatial binding, and binding end releases the row, once and at
the same timestamp. Next extend the endpoint model for environmental/fixed
anchors required by 1E1's authored ground chain. Retain each ability's identity
and slack/tangential behavior.
