# Heavy punch, finite knocks and elasticity

2026-11-09 correction: expiry removes numerical cancellation residue within the
existing1e-24 m/s contact-speed band. Changed body geometry exposed1e-48 m/s
left after subtracting reflected/projected impulse components. Those residues
must not become permanent imposed motion. Actual wall/group rebounds, separate
impulse clocks and remaining real velocity retain their existing rules.
Original failures and current regression are preserved in results/body-scales.

2026-11-01. **3E5 ability 4** now executes through actual shared melee contact,
damage snapshots, phase payment/cooldown and released finite body forces.
[Coordinator](combat_sim/knock_motion.py) ·
[Evidence/reproduction](results/knock-delivery/README.md).

## Primary and author definitions

`3E5.odt` p15/p145–p164 specifies 600 blunt damage, 15 m knock away, 100%
elasticity during that knock, cooldown 9 s, G180/A220, midpoint impact, target
O800/U800, self O200/U200 on impact, Db3 and intrinsic momentary effort. The
source explicitly illustrates elasticity by bouncing from a wall. It supplies
no knock duration, hand geometry, cooldown anchor or overlap/termination policy.

[The author's grapple clarification](KNOCKBACK.md) requires still-grappled
characters to move together, with stats summed before resistance:

`P2 = max(0, P - (sum(maximum_HP)/500 + sum(current_armor)/10)^1.1/150)`.

Knockback and knock away are synonyms; up/down specify direction. This
increment delivers the heavy punch's horizontal knock-away case. The
[upward counter](CONDITIONAL_MELEE.md) now adds gravity-based resisted height
and incoming-motion deflection. Falling kick, charge/slam and binding remain unfinished.

## Delegated delivery and causal ordering

Reuse the existing neutral right-hand pose and 1 m/2 cm timed melee capsule.
Lock the intended torso point at Active start; actual first body/solid/Block
contact decides the hit. A miss still pays Db3 and starts the 9 s cooldown at
Active start. No projectile, slash wound or replacement blade is fabricated.
The ordinary successful hit is at 290 ms, with full control ending at 400 ms.
Power uses the pre-self-status intrinsic snapshot; a contact applies the source
self effects without rewriting another due release in that wave.

Current `knock_group_timing: {"mode":"at_impact_v1"}` pins the actual grapple
component at impact. Finish all character damage/status calculations, then
apply committed forces before fatigue teardown, material damage and new grabs.
The very hit that exhausts a hold must still knock its matching participants
together. A dead or replaced target receives no force; retired partner lives
are excluded. An already released punch can still knock survivors if its
source dies in that batch. Multiple forces add to current physical velocity.
Later attachments compose with released motion through the shared coordinator.

This corrects the earlier delegated priority-3 force policy, which read live
membership after fatigue and could lose a just-hit pair. Frozen inputs without
the explicit timing mode retain that historical behavior. The correction was
exposed by actual 3E5 and 1E5 holds; [charge/knock evidence](CHARGE_GRAPPLE.md).

Every participant's maximum HP/current armor is snapshotted before the whole
impact batch; sum the selected component's snapshots once. Thus simultaneous
hits share defenses, while a later punch sees armor lost to an earlier hit.
Current deliveries never rebind a retired recipient life. HP damage, armor loss
and incoming O/U remain individual and use the existing defense snapshots.

A personal regenerative shield does not supply body resistance or prevent the
physical knock. A separate Block surface intercepts the melee strike; full
absorption transmits no physical force, while positive overflow can reach its
owner. Zero released power transmits no knock. Otherwise the source's 15 m is
not scaled by HP damage or by the instability damage-output formula.

## Finite additive motion

The selected engineering duration is **500 ms**, stored in character data.
For resisted distance P2, release a horizontal velocity component `P2/0.5 s`
away from the source's current horizontal centre. Retain the recipient's
existing physical velocity, including vertical motion. A stationary unshielded
2E4 receives approximately 14.670602609 m at 29.341205218 m/s, from 290 to
790 ms. Existing baseline momentum adds its own travel; this is not a forced
destination or a second movement loop. Gravity and continuous sweeps remain
authoritative throughout.

Each released impulse has its own source/action/life identity, participant
components, start and expiry. Overlapping impulses add. Contact linearly
transforms each component along with the body's velocity, so expiry removes
only that impulse's **current transformed contribution**, retaining other
impulses and baseline/gravity motion. Two equal opposing simultaneous knocks
cancel spatially while retaining both clocks. Staggered opposing punches differ
slightly because the second uses the reduced armor left by the first.

An imposed knock supplies one physical velocity to the current group without
another division by grapple weights. If common input must be imposed again,
rebase older impulse contributions through the same weighted projection,
including newly joined members, before retaining their independent expiries.
Release of the grapple does not cancel already imposed force on its survivors.
Only actual contacting bodies receive collision penalties.

Active force blocks lower-body commands through the existing per-source
function restriction. Walking, stopping and voluntary dash cannot erase it;
compatible upper-body actions remain independent. Expiry releases only its own
restriction. The stopping admission shortcut now checks imposed velocity as
well as nominal pace; the previous shortcut raised an ownership conflict during
a real knock instead of waiting.

An external **velocity replacement** retires affected impulse components, so
their old expiries cannot undo the replacement. Reference-only relocation
preserves the force clock. Support loss and gravity are not external velocity
replacement. Recipient death retires its components/restrictions immediately;
no impulse transfers to a revived life. Source death after release does not
retire a survivor's physical impulse.

## Elastic collision response

Elasticity is a temporary property of the forced body/group. Use the maximum
active coefficient rather than adding percentages. The source heavy punch uses
1. For the orthogonal normal space already computed by shared contact handling,
ordinary collision projects velocity out; elasticity e adds back `-e` times
that removed component. At e=1, normal velocity reverses at full magnitude;
tangential velocity remains. The original pre-contact velocities still supply
the normal collision O/U penalties. This kinematic game rule does not introduce
a mass/energy-exchange solver for moving characters.

Ground and ceiling faces participate. A descending real jumper can bounce from
the ground while elasticity is active; that bounce is not a landing. Its old
jump/dash landing obligation remains until actual support is established after
flight, even if launch control already ended. There is no new jump payment or
self effect at a bounce. Once the impulse expires, its elasticity stops;
gravity and any remaining flight continue normally.

**2026-11-02 current response:** [the prison increment](PRISON.md) selects
approaching-reference contacts, common moving-body rebound frames and a logged
1 ms repeated-contact absorption band. Separating pose obstruction only freezes
deformation. Zero elasticity retains authored component removal; original frozen
inputs retain the earlier bounce rule above. Longer crowded continuations still
reached dynamic-support and velocity-only force-expiry validation failures. The
latter is corrected in [spatial validation](SPATIAL_TRANSITIONS.md); selected
[living-body support](BODY_SUPPORT.md) also completes the full crowded2200ms
continuation with numerical controls. See
[reproduction/boundaries](results/prison-cast/README.md). This is not a general
multi-body energy or convergence certificate.

Existing finite-ground/ledge/facing guards remain. Prone/Get Up
now use the later shared equilibrium geometry.
The chosen force window and proxy are reversible data/design choices. General
kit completion, vertical knock delivery and reproducible 5v5 remain unverified.
