# Binding instances, Break and 1E3 marking projectile

The subsequent [1E2 fence](ELECTROCUTION_FENCE.md) delivers contact-scoped
lower-body bindings through this same controller. Each independent field/body/
life episode owns one B2 instance. Common Break can end it while electrical
contact continues; staying in that episode does not immediately bind again.
Positive exit/re-entry creates a fresh instance. Loss of all contacted material,
field expiry or recipient death ends the episode and its binding. Panel seams
and destruction of one still-supported panel do not reset escape work. This
adds no ordinary momentum/gravity cancellation or extra point cost.

2026-11-01. This increment delivers the existing **1E3 ability 1** through the
shared combat engine. [Implementation](combat_sim/binding_effects.py) ·
[Reproducible encounters](results/binding-marks/README.md).
The later [3E5 chain cast](CHAIN_CAST.md) now adds a spatial binding kind and
actual damage-free projectile contact through the same common Break lifecycle.
The later [ice-bomb carrier/burst](IMPACT_BINDINGS.md) now delivers ability2.
Prison, portals and duplication remain unfinished.

## Primary definitions

`Binding abilities.odt` p0/p3/p8 and `Object 1/content.xml` define binding as a
constraint on permitted activity. Common Break reverses depletion into **20/s
filling**, paused by disorientation, until a total `A` is reached. The embedded
MathML/StarMath is `A = (20*B - H/500)^0.9`, where `B` is binding value and `H`
is the recipient's maximum HP. This differs from the grapple response contest;
neither its comparison nor its penalties are copied onto bindings.

`1E3.odt` p3/p43–64 supplies a 350 Qard projectile, G140/A180, speed100 m/s,
release after Active, 1200 ms cooldown after firing, target O/U110, self
O/U120 on firing, and binding value4. Each impact adds an 8 s mark; another
stack refreshes the pool. Three marks are consumed for an **8 s upper-body
freeze**, preventing attacks. The source explicitly calls firing extrinsic
momentary. The author's earlier clarification places firing self effects at
Active midpoint, independently of release and impact.

The same primary document already supplies HP8140, armor150, run6.4, Recovery250,
resistances heat150/toxin40/Qard75/electrocution150, 4000 regenerative shield,
20 s delayed loss recovery at400/s, and one toxin resistance per100 current
shield HP. Those values are now imported. The earlier inventory's missing-stat
statement described an import omission, rather than missing author material.

## Delegated choices and numerical boundaries

- Floor the threshold's base at zero: `max(0,20*B-H/500)^0.9`, keeping its
  fractional power real. Snapshot maximum HP at binding creation. The pure
  helper owns 40-digit precision, independent of the caller's Decimal context.
  A zero threshold permits immediate escape **when Break is requested**; it
  does not make a recipient automatically immune to attachment.
- Count attempted 20/s filling as **escape work**, separately from actual
  stored dyspnea. Actual gains still use the one shared capped resource writer.
  At D=100, work continues while the stored gain is zero. Otherwise a threshold
  larger than remaining bar capacity could never be completed. Crossing the
  cap still applies the existing once-only O200; that disorientation pauses
  binding filling/work. Starting already at100 does not repeatedly retrigger it.
  This cap interpretation is an engineering choice, not an author statement.
- One actor focuses one binding Break at a time. It occupies its own resource,
  with no hand, limb or point-cost requirement. Repeated input cannot multiply
  the fill rate. Explicit stop ends that attempt; resuming retains work on that
  binding instance. Progress on one binding never breaks a different instance.
  A grapple contest remains a separate source-specific interaction.
- Select an eligible binding by application time then instance identity when
  no explicit identity is supplied. Existing `break` prioritizes an eligible
  incoming grapple for compatibility, then a binding. `break_binding` selects
  binding mode explicitly; `stop_binding_break` stops its effort. An optional
  `binding_id` disambiguates independent instances. Mixed link/binding selectors
  and controller responses carrying a binding selector are rejected before any
  script input is queued. Commands retain expected actor-life checks.
- Marks pool by source actor, source life, ability, recipient and recipient life.
  Separate casters and different source lives do not combine stacks. Each real
  contact contributes once; future physical copies can contribute independent
  hits without changing their root power. The third hit consumes the pool.
  Repeated procs create independent binding instances and clocks; they do not
  silently refresh or replace a previous freeze.
- Personal shield stock absorbs damage while allowing body marks. Independent
  Block layers must permit positive overflow into their living caster; a fully
  intercepted projectile cannot mark it. Terrain contacts cannot mark a body
  behind the obstacle. Damage/status calculations retain shared pre-hit defenses.
- Stage marks after the complete damage/healing/death wave, alongside other
  released hit effects. Recipient death in that wave prevents attachment.
  Effect events at the same priority retain the engine's deterministic insertion
  order. Existing mark expiry runs before a hit tied to its expiry; durations
  are half open. Stale earlier expiry events cannot erase a refreshed pool.
- Freeze constrains controlled body functions, rather than removing physical
  momentum or gravity. Upper freeze cancels upper-body/attack owners and leaves
  legal walking/jumping possible. Lower freeze removes voluntary ground drive;
  imposed forces and falling remain. Whole-body binding additionally blocks all
  controlled actions except common Break, including actions with no effort or
  limb cost. Lower/whole creation began as labelled shared API foundations. The later
  [ice bomb](IMPACT_BINDINGS.md) now delivers actual lower freeze; whole-body
  API creation does not deliver a physical prison.
- Recipient death retires its marks, bindings, restrictions and Break; revival
  inherits none. Released projectiles, marks and freezes survive source death.
  A restriction cancels only affected controlled actions: already released
  attacks and independently deployed effects retain their own lifetimes.

## Imported movement and action data

1E3's primary basic values are imported for jump, crouch, walk/run effects,
climb and sprint. Source jump is G100/A150, Db1.5, takeoff O/U80 and landing
100/120; crouch A150, Db1, O/U80; walk/run Db0.5, O/U80; climb G150/A300,
Db3.5, O80/U250; sprint +4.8 m/s, transition Db0.5/O/U100 and listed continuous2.
Shared author-confirmed movement geometry/physics and existing effort equations
remain authoritative.

Under delegation, apply the existing common missing-value defaults: walking2,
walk/run transition150 ms, sprint transition200 ms, standing/crouch/stop rules,
and neutral initial hands. No source hand coordinates exist for this firing
action, so it uses the neutral right hand as both start/end and the existing
2 cm spherical projectile. Current torso aim and the faster gravity-compensated
arc are reused without target prediction. No projectile recoil/exertion cost is
listed; firing uses `kind:none`, rather than a Db0 calculation. The source
effort category and author's extrinsic-effort preference support that choice.

## Controls and implementation scope

```json
{"actor":"B","at_ms":3600,"command":"break_binding","binding_id":"binding:1","expected_life_generation":1}
```

`binding_effects: {"mode":"life_bound_bindings_v1"}` opts current rules into
the lifecycle, controls and reporting. It requires owned living actors and
shared continuous effort. Historical frozen inputs keep their earlier rules and
traces. Break predicts the earliest work/disorientation boundary; observations
do not decide when escape occurs. Filling pauses per binding channel, so
unrelated holding/sprint effort continues through the common resource writer.

For the canonical 10 m stationary case, projectile releases are 320/1840/3360 ms;
the third contact at 3456.909025 applies the freeze. With Break at 3600, later
fire pauses it and escape occurs about 5768.761890512 ms. At maximum HP8140,
B4 requires about 42.05795872056224 work. Uninterrupted nominal filling would
take about 2102.897936028112 ms. Normal damage, status and resource ledgers remain
inspectable in the saved captures.

The later [3E5 chain](CHAIN_CAST.md) now supplies real 30 m/s contact, 15 s/20 m
spatial binding and common Break on [curved shared paths](PERSISTENT_DISTANCES.md).
Its `distance` kind has no limb/function freeze. Binding and distance rows share
endpoint lives/expiry, and either release ends both at one timestamp. Released
contact parameters remain pinned across profile changes and projectile copies.
The later [1E1 ground chain](GROUND_CHAIN.md) now supplies typed fixed surface
anchors, separating caster attribution from physical collider lifetime. Shared
Break, expiry, recipient death, geometry changes and actual wall destruction
release its binding/anchor/distance together. The later ice bomb adds a real
8m contact burst with independent lower freezes. The later [physical prison](PRISON.md)
uses independent material HP/lifetime, without an invented binding value.
Portals, leap/kick, charge/slam and complete six-kit/5v5 coverage remain unfinished. Prone/
Get Up now use shared geometry; ledge/dynamic-support/turning remain guarded.
