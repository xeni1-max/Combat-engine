# Combat Simulation Engine

[ENGINE_STATUS.md](ENGINE_STATUS.md) is the current capability/decision index.
[PROGRESS.md](PROGRESS.md) preserves the chronological handoff and evidence.

[2E4's basic9 Dodge](DODGING.md) now uses actual downward body motion and its
own four-charge stock. This script ducks after1E1 releases a Qard projectile;
the moving hitboxes determine the miss:

```sh
python3 -B -m combat_sim run scenarios/2e4_dodge.json --summary-only
```

[Verification and frozen replay](results/2e4-dodge/README.md). Close tracking
shots, lower shots and areas can still hit during a Dodge.

The shared world uses the [authored character proportions](CHARACTER_GEOMETRY.md)
for actual hitboxes, pose, aiming, movement, climbing and support. A scripted
example uses all six profiles, including head shots, a scaled dash, a guarded
heavy punch, Qard and marking projectiles:

```sh
python3 -B -m combat_sim run scenarios/authored_body_geometry.json --summary-only
```

[Geometry and constraint verification](results/body-scales/README.md) includes
the corrections to repeated running input through taut chains and near-tangent
distance certification. The full six-kit engine remains incomplete.

The [1E2 grappling gun](GRAPPLING_GUN.md) uses a real hook collision, a finite
terrain rope and native self-launch/contact physics. This demonstration supplies
an explicit surface target and runs without an enemy:

```sh
python3 -B -m combat_sim run scenarios/1e2_grappling_gun.json --summary-only
```

Verification and reproduction are in [the checkpoint](results/grappling-gun/README.md).
Author revisions and the remaining fence import are tracked in
[the source revisions](SOURCE_UPDATES_2026-11-09.md).

The current [1E2 ability4](1E2_ABILITY4_AUDIT.md) demonstration uses actual
head/body contact, release-time intrinsic output, Aim/spread and shared defenses:

```sh
python3 -B -m combat_sim run scenarios/1e2_precision_projectile.json --summary-only
```

The full JSON trace exposes contacted parts, the selected immutable power
component, range loss, costs and physical flights. [Shared rules](BODY_PART_DAMAGE.md) ·
[Verification and reproduction](results/1e2-ability4/README.md).

Shared [native contact receipts](CONTACT_EVENTS.md) preserve the bodies, lives,
held group and wall identity that existed at impact. Owned handlers dispatch
after the physical response, even if that contact cancelled their action.
The three [2000-HP walls](DESTRUCTIBLE_WALLS.md) accept the requested damage
types. Actual [3E5 charge/grab/wall slams](CHARGE_GRAPPLE.md) now reuse swept
owned contacts, timed motor bonuses, eight-second holding/Break and the same
mutable walls. Qualifying fracture and 700-base victim damage are separate.
[Current verification](results/charge-grapple/README.md).

```sh
python3 -B -m combat_sim run scenarios/3e5_charge_wall.json \
  --terrain data/terrain/destructible_arena.json --summary-only
```

The selected [living-body support](BODY_SUPPORT.md) joins the shared saved-path
solver: native landing, pose withdrawal, stacks, death and platform destruction
retain common gravity and action ownership. The full crowded prison encounter
now completes and agrees under numerical controls. Final regression status is
in [the evidence package](results/body-support/README.md).

```sh
python3 -B -m combat_sim run scenarios/prison_crowded_contacts.json --summary-only
```

Actual force expiry at existing wall/body contact poses now preserves position
and completes the previously failing prison encounter. Relocation and revival
clearance still apply. [Earlier velocity verification](results/velocity-transitions/README.md).

```sh
python3 -B -m combat_sim run scenarios/prison_force_expiry.json --summary-only
```

[1E3's physical prison](PRISON.md) now forms a hollow 4000-HP enclosure with
shared damage/cover/expiry. Solid hand reach keeps firing origins inside thin
material. Inspect a real breakout with incoming and outgoing gunfire:

```sh
python3 -B -m combat_sim run scenarios/prison_breakout.json --summary-only
```

[Verification and concrete remaining collision/support issues](results/prison-cast/README.md).

[1E3's ice bomb](IMPACT_BINDINGS.md) now throws a physical projectile, applies
blunt contact damage and independently freezes lower bodies within 8 m. Actual
Block/terrain collisions, native momentum, common Break, death and revival
share the engine. Inspect the complete burst and binding trace with:

```sh
python3 -B -m combat_sim run scenarios/ice_bomb.json
```

[Reproduction and verified interactions](results/ice-bomb/README.md).

The current [equilibrium system](EQUILIBRIUM.md) integrates the source fall
formula with changing statuses, six-part prone geometry and paid Get Up.
Crouch, native motion, attacks, clearance, death and restoration share the same
world. A real Block counter supplies this demonstration's fall:

```sh
python3 -B -m combat_sim run scenarios/equilibrium_counter.json --summary-only
python3 -B -m combat_sim run scenarios/prone_get_up.json --summary-only
```

[Current equilibrium evidence](results/equilibrium/README.md). The full six kits
and final 5v5 experiments remain unfinished.

The [wall arena](DESTRUCTIBLE_WALLS.md) adds three 2000-HP destructible panels,
including direct and delayed Qard blast damage, continuous heat, body/projectile
collision removal and typed blunt/slash/constriction/tear damage. Run it with:

```sh
python3 -B -m combat_sim run scenarios/destructible_wall_gun.json \
  --terrain data/terrain/destructible_arena.json --summary-only
```

[1E1's ground chain](GROUND_CHAIN.md) now uses fixed terrain endpoints on the
same shared paths: a real throw, 10 m/15 s binding, common Break and independent
collider/recipient lives. Actual climb, wall destruction, held knock and revival
interactions are recorded in [the ground-chain evidence](results/ground-chain/README.md).

[Persistent distance limits](PERSISTENT_DISTANCES.md) now use one shared saved
translation path for prediction and advancement, with actual slack crossings,
curved tangential motion, joint contacts/grapples and individual force expiry.
Actual grapple-pair knocks retain summed maximum-HP/current-armor resistance
and equal group increments. [Current evidence](results/persistent-distances/README.md).
The [finite planner](DISTANCE_PATHS.md) certifies complete quadratic intervals.
[3E5's actual chain cast](CHAIN_CAST.md) now uses those paths: a damage-free
throw, moving 20 m flight limit, 15 s binding, common Break and linked endpoint
lifetimes. [Ordinary API/CLI encounters](results/chain-cast/README.md).

The current development path is in [ROADMAP.md](ROADMAP.md), with the six existing
characters and actual ability coverage in [ROSTER.md](ROSTER.md). The author has
delegated mechanics decisions for internal consistency; material choices are
documented explicitly. No animations or new character abilities are planned.

Body movement, the existing gun, 2E4's blade thrust/venom, independent heat beams and 1E2's cooldown-pause
area now run together
with damage, bleeding, statuses, dyspnea, contacts, death and 2E4's automatic
revival. Its basic-10 passive healing uses consumed recent-damage capacity and
continuous HP flow. Block adds attached forward defense layers and rechargeable
stock for 2E4/3E5, with independent right-hand attacks and released-shield
lifetimes. [Verified rules and evidence](BLOCKING.md). The
2E4 counterattack uses committed Block signals, independent direct emissions,
shared blunt/line damage and actual HP/healing/revival credit.
[Verified reactions](COMBAT_REACTIONS.md). The
[author character revisions](SOURCE_UPDATES_2026-10-31.md) supersede older
1E5/2E4 enhancement descriptions. [Shared attack modifiers](ATTACK_MODIFIERS.md)
now execute 2E4's next-thrust armor loss and timed shielding bypass. Immutable
release values preserve death/expiry behavior, and mixed simultaneous packets
share defenses without consuming ignored shield stock. [1E5's component melee](COMPONENT_MELEE.md)
now runs its actual left/right alternation, double-bleed passive and timed
piercing, with pinned hand ownership, real shared contacts and posthumous wounds.
[Atomic spatial transitions](SPATIAL_TRANSITIONS.md) coordinate external
reference/velocity changes, support loss and restoration. [Joint radial/contact
projection](TETHERS.md) adds an instantaneous API foundation for the chain;
the [persistent backend](PERSISTENT_DISTANCES.md) now supplies curved paths,
and now serves the authored chain projectile. [Persistent grapple
motion](LINKED_MOTION.md) now combines independent drives throughout movement,
forces, gravity and collisions, with life/fatigue/expiry release. The author's
[knockback rule](KNOCKBACK.md) uses summed maximum HP/current armor and moves
joined participants together. Actual [1E5 grab/holding](GRAPPLE_DELIVERY.md) now
creates these links at real contact, preserves the grab tail and transfers its
hand atomically. Its three-second constriction/tear and effort use shared
continuous shield/HP/resource flows. [Common Break](GRAPPLE_BREAK.md) now adds
life-bound response inputs, fixed filling, continuous escape and phased actual-
gain penalties on real holds. [Actual 3E5 heavy punch](KNOCK_DELIVERY.md) now
adds finite additive knocks and 100% elasticity through shared contacts, with
summed-stat group resistance, independent expiries and life boundaries.
[3E5 conditional ability 1](CONDITIONAL_MELEE.md) now supplies normal b/c punches
and its upward counter as one selectable action. Branch hand/cost/timing remain
pinned; actual motion causes select the counter, and its deferred cooldown work
starts after Active. Gravity supplies resisted upward height and real landing.
[Conditional encounters](results/conditional-melee/README.md).
[1E3's marking projectile and shared bindings](BINDINGS.md) now add real
three-hit upper-body freezing, independent mark/effect lives and common Break.
Binding filling pauses on disorientation and counts escape work separately from
actual capped dyspnea. All six source profiles now have shared movement basics.
[Binding encounters](results/binding-marks/README.md).
[Actual Break encounters](results/grapple-break/README.md).
[Existing 1E5/2E4 dashes](BODY_LAUNCHES.md) now use shared ballistic launch,
body-only action ownership, phase payment/cooldown and real contact/landing.
Independent attacks and actual holds remain active where their requirements
permit. External displacement preserves paid landing effects; death retires them.
[Dash encounters](results/body-dashes/README.md).
Sprint adds continuous effort,
weapon restrictions and exhaustion handling. Jump now retains horizontal
momentum and resolves actual landing. Declared hand/weapon/locomotion ownership
lets eligible gunfire and reload overlap movement, jump and posture, with
per-action costs and selective upper/lower-body restrictions. Gravity and
compensated short-arc aim use the same timeline:

```sh
python3 -B -m combat_sim run results/applied-hp-credit/fluid_scenario.json --summary-only
python3 -B results/applied-hp-credit/reproduce.py
```

[Moving combat rules and limits](MOVING_COMBAT.md) ·
[Action ownership and decisions](ACTION_OWNERSHIP.md) ·
[Current ownership encounters and replay](results/action-ownership/REPORT.md) ·
[Projectile identities, contact and copying](PROJECTILE_ENTITIES.md) ·
[Current combat/probe evidence](results/projectile-entities/REPORT.md) ·
[Compound world collider rules](WORLD_COLLIDERS.md) ·
[Current barrier/expiry/support encounters](results/world-colliders/REPORT.md) ·
[Typed effects and heat volumes](SPATIAL_EFFECTS.md) ·
[Moving exposure and damageable cover evidence](results/spatial-heat/REPORT.md) ·
[Continuous heat and shield recovery](HEAT_SHIELD_COUPLING.md) ·
[Coupled encounter evidence and replay](results/heat-shield-coupling/REPORT.md) ·
[Cooldown work and pause areas](COOLDOWN_PAUSES.md) ·
[Pause-area encounter evidence and replay](results/cooldown-pauses/REPORT.md) ·
[Applied HP attribution and windows](DAMAGE_LEDGER.md) ·
[Applied-HP encounters and replay](results/applied-hp-credit/REPORT.md) ·
[Effort response and current 2v2 replay](results/phase-effort/REPORT.md) ·
[Sprint demonstrations](results/sprint-combat/REPORT.md) ·
[Jump demonstrations and replay](results/jump-combat/REPORT.md) ·
[Crouch/stand demonstrations](results/posture-combat/REPORT.md) ·
[Current climb demonstrations and replay](results/climb-combat/REPORT.md).
This mode supports walking, running, sprinting, stopping, jumping, crouch/stand and climbing
with the existing gun, Qard and heat beam. Posture changes include live resizing hitboxes, clearance,
costs/statuses, lowered projectile origins and interruption at solid contact.
Other spatial actions and kits still need shared integration. Current test
counts, saved runs and both unchanged five-method review checks are recorded
in [PROGRESS.md](PROGRESS.md). The
[movement review corrections](results/principal-review-corrections-2026-10-29/README.md)
verify phase/contact ordering, live registered climb prerequisites and imposed
climb-displacement interruption across observation schedules. The restriction demonstrations
use pre-applied conditions. The subsequent [binding increment](BINDINGS.md)
delivers 1E3's marking projectile; its other casts remain unfinished.
The [principal-review response](PRINCIPAL_ENGINEERING_REVIEW_RESPONSE.md) records
five corrected defects, explicit current world physics and comparison of older
artifacts whose captured snapshot/format/diagnostic fields now differ. Frozen
inputs retain their physics and trace presentation. The
[current historical comparison](results/projectile-entities/compare_historical.py)
also classifies obsolete pending stop events for already collided flights.

Physical projectiles have independent entity IDs, source attribution and
lifecycle revisions. Explicit policies support safe owner re-contact and a
shared copy API preserves momentum and traveled-distance falloff. Labelled
engineering probes verify those foundations; actual 1E3 duplication-field
activation remains unfinished. The former 2E4 owner-contact attack was superseded
by the current source revision; retained contact-policy probes do not define a
current character ability.

Fixed world objects now support compound parts, shared HP, expiry and separate
body/projectile/area blocking. Destruction opens later trajectories; disappearing
support causes a real fall. Summaries show deployed objects' final HP and status.
Four ordinary API/CLI encounters verify these mechanics without adding abilities.
Typed heat volumes now track moving entry/exit/re-entry, independent sources,
shield depletion and cooling. Heat can burn through cover and begin fresh body
exposure at that boundary; caster death preserves released effects. Six ordinary
API/CLI captures verify that increment. Other effect types and kit deliveries remain
unfinished.

[Analytic recovery flow](RECOVERY_FLOW.md) now supplies immutable rates and work
plans for ordinary current shield regeneration from actual gun/heat histories.
[Two ordinary API/CLI encounters](results/recovery-flow/REPORT.md) verify it.
[Continuous heat/shield coupling](HEAT_SHIELD_COUPLING.md) now executes net stock
balance, immediate absorption at zero stock, warm body heat after shield
reformation and delayed recovery of newly consumed shield. Seven ordinary
encounters reproduce complete API/CLI traces. Frozen inputs retain their
historical scope; complete kits remain unfinished.

Cooldowns now store remaining work with independent pause sources. Existing
1E2 ability 2 deploys an 8 m area for 4 s; overlap and moving membership pause
ability/weapon progress while reload, heat and shield recovery continue. Eight
ordinary API/CLI captures verify it. [Rules and scope](COOLDOWN_PAUSES.md).

Actual HP loss now has an attributed ledger with proportional overkill and
immutable analytic/dense curves. Rolling 8/10-second windows retain the damage's
time distribution, including nonlinear heat under regeneration. Nine ordinary
API/CLI captures and saved-history queries reproduce. Shield/armor/construct
loss gives no recovery credit; friendly/self damage stays auditable but is
ineligible for healing/revival. [Passive healing](HEALING.md) now consumes its
allowance and couples recovery with continuous incoming HP loss;
[actual 2E4 revival](REVIVAL.md) now uses the death-time basis.
[Rules and scope](DAMAGE_LEDGER.md).

[Actor life generations](LIFE_CYCLES.md) now bind controlled work and recipient
attachments to each life while released effects retain their original source.
The shared restoration API preserves resources/debt, reconciles cooldowns/support
and wakes policies. Three ordinary API/CLI captures and a labelled restoration
probe verify the foundation. Actual 2E4 revival now uses that transition;
[passive healing](HEALING.md) now shares its HP/history foundations.
[Reproduction](results/life-generations/README.md).

[2E4 ability 1](MELEE_VENOM.md) now executes real timed melee contact, shield
overflow, slash/bleeding, attached and residual venom, independent replacement
summoning and controlled grabbing. Its existing movement basics also use the
shared world. Venom follows wounded bodies and uses live toxin resistance,
including 2E4's current-shield bonus. Four ordinary API/CLI encounters reproduce
with attributed actual HP conservation. [Evidence and replay](results/melee-venom/README.md):

```sh
python3 -B results/melee-venom/reproduce.py
python3 -B -m combat_sim run results/melee-venom/gun_duel_scenario.json --summary-only
```

[2E4 ability 5](REVIVAL.md) now revives automatically after an eligible death:
2000 ms Active, captured actual damage from the previous 10 s, three finite
charges and a 65 s cooldown. The background clock progresses while dead and
reconciles live cooldown-pause areas at restoration. Occupied poses fail without
teleporting or retrying. Five ordinary encounters reproduce complete API/CLI
traces, including real gunfire, surviving heat and body obstruction:

```sh
python3 -B results/death-revival/reproduce.py
python3 -B -m combat_sim run results/death-revival/gun_return_scenario.json --summary-only
```

[2E4 basic 10](HEALING.md) now heals for 20% of eligible actual HP damage,
within consumed 90%-of-recent-incoming-HP capacity. Full/dead/unfunded excess
is discarded. Healing changes continuous death timing and retains nonlinear
saved histories; observations do not select payout times. Five ordinary API/CLI
captures include gunfire, a heat-death delay, walking and two healers through
capped revival:

```sh
python3 -B results/hp-recovery/reproduce.py
python3 -B -m combat_sim run results/hp-recovery/heat_scenario.json --summary-only
```

Shared Block layers, rechargeable charges and 2E4's automatic counter are now
verified. Timed/next-attack modifiers now deliver 2E4's current enhancements.
Component melee now delivers 1E5's alternating attacks, double-bleed passive and
piercing Ultimate. Atomic spatial changes and persistent coupled motion are
verified with [labelled engineering links and actual combat](results/grapple-motion/README.md).
Actual [1E5 grab/drag](GRAPPLE_DELIVERY.md) now adds phase-specific hand transfer,
owned sustained damage and effort, with real life/heat/shield interactions.
Common Break/controller response and both existing 1E5/2E4 dashes now execute.
3E5's heavy punch and conditional upward counter now deliver actual knock/physics.
3E5's chain now executes with common binding Break and independent force/life
handling. Fixed-ground bindings and 3E5's charge/wall slams now execute on
those shared foundations. Pending Aim, leap/kick, portals, duplication, other
abilities and the complete six kits remain unfinished.

Current shared rules now use [character effort per controlled phase](ABILITY_EFFORT.md).
Instability reduces intrinsic Qard power at release and interrupts sustained
gun control, preserving released shots and independently deployed beams/marks.
Firing's own recoil retains its cost without cancelling that same shot. Qard and
its delayed blast now share moving-body/gravity physics, live defenses and HP
receipts. [Reproducible evidence](results/phase-effort/REPORT.md).

The author-added [grapple rules](GRAPPLE.md) now have reviewed source formulas
and tested shared calculations for fatigue, Break comparison/effort and weighted
velocity. Actual 1E5 grabs now create coupled body motion and sustained control
on the shared timeline, including actual contests and Break. Other kit
deliveries remain unfinished.

Get Up now runs on the shared combat timeline, including dyspnea, cancellation
and death. [Get Up rules and scope](GET_UP.md):

```sh
python3 -B -m combat_sim run scenarios/get_up_combat.json --summary-only
```

This repository contains a documentation audit, a shared stationary encounter engine with a 30-second 1E1 + 1E2 versus 1E1 + 1E2 demonstration and the preserved earlier duel, and six earlier scoped execution models. See [MECHANICS_AUDIT.md](MECHANICS_AUDIT.md) for source precedence, the mechanics registry, conflicts, and open rules questions.

Run the current 30-second stationary team scenario through shared gravity,
effort, effect and cooldown rules:

```sh
python3 -B -m combat_sim run scenarios/effort_stationary_2v2.json --summary-only
```

The original positions, first-team 1000-HP shields and three cubes are retained.
1E1 prioritizes beam then Qard; 1E2 prioritizes firing/reload then its pause mark.
There are no movement commands. Earlier stationary terrain rules remain
available for historical comparison:

```sh
python3 -B -m combat_sim run scenarios/stationary_2v2_terrain.json --summary-only
```

It includes approved six-cuboid bodies, hand-launched 2 cm spherical projectiles,
perfect torso aim, fixed facings, actual body/area contacts, nearest living
targets, hand Recovery, dyspnea, reloads, death/persistent effects, simultaneous
hits and delayed shield regeneration. Finite ground and three fixed 1.8 m cubes stop projectiles; area attacks ignore cover.
This historical stationary scope retains straight flights. Gravity and basic
compensated aim, moving Qard and moving heat exposure are integrated above;
predictive NPC aim remains deferred. See [terrain rules](TERRAIN.md) and [map](design/terrain/arena.svg).
[Confirmed geometry and scope](HITBOXES.md) ·
[Results](results/stationary-2v2-terrain/REPORT.md) · [Inspect timeline](results/stationary-2v2-terrain/timeline.html).
The [earlier point-based 2v2](results/stationary-2v2/REPORT.md) remains a frozen comparison.
The earlier runners below retain their individual restrictions.

[CONSISTENCY_REVIEW.md](CONSISTENCY_REVIEW.md) contains the latest general check, prioritized author questions, and reproduced implementation edge cases.

A saved [numerical demonstration](results/demo-2026-10-24/REPORT.md) compares seven scripted combat scenarios and isolated mechanics calculations. It includes scenario inputs, character values, complete event logs, exact results, and reproduction commands.

## Run the included scenario

From the project root:

```sh
python3 -m combat_sim run
```

The command prints the complete initial state, confirmed impact event, timing calculation, formula inputs/outputs, state changes, assumptions, and final state. The default scenario starts 3E5 ability 1b at 0 ms; the engine derives impact at 230 ms from Gathering 140 ms plus half of its 180 ms Active swing. To print only the per-run summary:

```sh
python3 -m combat_sim run --summary-only
```

To run the repeated-hit example, where each shield loss has its own delay:

```sh
python3 -m combat_sim run scenarios/repeated_shield_hits.json
```

To inspect overlapping shield losses sharing the single regeneration rate:

```sh
python3 -m combat_sim run scenarios/overlapping_shield_regeneration.json
```

Character and ability values are in `data/characters.json`. Current projectile timing profiles require `target_distance_m`, the path length from release point to target. The revised sources removed the old distance-free fallback anchors; archived snapshots can still reproduce an explicitly supplied historical fallback. The runner executes 3E5 ability 1b Blunt hits, controlled 1E1 ability 1, and the controlled unshielded base 2E4 ability 1. Encounter starting states and the scripted action sequence are separate sections in `scenarios/one_blunt_impact.json`; the engine, scripted input source, event log, mechanics, and run summary are separate modules.

## Run tests

```sh
python3 -m unittest discover -s tests -v
```

The tests cover Blunt, instant Qard, slash, bleeding, venomous, and dyspnea formulas; exact continuous integrals and the 2E4 exposure/recovery lifecycle; controlled projectile/blast execution, explicit area recipients, status mitigation/stacking/decay, and multi-target summaries; HP/armor state floors and nominal-versus-applied losses; adjusted-defense floors; running/Gathering ordering and self-status scaling; conditional dyspnea recovery; shield-excluded healing/revival credit; exact square-root results; shield overflow/shared regeneration; timing; unsupported-input rejection; Decimal-context independence; and deterministic replay.

## Use the new calculation helpers

```python
from fractions import Fraction
from combat_sim.mechanics.dyspnea import DyspneaContext, decay_dyspnea
from combat_sim.mechanics.damage_credit import damage_based_recovery_amount

decay_dyspnea(50, 1000, context=DyspneaContext("walking"))  # 20 remains: loses 30/s
decay_dyspnea(50, 1000, context=DyspneaContext("running"))  # 32 remains: loses 18/s
decay_dyspnea(50, 1000, context=DyspneaContext("walking", active=True))  # 50 remains
decay_dyspnea(50, 1000, context=DyspneaContext("sprinting"))  # 50 remains

# Total damage 1000 includes 800 shield damage: (1000 - 800) * 20% = 40.
damage_based_recovery_amount(1000, 800, Fraction(1, 5))
```

The dyspnea context also accepts `disoriented`, `unstable`, `on_grapple_ability`, `gathering`, and `recovering` flags. Each pauses loss. The continuous-action helper adds its documented gain as D changes; sprinting with base rate 2 now increases dyspnea because recovery is zero. A context must remain unchanged during an elapsed interval; callers split at status expiry, movement changes, or ability phase boundaries.

## Run the controlled 1E1 ability-1 test

```sh
python3 -B -m combat_sim run scenarios/1e1_projectile_and_delayed_blast.json
python3 -B -m combat_sim run scenarios/1e1_projectile_and_delayed_blast.json --summary-only
```

The stationary scenario uses a supplied 10 m projectile path, confirms the initial hit, and explicitly lists the delayed-blast recipients in `area_targets`. The self effects occur at 230 ms, release at 320 ms, initial hit at 420 ms, and delayed blast at 920 ms. Both hits deal 450 raw Qard and apply 110 disorientation/instability each. Against unshielded 2E4, each hit deals 389.5 HP damage, for 779 total; final HP is 8301 and armor remains 165.

This execution model accepts optional nonnegative initial `disorientation`/`instability`, applies the actual self and target effects, decays them continuously, and adds current disorientation to Gathering. It rejects running or repeated activations in this stage. The legacy Blunt model still rejects initial status fields because it does not execute them. `area_targets` is an explicit eligibility input, not automatic radius detection.

See [the current 1E1 results](results/self-status-unmitigated/README.md) for five numerical comparisons, initial states, calculations, event logs, pending shield timers, source/code snapshots, and reproduction commands. Earlier result folders retain their historical rules. Multi-target summaries include totals and per-target results.

## Run the controlled 2E4 ability-1 test

```sh
python3 -B -m combat_sim run scenarios/2e4_venomous_thrust.json
python3 -B -m combat_sim run scenarios/2e4_venomous_thrust.json --summary-only
```

One confirmed stationary thrust hits unshielded 1E1 at 230 ms. Direct slash damage is 412.5, bleeding totals 41.25, and venom totals approximately 856.71428571. Total HP damage is approximately 1310.46428571, final HP 6829.53571429, and final armor 141.41915584.

Damage is calculated before the new self-instability and before armor loss. Target status mitigation and venom delivery retain pre-hit armor. Self effects are 150/150 without mitigation. Venom exposure grows during the one-second attachment, then non-exposure grows until toxin damage ends another second later. Every venomous attack includes slash delivery: the toxin multiplier is post-armor slash damage divided by post-shield/pre-armor slash damage. A fully absorbed thrust has zero delivery and zero toxin damage; the formula helper handles d=0 explicitly. Bleeding lasts eight seconds. Continuous damage uses analytic integrals, with exact rational results for this base attachment; interval logs are not damage ticks.

This model requires an unshielded nonlethal target, zero initial actor instability, one action, and complete effect resolution. It rejects unsupported interactions. Replacement-blade availability, overlaps, Ultimate, healing/revival, movement, general interrupts, and action eligibility remain outside it. See [the focused audit](2E4_ABILITY1_AUDIT.md) and [saved 2E4 results](results/2e4-ability1-stage/README.md).

## Earlier scoped runner limits

These limits describe the earlier single-family models. The shared 1E1-versus-1E2 runner has its own supported scope below.

The legacy Blunt model executes 3E5 ability 1b hits. The controlled projectile model executes one stationary 1E1 ability-1 activation and its delayed area event. The venomous model executes one unshielded, nonlethal base 2E4 thrust and complete single bleed/venom effects. Both apply shield-first damage and HP/armor zero floors, and preserve per-loss shield delays sharing one regeneration rate. Qard leaves armor unchanged, confirmed by the author. Logs distinguish nominal damage, actual HP loss, and excess; excess-damage credit is not inferred.

The controlled model applies unmitigated self effects, mitigated target effects, additive stacking, decay, and initial Gathering modification. It does not enforce cooldown availability, dyspnea costs, Recovery/limb transitions, movement, targeting, general interruptions, death/revival, or autonomous decisions. Its historical routing retains 450 raw Qard without the current source's intrinsic-effort reduction. Current shared-world inputs implement that response through [phase effort](ABILITY_EFFORT.md); this controlled runner does not. The scenario supplies hit/area eligibility. Conditional shield-resistance bonuses are not scheduled.

Self disorientation and self instability **bypass all HP/armor/additional-resistance mitigation**, under the author's latest override. `self_status_value` uses the listed amount, with the existing running +20% increase; `apply_self_status` adds it to current status. Thus self N=100 applies 100 while stationary or 120 while running, regardless of defenses. Incoming target effects still use collision mitigation. The maximum-dyspnea self-trigger helper also uses this exemption.

Running modifies base Gathering only before adding current disorientation. Base 140 with existing O=80 gives 168+80=248 ms. A listed self effect of 80 becomes 96 while running, producing 264 ms Gathering if that is the supplied current state. `self_status_value` handles this increase without mitigation; the controlled encounter model itself remains stationary. The preceding mitigated-self stage is historical.

Shared helpers support slash damage/armor loss, bleeding rate/integral, venom rate/full-phase integral, dyspnea state changes, and shield-excluded recovery entitlement. Adjusted defenses floor before squaring; each venom factor floors before multiplication. The controlled 2E4 model executes one bleed and venom lifecycle. Overlap/history, shielded continuous damage, healing caps, and revival remain outside it.

Timing profiles cover six primary characters. Timing fields alone do not establish ability delivery; consult the current shared support index above. The base 2E4 ability-1 model has the explicit limits above. 1E5 ability 1 has 150/150 self effects on impact; its earlier 80-after-Active chain is historical. Current shared component melee now executes that source timing with pinned hands, phase power and actual contacts; see COMPONENT_MELEE.md. Historical timing-only contact anchors required external events; current shared
3E5 Ultimate now resolves its own physical contacts. See [charge delivery](CHARGE_GRAPPLE.md).

Damage uses exact rationals and, for the heat model, symbolic square-root amounts. Status mitigation uses fixed 40-digit Decimal precision; continuous dyspnea uses 50 digits with a fixed context. Decimal values are labeled accordingly. Impact times round up to integer milliseconds. Old result directories preserve their own earlier rules and inputs.

## Run the controlled 1E1 ability-4 heat beam

```sh
python3 -B -m combat_sim run scenarios/1e1_heat_beam.json --summary-only
```

Against unshielded 2E4 (HP 9080, armor/heat resistance 165), the beam deals approximately **4519.353570 HP damage**, leaving **4560.646430 HP** and unchanged armor. It starts at 180 ms, ends at 3180 ms, and residual heat ends at 4680 ms. Damage accumulates continuously; exact square-root expressions are preserved alongside decimal display approximations. Heat uses current armor and heat resistance for each interval, unlike venom's fixed delivery snapshot. It adds no disorientation or instability.

The established scope is one stationary, nonlethal beam with explicit unshielded recipients, no initial caster instability, and no other actions. Movement, shielded exposure, overlap, interrupts, cooldown eligibility and death remain outside this model. Full audit and open rules are in [1E1_ABILITY4_AUDIT.md](1E1_ABILITY4_AUDIT.md); saved comparisons and reproduction instructions are in [the heat results](results/1e1-ability4-stage/README.md). The heat encounter stage passed **221 tests**; the subsequent ratio-analysis stage passes **232 tests**.

## Compare heat exposure and residual damage

[The parameter study](results/heat-ratio-analysis/REPORT.md) derives the ratios and compares k, duration, output and defenses. [The standalone interactive comparison](results/heat-ratio-analysis/comparison.html) lets you select k, exposure duration and zero-defense shield potential or unshielded 2E4. The comparison was prepared before the final shield decision. The author now confirms shields take residual heat, which ends at shield break without transferring to HP. Shielded combat is not yet implemented; see the current [heat audit](1E1_ABILITY4_AUDIT.md).

```sh
python3 -B results/heat-ratio-analysis/build_results.py
```

For unchanged defenses/output, residual adds `1/k` of the exposure damage and accounts for `1/(k+1)` of the combined total. Zero damage has an undefined damage ratio. General-k analysis is separate from the k=2 encounter runner.

## Run 1E2 ability 1

```sh
python3 -B -m combat_sim run scenarios/1e2_slash_projectile.json --summary-only
```

Base Gathering is **0 ms**. Self effects apply at 20 ms, release occurs at 40 ms, and the automatic **360 ms weapon cooldown** ends at 400 ms. This weapon process blocks no other actions and does not wait for character statuses; subsequent actions are outside the single-shot runner. Current disorientation still adds to Gathering under the existing rule.

At 100 m against unshielded 2E4, raw damage falls from 437 to 412, direct slash deals **359.550971**, and bleeding adds **35.955097**. Final HP is **8684.493932**; armor is **157.071520**. Impact is 154 ms, and bleeding ends at 8154 ms. The initial scope uses one stationary confirmed hit, explicit distance, a loaded weapon authorized by the scenario, and a nonlethal unshielded target. Ammo/reload execution, repeated fire, shielded bleeding, movement and general interruptions remain outside it.

The complete suite passes **254 tests**. See [the focused audit](1E2_ABILITY1_AUDIT.md) and [eleven reproducible numerical runs](results/1e2-ability1-stage/README.md).

## Shielded and repeated 1E2 gunfire

```sh
python3 -B -m combat_sim run scenarios/1e2_shield_overflow.json --summary-only
python3 -B -m combat_sim run scenarios/1e2_repeated_fire.json --summary-only
```

Shields absorb raw bullet damage before armor, and only overflow can create HP bleeding. Individual eight-second bleeds add independently and continue damaging HP after shield regeneration. The finite repeat-fire policy fires when ready, tracks magazine ammo, and keeps weapon cooldown independent of character statuses. Eleven shots at 100 m into shielded 2E4 remove 4000 shield and deal **396.545678 HP damage** in total.

**285 tests pass.** [The latest repeat-fire report](results/1e2-repeat-fire-stage/README.md) includes shield-overflow, multiple-bleed, ammo-exhaustion and regeneration cases. Reload executes current-disorientation Gathering followed by 1800 ms Active and may overlap automatic weapon cooldown. The next shot waits for both. Disorientation does not insert Gathering once an ability is already Active, including continuous abilities; its accuracy penalty still applies. The earlier single-shot result package is historical.

To run twelve shots across a reload:

```sh
python3 -B -m combat_sim run scenarios/1e2_reload_cycle.json --summary-only
```

Shot eleven releases at 4040 ms; current O=115 delays reload Active until 4155 ms. Reload completes at 5955 ms and shot twelve releases at 5995 ms. Repeated cubic armor loss can grow exact fractions rapidly; the engine explicitly rejects impact results beyond its 12000-bit arithmetic budget without rounding the rules. This limits some long encounters; see the latest report.

## Run one 1E1 Ultimate grenade

```sh
python3 -B -m combat_sim run scenarios/1e1_ultimate_poison_grenade.json --summary-only
```

This controlled run equips the launcher, fires one grenade at a supplied 60 m path, and places 2E4 in its cloud for an explicitly supplied two seconds. Another two seconds of residual poison follows. The cloud still exists for its documented eight seconds. Poison bypasses shields and leaves armor unchanged. Area disorientation/instability apply once at detonation to all supplied explosion recipients.

HP damage is **4464.640789**, leaving 2E4 with **4615.359211 HP**, unchanged shield 4000 and armor 165. The simulation resolves cloud expiry at 9620 ms and leaves nine grenades. Exposure windows are scenario inputs; movement and spatial hit detection are not simulated. Full eight-second exposures can be lethal and are rejected by this nonlethal scope. Repeated grenades, Ultimate availability/65 s cooldown anchor, initial caster statuses across equip/fire transitions, changing resistance, overlap and death remain outside it.

**311 tests pass**. See [the focused audit](1E1_ULTIMATE_AUDIT.md) and [the numerical results](results/1e1-ultimate-stage/README.md).

## Compare repeated damage over ten seconds

[Interactive damage-over-time curves](results/repeated-10s-comparison/comparison.html) compare all six executable ability families against canonical 1E1, 3E5 and 1E5, with full 4000 shield or without shield. The window is ten seconds; all new shield losses remain ineligible for regeneration. [The full report](results/repeated-10s-comparison/REPORT.md) includes HP/shield totals, HP-zero times, every input/event log, curves and CSV exports.

```sh
python3 -B results/repeated-10s-comparison/build_results.py
```

The separate benchmark uses fixed 50-digit numerical arithmetic and analytic integrals; all 36 cases agree with 80-digit evaluation within 1e-20 in checked metrics. This avoids repeated exact-fraction growth without inventing gameplay rounding. Targets are passive and hits confirmed; dyspnea costs, accuracy, movement and defensive abilities are excluded. Observation stops at HP=0 without defining death or victory. The original exact encounter runners remain separate. **329 tests pass**, including precision, cadence, shield heat boundaries, independent damage effects and sampling invariance.

## Shared 1E1 versus 1E2 encounter

```sh
python3 -B -m combat_sim run scenarios/1e1_vs_1e2_shared.json --summary-only
python3 -B -m combat_sim run scenarios/1e1_vs_1e2_shared.json
```

Both characters act on one clock for 10 seconds at a supplied 10 m distance, starting with canonical HP/armor and full 4000 shields. A separate priority policy selects 1E1's independent beam when ready, then its projectile; 1E2 fires when ready and reloads its empty magazine. New incoming disorientation extends Gathering already in progress; Active does not gain Gathering. Heat, delayed blasts, gunfire and independent bleeds update the same character states.

This is a controlled interaction study: hits are confirmed, each area explicitly affects the selected target only, and dyspnea/physical Recovery eligibility are excluded. An unresolved coupled simultaneous event is rejected. Observation stops at the horizon or first HP zero, preserving pending actions/effects without inferring death or victory. Regeneration is not eligible within this window; longer shared-regeneration encounters are rejected. The earlier exact runners retain their own scoped limits.

Character instances and action priorities are configured in the scenario; formulas remain in `combat_sim/mechanics`, shared states in `battle_models`, execution in `shared_engine`, decisions in `battle_actions`, and summaries in `battle_analysis`. [The stage audit](SHARED_ENCOUNTER_AUDIT.md) records source references and remaining gaps. [The saved report](results/1e1-vs-1e2-shared/REPORT.md) includes inputs, initial/final states, all events, curves and numerical checks.

```sh
python3 -B results/1e1-vs-1e2-shared/build_results.py
python3 -B -m unittest discover -s tests -q
```

## Shared-engine movement geometry test

```sh
python3 -B -m combat_sim run scenarios/scripted_movement_geometry.json --summary-only
python3 -B -m combat_sim run scenarios/scripted_movement_contact_stop.json --summary-only
```

Runs walking/running transitions and jumping on the shared combat timeline,
with continuously positioned bodies and temporary contact stops. The author
selected geometry/timing only; effects and attacks are excluded. The completed
special-stop test is linked below; ordinary linear stopping remains deleted.
[Results](results/scripted-movement-shared/REPORT.md) ·
[Stopping review](STOPPING_REVIEW.md).

The completed geometry/timing test now also includes special stops and all
three jump modes:

```sh
python3 -B -m combat_sim run scenarios/scripted_movement_stopping.json --summary-only
```

[Latest movement results](results/scripted-movement-stopping/REPORT.md) ·
[Position/speed/height inspection](results/scripted-movement-stopping/timeline.html).

Climbing now checks the inclusive 0.5 m origin-to-surface range once at Active
start, allowing walking/running during Gathering:

```sh
python3 -B -m combat_sim run scenarios/scripted_moving_climb_geometry.json --summary-only
```

[Climb rules](CLIMBING.md) · [Results](results/climbing-active-start/REPORT.md).

Crouch, stand-up and sprint geometry/timing:

```sh
python3 -B -m combat_sim run scenarios/scripted_crouch_sprint_geometry.json --summary-only
```

[Rules and limits](CROUCH_SPRINT.md) · [Body diagram](design/postures/standing_crouch.svg) ·
[Results](results/crouch-sprint-shared/REPORT.md).
