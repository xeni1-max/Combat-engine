# Instability-based special stopping — confirmed rules

Author clarifications, 2026-10-25. Ordinary linear stopping is deleted. Walk/run
transitions and standing-to-walking acceleration retain their separate rules.

## Special slide

- Sliding starts at **Active start**.
- `Details.odt`: stopping contributes base disorientation and instability
  **150 per 5 m/s** of original travel speed.
- Slide duration in milliseconds equals that stop's **base instability**, without
  running's +20% modifier and without including pre-existing accumulated status.
- Unmitigated slide distance is **0.5 m per 10 m/s** of original travel speed.
- Resistance uses maximum HP H and current armor a:
  `S2 = max(0, S − (H/500 + a/10)^1.1 / 250)`.
- When resistance cancels the distance, the character stops travelling immediately.
  The authored stopping Active duration remains; no backwards travel is produced.
- Slide speed **decays linearly to zero**. The author explicitly approved deriving
  initial slide speed from the mitigated distance and duration, even when that
  is lower than the movement speed immediately before stopping.

For mitigated distance d, duration T seconds, and elapsed time 0 ≤ t ≤ T:

```
initial slide speed = 2d / T
speed(t) = (2d / T) × (1 − t/T)
distance(t) = d × (2t/T − (t/T)²)
```

At T, distance travelled is exactly d and velocity is zero. This curve describes
special sliding after resistance. It does not restore the deleted rule which
slowed from the original running speed to zero over the same duration.

## Current characters

Maximum HP 8140, current armor 150:

| Original speed | Base instability / duration | Raw slide | Mitigated slide | Initial slide speed |
|---|---:|---:|---:|---:|
| Walking, 2 m/s | 60 / 60 ms | 0.1 m | 0 m | 0 m/s |
| Running, 6.4 m/s | 192 / 192 ms | 0.32 m | 0.1434558179 m | 1.4943314368 m/s |

Stopping Active was specified as 150 ms per 5 m/s; with the current base-duration
rule, Active and slide end together when sliding begins at Active start.

## Implementation and test scope

[mechanics/stopping.py](combat_sim/mechanics/stopping.py) calculates distance,
base-instability duration and the linear slide curve with explicit numerical
precision. The shared event loop executes `stop` as a special slide and records
its original speed, resistance, initial slide speed, duration and completion.
Body/cube contact can interrupt the slide under the temporary stop-only response.

Nine pure slide tests and shared-engine integration tests verify running and
walking stops, midpoint distance/speed, final zero velocity, collision cancellation,
precision and regression preservation. The full suite passes **591 tests**.
[Saved shared-engine test](results/scripted-movement-stopping/REPORT.md).

The author selected geometry/timing first. Actual stopping penalties, movement
statuses and dyspnea payments remain excluded in that explicit test scope.
Temporary cube/body contact stops are independently specified responses.
