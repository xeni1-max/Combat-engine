# Angular static and living support

2026-11-13. Delegated engineering integration; no new character ability or
character data. [Evidence](results/angular-support/README.md).

Native turns now use the existing finite-ground, raised-surface and living-body
support policy. Any real underside may supply support. Every footprint SAT axis
needs intersection width greater than the existing 1e-20 m band, including each
part's own projected width. The underside/top gap remains within that same
vertical band. Whole-body containment, frictional carrying and an invented
balance force are not introduced. Other parts and alternate parents are checked
before declaring loss; one foot leaving does not imply a fall.

## One path and support response

Support prediction runs during saved-reference construction. The pure
`TurnControl.path_from_piece` composes heading and pose against that candidate
BodyPathPiece without looking up/rebuilding a saved frame. Query slices retain
the original yaw anchor. Both living participants may rotate. Reference and
signed vertical-face polynomials are combined before bounding, so common
translation/gravity or compensating local pose cannot create fictitious drift.

Shared rational interval/derivative bounds now live in angular_intervals.py;
fields keep their previous forward-open-cell behavior. Support retains its
actual initial witness and consumes the confirmed side of a loss bracket,
including a remaining contact shorter than temporal resolution. Absolute
millisecond boundaries round upward at owned precision before the existing
lease/constraint clocks use them. No query extrapolates a candidate prefix.

The existing support closure selects an alternate parent or releases support
after atomic reference consumption. It preserves position, instantaneous
velocity, independent inputs and earned landing obligations. Existing gravity,
contacts and life ownership decide falling/landing. Departure adds no jump fee
or basic-jump landing penalty. Body support retains its existing vertical
constraint response; rotation supplies no new horizontal carrying force.

## Corrected contact bounds and edge revalidation

The co-falling world exposed a query defect: independent swept enclosures
overlap even when two touching faces retain exact separation. Box-path contact
now additionally bounds their relative reference polynomial and local geometry.
Vertical relative faces combine all signed coefficients before bounding. The
original world paths still confirm contact, provide witnesses/velocities and
retain collision response. No reference is moved or independently integrated.
The retained old/new geometry probe and actual world distinguish this correction
from simply raising a search budget or ignoring contacts.

An outward floor graze also exposed a missing angular consumer of the existing
separating-edge rule. When a footprint gap is within the contact band and its
actual angular derivative/acceleration is outward, it cannot create a vertical
impact. Prediction requires a new, deeper entry before nominating that departing
edge again. Actual inward sheet-edge/corner impacts retain their normal response;
underside contact does not establish ground support. This matches the selected
fixed-frame contact policy and preserves the shared pre-impact status snapshot.

## Scope

Tests exercise all six source scales, partial floor/deck contact, walking and
turning after an actual climb, rotation-only static/head-support loss, alternate
tops, both rotating participants, a co-falling stack, support expiry and crouch.
Native return, underside and finite-edge contacts and the outward graze are
checked separately. Complete captures label ordinary movement/casts separately
from explicit engineering placements/velocities; those placements are not new
character abilities.

[Active grapple/tether response](ANGULAR_LINKS.md) now preserves reference-space
metrics, real angular contact lifetimes and shared impact snapshots.
Prescribed angular climbing remains guarded.
Prescribed linked climbing, the final cross-kit matrix and reproducible 5v5 are
still unfinished. Advanced NPC behavior, mass experiments and balancing remain
deferred. See the evidence package for current counts and retained diagnoses.
