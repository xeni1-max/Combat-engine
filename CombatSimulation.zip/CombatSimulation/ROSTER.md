# Six-character roster and implementation inventory

Inventory begun **2026-10-25**; support reviewed **2026-11-14**. The roster is
**1E1, 1E2, 1E3, 1E5, 2E4 and 3E5**. This
inventory records their existing abilities; it does not add abilities.

Author-provided body traits now feed the shared geometry:1E5 is1.3 times the
reference height and1.6 times its width/depth;3E5 uses1.05 and1.15 respectively.
Standing heights are2.275 m and1.8375 m. Other profiles retain the approved
1.75 m reference. [Geometry and delegated pose choices](CHARACTER_GEOMETRY.md) ·
[Current verification](PROGRESS.md).

Primary sources are the six root character ODTs and the author's subsequent
clarifications. Paragraph references below count all ODT text paragraphs from
zero, including empty paragraphs. Original documents remain unchanged.
Runtime evidence comes from [character data](data/characters.json),
[shared engine](combat_sim/shared_engine.py),
[controlled-runner dispatch](combat_sim/engine.py), and the
[passive-target benchmark](combat_sim/benchmark.py).

## What the support labels mean

[Effort categories](ABILITY_EFFORT.md) describe controlled character effort per
phase. They do not follow the duration of a summoned effect. Current shared
rules integrate Qard's intrinsic release power and gun control interruption;
metadata/formula helpers alone do not establish other kits' delivery. Legacy
damage handlers retain the explicit boundaries recorded there.

- **Shared combat:** executable on the common encounter timeline with the
  documented scenario restrictions. All six current creative kits have shared
  delivery within the boundaries below. Actual current-rule interaction proof
  is tracked separately from historical fixture tests. See
  [current scope](ENGINE_STATUS.md).
- **Controlled runner:** executable only in a separate restricted scenario;
  it is not integrated into shared combat.
- **Benchmark:** numerical repeated attacks against a passive target, not a
  shared battle or evidence that the character's full kit works.
- **Metadata:** some source/timing fields exist in `data/characters.json`,
  but the ability is not executable.
- **Source only:** documented in the ODT but not yet represented as an
  executable ability or a dedicated metadata entry.

## Existing combat abilities

Descriptions summarize the authored kits. Detailed formulas, timing,
restrictions and later clarifications remain in the primary sources and
mechanics documents.

| Character / ability | Authored behavior | Current support |
|---|---|---|
| 1E1 / 1 | Qard projectile with base damage 450; impact location creates another blast after 0.5 s, radius 4 m. | Shared stationary/moving combat with intrinsic release power U/10 and inherited blast power; historical controlled runner/benchmark retain their scope. |
| 1E1 / 2 | A chain attaches the target to ground for 15 s; length 10 m. | Actual shared 30 m/s throw, G180/A220, Db3.5, B6, 9 s cooldown and common Break; fixed surface anchors, joint contact/grapple paths, source-independent lifetime, wall destruction and recipient revival compose. [Rules](GROUND_CHAIN.md). |
| 1E1 / 3 | Leap with initial speed 15 m/s. | Actual shared fixed-speed launch, G140/A250/Db3.5, 9 s cooldown, source takeoff/landing effects, independent hands and native flight/support/lives. Distinct from basic jump. [Rules and controls](LEAPS.md); verification in PROGRESS.md. |
| 1E1 / 4 | Summon a heat beam at a location for 3 s. | Shared stationary/moving combat with independent exposure, cover changes and continuous shield recovery; controlled runner; benchmark. See [scope](SPATIAL_EFFECTS.md). |
| 1E1 / Ultimate | Equip a poisonous grenade launcher; ability 1 fires impact grenades, radius 5 m, poison cloud 8 s, 10 rounds. | Actual owned 400 ms/Db2.5 swap, per-actor inventory, paid grenade firing, gravity/first-contact poison, frozen release definitions, copying/lives and empty return. Current source65 s cooldown; historical controlled 300 ms equip remains. [Rules](LAUNCHER.md); verification in PROGRESS.md. |
| 1E2 / 1 | 437-damage slash projectile firearm; 11 rounds per magazine. | Shared combat with reload and phase-specific sustained control/interruption; historical controlled runner/benchmark retain their scope. |
| 1E2 / 2 | Mark a radius-8-m area for 4 s; cooldowns pause inside. | Shared moving combat; independent overlapping fields pause ability/weapon work. See [rules](COOLDOWN_PAUSES.md). |
| 1E2 / 3 | Grappling gun launches the character; rope length 30 m. | Verified physical hook, explicit world/surface targeting without an enemy, separate firing/launch payments, finite terrain rope and native arrival effects. [Rules/evidence](GRAPPLING_GUN.md). |
| 1E2 / 4 | Projectile deals 600 damage, or 1500 on a headshot. | Actual shared direct projectile: source firing/recoil/cost, independent 9 s cooldown, intrinsic release snapshots, actual body/head/Block/terrain contacts, range loss and shared defenses. [Audit](1E2_ABILITY4_AUDIT.md); verification in PROGRESS.md. |
| 1E2 / 5 | Summon a fence for 6 s; 800 damage/s and movement prevention. New detail: 20 m × 1.5 m, five 4-m parts with 1500 non-toxin/non-electrocution HP each. | Actual shared owned summon, five independent materials, continuous body contact, one electrical stream per contact episode, lower-body B2/common Break, gaps, destruction and independent lives. No summon dyspnea. Axis-aligned placement and other delegated rules in [ELECTROCUTION_FENCE.md](ELECTROCUTION_FENCE.md); final verification in PROGRESS.md. Detailed 20 m takes precedence over the old 15-m overview. |
| 1E2 / Ultimate | Impact device deals 900 Qard damage in radius 8 m and adds 250 ms Gathering for 6 s. | Actual shared intrinsic throw, ballistic first-contact explosion, simultaneous body/material damage, source/recipient lives and timed maximum/committed Gathering. No extra direct carrier hit. [Delivery](IMPACT_AREAS.md), [preparation](TIMED_GATHERING.md); verification in PROGRESS.md. |
| 1E3 / 1 | 350 Qard projectile applies an 8-s mark; three marks consume the marks and freeze the target's upper body for 8 s. | Actual shared marking projectile, source/life-specific refreshed pools, independent upper freezes and common binding Break. [Rules](BINDINGS.md). |
| 1E3 / 2 | Impact ice bomb freezes lower bodies in radius 8 m for 10 s. | Actual shared throw/contact burst, lower binding/Break, independent lives/expiry; delegated 200 blunt contact damage, no area HP damage. [Rules](IMPACT_BINDINGS.md). |
| 1E3 / 3 | Two allied-use portals, current location to a point up to 10 m away; last 8 s, reusable every 2 s. | Actual owned300ms/no-dyspnea pair release, explicit allied use, offset/motion-preserving atomic grapple transport, tether/exit checks and per-user/pair/life shared reuse work. Source death, native support/contact and pause fields compose. [Rules/boundaries](PORTALS.md); verification in PROGRESS.md. |
| 1E3 / 4 | Impact projectile traps the target in a 4000-HP prison cube for up to 12 s; cube blocks damage from both sides. | Actual damage-free utility contact creates a hollow six-face shared-HP collider; native cover, destruction, expiry and independent lives. [Rules/boundaries](PRISON.md). |
| 1E3 / Ultimate | Radius-12-m area lasts 25 s; allied projectiles duplicate and separate by 4 m. | Actual owned 300ms/no-dyspnea activation, fixed field and continuous entry, symmetric split, inherited per-field lineage, retained power/accuracy/payload/travel/source lives, native endpoint impacts and independent expiry. [Rules](PROJECTILE_DUPLICATION.md); verification in PROGRESS.md. |
| 1E5 / 1 | Alternate left/right arm-blade swings, 440 slash damage each. | Actual shared component melee: pinned hand/action identity, midpoint physical contacts, consecutive Gathering, independent movement and ordinary defense/HP snapshots. [Rules](COMPONENT_MELEE.md). |
| 1E5 / 2 | Grab and drag a target along ground for 3 s, dealing 900 constriction/tear damage/s. | Actual physical grab, complete Active tail, atomic hand transfer, holding damage/effort, linked movement, life cleanup and common Break/response. [Delivery](GRAPPLE_DELIVERY.md), [escape](GRAPPLE_BREAK.md). |
| 1E5 / 3 | Dash 13.5 m away. | Actual shared ballistic launch, body-only ownership, Active-start Db2.5/cooldown, physical contacts and life-bound landing effects; linked holds and independent attacks compose. Trajectory/direction defaults are delegated. [Rules](BODY_LAUNCHES.md). |
| 1E5 / 4 | Attacks apply twice the bleeding. | Actual actor-specific passive release modifier and doubled post-armor wound basis; source/life attribution, shielding and posthumous damage verified. [Rules](COMPONENT_MELEE.md). |
| 1E5 / Ultimate | For 15 s, ability 1 gains 80 piercing. | Actual 320 ms activation/65 s cooldown and timed release capture for both arms; expiry preserves old wounds. [Rules](COMPONENT_MELEE.md). |
| 2E4 / 1 | 440-damage blade thrust with slash delivery, attached venomous blade for 1 s, then automatic replacement blade. | Shared moving combat: actual timed melee contact, shield/armor snapshots, bleeding, attached/residual venom with live toxin resistance, independent summoning and owned grab. [Rules and limits](MELEE_VENOM.md). Earlier runner/benchmark preserved. |
| 2E4 / 2 | A successful block consumes a charge and releases a 500-damage attack 5 m forward; one charge, replenished every 9 s. | Actual automatic shared reaction: causal defense snapshots, line/cover delivery, statuses, refill/pauses/death and HP/healing/revival credit. [Source versus delegated rules](COMBAT_REACTIONS.md). |
| 2E4 / 3 | Dash 14 m. | Same shared launch/landing system, with its own range and 2.85 s cooldown; current simple policy moves toward the requested enemy. [Rules](BODY_LAUNCHES.md). |
| 2E4 / 4 | Next ability-1 attack removes 20 additional armor. | Actual shared enhancement: 200 ms Active, 9 s cooldown, once-only release capture, shield/armor/cover handling and life retirement. [Rules](ATTACK_MODIFIERS.md). |
| 2E4 / 5 | Upon death, revive with HP based on damage dealt in the preceding 10 s; three charges and 65-s cooldown. | Actual shared death trigger, 2000 ms attempt and life transition; finite charge stock, background cooldown and occupied-completion handling. [Source versus delegated rules](REVIVAL.md). |
| 2E4 / Ultimate | For 10 s, ability 1 ignores 4000 shielding. | Actual shared timed enhancement: 400 ms Active, 60 s cooldown, finite per-packet bypass across Block/personal layers, simultaneous sharing and posthumous snapshots. [Rules](ATTACK_MODIFIERS.md). |
| 3E5 / 1a | Against a target dashing or knocked toward the attacker, upward punch deals 600 Blunt damage and knocks the target 15 m upward. | Actual branch of shared ability 1: documented motion cause/closing predicate, pinned right hand/Db3/G180/A220, private after-Active 4 s cooldown and gravity-based resisted up launch/group deflection. [Rules](CONDITIONAL_MELEE.md). |
| 3E5 / 1b, 1c | Otherwise alternate right/left punches, 300 Blunt damage each. | Actual normal cycle of shared ability 1, pinned hands/Db1.8/G140/A180, consecutive Gathering and individual blunt defenses/statuses; available while counter cooldown runs. Legacy scalar/benchmark paths preserved. [Rules](CONDITIONAL_MELEE.md). |
| 3E5 / 2 | Chain target to the character for 15 s, length 20 m; linked motion at maximum separation. | Actual shared damage-free throw, G180/A220, 30 m/s gravity flight with moving-anchor limit, Db3.5/9 s cooldown, O/U effects, spatial binding and common Break. Persistent slack/tangential/contact/force motion and endpoint lives compose. [Rules](CHAIN_CAST.md). |
| 3E5 / 3 | Leap at initial speed 20 m/s and kick downward while falling; first hit takes 600 damage and downward knock. | Actual shared fixed-speed launch, controlled descending foot contact, intrinsic contact power, shared Blunt/shield/Block/material/life handling and summed-stat grapple knock. Prone/Get Up remains a separate balance result. Delegated 15 m/500 ms down impulse and foot proxy in [LEAPS.md](LEAPS.md); verification in PROGRESS.md. |
| 3E5 / 4 | Heavy punch deals 600 damage, knocks the first target 15 m away and grants 100% elasticity during that knock. | Actual shared timed contact, blunt defenses/statuses, Db3/cooldown, additive finite knock components, summed-stat grapple motion and elastic wall/body/ground contacts. Force duration/contact proxy and causal ordering are delegated. [Rules](KNOCK_DELIVERY.md). |
| 3E5 / Ultimate | Forward charge with temporary +50% speed, grab first target, hold for 8 s; qualifying wall impacts deal 700 damage and destroy walls. | Actual owned swept grab, complete 180 ms tail, shared holding/Break, speed expiry/reset and committed wall slams; delegated 600 DPS/Dd2 drag. [Rules](CHARGE_GRAPPLE.md). |

Overview sources: [1E1.odt](1E1.odt) p0–30,
[1E2.odt](1E2.odt) p0–34, [1E3.odt](1E3.odt) p0–28,
[1E5.odt](1E5.odt) p0–32, [2E4.odt](2E4.odt) p0–36,
[3E5.odt](3E5.odt) p0–36. Overview wording does not supersede later
detailed ability sections or recorded author clarifications.

Current interaction boundary, 2026-11-14: all creative rows above have shared
delivery within their declared scope. Static/finite/living support departure,
initial heading, native turns and prescribed linked climbing are integrated.
The [current six-kit audit](KIT_INTERACTIONS.md) separates actual execution paths
and current positive witnesses from historical fixtures. Final cross-kit and
reproducible5v5 evidence remain unfinished; those limits do not make delivered
portals/leaps missing. Detailed source revisions supersede old overview wording.

## Basic abilities and shared systems

The author's [effort/dyspnea policy](DYSPNEA_POLICY.md) confirms eight no-cost
effects. Summons, marks, passives and enhancements need no invented cost;
documented recoil/block/attack effort retains its own cost. Cost metadata alone
does not mean the corresponding ability is executable.

[Applied-HP attribution](DAMAGE_LEDGER.md) now runs for current shared attacks
and effects, with shield exclusion and rolling histories. This supplies recovery
bases. [Life generations/restoration](LIFE_CYCLES.md) now run in the shared world;
2E4's [actual revival controller](REVIVAL.md) now supplies its death trigger,
timing, charges and payout. [Basic-10 passive healing](HEALING.md) now pays
from actual eligible HP with consumed incoming-loss funding and continuous
HP/death integration. Earlier
restoration API probes retain their explicit foundation scope.

2E4's authored movement basics now use the same shared combat implementation:
run 8 m/s, upward jump 4 m/s and sprint 14 m/s, with imported source costs and
self effects. Walking/transition/hand geometry gaps use the documented delegated
defaults in [MELEE_VENOM.md](MELEE_VENOM.md). Its shield's live toxin-resistance
bonus also executes for attached venom. Block, the authored counter and both
current enhancements and common grapple Break now execute. Its [dash](BODY_LAUNCHES.md)
now uses the shared body launch system; complete interaction coverage remains incremental.
The old owner-contact attack was removed by the author’s source revision.
1E5 now uses shared [component melee/passive/Ultimate and movement](COMPONENT_MELEE.md).
Its [grab/drag](GRAPPLE_DELIVERY.md) now executes with owned phase resources,
continuous damage and effort. Basic grapple Break now executes on real holds.
Its remaining main ability, the 13.5 m away dash, now executes through the same
shared flight/landing system. This does not establish complete six-kit coverage.

All six document basic jump, crouch, walk, climb, sprint, break, and a
4000-HP regenerative shield. Basic **Break** belongs to the authored grapple
escape mechanic (`Grapple abilities.odt` p10); [its controller](GRAPPLE_BREAK.md)
now handles live holds, response, fixed filling, continuous escape and penalties.
It is separate from physical **special stopping**, which uses opposite movement
input and the slide/instability rule in `Details.odt` p38. This corrects the
earlier inventory’s conflation without inventing another ability. The shield
loss delay is 20 s with a
shared 400 HP/s regeneration rate. A scenario may start below capacity.

Additional basics:1E2 has aim and reload;2E4 now lists Block at basic8, Dodge
at basic9 and healing for20% of damage dealt;3E5 has block. Current basic9 now
executes a physical75 ms downward dip/75 ms return, Db3.5 and independent four-
charge stock with4500 ms serial recharge. Native contact, interruption, source
life and concurrent hands use the shared world. The downward variant is a
documented delegated choice. [Rules](DODGING.md) ·
[Evidence](results/2e4-dodge/README.md).
[Source revision and pending imports](SOURCE_UPDATES_2026-11-09.md).

Historical checkpoint, 2026-11-03: [1E2 Aim](AIMING.md) is an actual owned 160 ms toggle
with running restrictions, interruption/death handling and deterministic released
spread. Gun recoil/disorientation still affects its cone; Aim removes only the
source unaimed increment. Walking/crouching, physical copies, real holding,
wall destruction and prison/ice contact compose with the same projectile world.
That Aim checkpoint did not yet include ability4. Its subsequent actual direct
shot and head/body damage are now documented in the ability table above.
[Evidence](results/aim-toggle-confirmed-entry/README.md).

Current common movement covers all six profiles, including native turns,
standing/crouch/prone/Get Up geometry, flight/support and linked climbing.
[Current capability index](ENGINE_STATUS.md) and [audit](KIT_INTERACTIONS.md).

Historical geometry checkpoint (2026-10-25): for1E1 and1E2,
walking/running transitions, special stopping, jumping,
climbing, crouching/standing and sprinting execute on the shared **geometry
and timing test** timeline. That mode excludes attacks, movement statuses
and movement dyspnea. Its coverage must not be described as moving combat.
Other characters do not yet have complete executable locomotion profiles.

Historical checkpoint, 2026-10-31: 2E4 and 3E5 Block now run on the shared combat
timeline with actual attacks and recharging stock; 3E5's existing basic movement
profile is ported. Walking, crouch, jump and climb interactions are verified.
This does not execute 3E5's punch/chain/leap/heavy-punch/Ultimate kit. See
[Block](BLOCKING.md) and [current author ability revisions](SOURCE_UPDATES_2026-10-31.md).
Body-collision response and body-turn timing have isolated helpers;
this is separate from complete shared-combat integration.

Update, 2026-10-27: [moving combat](MOVING_COMBAT.md) now integrates
walking/running/sprinting/stopping and basic jumping with the existing 1E2 gun,
instability speed reduction, directional contacts, dyspnea, bleeding and death.
Jump separates controlled Active from flight, retains horizontal momentum,
and applies actual landing/contact effects. Its gravity scope additionally
integrates direction-following deceleration, compensated short-arc aim, moving
curved contacts and actual-path falloff; see [GRAVITY.md](GRAVITY.md) and
[JUMPING.md](JUMPING.md). The more extensive geometry test remains separate;
the other kits are not yet claimed as integrated combat. Subsequent
crouch/stand integration adds changing cuboids, clearance, resources/statuses,
lowered hand/projectile origins, crouched jumping and live contact interruption;
see [CROUCH_SPRINT.md](CROUCH_SPRINT.md) and
[saved posture results](results/posture-combat/REPORT.md). Fixed facing remains.

Update, 2026-10-28: the existing climb is integrated with live gunfire, costs,
statuses, path obstruction/interruption, raised support and death; see
[CLIMBING.md](CLIMBING.md) and [verified scenes](results/climb-combat/REPORT.md).
Movement intents now have one dispatcher and explicit prerequisite ownership.
Current body physics is immutable and independent of future commands. The
[current index](ENGINE_STATUS.md) and [review response](PRINCIPAL_ENGINEERING_REVIEW_RESPONSE.md)
distinguish corrected defects from remaining action/entity/effect prerequisites.
This does not extend moving weapon support beyond the existing 1E2 gun or
complete any other kit.

Current-action ownership now permits eligible gun/reload and body-action
overlap, with action-bound payments and independent upper/lower function
restrictions. Pre-applied conditions and runtime API tests verify the shared
foundation required by 1E3. Its subsequent [marking projectile](BINDINGS.md)
now executes, as do the existing ice bomb, portals and remaining roster casts. Source-specific declared requirements and any phase-specific
transfers/extra-limb mappings. See [ACTION_OWNERSHIP.md](ACTION_OWNERSHIP.md)
and [four reproducible interactions](results/action-ownership/REPORT.md).

The subsequent projectile increment separates flight/action identity and tests
copying, ancestry, retained distance and safe owner consumption in the shared
engine. This is a reusable foundation required by existing 1E3/2E4 features;
engineering probes do not implement their casts, field entry/split placement
or secondary attack. Ability support labels above remain unchanged. See
[PROJECTILE_ENTITIES.md](PROJECTILE_ENTITIES.md) and
[combat/probe evidence](results/projectile-entities/REPORT.md).

Fixed world colliders now support compound geometry, shared HP, lifetime and
independent collision/cover channels. Gunfire, support loss and a hollow-shell
scene are verified in ordinary shared API/CLI encounters. The shell is initial
geometry in that earlier checkpoint. The later [1E3 prison cast](PRISON.md) now
creates physical enclosures through contact; later [3E5 charge/wall destruction](CHARGE_GRAPPLE.md)
uses the same mutable material and committed native contacts. Construct HP damage grants no character recovery credit.
See [WORLD_COLLIDERS.md](WORLD_COLLIDERS.md) and
[collider encounters](results/world-colliders/REPORT.md).

## Values needed by Get Up

The new global Get Up definition is in [Details2.odt](Details2.odt): used
after knockdown, Active = `2 × Recovery`, dyspnea = `2 × jump dyspnea value`.
The following table records source values and arithmetic. [GET_UP.md](GET_UP.md)
now documents the shared-combat action lifecycle; six numerical profiles do not
mean all six kits are executable.

| Character | HP | Armor | Base running m/s | Numeric Recovery | Basic jump listed dyspnea | `2 × Recovery` | `2 × listed jump value` |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1E1 | 8140 | 150 | 6.4 | 200 | 1.5 | 400 | 3 |
| 1E2 | 8140 | 150 | 6.4 | 200 | 1.5 | 400 | 3 |
| 1E3 | 8140 | 150 | 6.4 | 250 | 1.5 | 500 | 3 |
| 1E5 | 20000 | 350 | 7 | 200 | 1.2 | 400 | 2.4 |
| 2E4 | 9080 | 165 | 8 | 150 | 1.2 | 300 | 2.4 |
| 3E5 | 11400 | 250 | 8 | 150 | 1.2 | 300 | 2.4 |

All six basic jumps list 100 ms Gathering and 150 ms Active, self
disorientation/instability 80/80 on jump and 100/120 on landing.

Recovery/jump source paragraphs respectively: 1E1 p41/p157–168;
1E2 p43/p173–184; 1E3 p37/p120–131; 1E5 p40/p107–118;
2E4 p45/p133–144; 3E5 p45/p180–191.

All six runtime profiles now import their primary combat stats and Recovery.
The [binding increment](BINDINGS.md) corrected 1E3's earlier import omission,
including Recovery250, its shield/toxin bonus and documented common movement.
Current walk/run/sprint/jump/crouch/climb definitions cover all six profiles.
The separate [Get Up definitions](data/movement/get_up.json) also retain all six
source values. Numerical profiles and common movement do not complete their
kits. Current equilibrium rules now add shared prone/Get Up geometry; they
derive the six profiles directly from supplied Recovery/jump values.

The Get Up increment records numeric Recovery and doubled base dyspnea as
explicit delegated decisions. Costs at zero current dyspnea are 9 for
1E1/1E2/1E3 and 5.76 for 1E5/2E4/3E5. Payment at Active start, cancellation,
death and knockdown-state transitions execute on the shared combat queue for
all six common profiles. Prone geometry, clearance, native motion and life-bound
completion now work in the shared world; see [GET_UP.md](GET_UP.md) and
[the current evidence](results/equilibrium/README.md).

The author-added [grapple source](GRAPPLE.md) classifies 3E5 Ultimate as a grapple.
Its actual [charge/holding delivery](CHARGE_GRAPPLE.md) keeps wall-slam damage
separate from drag damage. Delegated 600 DPS/Dd2 fills its source omissions;
1E5's separate 900 DPS/3 s identity is unchanged.
