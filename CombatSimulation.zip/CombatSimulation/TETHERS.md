# Tether projection and chain delivery

2026-11-01. The shared engine now exposes an **instantaneous** joint radial/
contact projection through atomic spatial updates. The later
[authored 3E5 chain](CHAIN_CAST.md) now uses the persistent controller; the
instantaneous API remains a separate numerical prerequisite.
[Numerical implementation](combat_sim/mechanics/unilateral_velocity.py) ·
[Shared API](combat_sim/spatial_transitions.py) ·
[Evidence](results/tether-projection/README.md).

**Later numerical prerequisite:** [finite distance paths](DISTANCE_PATHS.md) now
have exact whole-interval bounds, jointly with grapple/contact constraints.
The pure planner retains tangents beyond a conservative control cage and
certifies its finite endpoint response. The subsequent
[live controller](PERSISTENT_DISTANCES.md), 2026-11-02, now integrates those
pieces through shared paths, with independent knots, separate physical drivers
and per-force expiry. The authored chain now connects actual contact and common
binding/Break to those rows. [Delivery evidence](results/chain-cast/README.md).

## Primary source and delegated mechanical choice

`3E5.odt` p11/p100–119 defines ability 2: throw a 30 m/s chain, G180/A220,
release after throw, self O/U120 on throw, target O/U60 on impact, Db3.5 and
binding value6. The impact binds the recipient to the caster for 15 s, with
20 m chain length and joint motion at maximum separation when moving apart.
Overview cooldown is 9 s. The throw is intrinsic momentary; attachment is binding.
These primary definitions are unchanged. The subsequent
[delivery](CHAIN_CAST.md) adds its selectable cast, payment, cooldown, projectile
and binding attachment through the existing common systems.

Under delegation, the taut response constrains **outward relative radial
velocity**, leaving permitted tangential and inward motion. Use the existing
positive body weights `(maximumHP/500+currentArmor/10)^1.1` for sharing response.
This is a technical extension of the existing grapple weighting, not an author
statement about chain mass. It does not reuse the author's summed-stat knock
resistance formula or make the chain a grapple link. Existing grapple equalities
and terrain/body constraints must be solved in the same system when applicable.

## Instantaneous mathematical contract

For requested velocities `u_i`, find the unique minimum of
`sum_i(weight_i * |v_i-u_i|²)/2` subject to the declared constraints:

- `TautDistance(A,B,n)`: `(v_B-v_A)·n <= 0`, where `n` points from A toward B.
  The caller must decide whether the actual distance is taut. This helper does
  not infer distance from a supplied normal or create a persistent link.
- `ContactLimit(A,n)`: `v_A·n <= 0`, where `n` points toward the obstacle. Moving
  away remains legal. Normals need not be unit length.
- Existing `VelocityEquality` and `BlockedDirection` retain their bilateral
  meaning. A blocked direction sets its component to zero; it is not silently
  reinterpreted as a one-sided contact.

With equally weighted bodies moving at −8 and +6 m/s along a taut radial axis,
the result is −1 m/s for each. Their other components stay independent. If B
also touches a wall preventing negative radial movement, the joint result is
zero for both on that axis. Projecting the pair and then stopping only B would
leave outward separation; sequential corrections cannot implement this rule.

The solver uses exact rational arithmetic after the existing fixed-precision
body weights. It first constructs the equality nullspace and then solves the
nonnegative dual active set for all unilateral rows together. Canonical actor/
constraint ordering and positive-scale normalization make input ordering and
equivalent normals deterministic. Redundant cycles, opposing contacts and limits
internal to a grapple do not require an invertible full constraint matrix.

Every result checks exact feasibility, nonnegative multipliers and
complementarity. The constructed correction also supplies stationarity in the
equality nullspace. A failed certificate or iteration guard raises a solver
error; it never returns an approximate pairwise fallback. Homogeneous constraints
always admit zero velocity. The presentation velocity uses owned Decimal
precision; exact values/certificates remain available in the immutable result.
Recorded ratios are strings so the shared world's JSON trace remains valid.

## Shared API boundary

`world.spatial_transitions.prepare_projection(...)` and `.project(...)` accept
optional `taut=` and `contacts=` tuples. The API expands actual live grapple
components, snapshots all participating lives and returns an atomic dependency-
checked spatial plan. It preserves the existing legacy solver path when no new
constraint is supplied. Invalid endpoints/lives and stale plans cannot partially
commit a projection. Ordinary projected velocities use shared body physics,
contacts and upper-action ownership. Real holding retains its independent owner
and damage/effort stream; the projection does not register an invented hold.

These are **engineering API operations**, with the same explicit velocity-
replacement semantics as existing spatial transitions. They do not supply the
continuous control/force decomposition needed by a persistent chain. The saved
world probes are labelled accordingly; no CLI chain integration is claimed.

## Live architecture and remaining chain delivery

The current world now uses [saved polynomial body paths](BODY_PATHS.md): one
immutable reference prefix supplies body, terrain, projectile and area/field
queries and one writer advances that reference. Existing free/grapple/climb
polynomials are retained; airborne z no longer has a separate advancement
writer in this mode. Frozen earlier inputs retain their original path.

The [persistent coordinator](PERSISTENT_DISTANCES.md) now integrates curved
taut paths, actual slack crossings, permitted inward motion and joint resolved
contacts/grapple equalities. Numerical knots come from physics controls rather
than observations. Ground motor requests remain separate from inertia, native
gravity/landing retains its lifetime, and every finite knock component passes
through the selected response before its own expiry. The affine offset belongs
to base motion once. Repeated internal commits do not use external
velocity-replacement semantics, which would retire forces and cancel control.

The author's summed-stat knock resistance still queries actual grapple groups;
a distance attachment is not added to that resistance group. The new complete
held-heavy encounter checks this distinction directly.

The [real projectile and binding/Break lifecycle](CHAIN_CAST.md) now use those
shared paths, with source-specific range, phase and endpoint-life choices
documented separately. Next extend the endpoint model for environmental/fixed
anchors needed by 1E1's ground chain. The overall six-kit/5v5 Goal remains active
and incomplete.
