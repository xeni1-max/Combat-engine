# Timed Gathering modifiers

Author rule: 1E2 Ultimate adds 250 ms Gathering to everyone hit for six seconds
(`1E2.odt`, overview paragraph 11). This is preparation work, separate from
disorientation, instability, fatigue, cooldowns and physical hand Recovery.

Delegated rules (2026-11-09): independent released instances belong to the
recipient's current life and retain their original source life through caster
death. Recipient death retires them; revival does not restore them. The active
addition is the maximum among instances, avoiding unlimited same-effect
stacking while preserving independent durations. A new instance does not erase
an older one.

On entering an existing Gathering phase, add that maximum after the ordinary
base-duration/running calculation and disorientation. Zero-base Gathering
(reload, posture, Aim and some attacks) still receives the addition. Jump,
climb and replacement-blade preparation use the same controller. Each action
commits the largest addition encountered: a hit during unfinished Gathering
adds only the positive difference from its previous commitment. Expiration
never refunds committed preparation. Repeated refreshes cannot repeatedly add
250 ms to one action. A later action commits the then-current maximum anew.
The maximum is rounded upward once to the shared whole-millisecond phase
resolution; fractional strength refreshes cannot accumulate rounding delays.

The modifier does not invent Gathering phases for Active-only locomotion,
sprint transitions, Get Up, Break input, passive reactions or an already Active
hold. It affects named Gathering, not every passage of time. Existing
disorientation can independently extend Gathering. An action whose Active is
already due at the impact clock progresses first under the shared phases-first
rule. Effect expiry is also due before new selections at that clock.

`combat_sim/timed_gathering.py` owns lifetime, validation and preparation
commitments. It changes no actor O/U values, decay rates, payment anchor,
resource occupancy or attack power. `gathering_modifier_*` receipts and result
instances expose both sources and added work. Current data opts in explicitly;
frozen legacy configurations retain their earlier behavior.
