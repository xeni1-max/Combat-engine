# Primary-source changes found on resumption

Current primary documents were compared with exact archived pre-pause copies
on2026-11-09. All5493 previous result files remain unchanged. Eleven primary
ODTs retain their old hash; three have the changes below. Original and current
hashes, source copies and paragraph diffs are preserved under
results/grappling-gun. Do not refresh the older source manifests.

| Author revision | Consequence | Import status |
|---|---|---|
|1E2 ability5 adds a 20 m × 1.5 m fence, five 4 m parts, each destroyed by 1500 non-toxin/non-electrocution damage | Actual fence needs independent material parts and binding/electrocution contact; source overview still says 15 m | [Actual field](ELECTROCUTION_FENCE.md) now composes owned summon, independent panels, contact, common B2/Break and shared electrical HP/life flow. Delegated detailed 20 m precedence is applied. Final verification is in PROGRESS.md. |
|2E4 basic9 overview changes Block to Dodge, retaining four charges and4.5 s/charge | The old second Block interpretation is superseded | Imported and verified as a physical downward Dodge,150 ms Active/Db3.5, with independent stock.2618 full tests,18 API/CLI cases and four labelled API probes pass. [Rules](DODGING.md); [evidence](results/2e4-dodge/README.md). |
|Details2 adds1E5 height +30%, width/depth +60%, and3E5 height +5%, width/depth +15%, relative to1E1 | Shared per-character geometry, hand/reach and interactions | Imported and verified in current shared body/pose/hand/reach/support paths.2590 methods and21 complete API/CLI/hash/numerical cases pass. [Rules](CHARACTER_GEOMETRY.md); [evidence](results/body-scales/README.md). |

1E2's grappling-gun firing and launch paragraphs did not change. The added fence
paragraphs shift later paragraph indices by two, including Aim's source indices.
The current grappling-gun increment may use the existing selected geometry, but
its verification must not imply these newer author revisions are implemented.
The geometry and Dodge imports are verified. The fence now has actual shared
delivery on its electrical foundation; current regression/reproduction status
is in PROGRESS.md. The [actual existing 1E2 Ultimate](IMPACT_AREAS.md) now
delivers one impact area and shared [timed Gathering](TIMED_GATHERING.md); its
source values remain intact, and delegated geometry/phase/stacking/cover rules
are documented. The [actual 1E3 Ultimate](PROJECTILE_DUPLICATION.md) now
delivers the revised12m/4m field with continuous entry and independent shared
projectile branches; verification is in PROGRESS.md. Next deliver its existing
portal pair.
Current-source kit
completeness remains unproven. Advanced NPCs and
mass/balancing work remain deferred.
