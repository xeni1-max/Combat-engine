"""Finite flat ground and fixed cuboid terrain, separate from combat rules."""
from dataclasses import dataclass

from combat_sim.hitboxes import Cuboid
from combat_sim.models import UnsupportedMechanicError, as_fraction
from combat_sim.world_colliders import collider_tags, finite


def vector3(values):
    if len(values) != 3:
        raise ValueError('Terrain coordinates need exactly three components')
    return tuple(as_fraction(value) for value in values)


def fields(value,allowed,where):
    unknown = set(value)-set(allowed)
    if unknown:
        raise UnsupportedMechanicError(f'Unsupported {where} fields: {sorted(unknown)}')


@dataclass(frozen=True)
class RectangularGround:
    """A closed horizontal rectangle, with no invented ground thickness.

    Point-to-bounds distance is valid when one bound extent is zero, so this
    surface shares the exact quadratic sphere sweep used for solid cuboids.
    It creates no vertical boundary walls or ceiling.
    """
    part: str
    minimum_m: tuple
    maximum_m: tuple

    def __post_init__(self):
        low,high = vector3(self.minimum_m),vector3(self.maximum_m)
        if not self.part or low[0] >= high[0] or low[1] >= high[1] or low[2] != high[2]:
            raise ValueError('Ground needs a nonempty horizontal rectangle at one explicit z')
        object.__setattr__(self,'minimum_m',low)
        object.__setattr__(self,'maximum_m',high)

    @property
    def bounds(self):
        return self.minimum_m,self.maximum_m

    @property
    def centre_m(self):return tuple((a+b)/2 for a,b in zip(self.minimum_m,self.maximum_m))

    @property
    def size_m(self):return tuple(b-a for a,b in zip(self.minimum_m,self.maximum_m))

    def swept_sphere_contact(self,start,end,radius_m,*,precision=50):
        return Cuboid.swept_sphere_contact(self,start,end,radius_m,precision=precision)


def terrain_colliders(definition):
    fields(definition,{'id','units','status','source','battlefield_bounds_m','boundary_behavior','ground','obstacles'},'terrain')
    if definition['units'] != 'metres' or definition['status'] != 'confirmed_by_author':
        raise UnsupportedMechanicError('Terrain must have confirmed metre-based source data')
    if definition['boundary_behavior'] != {'sides':'open','top':'open'}:
        raise UnsupportedMechanicError('Boundary walls/ceiling are outside this terrain scope')
    volume = definition['battlefield_bounds_m']
    fields(volume,{'minimum','maximum'},'battlefield bounds')
    low,high = vector3(volume['minimum']),vector3(volume['maximum'])
    if any(a >= b for a,b in zip(low,high)):
        raise ValueError('Battlefield bounds must have positive extents')
    ground = definition['ground']
    fields(ground,{'id','shape','minimum_m','maximum_m'},'ground')
    if ground['shape'] != 'rectangle':
        raise UnsupportedMechanicError('Only the authored flat rectangular ground is supported')
    surface = RectangularGround(ground['id'],ground['minimum_m'],ground['maximum_m'])
    if surface.bounds != ((low[0],low[1],low[2]),(high[0],high[1],low[2])):
        raise ValueError('Ground must match the declared battlefield footprint and bottom z')
    colliders = {surface.part:(surface,)}
    for item in definition['obstacles']:
        fields(item,{'id','shape','centre_m','side_length_m','size_m','climbable','hp','tags'},'terrain obstacle')
        if not isinstance(item.get('climbable',False),bool):
            raise ValueError('Climbable terrain flag must be boolean')
        if item.get('hp') is not None:finite(item['hp'],'Terrain HP',positive=True)
        collider_tags(item.get('tags',()))
        if item['id'] in colliders:
            raise ValueError('Terrain object identities must be unique')
        if item['shape']=='cube':
            if 'size_m' in item:raise ValueError('Cube dimensions use side_length_m only')
            side = as_fraction(item['side_length_m'])
            size = (side,side,side)
        elif item['shape']=='cuboid':
            if 'side_length_m' in item:raise ValueError('Cuboid dimensions use size_m only')
            size = vector3(item['size_m'])
        else:
            raise UnsupportedMechanicError('Terrain obstacles require cube or cuboid geometry')
        box = Cuboid(item['id'],item['centre_m'],size)
        if box.bounds[0][2] != low[2]:
            raise ValueError('Terrain obstacles must rest on the ground')
        colliders[item['id']] = (box,)
    return colliders
