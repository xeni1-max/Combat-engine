"""Independent combatant instances and action state for shared encounters."""
from dataclasses import dataclass, field
from copy import deepcopy
from contextlib import contextmanager
from decimal import Decimal as D, ROUND_CEILING
from fractions import Fraction
from typing import Any

from combat_sim.orientation import YawFrame
from combat_sim.models import as_fraction
from combat_sim.mechanics.life import life_generation as validate_life_generation


def decimal_value(value):
    if isinstance(value, D):
        result = value
    else:
        f = as_fraction(value)
        result = D(f.numerator) / D(f.denominator)
    if not result.is_finite():
        raise ValueError('Combat values must be finite')
    return result


def ceil_ms(value):
    return value.to_integral_value(rounding=ROUND_CEILING)


@dataclass
class BattleAction:
    id: int
    actor: str
    target: str | None
    ability_id: str
    kind: str
    started_ms: D
    active_due_ms: D
    active_ms: D
    phase: str = 'gathering'
    revision: int = 0
    active_end_ms: D | None = None
    recovery_end_ms: D | None = None
    base_gathering_ms: D | None = None
    aim_location_m: tuple | None = None
    life_generation: int | None = None
    component_id: str | None = None
    aim_part: str | None = None
    target_snapshot: dict | None = None

    def record(self):
        return {key: str(value) if isinstance(value, D) else value
                for key, value in vars(self).items()
                if key!='definition_snapshot' and (key not in ('recovery_end_ms', 'base_gathering_ms','aim_location_m','life_generation','component_id','aim_part','target_snapshot') or value is not None)}


@dataclass
class Combatant:
    id: str
    profile_id: str
    team: str
    profile: dict[str, Any]
    hp: D
    armor: D
    shield: D
    disorientation: D = D(0)
    instability: D = D(0)
    _current: BattleAction | None = field(default=None,repr=False)
    action_registry: Any = field(default=None,repr=False)
    ready: dict[str, D] = field(default_factory=dict)
    cooldowns: Any = field(default=None,repr=False)
    ammo: dict[str, int] = field(default_factory=dict)
    decision_due: D | None = None
    decision_revision: int = 0
    position_m: tuple | None = None
    dyspnea: D = D(0)
    hands: dict | None = None
    died_at_ms: D | None = None
    facing: str | YawFrame | None = None
    body_origin_m: tuple | None = None
    pose_drop_m: D | None = None
    locomotion: dict | None = None
    knocked_down: bool = False
    life_generation: int = 1
    life_reporting: bool = field(default=False, repr=False)
    metrics: dict[str, Any] = field(default_factory=lambda: {
        'activations_started': 0, 'projectiles_released': 0, 'hits_resolved': 0,
        'reloads_started': 0, 'reloads_completed': 0,
        'direct_hp_damage_received': D(0), 'continuous_hp_damage_received': D(0),
        'shield_damage_received': D(0), 'armor_lost': D(0),
    })

    @property
    def current(self):
        # Compatibility for phase implementations. In owned mode each event or
        # body response binds an explicit action; an ambiguous lookup is an error.
        return self.action_registry.selected_or_single() if self.action_registry is not None else self._current

    @current.setter
    def current(self,action):
        if action is not None and self.life_reporting:
            validate_life_generation(action.life_generation)
            if self.hp <= 0 or self.died_at_ms is not None:
                raise ValueError('A dead life cannot acquire a controlled action')
            if action.life_generation is None:
                action.life_generation = self.life_generation
            elif action.life_generation != self.life_generation:
                raise ValueError('Controlled action belongs to a different life')
        if self.action_registry is None:
            self._current=action
        elif action is None:
            self.action_registry.release_selected()
        else:
            if action.actor!=self.id:
                raise ValueError('Controlled action belongs to a different actor')
            self.action_registry.acquire(action)

    def live_actions(self):
        return self.action_registry.all() if self.action_registry is not None else ((self._current,) if self._current else ())

    def action_by_id(self,action_id):
        return next((a for a in self.live_actions() if a.id==action_id and (
            not self.life_reporting or a.life_generation==self.life_generation)),None)

    def body_action(self):
        if self.action_registry is not None:
            return self.action_registry.owner('locomotion')
        return self._current if self._current is not None and self._current.kind in ('locomotion','posture','dodge','basic_jump','climb','get_up','ballistic_dash') else None

    @contextmanager
    def using_action(self,action):
        if self.action_registry is None:
            yield action
        else:
            if action is not None and action.actor!=self.id:
                raise ValueError('Cannot bind another actor\'s controlled action')
            with self.action_registry.select(action.id if action is not None else None):
                yield action

    def record(self):
        result = {
            'character': self.profile_id, 'team': self.team,
            **{name: str(getattr(self, name)) for name in
               ('hp', 'armor', 'shield', 'disorientation', 'instability')},
            'current_action': self.live_actions()[0].record() if len(self.live_actions())==1 else None,
            'ability_ready_at_ms': {k: str(v) for k, v in sorted(self.ready.items())},
            'ammo': dict(sorted(self.ammo.items())),
        }
        if self.position_m is not None:
            result.update(position_m=list(self.position_m), dyspnea=str(self.dyspnea),
                          hands_m=deepcopy(self.hands), alive=self.died_at_ms is None and self.hp > 0,
                          died_at_ms=str(self.died_at_ms) if self.died_at_ms is not None else None)
        if self.locomotion is not None:
            result['locomotion'] = deepcopy(self.locomotion)
        if 'get_ups_started' in self.metrics:
            result['knocked_down'] = self.knocked_down
        if self.facing is not None:
            from combat_sim.facing import record as facing_record
            result.update(facing=facing_record(self.facing),body_origin_m=[str(value) for value in self.body_origin_m])
        if self.action_registry is not None:
            result['owned_actions']=self.action_registry.record()
            result['action_restrictions']={k:sorted(v) for k,v in sorted(self.action_registry.blocks.items())}
        if self.cooldowns is not None:
            result['cooldown_clocks']=self.cooldowns.record()
            result['ability_ready_at_ms']={k:str(v) if v.is_finite() else None for k,v in sorted(self.ready.items())}
        if self.life_reporting:
            result['life_generation'] = self.life_generation
        if hasattr(self,'weapon_inventory'):result['weapon_inventory']=deepcopy(self.weapon_inventory)
        return result
