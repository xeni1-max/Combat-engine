"""Existing fixed-speed leaps and owned descending foot contacts.

Flight remains in the shared body writer. Launch Active and the subsequent
controlled kick are separate phases; neither an observation horizon nor a
guessed flight timer determines contact or landing.
"""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.action_ownership import ActionConflict
from combat_sim.character_geometry import actor_body
from combat_sim.hitboxes import standing_cuboids
from combat_sim.mechanics.body_launch import directed_launch
from combat_sim.models import UnsupportedMechanicError
from combat_sim.spatial_motion import CONTACT_SPEED_EPS_MPS as SPEED,CONTACT_ACCEL_EPS_MPS2 as ACCEL,CONTACT_TIME_EPS_MS as TIME
from combat_sim.world_colliders import finite
from combat_sim.facing import forward
from combat_sim.orientation import YawFrame

EVENT='leap_vertical_gate'


class BodyLeaps:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.rows={};self.attempts=[]
        if self.enabled and (definition!={'mode':'controlled_falling_v1'} or not world.mobile_mode):
            raise UnsupportedMechanicError('Leaps require the shared mobile world')

    def validate(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id]
        if not (self.enabled and w.airborne_enabled and w.life_cycles.enabled and w.effort_system.enabled
                and w.body_paths.enabled and w.spatial_transitions.enabled and w.body_support.enabled
                and actor.action_registry is not None):
            raise UnsupportedMechanicError('Leaps require shared owned flight, support and contacts')
        cfg=w.ownership_definition['actions'].get('ballistic_leap')
        if (cfg!={'occupies':['locomotion'],'requires':['lower_body']} or
                a.get('launch_timing')!='active_start' or a.get('cooldown_anchor')!='active_start' or
                a.get('dyspnea',{}).get('payment_timing')!='active_start' or
                a.get('hand_positions_m')!={'start':{},'end':{}} or a.get('target_mode')!='self'):
            raise UnsupportedMechanicError('Leaps need their independent lower-body launch contract')
        finite(a['initial_speed_mps'],'Leap speed',positive=True);finite(a['cooldown_ms'],'Leap cooldown',positive=True)
        for key in ('takeoff_self_effects','landing_self_effects'):
            if set(a.get(key,{}))!={'disorientation','instability'}:raise ValueError('Leap needs explicit self effects')
            for v in a[key].values():finite(v,'Leap self effect')
        if a.get('falling_kick') is not None:
            if (a['falling_kick']!={'height_m':'0.1'} or a.get('direct_damage_type')!='blunt' or
                    not w.knock_motion.at_impact or not w.melee.enabled or a.get('knock')!={
                        'direction':'knock_down','distance_m':15,'duration_ms':500,'elasticity':0,'vertical':'add'}):
                raise UnsupportedMechanicError('Falling kick needs owned foot contact and shared downward knock')
            finite(a['pre_mitigation_damage'],'Kick output',positive=True)

    def available(self,actor):
        w=self.world
        return (not actor.knocked_down and not w._airborne(actor.id) and not w._climbing(actor.id)
            and w.collider_system.find_support(actor) is not None)

    def start(self,actor):
        w=self.world;action=actor.current;a=w.action_definition(actor,action)
        if not self.available(actor):return w.cancel_owned_action(actor,action,'leap_requires_support')
        speed=dec(a['initial_speed_mps']);target=None
        if action.target_snapshot is None:
            # A simple forward45-degree control, independent of target AI.
            half=speed/D(2).sqrt();sign=1 if actor.facing=='+x' else -1
            velocity=(tuple(half*dec(v) for v in forward(actor.facing)[:2])+(half,) if isinstance(actor.facing,YawFrame)
                else (sign*half,D(0),half))
        else:
            target=tuple(map(dec,action.target_snapshot['point_m']))
            ref=w.spatial_transitions.reference(actor.id)
            bottom=dec(min(b.bounds[0][2] for b in w.world_bodies[actor.id]))
            desired=(*target[:2],target[2]+ref[2]-bottom)
            try:velocity=directed_launch(ref,desired,speed,w.jump_gravity,precision=w.precision).velocity_mps
            except UnsupportedMechanicError as error:
                self.attempts.append(dict(actor=actor.id,action_id=action.id,at_ms=w.time,status='rejected',reason=str(error)))
                return w.cancel_owned_action(actor,action,'leap_target_unreachable')
            if velocity[2]<=0:return w.cancel_owned_action(actor,action,'leap_requires_upward_takeoff')
        if not w.pay_team_dyspnea(actor,'active_start'):return
        m=w.motion[actor.id];running=w.mobile_is_running(actor.id)
        factor=dec(w.combat_locomotion_definition['running_self_effect_multiplier']) if running else D(1)
        if w.mobile_sprint_effort(actor.id):
            m.update(mode='running',speed=dec(w.movement_definition['characters'][actor.profile_id]['running_speed_mps']),sprint_anchor=None)
        drive=tuple(v*m['speed'] for v in m['direction'])+(D(0),)
        m.pop('imposed_velocity',None)
        action.phase='active';action.active_end_ms=w.time+action.active_ms
        effects={k:dec(v)*factor for k,v in a['takeoff_self_effects'].items()}
        for key,v in effects.items():setattr(actor,key,getattr(actor,key)+v)
        landing=(actor.life_generation,action.ability_id,action.id,
            dec(a['landing_self_effects']['disorientation']),dec(a['landing_self_effects']['instability']))
        w.launch_body(actor,velocity,ground_drive_velocity=drive,landing_effects=landing,
            motion_cause=('leap',actor.life_generation,action.id))
        w.cooldown_system.start(actor,action.ability_id,a['cooldown_ms'],action.id)
        w.extend_parallel_gatherings(actor,effects['disorientation'],action.id)
        row=dict(actor=actor.id,ability=action.ability_id,action_id=action.id,source_life_generation=actor.life_generation,
            launched_at_ms=w.time,launch_active_end_ms=action.active_end_ms,launch_velocity_mps=velocity,
            reference_m=w.spatial_transitions.reference(actor.id),target_feet_m=target,
            status='launching',has_kick='falling_kick' in a,volume_id=None,self_effects=effects)
        self.rows[action.id]=row;w.refresh_mobile_locomotion()
        w.log('body_leap_launched',leap=deepcopy(row));w._schedule_phase(action,'active_completed',action.active_end_ms)

    def action(self,row):
        a=self.world.fighters[row['actor']]
        return a.action_by_id(row['action_id']) if a.hp>0 and a.life_generation==row['source_life_generation'] else None

    def complete(self,actor):
        w=self.world;action=actor.current;row=self.rows.get(action.id)
        if row is None:return
        w.log('leap_launch_active_completed',actor=actor.id,ability=action.ability_id,action_id=action.id,
            airborne=w._airborne(actor.id))
        if not row['has_kick'] or not w._airborne(actor.id):return self.end(row,'launch_control_completed')
        action.phase='airborne_wait';action.active_end_ms=None;action.revision+=1;row['status']='waiting'
        self.settle()

    def falling(self,name):
        v,a=self.world.mobile_motion(name)
        return v[2]<-SPEED or abs(v[2])<=SPEED and a[2]<-ACCEL

    def foot_geometry(self,actor):
        # Fixed width/depth of both standing feet; the vertical anchor follows
        # the actual part's lower face under current pose deformation.
        parts=standing_cuboids(actor_body(self.world,actor.id))
        legs=[p for p in parts if p.part in ('left_leg','right_leg')]
        low=tuple(min(p.bounds[0][i] for p in legs) for i in range(3))
        high=tuple(max(p.bounds[1][i] for p in legs) for i in range(3))
        anchor=next(p for p in legs if p.part=='right_leg');height=D('.1')
        return dict(mode='body_part_box',anchor_part='right_leg',anchor_fraction=[0,0,'-.5'],
            centre_offset_m=[dec((low[i]+high[i])/2-anchor.centre_m[i]) for i in (0,1)]+[height/2],
            size_xyz_m=[dec(high[i]-low[i]) for i in (0,1)]+[height])

    def activate(self,row):
        w=self.world;actor=w.fighters[row['actor']];action=self.action(row)
        if action is None:return self.end(row,'control_ended')
        try:actor.action_registry.transfer({action.id:w.action_requirements(actor,action.kind,action.ability_id,'falling_kick',action=action)})
        except ActionConflict:return w.cancel_owned_action(actor,action,'kick_requirements_unavailable')
        action.leap_kick_active=True
        action.phase='active';action.active_end_ms=None;action.revision+=1;row['status']='kicking'
        volume=w.owned_contacts.start(actor,action,self.foot_geometry(actor),None,ordering='down',apply_self_effects=False)
        row['volume_id']=volume['id'];row.setdefault('kick_started_at_ms',w.time)
        w.log('falling_kick_started',actor=actor.id,ability=action.ability_id,action_id=action.id,volume_id=volume['id'])
        # Creation inside a body/material at the observation horizon must still
        # commit the actual same-clock contact.
        box=w.owned_contacts.box(volume)
        if any(w.owned_contacts.touching(box,p) for _,parts,_ in w.owned_contacts.groups(volume) for p in parts):
            w.push(w.time,'owned_contact',{'volume_id':volume['id']},priority=1)

    def pause(self,row):
        w=self.world;action=self.action(row)
        if row['volume_id'] is not None:w.owned_contacts.end(w.owned_contacts.rows[row['volume_id']],'source_not_descending')
        row.update(status='waiting',volume_id=None)
        if action is not None:
            action.leap_kick_active=False;action.phase='airborne_wait';action.revision+=1
            actor=w.fighters[row['actor']]
            actor.action_registry.transfer({action.id:w.action_requirements(actor,action.kind,action.ability_id,'airborne_wait',action=action)})

    def next_boundary(self,end):
        w=self.world;found=[]
        for row in self.rows.values():
            if row['status'] not in ('waiting','kicking') or self.action(row) is None or not w._airborne(row['actor']):continue
            descending=self.falling(row['actor'])
            if descending!=(row['status']=='kicking'):when=w.time
            else:
                v,a=w.mobile_motion(row['actor']);vz,az=v[2],a[2]
                if not (row['status']=='waiting' and vz>0 and az<0 or row['status']=='kicking' and vz<0 and az>0):continue
                when=w.time-vz/az*1000
                if when>end+TIME:continue
                when=min(when,end)
            found.append((when,{'action_id':row['action_id']}))
        if not found:return None
        at=min(t for t,_ in found);return at,[p for t,p in found if abs(t-at)<=TIME]

    def live(self,p):
        row=self.rows.get(p['action_id'])
        return row is not None and row['status'] in ('waiting','kicking') and self.action(row) is not None

    def process(self,p):
        if not self.live(p):return
        row=self.rows[p['action_id']]
        if not self.world._airborne(row['actor']):return self.end(row,'landed')
        if self.falling(row['actor']) and row['status']=='waiting':self.activate(row)
        elif not self.falling(row['actor']) and row['status']=='kicking':self.pause(row)

    def contact(self,packet):
        row=self.rows.get(packet['action_id'])
        if row is not None and row['status']=='kicking':
            row['contact']=deepcopy(packet);self.end(row,'kick_contact')

    def end(self,row,reason,*,release=True):
        if row['status']=='ended':return
        w=self.world;action=self.action(row)
        if row['volume_id'] is not None:w.owned_contacts.end(w.owned_contacts.rows[row['volume_id']],reason)
        row.update(status='ended',ended_at_ms=w.time,end_reason=reason)
        if release and action is not None:
            with w.fighters[row['actor']].using_action(action):w.fighters[row['actor']].current=None
            action.revision+=1;w.request_decision(row['actor'],w.time)
        w.log('body_leap_ended',actor=row['actor'],ability=row['ability'],action_id=row['action_id'],reason=reason)

    def action_cancelled(self,actor,action,reason):
        row=self.rows.get(action.id)
        if row is not None:self.end(row,reason,release=False)

    def settle(self):
        for row in tuple(self.rows.values()):
            if row['status']=='ended':continue
            if self.action(row) is None:self.end(row,'control_or_life_ended')
            elif row['status'] in ('waiting','kicking'):
                if not self.world._airborne(row['actor']):self.end(row,'landed')
                elif row['status']=='waiting' and self.falling(row['actor']):self.activate(row)
                elif row['status']=='kicking' and not self.falling(row['actor']):self.pause(row)

    def result(self):
        return {'body_leap_rules':deepcopy(self.world.combat_locomotion_input['body_leaps']),
            'body_leaps':deepcopy(list(self.rows.values())),'body_leap_attempts':deepcopy(self.attempts)} if self.enabled else {}
