"""Continuous rigid cuboid contacts for quadratic translation intervals.

Geometry only: no impulses, sliding, collision statuses or arbitrary contact
priority. Tangential motion along an already touching face is non-penetrating.
"""
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.kinematic_bounds import quadratic_range
from combat_sim.orientation import vector3,dot
from combat_sim.oriented_geometry import OrientedCuboid,separating_axes,projected_size


def stationary_face_tangency(delta,half,velocity,acceleration,half_rate,half_acceleration,*,resolution):
    """A numerically stationary touching axis cannot enter box interior.

    Current worlds share their distance/speed/acceleration resolutions here
    and in native contact revalidation. Historical callers keep exact faces.
    """
    distance,speed,change=tuple(map(dec,resolution))
    if any(not x.is_finite() or x<=0 for x in (distance,speed,change)):
        raise ValueError('Contact resolutions must be finite and positive')
    for d,h,v,a,r,q in zip(delta,half,velocity,acceleration,half_rate,half_acceleration):
        sign=D(1) if d>=0 else D(-1)
        if abs(abs(d)-h)<=distance and abs(sign*v-r)<=speed and abs(sign*a-q)<=change:return True
    return False


def first_box_contact(left,right,relative_velocity,relative_acceleration,duration_s,*,left_size_rate_mps=(0,0,0),right_size_rate_mps=(0,0,0),
        left_size_acceleration_mps2=(0,0,0),right_size_acceleration_mps2=(0,0,0),contact_resolution=None,allow_flat_static_right=False):
    """First entry into cuboid interior; includes an approaching end contact.

    Boxes start in world coordinates and retain their orientation throughout
    this interval. Relative velocity/acceleration translate left relative to
    right; size derivatives follow each shape's local axes. The full separating
    axis set handles fixed yaw without replacing a rotated body with its AABB.
    The caller owns Decimal precision and the resulting movement response.
    """
    duration=dec(duration_s)
    left_rate=tuple(map(dec,left_size_rate_mps));right_rate=tuple(map(dec,right_size_rate_mps))
    left_accel=tuple(map(dec,left_size_acceleration_mps2));right_accel=tuple(map(dec,right_size_acceleration_mps2))
    if any(len(v)!=3 for v in (left_rate,right_rate,left_accel,right_accel)) or duration<0:
        raise ValueError('Invalid size-rate vectors or interval duration')
    changing_acceleration=any(left_accel) or any(right_accel)
    flat=(allow_flat_static_right and tuple(map(dec,right.size_m)).count(D(0))==1 and
        all(dec(x)>=0 for x in right.size_m) and not any(right_rate) and not any(right_accel))
    if allow_flat_static_right and any(dec(x)==0 for x in right.size_m) and not flat:
        raise ValueError('A flat static surface cannot resize during its contact interval')
    shapes=((left,left_rate,left_accel),) if flat else ((left,left_rate,left_accel),(right,right_rate,right_accel))
    invalid=(any(quadratic_range(size,rate,accel,0,duration)[0]<=0
            for box,rates,accels in shapes
            for size,rate,accel in zip(box.size_m,rates,accels)) if changing_acceleration else
        any(dec(size)+rate*duration<=0 for box,rates,_ in shapes
            for size,rate in zip(box.size_m,rates)))
    if invalid:
        raise ValueError('Cuboid sizes must stay positive throughout contact interval')
    if isinstance(left,OrientedCuboid) or isinstance(right,OrientedCuboid):
        directions=separating_axes(left,right)
        difference=tuple(a-b for a,b in zip(vector3(left.centre_m),vector3(right.centre_m)))
        v,a=vector3(relative_velocity),vector3(relative_acceleration)
        delta=tuple(dec(dot(difference,n)) for n in directions)
        half=tuple(dec((projected_size(left,n)+projected_size(right,n))/2) for n in directions)
        half_rate=tuple(dec((projected_size(left,n,left_rate)+projected_size(right,n,right_rate))/2) for n in directions)
        half_accel=tuple(dec((projected_size(left,n,left_accel)+projected_size(right,n,right_accel))/2) for n in directions)
        velocity=tuple(dec(dot(v,n)) for n in directions)
        acceleration=tuple(dec(dot(a,n)) for n in directions)
    else:
        delta=tuple(dec(a)-dec(b) for a,b in zip(left.centre_m,right.centre_m))
        half=tuple((dec(a)+dec(b))/2 for a,b in zip(left.size_m,right.size_m))
        half_rate=tuple((a+b)/2 for a,b in zip(left_rate,right_rate))
        half_accel=tuple((a+b)/2 for a,b in zip(left_accel,right_accel))
        velocity=tuple(map(dec,relative_velocity));acceleration=tuple(map(dec,relative_acceleration))
    if contact_resolution is not None and stationary_face_tangency(delta,half,velocity,
            acceleration,half_rate,half_accel,resolution=contact_resolution):return None
    coefficients=tuple((a/2,v,p) for p,v,a in zip(delta,velocity,acceleration))
    cuts={D(0),duration}
    for (a,b,c),extent,rate,change in zip(coefficients,half,half_rate,half_accel):
        for sign in (-1,1):
            quadratic=a-sign*change/2
            face=sign*extent
            linear=b-sign*rate
            offset=c-face
            if not quadratic:
                roots=() if not linear else (-offset/linear,)
            else:
                discriminant=linear*linear-4*quadratic*offset
                roots=() if discriminant<0 else ((-linear-discriminant.sqrt())/(2*quadratic),(-linear+discriminant.sqrt())/(2*quadratic))
            cuts.update(t for t in roots if 0<=t<=duration)
    def inside(t):
        return all(-(extent+rate*t+change*t*t/2) < a*t*t+b*t+c < extent+rate*t+change*t*t/2
                   for (a,b,c),extent,rate,change in zip(coefficients,half,half_rate,half_accel))
    ordered=sorted(cuts)
    for start,end in zip(ordered,ordered[1:]):
        if inside((start+end)/2):
            return start
    # At the final instant, stop if contact would enter rather than separate.
    approaching=False
    for (a,b,c),extent,rate,change in zip(coefficients,half,half_rate,half_accel):
        extent+=rate*duration+change*duration*duration/2
        rate+=change*duration
        value=a*duration*duration+b*duration+c
        derivative=2*a*duration+b
        if abs(value)>extent:
            return None
        if value==extent:
            if derivative-rate>=0:return None
            approaching=True
        elif value==-extent:
            if derivative+rate<=0:return None
            approaching=True
    return duration if approaching else None
