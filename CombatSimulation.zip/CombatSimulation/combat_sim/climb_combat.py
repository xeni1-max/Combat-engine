"""Approved climbing paths integrated with shared actions and live contacts.

The path supplies kinematics, never projectile eligibility or an alternate
combat loop. Segment boundaries split the common continuous coordinator.
"""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.character_geometry import actor_body
from combat_sim.battle_models import BattleAction, ceil_ms, decimal_value as dec
from combat_sim.mechanics.climbing import ClimbPath, surface_distance_squared, within_climb_range
from combat_sim.mechanics.dyspnea import apply_action_dyspnea
from combat_sim.models import UnsupportedMechanicError
from combat_sim.command_dispatch import IntentOutcome
from combat_sim.spatial_motion import CONTACT_SPEED_EPS_MPS

EPS = D('1e-24')
ATTACHMENT_EPS_M = D('1e-20')


class ClimbCombatRules:
    def setup_mobile_combat(self, definition, effects):
        self.climb_enabled = self.climb_input is not None
        self.climb_attachment_enabled = False
        if self.climb_enabled:
            rules = self.climb_input
            expected = {'mode':'integrated_climb', 'range_origin':'character_body_origin',
                'range_inclusive':True, 'path':'up_then_top_centre', 'speed':'constant_along_path',
                'activation_check':'active_start_once', 'movement_during_gathering':'continue',
                'movement_on_success':'use_climb_path', 'payment_timing':'successful_active_start',
                'hands':'retain_current_pose', 'posture':'stand_before_climb',
                'interruption':'project_velocity_then_gravity'}
            if any(rules.get(k) != v for k,v in expected.items()):
                raise UnsupportedMechanicError('Unsupported combat climb definition')
            attachment = rules.get('ongoing_attachment')
            if attachment is not None and attachment != {'mode':'interrupt_on_external_motion_v1'}:
                raise UnsupportedMechanicError('Unsupported ongoing climb attachment rule')
            self.climb_attachment_enabled = attachment is not None
            distance = dec(rules['activation_distance_m'])
            if not distance.is_finite() or distance < 0:
                raise ValueError('Climb range must be finite and nonnegative')
            for actor in self.fighters.values():
                p = rules['characters'].get(actor.profile_id)
                if p is None:
                    raise UnsupportedMechanicError('Missing combat climb profile')
                for key in ('gathering_ms','active_ms','self_disorientation_on_climb',
                            'self_instability_on_climb','listed_dyspnea_value'):
                    value = dec(p[key])
                    if isinstance(p[key],bool) or not value.is_finite() or value < 0:
                        raise ValueError('Climb timings, costs and effects must be finite and nonnegative')
                if dec(p['active_ms']) <= 0 or dec(p['active_ms']) != ceil_ms(dec(p['active_ms'])):
                    raise ValueError('Climb Active must be positive integer milliseconds')
        super().setup_mobile_combat(definition,effects)
        if self.climb_enabled:
            if not self.airborne_enabled:
                raise ValueError('Climb combat requires flight rules for physical interruption')
            self.climb_definition = deepcopy(self.climb_input)
            for name,actor in self.fighters.items():
                self.motion[name]['climb'] = None
                actor.metrics.update(climbs_started=0,climbs_completed=0,
                    climb_requests_rejected=0,climb_interruptions=0)
            self.refresh_mobile_locomotion()

    def _climbing(self,name):
        return (self.climb_enabled and self.motion.get(name,{}).get('climb') is not None
                and self.fighters[name].hp > 0)

    def _climb_state(self,name,time):
        climb = self.motion[name]['climb']
        elapsed = time-climb['start_ms']
        # Preserve analytic corner/end coordinates when subtracting a rounded
        # nonterminating absolute timestamp would leave a tiny residue.
        if abs(time-climb['corner_at_ms']) <= EPS:
            elapsed = climb['path'].corner_ms
        if abs(time-climb['end_at_ms']) <= EPS:
            elapsed = climb['path'].duration
        return climb['path'].at(elapsed)

    def settle_climb_attachments(self):
        """Do not let a prescribed path overwrite imposed body motion.

        Starting reach uses the approved origin-to-surface gate. The approved
        up/across path then maintains attachment, including its raised origin
        above the top. An external pose/velocity override ends that control;
        checking the starting origin radius throughout would abort normal climbs.
        No interpolation, refund, implicit regrip or new jump is introduced.
        """
        if not self.climb_attachment_enabled or not hasattr(self, 'motion'):
            return False
        interrupted = False
        for name, actor in self.fighters.items():
            if not self._climbing(name):
                continue
            expected = self._climb_state(name, self.time).position_m
            actual = tuple(map(dec, actor.body_origin_m))
            xy = tuple(map(dec, actor.position_m))
            # Body origin is the full pose. Also accept the normal horizontal
            # coordinate interface or upright-reference interface when a
            # movement producer updated only that authoritative component.
            if self.equilibrium.enabled:
                # Balance changes the collision proxy's centre without an
                # external displacement of the saved translation path.
                actual = (*xy,self.motion[name]['body_reference_z'])
            elif all(abs(a-b) <= ATTACHMENT_EPS_M for a,b in zip(actual[:2],expected[:2])):
                actual = (*xy, actual[2])
            if not self.equilibrium.enabled and self.posture_ready and abs(actual[2]-expected[2]) <= ATTACHMENT_EPS_M:
                actual = (*actual[:2], self.motion[name]['body_reference_z'])
            displaced = any(abs(a-b) > ATTACHMENT_EPS_M for a,b in zip(actual, expected))
            flight = self.motion[name]['jump']
            if not displaced and flight is None:
                continue
            action = actor.body_action()
            target = self.motion[name]['climb']['target']
            self.set_body_reference(name, actual)
            self.log('climb_attachment_lost', actor=name, target=target,
                action_id=action.id if action is not None else None,
                expected_origin_m=expected, actual_origin_m=actual,
                imposed_velocity_mps=flight['velocity'] if flight is not None else None)
            self.interrupt_combat_climb(actor, 'external_displacement',
                velocity_mps=flight['velocity'] if flight is not None else None)
            if action is not None:
                action.revision += 1
            interrupted = True
        return interrupted

    def mobile_motion(self,name):
        if self._climbing(name):
            return self._climb_state(name,self.time).velocity_mps,(D(0),)*3
        return super().mobile_motion(name)

    def mobile_kinematics(self,name):
        if self._climbing(name):
            velocity = self._climb_state(name,self.time).velocity_mps
            return sum(v*v for v in velocity[:2]).sqrt(),D(0)
        return super().mobile_kinematics(name)

    def mobile_contact_velocity(self,name,seconds):
        if self._climbing(name):
            # A touch at the corner uses the outgoing segment. Exact overhead
            # clearance must not interrupt a path that turns tangentially.
            return self._climb_state(name,self.time+seconds*1000).velocity_mps
        return super().mobile_contact_velocity(name,seconds)

    def next_mobile_knot(self,end):
        finish = super().next_mobile_knot(end)
        for name in self.motion:
            if self._climbing(name):
                c = self.motion[name]['climb']
                if self.time < c['corner_at_ms']:
                    finish = min(finish,c['corner_at_ms'])
                finish = min(finish,c['end_at_ms'])
        return finish

    def advance_mobile_geometry(self,begin,end):
        if self.settle_climb_attachments():
            self.refresh_mobile_locomotion()
        climbers = [n for n in self.motion if self._climbing(n)]
        super().advance_mobile_geometry(begin,end)
        for name in climbers:
            if not self._climbing(name):
                continue
            actor = self.fighters[name]
            state = self._climb_state(name,end)
            self.set_body_reference(name, state.position_m)

    def refresh_mobile_locomotion(self):
        self.settle_climb_attachments()
        super().refresh_mobile_locomotion()
        for name in self.motion:
            if self._climbing(name):
                self.fighters[name].locomotion.update(grounded=False,support_id=None,
                    climb_target=self.motion[name]['climb']['target'])

    def process_mobile_event(self,kind,payload):
        if kind=='movement_climb_corner':
            if self.settle_climb_attachments():
                self.refresh_mobile_locomotion()
            actor = self.fighters[payload['actor']]
            if (not self._climbing(actor.id) or actor.current is None or
                    actor.current.id != payload['action_id']):
                return
            self.log('climb_top_reached',actor=actor.id,target=actor.current.target,
                feet_z_m=self.motion[actor.id]['climb']['path'].top_z)
            self.refresh_mobile_locomotion()
            return
        return super().process_mobile_event(kind,payload)

    def _reject_climb(self,actor,target,reason):
        actor.metrics['climb_requests_rejected'] += 1
        self.log('climb_rejected',actor=actor.id,target=target,reason=reason,
            movement_continues=True,collision_requires_actual_contact=True)

    def try_climb_step(self,actor,target):
        m = self.motion[actor.id]
        obj=self.collider_system.climb_target(target)
        if obj is None:
            known=self.collider_system.registry.objects.get(target)
            self._reject_climb(actor,target,'unknown_climb_target' if known is None or not known.active(self.time) else 'target_not_climbable')
            return IntentOutcome.REJECTED
        p = self.climb_definition['characters'][actor.profile_id]
        ready = self.resource_ready_time(actor,{'kind':'action','base_value':p['listed_dyspnea_value']})
        if ready > self.time:
            if ready.is_finite():
                self.request_decision(actor.id,ready)
            self.log('movement_waiting_for_capacity',actor=actor.id,action='climb',resume_at_ms=ready)
            return IntentOutcome.WAITING
        factor = D('1.2') if self.mobile_is_running(actor.id) else D(1)
        due = ceil_ms(self.time+dec(p['gathering_ms'])*factor+actor.disorientation)
        action = BattleAction(next(self.action_ids),actor.id,target,'climb','climb',self.time,due,
            dec(p['active_ms']),phase='gathering',base_gathering_ms=dec(p['gathering_ms']))
        actor.current = action
        due = self.timed_gathering.commit(actor,action)
        self.log('climb_requested',actor=actor.id,target=target,action_id=action.id,
            active_start_ms=due,origin_m=actor.body_origin_m,
            origin_surface_distance_squared_m2=dec(surface_distance_squared(actor.body_origin_m,self.terrain_colliders[target][0])),
            range_check='once_at_active_start',movement_during_gathering='continue',hands='retained')
        self._schedule_phase(action,'active_started',due)
        return IntentOutcome.STARTED

    def start_combat_climb(self,actor):
        action,m = actor.current,self.motion[actor.id]
        obj=self.collider_system.climb_target(action.target)
        if obj is None:
            actor.current=None
            self._reject_climb(actor,action.target,'target_unavailable_at_active_start')
            self.request_decision(actor.id,self.time)
            return
        # The command dispatcher establishes these prerequisites; recheck the
        # live pose/mode at the activation boundary before any cost or path.
        if ((self.posture_ready and self.posture_at(actor.id,self.time)[0] != 0)
                or m['mode']=='sprinting'):
            actor.current = None
            self._reject_climb(actor,action.target,'posture_or_pace_not_ready_at_active_start')
            self.request_decision(actor.id,self.time)
            return
        box = obj.parts[0]
        allowed = not self._airborne(actor.id) and within_climb_range(
            actor.body_origin_m,box,self.climb_definition['activation_distance_m'])
        self.log('climb_range_checked',actor=actor.id,target=action.target,phase='active_start',
            origin_m=actor.body_origin_m,allowed=bool(allowed),
            origin_surface_distance_squared_m2=dec(surface_distance_squared(actor.body_origin_m,box)))
        if not allowed:
            actor.current = None
            self._reject_climb(actor,action.target,'airborne_at_active_start' if self._airborne(actor.id) else 'outside_activation_range')
            self.request_decision(actor.id,self.time)
            return
        offset = -dec(actor_body(self,actor.id)['standing_placement']['ground_z_m'])
        destination = (dec(box.centre_m[0]),dec(box.centre_m[1]),dec(box.bounds[1][2])+offset)
        if tuple(map(dec,actor.body_origin_m)) == destination:
            actor.current = None
            self.log('climb_command_no_change',actor=actor.id,target=action.target)
            self.request_decision(actor.id,self.time)
            return
        if dec(actor.body_origin_m[2]) > destination[2]:
            actor.current = None
            self._reject_climb(actor,action.target,'target_below_current_support')
            self.request_decision(actor.id,self.time)
            return
        p = self.climb_definition['characters'][actor.profile_id]
        reference=(*actor.position_m,m['body_reference_z']) if self.equilibrium.enabled else actor.body_origin_m
        path = ClimbPath(reference,box,offset,p['active_ms'],precision=self.precision)
        payment = self.action_payment(actor,action,p['listed_dyspnea_value'])
        if not payment.allowed:
            actor.current = None
            self._reject_climb(actor,action.target,'active_start_capacity')
            self.request_decision(actor.id,self.time)
            return
        incoming = self.mobile_motion(actor.id)[0]
        factor = dec(self.combat_locomotion_definition['running_self_effect_multiplier']) if self.mobile_is_running(actor.id) else D(1)
        actor.dyspnea = dec(payment.after)
        actor.metrics['dyspnea_paid'] += dec(payment.action_value)
        additions = {k:dec(p['self_'+k+'_on_climb'])*factor for k in ('disorientation','instability')}
        for key,value in additions.items():
            setattr(actor,key,getattr(actor,key)+value)
        cap_disorientation=D(0)
        if payment.reached_maximum:
            extra = dec(payment.disorientation_trigger)*factor
            cap_disorientation=extra
            actor.disorientation += extra
            self.log('maximum_dyspnea_trigger',actor=actor.id,added_disorientation=extra,source='climb')
        m.pop('imposed_velocity',None)
        m.update(mode='climbing',phase='climb_active',speed=D(0),acceleration=D(0),
            climb={'path':path,'target':action.target,'start_ms':self.time,
                'corner_at_ms':self.time+path.corner_ms,'end_at_ms':self.time+path.duration})
        self.set_body_reference(actor.id, reference)
        action.phase='active'
        action.active_end_ms=self.time+path.duration
        self.extend_parallel_gatherings(actor,additions['disorientation']+cap_disorientation,action.id)
        actor.metrics['climbs_started'] += 1
        self.log('dyspnea_paid',actor=actor.id,ability='climb',action_id=action.id,action_kind='climb',
            phase='active_start',before=dec(payment.before),amount=dec(payment.action_value),after=actor.dyspnea)
        self.log('climb_active_started',actor=actor.id,target=action.target,action_id=action.id,
            origin_m=path.origin,target_origin_m=path.target,path_length_m=path.length,path_speed_mps=path.speed,
            self_effects=additions,velocity_before_climb_mps=incoming,active_end_ms=action.active_end_ms,
            top_reached_at_ms=self.time+path.corner_ms)
        if 0 < path.corner_ms < path.duration:
            self.push(self.time+path.corner_ms,'movement_climb_corner',{'actor':actor.id,'action_id':action.id})
        self._schedule_phase(action,'active_completed',action.active_end_ms)
        self.refresh_mobile_locomotion()

    def complete_combat_climb(self,actor):
        if self.settle_climb_attachments():
            self.refresh_mobile_locomotion()
            if not self._climbing(actor.id):
                return
        m,action = self.motion[actor.id],actor.current
        if self.collider_system.climb_target(action.target) is None:
            self.interrupt_combat_climb(actor,'target_unavailable_at_completion')
            return
        path = m['climb']['path']
        self.set_body_reference(actor.id, path.target)
        m.update(mode='standing',phase=None,climb=None,support_id=action.target,
            support_part=self.terrain_colliders[action.target][0].part,
            ground_origin_z=path.target[2],speed=D(0),acceleration=D(0))
        actor.current = None
        actor.metrics['climbs_completed'] += 1
        self.refresh_mobile_locomotion()
        self.log('climb_completed',actor=actor.id,target=action.target,action_id=action.id,
            body_origin_m=actor.body_origin_m,feet_z_m=path.top_z,support_id=action.target)
        self.request_decision(actor.id,self.time)

    def interrupt_combat_climb(self,actor,reason,*,velocity_mps=None,resume_decision=True):
        if not self._climbing(actor.id):
            return
        m = self.motion[actor.id]
        velocity = self._climb_state(actor.id,self.time).velocity_mps if velocity_mps is None else tuple(map(dec,velocity_mps))
        linked=self.grapple_links.joined(actor.id) and velocity_mps is None
        physical=self.mobile_motion(actor.id)[0] if linked else velocity
        if len(velocity) != 3 or not all(v.is_finite() for v in velocity):
            raise ValueError('Climb interruption needs a finite three-component velocity')
        m.update(climb=None,mode='standing',phase=None,speed=D(0),acceleration=D(0),
            jump={'velocity':velocity,'basic_jump':False})
        action = actor.body_action()
        if action is not None and action.kind=='climb':
            with actor.using_action(action):
                self.note_action_cancelled(actor,action,reason)
                actor.current = None
        actor.metrics['climb_interruptions'] += 1
        self.log('climb_interrupted',actor=actor.id,reason=reason,velocity_before_contact_mps=physical,
            **({'free_velocity_mps':velocity} if linked else {}))
        if resume_decision:self.request_decision(actor.id,self.time)

    def resolve_mobile_contacts(self,contacts):
        for c in contacts:
            # Pose contact can freeze equilibrium without obstructing the
            # prescribed climb path; only translation contact interrupts it.
            if c.get('pose_only') or c.get('angular_collision') and not self.reference_contact_closing(c):
                continue
            if self.fighters[c['first']].hp<=0 or (c['second'] in self.fighters and self.fighters[c['second']].hp<=0):
                continue
            for name in (c['first'],c['second']):
                if name in self.fighters:
                    self.interrupt_combat_climb(self.fighters[name],'body_contact')
        return super().resolve_mobile_contacts(contacts)

    def apply_air_contact_velocity(self,actor,velocity,contacts):
        # Upward prescribed motion is not a new ballistic launch. A tangent
        # angular impact may stop heading while retaining the approved path.
        if self._climbing(actor.id):
            requested=self._climb_state(actor.id,self.time).velocity_mps
            if all(abs(a-b)<=CONTACT_SPEED_EPS_MPS for a,b in zip(velocity,requested)):return None
        return super().apply_air_contact_velocity(actor,velocity,contacts)

    def cancel_mobile_motion(self,actor):
        # Death is resolved after HP reaches zero, so _climbing is already false.
        if self.climb_enabled and self.motion[actor.id].get('climb') is not None:
            self.motion[actor.id].update(climb=None,jump={'velocity':(D(0),)*3,'basic_jump':False})
            actor.metrics['climb_interruptions'] += 1
            self.log('climb_interrupted',actor=actor.id,reason='death')
        return super().cancel_mobile_motion(actor)

    def mobile_result(self):
        result = super().mobile_result()
        if self.climb_enabled:
            result['climb_definition'] = deepcopy(self.climb_definition)
            result['movement_combat_scope']['actions'].append('climb')
            result['movement_combat_scope']['prescribed_motion'] = 'climb_path_with_live_contacts'
        return result
