"""Fixed world collider identities, compound geometry and lifecycle state."""
from dataclasses import dataclass
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import Cuboid
from combat_sim.models import as_fraction
from combat_sim.mechanics.life import life_generation
from combat_sim.oriented_geometry import OrientedCuboid


OBJECT_DAMAGE_TYPES=frozenset({'blunt','slash','qard','heat','constriction','tear','constriction_tear'})


def damage_immunities(values):
    values=collider_tags(values)
    if not set(values)<=OBJECT_DAMAGE_TYPES|{'toxin','electrocution'}:
        raise ValueError('Unknown material damage immunity')
    return values


def collider_tags(values):
    """Stable semantic labels, independent of collider geometry and lifetime."""
    if not isinstance(values,(list,tuple)) or any(not isinstance(v,str) or not v for v in values):
        raise ValueError('Collider tags must be nonempty strings in a list or tuple')
    if len(set(values))!=len(values):raise ValueError('Collider tags cannot repeat')
    return tuple(sorted(values))


def finite(value,name,*,positive=False):
    try:
        if isinstance(value,bool):raise ValueError
        result=dec(value)
        if not result.is_finite() or result<0 or positive and result<=0:raise ValueError
    except (ValueError,TypeError,ArithmeticError) as error:
        raise ValueError(name+' must be finite and '+('positive' if positive else 'nonnegative')) from error
    return result


@dataclass(frozen=True)
class ColliderPolicy:
    projectiles: bool = True
    bodies: bool = True
    areas: bool = False

    def __post_init__(self):
        if any(type(value) is not bool for value in (self.projectiles,self.bodies,self.areas)):
            raise ValueError('Collider blocking policies must be explicit booleans')

    @classmethod
    def from_definition(cls,value):
        if not isinstance(value,dict) or set(value)!={'projectiles','bodies','areas'}:
            raise ValueError('Collider policy requires projectiles, bodies and areas')
        return cls(**value)

    def record(self):return dict(projectiles=self.projectiles,bodies=self.bodies,areas=self.areas)


@dataclass(frozen=True)
class ColliderIdentity:
    id: str
    created_at_ms: D
    kind: str
    source: str
    owner: str | None = None
    ability: str | None = None
    action_id: int | None = None
    source_life_generation: int | None = None
    tags: tuple = ()


@dataclass
class WorldCollider:
    identity: ColliderIdentity
    parts: tuple
    policy: ColliderPolicy
    hp: D | None = None
    max_hp: D | None = None
    expires_at_ms: D | None = None
    climbable: bool = False
    permanent: bool = False
    status: str = 'active'
    revision: int = 0
    collision_revision: int = 0
    expiry_revision: int = 0
    removed_at_ms: D | None = None
    removal_reason: str | None = None
    damage_immunities: tuple = ()

    def active(self,time=None):
        return self.status=='active' and (time is None or self.expires_at_ms is None or time<self.expires_at_ms)

    def record(self):
        i=self.identity
        return {'id':i.id,'kind':i.kind,'source':i.source,'owner':i.owner,'ability':i.ability,'action_id':i.action_id,
            **({'source_life_generation':i.source_life_generation} if i.source_life_generation is not None else {}),
            **({'tags':list(i.tags)} if i.tags else {}),
            **({'damage_immunities':list(self.damage_immunities)} if self.damage_immunities else {}),
            'created_at_ms':str(i.created_at_ms),'status':self.status,'revision':self.revision,
            'collision_revision':self.collision_revision,'expiry_revision':self.expiry_revision,
            'hp':str(self.hp) if self.hp is not None else None,'max_hp':str(self.max_hp) if self.max_hp is not None else None,
            'expires_at_ms':str(self.expires_at_ms) if self.expires_at_ms is not None else None,
            'climbable':self.climbable,'permanent':self.permanent,'blocking':self.policy.record(),
            'removed_at_ms':str(self.removed_at_ms) if self.removed_at_ms is not None else None,
            'removal_reason':self.removal_reason,'parts':[{'part':part.part,
                'minimum_m':[str(dec(v)) for v in part.bounds[0]],
                'maximum_m':[str(dec(v)) for v in part.bounds[1]],
                **({'shape':'oriented_cuboid','centre_m':[str(dec(v)) for v in part.centre_m],
                    'size_m':[str(dec(v)) for v in part.size_m],'yaw_frame':part.frame.record()}
                    if isinstance(part,OrientedCuboid) else {})} for part in self.parts]}


class ColliderRegistry:
    def __init__(self,reserved_ids=()):
        self.reserved=set(reserved_ids)
        self.objects={}
        self.ids=count(1)
        self.epoch=0

    @staticmethod
    def clock(obj,time):
        time=finite(time,'Collider time')
        if time<obj.identity.created_at_ms:raise ValueError('Collider changes cannot predate creation')
        return time

    @staticmethod
    def validate_parts(parts,climbable=False):
        parts=tuple(parts)
        if not parts or len({p.part for p in parts})!=len(parts):
            raise ValueError('A collider needs independently named parts')
        for part in parts:
            low,high=part.bounds
            if (not isinstance(part.part,str) or not part.part or len(low)!=3 or len(high)!=3
                    or any(not dec(v).is_finite() for v in (*low,*high)) or any(a>b for a,b in zip(low,high))):
                raise ValueError('Invalid fixed collider bounds')
        if climbable and (len(parts)!=1 or not isinstance(parts[0],(Cuboid,OrientedCuboid))):
            raise ValueError('Current climb path requires one solid cuboid')
        return parts

    def add(self,parts,*,time,source,kind='deployed',entity_id=None,policy=ColliderPolicy(),hp=None,
            expires_at_ms=None,climbable=False,permanent=False,owner=None,ability=None,action_id=None,source_life_generation=None,
            tags=(),immune_damage_types=()):
        time=finite(time,'Creation time')
        if kind not in ('terrain','deployed') or not isinstance(source,str) or not source:
            raise ValueError('A collider requires a kind and source identity')
        if not isinstance(policy,ColliderPolicy) or type(climbable) is not bool or type(permanent) is not bool:
            raise ValueError('Invalid collider policy or flags')
        parts=self.validate_parts(parts,climbable)
        if kind=='deployed' and any(not isinstance(part,(Cuboid,OrientedCuboid)) for part in parts):
            raise ValueError('Deployed colliders require positive cuboid parts')
        hp=finite(hp,'Collider HP',positive=True) if hp is not None else None
        expiry=finite(expires_at_ms,'Collider expiry') if expires_at_ms is not None else None
        if expiry is not None and expiry<=time:raise ValueError('Collider expiry must be after creation')
        if permanent and (hp is not None or expiry is not None):raise ValueError('Permanent ground cannot have HP or expiry')
        if (owner is None)!=(ability is None) or owner is not None and (
                not isinstance(owner,str) or not owner or not isinstance(ability,str) or not ability):
            raise ValueError('Collider ability attribution needs both owner and ability')
        if action_id is not None and (owner is None or type(action_id) is not int or action_id<=0):
            raise ValueError('Collider action attribution needs its owner and a positive action ID')
        life_generation(source_life_generation)
        if source_life_generation is not None and owner is None:raise ValueError('Collider life attribution needs its owner')
        tags=collider_tags(tags)
        immunities=damage_immunities(immune_damage_types)
        if entity_id is None:
            entity_id='collider:'+str(next(self.ids))
            while entity_id in self.objects or entity_id in self.reserved:
                entity_id='collider:'+str(next(self.ids))
        if (not isinstance(entity_id,str) or not entity_id or entity_id in self.objects or entity_id in self.reserved):
            raise ValueError('Collider identities are unique and cannot be reused')
        obj=WorldCollider(ColliderIdentity(entity_id,time,kind,source,owner,ability,action_id,source_life_generation,tags),parts,
            policy,hp,hp,expiry,climbable,permanent,damage_immunities=immunities)
        self.objects[entity_id]=obj
        self.epoch+=1
        return obj

    def active(self,channel=None,time=None):
        return {key:obj.parts for key,obj in self.objects.items() if obj.active(time)
            and (channel is None or getattr(obj.policy,channel))}

    def contact_fields(self,entity_id):
        obj=self.objects[entity_id]
        return {'collider_id':entity_id,'collider_revision':obj.collision_revision}

    def contact_live(self,payload,channel,time=None):
        obj=self.objects.get(payload.get('collider_id'))
        return (obj is not None and obj.active(time) and getattr(obj.policy,channel)
            and obj.collision_revision==payload.get('collider_revision'))

    def remove(self,entity_id,*,time,reason,status='removed'):
        obj=self.objects[entity_id]
        time=self.clock(obj,time)
        if obj.status!='active':return False
        if obj.permanent:raise ValueError('Permanent ground cannot be removed')
        if status not in ('removed','destroyed','expired') or not isinstance(reason,str) or not reason:
            raise ValueError('Collider removal needs a terminal state and reason')
        obj.status=status;obj.removed_at_ms=time;obj.removal_reason=reason
        obj.revision+=1;obj.collision_revision+=1;obj.expiry_revision+=1;self.epoch+=1
        return True

    def damage(self,entity_id,amount,*,time,interval_begin_ms=None):
        amount=finite(amount,'Collider damage')
        obj=self.objects[entity_id]
        time=self.clock(obj,time)
        begin=self.clock(obj,interval_begin_ms) if interval_begin_ms is not None else None
        if begin is not None and begin>=time:raise ValueError('Continuous collider damage needs a positive interval')
        # Continuous loss belongs to [begin,time), before expiry at its right
        # endpoint. Point hits at expiry still see the half-open inactive object.
        accepts=obj.active(time) or (begin is not None and obj.active(begin)
            and obj.status=='active' and obj.expires_at_ms==time)
        if not accepts or obj.hp is None or not amount:return D(0)
        applied=min(obj.hp,amount)
        obj.hp-=applied;obj.revision+=1
        if obj.hp==0:self.remove(entity_id,time=time,reason='hp_zero',status='destroyed')
        return applied

    def reshape(self,entity_id,*,parts=None,policy=None,time):
        obj=self.objects[entity_id]
        time=self.clock(obj,time)
        if not obj.active(time):return False
        if obj.permanent:raise ValueError('Permanent ground cannot change geometry or policy')
        parts=self.validate_parts(parts if parts is not None else obj.parts,obj.climbable)
        if obj.identity.kind=='deployed' and any(not isinstance(part,(Cuboid,OrientedCuboid)) for part in parts):
            raise ValueError('Deployed colliders require positive cuboid parts')
        policy=policy if policy is not None else obj.policy
        if not isinstance(policy,ColliderPolicy):raise ValueError('Invalid collider policy')
        if parts==obj.parts and policy==obj.policy:return False
        obj.parts=parts;obj.policy=policy;obj.revision+=1;obj.collision_revision+=1;self.epoch+=1
        return True

    def set_expiry(self,entity_id,*,time,expires_at_ms):
        obj=self.objects[entity_id]
        time=self.clock(obj,time)
        if not obj.active(time):return False
        if obj.permanent:raise ValueError('Permanent ground cannot expire')
        expiry=finite(expires_at_ms,'Collider expiry') if expires_at_ms is not None else None
        if expiry is not None and expiry<=time:raise ValueError('Refreshed expiry must be in the future')
        obj.expires_at_ms=expiry;obj.expiry_revision+=1;obj.revision+=1
        return True

    def record(self):return {key:obj.record() for key,obj in sorted(self.objects.items())}


def segment_crosses_interior(start,end,part):
    """Exact positive-length line penetration; tangential touch is not cover."""
    start,end=tuple(map(as_fraction,start)),tuple(map(as_fraction,end))
    if len(start)!=3 or len(end)!=3:raise ValueError('Cover segments require three-dimensional endpoints')
    if isinstance(part,OrientedCuboid):
        return segment_crosses_interior(part.frame.to_local_point(start,part.centre_m),
            part.frame.to_local_point(end,part.centre_m),part.local_box)
    if start==end:return False
    low,high=part.bounds
    enter,leave=as_fraction(0),as_fraction(1)
    for p,q,a,b in zip(start,end,low,high):
        delta=q-p
        if not delta:
            if not a<p<b:return False
            continue
        first,last=sorted(((a-p)/delta,(b-p)/delta))
        enter=max(enter,first);leave=min(leave,last)
        if enter>=leave:return False
    return enter<leave
