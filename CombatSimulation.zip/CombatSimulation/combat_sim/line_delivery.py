"""Finite sphere-swept lines hit each receiver once, clipped by solid cover.

Receiver identity and gameplay effects belong to the caller. Exact cuboids and
the existing swept-sphere primitive determine physical overlap, including corners.
Bodies do not occlude other receivers; the nearest world solid does.
"""
from dataclasses import dataclass

from combat_sim.models import as_fraction


@dataclass(frozen=True)
class LineSweep:
    recipients: tuple
    blocker: tuple | None


def sweep_line(start,end,radius,receivers,solids,*,precision=50):
    start,end=tuple(map(as_fraction,start)),tuple(map(as_fraction,end))
    radius=as_fraction(radius)
    if len(start)!=3 or len(end)!=3 or start==end or radius<0:
        raise ValueError('A directed line needs distinct finite 3D endpoints and a nonnegative radius')

    def first(parts):
        contacts=[hit for box in parts if (hit:=box.swept_sphere_contact(start,end,radius,precision=precision)) is not None]
        return min(contacts,key=lambda h:(h.parameter,h.part)) if contacts else None

    covers=[(key,hit) for key,parts in solids.items() if (hit:=first(parts)) is not None]
    blocker=min(covers,key=lambda p:(p[1].parameter,p[0],p[1].part)) if covers else None
    recipients=[]
    for key,parts in sorted(receivers.items()):
        hit=first(parts)
        # A solid wins a closed boundary tie. An earlier body never truncates
        # the line, so all distinct receivers in front of cover retain a hit.
        if hit is not None and (blocker is None or hit.parameter<blocker[1].parameter):
            recipients.append((key,hit))
    return LineSweep(tuple(recipients),blocker)
