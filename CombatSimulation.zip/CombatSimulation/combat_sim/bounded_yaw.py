"""Rational enclosures for degree-selected upright frames.

Existing fixed headings retain their original numerical selector. Moving yaw
needs an error bound as well: a swept enclosure must contain geometry between
its endpoints. Machin's formula and alternating Taylor remainders bound the
ideal sine/cosine; outward rational rounding bounds every intermediate step.
The selected frame still has exactly unit length, with no normalization drift.
"""
from fractions import Fraction as F
from functools import lru_cache

from combat_sim.orientation import YawFrame, scalar


def _outward(low, high, scale):
    return F((low*scale).__floor__(), scale), F((high*scale).__ceil__(), scale)


def _multiply(first, second, scale):
    values = [a*b for a in first for b in second]
    return _outward(min(values), max(values), scale)


def _atan_reciprocal(denominator, threshold):
    value = F(1, denominator)
    square = -value*value
    power, total, n = value, value, 1
    while True:
        power *= square
        term = power/(2*n+1)
        if abs(term) <= threshold:
            return min(total, total+term), max(total, total+term)
        total += term
        n += 1


def pi_bounds(precision=50):
    """Exact rational lower/upper bounds, independent of Decimal context."""
    if type(precision) is not int or precision < 40:
        raise ValueError('Angular precision must be an integer of at least 40 digits')
    return _pi_bounds(precision)


@lru_cache(maxsize=32)
def _pi_bounds(precision):
    scale = 10**(precision+12)
    a, b = _atan_reciprocal(5, F(1, scale)), _atan_reciprocal(239, F(1, scale))
    return _outward(16*a[0]-4*b[1], 16*a[1]-4*b[0], scale)


def _trig(argument, cosine, scale):
    # Reduction guarantees |argument| <= pi/8 < 2/5. Each series is
    # alternating with decreasing terms, including negative sine arguments.
    square = _multiply(argument, argument, scale)
    term = (F(1), F(1)) if cosine else argument
    total = term
    bound = F(1) if cosine else F(2, 5)
    n = 1
    while True:
        divisor = (2*n-1)*(2*n) if cosine else (2*n)*(2*n+1)
        bound *= F(4, 25)/divisor
        if bound <= F(1, scale):
            return total[0]-bound, total[1]+bound
        product = _multiply(term, square, scale)
        term = _outward(-product[1]/divisor, -product[0]/divisor, scale)
        total = total[0]+term[0], total[1]+term[1]
        n += 1


def bounded_degrees_frame(degrees, precision=50):
    """Return an exact unit frame and a bound on each coefficient's error.

    Error is relative to ideal trigonometry of the supplied rational degrees,
    not a claim about a physical body's other numerical drivers.
    """
    pi_bounds(precision)  # validate before caching, including cardinal inputs
    angle = scalar(degrees) % 360
    return _bounded_degrees_frame(angle, precision)


@lru_cache(maxsize=1024)
def _bounded_degrees_frame(angle, precision):
    pi = pi_bounds(precision)
    quarter = int((angle+45)//90)
    offset = angle-90*quarter
    c, s = ((1, 0), (0, 1), (-1, 0), (0, -1))[quarter % 4]
    if not offset:
        return YawFrame(c, s), F(0)
    scale = 10**(precision+12)
    argument = tuple(sorted(offset*v/360 for v in pi))
    sine, cosine = _trig(argument, False, scale), _trig(argument, True, scale)
    assert cosine[0] > 0
    ratios = [a/b for a in sine for b in cosine]
    low, high = _outward(min(ratios), max(ratios), scale)
    base = YawFrame.from_half_angle_tangent((low+high)/2)
    frame = YawFrame(c*base.cosine-s*base.sine, s*base.cosine+c*base.sine)
    # Both stereographic coefficients have absolute derivative <= 2.
    return frame, high-low
