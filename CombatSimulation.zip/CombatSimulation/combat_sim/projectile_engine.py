"""Controlled single-activation projectile/area execution, separate from AI.

Targets and blast eligibility are explicit scenario decisions. No movement,
hit detection, action availability, or general team-event ordering is inferred.
"""

from fractions import Fraction
from typing import Any

from combat_sim.actions import ScriptedActionSequence
from combat_sim.encounters import initial_states
from combat_sim.events import EventLog
from combat_sim.mechanics import qard
from combat_sim.mechanics.shield import split_damage
from combat_sim.mechanics.status import decay_status
from combat_sim.status_events import _advance_statuses, _apply_effects
from combat_sim.mechanics.timing import impact_time_from_activation, self_effect_time_from_activation
from combat_sim.models import UnsupportedMechanicError, as_fraction, fraction_record
from combat_sim.state_updates import _advance_regeneration, _state_snapshot, _validate_shield_state


def _ms(value, label):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{label} must be a nonnegative integer millisecond")
    return value


def _hit(actor, target, ability_id, ability, time, origin, timing, states, profiles, pending, index, log):
    state, profile = states[target], profiles[target]
    before = (state.hp, state.armor, state.shield)
    incoming = as_fraction(ability["pre_mitigation_damage"])
    shield_damage, overflow = split_damage(incoming, state.shield)
    raw = qard.raw_post_mitigation_damage(overflow, state.armor, profile["resistances"]["qard"]) if overflow else Fraction(0)
    damage = max(Fraction(0), raw)
    state.shield -= shield_damage
    state.hp = max(Fraction(0), state.hp - damage)
    actual = before[0] - state.hp
    if shield_damage:
        regen = profile.get("shield_regeneration")
        if not regen or as_fraction(regen["rate_per_second"]) <= 0:
            raise UnsupportedMechanicError(f"{target} requires a positive documented shield regeneration rate")
        pending.append({
            "loss_instance": index, "target": target, "loss_at_ms": time,
            "eligible_at_ms": time + _ms(regen["delay_ms"], "Shield regeneration delay"),
            "remaining": shield_damage, "rate_per_second": as_fraction(regen["rate_per_second"]),
            "source": regen["source"],
        })
    log.record({
        "time_ms": time, "type": "impact_resolved", "actor": actor, "target": target,
        "ability": ability_id, "origin": origin, "hit_confirmation": "supplied_by_scenario",
        "timing_calculation": timing,
        "damage_calculation": {
            "damage_type": "qard", "damage_category": "extrinsic",
            "incoming_damage": fraction_record(incoming),
            "shield_handling": {
                "shield_damage_is_unmitigated": True, "shield_before": fraction_record(before[2]),
                "damage_to_shield": fraction_record(shield_damage),
                "shield_after_impact": fraction_record(state.shield),
                "damage_left_after_shield": fraction_record(overflow),
            },
            "formulas": {"post_mitigation_damage": qard.FORMULA, "armor_reduction": "0; Qard does not reduce armor, confirmed by author"},
            "formula_evaluation": "evaluated_on_damage_left_after_shield" if overflow else "skipped_fully_absorbed_by_shield",
            "formula_inputs": {"dq_left_after_shield": str(overflow), "a_pre_impact": str(before[1]), "Rq": str(profile["resistances"]["qard"])} if overflow else None,
            "outputs": {"y": {**fraction_record(damage), "formula_source": qard.SOURCE}, "Ar": {**fraction_record(Fraction(0)), "formula_source": qard.SOURCE}},
            "raw_formula_outputs_before_zero_clamp": {"y": fraction_record(raw), "Ar": fraction_record(Fraction(0))},
            "applied_state_losses": {"hp": fraction_record(actual), "armor": fraction_record(Fraction(0))},
            "excess_formula_outputs": {"hp": fraction_record(damage - actual), "armor": fraction_record(Fraction(0))},
            "state_mapping": "Qard reduces HP after shield overflow; armor unchanged; HP minimum zero",
            "state_mapping_status": "confirmed_by_user",
        },
        "state_changes": {
            "target": target, "hp_before": fraction_record(before[0]), "hp_after_impact": fraction_record(state.hp),
            "armor_before": fraction_record(before[1]), "armor_after_impact": fraction_record(state.armor),
            "shield_before": fraction_record(before[2]), "shield_after_impact": fraction_record(state.shield),
        },
        "sources": {"ability": ability["source"], "damage_rule": qard.SOURCE, "target_profile": profile["source"]},
    })
    if shield_damage:
        log.record({
            "time_ms": time, "type": "shield_regeneration_scheduled", "target": target,
            "loss_instance": index, "amount_lost": fraction_record(shield_damage),
            "eligible_at_ms": pending[-1]["eligible_at_ms"],
            "shared_rate_per_second": str(pending[-1]["rate_per_second"]),
            "source": pending[-1]["source"],
        })
    # HP/shield application and target effects commute here: max HP and armor
    # are unchanged, and this stage has no conditional shield bonuses. This is
    # a local logging order, not a global policy for future simultaneous hits.
    _apply_effects(target, state, profile, ability["target_effects"], time, origin, log)


def run_projectile_scenario(scenario: dict[str, Any], profiles: dict[str, Any]) -> dict[str, Any]:
    allowed = {"id", "description", "encounter", "action_sequence", "run_until_ms"}
    if set(scenario) - allowed:
        raise UnsupportedMechanicError("Unsupported controlled scenario fields: " + ", ".join(sorted(set(scenario) - allowed)))
    encounter = scenario.get("encounter", {})
    if set(encounter) - {"initial_states", "movement"}:
        raise UnsupportedMechanicError("Controlled encounter supports initial_states and movement only")
    if encounter.get("movement") != "stationary":
        raise UnsupportedMechanicError("Controlled projectile stage requires encounter movement='stationary'")
    states = initial_states(encounter, track_statuses=True)
    initial = _state_snapshot(states)
    inputs = ScriptedActionSequence(scenario.get("action_sequence", [])).inputs()
    if len(inputs) != 1:
        raise UnsupportedMechanicError("Controlled projectile stage requires exactly one activation")
    action = inputs[0]
    fields = {"kind", "action_start_ms", "actor", "target", "ability", "hit_confirmed", "target_distance_m", "area_targets"}
    if set(action) - fields:
        raise UnsupportedMechanicError("Unsupported controlled action fields: " + ", ".join(sorted(set(action) - fields)))
    if action.get("kind") != "activation" or action.get("hit_confirmed") is not True:
        raise UnsupportedMechanicError("Controlled projectile stage requires a scenario-confirmed activation hit")
    actor, target, ability_id = (action.get(key) for key in ("actor", "target", "ability"))
    area_targets = action.get("area_targets")
    if not isinstance(area_targets, list) or any(not isinstance(name, str) for name in area_targets):
        raise ValueError("area_targets must explicitly list the characters hit by the delayed blast, or []")
    if len(set(area_targets)) != len(area_targets):
        raise ValueError("area_targets cannot contain duplicates")
    if actor == target:
        raise UnsupportedMechanicError("Direct self-targeting is outside this controlled projectile test")
    for name in {actor, target, *area_targets}:
        if name not in states or name not in profiles:
            raise ValueError(f"Character {name!r} must have an initial state and a profile")
    for name, state in states.items():
        profile = profiles.get(name, {})
        for field in ("max_hp", "shield_capacity", "status_resistance"):
            if field not in profile:
                raise UnsupportedMechanicError(f"Controlled character {name} has incomplete defender data: {field}")
        if "qard" not in profile.get("resistances", {}):
            raise UnsupportedMechanicError(f"Controlled character {name} requires documented Qard resistance")
        if any(as_fraction(value) < 0 for value in (profile["max_hp"], profile["status_resistance"], profile["resistances"]["qard"])):
            raise ValueError("Maximum HP and resistances must be nonnegative")
        _validate_shield_state(state, as_fraction(profile["shield_capacity"]), name)
    ability = profiles[actor]["abilities"][ability_id]
    area = ability["delayed_area"]
    if ability.get("damage_type") != "qard" or ability.get("damage_category") != "extrinsic":
        raise UnsupportedMechanicError("This controlled model currently executes extrinsic Qard damage only")
    if area.get("damage_and_target_effects") != "same_as_initial_hit" or area.get("anchor") != "initial_impact_location":
        raise UnsupportedMechanicError("Only a delayed blast with the same damage/effects at the original impact location is supported")
    start = _ms(action.get("action_start_ms"), "action_start_ms")
    gathering_status = decay_status(states[actor].statuses.disorientation, start)
    timing_profile = profiles[actor]["timing_profiles"][ability["timing_profile"]]
    impact, timing = impact_time_from_activation(
        start, timing_profile, action.get("target_distance_m"),
        disorientation_at_gathering_start=gathering_status,
    )
    self_time, self_timing = self_effect_time_from_activation(
        start, timing_profile, ability["self_effects"]["application_timing"],
        disorientation_at_gathering_start=gathering_status,
    )
    release = timing["projectile_release_time_ms"]
    blast = impact + _ms(area["delay_ms"], "Delayed area delay")
    until = _ms(scenario.get("run_until_ms", blast), "run_until_ms")
    if until < blast:
        raise ValueError("run_until_ms must include the delayed blast")
    # Priorities describe causal stages of this one activation only. No global
    # ordering for unrelated combatants is invented.
    queue = [(start, 0, "ability_started"), (self_time, 1, "self_effect"),
             (release, 2, "projectile_released"), (impact, 3, "projectile_impact"),
             (blast, 4, "delayed_area")]
    log, pending, current, hit_index = EventLog(), [], 0, 0
    for time, _, event in sorted(queue):
        _advance_regeneration(states, profiles, pending, current, time, log)
        _advance_statuses(states, current, time, log)
        current = time
        common = {"time_ms": time, "actor": actor, "ability": ability_id}
        if event == "ability_started":
            log.record({**common, "type": event, "timing_calculation": timing, "actor_state": states[actor].to_record(), "availability": "Activation supplied by scenario; cooldown/dyspnea eligibility not evaluated"})
        elif event == "self_effect":
            log.record({**common, "type": "self_effect_triggered", "timing_calculation": self_timing})
            _apply_effects(actor, states[actor], profiles[actor], ability["self_effects"], time, "self", log)
        elif event == "projectile_released":
            log.record({**common, "type": event, "target": target, "actor_state": states[actor].to_record(), "timing_calculation": timing})
        elif event == "projectile_impact":
            _hit(actor, target, ability_id, ability, time, "initial_projectile", timing, states, profiles, pending, hit_index, log)
            hit_index += 1
            log.record({**common, "type": "area_marker_created", "anchor": "initial_impact_location", "detonates_at_ms": blast, "radius_m": area["radius_m"], "source": area["source"]})
        elif event == "delayed_area":
            log.record({**common, "type": "area_detonated", "anchor": "initial_impact_location", "radius_m": area["radius_m"], "targets": sorted(area_targets), "eligibility": "supplied_by_scenario_at_detonation"})
            for name in sorted(area_targets):
                _hit(actor, name, ability_id, ability, time, "delayed_area", {"anchor": "initial_impact_plus_delay", "initial_impact_time_ms": impact, "delay_ms": area["delay_ms"]}, states, profiles, pending, hit_index, log)
                hit_index += 1
    _advance_regeneration(states, profiles, pending, current, until, log)
    _advance_statuses(states, current, until, log)
    # Regeneration and decay are continuous interval records, potentially
    # emitted in character order. Present them in chronological time order.
    events = sorted(log.records(), key=lambda item: Fraction(item["time_ms"]) if isinstance(item["time_ms"], int) else Fraction(item["time_ms"]["exact"]))
    return {
        "scenario_id": scenario.get("id", "unnamed"), "initial_states": initial,
        "encounter_configuration": {"movement": encounter["movement"]},
        "inputs": inputs, "run_until_ms": until, "events": events,
        "final_states": _state_snapshot(states),
        "pending_shield_regeneration": [
            {"target": cohort["target"], "loss_instance": cohort["loss_instance"],
             "loss_at_ms": cohort["loss_at_ms"], "eligible_at_ms": cohort["eligible_at_ms"],
             "remaining": fraction_record(cohort["remaining"])}
            for cohort in pending
        ],
        "assumptions_and_limits": [
            "One stationary scripted activation; the scenario confirms the initial hit and explicitly supplies delayed-blast recipients. The marker remains at the initial impact location; geometry is not simulated.",
            "Both hits use the same Qard damage and target effects, confirmed by the author. Qard does not reduce armor.",
            "Firing is extrinsic (Details.odt); instability's intrinsic-damage penalty does not reduce this weapon's damage. Accuracy/hit detection are supplied rather than simulated.",
            "Target effects receive collision mitigation before additive stacking. Self disorientation/instability bypass all mitigation and retain the running +20% rule; running is outside this stationary stage. Target mitigation uses fixed 40-digit precision; status records are Decimal values.",
            "Statuses decay continuously by one point per millisecond with a zero floor. Interval logs report continuous changes between scheduled events.",
            "Damage precedes target status entries locally; those operations commute here because Qard leaves armor/max HP unchanged and no conditional shield resistance bonuses are active. This is not a global simultaneous-event rule.",
            "Shield absorbs raw damage; each loss waits its own delay and eligible losses share the profile regeneration rate. Initial missing shield HP has no invented regeneration history.",
            "Cooldown availability, dyspnea costs, hand Recovery, movement, death/revival, general interrupts, and autonomous decisions are not executed. HP depletion alone is not interpreted as a complete encounter outcome.",
        ],
    }
