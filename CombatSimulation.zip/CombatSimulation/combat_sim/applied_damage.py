"""Applied actor HP receipts composed with existing physical damage commits."""
from decimal import Decimal as D
from combat_sim.automatic_abilities import ability_definition

from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.damage_ledger import (AffineHeatDose,BleedDose,DamageContribution,DamageLedger,
    PiecewiseDose,QuarticDose)
from combat_sim.models import UnsupportedMechanicError
from combat_sim.mechanics.rate_damage import RateDamageSource


class AppliedDamage:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'applied_hp_v1'} or not world.effect_system.enabled):
            raise UnsupportedMechanicError('Applied HP history requires the typed integrated world')
        self.history=DamageLedger(world.precision);self.keys=set();self.thermal_curves={}

    def eligible(self,actor,target):
        return actor!=target and self.world.fighters[actor].team!=self.world.fighters[target].team

    def _record(self,key,target,begin,end,contributions,actual):
        if key in self.keys:raise ValueError('Applied HP receipt was already recorded')
        receipt='loss-receipt:'+str(len(self.keys)+1)
        generation=self.world.life_cycles.generation(target) if hasattr(self.world,'life_cycles') else None
        entries=self.history.record_loss(receipt,target,begin,end,contributions,actual,target_life_generation=generation)
        self.keys.add(key)
        if begin==end and hasattr(self.world,'healing'):self.world.healing.stage_points(entries)
        self.world.log('applied_hp_credited',receipt_id=receipt,target=target,interval_start_ms=begin,interval_end_ms=end,
            applied_hp_damage=actual,eligible_hp_damage=sum((e.amount for e in entries if e.contribution.eligible),D(0)),
            entries=[e.record() for e in entries])
        return entries

    def point(self,target,packets,calculations,actual):
        if not self.enabled or not actual:return ()
        values=[]
        for p,hit in zip(packets,calculations):
            source=EffectSource(p['actor'],p['ability'],p['action_id'],p.get('projectile_id'),p.get('source_life_generation'))
            # The standalone journal also accepts a profile-only data world.
            # Shared encounters resolve the actual released variant/component.
            resolver=getattr(self.world,'attack_definition',None)
            ability=(resolver(p['actor'],p['ability'],p.get('melee_component'),packet=p) if resolver is not None
                else ability_definition(self.world.fighters[p['actor']],p['ability']))
            kind=ability.get('direct_damage_type',ability['damage_type'])
            values.append(DamageContribution(source,hit.hp_damage,kind,self.eligible(p['actor'],target),
                component=p.get('component','impact')))
        # Receipt identity follows the attack, not mutable defense/damage values.
        generation=self.world.life_cycles.generation(target) if hasattr(self.world,'life_cycles') else None
        key=('point',self.world.time,target,generation,tuple(sorted(c.key[:-1] for c in values)))
        return self._record(key,target,self.world.time,self.world.time,values,actual)

    def _thermal_curve(self,target,incident_id):
        plan=self.world.thermal_recovery.caches[target]['thermal']
        cached=self.thermal_curves.get(target)
        if cached is None or cached[0] is not plan:
            cached=(plan,{})
            self.thermal_curves[target]=cached
        if incident_id not in cached[1]:
            index=next(i for i,source in enumerate(plan.sources) if source.id==incident_id)
            count=len(plan.sources);pieces=[]
            for segment in plan.segments:
                if segment.dense is None:
                    if isinstance(plan.sources[index],RateDamageSource):continue
                    curve=AffineHeatDose(plan.sources[index].coefficient,segment.body_begin[index],segment.begin,segment.slopes[index])
                    pieces.append((segment.begin,segment.end,curve))
                else:
                    dose_index=count+index
                    for step in segment.dense.steps:
                        curve=QuarticDose(step.begin,step.end,step.initial[dose_index],step.final[dose_index],step.coefficients[dose_index])
                        pieces.append((step.begin,step.end,curve))
            cached[1][incident_id]=PiecewiseDose(tuple(pieces))
        return cached[1][incident_id]

    def continuous(self,target,begin,end,parts,actual):
        if not self.enabled or not actual:return ()
        values=[]
        for part in parts:
            if part['channel']!='hp' or not part['amount']:continue
            inputs=part['inputs'];kind=part['kind'];curve=self.curve(target,part,begin,end)
            source=EffectSource(part['actor'],part['ability'],part['action_id'],part.get('projectile_id'),part.get('source_life_generation'))
            values.append(DamageContribution(source,part['amount'],kind,self.eligible(part['actor'],target),curve,
                str(part['effect_id']),inputs.get('volume_id'),component=kind))
        return self._record(('continuous',target,begin,end),target,begin,end,values,actual)

    def curve(self,target,part,begin,end):
        """The same immutable measure serves HP prediction and committed history."""
        inputs=part['inputs']
        if part['kind']=='bleeding':return BleedDose(inputs['basis_y'],inputs['start_ms'])
        if inputs.get('curve_kind')=='venom_live_resistance_v1':
            return self.world.venom_effects.curve(part['effect_id'],begin,end)
        if inputs.get('curve_kind')=='poison_live_resistance_v1':
            return self.world.poison_volumes.curve(part['effect_id'],begin,end)
        if inputs.get('curve_kind')=='affine_root_v1':
            return AffineHeatDose(*(inputs[k] for k in ('coefficient','q_reference','reference_ms','slope_per_second')))
        if inputs.get('curve_kind')=='fluid_body_v1':return self._thermal_curve(target,inputs['incident_id'])
        if inputs.get('curve_kind')=='fluid_controlled_v1':return self._thermal_curve(target,inputs['stream_id'])
        raise UnsupportedMechanicError('Applied HP history requires the actual continuous dose curve')

    def totals(self):
        if not self.enabled:return {}
        self.history.observe_until(self.world.time)
        return {name:{'applied_hp_dealt':self.history.amount(actor=name),
            'eligible_hp_dealt':self.history.amount(actor=name,eligible_only=True),
            'eligible_hp_dealt_last_10s':self.history.amount(actor=name,eligible_only=True,window_ms=10000),
            'hp_received':self.history.amount(target=name),'hp_received_last_8s':self.history.amount(target=name,window_ms=8000)}
            for name in sorted(self.world.fighters)}

    def result(self):
        if not self.enabled:return {}
        totals=self.totals()
        return {'damage_ledger_rules':self.world.combat_locomotion_input['damage_ledger'],
            'damage_credit_totals':totals,'applied_hp_history':self.history.record()}
