"""Released utility contacts that form autonomous, physical enclosures.

Formation follows the ordinary HP/death wave. A construct uses the existing
fixed world registry for damage, collision, cover, expiry and support changes;
it owns neither actor movement nor a fabricated binding/freeze.
"""
from copy import deepcopy
from itertools import count

from combat_sim.mechanics.enclosure import fit_enclosure
from combat_sim.models import UnsupportedMechanicError
from combat_sim.projectile_entities import ProjectileContactPolicy
from combat_sim.world_colliders import ColliderPolicy,finite

EVENT='contact_construct_hit'


class ContactConstructs:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        self.ids=count(1);self.hits={};self.by_projectile={}
        if self.enabled and (definition!={'mode':'contact_construct_v1'} or not world.gravity_mode or
                not world.body_paths.enabled or not world.effort_system.enabled or not world.life_cycles.enabled):
            raise UnsupportedMechanicError('Contact constructs require current gravity, saved paths, effort and actor lives')

    def validate(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id];cfg=a.get('contact_construct',{})
        if not self.enabled or not w.collider_system.enabled or not w.hand_reach.enabled:
            raise UnsupportedMechanicError('Contact constructs require mutable world colliders and solid hand reach')
        if (not isinstance(cfg,dict) or set(cfg)!={'shape','hp','duration_ms','minimum_inner_side_m',
                'wall_thickness_m','clearance_m'} or cfg['shape']!='hollow_cube'):
            raise UnsupportedMechanicError('Contact construct requires explicit hollow-cube dimensions and lifetime')
        for key in ('hp','duration_ms','minimum_inner_side_m','wall_thickness_m','clearance_m'):
            finite(cfg[key],key,positive=True)
        if finite(a['pre_mitigation_damage'],'Utility damage')!=0 or a.get('damage_type')!='contact':
            raise UnsupportedMechanicError('Contact constructs use a damage-free utility carrier')
        if ProjectileContactPolicy.from_definition(a['projectile_geometry'].get('contact_policy'))!=ProjectileContactPolicy():
            raise UnsupportedMechanicError('Contact constructs require first physical contact')
        timing=actor.profile['timing_profiles'][a['timing_profile']]
        if finite(timing.get('projectile_acceleration_mps2',0),'Projectile acceleration')!=0:
            raise UnsupportedMechanicError('Current contact constructs require ballistic gravity flight')

    def queue(self,packet):
        if not self.enabled or 'projectile_id' not in packet:return
        w=self.world;projectile=packet['projectile_id'];flight=w.projectile_flights[projectile]
        cfg=flight.get('contact_payload',{}).get('contact_construct')
        if cfg is None or projectile in self.by_projectile:return
        identity='contact-construct:'+str(next(self.ids))
        self.by_projectile[projectile]=identity
        self.hits[identity]={'id':identity,'projectile_id':projectile,'packet':deepcopy(packet),
            'definition':deepcopy(cfg),'status':'queued'}
        w.push(w.time,EVENT,{'hit_id':identity},priority=3)

    def event_live(self,payload):
        row=self.hits.get(payload['hit_id']);return row is not None and row['status']=='queued'

    def process(self,payload):
        if not self.event_live(payload):return
        w=self.world;row=self.hits[payload['hit_id']];p=row['packet'];cfg=row['definition']
        if not w.life_cycles.target_matches(p) or w.fighters[p['target']].hp<=0:
            row['status']='recipient_life_ended'
            w.log('contact_construct_resolved',**deepcopy(row));return
        plan=fit_enclosure({n:parts for n,parts in w.world_bodies.items() if w.fighters[n].hp>0},
            (p['target'],),groups=w.grapple_links.groups(),
            minimum_inner_side_m=cfg['minimum_inner_side_m'],wall_thickness_m=cfg['wall_thickness_m'],
            clearance_m=cfg['clearance_m'])
        collider=w.collider_system.spawn(plan.parts,source=row['id'],hp=cfg['hp'],
            expires_at_ms=w.time+finite(cfg['duration_ms'],'Construct lifetime',positive=True),
            policy=ColliderPolicy(projectiles=True,bodies=True,areas=True),owner=p['actor'],
            ability=p['ability'],action_id=p['action_id'],source_life_generation=p['source_life_generation'],
            tags=('prison','wall'))
        row.update(status='formed',at_ms=w.time,collider_id=collider,placement=plan.record(),autonomous=True)
        w.refresh_mobile_locomotion()
        w.log('contact_construct_resolved',**deepcopy(row))

    def result(self):
        return {'contact_construct_rules':self.world.combat_locomotion_input['contact_constructs'],
            'contact_construct_hits':deepcopy(list(self.hits.values()))} if self.enabled else {}
