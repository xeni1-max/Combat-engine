"""Life-bound distance constraints on the shared saved-body-path provider."""
from dataclasses import dataclass
from decimal import Context,Decimal as D,localcontext,ROUND_FLOOR
from fractions import Fraction as F
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import UnsupportedMechanicError,as_fraction
from combat_sim.angular_resting import contact_departure
from combat_sim.oriented_geometry import axes
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.mechanics.distance_path import build_distance_path
from combat_sim.mechanics.distance_projection import MaximumDistance,FixedDistance,sqrt_bound,dot
from combat_sim.mechanics.constraint_response import path_force_coefficients
from combat_sim.mechanics.unilateral_velocity import ContactLimit,TautDistance,project_unilateral
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality,number,vector
from combat_sim.mechanics.status import body_status_weight
from combat_sim.moving_projectiles import _roots,_evaluate
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M,CONTACT_SPEED_EPS_MPS,CONTACT_TIME_EPS_MS,CONTACT_ACCEL_EPS_MPS2
from combat_sim.mechanics.exact_ratio import ratio_text
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.box_motion import touching_normals


@dataclass(frozen=True)
class DistanceFrame:
    names: tuple
    path: object
    force_coefficients: tuple
    signature: tuple
    ground_requested: tuple = ()
    ground_coefficients: tuple = ()
    inertial_names: tuple = ()
    row_ids: tuple = ()


class PersistentDistances:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.rows={};self.ids=count(1)
        self.epoch=0;self.restricted=set();self.planned_steps=0
        self.resting=set();self.contact_epoch=None
        self.contact_lives=None
        self.responding=set();self.last_committed=None
        self.fixed_seen=False;self.exact_references={}
        self.fixed_reference_max_bits=0;self.fixed_reference_fallbacks=0
        self.end_handlers={}
        if self.enabled:
            if set(definition)!={'mode','maximum_step_ms','position_inset_m','maximum_relative_step_fraction'} or definition['mode']!='persistent_distance_v1':
                raise UnsupportedMechanicError('Unsupported persistent distance rules')
            self.step=number(definition['maximum_step_ms'],positive=True)
            self.inset=number(definition['position_inset_m'],positive=True)
            self.relative_step=number(definition['maximum_relative_step_fraction'],positive=True)
            if self.inset>=F(CONTACT_DISTANCE_EPS_M)/100 or self.step>100:
                raise ValueError('Distance reconciliation must be below contact resolution; step cannot exceed 100 ms')
            if self.relative_step>F(1,10):raise ValueError('Relative distance step must be at most one tenth of the limit')

    def active(self):
        w=self.world
        return tuple(r for _,r in sorted(self.rows.items()) if r['status']=='active' and r['expires_at_ms']>w.time and
            all(w.fighters[n].hp>0 and w.fighters[n].life_generation==g for n,g in r['lives']) and
            (not r.get('anchor_id') or w.terrain_anchors.live(r['anchor_id'])))

    def reference(self,name):
        w=self.world
        if name in w.terrain_anchors.points:return w.terrain_anchors.points[name].position_m
        current=vector(w.spatial_transitions.reference(name));saved=self.exact_references.get(name)
        if saved is not None:
            time,generation,p=saved
            if time==w.time and generation==w.fighters[name].life_generation and all(abs(a-b)<=F(CONTACT_DISTANCE_EPS_M)/100 for a,b in zip(current,p)):return p
        return current

    def endpoint_piece(self,name,pieces,begin,end):
        if name in pieces:return pieces[name]
        return BodyPathPiece(begin,end,self.reference(name),(0,0,0),(0,0,0))

    def edge(self,row,*,inset=False):
        length=as_fraction(row['maximum_m'])-(self.inset if inset else 0)
        if row.get('anchor_id'):return FixedDistance(row['first'],self.world.terrain_anchors.points[row['anchor_id']],length)
        return MaximumDistance(row['first'],row['second'],length)

    def reconcile_fixed_references(self,original,names):
        """Bound roundoff without moving fixed points or assigning them mass.

        Only sub-contact-resolution reference repair is permitted. Each trial
        starts on the owned Decimal grid and is checked against all touching
        distance rows. Exact committed references remain the final witness for
        degenerate sets which have no interior grid point.
        """
        w=self.world;selected=set(names)
        rows=tuple(r for r in self.active() if selected.intersection((r['first'],r['second'])))
        def point(n,values):return values[n] if n in values else self.reference(n)
        def legal(values):return all(sum((a-b)**2 for a,b in zip(point(r['first'],values),point(r['second'],values)))<=as_fraction(r['maximum_m'])**2 for r in rows)
        trial={n:vector(tuple(map(dec,p))) for n,p in original.items()}
        for _ in range(16):
            if legal(trial):return trial
            for r in rows:
                a,b=point(r['first'],trial),point(r['second'],trial);length=as_fraction(r['maximum_m'])
                if sum((x-y)**2 for x,y in zip(a,b))<=length*length:continue
                name=r['first'] if r['first'] in selected else r['second']
                other=r['second'] if name==r['first'] else r['first']
                p=trial[name];centre=point(other,trial);m=w.motion[name]
                axes=(0,1) if m['jump'] is None and m.get('support_id') is not None and not w._climbing(name) else (0,1,2)
                locked=sum((p[i]-centre[i])**2 for i in range(3) if i not in axes)
                available=length*length-locked
                if available<0:continue
                norm=sum((p[i]-centre[i])**2 for i in axes)
                if not norm:continue
                scale=sqrt_bound(available,w.precision,upper=False)/sqrt_bound(norm,w.precision,upper=True)
                scale*=1-self.inset/length
                trial[name]=tuple(centre[i]+scale*(p[i]-centre[i]) if i in axes else p[i] for i in range(3))
        if legal(original):
            self.fixed_reference_fallbacks+=1
            return original
        raise ValueError('Fixed distance state has no certified numerical reference')

    def signature(self):
        if not self.rows:return ()
        return (self.epoch,tuple(r['id'] for r in self.active()),
            tuple((r['id'],r['status']) for r in self.world.knock_motion.impulses.values() if r['status']=='active'))

    def attach(self,first,second,*,maximum_m,expires_at_ms,source,expected_lives):
        w=self.world
        if not self.enabled or not w.body_paths.ready or not w.airborne_enabled:
            raise UnsupportedMechanicError('Persistent distances need saved paths and shared body physics')
        with localcontext(Context(prec=w.precision)):
            edge=MaximumDistance(first,second,maximum_m);expires=dec(number(expires_at_ms,positive=True))
            if edge.maximum_m<=self.inset:raise ValueError('Distance must exceed its numerical inset')
            if not isinstance(source,str) or not source or expires<=w.time or not expires.is_finite():
                raise ValueError('A distance needs a source and future finite expiry')
            lives=tuple(sorted(dict(expected_lives).items()))
            if set(dict(lives))!={first,second}:raise ValueError('Distance endpoints need explicit lives')
            for n,g in lives:
                if n not in w.fighters or w.fighters[n].hp<=0 or type(g) is not int or w.fighters[n].life_generation!=g:
                    raise ValueError('Distance endpoint is not the expected living actor')
            refs={n:vector(w.spatial_transitions.reference(n)) for n in (first,second)}
            relative=tuple(b-a for a,b in zip(refs[first],refs[second]))
            if dot(relative,relative)>edge.maximum_m**2:raise ValueError('Distance begins outside its maximum length')
            identity='distance:'+str(next(self.ids))
            row={'id':identity,'first':first,'second':second,'maximum_m':dec(edge.maximum_m),'lives':lives,
                'source':source,'created_at_ms':w.time,'expires_at_ms':expires,'status':'active','response_active':False}
            self.rows[identity]=row;self.epoch+=1;w.body_paths.invalidate()
            w.push(expires,'distance_expired',{'distance_id':identity},priority=0)
            w.log('distance_attached',**row);w.refresh_mobile_locomotion()
            return identity

    def attach_fixed(self,actor,anchor,*,maximum_m,expires_at_ms,source,expected_life):
        w=self.world
        if not self.enabled or not w.body_paths.ready or not w.airborne_enabled:
            raise UnsupportedMechanicError('Fixed distances need saved paths and shared body physics')
        with localcontext(Context(prec=w.precision)):
            length=number(maximum_m,positive=True);expires=dec(number(expires_at_ms,positive=True))
            if length<=self.inset or expires<=w.time or not isinstance(source,str) or not source:raise ValueError('Invalid fixed distance lifetime/length/source')
            if actor not in w.fighters or type(expected_life) is not int or w.fighters[actor].hp<=0 or w.fighters[actor].life_generation!=expected_life:
                raise ValueError('Fixed distance needs its expected living actor')
            if not w.terrain_anchors.valid_candidate(anchor):raise ValueError('Fixed distance needs a current surface anchor')
            if sum((x-y)**2 for x,y in zip(self.reference(actor),anchor.position_m))>length*length:
                raise ValueError('Fixed distance begins outside its length')
            anchor_id=w.terrain_anchors.attach(anchor,source=source);identity='distance:'+str(next(self.ids))
            row={'id':identity,'first':actor,'second':anchor_id,'anchor_id':anchor_id,'maximum_m':dec(length),
                'lives':((actor,expected_life),),'source':source,'created_at_ms':w.time,'expires_at_ms':expires,
                'status':'active','response_active':False}
            self.rows[identity]=row;self.fixed_seen=True;self.epoch+=1
            w.terrain_anchors.rows[anchor_id]['distance_id']=identity
            w.body_paths.invalidate();w.push(expires,'distance_expired',{'distance_id':identity},priority=0)
            w.log('distance_attached',**row);w.refresh_mobile_locomotion()
            return identity

    def watch_end(self,identity,handler):
        """Notify a controlled continuation at the actual physical end clock."""
        if identity not in self.rows or self.rows[identity]['status']!='active' or not callable(handler):
            raise ValueError('Distance end observer requires a live distance and callable handler')
        self.end_handlers.setdefault(identity,[]).append(handler)

    def release(self,identity,*,reason='released'):
        row=self.rows.get(identity)
        if row is None or row['status']!='active':return False
        if identity in self.responding:
            self.responding.remove(identity);row['response_active']=False
            self.world.log('distance_response_ended',distance_id=identity,reason=reason)
        row.update(status='ended',ended_at_ms=self.world.time,end_reason=reason);self.epoch+=1
        self.world.body_paths.invalidate();self.world.log('distance_ended',distance_id=identity,reason=reason)
        if row.get('anchor_id'):self.world.terrain_anchors.end(row['anchor_id'],reason)
        if row.get('binding_id'):
            binding=self.world.bindings.bindings.get(row['binding_id'])
            if binding is not None:
                self.world.bindings.end(binding,'duration_expired' if reason=='expired' else reason)
        for handler in self.end_handlers.pop(identity,()):handler(identity,reason)
        return True

    def live(self,p):return p['distance_id'] in self.rows and self.rows[p['distance_id']]['status']=='active'

    def settle(self):
        if not self.enabled:return
        w=self.world
        w.terrain_anchors.settle()
        for identity,row in self.rows.items():
            if row['status']!='active':continue
            if any(w.fighters[n].hp<=0 or w.fighters[n].life_generation!=g for n,g in row['lives']):
                self.release(identity,reason='endpoint_life_ended')

    def external_changed(self,bodies):
        names={b.actor for b in bodies}
        self.resting={token for token in self.resting if not names.intersection(token[:2])}
        w=self.world
        for row in self.active():
            if not names.intersection((row['first'],row['second'])):continue
            relative=tuple(b-a for a,b in zip(self.reference(row['first']),self.reference(row['second'])))
            if sum(x*x for x in relative)>(row['maximum_m']+CONTACT_DISTANCE_EPS_M)**2:
                self.release(row['id'],reason='external_separation')

    def validate_transport(self,destinations):
        """Voluntary instantaneous transport cannot evade a live distance limit.

        Unlike an imposed external displacement, it is rejected before moving
        either endpoint. Actual grapple expansion belongs to the spatial plan;
        a distance tether alone does not make its other endpoint travel.
        """
        selected=set(destinations)
        for row in self.active():
            if not selected.intersection((row['first'],row['second'])):continue
            a=vector(destinations[row['first']]) if row['first'] in selected else self.reference(row['first'])
            b=vector(destinations[row['second']]) if row['second'] in selected else self.reference(row['second'])
            if sum((x-y)**2 for x,y in zip(a,b))>as_fraction(row['maximum_m'])**2:
                raise ValueError('Transport destination exceeds a live distance constraint: '+row['id'])

    def prepare(self):
        """Close newly transmitted force restrictions before advancing time."""
        self.settle()
        self.world.body_support.settle()
        if not self.active() and not self.world.body_support.active():return
        w=self.world
        for _ in range(3*len(w.fighters)+3):
            frame=w.body_paths.ensure(future=True);plan=frame.constraints
            names=plan.names if plan is not None else {r[k] for r in self.active() for k in ('first','second') if r[k] in w.fighters}
            normalized=False
            for name in names:
                m=w.motion[name];imposed=m.get('imposed_velocity')
                if imposed is not None and not any(imposed) and m['jump'] is None and not w.knock_motion.members(name):
                    m.pop('imposed_velocity',None);m.pop('distance_force_driven',None);normalized=True
            if normalized:w.body_paths.invalidate();continue
            if plan is None:return
            changed=False
            for identity,coefficients in plan.force_coefficients:
                row=w.knock_motion.impulses[identity]
                for name,(v,a) in coefficients:
                    key=(identity,name,w.fighters[name].life_generation)
                    if key in self.restricted or not any(abs(x)>F(CONTACT_SPEED_EPS_MPS) for x in v+a):continue
                    self.restricted.add(key)
                    if name not in row['components']:
                        w.knock_motion._restrict(name,row);w.motion[name]['distance_force_driven']=True;changed=True
            if not changed:return
            w.body_paths.invalidate()
        raise RuntimeError('Distance force admission failed to close')

    @staticmethod
    def polynomial(a,b,length):
        r=tuple(y-x for x,y in zip(a.reference_m,b.reference_m))
        v=tuple(y-x for x,y in zip(a.velocity_mps,b.velocity_mps))
        q=tuple((y-x)/2 for x,y in zip(a.acceleration_mps2,b.acceleration_mps2))
        return (dot(r,r)-length*length,2*dot(r,v),dot(v,v)+2*dot(r,q),2*dot(v,q),dot(q,q))

    def first_outward(self,poly,seconds):
        roots=_roots(poly,F(0),seconds);tolerance=F(1,10**32)
        for root in roots:
            while root.high-root.low>tolerance:root.refine()
        roots.sort(key=lambda r:r.low)
        for i,root in enumerate(roots):
            if root.high==0:continue
            after=(root.high+(roots[i+1].low if i+1<len(roots) else seconds))/2
            if after>root.high and _evaluate(poly,after)>0:return root.low
        return None

    @staticmethod
    def needs_tension(poly,length):
        near=poly[0]+length*length>=(length-F(CONTACT_DISTANCE_EPS_M))**2
        radial=poly[1] if abs(poly[1])>2*length*F(CONTACT_SPEED_EPS_MPS) else F(0)
        outward=next((x for x in (radial,*poly[2:]) if x),F(0))>0
        return near and outward,near

    def contact_resolved(self,contacts):
        if not self.active() and not self.world.body_support.ready:return
        w=self.world
        self.sync_contact_cache()
        for c in contacts:
            for normal in c['normals']:
                a,b=c['first'],c['second']
                n=tuple(-F(x) for x in normal)
                if b in w.fighters and b<a:a,b=b,a;n=tuple(-x for x in n)
                self.resting.add((a,b,n))
        w.body_paths.invalidate()
        w.refresh_mobile_locomotion()

    def sync_contact_cache(self):
        w=self.world
        lives=tuple((n,a.life_generation,a.hp>0) for n,a in sorted(w.fighters.items()))
        if self.contact_epoch!=w.collider_system.registry.epoch or self.contact_lives!=lives:
            self.resting.clear();self.contact_epoch=w.collider_system.registry.epoch
            self.contact_lives=lives

    def contacts(self,names):
        w=self.world;result=set();eps=F(CONTACT_DISTANCE_EPS_M)
        self.sync_contact_cache()
        touching=set()
        terrain=w.body_terrain_colliders()
        for name in names:
            for box in w.world_bodies[name]:
                lo,hi=box.bounds
                for key,colliders in terrain.items():
                    for other in colliders:
                        if isinstance(box,OrientedCuboid) or isinstance(other,OrientedCuboid):
                            for outward in touching_normals(box,other,distance_epsilon=eps,vertical_area=True):
                                normal=tuple(-F(dec(v)) for v in outward);token=(name,key,normal);touching.add(token)
                                grounded_top=(normal[2]<0 and w.motion[name]['jump'] is None and w.motion[name].get('support_id')==key)
                                suspended=not normal[2] and w.turns.suspends_reference_plane(name)
                                if (token in self.resting or grounded_top) and not suspended:result.add(ContactLimit(name,normal))
                            continue
                        a,b=other.bounds
                        for axis in range(3):
                            if not all(min(hi[i],b[i])-max(lo[i],a[i])>=-eps for i in range(3) if i!=axis):continue
                            if axis==2 and w.terrain_support.enabled and any(min(hi[i],b[i])-max(lo[i],a[i])<=eps for i in (0,1)):continue
                            for sign,gap in ((1,a[axis]-hi[axis]),(-1,lo[axis]-b[axis])):
                                if abs(gap)<=eps:
                                    normal=tuple(F(sign if i==axis else 0) for i in range(3));token=(name,key,normal);touching.add(token)
                                    grounded_top=(axis==2 and sign==-1 and w.motion[name]['jump'] is None and
                                        w.motion[name].get('support_id')==key)
                                    if token in self.resting or grounded_top:result.add(ContactLimit(name,normal))
        for first in sorted(n for n in w.fighters if w.fighters[n].hp>0):
            for second in sorted(n for n in w.fighters if n>first and w.fighters[n].hp>0):
                if first not in names and second not in names:continue
                for box in w.world_bodies[first]:
                    lo,hi=box.bounds
                    for other in w.world_bodies[second]:
                        if isinstance(box,OrientedCuboid) or isinstance(other,OrientedCuboid):
                            for outward in touching_normals(box,other,distance_epsilon=eps,vertical_area=True):
                                if outward[2] and w.body_support.ready:continue
                                normal=tuple(-F(dec(v)) for v in outward);token=(first,second,normal);touching.add(token)
                                suspended=not normal[2] and any(w.turns.suspends_reference_plane(n) for n in (first,second))
                                if token in self.resting and not suspended:result.add(ContactLimit(first,normal,second))
                            continue
                        a,b=other.bounds
                        for axis in range(3):
                            # Current vertical body contacts have part/life and
                            # pose/departure ownership in BodySupport. A cached
                            # reference-only plane must not keep a withdrawing
                            # head supporting an upper body through a tether.
                            if axis==2 and w.body_support.ready:continue
                            if not all(min(hi[i],b[i])-max(lo[i],a[i])>=-eps for i in range(3) if i!=axis):continue
                            for sign,gap in ((1,a[axis]-hi[axis]),(-1,lo[axis]-b[axis])):
                                if abs(gap)<=eps:
                                    normal=tuple(F(sign if i==axis else 0) for i in range(3));token=(first,second,normal);touching.add(token)
                                    if token in self.resting:result.add(ContactLimit(first,normal,second))
        self.resting.difference_update(token for token in tuple(self.resting)
            if (token[0] in names or token[1] in names) and token not in touching)
        return tuple(sorted(result,key=lambda c:(c.actor,c.other or '',c.toward_obstacle)))

    def angular_contact_departure(self,pieces,end):
        """Clip even slack leases when a rotating cached contact actually ends."""
        w=self.world
        if not w.turns.any_active() or not self.resting:return end
        self.sync_contact_cache();now=F(w.time);limit=F(end);by_name=dict(pieces)
        terrain=w.body_terrain_colliders()
        for token in tuple(sorted(self.resting)):
            a,b,normal=token
            if not w.turns.active(a) and (b not in w.fighters or not w.turns.active(b)):continue
            outward=tuple(-v for v in normal);pairs=[]
            right=w.world_bodies[b] if b in w.fighters else terrain.get(b,())
            for first in w.world_bodies[a]:
                for second in right:
                    candidates=touching_normals(first,second,distance_epsilon=F(CONTACT_DISTANCE_EPS_M),vertical_area=True)
                    for exact in candidates:
                        if tuple(F(dec(x)) for x in exact)!=outward:continue
                        fixed=(exact[2] or any(tuple(F(dec(v)) for v in axis) in (outward,normal)
                            for name,box in ((a,first),(b,second)) if name not in w.fighters or not w.turns.active(name)
                            for axis in axes(box)))
                        if fixed:pairs.append((first,second,exact))
            if not pairs:
                self.resting.discard(token);continue
            for first,second,exact in pairs:
                pa=w.turns.path_from_piece(a,first,by_name[a].slice(now,limit))
                pb=w.turns.path_from_piece(b,second,by_name[b].slice(now,limit)) if b in w.fighters else second
                loss=contact_departure(pa,pb,exact,now/1000,limit/1000,
                    distance_epsilon=CONTACT_DISTANCE_EPS_M,precision=w.precision)
                if loss is not None:limit=min(limit,loss*1000)
        return limit

    def participants(self,rows):
        w=self.world;names={r[k] for r in rows for k in ('first','second') if r[k] in w.fighters}
        names.update(w.body_support.names())
        changed=True
        while changed:
            before=set(names)
            for n in tuple(names):names.update(w.grapple_links.group(n))
            contacts=tuple(sorted(set(self.contacts(names))|set(w.body_support.planes()),
                key=lambda c:(c.actor,c.other or '',c.toward_obstacle)))
            names.update(c.actor for c in contacts)
            names.update(c.other for c in contacts if c.other is not None)
            changed=names!=before
        return tuple(sorted(names)),contacts

    def limit_step(self,end,now,rows,drivers):
        w=self.world;end=min(end,now+self.step)
        if end>now:
            for row in rows:
                a=drivers[row['first']];b=drivers.get(row['second'])
                velocity=b.free_velocity if b is not None else (0,0,0)
                change=b.free_acceleration if b is not None else (0,0,0)
                speed=sqrt_bound(sum((y-x)**2 for x,y in zip(a.free_velocity,velocity)),w.precision,upper=True)
                acceleration=sqrt_bound(sum((y-x)**2 for x,y in zip(a.free_acceleration,change)),w.precision,upper=True)
                travel=self.relative_step*as_fraction(row['maximum_m'])
                if acceleration:h=2*travel/(speed+sqrt_bound(speed*speed+2*acceleration*travel,w.precision,upper=True))
                elif speed:h=travel/speed
                else:continue
                end=min(end,now+1000*h)
        return end

    def compile(self,pieces,drivers,end):
        rows=self.active()
        if not rows and not self.world.body_support.active():return tuple(pieces),end,None
        w=self.world;now=as_fraction(w.time);by_name=dict(pieces);driver_map=dict(drivers)
        duration=(end-now)/1000;taut_rows=[];crossing=end
        for row in rows:
            a=by_name[row['first']];b=self.endpoint_piece(row['second'],by_name,now,end);length=as_fraction(row['maximum_m'])
            if row.get('anchor_id'):a=BodyPathPiece(now,end,self.reference(row['first']),a.velocity_mps,a.acceleration_mps2)
            poly=self.polynomial(a,b,length);tension,near=self.needs_tension(poly,length)
            if tension:taut_rows.append(row)
            elif duration>0:
                root=self.first_outward(poly,duration)
                if root is not None:
                    if near and root*1000<=F(CONTACT_TIME_EPS_MS):taut_rows.append(row)
                    else:crossing=min(crossing,now+root*1000)
        def clock(value):
            with localcontext(Context(prec=w.precision,rounding=ROUND_FLOOR)):
                return F(D(value.numerator)/D(value.denominator))
        if not taut_rows and not w.body_support.active():
            crossing=clock(crossing)
            if crossing<end:
                pieces=tuple((n,p.slice(now,crossing)) for n,p in pieces);end=crossing
            return tuple(pieces),end,None
        end=clock(self.limit_step(end,now,taut_rows,driver_map))
        if end<=now:
            # A queued phase at this instant gets an instantaneous snapshot.
            # Positive-time planning follows the phase closure.
            names,contacts=self.participants(taut_rows)
            nodes=tuple(VelocityNode(n,driver_map[n].free_velocity,w.fighters[n].profile['max_hp'],w.fighters[n].armor) for n in names)
            limits=[];contacts=list(contacts)
            for r in taut_rows:
                radial=tuple(b-a for a,b in zip(by_name[r['first']].reference_m,self.endpoint_piece(r['second'],by_name,now,end).reference_m))
                if sum(x*x for x in radial)<(as_fraction(r['maximum_m'])-F(CONTACT_DISTANCE_EPS_M))**2:continue
                if r.get('anchor_id'):contacts.append(ContactLimit(r['first'],tuple(-x for x in radial)))
                else:limits.append(TautDistance(r['first'],r['second'],radial))
            equalities=tuple(VelocityEquality(g[0],n) for g in w.grapple_links.groups() if g[0] in names for n in g[1:])
            projection=project_unilateral(nodes,limits,contacts,equalities,precision=w.precision)
            velocities=dict(projection.exact_velocities)
            snapshot=tuple((n,BodyPathPiece(now,now,p.reference_m,velocities.get(n,p.velocity_mps),(0,0,0))) for n,p in pieces)
            return snapshot,end,DistanceFrame(names,None,(),self.signature())
        # Only taut rows apply force. A slack neighbour's first crossing must
        # be located on the already constrained candidate, not its raw path.
        for _ in range(len(rows)+32):
            names,contacts=self.participants(taut_rows)
            end=clock(self.limit_step(end,now,taut_rows,driver_map))
            fixed=any(r.get('anchor_id') for r in taut_rows)
            original_refs={n:self.reference(n) if fixed else vector(w.spatial_transitions.reference(n)) for n in names}
            weights={n:F(body_status_weight(w.fighters[n].profile['max_hp'],w.fighters[n].armor)) for n in names}
            centre=tuple(sum((weights[n]*original_refs[n][i] for n in names),F(0))/sum(weights.values()) for i in range(3))
            equalities=tuple(VelocityEquality(g[0],n) for g in w.grapple_links.groups() if g[0] in names for n in g[1:])
            nodes=tuple(VelocityNode(n,driver_map[n].free_velocity,w.fighters[n].profile['max_hp'],w.fighters[n].armor) for n in names)
            accelerations={n:driver_map[n].free_acceleration for n in names}
            # Independent grounded drivers already cancel gravity. Joint
            # constraints must instead see gravity once and solve its contact
            # reaction, or arbitrarily weak upward pressure levitates a body.
            for n in names:
                m=w.motion[n]
                if m['jump'] is None and m.get('support_id') is not None and not w._climbing(n):
                    accelerations[n]=(*accelerations[n][:2],-F(w.jump_gravity))
            edges=tuple(self.edge(r,inset=not fixed) for r in taut_rows)
            scale=F(1)
            for edge in edges:
                if fixed:break
                r=tuple(b-a for a,b in zip(original_refs[edge.first],original_refs[edge.second]))
                distance=sqrt_bound(dot(r,r),w.precision,upper=True)
                if distance:scale=min(scale,edge.maximum_m/distance)
            refs=(self.reconcile_fixed_references(original_refs,names) if fixed else
                {n:tuple(c+scale*(x-c) for c,x in zip(centre,original_refs[n])) for n in names})
            if any(abs(x-y)>F(CONTACT_DISTANCE_EPS_M)/100 for n in names for x,y in zip(original_refs[n],refs[n])):
                raise ValueError('Distance state needs more than numerical reconciliation')
            if fixed:self.fixed_reference_max_bits=max(self.fixed_reference_max_bits,max((max(x.numerator.bit_length(),x.denominator.bit_length()) for p in refs.values() for x in p),default=0))
            path=build_distance_path(nodes,refs,now,end,edges,contacts,equalities,accelerations=accelerations,precision=w.precision)
            candidate={n:p.slice(now,end) for n,p in pieces};candidate.update(path.pieces)
            departure=w.body_support.departure(tuple(candidate.items()),end)
            if departure<end-F(CONTACT_TIME_EPS_MS):end=clock(departure);continue
            selected={r['id'] for r in taut_rows};promoted=[];crossing=end
            # A resolved contact remains a resting constraint only until an
            # actual candidate departs. This preserves the next impact's own
            # pre-contact velocity if it leaves and returns within one lease.
            for contact in contacts:
                first=candidate[contact.actor];second=candidate.get(contact.other)
                v=tuple(x-(y if second else 0) for x,y in zip(first.velocity_mps,second.velocity_mps if second else (0,0,0)))
                a=tuple(x-(y if second else 0) for x,y in zip(first.acceleration_mps2,second.acceleration_mps2 if second else (0,0,0)))
                rate=dot(v,contact.toward_obstacle);change=dot(a,contact.toward_obstacle)
                if rate < -F(CONTACT_SPEED_EPS_MPS) or abs(rate)<=F(CONTACT_SPEED_EPS_MPS) and change < -F(CONTACT_ACCEL_EPS_MPS2):
                    self.resting={t for t in self.resting if not (t[0]==contact.actor and t[2]==contact.toward_obstacle and
                        (t[1]==contact.other if contact.other else t[1] not in w.fighters))}
            for row in rows:
                if row['id'] in selected:continue
                length=as_fraction(row['maximum_m'])
                poly=self.polynomial(candidate[row['first']],self.endpoint_piece(row['second'],candidate,now,end),length)
                tension,near=self.needs_tension(poly,length)
                root=None if tension else self.first_outward(poly,(end-now)/1000)
                if tension or near and root is not None and root*1000<=F(CONTACT_TIME_EPS_MS):promoted.append(row)
                elif root is not None:crossing=min(crossing,now+root*1000)
            if promoted:taut_rows.extend(promoted);continue
            if crossing<end-F(CONTACT_TIME_EPS_MS):end=clock(crossing);continue
            break
        else:raise ArithmeticError('Coupled slack activation failed to close')
        coefficients=[]
        for identity,row in sorted(w.knock_motion.impulses.items()):
            if row['status']!='active':continue
            field={n:c['velocity_mps'] for n,c in row['components'].items() if n in names and
                c['life_generation']==w.fighters[n].life_generation}
            if field:coefficients.append((identity,tuple(path_force_coefficients(path,field).items())))
        replacement=dict(path.pieces);self.planned_steps+=1
        ground={n:tuple(v-i for v,i in zip(driver_map[n].free_velocity,
            vector(w.motion[n].get('distance_inertial_velocity',(0,0,0))))) for n in names
            if w.motion[n]['jump'] is None and w.motion[n].get('imposed_velocity') is None}
        inertial={n for n in names if w.motion[n]['jump'] is not None or w.motion[n].get('imposed_velocity') is not None or
            any(w.motion[n].get('distance_inertial_velocity',(0,0,0)))}
        changed=True
        connections=[(e.first,e.second) for e in edges if not isinstance(e,FixedDistance)]+[(e.first,e.second) for e in equalities]+[(c.actor,c.other) for c in contacts if c.other]
        while changed:
            before=set(inertial)
            for a,b in connections:
                if a in inertial or b in inertial:inertial.update((a,b))
            changed=inertial!=before
        ground_response=tuple(path_force_coefficients(path,ground).items()) if inertial else ()
        result=tuple((n,replacement.get(n,p.slice(now,end))) for n,p in pieces)
        return result,end,DistanceFrame(names,path,tuple(coefficients),self.signature(),tuple(ground.items()),ground_response,
            tuple(sorted(inertial)),tuple(sorted(r['id'] for r in taut_rows)))

    def commit(self,frame,end):
        if end<=self.world.time:return
        if self.fixed_seen:
            self.exact_references={n:(as_fraction(end),self.world.fighters[n].life_generation,p.position(end)) for n,p in frame.pieces}
        plan=frame.constraints
        responding=set(plan.row_ids if plan is not None else ())
        for identity in sorted(self.responding-responding):
            self.rows[identity]['response_active']=False
            self.world.log('distance_response_ended',distance_id=identity,reason='free_motion_permitted')
        for identity in sorted(responding-self.responding):
            self.rows[identity]['response_active']=True
            self.world.log('distance_response_started',distance_id=identity,solver_actors=plan.names)
        self.responding=responding
        if plan is None:return
        if plan.path is not None:self.last_committed=(plan,as_fraction(end),tuple((n,self.world.fighters[n].life_generation) for n in plan.names))
        w=self.world;pieces=dict(frame.pieces);seconds=(as_fraction(end)-frame.begin_ms)/1000
        requested=dict(plan.ground_requested)
        for identity,coefficients in plan.force_coefficients:
            row=w.knock_motion.impulses.get(identity)
            if row is None or row['status']!='active':continue
            for name,(v,a) in coefficients:
                velocity=tuple(dec(x+y*seconds) for x,y in zip(v,a))
                if name in row['components'] or any(abs(x)>CONTACT_SPEED_EPS_MPS for x in velocity):
                    row['components'][name]={'life_generation':w.fighters[name].life_generation,'velocity_mps':velocity}
        for name in plan.names:
            m=w.motion[name];velocity=tuple(map(dec,pieces[name].velocity(end)))
            if self.climb_compatible(name,pieces[name]) and m['jump'] is None:continue
            flight=m['jump'];saved=dict(frame.drivers)[name]
            expected=tuple(dec(v+a*seconds) for v,a in zip(saved.free_velocity,saved.free_acceleration))
            redirected=flight is not None and any(abs(x-y)>CONTACT_SPEED_EPS_MPS for x,y in zip(velocity,expected))
            if redirected and 'ground_drive_velocity' in flight:
                flight.pop('ground_drive_velocity')
                w.log('distance_ground_drive_retired',actor=name,reason='flight_redirected',motion_cause=flight.get('motion_cause'))
            preserve_ground=flight is not None and 'ground_drive_velocity' in flight
            if (m.get('imposed_velocity') is not None or m.get('distance_force_driven') or redirected) and not preserve_ground:
                m['imposed_velocity']=(*velocity[:2],D(0))
                m.pop('distance_inertial_velocity',None)
            support=w.collider_system.find_support(w.fighters[name])
            if m['jump'] is None and m.get('support_id') in w.fighters and support is None:
                # The common support-loss transaction owns the conversion to
                # flight, its inherited velocity and cancellation/receipts.
                # Do not silently manufacture a flight driver during commit.
                continue
            if m['jump'] is not None or velocity[2]>CONTACT_SPEED_EPS_MPS or support is None:
                if m['jump'] is None:m['imposed_velocity']=(*velocity[:2],D(0))
                m['jump']={**(m['jump'] or {'basic_jump':False}),'velocity':velocity}
                m.update(support_id=None,support_part=None)
                m.pop('distance_inertial_velocity',None)
            elif m.get('imposed_velocity') is None and name in plan.inertial_names:
                # The next free driver adds its own ground request again.
                # Store the residual against that request, not its projected
                # share: subtracting the share adds motor velocity on every
                # new constraint lease and can pump unbounded kinetic energy.
                v=requested[name];a=saved.free_acceleration
                residual=tuple(physical-dec(x+y*seconds) for physical,x,y in zip(velocity,v,a))
                m['distance_inertial_velocity']=tuple(D(0) if abs(x)<D('1e-28') else x for x in residual[:2])+(D(0),)

    def climb_compatible(self,name,piece):
        w=self.world
        if not w._climbing(name):return False
        for t in (piece.begin_ms,(piece.begin_ms+piece.end_ms)/2,piece.end_ms):
            expected=vector(w._climb_state(name,dec(t)).position_m)
            if any(abs(a-b)>F(CONTACT_DISTANCE_EPS_M) for a,b in zip(piece.position(t),expected)):return False
        return True

    def result(self):
        if not self.rows:return {}
        last=None
        if self.last_committed is not None:
            plan,end,lives=self.last_committed
            last={'distance_ids':plan.row_ids,'lives':dict(lives),'committed_until_ms':ratio_text(end),
                'pieces':{n:p.record() for n,p in plan.path.pieces},
                'bernstein_certificate':tuple({'first':a,'second':b,'maximum_m':ratio_text(length),
                    'distance_squared_minus_limit_squared':tuple(map(ratio_text,coefficients))}
                    for a,b,length,coefficients in plan.path.bernstein_certificate)}
            if plan.path.fixed_points:last['fixed_points']={n:tuple(map(ratio_text,p)) for n,p in plan.path.fixed_points}
        extra=({'fixed_reference_maximum_bits':self.fixed_reference_max_bits,'fixed_reference_exact_fallbacks':self.fixed_reference_fallbacks} if self.fixed_seen else {})
        return {**extra,'distance_constraints':list(self.rows.values()),'distance_path_steps_planned':self.planned_steps,
            'last_committed_distance_plan':last,'distance_geometry_tolerance_m':str(CONTACT_DISTANCE_EPS_M)}
