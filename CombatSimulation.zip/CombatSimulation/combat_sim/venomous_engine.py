"""Controlled base venomous thrust with exact full-phase continuous damage.

One unshielded, nonlethal target and one attachment are supported. This does
not infer overlapping effects, shielding of toxin, interrupts, or availability.
"""

from fractions import Fraction
from typing import Any

from combat_sim.actions import ScriptedActionSequence
from combat_sim.encounters import initial_states
from combat_sim.events import EventLog
from combat_sim.mechanics import slash, venom
from combat_sim.mechanics.status import decay_status
from combat_sim.mechanics.timing import impact_time_from_activation
from combat_sim.models import UnsupportedMechanicError, as_fraction, fraction_record
from combat_sim.state_updates import _state_snapshot, _validate_shield_state
from combat_sim.status_events import _advance_statuses, _apply_effects


def _ms(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a nonnegative integer millisecond")
    return value


def _changes(target, before, state):
    return {
        "target": target, "hp_before": fraction_record(before[0]), "hp_after_impact": fraction_record(state.hp),
        "armor_before": fraction_record(before[1]), "armor_after_impact": fraction_record(state.armor),
        "shield_before": fraction_record(before[2]), "shield_after_impact": fraction_record(state.shield),
    }


def run_venomous_scenario(scenario: dict[str, Any], profiles: dict[str, Any]) -> dict[str, Any]:
    allowed = {"id", "description", "encounter", "action_sequence", "run_until_ms"}
    if set(scenario) - allowed:
        raise UnsupportedMechanicError("Unsupported venomous scenario fields")
    encounter = scenario.get("encounter", {})
    if set(encounter) - {"initial_states", "movement"}:
        raise UnsupportedMechanicError("Controlled venomous encounter supports initial_states and movement only")
    if encounter.get("movement") != "stationary":
        raise UnsupportedMechanicError("Controlled venomous thrust requires movement='stationary'")
    inputs = ScriptedActionSequence(scenario.get("action_sequence", [])).inputs()
    if len(inputs) != 1:
        raise UnsupportedMechanicError("Controlled venomous thrust requires one activation")
    action = inputs[0]
    fields = {"kind", "action_start_ms", "actor", "target", "ability", "hit_confirmed"}
    if set(action) - fields:
        raise UnsupportedMechanicError("Unsupported venomous action fields: " + ", ".join(sorted(set(action) - fields)))
    if action.get("kind") != "activation" or action.get("hit_confirmed") is not True:
        raise UnsupportedMechanicError("A scenario-confirmed activation hit is required")
    actor, target, ability_id = (action.get(key) for key in ("actor", "target", "ability"))
    states = initial_states(encounter, track_statuses=True)
    if actor == target or set(states) != {actor, target}:
        raise UnsupportedMechanicError("This model requires one distinct actor and target")
    for name, state in states.items():
        profile = profiles.get(name, {})
        if any(key not in profile for key in ("max_hp", "shield_capacity", "status_resistance")) or "toxin" not in profile.get("resistances", {}):
            raise UnsupportedMechanicError(f"{name} requires complete defender data including toxin resistance")
        if min(as_fraction(profile["max_hp"]), as_fraction(profile["status_resistance"]), as_fraction(profile["resistances"]["toxin"])) < 0:
            raise ValueError("Maximum HP and resistances must be nonnegative")
        _validate_shield_state(state, as_fraction(profile["shield_capacity"]), name)
    if states[target].shield != 0:
        raise UnsupportedMechanicError("This stage requires target shield=0; fully absorbed delivery is defined as zero, but other shielded bleed/continuous interactions are not implemented")
    if states[actor].statuses.instability != 0:
        raise UnsupportedMechanicError("This first intrinsic-attack model requires zero initial actor instability")
    ability = profiles[actor]["abilities"][ability_id]
    if ability.get("damage_type") != "venomous" or ability.get("direct_damage_type") != "slash" or ability.get("damage_payment") != "continuous":
        raise UnsupportedMechanicError("Only the confirmed continuous venomous/slash model is supported")
    if ability.get("venom_armor_snapshot") != "before_thrust_armor_loss" or ability.get("target_status_armor_snapshot") != "before_thrust_armor_loss" or ability.get("venom_damage_input") != "slash_damage_after_shield_before_armor":
        raise UnsupportedMechanicError("This model requires pre-hit armor snapshots and post-shield/pre-armor venom d")
    start = _ms(action.get("action_start_ms"), "action_start_ms")
    current_o = decay_status(states[actor].statuses.disorientation, start)
    profile = profiles[actor]["timing_profiles"][ability["timing_profile"]]
    if profile.get("impact_timing") != "middle_of_active" or ability["self_effects"].get("application_timing") != "impact":
        raise UnsupportedMechanicError("This model requires midpoint hit and on-impact self effects")
    impact_time, timing = impact_time_from_activation(start, profile, disorientation_at_gathering_start=current_o)
    duration_ms = _ms(ability["poison_exposure_ms"], "poison_exposure_ms")
    bleed_duration_ms = int(slash.BLEED_DURATION_SECONDS * 1000)
    if duration_ms == 0 or 2 * duration_ms > bleed_duration_ms:
        raise UnsupportedMechanicError("This controlled model requires positive exposure with its recovery completed before the single eight-second bleed ends")
    exposure_seconds = Fraction(duration_ms, 1000)
    detached = impact_time + duration_ms
    toxin_end = detached + duration_ms
    bleed_end = impact_time + bleed_duration_ms
    until = _ms(scenario.get("run_until_ms", bleed_end), "run_until_ms")
    if until < bleed_end:
        raise ValueError("run_until_ms must include all eight seconds of the bleed")
    state = states[target]
    initial = _state_snapshot(states)
    calculation = slash.calculate_impact(ability["pre_mitigation_damage"], state.armor, ability["piercing"], state.shield)
    if calculation.damage_left_after_shield <= 0:
        raise UnsupportedMechanicError("Zero slash delivery causes no toxin damage; this controller currently executes positive-delivery unshielded thrusts only")
    venom_args = (calculation.damage_left_after_shield, calculation.pre_hit_armor,
                  ability["piercing"], ability["toxicity"], profiles[target]["resistances"]["toxin"])
    phase_expression = venom.venomous_full_phase_damage(*venom_args, exposure_seconds)
    phase_damage = phase_expression.as_fraction()
    if phase_damage is None:
        raise UnsupportedMechanicError("This exact-HP controller currently requires rational full-phase integrals; the formula helper preserves irrational results symbolically")
    bleed_total = slash.bleeding_damage_between(calculation.hp_damage, 0, slash.BLEED_DURATION_SECONDS)
    if state.hp <= calculation.hp_damage + bleed_total + 2 * phase_damage:
        raise UnsupportedMechanicError("This first continuous-damage model requires a nonlethal target; death inside a continuous interval is not specified")
    peak_rate = venom.venomous_damage_rate(*venom_args, exposure_seconds, 0)
    snapshot = {
        "d_after_shield_before_armor": str(calculation.damage_left_after_shield),
        "a_before_thrust": str(calculation.pre_hit_armor), "p": str(ability["piercing"]),
        "Tp": str(ability["toxicity"]), "RT": str(profiles[target]["resistances"]["toxin"]),
    }
    queue = [(start, 0, "ability_started"), (impact_time, 1, "impact"),
             (timing["active_end_ms"], 2, "active_completed"),
             (detached, 3, "blade_detached"), (toxin_end, 4, "venom_expired"),
             (bleed_end, 5, "bleeding_expired")]
    log, current, last_damage_time = EventLog(), 0, impact_time
    for time, _, event in sorted(queue):
        _advance_statuses(states, current, time, log)
        current = time
        common = {"time_ms": time, "actor": actor, "ability": ability_id}
        if event == "ability_started":
            log.record({**common, "type": event, "timing_calculation": timing,
                        "availability": "Activation supplied by scenario; eligibility, costs, and passives not executed"})
        elif event == "impact":
            before = (state.hp, state.armor, state.shield)
            state.hp -= calculation.hp_damage
            state.armor = max(Fraction(0), state.armor - calculation.armor_loss)
            armor_lost = before[1] - state.armor
            log.record({
                **common, "type": "impact_resolved", "target": target, "origin": "venomous_thrust",
                "hit_confirmation": "supplied_by_scenario", "timing_calculation": timing,
                "damage_calculation": {
                    "damage_type": "slash", "damage_category": "intrinsic_momentary",
                    "incoming_damage": fraction_record(as_fraction(ability["pre_mitigation_damage"])),
                    "instability_before_new_self_effect": "0",
                    "shield_handling": {"shield_damage_is_unmitigated": True, "shield_before": fraction_record(before[2]),
                                        "damage_to_shield": fraction_record(calculation.shield_damage), "shield_after_impact": fraction_record(state.shield),
                                        "damage_left_after_shield": fraction_record(calculation.damage_left_after_shield)},
                    "formulas": {"post_mitigation_damage": slash.FORMULA, "armor_reduction": slash.ARMOR_REDUCTION_FORMULA},
                    "formula_inputs": {"d_left_after_shield": str(calculation.damage_left_after_shield), "a_pre_impact": str(calculation.pre_hit_armor), "p": str(ability["piercing"])},
                    "outputs": {"y": {**fraction_record(calculation.hp_damage), "formula_source": slash.SOURCE}, "Ar": {**fraction_record(calculation.armor_loss), "formula_source": slash.ARMOR_SOURCE}},
                    "applied_state_losses": {"hp": fraction_record(calculation.hp_damage), "armor": fraction_record(armor_lost)},
                    "excess_formula_outputs": {"hp": fraction_record(Fraction(0)), "armor": fraction_record(calculation.armor_loss - armor_lost)},
                    "raw_formula_outputs_before_zero_clamp": {"y": fraction_record(calculation.raw_hp_damage), "Ar": fraction_record(calculation.raw_armor_loss)},
                    "state_mapping_status": "confirmed_by_user",
                    "state_mapping": "Calculate HP damage with pre-hit armor and before new self instability; then reduce armor; target statuses and venom delivery retain pre-hit armor",
                },
                "state_changes": _changes(target, before, state), "sources": {"ability": ability["source"], "damage_rule": slash.SOURCE},
            })
            _apply_effects(target, state, profiles[target], ability["target_effects"], time, "thrust_target", log, armor_snapshot=calculation.pre_hit_armor)
            _apply_effects(actor, states[actor], profiles[actor], ability["self_effects"], time, "self", log)
            log.record({**common, "type": "blade_attached", "target": target, "detaches_at_ms": detached,
                        "venom_ends_at_ms": toxin_end, "bleed_ends_at_ms": bleed_end,
                        "venom_delivery_snapshot": snapshot, "bleed_basis_y": fraction_record(calculation.hp_damage),
                        "initial_bleeding_dps": fraction_record(slash.bleeding_damage_rate(calculation.hp_damage, 0)),
                        "initial_venom_dps": "0", "source": ability["source"]})
        elif event == "active_completed":
            # Only actor state is sampled here. Target HP is evaluated lazily
            # at continuous-effect boundaries; no HP-dependent events intervene.
            log.record({**common, "type": event, "actor_state": states[actor].to_record()})
        else:
            begin = last_damage_time
            tb0, tb1 = Fraction(begin - impact_time, 1000), Fraction(time - impact_time, 1000)
            bleeding = slash.bleeding_damage_between(calculation.hp_damage, tb0, tb1)
            toxin = phase_damage if event in {"blade_detached", "venom_expired"} else Fraction(0)
            nominal = bleeding + toxin
            before = (state.hp, state.armor, state.shield)
            state.hp -= nominal
            phase = "growing_exposure" if event == "blade_detached" else "non_exposure_decay" if event == "venom_expired" else "inactive"
            log.record({
                **common, "type": "continuous_damage_resolved", "target": target,
                "interval_start_ms": begin, "interval_end_ms": time,
                "damage_payment": "continuous analytic integral, not a damage tick",
                "nominal_hp_damage": fraction_record(nominal), "applied_hp_damage": fraction_record(nominal),
                "components": {
                    "bleeding": {"amount": fraction_record(bleeding), "y": str(calculation.hp_damage),
                                 "tb_start_seconds": str(tb0), "tb_end_seconds": str(tb1),
                                 "integral": "y * (8*(end-start) - (end^2-start^2)/2) / 320, clipped at 8 seconds", "source": slash.BLEED_SOURCE},
                    "venom": {"amount": fraction_record(toxin), "phase": phase, "delivery_snapshot": snapshot,
                              "exposure_duration_seconds": str(exposure_seconds),
                              "phase_integral": "(2/3) * C * T * sqrt(T)" if toxin else "0",
                              "exact_root_product": {"coefficient": str(phase_expression.coefficient), "radicand": str(phase_expression.radicand)} if phase != "inactive" else None,
                              "source": venom.SOURCE},
                }, "state_changes": _changes(target, before, state),
            })
            last_damage_time = time
            log.record({**common, "type": event, "target": target,
                        "peak_venom_rate": {"coefficient": str(peak_rate.coefficient), "radicand": str(peak_rate.radicand)} if event == "blade_detached" else None})
    _advance_statuses(states, current, until, log)
    return {
        "scenario_id": scenario.get("id", "unnamed"), "initial_states": initial,
        "encounter_configuration": {"movement": "stationary"}, "inputs": inputs,
        "run_until_ms": until, "events": log.records(), "final_states": _state_snapshot(states),
        "active_continuous_effects_final": [], "pending_shield_regeneration": [],
        "outcome": "One controlled activation and its continuous effects completed",
        "assumptions_and_limits": [
            "One stationary scenario-confirmed unshielded, nonlethal hit, with no initial actor instability or other actions. This does not model complete characters or encounter victory.",
            "Damage is calculated before new self instability and before armor loss. Target statuses and venom delivery use pre-hit armor; venom d is post-shield/pre-armor slash damage.",
            "Exposure grows with elapsed attachment time. After detachment exposure is retained while non-exposure grows until the square-root input reaches zero. The attached blade is treated as an autonomous target effect for its stated duration; no channel/interruption behavior is inferred.",
            "Bleeding and venom accumulate continuously. Exact analytic integrals are applied at effect boundaries; interval records describe continuous accumulation. No HP-dependent events occur inside these nonlethal intervals. The Active-end event samples only actor state.",
            "This controller requires rational full-phase venom integrals; the pure formula helper preserves irrational roots symbolically. It executes complete effects, not arbitrary partial observation times.",
            "Self statuses bypass mitigation; target statuses use collision mitigation and stacking. Status decay remains continuous with a zero floor.",
            "Shielded venom, overlapping blades/bleeds, Ultimate, replacement-blade grab timing/availability, cooldown/dyspnea eligibility, Recovery, healing/revival, general interrupts, movement, and autonomous decisions are outside this stage.",
        ],
    }
