"""Exact fixed-frame face polynomials shared by contact and support queries.

This module describes a supplied translation/size prefix. It never advances
the world or chooses a collision response. Each stored shape frame is constant.
"""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.orientation import scalar,vector3,dot
from combat_sim.oriented_geometry import OrientedCuboid,WORLD_AXES,separating_axes,projected_size


def value(poly,time):
    t=scalar(time);return poly[0]+poly[1]*t+poly[2]*t*t


@dataclass(frozen=True)
class AxisMotion:
    normal: tuple
    delta: tuple
    half: tuple

    def gaps(self):
        return tuple(a-b for a,b in zip(self.half,self.delta)),tuple(a+b for a,b in zip(self.half,self.delta))


def axis_motions(first,second,relative_velocity=(0,0,0),relative_acceleration=(0,0,0),*,
        first_size_rate=(0,0,0),second_size_rate=(0,0,0),
        first_size_acceleration=(0,0,0),second_size_acceleration=(0,0,0)):
    delta=tuple(a-b for a,b in zip(vector3(first.centre_m),vector3(second.centre_m)))
    v,a,s,t,q,r=map(vector3,(relative_velocity,relative_acceleration,first_size_rate,second_size_rate,
        first_size_acceleration,second_size_acceleration))
    directions=(separating_axes(first,second) if isinstance(first,OrientedCuboid) or isinstance(second,OrientedCuboid) else WORLD_AXES)
    return tuple(AxisMotion(n,(dot(delta,n),dot(v,n),dot(a,n)/2),
        ((projected_size(first,n)+projected_size(second,n))/2,
         (projected_size(first,n,s)+projected_size(second,n,t))/2,
         (projected_size(first,n,q)+projected_size(second,n,r))/4)) for n in directions)


def at_boundary(rows,time,first,second,velocity,acceleration,*,first_size_rate,second_size_rate,
        first_size_acceleration,second_size_acceleration):
    """Keep predicted geometry while using actual outgoing endpoint drivers."""
    v,a=vector3(velocity),vector3(acceleration)
    return tuple(AxisMotion(r.normal,(value(r.delta,time),dot(v,r.normal),dot(a,r.normal)/2),
        (value(r.half,time),
         (projected_size(first,r.normal,first_size_rate)+projected_size(second,r.normal,second_size_rate))/2,
         (projected_size(first,r.normal,first_size_acceleration)+projected_size(second,r.normal,second_size_acceleration))/4)) for r in rows)


def impact_normals(rows,*,distance_epsilon,speed_epsilon,acceleration_epsilon):
    """Actual one-sided entry faces; separating or stationary tangency is free."""
    eps,speed,change=map(scalar,(distance_epsilon,speed_epsilon,acceleration_epsilon))
    if min(eps,speed,change)<=0:raise ValueError('Contact resolutions must be positive')
    if any(r.half[0]-abs(r.delta[0]) < -eps for r in rows):return ()
    normals=[]
    for r in rows:
        if abs(abs(r.delta[0])-r.half[0])>eps:continue
        sign=1 if r.delta[0]>=0 else -1
        rate=sign*r.delta[1]-r.half[1];acceleration=2*(sign*r.delta[2]-r.half[2])
        if rate>speed or abs(rate)<=speed and acceleration>=-change:return ()
        normals.append(tuple(sign*x for x in r.normal))
    return tuple(sorted(normals))


def touching_normals(first,second,*,distance_epsilon,vertical_area=False):
    """Outward normals from the second shape to the first at real contact."""
    eps=scalar(distance_epsilon)
    if eps<=0:raise ValueError('Contact distance resolution must be positive')
    rows=axis_motions(first,second)
    if any(row.half[0]-abs(row.delta[0]) < -eps for row in rows):return ()
    result=[]
    for row in rows:
        if abs(abs(row.delta[0])-row.half[0])>eps:continue
        if row.normal[2] and vertical_area and not footprint_overlap(first,second,distance_epsilon=eps):continue
        sign=1 if row.delta[0]>=0 else -1
        result.append(tuple(sign*x for x in row.normal))
    return tuple(sorted(result))


def footprint_overlap(first,second,*,distance_epsilon=0):
    """Positive overlap on every footprint separating axis, beyond resolution."""
    eps=scalar(distance_epsilon)
    if eps<0:raise ValueError('Footprint resolution cannot be negative')
    for n in separating_axes(first,second):
        if n[2]:continue
        a,b=dot(vector3(first.centre_m),n),dot(vector3(second.centre_m),n)
        r,s=projected_size(first,n)/2,projected_size(second,n)/2
        if min(a+r,b+s)-max(a-r,b-s)<=eps:return False
    return True


def footprint_contains(box,point,*,closed=True):
    point=vector3(point)
    if isinstance(box,OrientedCuboid):
        local=box.frame.to_local_point(point,box.centre_m)
        return all(abs(local[i])<=box.size_m[i]/2 if closed else abs(local[i])<box.size_m[i]/2 for i in (0,1))
    low,high=box.bounds
    return all(low[i]<=point[i]<=high[i] if closed else low[i]<point[i]<high[i] for i in (0,1))


def closest_point(box,point):
    point=vector3(point)
    if isinstance(box,OrientedCuboid):return box.closest_point(point)
    low,high=box.bounds
    return tuple(min(b,max(a,p)) for a,b,p in zip(low,high,point))


def closest_surface_point(box,point):
    """Snap to an actual physical face; deterministic axis/side ties."""
    point=vector3(point)
    if isinstance(box,OrientedCuboid):
        local=box.frame.to_local_point(point,box.centre_m)
        return box.frame.to_world_point(closest_surface_point(box.local_box,local),box.centre_m)
    low,high=box.bounds;result=closest_point(box,point)
    if not any(p in (a,b) for p,a,b in zip(result,low,high)):
        _,axis,_,face=min((abs(point[i]-face),i,side,face) for i in range(3)
            for side,face in enumerate((low[i],high[i])))
        result=tuple(face if i==axis else x for i,x in enumerate(result))
    return result


def on_surface(box,point):
    point=vector3(point)
    if isinstance(box,OrientedCuboid):return on_surface(box.local_box,box.frame.to_local_point(point,box.centre_m))
    low,high=box.bounds
    return all(a<=p<=b for p,a,b in zip(point,low,high)) and any(p in (a,b) for p,a,b in zip(point,low,high))
