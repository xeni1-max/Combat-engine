"""Immutable per-release accuracy receipts and real velocity perturbations."""
from copy import deepcopy

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.accuracy import disk_sample,dispersed_velocity,nonnegative,spread_radius
from combat_sim.models import UnsupportedMechanicError


class ProjectileAccuracy:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.ordinals={};self.releases=[]
        if self.enabled:
            if definition!={'mode':'release_cone_v1'} or not world.mobile_mode or not world.life_cycles.enabled:
                raise UnsupportedMechanicError('Projectile accuracy needs current living moving bodies')
            seed=world.scenario.get('random_seed',0)
            if not isinstance(seed,int) or isinstance(seed,bool) or seed<0:raise ValueError('random_seed must be a nonnegative integer')
            self.seed=seed

    def attach(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            for ability in actor.profile.get('abilities',{}).values():
                cfg=ability.get('projectile_accuracy',{})
                if not isinstance(cfg,dict) or set(cfg)-{'base_radius_cm_per_100m','unaimed_radius_cm_per_100m'}:
                    raise ValueError('Unknown weapon accuracy fields')
                for value in cfg.values():nonnegative(value)

    def release(self,actor,action,ability,velocity):
        if not self.enabled:return velocity,None
        w=self.world;key=(actor.id,actor.life_generation,action.ability_id);ordinal=self.ordinals.get(key,0)+1
        cfg=ability.get('projectile_accuracy',{})
        if set(cfg)-{'base_radius_cm_per_100m','unaimed_radius_cm_per_100m'}:raise ValueError('Unknown weapon accuracy fields')
        base=nonnegative(cfg.get('base_radius_cm_per_100m',0));aiming=w.aim_control.effective(actor.id)
        unaimed=nonnegative(cfg.get('unaimed_radius_cm_per_100m',0)) if not aiming else dec(0)
        running=w.mobile_is_running(actor.id)
        radius=spread_radius(base,unaimed,actor.disorientation,running=running,precision=w.precision)
        sample=disk_sample(self.seed,actor.id,actor.profile_id,actor.life_generation,action.ability_id,ordinal)
        actual=dispersed_velocity(velocity,radius,sample,precision=w.precision)
        row=dict(actor=actor.id,profile=actor.profile_id,ability=action.ability_id,action_id=action.id,
            source_life_generation=actor.life_generation,ordinal=ordinal,released_at_ms=w.time,seed=self.seed,
            aiming=aiming,running=running,base_radius_cm_per_100m=base,unaimed_radius_cm_per_100m=unaimed,
            disorientation=actor.disorientation,total_radius_cm_per_100m=radius,disk_sample=sample,
            ideal_velocity_mps=tuple(map(dec,velocity)),actual_velocity_mps=actual)
        self.ordinals[key]=ordinal;self.releases.append(row)
        w.log('projectile_accuracy_released',accuracy=deepcopy(row));return actual,row

    def result(self):
        return dict(projectile_accuracy_rules=self.world.combat_locomotion_input['projectile_accuracy'],
            accuracy_seed=self.seed,projectile_accuracy_releases=deepcopy(self.releases)) if self.enabled else {}
