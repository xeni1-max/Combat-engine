"""Typed persistent effects and independently active heat volumes.

The coordinator still owns time, resource/HP boundaries and collision order.
This component supplies effect-specific integrals and spatial eligibility knots.
Frozen definitions retain the explicit earlier fixed-recipient effect adapter.
"""
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import AttachedVenom, BleedingEffect, EffectSource, HeatColumn, HeatExposure, HeatParameters
from combat_sim.mechanics import heat, slash
from combat_sim.mechanics.continuous_numeric import bleed_integral
from combat_sim.models import UnsupportedMechanicError
from combat_sim.volume_geometry import TIME_EPS_S, column_cells
from combat_sim.volume_query_cache import VolumeQueryCache
from combat_sim.world_colliders import finite
from combat_sim.pose_kinematics import pose_acceleration
from combat_sim.angular_paths import RotatingBoxPath


class SpatialEffects:
    def __init__(self,world,definition=None):
        self.world=world
        if definition is not None and definition!={'mode':'typed_heat_volumes_v1'}:
            raise UnsupportedMechanicError('Unsupported persistent effect rules')
        self.enabled=definition is not None
        if self.enabled and (not world.mobile_mode or world.combat_locomotion_input.get('world',{}).get('ruleset')!='integrated_v2'):
            raise UnsupportedMechanicError('Spatial effects require the integrated world')
        self.effect_ids=count(1);self.volume_ids=count(1)
        self.effects={};self.volumes={};self.members={};self.tracks={}
        self.query_cache=VolumeQueryCache()

    def add_bleed(self,payload,basis):
        world=self.world
        if not self.enabled:
            effect={'id':next(world.effect_ids),'kind':'bleeding','actor':payload['actor'],'target':payload['target'],
                'ability':payload['ability'],'basis_y':dec(basis),'start':world.time,'expiry':world.time+D(8000)}
            world.effects.append(effect)
            world.push(effect['expiry'],'effect_expired',{'effect_id':effect['id']})
            return effect
        source=EffectSource(payload['actor'],payload['ability'],payload['action_id'],payload.get('projectile_id'),
            payload.get('source_life_generation'))
        effect=BleedingEffect('effect:'+str(next(self.effect_ids)),source,payload['target'],world.time,dec(basis),
            target_life_generation=world.life_cycles.generation(payload['target']))
        self.effects[effect.id]=effect
        world.push(effect.expiry,'typed_effect_expired',{'effect_id':effect.id,'revision':effect.revision})
        return effect.record(world.time)

    def deploy_heat(self,actor,action,ability):
        world=self.world
        if ability['area_shape']!='vertical_cylinder':raise UnsupportedMechanicError('Spatial heat requires a column')
        source=EffectSource(actor.id,action.ability_id,action.id,life_generation=action.life_generation)
        params=HeatParameters(dec(ability['heat_output']),dec(ability['k']))
        volume=HeatColumn('volume:'+str(next(self.volume_ids)),source,
            tuple(map(dec,world.fighters[action.target].body_origin_m)),finite(ability['radius_m'],'Beam radius',positive=True),
            world.time,world.time+finite(ability['beam_duration_ms'],'Beam lifetime',positive=True),params)
        self.volumes[volume.id]=volume;self.members[volume.id]=set()
        world.push(volume.expiry,'volume_expired',{'volume_id':volume.id,'revision':volume.revision})
        recipients=[];constructs=[]
        for target,kind in self.targets():
            if self.cells(volume,target,kind,D(0))[0][1]:
                self.set_eligible(volume,target,kind,True)
                (recipients if kind=='actor' else constructs).append(target)
        world.log('beam_deployed',actor=actor.id,ability=action.ability_id,volume_id=volume.id,
            location_m=volume.centre,recipients=recipients,collider_recipients=constructs,leave_ms=volume.expiry)

    def targets(self):
        world=self.world
        targets=[(name,'actor') for name,actor in world.fighters.items() if actor.hp>0]
        targets.extend((name,'collider') for name,obj in world.collider_system.registry.objects.items()
            if obj.hp is not None and obj.hp>0 and obj.active(world.time))
        return targets

    def target_live(self,target,kind):
        if kind=='actor':return self.world.fighters[target].hp>0
        obj=self.world.collider_system.registry.objects.get(target)
        return obj is not None and obj.hp is not None and obj.hp>0 and obj.active(self.world.time)

    def motion_parts(self,target,kind='actor',seconds=None):
        world=self.world
        turns=getattr(world,'turns',None)
        if kind=='actor' and seconds is not None and turns is not None and turns.active(target):
            lease=dec(world.body_paths.ensure().end_ms)
            # Reconciliation itself can queue a due decision and shorten the
            # lease between recipients/volumes. Clip to the current prefix;
            # prepare_interval then returns that queued semantic boundary.
            end=min(world.time+seconds*1000,lease)
            return [turns.path(target,box,end) for box in world.world_bodies[target]]
        if kind=='actor':
            velocity,acceleration=world.mobile_motion(target)
            parts=[]
            for box in world.world_bodies[target]:
                offset,size_rate=world.pose_part_motion(target,box.part,world.time)
                pose_accel,size_accel=pose_acceleration(world,target,box.part,world.time)
                combined_accel=tuple(a+b for a,b in zip(acceleration,pose_accel)) if any(pose_accel) else acceleration
                row=(box,tuple(v+o for v,o in zip(velocity,offset)),combined_accel,size_rate)
                parts.append((*row,size_accel) if any(size_accel) else row)
        else:
            parts=[(box,(D(0),)*3,(D(0),)*3,(D(0),)*3) for box in world.collider_system.registry.objects[target].parts]
        return parts

    def field_motion(self,target,kind,seconds):
        parts=self.motion_parts(target,kind,seconds)
        if parts and isinstance(parts[0],RotatingBoxPath):
            seconds=min(seconds,dec(parts[0].yaw.end_s-parts[0].yaw.begin_s))
        return parts,seconds

    def motion_limit(self,end,*,physical_only=False):
        world=self.world;finish=end
        if physical_only:
            finish=min(finish,min((e[0] for e in world.queue if e[3] not in ('sample','world_horizon') and world._live(e)),default=finish))
        elif world.queue:finish=min(finish,world.queue[0][0])
        if world.mobile_mode:finish=min(finish,world.next_mobile_knot(finish))
        return finish

    def cells(self,volume,target,kind,seconds,*,occluded=True):
        world=self.world;parts,seconds=self.field_motion(target,kind,seconds)
        blockers=[part for key,boxes in world.collider_system.registry.active('areas',world.time).items()
            if kind!='collider' or key!=target for part in boxes] if occluded else []
        return self.query_cache.query(column_cells,volume.centre,volume.radius,parts,blockers,seconds,
            precision=world.precision,first_boundary_only=True)

    def end_effect(self,effect,reason):
        if hasattr(self.world,'healing'):self.world.healing.invalidate()
        if effect.ended:return
        if isinstance(effect,AttachedVenom):self.world.venom_effects.freeze_anchor(effect)
        if isinstance(effect,HeatExposure):
            effect.q_reference=effect.q_at(self.world.time);effect.reference_ms=self.world.time
        effect.ended=True;effect.revision+=1
        effect.ended_at_ms=self.world.time;effect.end_reason=reason
        self.world.log('effect_expired',effect_id=effect.id,target=effect.target,reason=reason)

    def retire_life(self,target,generation):
        """End recipient attachments; source-owned autonomous volumes survive."""
        retired=[]
        for effect in self.effects.values():
            if (effect.target==target and effect.target_life_generation==generation
                    and not effect.ended):
                self.end_effect(effect,'target_life_ended');retired.append(effect.id)
        for volume in self.volumes.values():self.members[volume.id].discard(target)
        for key in list(self.tracks):
            if key[1]==target:del self.tracks[key]
        self.world.thermal_recovery.retire_life(target,generation)
        if retired:self.world.log('life_effects_retired',actor=target,life_generation=generation,effect_ids=retired)

    def set_eligible(self,volume,target,kind,eligible):
        world=self.world;key=(volume.id,target)
        if (target in self.members[volume.id])!=eligible and hasattr(world,'healing'):world.healing.invalidate()
        if kind=='actor':
            incident=world.thermal_recovery.track(volume,target,eligible)
            if world.thermal_recovery.is_active(target):
                return world.thermal_recovery.set_eligible(volume,target,eligible,incident)
        effect=self.effects.get(self.tracks.get(key))
        before=target in self.members[volume.id]
        if eligible:
            channel='shield' if kind=='actor' and world.fighters[target].shield>0 else 'hp'
            if effect is not None and not effect.ended and effect.channel!=channel:
                if effect.channel=='hp':
                    raise UnsupportedMechanicError('Regenerated shield overlapping HP heat requires the shield re-entry lifecycle')
                self.end_effect(effect,'shield_depleted')
            if effect is None or effect.ended:
                previous=effect
                effect=HeatExposure('effect:'+str(next(self.effect_ids)),volume.source,volume.id,target,kind,channel,
                    volume.parameters,world.time,world.time,
                    target_life_generation=world.life_cycles.generation(target) if kind=='actor' else None)
                self.effects[effect.id]=effect;self.tracks[key]=effect.id
                world.log('heat_started',effect=effect.record(world.time),autonomous=True)
                if previous is not None and previous.channel=='shield' and channel=='hp':
                    world.log('hp_heat_exposure_started',effect_id=effect.id,previous_effect_id=previous.id,
                        volume_id=volume.id,target=target,exposure_seconds=0,remaining_exposure_ms=volume.expiry-world.time)
            else:
                effect.set_exposed(world.time,True)
            self.members[volume.id].add(target)
            if not before:
                world.log('heat_exposure_entered',volume_id=volume.id,effect_id=effect.id,target=target,target_kind=kind,
                    q_seconds=effect.q_at(world.time))
        else:
            self.members[volume.id].discard(target)
            if effect is not None and not effect.ended:
                if kind=='collider' and not self.target_live(target,kind):
                    self.end_effect(effect,'collider_removed')
                elif effect.set_exposed(world.time,False):
                    if effect.expiry<=world.time:
                        self.end_effect(effect,'thermal_memory_zero')
                    else:
                        world.push(effect.expiry,'typed_effect_expired',{'effect_id':effect.id,'revision':effect.revision})
            if before:
                world.log('heat_exposure_left',volume_id=volume.id,target=target,target_kind=kind,
                    q_seconds=effect.q_at(world.time) if effect is not None else D(0))

    def prepare_interval(self,end,*,physical_only=False):
        """Reconcile the current open cell and return the next eligibility knot."""
        if not self.enabled:return end
        world=self.world;finish=end
        if getattr(world,'segment_fields',None) is not None and world.segment_fields.enabled:
            finish=world.segment_fields.prepare(finish,physical_only=physical_only)
            end=finish
        # Forecasts (including HP recovery's independent250 ms epoch) must use
        # one valid motion/pose polynomial. Clipping only after cells() lets a
        # downward dip keep shrinking legs beyond its reversal and even below
        # zero size. Observations are excluded from physical-only epochs.
        if any(v.active and v.expiry>world.time for v in self.volumes.values()):
            finish=self.motion_limit(finish,physical_only=physical_only)
            end=finish
        for effect in self.effects.values():
            if isinstance(effect,HeatExposure) and not effect.ended and effect.target_kind=='collider' and not self.target_live(effect.target,'collider'):
                self.end_effect(effect,'collider_removed')
        targets=dict(self.targets())
        for volume in self.volumes.values():
            if not volume.active or volume.expiry<=world.time:continue
            for target in sorted(self.members[volume.id]):
                if target not in targets:
                    effect=self.effects[self.tracks[(volume.id,target)]]
                    self.set_eligible(volume,target,effect.target_kind,False)
            for target,kind in targets.items():
                cells=self.cells(volume,target,kind,(end-world.time)/1000)
                self.set_eligible(volume,target,kind,cells[0][1])
                if len(cells)>1:finish=min(finish,world.time+cells[1][0]*1000)
        if physical_only:
            finish=min((e[0] for e in world.queue if e[3] not in ('sample','world_horizon') and world._live(e)),default=finish)
            finish=min(finish,end)
        elif world.queue:finish=min(finish,world.queue[0][0])
        finish=world.poison_volumes.prepare_geometry(finish,physical_only=physical_only)
        return world.poison_volumes.prepare_doses(world.venom_effects.prepare(world.thermal_recovery.prepare(finish)))

    def settle(self):
        """Settle final membership without advancing time or integrating damage.

        The forward open cell at the geometry solver's 1e-24 ms boundary
        resolution handles motion away from a rounded contact. The tiny query
        classifies polynomial cells; it never becomes a gameplay time delay.
        """
        if not self.enabled:return
        world=self.world;targets=dict(self.targets())
        world.poison_volumes.settle()
        for volume in self.volumes.values():
            if not volume.active or volume.expiry<=world.time:continue
            for target in sorted(self.members[volume.id]):
                if target not in targets:
                    effect=self.effects[self.tracks[(volume.id,target)]]
                    self.set_eligible(volume,target,effect.target_kind,False)
            for target,kind in targets.items():
                self.set_eligible(volume,target,kind,self.cells(volume,target,kind,2*TIME_EPS_S)[0][1])

    def components(self,begin,end):
        parts={}
        if not self.enabled:return parts
        world=self.world
        for effect in self.effects.values():
            if effect.ended:continue
            if (effect.target_life_generation is not None and
                    effect.target_life_generation!=world.fighters[effect.target].life_generation):continue
            if isinstance(effect,AttachedVenom):
                if world.fighters[effect.target].hp>0:
                    part=world.venom_effects.component(effect,begin,end)
                    if part is not None:parts.setdefault(effect.target,[]).append(part)
                continue
            if isinstance(effect,BleedingEffect):
                if world.fighters[effect.target].hp<=0:continue
                amount=bleed_integral(effect.basis_y,effect.start,begin,end);channel='hp'
                inputs={'basis_y':effect.basis_y,'start_ms':effect.start,'expiry_ms':effect.expiry,'formula':slash.BLEED_FORMULA}
                kind='bleeding'
            elif isinstance(effect,HeatExposure):
                if not self.target_live(effect.target,effect.target_kind):continue
                if effect.target_kind=='actor' and world.thermal_recovery.is_active(effect.target):continue
                channel=effect.channel
                if effect.target_kind=='actor':
                    target=world.fighters[effect.target]
                    armor=target.armor if channel=='hp' else D(0)
                    resistance=dec(target.profile['resistances']['heat']) if channel=='hp' else D(0)
                else:armor=resistance=D(0)
                coefficient=dec(heat.heat_coefficient(effect.parameters.output,armor,resistance,effect.parameters.decay))
                amount=effect.integral(coefficient,begin,end);kind='heat'
                inputs={'curve_kind':'affine_root_v1','coefficient':coefficient,'q_reference':effect.q_reference,
                    'reference_ms':effect.reference_ms,'slope_per_second':effect.slope,'heat_output':effect.parameters.output,
                    'k':effect.parameters.decay,'armor':armor,'heat_resistance':resistance,'formula':heat.FORMULA,
                    'volume_id':effect.volume_id,'target_kind':effect.target_kind}
            else:raise UnsupportedMechanicError('Unknown typed persistent effect')
            if amount:
                parts.setdefault(effect.target,[]).append({'effect_id':effect.id,'kind':kind,'actor':effect.source.actor,
                    'ability':effect.source.ability,'action_id':effect.source.action_id,'channel':channel,'inputs':inputs,'amount':amount,
                    **effect.source.life_record(),
                    **({'projectile_id':effect.source.projectile_id} if self.world.applied_damage.enabled else {}),
                    **({'coefficient':coefficient} if kind=='heat' else {})})
        for target,entries in world.thermal_recovery.components(begin,end).items():
            parts.setdefault(target,[]).extend(entries)
        for target,entries in world.poison_volumes.components(begin,end).items():
            parts.setdefault(target,[]).extend(entries)
        return parts

    def shield_broken(self,target):
        if not self.enabled:return
        self.world.thermal_recovery.on_break(target)
        for effect in self.effects.values():
            if isinstance(effect,HeatExposure) and effect.target==target and effect.channel=='shield' and not effect.ended:
                self.end_effect(effect,'shield_depleted')
                self.world.log('shield_residual_terminated' if not effect.exposed else 'shield_heat_terminated',
                    effect_id=effect.id,target=target,transferred_hp_damage=0)

    def event_live(self,kind,payload):
        item=self.volumes.get(payload.get('volume_id')) if kind=='volume_expired' else self.effects.get(payload.get('effect_id'))
        return item is not None and (item.active if isinstance(item,HeatColumn) else not item.ended) and item.revision==payload['revision']

    def process(self,kind,payload):
        if not self.event_live(kind,payload):return
        if kind=='volume_expired':
            volume=self.volumes[payload['volume_id']];volume.active=False;volume.revision+=1
            for target in sorted(self.members[volume.id]):
                effect=self.effects[self.tracks[(volume.id,target)]]
                self.set_eligible(volume,target,effect.target_kind,False)
            self.world.log('volume_expired',volume_id=volume.id)
        else:
            effect=self.effects[payload['effect_id']]
            if kind=='venom_detached':self.world.venom_effects.detach(effect)
            else:self.end_effect(effect,'clock_expired')

    def result(self):
        if not self.enabled:return {}
        now=self.world.time
        return {'persistent_effect_rules':self.world.combat_locomotion_input['persistent_effects'],
            'persistent_effect_numerics':{'membership':'rational_polynomial_open_cells',
                'membership_boundary_tolerance_ms':TIME_EPS_S*1000,
                'damage':'analytic roots plus adaptive dense fluid body heat' if self.world.thermal_recovery.enabled else 'decimal_analytic_affine_root_integrals'},
            'effect_instances':[self.world.venom_effects.record(effect,now) if isinstance(effect,AttachedVenom)
                else effect.record(now) for effect in self.effects.values()],
            'volume_instances':[volume.record(self.members[volume.id]) for volume in self.volumes.values()]}

    def pending(self):
        return [self.world.venom_effects.record(effect,self.world.time) if isinstance(effect,AttachedVenom)
            else effect.record(self.world.time) for effect in self.effects.values() if not effect.ended
            and (effect.expiry is None or effect.expiry>self.world.time)]
