"""Explicit damage-benchmark decisions; no autonomous combat AI."""
from dataclasses import dataclass


@dataclass(frozen=True)
class RepeatWhenReady:
    """Repeat the selected ability, reloading only a supported empty firearm."""
    ability: str

    def choose(self, ammo=None):
        if ammo==0:
            return 'reload' if self.ability=='1E2_1' else 'stop_empty'
        return 'activate'

    def component(self, attacks_started):
        return ('b','c')[attacks_started%2] if self.ability=='3E5_1bc' else None
