"""Actual allied-projectile entry fields using shared independent entities."""
from copy import deepcopy
from decimal import Decimal as D, ROUND_CEILING
from itertools import count
from math import hypot
from types import SimpleNamespace

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import UnsupportedMechanicError
from combat_sim.projectile_volume_entry import first_radial_entry
from combat_sim.world_colliders import finite

ENTRY='projectile_duplication_entered'
EXPIRY='projectile_duplication_expired'
EVENTS=frozenset((ENTRY,EXPIRY))


class ProjectileDuplication:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        self.ids=count(1);self.fields={};self.splits=[];self.pending=set();self.predictions={};self.misses=set()
        if self.enabled and (definition!={'mode':'entry_split_v1'} or not world.mobile_mode):
            raise UnsupportedMechanicError('Projectile duplication requires current moving combat')

    def validate(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id];cfg=a.get('projectile_duplication')
        if not (self.enabled and w.projectiles.trace_schema=='entity_v1' and w.life_cycles.enabled
                and w.effort_system.enabled and w.cooldown_system.enabled and actor.action_registry is not None):
            raise UnsupportedMechanicError('Duplication fields need owned source lives, released power and independent projectile entities')
        if (not isinstance(cfg,dict) or set(cfg)!={'shape','radius_m','duration_ms','separation_m'}
                or cfg['shape']!='vertical_cylinder' or a.get('dyspnea',{}).get('kind')!='none'
                or a.get('deployment_timing')!='active_end' or a.get('cooldown_anchor')!='activation_start'):
            raise UnsupportedMechanicError('Duplication requires an autonomous no-effort cylindrical field')
        for key in ('radius_m','duration_ms','separation_m'):finite(cfg[key],'Duplication '+key,positive=True)
        finite(a['cooldown_ms'],'Duplication cooldown',positive=True)

    def selected(self,actor,action):
        w=self.world
        if action.target_snapshot is None:
            action.aim_location_m=tuple(map(dec,w.fighters[action.target].body_origin_m))

    def deploy(self,actor,action,ability):
        w=self.world;cfg=deepcopy(ability['projectile_duplication'])
        identity='duplication-field:'+str(next(self.ids))
        row=dict(id=identity,actor=actor.id,ability=action.ability_id,action_id=action.id,
            source_life_generation=action.life_generation,team=actor.team,definition=cfg,
            centre_m=deepcopy(action.aim_location_m),deployed_at_ms=w.time,
            expiry_ms=w.time+dec(cfg['duration_ms']),status='active',autonomous=True)
        self.fields[identity]=row
        w.push(row['expiry_ms'],EXPIRY,{'field_id':identity})
        w.log('projectile_duplication_deployed',**deepcopy(row))
        self.settle()

    def eligible(self,row,flight):
        w=self.world
        if (row['status']!='active' or w.time>=row['expiry_ms'] or flight['status']!='in_flight'
                or row['id'] in flight['duplication_sources'] or w.fighters[flight['actor']].team!=row['team']):return False
        if w.gravity_mode:
            path=w.gravity_trajectories[flight['id']]
            if path.stopping_time_s is not None and float((w.time-flight['trajectory_started_at_ms'])/1000)>=path.stopping_time_s:return False
        return True

    def key(self,row,flight):
        return row['id'],flight['id'],flight['revision']

    def inside(self,row,flight):
        point=self.world.mobile_flight_state(flight,self.world.time)[0]
        radius=dec(row['definition']['radius_m'])+dec(flight['radius_m'])
        return hypot(*(float(p-c) for p,c in zip(point[:2],row['centre_m'][:2])))<=float(radius)

    def payload(self,row,flight):
        return dict(self.world.projectiles.link(flight),field_id=row['id'])

    def enqueue(self,payload,at_ms):
        key=payload['field_id'],payload['projectile_id'],payload['projectile_revision']
        if key not in self.pending:
            self.pending.add(key)
            self.world.push(at_ms,ENTRY,payload,priority=3)

    def settle(self):
        if not self.enabled:return
        live=lambda key:(key[0] in self.fields and self.fields[key[0]]['status']=='active'
            and key[1] in self.world.projectile_flights
            and self.world.projectile_flights[key[1]]['status']=='in_flight'
            and self.world.projectile_flights[key[1]]['revision']==key[2])
        self.pending={key for key in self.pending if live(key)}
        self.predictions={key:value for key,value in self.predictions.items() if live(key)}
        self.misses={key for key in self.misses if live(key)}
        for row in self.fields.values():
            for flight in list(self.world.projectile_flights.values()):
                key=self.key(row,flight)
                cached=self.predictions.get(key)
                if cached is not None and cached[0]>self.world.time:continue
                if key not in self.pending and self.eligible(row,flight) and self.inside(row,flight):
                    self.enqueue(cached[1] if cached else self.payload(row,flight),self.world.time)

    def next_boundary(self,end):
        if not self.enabled:return None
        w=self.world;found=[]
        for row in self.fields.values():
            for flight in list(w.projectile_flights.values()):
                key=self.key(row,flight)
                if key in self.pending or key in self.misses or not self.eligible(row,flight):continue
                cached=self.predictions.get(key)
                if cached is None:
                    # Fixed volume + immutable flight: solve this pair once
                    # over its entire remaining lifetime. Observation clocks
                    # cannot change the subdivision/root-rounding bracket.
                    start=flight['trajectory_started_at_ms']
                    begin=float((max(start,row['deployed_at_ms'])-start)/1000)
                    finish=min(w.horizon,row['expiry_ms'])
                    if w.gravity_mode:
                        trajectory=w.gravity_trajectories[flight['id']]
                        until=min(trajectory.duration,float((finish-start)/1000))
                        if trajectory.stopping_time_s is not None:until=min(until,trajectory.stopping_time_s)
                        bound=trajectory.gravity+trajectory.deceleration
                    else:
                        trajectory=SimpleNamespace(duration=float((w.horizon-start)/1000),
                            at=lambda t,f=flight,s=start:SimpleNamespace(position_m=w.mobile_flight_state(f,s+dec(t)*1000)[0]))
                        until=float((finish-start)/1000);bound=abs(float(flight['acceleration_mps2']))
                        if 'stops_at_ms' in flight:until=min(until,float((flight['stops_at_ms']-start)/1000))
                    if begin>until:continue
                    radius=dec(row['definition']['radius_m'])+dec(flight['radius_m'])
                    entry=first_radial_entry(trajectory,row['centre_m'][:2],radius,begin,until,
                        acceleration_bound_mps2=bound,
                        time_tolerance_s=float(w.physics['contact_time_tolerance_s']) if w.gravity_mode else 1e-12,
                        clearance_tolerance_m=float(w.physics['contact_clearance_tolerance_m']) if w.gravity_mode else 1e-14)
                    if entry is None:
                        self.misses.add(key)
                        continue
                    quantum=w.physics['event_quantum_ms'] if w.gravity_mode else D('0.000001')
                    absolute=((start+dec(entry.time_upper_s)*1000)/quantum).to_integral_value(rounding=ROUND_CEILING)*quantum
                    payload=self.payload(row,flight)
                    payload.update(entry_bracket_s=(entry.time_lower_s,entry.time_upper_s),trajectory_started_at_ms=start)
                    cached=max(w.time,absolute),payload
                    self.predictions[key]=cached
                absolute,payload=cached
                if absolute<=end and absolute<row['expiry_ms']:found.append((max(w.time,absolute),payload))
        if not found:return None
        first=min(t for t,_ in found)
        return first,[p for t,p in found if t==first]

    def event_live(self,kind,payload):
        row=self.fields.get(payload['field_id'])
        if row is None or row['status']!='active':return False
        if kind==EXPIRY:return True
        flight=self.world.projectile_flights.get(payload['projectile_id'])
        return flight is not None and self.world.projectiles.live(payload) and self.eligible(row,flight)

    def process(self,kind,payload):
        if kind==ENTRY:
            self.pending.discard((payload['field_id'],payload['projectile_id'],payload['projectile_revision']))
        if not self.event_live(kind,payload):return
        row=self.fields[payload['field_id']];w=self.world
        if kind==EXPIRY:
            row.update(status='expired',ended_at_ms=w.time)
            w.log('projectile_duplication_expired',field_id=row['id'])
            return
        # A due phase may have changed body geometry or introduced a solid at
        # the entry clock. Finish the complete ordinary physical wave first.
        contacts=w.next_mobile_projectile_contacts(w.time)
        if contacts is not None:
            for p in contacts[1]:w.push(w.time,p.get('projectile_event','impact'),p)
            self.enqueue(payload,w.time)
            return
        split=w.projectile_system.split(payload['projectile_id'],source=row['id'],separation_m=row['definition']['separation_m'])
        if split is None:return
        record=dict(field_id=row['id'],field_actor=row['actor'],field_source_life_generation=row['source_life_generation'],
            at_ms=w.time,entry=deepcopy(payload),**split)
        self.splits.append(record)
        w.log('projectile_duplication_resolved',**deepcopy(record))
        # Authored shifts can put an endpoint inside a body/material. Resolve
        # that actual new contact at this clock, before decisions/other splits.
        contacts=w.next_mobile_projectile_contacts(w.time)
        if contacts is not None:
            for p in contacts[1]:w.push(w.time,p.get('projectile_event','impact'),p)

    def result(self):
        return {'projectile_duplication_rules':deepcopy(self.world.combat_locomotion_input['projectile_duplication']),
            'projectile_duplication_fields':deepcopy(list(self.fields.values())),
            'projectile_duplication_splits':deepcopy(self.splits)} if self.enabled else {}
