"""Common Break input, controller response and life-bound per-hold contests."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
from itertools import count

from combat_sim.action_ownership import ActionRequirements
from combat_sim.battle_models import BattleAction,decimal_value as dec
from combat_sim.mechanics.escape_boundary import first_nonnegative,MARGIN_RESOLUTION,TIME_RESOLUTION_MS
from combat_sim.mechanics.grapple import GrappleState,assess_break,break_status_base
from combat_sim.mechanics.life import life_generation
from combat_sim.mechanics.status import mitigate_status
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite


COMMANDS=('break','continue_grapple','release_grapple','break_binding','stop_binding_break')


class GrappleBreak:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.contests={};self.by_link={};self.commands={};self.ids=count(1)
        if self.enabled:
            if (not isinstance(definition,dict) or set(definition)!={'mode','response_window_ms'} or
                    definition['mode']!='grapple_break_v1' or not world.grapple_casts.enabled):
                raise UnsupportedMechanicError('Grapple Break needs owned holds and a declared response window')
            with localcontext(Context(prec=world.precision)):
                self.response_window=finite(definition['response_window_ms'],'Break response window',positive=True)
            if self.response_window<=TIME_RESOLUTION_MS:raise ValueError('Break response window must exceed clock resolution')

    def requirements(self,action):
        return ActionRequirements(frozenset(('grapple_break:'+str(action.id),)),frozenset())

    def load_script(self):
        return self.world.controls.load_script()

    def live_hold(self,row):
        w=self.world
        return row['status']=='active' and row['expiry_ms']>w.time and all(w.fighters[n].hp>0 and
            w.fighters[n].life_generation==row[key] for n,key in ((row['actor'],'source_life_generation'),
                (row['target'],'target_life_generation')))

    def live(self,row):
        hold=self.world.grapple_casts.holds[row['link_id']]
        return row['status'] in ('awaiting_response','filling') and self.live_hold(hold)

    def select(self,actor,command,link_id):
        holds=[h for h in self.world.grapple_casts.holds.values() if self.live_hold(h) and
            h['target' if command=='break' else 'actor']==actor]
        if command=='continue_grapple':holds=[h for h in holds if h['id'] in self.by_link and
            self.contests[self.by_link[h['id']]]['status']=='awaiting_response']
        if link_id is not None:holds=[h for h in holds if h['id']==link_id]
        return min(holds,key=lambda h:(h['started_at_ms'],h['actor'],h['id']),default=None)

    def state(self,name,time=None,plan=None):
        actor=self.world.fighters[name];elapsed=D(0) if time is None else time-self.world.time
        return GrappleState(actor.dyspnea if plan is None else plan.at(time)[0],
            max(D(0),actor.disorientation-elapsed),max(D(0),actor.instability-elapsed))

    def assessment(self,row):return assess_break(self.state(row['controller']),self.state(row['defender']))

    def validate_binding_control(self,command,link_id,binding_id):
        if binding_id is not None and (not isinstance(binding_id,str) or not binding_id):
            raise ValueError('A binding identity must be nonempty')
        if binding_id is not None and (link_id is not None or command not in ('break','break_binding','stop_binding_break')):
            raise ValueError('A binding control cannot select a grapple link or controller response')
        if command in ('break_binding','stop_binding_break') or binding_id is not None:
            if not self.world.bindings.enabled:raise UnsupportedMechanicError('Binding Break is not enabled')
            if link_id is not None:raise ValueError('A binding control cannot select a grapple link')

    def command(self,actor,command,*,link_id=None,binding_id=None,expected_life_generation=None):
        with localcontext(Context(prec=self.world.precision)):
            return self._command(actor,command,link_id,binding_id,expected_life_generation)

    def _command(self,actor,command,link_id,binding_id,generation):
        if not self.enabled and not self.world.bindings.enabled:raise UnsupportedMechanicError('Common Break is not enabled')
        if not isinstance(actor,str) or actor not in self.world.fighters or command not in COMMANDS:raise ValueError('Unknown combat control actor/command')
        if link_id is not None and (not isinstance(link_id,str) or not link_id):raise ValueError('A link identity must be nonempty')
        self.validate_binding_control(command,link_id,binding_id)
        a=self.world.fighters[actor]
        generation=a.life_generation if generation is None else life_generation(generation)
        if generation is None:raise ValueError('A control needs an expected actor life')
        if a.hp<=0 or a.life_generation!=generation:return {'status':'ignored','reason':'actor_life_ended'}
        if command in ('break_binding','stop_binding_break') or binding_id is not None:
            return self.world.bindings.command(actor,command,binding_id)
        hold=self.select(actor,command,link_id)
        if hold is None:
            if command=='break' and link_id is None and self.world.bindings.enabled:
                return self.world.bindings.command(actor,command)
            return {'status':'ignored','reason':'no_eligible_hold'}
        if command=='release_grapple':
            self.world.grapple_casts.release(actor,hold['id']);return {'status':'released','link_id':hold['id']}
        if command=='continue_grapple':return self.respond(hold)
        previous=self.by_link.get(hold['id'])
        if previous is not None:return {'status':'duplicate','contest_id':previous}
        w=self.world;identity='grapple-contest:'+str(next(self.ids));until=hold['expiry_ms']
        action=BattleAction(next(w.action_ids),actor,hold['actor'],'break','grapple_break',w.time,w.time,until-w.time,
            phase='awaiting_response',active_end_ms=until,life_generation=a.life_generation)
        a.current=action
        row={'id':identity,'link_id':hold['id'],'controller':hold['actor'],'defender':actor,
            'controller_life_generation':hold['source_life_generation'],'defender_life_generation':a.life_generation,
            'break_action_id':action.id,'requested_at_ms':w.time,'response_deadline_ms':min(until,w.time+self.response_window),
            'status':'awaiting_response','effort_channel_ids':[],'boundary_revision':0,'boundary_at_ms':None}
        self.contests[identity]=row;self.by_link[hold['id']]=identity
        w.log('grapple_break_requested',contest=self.record(row),assessment=self.assessment(row).record())
        if self.assessment(row).escape_condition_met:
            w.grapple_casts.end(hold,'break_escaped');return {'status':'escaped','contest_id':identity}
        w.push(row['response_deadline_ms'],'grapple_break_deadline',{'contest_id':identity},priority=0)
        return {'status':'awaiting_response','contest_id':identity}

    def respond(self,hold):
        w=self.world;row=self.contests[self.by_link[hold['id']]]
        if row['response_deadline_ms']-w.time<=TIME_RESOLUTION_MS:
            return {'status':'ignored','reason':'response_deadline_reached'}
        if self.assessment(row).escape_condition_met:
            w.grapple_casts.end(hold,'break_escaped');return {'status':'escaped','contest_id':row['id']}
        controller=w.fighters[row['controller']];defender=w.fighters[row['defender']]
        actions=(controller.action_by_id(hold['holding_action_id']),defender.action_by_id(row['break_action_id']))
        if any(a is None for a in actions):return {'status':'ignored','reason':'control_ended'}
        row.update(status='filling',responded_at_ms=w.time)
        actions[1].phase='filling'
        for actor,action in zip((controller,defender),actions):
            channel=w.continuous_effort.start(actor,action,tag='grapple_break:'+row['id'],kind='fill',base=20,
                until_ms=hold['expiry_ms'])
            row['effort_channel_ids'].append(channel.id)
        w.log('grapple_break_answered',contest=self.record(row))
        return {'status':'filling','contest_id':row['id']}

    def record(self,row):
        return deepcopy({k:v for k,v in row.items() if k not in ('boundary_snapshot',)})

    def hold_ended(self,hold,reason,*,cancelling_action_id=None):
        identity=self.by_link.get(hold['id']);w=self.world
        if identity is None:return
        row=self.contests[identity]
        if row['status']=='ended':return
        row.update(status='ended',ended_at_ms=w.time,end_reason=reason)
        channels=[w.continuous_effort.channels[i] for i in row['effort_channel_ids']]
        gained=sum((c.gained for c in channels),D(0));row['actual_break_dyspnea']=gained
        for channel in channels:w.continuous_effort.end(channel,'grapple_contest_ended')
        target=w.fighters[row['defender']];action=target.action_by_id(row['break_action_id'])
        if action is not None and action.id!=cancelling_action_id:
            action.phase='ended';action.revision+=1;target.action_registry.release(action.id)
        row['penalty_base']=dec(break_status_base(gained));row['penalty_status']='queued';row['penalties']=[]
        if row['penalty_base']:
            # Continuous fatigue and expiry can end a hold before due Active
            # starts are processed. Incoming penalties must not retract them.
            w.push(w.time,'grapple_break_penalty',{'contest_id':row['id']},priority=3)
        else:self.apply_penalty(row)
        w.log('grapple_break_ended',contest=self.record(row))
        for name in (row['controller'],row['defender']):w.request_decision(name,w.time)

    def apply_penalty(self,row):
        if row['penalty_status']!='queued':return
        w=self.world;base=row['penalty_base'];penalties=[]
        # Snapshot both individual defenses before applying either penalty.
        for name,key in ((row['controller'],'controller_life_generation'),(row['defender'],'defender_life_generation')):
            a=w.fighters[name]
            if a.hp<=0 or a.life_generation!=row[key]:continue
            amount=mitigate_status(base,a.profile['max_hp'],a.armor,w.target_status_resistance(a))
            penalties.append((name,a.armor,amount))
        for name,armor,amount in penalties:
            if amount:w.apply_target_status_additions(name,{'disorientation':amount,'instability':amount},armor)
        row['penalty_status']='applied'
        row['penalties']=[{'actor':n,'disorientation':v,'instability':v} for n,_,v in penalties]
        w.log('grapple_break_penalty_applied',contest=self.record(row))

    def action_cancelled(self,actor,action,reason):
        if action.kind!='grapple_break':return
        for row in self.contests.values():
            if row['status']!='ended' and row['defender']==actor.id and row['break_action_id']==action.id:
                hold=self.world.grapple_casts.holds[row['link_id']]
                self.world.grapple_casts.end(hold,'break_control_'+reason)

    def invalidate(self):
        for row in self.contests.values():
            if row['status']!='ended':row['boundary_revision']+=1;row['boundary_at_ms']=None

    def queue_boundary(self,row,time,snapshot):
        if row['boundary_at_ms'] is not None and abs(row['boundary_at_ms']-time)<=TIME_RESOLUTION_MS:return
        row['boundary_revision']+=1;row['boundary_at_ms']=time;row['boundary_snapshot']=snapshot
        self.world.push(time,'grapple_break_boundary',{'contest_id':row['id'],'revision':row['boundary_revision']},priority=4)

    def settle(self):
        for row in self.contests.values():
            if self.live(row) and self.assessment(row).escape_condition_met:
                self.queue_boundary(row,self.world.time,self.snapshot(row,self.world.time))

    def snapshot(self,row,time,plans=None):
        return tuple(self.state(row[key],time,plans[row[key]] if plans else None) for key in ('controller','defender'))

    def prepare(self,end):
        if not self.enabled or end<=self.world.time:return end
        w=self.world;finish=end
        for row in self.contests.values():
            if not self.live(row):continue
            names=(row['controller'],row['defender']);plans={n:w.continuous_effort.forecast(n,finish) for n in names}
            cuts={w.time,finish}
            for name,plan in plans.items():
                cuts.update(t for t in plan.knots() if w.time<t<finish)
                a=w.fighters[name];cuts.update(w.time+s for s in (a.disorientation,a.instability) if 0<s<finish-w.time)
            def value(time):return dec(assess_break(*self.snapshot(row,time,plans)).margin)
            for a,b in zip(sorted(cuts),sorted(cuts)[1:]):
                middle=(a+b)/2
                status_counts=[sum(s>middle-w.time for s in (w.fighters[n].disorientation,w.fighters[n].instability)) for n in names]
                status_slope=D(status_counts[1]-status_counts[0])/10
                def slopes(first,last):
                    low_a,high_a=plans[names[0]].rate_bounds(first,last)
                    low_b,high_b=plans[names[1]].rate_bounds(first,last)
                    return (low_a-high_b)/1000+status_slope,(high_a-low_b)/1000+status_slope
                boundary=first_nonnegative(value,slopes,a,b,precision=w.precision)
                if boundary is not None:
                    self.queue_boundary(row,boundary,self.snapshot(row,boundary,plans));finish=min(finish,boundary);break
        return finish

    def event_live(self,kind,p):
        if kind=='combat_control':return self.world.controls.live(p)
        row=self.contests[p['contest_id']]
        if kind=='grapple_break_deadline':return row['status']=='awaiting_response'
        if kind=='grapple_break_penalty':return row['status']=='ended' and row['penalty_status']=='queued'
        return self.live(row) and row['boundary_revision']==p['revision']

    def process(self,kind,p):
        if not self.event_live(kind,p):return
        w=self.world
        if kind=='combat_control':return w.controls.process(p)
        row=self.contests[p['contest_id']];hold=w.grapple_casts.holds[row['link_id']]
        if kind=='grapple_break_penalty':return self.apply_penalty(row)
        if kind=='grapple_break_deadline':
            if self.live(row):w.grapple_casts.end(hold,'break_no_response')
            return
        assessment=self.assessment(row);current=self.snapshot(row,w.time);expected=row['boundary_snapshot']
        equivalent=all(abs(dec(getattr(a,k))-dec(getattr(b,k)))<=MARGIN_RESOLUTION for a,b in zip(current,expected)
            for k in ('dyspnea','disorientation','instability'))
        if assessment.escape_condition_met or equivalent and abs(dec(assessment.margin))<=MARGIN_RESOLUTION:
            w.grapple_casts.end(hold,'break_escaped')
        row['boundary_at_ms']=None

    def result(self):
        result={'grapple_break_rules':self.world.combat_locomotion_input['grapple_break'],
            'grapple_break_contests':[self.record(r) for r in self.contests.values()],
            'combat_control_commands':deepcopy(list(self.commands.values()))} if self.enabled else {}
        if self.world.bindings.enabled and not self.enabled:
            result['combat_control_commands']=deepcopy(list(self.commands.values()))
        return result
