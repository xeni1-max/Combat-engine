"""Per-character bodies derived from one approved reference placement.

Coordinates authored in metres remain metre offsets. Body scale controls body
geometry and the proportional crouch target, not weapon/ability range or speed.
Older supplied body definitions without this mode retain their original proxy.
"""
from copy import deepcopy
from fractions import Fraction as F

from combat_sim.hitboxes import standing_cuboids
from combat_sim.mechanics.velocity_projection import vector
from combat_sim.models import UnsupportedMechanicError,as_fraction

IDENTITY=(F(1),)*3


def profile_scale(definition,profile):
    rule=definition.get('character_geometry')
    if rule is None:return IDENTITY
    if rule!={'mode':'profile_scale_v1','profile_field':'body_scale_xyz'}:
        raise UnsupportedMechanicError('Unknown per-character body geometry rules')
    scale=vector(profile.get('body_scale_xyz',IDENTITY))
    if any(v<=0 for v in scale):raise ValueError('Character body scale must be positive in every axis')
    return scale


def scaled_definition(definition,scale):
    """Affine local-axis scaling, preserving feet and exact cuboid proportions."""
    scale=vector(scale)
    if any(v<=0 for v in scale):raise ValueError('Character body scale must be positive')
    standing_cuboids(definition)
    if scale==IDENTITY:return definition
    result=deepcopy(definition);placement=result['standing_placement']
    for part in result['parts']:
        result['parts'][part]['size_xyz_m']=[as_fraction(x)*s for x,s in zip(result['parts'][part]['size_xyz_m'],scale)]
        placement['centres_xyz_m'][part]=[as_fraction(x)*s for x,s in zip(placement['centres_xyz_m'][part],scale)]
    placement['ground_z_m']=as_fraction(placement['ground_z_m'])*scale[2]
    placement['combined_size_xyz_m']=[as_fraction(x)*s for x,s in zip(placement['combined_size_xyz_m'],scale)]
    placement['status']='scaled_from_confirmed_reference'
    placement['source']='Author body proportions; delegated affine scaling of the approved reference placement'
    return result


def actor_body(world,name):
    return getattr(world,'actor_body_definitions',{}).get(name,world.body_definition)


def crouch_target(world,name,nominal_height):
    scale=getattr(world,'actor_body_scales',{}).get(name,IDENTITY)
    return as_fraction(nominal_height)*scale[2]
