"""Posture actions on the shared combat clock; geometry remains reusable."""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.character_geometry import actor_body,crouch_target
from combat_sim.battle_models import BattleAction, ceil_ms, decimal_value as dec
from combat_sim.hitboxes import combined_bounds, local_to_world_point
from combat_sim.locomotion_features import LocomotionFeatureRules
from combat_sim.mechanics.dyspnea import apply_action_dyspnea
from combat_sim.models import UnsupportedMechanicError
from combat_sim.command_dispatch import IntentOutcome
from combat_sim.movement_contacts import first_box_contact
from combat_sim.postures import body_origin_from_bounds, crouch_drop_m, pose_local_hand_position, world_posture_cuboids


class PostureCombatRules:
    def setup_mobile_combat(self, definition, effects):
        self.posture_ready = False
        self.posture_combat = effects.get('posture') if effects else None
        if self.posture_combat is not None:
            expected = {'payment_timing':'active_start', 'self_effect_timing':'active_start',
                'stand_effects':'same_as_crouch', 'hands':'retain_current_pose',
                'blocked_transition':'freeze_at_contact'}
            if any(self.posture_combat.get(k) != v for k,v in expected.items()):
                raise UnsupportedMechanicError('Unsupported combat posture definition')
            c = definition.get('crouch', {})
            if (c.get('status') != 'confirmed_by_author' or
                    c.get('geometry') != 'shorten_legs_lower_upper_body' or
                    c.get('pose_curve') != 'linear_during_active' or c.get('standing_clearance') != 'required'):
                raise UnsupportedMechanicError('Combat posture requires the approved crouch geometry')
            for actor in self.fighters.values():
                crouch_drop_m(actor_body(self,actor.id),1,crouch_target(self,actor.id,c['target_leg_height_m']))
                p = c.get('characters',{}).get(actor.profile_id)
                if p is None:
                    raise UnsupportedMechanicError('Missing combat posture profile')
                if any(not dec(p[k]).is_finite() or dec(p[k]) <= 0 or dec(p[k]) != ceil_ms(dec(p[k]))
                       for k in ('crouch_active_ms','stand_active_ms')):
                    raise ValueError('Posture Active durations must be positive integer milliseconds')
                if any(not dec(p[k]).is_finite() or dec(p[k]) < 0 for k in
                       ('self_disorientation_on_crouch','self_instability_on_crouch','listed_dyspnea_value')):
                    raise ValueError('Posture costs and statuses must be finite and nonnegative')
        super().setup_mobile_combat(definition,effects)
        if self.posture_combat is not None:
            self.crouch_definition = deepcopy(definition['crouch'])
            for name,actor in self.fighters.items():
                self.motion[name].update(crouch_fraction=D(0),pose_transition=None,
                    body_reference_z=dec(actor.body_origin_m[2]))
                actor.metrics.update(crouches_started=0,crouches_completed=0,
                    stands_completed=0,stand_requests_rejected=0,posture_interruptions=0)
            self.posture_ready = True
            self.refresh_mobile_locomotion()

    def posture_at(self,name,time):
        return LocomotionFeatureRules.posture_at(self,name,time)

    def pose_part_motion(self,name,part,time):
        if self.equilibrium.carries(name,time):
            velocity,_,size_rate,_=self.equilibrium.deformation(name,part,time)
            return velocity,size_rate
        return LocomotionFeatureRules.pose_part_motion(self,name,part,time)

    def pose_part_acceleration(self,name,part,time):
        if self.equilibrium.carries(name,time):
            _,acceleration,_,size_accel=self.equilibrium.deformation(name,part,time)
            return acceleration,size_accel
        return LocomotionFeatureRules.pose_part_acceleration(self,name,part,time)

    def _refresh_combat_posture(self):
        if not self.posture_ready:
            return
        for name,actor in self.fighters.items():
            m = self.motion[name]
            if self.equilibrium.carries(name):
                self.equilibrium.refresh_actor(name)
                continue
            fraction,rate = self.posture_at(name,self.time)
            reference = (*actor.position_m,m['body_reference_z'])
            boxes = world_posture_cuboids(actor_body(self,name),reference,actor.facing,
                                         fraction,crouch_target(self,name,self.crouch_definition['target_leg_height_m']))
            self.world_bodies[name] = boxes
            actor.body_origin_m = tuple(map(dec,body_origin_from_bounds(boxes)))
            actor.pose_drop_m = dec(crouch_drop_m(actor_body(self,name),fraction,
                crouch_target(self,name,self.crouch_definition['target_leg_height_m'])))
            low,high = combined_bounds(boxes)
            posture = ('crouching' if rate>0 else 'standing_up' if rate<0 else
                'crouched' if fraction==1 else 'standing' if fraction==0 else 'partial')
            from combat_sim.pose_kinematics import world_hand_point
            hands = {hand:[str(dec(v)) for v in world_hand_point(self,actor,point)]
                for hand,point in actor.hands.items()}
            actor.locomotion.update(posture=posture,crouch_fraction=str(fraction),
                crouch_drop_m=str(actor.pose_drop_m),body_height_m=str(dec(high[2]-low[2])),
                feet_z_m=str(dec(low[2])),
                height_above_ground_m=str(dec(low[2])-dec(self.scenario['encounter']['ground_z_m'])),
                hand_world_positions_m=hands)
            if self.equilibrium.enabled:
                actor.locomotion.update(balance_fraction='0',pose_drop_m=str(actor.pose_drop_m))

    def refresh_mobile_locomotion(self):
        super().refresh_mobile_locomotion()
        self._refresh_combat_posture()

    def advance_mobile_geometry(self,begin,end):
        if not self.posture_ready:
            return super().advance_mobile_geometry(begin,end)
        # Flight and support track an upright reference, independently of the
        # pose's recentered body origin. Never integrate a sampled pose offset.
        for name,actor in self.fighters.items():
            actor.body_origin_m = (*actor.position_m,self.motion[name]['body_reference_z'])
        super().advance_mobile_geometry(begin,end)
        for name,actor in self.fighters.items():
            self.motion[name]['body_reference_z'] = dec(actor.body_origin_m[2])
        # The caller sets the common clock to end before refreshing the pose.

    def try_posture_step(self,actor,command):
        m = self.motion[actor.id]
        fraction,_ = self.posture_at(actor.id,self.time)
        target = D(1) if command=='crouch' else D(0)
        if fraction == target:
            self.log('posture_command_no_change',actor=actor.id,action=command)
            return IntentOutcome.CONSUMED
        p = self.crouch_definition['characters'][actor.profile_id]
        duration = dec(p['crouch_active_ms' if command=='crouch' else 'stand_active_ms'])*abs(target-fraction)
        if command=='stand' and not self.standing_clearance(actor.id,duration):
            actor.metrics['stand_requests_rejected'] += 1
            self.log('stand_rejected',actor=actor.id,reason='insufficient_clearance')
            return IntentOutcome.REJECTED
        ready = self.resource_ready_time(actor,{'kind':'action','base_value':p['listed_dyspnea_value']})
        if ready > self.time:
            if ready.is_finite():
                self.request_decision(actor.id,ready)
            self.log('movement_waiting_for_capacity',actor=actor.id,action=command,resume_at_ms=ready)
            return IntentOutcome.WAITING
        # No jump/crouch hand poses are authored. Keep canonical standing-frame
        # hands; the shared world transform lowers them with the upper body.
        due = ceil_ms(self.time+actor.disorientation)
        action = BattleAction(next(self.action_ids),actor.id,actor.id,command,'posture',
            self.time,due,duration,phase='gathering',base_gathering_ms=D(0))
        actor.current = action
        due = self.timed_gathering.commit(actor,action)
        self.log('posture_requested',actor=actor.id,action=command,action_id=action.id,active_start_ms=due)
        self._schedule_phase(action,'active_started',due)
        return IntentOutcome.STARTED

    def standing_clearance(self,name,duration):
        if not self.mobile_mode:
            return LocomotionFeatureRules.standing_clearance(self,name,duration)
        if self.equilibrium.carries(name):
            from combat_sim.prone_actions import clearance
            return clearance(self.equilibrium,self.fighters[name],duration,recover_balance=False)
        fraction,_ = self.posture_at(name,self.time)
        seconds = duration/1000
        rise_rate = dec(crouch_drop_m(actor_body(self,name),fraction,
            crouch_target(self,name,self.crouch_definition['target_leg_height_m'])))/seconds
        # Check current occupancy only. Future translation, other actors and
        # their phase boundaries are resolved by the live contact coordinator.
        groups = [(n,boxes,False) for n,boxes in self.world_bodies.items()
            if n!=name and self.fighters[n].hp>0]
        groups += [(n,boxes,True) for n,boxes in self.body_terrain_colliders().items()
            if n!=self.terrain_definition['ground']['id']]
        for box in self.world_bodies[name]:
            leg = box.part in ('left_leg','right_leg')
            offset = (D(0),D(0),rise_rate/2 if leg else rise_rate)
            size = (D(0),D(0),rise_rate if leg else D(0))
            for other,boxes,static in groups:
                for collider in boxes:
                    contact = first_box_contact(box,collider,offset,(0,0,0),seconds,
                        left_size_rate_mps=size)
                    if contact is not None and contact<seconds-D('1e-25'):
                        return False
        return True

    def start_combat_posture(self,actor):
        m,action = self.motion[actor.id],actor.current
        p = self.crouch_definition['characters'][actor.profile_id]
        if self._airborne(actor.id):
            self.note_action_cancelled(actor,action,'airborne_at_active_start')
            actor.current = None
            self.queue_mobile_intent(actor,action.ability_id,front=True)
            self.log('posture_deferred',actor=actor.id,reason='airborne_at_active_start')
            self.request_decision(actor.id,self.time)
            return
        fraction,_ = self.posture_at(actor.id,self.time)
        if action.ability_id=='stand' and not self.standing_clearance(actor.id,action.active_ms):
            actor.current = None
            actor.metrics['stand_requests_rejected'] += 1
            self.log('stand_rejected',actor=actor.id,reason='insufficient_clearance_at_active_start')
            self.request_decision(actor.id,self.time)
            return
        payment = self.action_payment(actor,action,p['listed_dyspnea_value'])
        if not payment.allowed:
            self.note_action_cancelled(actor,action,'active_start_capacity')
            actor.current = None
            self.queue_mobile_intent(actor,action.ability_id,front=True)
            self.log('posture_deferred',actor=actor.id,reason='active_start_capacity')
            self.request_decision(actor.id,self.time)
            return
        actor.dyspnea = dec(payment.after)
        actor.metrics['dyspnea_paid'] += dec(payment.action_value)
        if self.mobile_sprint_effort(actor.id):
            m['sprint_anchor'] = (self.time,actor.dyspnea)
        factor = dec(self.combat_locomotion_definition['running_self_effect_multiplier']) if self.mobile_is_running(actor.id) else D(1)
        additions = {k:dec(p['self_'+k+'_on_crouch'])*factor for k in ('disorientation','instability')}
        for key,value in additions.items():
            setattr(actor,key,getattr(actor,key)+value)
        cap_disorientation=D(0)
        if payment.reached_maximum:
            if self.mobile_sprint_effort(actor.id):
                # The existing sprint response owns the single cap trigger,
                # cancellation and free stop at this same timestamp.
                self._schedule_sprint_exhaustion(actor)
            else:
                extra = dec(payment.disorientation_trigger)*factor
                cap_disorientation=extra
                actor.disorientation += extra
                self.log('maximum_dyspnea_trigger',actor=actor.id,added_disorientation=extra,source='posture')
        m['pose_transition'] = {'from':fraction,'to':D(1) if action.ability_id=='crouch' else D(0),
            'start_ms':self.time,'duration_ms':action.active_ms}
        action.phase = 'active'
        action.active_end_ms = self.time+action.active_ms
        self.extend_parallel_gatherings(actor,additions['disorientation']+cap_disorientation,action.id)
        if action.ability_id=='crouch':
            actor.metrics['crouches_started'] += 1
        self.refresh_mobile_locomotion()
        self.log('dyspnea_paid',actor=actor.id,ability=action.ability_id,action_id=action.id,
            action_kind='posture',phase='active_start',before=dec(payment.before),amount=dec(payment.action_value),after=actor.dyspnea)
        self.log('posture_transition_started',actor=actor.id,action=action.ability_id,action_id=action.id,
            active_end_ms=action.active_end_ms,self_effects=additions)
        self._schedule_phase(action,'active_completed',action.active_end_ms)

    def complete_combat_posture(self,actor):
        m,action = self.motion[actor.id],actor.current
        m.update(crouch_fraction=m['pose_transition']['to'],pose_transition=None)
        actor.current = None
        actor.metrics['crouches_completed' if action.ability_id=='crouch' else 'stands_completed'] += 1
        self.refresh_mobile_locomotion()
        self.log('crouch_completed' if action.ability_id=='crouch' else 'stand_completed',
            actor=actor.id,action_id=action.id,body_origin_m=actor.body_origin_m)
        self.request_decision(actor.id,self.time)

    def freeze_combat_posture(self,actor,reason):
        if not self.posture_ready or self.motion[actor.id]['pose_transition'] is None:
            return
        body=actor.body_action()
        if body is not None and body.kind=='dodge' and body.phase=='active':
            self.cancel_owned_action(actor,body,reason)
            return
        m = self.motion[actor.id]
        fraction,_ = self.posture_at(actor.id,self.time)
        m.update(crouch_fraction=fraction,pose_transition=None)
        if actor.current is not None and actor.current.kind=='posture':
            self.note_action_cancelled(actor,actor.current,reason)
            actor.current = None
            self.request_decision(actor.id,self.time)
        actor.metrics['posture_interruptions'] += 1
        self.log('posture_interrupted',actor=actor.id,reason=reason,crouch_fraction=fraction)
        self.refresh_mobile_locomotion()

    def resolve_mobile_contacts(self,contacts):
        for c in contacts:
            if self.fighters[c['first']].hp<=0 or (c['second'] in self.fighters and self.fighters[c['second']].hp<=0):
                continue
            for name in (c['first'],c['second']):
                if name in self.fighters:
                    if self.equilibrium.enabled:
                        other=c['second'] if name==c['first'] else c['first']
                        self.equilibrium.freeze(name,'body_contact',blockers=(other,))
                    self.freeze_combat_posture(self.fighters[name],'body_contact')
        return super().resolve_mobile_contacts(contacts)

    def apply_air_contact_velocity(self,actor,velocity,contacts):
        if not self.posture_ready:
            return super().apply_air_contact_velocity(actor,velocity,contacts)
        actor.body_origin_m = (*actor.position_m,self.motion[actor.id]['body_reference_z'])
        extra = super().apply_air_contact_velocity(actor,velocity,contacts)
        self.motion[actor.id]['body_reference_z'] = dec(actor.body_origin_m[2])
        self._refresh_combat_posture()
        return extra

    def cancel_mobile_motion(self,actor):
        self.freeze_combat_posture(actor,'death')
        if self.posture_ready:
            actor.body_origin_m = (*actor.position_m,self.motion[actor.id]['body_reference_z'])
        super().cancel_mobile_motion(actor)

    def process_mobile_event(self,kind,payload):
        if kind=='movement_sprint_exhausted':
            self.freeze_combat_posture(self.fighters[payload['actor']],'sprint_exhaustion')
        return super().process_mobile_event(kind,payload)

    def mobile_result(self):
        result = super().mobile_result()
        if self.posture_combat is not None:
            result['movement_combat_scope']['actions'].extend(['crouch','stand'])
            result['movement_combat_scope']['posture'] = 'standing_crouched_and_linear_transitions'
            result['movement_combat_scope']['kind'] = ('ground_and_airborne_posture_combat'
                if self.airborne_enabled else 'ground_posture_combat')
        return result
