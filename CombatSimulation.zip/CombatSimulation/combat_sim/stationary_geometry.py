"""Position-centre geometry for the author's controlled stationary experiment.

This implements the confirmed inclusive radius test and nearest living enemy
selection. It does not infer hitboxes, accuracy, movement, or projectile cover.
Rational squared distances keep exact-radius membership and target ordering
independent of square-root display precision.
"""
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext

from combat_sim.models import UnsupportedMechanicError, as_fraction


def _position(value):
    if len(value) != 2:
        raise ValueError('A stationary position requires exactly two coordinates')
    return tuple(as_fraction(coordinate) for coordinate in value)


def squared_distance(first, second):
    x0, y0 = _position(first)
    x1, y1 = _position(second)
    return (x1 - x0) ** 2 + (y1 - y0) ** 2


def distance_metres(first, second, *, precision=50):
    if not isinstance(precision, int) or precision < 40:
        raise ValueError('Position distance precision must be at least 40 digits')
    squared = squared_distance(first, second)
    with localcontext(Context(prec=precision, rounding=ROUND_HALF_EVEN)):
        return (Decimal(squared.numerator) / Decimal(squared.denominator)).sqrt()


def within_radius(position, centre, radius_m):
    radius = as_fraction(radius_m)
    if radius < 0:
        raise ValueError('Area radius must be nonnegative')
    return squared_distance(position, centre) <= radius ** 2


def nearest_living_enemy(actor, participants):
    """Choose nearest living enemy, then stable instance identity on exact ties.

    Identity tie-breaking is a delegated deterministic policy default. It has
    no effect on unequal distances and never depends on insertion order.
    """
    source = participants[actor]
    if as_fraction(source['hp']) <= 0:
        return None
    candidates = {name: squared_distance(source['position_m'], data['position_m'])
                  for name, data in participants.items()
                  if data['team'] != source['team'] and as_fraction(data['hp']) > 0}
    if not candidates:
        return None
    closest = min(candidates.values())
    tied = sorted(name for name, distance in candidates.items() if distance == closest)
    return tied[0]
