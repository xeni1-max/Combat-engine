"""Fixed-yaw cuboids and exact narrow-phase queries, separate from turn control.

``bounds`` is an enclosing AABB for broad-phase use only. Actual containment,
area, segment, sphere sweep and box overlap use the stored orthonormal frame.
Sizes and size derivatives are along the shape's local axes.
"""
from dataclasses import dataclass
from decimal import Context,Decimal as D,ROUND_HALF_EVEN,localcontext
from fractions import Fraction as F
from itertools import product

from combat_sim.hitboxes import Cuboid,SphereContact
from combat_sim.orientation import YawFrame,scalar,vector3,dot

WORLD_AXES=((F(1),F(0),F(0)),(F(0),F(1),F(0)),(F(0),F(0),F(1)))


def axes(box):return box.frame.basis if isinstance(box,OrientedCuboid) else WORLD_AXES


def projected_size(box,axis,values=None):
    """Full projected dimension, or its derivative when supplied explicitly."""
    axis=vector3(axis);values=box.size_m if values is None else vector3(values)
    return sum((scalar(size)*abs(dot(axis,basis)) for size,basis in zip(values,axes(box))),F(0))


def separating_axes(first,second):
    """Complete deterministic unit-axis set for two upright yaw cuboids."""
    candidates=(*axes(first)[:2],*axes(second)[:2],WORLD_AXES[2]);result=set()
    for axis in candidates:
        first_nonzero=next(v for v in axis if v)
        result.add(tuple(-v for v in axis) if first_nonzero<0 else axis)
    return tuple(sorted(result))


def boxes_overlap(first,second,*,closed=True):
    delta=tuple(a-b for a,b in zip(vector3(first.centre_m),vector3(second.centre_m)))
    for axis in separating_axes(first,second):
        gap=(projected_size(first,axis)+projected_size(second,axis))/2-abs(dot(delta,axis))
        if gap<0 or not closed and gap==0:return False
    return True


def decimal_point(value):
    return tuple(D(v.numerator)/D(v.denominator) for v in vector3(value))


@dataclass(frozen=True)
class OrientedCuboid:
    part: str
    centre_m: tuple
    size_m: tuple
    frame: YawFrame

    def __post_init__(self):
        centre,size=vector3(self.centre_m),vector3(self.size_m)
        if not isinstance(self.part,str) or not self.part or any(v<=0 for v in size):
            raise ValueError('Oriented cuboid requires a name and positive dimensions')
        if not isinstance(self.frame,YawFrame):raise ValueError('Oriented cuboid requires an immutable yaw frame')
        object.__setattr__(self,'centre_m',centre);object.__setattr__(self,'size_m',size)

    @property
    def bounds(self):
        half=tuple(projected_size(self,axis)/2 for axis in WORLD_AXES)
        return tuple(c-r for c,r in zip(self.centre_m,half)),tuple(c+r for c,r in zip(self.centre_m,half))

    @property
    def local_box(self):return Cuboid(self.part,(0,0,0),self.size_m)

    def vertices(self):
        return tuple(self.frame.to_world_point(tuple(sign*v/2 for sign,v in zip(signs,self.size_m)),self.centre_m)
            for signs in product((-1,1),repeat=3))

    def contains(self,point):return self.local_box.contains(self.frame.to_local_point(point,self.centre_m))

    def closest_point(self,point):
        local=self.frame.to_local_point(point,self.centre_m);low,high=self.local_box.bounds
        return self.frame.to_world_point(tuple(min(b,max(a,p)) for p,a,b in zip(local,low,high)),self.centre_m)

    def intersects_sphere(self,centre_m,radius_m):
        return self.local_box.intersects_sphere(self.frame.to_local_point(centre_m,self.centre_m),radius_m)

    def intersects_vertical_column(self,centre_xy_m,radius_m):
        try:
            centre=tuple(centre_xy_m)
            if len(centre)!=2:raise ValueError
        except (TypeError,ValueError) as error:raise ValueError('Column centre needs two coordinates') from error
        local=self.frame.to_local_point((*centre,self.centre_m[2]),self.centre_m)
        return self.local_box.intersects_vertical_column(local[:2],radius_m)

    def segment_interval(self,start,end):
        return self.local_box.segment_interval(self.frame.to_local_point(start,self.centre_m),
            self.frame.to_local_point(end,self.centre_m))

    def swept_sphere_contact(self,start,end,radius_m,*,precision=50):
        if type(precision) is not int or precision<40:raise ValueError('Contact precision must be at least 40 digits')
        result=self.local_box.swept_sphere_contact(self.frame.to_local_point(start,self.centre_m),
            self.frame.to_local_point(end,self.centre_m),radius_m,precision=precision)
        if result is None:return None
        with localcontext(Context(prec=precision,rounding=ROUND_HALF_EVEN)):
            return SphereContact(self.part,result.parameter,
                decimal_point(self.frame.to_world_point(result.centre_m,self.centre_m)),
                decimal_point(self.frame.to_world_point(result.closest_box_point_m,self.centre_m)))


def place_local_cuboids(cuboids,origin_m,frame):
    if not isinstance(frame,YawFrame):raise ValueError('Body placement requires an immutable yaw frame')
    origin=vector3(origin_m);parts=tuple(cuboids)
    if any(not isinstance(box,Cuboid) for box in parts):raise ValueError('Local body parts must be declared cuboids')
    return tuple(OrientedCuboid(box.part,frame.to_world_point(box.centre_m,origin),box.size_m,frame) for box in parts)
