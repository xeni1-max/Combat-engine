"""One saved reference-translation prefix for prediction and advancement.

Pose deformation stays separate. This first backend saves the existing free/
grapple/climb polynomials; persistent constrained paths are a following backend.
"""
from dataclasses import dataclass
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.mechanics.velocity_projection import vector
from combat_sim.models import UnsupportedMechanicError,as_fraction

MATCH_EPS=F(1,10**35)


@dataclass(frozen=True)
class BodyDriver:
    structure: tuple
    free_velocity: tuple
    free_acceleration: tuple
    model_velocity: tuple
    model_acceleration: tuple
    nominal_speed: F
    nominal_acceleration: F


@dataclass(frozen=True)
class BodyPathFrame:
    begin_ms: F
    end_ms: F
    groups: tuple
    pieces: tuple
    drivers: tuple
    constraints: object = None


class SavedBodyPaths:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.ready=False;self.busy=False
        self.frame=None;self.frames_created=0;self.validated_signature=None;self.advancing=False
        if self.enabled and (definition!={'mode':'saved_polynomial_v1'} or not world.mobile_mode):
            raise UnsupportedMechanicError('Saved body paths need the moving world and a declared polynomial mode')

    def attach(self):
        if self.enabled:
            self.ready=True
            self.world.refresh_mobile_locomotion()

    def invalidate(self):self.frame=None;self.validated_signature=None

    def groups(self):return tuple(tuple(g) for g in self.world.grapple_links.groups())

    def heading_key(self,name):
        turns=getattr(self.world,'turns',None)
        return turns.key(name) if turns is not None else self.world.fighters[name].facing

    def semantic_boundary(self):
        w=self.world
        return min((e[0] for e in w.queue if e[0]>=w.time and e[3] not in ('sample','world_horizon')),default=w.horizon)

    def signature(self):
        w=self.world
        support=getattr(w,'body_support',None)
        return (w.time,getattr(w,'jump_gravity',None),self.semantic_boundary(),self.groups(),w.distance_constraints.signature(),
            support.signature() if support is not None else (),tuple((n,a.life_generation,a.hp>0,self.heading_key(n),a.armor,a.profile['max_hp'],a.instability,
            tuple(a.position_m),w.motion[n].get('body_reference_z',a.body_origin_m[2]),
            w.motion[n]['speed'],w.motion[n]['acceleration'],w.motion[n]['mode'],w.motion[n]['phase'],
            tuple(w.motion[n]['direction']),w.motion[n].get('sprint_anchor'),
            w.motion[n].get('revision',0),w.motion[n].get('support_id'),w.motion[n].get('support_part'),
            tuple(w.motion[n]['imposed_velocity']) if w.motion[n].get('imposed_velocity') is not None else None,
            tuple(w.motion[n].get('distance_inertial_velocity',(0,0,0))),
            tuple(w.motion[n]['jump']['velocity']) if w.motion[n].get('jump') is not None else None,
            w.motion[n].get('climb',{}).get('path') if w.motion[n].get('climb') is not None else None)
            for n,a in sorted(w.fighters.items())))

    def driver(self,name):
        w=self.world;a=w.fighters[name];m=w.motion[name]
        free=tuple(map(vector,w.free_mobile_motion(name)))
        model=tuple(map(vector,w.raw_body_motion(name)))
        structure=(a.life_generation,a.hp>0,self.heading_key(name),as_fraction(a.armor),as_fraction(a.profile['max_hp']),
            m['mode'],m['phase'],m.get('revision',0),m.get('support_id'),m.get('support_part'),
            m.get('jump') is not None,w._climbing(name),
            m.get('sprint_anchor'),
            vector(m['imposed_velocity']) if m.get('imposed_velocity') is not None else None)
        return BodyDriver(structure,*free,*model,as_fraction(m['speed']),as_fraction(m['acceleration']))

    @staticmethod
    def close(left,right):return all(abs(a-b)<=MATCH_EPS for a,b in zip(left,right))

    def matches(self,frame):
        w=self.world;now=as_fraction(w.time)
        if not frame.begin_ms<=now<=frame.end_ms or frame.groups!=self.groups():return False
        seconds=(now-frame.begin_ms)/1000;pieces=dict(frame.pieces)
        for name,saved in frame.drivers:
            current=self.driver(name)
            constrained=frame.constraints is not None and name in frame.constraints.names
            structure=lambda d:tuple(v for i,v in enumerate(d.structure) if not constrained or i not in (8,9,10,13))
            if structure(current)!=structure(saved) or current.nominal_acceleration!=saved.nominal_acceleration:return False
            if abs(current.nominal_speed-max(F(0),saved.nominal_speed+saved.nominal_acceleration*seconds))>MATCH_EPS:return False
            if constrained:
                m=w.motion[name]
                if m['jump'] is not None or m.get('imposed_velocity') is not None:
                    if not self.close(current.free_velocity,pieces[name].velocity(now)):return False
                else:
                    residue=vector(m.get('distance_inertial_velocity',(0,0,0)))
                    independent=tuple(v-i for v,i in zip(current.free_velocity,residue))
                    requested=dict(frame.constraints.ground_requested).get(name,saved.free_velocity)
                    expected=tuple(v+a*seconds for v,a in zip(requested,saved.free_acceleration))
                    support=getattr(w,'body_support',None)
                    if support is not None and support.gravity(name):expected=(*expected[:2],requested[2])
                    if not self.close(independent,expected):return False
            else:
                for v,a,expected_v,expected_a in ((current.free_velocity,current.free_acceleration,saved.free_velocity,saved.free_acceleration),
                    (current.model_velocity,current.model_acceleration,saved.model_velocity,saved.model_acceleration)):
                    if not self.close(a,expected_a) or not self.close(v,tuple(x+y*seconds for x,y in zip(expected_v,expected_a))):return False
            tolerance=F(1,10**22) if constrained else MATCH_EPS
            if any(abs(a-b)>tolerance for a,b in zip(vector(w.spatial_transitions.reference(name)),pieces[name].position(now))):return False
        return True

    def build(self):
        w=self.world;now=as_fraction(w.time);end=as_fraction(w.horizon)
        knot=as_fraction(w.raw_body_knot(w.horizon))
        if knot>=now:end=min(end,knot)
        end=min(end,as_fraction(self.semantic_boundary()))
        end=max(now,end);groups=self.groups();joined={n for group in groups for n in group}
        drivers=[];pieces=[]
        for name in sorted(w.fighters):
            d=self.driver(name);reference=vector(w.spatial_transitions.reference(name));velocity=d.model_velocity
            if w._climbing(name) and name not in joined and end>now:
                # Source climb corners/endpoints have canonical exact positions.
                # Fit the saved segment to their declared absolute clock, rather
                # than accumulating a nonterminating rounded speed per sample.
                destination=vector(w._climb_state(name,dec(end)).position_m)
                velocity=tuple((b-a)*1000/(end-now) for a,b in zip(reference,destination))
            pieces.append((name,BodyPathPiece(now,end,reference,velocity,d.model_acceleration)))
            drivers.append((name,d))
        self.frames_created+=1
        pieces,end,constraints=w.distance_constraints.compile(tuple(pieces),tuple(drivers),end)
        departure=min(w.terrain_support.departure(pieces,end),w.distance_constraints.angular_contact_departure(pieces,end))
        if departure<end:
            # Queue/advancement clocks use the declared Decimal context. Keep
            # the saved lease at that same representable clock, as the distance
            # compiler does, so rounding cannot put consumption past its end.
            end=as_fraction(dec(departure))
            pieces=tuple((name,piece.slice(now,end)) for name,piece in pieces)
        return BodyPathFrame(now,end,groups,tuple(pieces),tuple(drivers),constraints)

    def ensure(self,*,future=False):
        with localcontext(Context(prec=self.world.precision)):
            return self._ensure(future=future)

    def _ensure(self,*,future=False):
        if not self.ready:raise ValueError('Saved body paths are not attached')
        if self.busy:raise RuntimeError('Recursive saved-body-path construction')
        signature=self.signature()
        moving_boundary=(self.frame is not None and future and self.frame.end_ms<=as_fraction(self.world.time)<as_fraction(self.world.horizon))
        if self.frame is not None and signature==self.validated_signature and not moving_boundary:return self.frame
        self.busy=True
        try:
            valid=self.frame is not None and self.matches(self.frame)
            if not valid or moving_boundary:
                self.frame=self.build()
            elif as_fraction(self.semantic_boundary())<self.frame.end_ms:
                # A newly queued semantic event shortens the lease without
                # reanchoring its polynomial at an observation/query time.
                f=self.frame;end=as_fraction(self.semantic_boundary())
                self.frame=BodyPathFrame(f.begin_ms,end,f.groups,
                    tuple((n,p.slice(f.begin_ms,end)) for n,p in f.pieces),f.drivers,f.constraints)
            self.validated_signature=signature
            return self.frame
        finally:self.busy=False

    def motion(self,name):
        with localcontext(Context(prec=self.world.precision)):
            frame=self.ensure();piece=dict(frame.pieces)[name]
            return tuple(map(dec,piece.velocity(self.world.time))),tuple(map(dec,piece.acceleration_mps2))

    def limit(self,end):
        with localcontext(Context(prec=self.world.precision)):
            return min(end,dec(self.ensure(future=True).end_ms))

    def advance(self,begin,end):
        with localcontext(Context(prec=self.world.precision)):
            return self._advance(begin,end)

    def _advance(self,begin,end):
        frame=self.ensure(future=True);w=self.world;seconds=(as_fraction(end)-frame.begin_ms)/1000
        if begin!=w.time or end<begin or as_fraction(end)>frame.end_ms:
            raise ValueError('Body advancement needs an increasing saved path prefix')
        drivers=dict(frame.drivers);pieces=dict(frame.pieces);self.busy=True;self.advancing=True
        try:
            for name in sorted(w.fighters):
                a=w.fighters[name];m=w.motion[name];d=drivers[name]
                if a.hp>0:
                    m['speed']=dec(max(F(0),d.nominal_speed+d.nominal_acceleration*seconds))
                    if m.get('jump') is not None and (frame.constraints is None or name not in frame.constraints.names):
                        m['jump']['velocity']=tuple(dec(v+q*seconds) for v,q in zip(d.free_velocity,d.free_acceleration))
                revision=m.get('spatial_revision')
                w.set_body_reference(name,pieces[name].position(end))
                # Consuming an observation prefix is not a new spatial command.
                if revision is None:m.pop('spatial_revision',None)
                else:m['spatial_revision']=revision
            w.distance_constraints.commit(frame,end)
            if hasattr(w,'body_support'):w.body_support.committed(frame,end)
            for group in frame.groups:
                if end==begin and frame.constraints is not None and any(n in frame.constraints.names for n in group):continue
                velocity=tuple(map(dec,pieces[group[0]].velocity(end)))
                for name in group:w.motion[name]['ground_origin_z']=dec(pieces[name].position(end)[2])
                w._sync_link_vertical(group,velocity)
        finally:self.busy=False;self.advancing=False

    def result(self):
        if not self.enabled:return {}
        frame=self.ensure()
        return {'body_path_rules':self.world.combat_locomotion_input['body_paths'],
            'body_path_frames_created':self.frames_created,
            'current_body_path_pieces':{n:{'life_generation':dict(frame.drivers)[n].structure[0],**p.record()} for n,p in frame.pieces}}


class SavedBodyPathRules:
    def refresh_mobile_locomotion(self):
        result=super().refresh_mobile_locomotion()
        if hasattr(self,'motion'):
            for name,m in self.motion.items():
                if m.get('distance_inertial_velocity') is not None:
                    velocity=self.mobile_motion(name)[0]
                    self.fighters[name].locomotion.update(speed_mps=str(sum(v*v for v in velocity[:2]).sqrt()),
                        motion_driver='transmitted_inertia')
                frame=self.body_paths.frame if hasattr(self,'body_paths') else None
                if frame is not None and frame.constraints is not None and name in frame.constraints.names:
                    velocity=self.mobile_motion(name)[0];state=self.fighters[name].locomotion
                    state.update(speed_mps=str(sum(v*v for v in velocity[:2]).sqrt()),distance_response=True)
                    state.setdefault('motion_driver','constrained')
        return result

    def raw_body_motion(self,name):return super().mobile_motion(name)
    def raw_body_knot(self,end):return super().next_mobile_knot(end)

    def mobile_motion(self,name):
        paths=getattr(self,'body_paths',None)
        if paths is None or not paths.ready or paths.busy:return super().mobile_motion(name)
        return paths.motion(name)

    def mobile_contact_velocity(self,name,seconds):
        paths=getattr(self,'body_paths',None)
        prescribed=self._climbing(name)
        if prescribed and paths is not None and paths.ready and not paths.busy:
            frame=paths.ensure()
            if frame.constraints is not None and name in frame.constraints.names:
                prescribed=self.distance_constraints.climb_compatible(name,dict(frame.pieces)[name])
        if paths is None or not paths.ready or paths.busy or prescribed:
            return super().mobile_contact_velocity(name,seconds)
        v,a=self.mobile_motion(name)
        return tuple(x+y*seconds for x,y in zip(v,a))

    def next_mobile_knot(self,end):
        finish=super().next_mobile_knot(end)
        paths=getattr(self,'body_paths',None)
        return paths.limit(finish) if paths is not None and paths.ready and not paths.busy else finish

    def advance_mobile_geometry(self,begin,end):
        if not self.body_paths.ready:return super().advance_mobile_geometry(begin,end)
        if self.settle_climb_attachments():
            self.body_paths.invalidate();self.refresh_mobile_locomotion()
        return self.body_paths.advance(begin,end)

    def resolve_mobile_contacts(self,contacts):
        result=super().resolve_mobile_contacts(contacts)
        self.distance_constraints.contact_resolved(contacts)
        return result
