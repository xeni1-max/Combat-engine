"""The existing Aim toggle uses ordinary owned Recovery/Gathering/Active phases."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext

from combat_sim.battle_models import BattleAction,decimal_value as dec
from combat_sim.mechanics.life import life_generation
from combat_sim.pose_kinematics import physical_hand_recovery
from combat_sim.models import UnsupportedMechanicError

COMMANDS=('toggle_aim','aim_on','aim_off')


class AimControl:
    def __init__(self,world,enabled=False):self.world=world;self.enabled=enabled;self.states={};self.pending={}

    def validate_actor(self,name):
        if not self.enabled or not isinstance(name,str) or name not in self.states:raise ValueError('Actor has no current Aim ability')

    def attach(self):
        if not self.enabled:return
        w=self.world
        for a in w.fighters.values():
            key=a.profile.get('aim_control_ability')
            if key is None:continue
            ability=a.profile['abilities'][key];timing=a.profile['timing_profiles'][ability['timing_profile']]
            if (ability.get('execution_model')!='aim_toggle' or dec(timing['active_ms'])<=0 or
                    dec(timing['gathering_ms'])<0 or ability['dyspnea']!={'kind':'none'} or
                    any(set(ability['hand_positions_m'][p])!=set(a.hands) for p in ('start','end'))):
                raise ValueError('Invalid source Aim profile')
            if w.ownership_definition['actions'].get('aim_toggle')!={'occupies':['hands','focus:aim'],
                    'requires':['upper_body','hand:left','hand:right']}:raise ValueError('Aim needs declared hand/focus requirements')
            self.states[a.id]=dict(actor=a.id,ability=key,life_generation=a.life_generation,aiming=False)
            w.effort_system.validate_ability(a,key)

    def effective(self,name):
        row=self.states.get(name)
        if row is None:return False
        a=self.world.fighters[name]
        return a.hp>0 and row['life_generation']==a.life_generation and row['aiming'] and not self.running(name)

    def running(self,name):return self.world.mobile_is_running(name) or self.world.motion[name]['mode']=='sprinting'

    def command(self,name,command,*,expected_life_generation=None):
        with localcontext(Context(prec=self.world.precision)):
            self.validate_actor(name)
            if command not in COMMANDS:raise ValueError('Unknown Aim control')
            w=self.world;a=w.fighters[name]
            generation=a.life_generation if expected_life_generation is None else life_generation(expected_life_generation)
            if a.hp<=0 or generation!=a.life_generation:return dict(status='ignored',reason='actor_life_ended')
            self.settle();row=self.states[name];old=self.pending.get(name)
            current=old['desired'] if old is not None else row['aiming']
            desired=not current if command=='toggle_aim' else command=='aim_on'
            if desired and self.running(name):return dict(status='ignored',reason='aim_unavailable_while_running')
            if old is not None and old['desired']==desired:return dict(status='duplicate',action_id=old['action_id'])
            if old is not None:
                self.pending.pop(name)
                action=a.action_by_id(old['action_id']) if old['action_id'] is not None else None
                if action is not None:w.cancel_owned_action(a,action,'aim_request_replaced')
            if row['aiming']==desired:return dict(status='unchanged',aiming=desired)
            self.pending[name]=dict(actor=name,life_generation=a.life_generation,desired=desired,requested_at_ms=w.time,action_id=None)
            w.request_decision(name,w.time)
            return dict(status='queued',aiming=desired)

    def try_pending(self,actor):
        row=self.pending.get(actor.id)
        if row is None or row['action_id'] is not None:return
        if self.running(actor.id):return self.clear(actor.id,'running')
        if actor.knocked_down:return
        w=self.world;key=self.states[actor.id]['ability'];a=actor.profile['abilities'][key]
        req=w.action_requirements(actor,'aim_toggle',key,'recovery')
        if any(actor.action_registry.unavailable(req)):return
        timing=actor.profile['timing_profiles'][a['timing_profile']]
        recovery,individual=physical_hand_recovery(w,actor,actor.hands,a['hand_positions_m']['start'],
            dec(actor.profile['recovery_value']),equilibrium_legacy=True)
        action=BattleAction(next(w.action_ids),actor.id,actor.id,key,'aim_toggle',w.time,w.time+recovery,
            dec(timing['active_ms']),phase='recovery',recovery_end_ms=w.time+recovery,
            base_gathering_ms=dec(timing['gathering_ms']),life_generation=actor.life_generation)
        actor.current=action;row['action_id']=action.id
        actor.metrics['activations_started']+=1;w.effort_system.action_started(actor,action)
        w.log('aim_toggle_started',actor=actor.id,desired=row['desired'],action=action.record(),individual_hands=individual)
        w._schedule_phase(action,'recovery_completed',action.recovery_end_ms)

    def complete(self,actor,action):
        row=self.pending.get(actor.id)
        if row is None or row['action_id']!=action.id:return False
        if self.running(actor.id):
            self.clear(actor.id,'running');return False
        self.states[actor.id]['aiming']=row['desired'];self.pending.pop(actor.id)
        self.world.log('aim_toggled',actor=actor.id,action_id=action.id,aiming=row['desired'],life_generation=actor.life_generation)
        return True

    def action_cancelled(self,actor,action,reason):
        row=self.pending.get(actor.id)
        if row is not None and row['action_id']==action.id:
            self.pending.pop(actor.id);self.world.log('aim_toggle_cancelled',actor=actor.id,action_id=action.id,reason=reason)

    def clear(self,name,reason):
        row=self.states[name];pending=self.pending.pop(name,None);changed=row['aiming'] or pending is not None
        row['aiming']=False
        if pending is not None and pending['action_id'] is not None:
            a=self.world.fighters[name];action=a.action_by_id(pending['action_id'])
            if action is not None:self.world.cancel_owned_action(a,action,'aim_'+reason)
        if changed:self.world.log('aim_cleared',actor=name,reason=reason,life_generation=row['life_generation'])

    def settle(self):
        if not self.enabled:return
        for name,row in self.states.items():
            a=self.world.fighters[name]
            if a.hp<=0 or a.life_generation!=row['life_generation']:
                self.clear(name,'actor_life_ended');row['life_generation']=a.life_generation
            elif self.running(name):self.clear(name,'running')

    def result(self):
        return dict(aim_states=deepcopy(self.states),pending_aim_controls=deepcopy(list(self.pending.values()))) if self.enabled else {}
