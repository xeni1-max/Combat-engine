"""Owned enhancement activation, life-bound grants and immutable release snapshots."""
from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.attack_modifiers import ModifierValues
from combat_sim.models import UnsupportedMechanicError


@dataclass(frozen=True)
class AttackModifierSnapshot:
    attack_id: str
    actor: str
    ability: str
    action_id: int
    source_life_generation: int
    released_at_ms: Decimal
    modifier_ids: tuple[str,...]
    values: ModifierValues
    passive_ids: tuple[str,...] = ()
    component_id: str | None = None

    def record(self):
        return {k:deepcopy(v) for k,v in vars(self).items() if k!='values' and
            (k not in ('passive_ids','component_id') or v)}|{
            'values':{k:dec(v) for k,v in self.values.record().items()}}


class AttackModifiers:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'release_snapshot_v1'} or
                not world.life_cycles.enabled or not world.effort_system.enabled):
            raise UnsupportedMechanicError('Attack modifiers require current life and phase effort rules')
        self.ids=count(1);self.grants={};self.snapshots={};self.passives={}

    def attach_passives(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            for ability,cfg in actor.profile.get('passive_effects',{}).items():
                if cfg.get('execution_model')!='attack_modifier_passive':continue
                if (set(cfg)-{'execution_model','scope_ability','values','dyspnea','source'} or
                        cfg.get('dyspnea',{}).get('kind')!='none' or
                        cfg.get('scope_ability')!='*' and cfg.get('scope_ability') not in actor.profile.get('abilities',{})):
                    raise UnsupportedMechanicError('Unsupported passive attack modifier definition')
                try:values=ModifierValues(**cfg['values'])
                except TypeError as error:raise ValueError('Unknown passive attack modifier value') from error
                identity='passive-modifier:'+str(len(self.passives)+1)
                self.passives[identity]={'id':identity,'actor':actor.id,'ability':ability,
                    'scope_ability':cfg['scope_ability'],'values':{k:dec(v) for k,v in values.record().items()},
                    'source':cfg.get('source')}

    def validate(self,actor,ability_id):
        if not self.enabled:raise UnsupportedMechanicError('Attack enhancements require shared modifier rules')
        a=actor.profile['abilities'][ability_id];m=a.get('modifier',{})
        if (a.get('dyspnea',{}).get('kind')!='none' or
                a.get('hand_positions_m')!={'start':{},'end':{}} or
                a.get('cooldown_anchor')!='activation_start' or
                a.get('deployment_timing')!='active_end' or
                actor.profile['documented_abilities'][ability_id]['effort_phases'][a['effort_phase']]['category']!='extrinsic_momentary'):
            raise UnsupportedMechanicError('Unsupported enhancement activation rules')
        if m.get('scope_ability') not in actor.profile['abilities']:
            raise UnsupportedMechanicError('Enhancement needs an integrated recipient attack')
        if actor.profile['abilities'][m['scope_ability']]['execution_model'] not in ('venomous_thrust','component_melee','conditional_melee'):
            raise UnsupportedMechanicError('This attack delivery has no modifier capture boundary yet')
        if m.get('kind') not in ('next_attack','timed'):
            raise ValueError('Enhancement must be next-attack or timed')
        expected={'scope_ability','kind','values'}|({'duration_ms'} if m['kind']=='timed' else set())
        if set(m)!=expected or not isinstance(m['values'],dict) or not m['values']:
            raise ValueError('Enhancement needs explicit modifier values/lifetime')
        try:ModifierValues(**m['values'])
        except TypeError as error:raise ValueError('Unknown attack modifier value') from error
        if dec(a.get('cooldown_ms',0))<=0 or (m['kind']=='timed' and dec(m['duration_ms'])<=0):
            raise ValueError('Enhancement durations must be positive')

    def grant(self,actor,action,ability):
        m=ability['modifier'];world=self.world
        for row in self.grants.values():
            if row['actor']==actor.id and row['ability']==action.ability_id and row['status']=='active':
                self._end(row,'replaced')
        identity='modifier:'+str(next(self.ids))
        row={'id':identity,'actor':actor.id,'ability':action.ability_id,'action_id':action.id,
            'source_life_generation':action.life_generation,'scope_ability':m['scope_ability'],
            'kind':m['kind'],'start_ms':world.time,
            'expiry_ms':world.time+dec(m['duration_ms']) if m['kind']=='timed' else None,
            'values':{k:dec(v) for k,v in ModifierValues(**m['values']).record().items()},'status':'active'}
        self.grants[identity]=row
        if row['expiry_ms'] is not None:world.push(row['expiry_ms'],'attack_modifier_expired',{'modifier_id':identity})
        world.log('attack_modifier_granted',modifier=deepcopy(row))

    def _end(self,row,reason,*,attack_id=None):
        row.update(status='ended',ended_at_ms=self.world.time,end_reason=reason)
        if attack_id is not None:row['consumed_by_attack_id']=attack_id
        self.world.log('attack_modifier_ended',modifier=deepcopy(row))

    def live(self,payload):
        return self.grants[payload['modifier_id']]['status']=='active'

    def expire(self,payload):
        row=self.grants[payload['modifier_id']]
        if row['status']=='active':self._end(row,'expired')

    def retire_life(self,actor):
        for row in self.grants.values():
            if (row['actor']==actor.id and row['source_life_generation']==actor.life_generation
                    and row['status']=='active'):self._end(row,'owner_death')

    def capture(self,actor,action,attack_id):
        if not self.enabled:return
        if attack_id in self.snapshots:
            old=self.snapshots[attack_id]
            if (old.actor,old.ability,old.action_id,old.source_life_generation,old.component_id)!=(
                    actor.id,action.ability_id,action.id,action.life_generation,getattr(action,'component_id',None)):
                raise ValueError('Attack modifier snapshot identity cannot be reassigned')
            return old
        values=ModifierValues();identities=[]
        passive_ids=[]
        for identity,row in self.passives.items():
            if row['actor']==actor.id and row['scope_ability'] in ('*',action.ability_id):
                values=values.combine(ModifierValues(**row['values']));passive_ids.append(identity)
        for identity,row in self.grants.items():
            if (row['status']!='active' or row['actor']!=actor.id or row['scope_ability']!=action.ability_id
                    or row['source_life_generation']!=action.life_generation
                    or row['start_ms']>self.world.time
                    or row['expiry_ms'] is not None and row['expiry_ms']<=self.world.time):continue
            values=values.combine(ModifierValues(**row['values']));identities.append(identity)
            if row['kind']=='next_attack':self._end(row,'consumed',attack_id=attack_id)
        snapshot=AttackModifierSnapshot(attack_id,actor.id,action.ability_id,action.id,
            action.life_generation,self.world.time,tuple(identities),values,tuple(passive_ids),getattr(action,'component_id',None))
        self.snapshots[attack_id]=snapshot
        self.world.log('attack_modifiers_captured',**snapshot.record())
        return snapshot

    def values(self,packet):
        snapshot=self.snapshots.get(packet.get('attack_id'))
        return snapshot.values if snapshot is not None else ModifierValues()

    def piercing(self,packet,ability):
        return dec(ability.get('piercing',0))+dec(self.values(packet).additional_piercing)

    def result(self):
        if not self.enabled:return {}
        return {'attack_modifier_rules':self.world.combat_locomotion_input['attack_modifiers'],
            **({'passive_attack_modifiers':deepcopy(list(self.passives.values()))} if self.passives else {}),
            'attack_modifiers':deepcopy(list(self.grants.values())),
            'released_attack_modifiers':[s.record() for s in self.snapshots.values()]}
