"""One iterative movement-intent dispatcher and explicit prerequisite ownership.

Handlers start one legal step or return an outcome. Only this coordinator owns
the queue, so consuming a no-op always dispatches the next action family again.
"""
from dataclasses import dataclass, replace
from enum import Enum, auto


@dataclass(frozen=True)
class MovementIntent:
    id: int
    action: str
    target: str | None = None


class IntentOutcome(Enum):
    STARTED = auto()
    WAITING = auto()
    CONSUMED = auto()
    REJECTED = auto()
    STOP_FALLBACK = auto()


class MovementCommandRules:
    def setup_mobile_combat(self,definition,effects):
        super().setup_mobile_combat(definition,effects)
        for m in self.motion.values():
            m['active_intent'] = None

    def queue_mobile_intent(self,actor,action,*,target=None,front=False):
        intent = MovementIntent(next(self.intent_ids),action,target)
        queue = self.motion[actor.id]['intents']
        queue.insert(0,intent) if front else queue.append(intent)
        return intent

    def process_mobile_event(self,kind,payload):
        if kind=='movement_command':
            actor = self.fighters[payload['actor']]
            if actor.hp <= 0:
                self.log('movement_intent_rejected',actor=actor.id,action=payload['action'],reason='dead')
                return
            self.queue_mobile_intent(actor,payload['action'],target=payload.get('target'))
            actor.metrics['movement_commands'] += 1
            extra = {'target':payload['target']} if 'target' in payload else {}
            self.log('movement_intent_received',actor=actor.id,action=payload['action'],**extra)
            self.request_decision(actor.id,self.time)
            return
        if kind=='movement_sprint_exhausted':
            self.block_mobile_intent(self.fighters[payload['actor']],'sprint_exhaustion')
        return super().process_mobile_event(kind,payload)

    def _movement_step(self,actor,intent):
        m = self.motion[actor.id]
        step = intent.action
        if step=='climb':
            if self.collider_system.climb_target(intent.target) is None:
                return step
            if self.posture_ready and self.posture_at(actor.id,self.time)[0] != 0:
                step = 'stand'
            elif m['mode']=='sprinting':
                step = 'run'
        if step=='jump' and m['mode']=='sprinting':
            step = 'run'
        if step=='sprint' and m['mode'] in ('standing','walking'):
            step = 'run'
        if step=='walk' and m['mode']=='sprinting':
            step = 'run'
        if step=='run' and m['mode']=='standing':
            step = 'walk'
        return step

    def try_mobile_intent(self,actor):
        m = self.motion[actor.id]
        if self._airborne(actor.id):
            return False
        while m['intents']:
            intent = m['intents'][0]
            step = self._movement_step(actor,intent)
            if not self.movement_step_available(actor,step):
                return True
            if step in ('crouch','stand'):
                outcome = self.try_posture_step(actor,step)
            elif step=='jump':
                outcome = self.try_jump_step(actor)
            elif step=='climb':
                outcome = self.try_climb_step(actor,intent.target)
            elif step=='sprint' or (step=='run' and m['mode']=='sprinting'):
                outcome = self.request_sprint_transition(actor,step)
            else:
                outcome = self.try_ground_step(actor,step)
            if outcome is IntentOutcome.STARTED:
                m['active_intent'] = intent
                if step==intent.action:
                    m['intents'].pop(0)
                return True
            if outcome is IntentOutcome.WAITING:
                return True
            if outcome is IntentOutcome.STOP_FALLBACK:
                m['intents'][0] = replace(intent,action='stop',target=None)
                continue
            if outcome not in (IntentOutcome.CONSUMED,IntentOutcome.REJECTED):
                raise RuntimeError('Movement handler did not return an explicit outcome')
            if outcome is IntentOutcome.REJECTED and step!=intent.action:
                self.log('movement_intent_rejected',actor=actor.id,action=intent.action,
                    reason='prerequisite_rejected',prerequisite=step)
            m['intents'].pop(0)
        return False

    def block_mobile_intent(self,actor,reason):
        m = self.motion[actor.id]
        intent = m.get('active_intent')
        if intent is None:
            return
        m['intents'] = [item for item in m['intents'] if item.id != intent.id]
        m['active_intent'] = None
        self.log('movement_intent_blocked',actor=actor.id,action=intent.action,
            intent_id=intent.id,reason=reason,retry='requires_new_command')

    def resolve_mobile_contacts(self,contacts):
        for c in contacts:
            # A blocked pose deformation does not block tangential reference
            # motion. Forward the contact so posture can freeze the pose.
            if c.get('pose_only') or c.get('angular_collision') and not self.reference_contact_closing(c):
                continue
            if self.fighters[c['first']].hp<=0 or (c['second'] in self.fighters and self.fighters[c['second']].hp<=0):
                continue
            for name in (c['first'],c['second']):
                if name not in self.fighters:
                    continue
                actor,m = self.fighters[name],self.motion[name]
                if actor.current is not None and (actor.current.kind=='locomotion' and m['phase']!='stopping_active'
                        or actor.current.kind in ('posture','climb') and actor.current.phase=='active'):
                    self.block_mobile_intent(actor,'body_contact')
        return super().resolve_mobile_contacts(contacts)

    def complete_mobile_action(self,actor):
        self.motion[actor.id]['active_intent'] = None
        return super().complete_mobile_action(actor)

    def complete_basic_jump(self,actor):
        self.motion[actor.id]['active_intent'] = None
        return super().complete_basic_jump(actor)

    def complete_combat_posture(self,actor):
        self.motion[actor.id]['active_intent'] = None
        return super().complete_combat_posture(actor)

    def complete_combat_climb(self,actor):
        self.motion[actor.id]['active_intent'] = None
        return super().complete_combat_climb(actor)

    def interrupt_combat_climb(self,actor,reason,**kwargs):
        if self._climbing(actor.id):self.block_mobile_intent(actor,reason)
        return super().interrupt_combat_climb(actor,reason,**kwargs)

    def cancel_mobile_motion(self,actor):
        self.motion[actor.id]['active_intent'] = None
        return super().cancel_mobile_motion(actor)
