"""Source balance clock and one shared accelerated prone deformation channel.

The saved body-path writer still owns translation. This component owns pose
progress and numerical pose boundaries; common Get Up retains action/payment
ownership. See EQUILIBRIUM.md for delegated geometry and recovery choices.
"""
from dataclasses import dataclass,replace
from decimal import Context,Decimal as D,ROUND_CEILING,localcontext
from fractions import Fraction as F

from combat_sim.character_geometry import actor_body,crouch_target
from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import combined_bounds,local_to_world_point
from combat_sim.mechanics.equilibrium import BalancePiece,balance_piece,fall_duration_ms
from combat_sim.mechanics.exact_ratio import ratio_text
from combat_sim.models import UnsupportedMechanicError,as_fraction
from combat_sim.postures import body_origin_from_bounds
from combat_sim.prone import prone_morph

ZERO=(D(0),)*3
STATUS_EPS=D('1e-24')


@dataclass
class BalanceState:
    life_generation: int
    progress: F = F(0)
    piece: object = None
    revision: int = 0
    anchor_ms: D = D(0)
    source_o: D = D(0)
    source_u: D = D(0)
    pose_signature: object = None
    blocked: bool = False
    waiting_get_up: bool = False
    forced_rate: object = None
    get_up_action_id: object = None
    event_at_ms: object = None
    driver_signature: object = None
    clearance_blockers: tuple = ()


class Equilibrium:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.ready=False
        self.states={};self.templates={};self.segments=0;self.boundaries=0
        self.history=[];self.last_interval={}
        self.deformation_clock=None;self.deformation_cache={}
        self.progress_cache={}
        if self.enabled and (definition!={'mode':'status_balance_v1'} or not world.mobile_mode or not world.body_paths.enabled):
            raise UnsupportedMechanicError('Equilibrium needs the saved-path moving world and status_balance_v1 rules')

    def basis(self,name):
        if name not in self.templates:
            c=self.world.movement_input.get('crouch',{})
            if 'target_leg_height_m' not in c:raise ValueError('Equilibrium requires the current crouch geometry')
            self.templates[name]=prone_morph(actor_body(self.world,name),0,
                crouch_target(self.world,name,c['target_leg_height_m']))
        return self.templates[name]

    def state(self,name):
        actor=self.world.fighters[name];row=self.states.get(name)
        if row is None:
            row=BalanceState(actor.life_generation,F(1) if actor.knocked_down else F(0))
            self.states[name]=row
        elif row.life_generation!=actor.life_generation:
            q=self.at(name,self.world.time)[0]
            row=BalanceState(actor.life_generation,q);self.states[name]=row
            actor.knocked_down=actor.knocked_down or q==1
        return row

    def initial_body(self,name,reference,facing):
        row=self.state(name)
        return self.basis(name).world_parts(reference,facing,row.progress)

    def attach(self):
        if not self.enabled:return
        w=self.world
        if not (w.posture_ready and w.airborne_enabled and w.ownership_definition is not None):
            raise UnsupportedMechanicError('Equilibrium needs current owned posture and body physics')
        self.ready=True
        for name in w.fighters:
            self.state(name)
            if w.fighters[name].knocked_down:w.request_decision(name,w.time)
        self.settle();w.refresh_mobile_locomotion()

    def at(self,name,time):
        row=self.states.get(name)
        if row is None:return F(0),F(0),F(0)
        piece=row.piece
        if piece is None:return row.progress,F(0),F(0)
        requested=as_fraction(time)
        # A constant validated piece has the same value at every clamped
        # clock. Avoid two rational polynomial evaluations for every part
        # query while preserving input validation and out-of-lease behavior.
        if not piece.velocity_per_s and not piece.acceleration_per_s2:
            return piece.progress,F(0),F(0)
        cached=self.progress_cache.get(name)
        if cached is not None and cached[0] is piece and cached[1]==requested:
            return cached[2]
        clock=min(piece.end_ms,max(piece.begin_ms,requested))
        q=piece.at(clock);v=piece.rate(clock);a=piece.acceleration_per_s2
        if requested>piece.end_ms:v=a=F(0)
        result=min(F(1),max(F(0),q)),v,a
        # One immutable polynomial/clock result per actor, never a history.
        # A replacement piece or any different requested time misses directly.
        self.progress_cache[name]=(piece,requested,result)
        return result

    def carries(self,name,time=None):
        if not self.enabled or name not in self.states:return False
        q,v,a=self.at(name,self.world.time if time is None else time)
        return bool(q or v or a)

    def moving(self,name,time):
        if not self.carries(name,time) or self.world.fighters[name].hp<=0:return False
        _,v,a=self.at(name,time)
        return bool(v or a)

    def pose(self,name,time):
        q,v,a=self.at(name,time);c,cv=self.world.posture_at(name,dec(time))
        return replace(self.basis(name),crouch_fraction=as_fraction(c)),q,v,a,as_fraction(cv)

    def boxes(self,name,reference,time=None):
        morph,q,_,_,_=self.pose(name,self.world.time if time is None else time)
        return morph.world_parts(reference,self.world.fighters[name].facing,q)

    def deformation(self,name,part,time):
        if not self.carries(name,time):return ZERO,ZERO,ZERO,ZERO
        clock=as_fraction(time)
        if clock!=self.deformation_clock:
            self.deformation_clock=clock;self.deformation_cache.clear()
        row=self.states[name]
        key=(name,part,row.life_generation,row.revision,row.piece,row.progress,
            self.pose_signature(name),self.world.fighters[name].facing)
        if key not in self.deformation_cache:
            self.deformation_cache[key]=self._deformation(name,part,time)
        return self.deformation_cache[key]

    def _deformation(self,name,part,time):
        with localcontext(Context(prec=self.world.precision)):
            morph,q,v,a,cv=self.pose(name,time);actor=self.world.fighters[name]
            if part in self.world.blocking.layers:
                start=(0,F(2,5),0)
                front=max(p.bounds[1][1] for p in morph.local_parts(1))
                target=(0,front+F(1,4),morph.floor_m+morph.prone_height_m/2)
                _,velocity,acceleration=morph.point_kinematics(start,target,(0,0,-morph.full_crouch_drop_m),q,v,a,
                    actor.facing,crouch_rate_per_s=cv)
                return tuple(map(dec,velocity)),tuple(map(dec,acceleration)),ZERO,ZERO
            return tuple(tuple(map(dec,x)) for x in morph.part_derivatives(part,q,v,a,actor.facing,crouch_rate_per_s=cv))

    def local_hand(self,name,point,time=None):
        time=self.world.time if time is None else time
        morph,q,v,a,cv=self.pose(name,time);point=tuple(map(as_fraction,point))
        height=as_fraction(actor_body(self.world,name)['standing_placement']['combined_size_xyz_m'][2])
        target=(*point[:2],morph.floor_m+morph.prone_height_m/2+point[2]*morph.prone_height_m/height)
        return morph.point_kinematics(point,target,(0,0,-morph.full_crouch_drop_m),q,v,a,
            self.world.fighters[name].facing,crouch_rate_per_s=cv)[0]

    def world_hand(self,name,point):
        w=self.world;reference=(*w.fighters[name].position_m,w.motion[name]['body_reference_z'])
        return local_to_world_point(self.local_hand(name,point),reference,w.fighters[name].facing)

    def block_centre(self,name):
        w=self.world;morph,q,v,a,cv=self.pose(name,w.time)
        front=max(p.bounds[1][1] for p in morph.local_parts(1))
        point=morph.point_kinematics((0,F(2,5),0),(0,front+F(1,4),morph.floor_m+morph.prone_height_m/2),
            (0,0,-morph.full_crouch_drop_m),q,v,a,w.fighters[name].facing,crouch_rate_per_s=cv)[0]
        reference=(*w.fighters[name].position_m,w.motion[name]['body_reference_z'])
        return local_to_world_point(point,reference,w.fighters[name].facing)

    def refresh_actor(self,name):
        from combat_sim.pose_kinematics import world_hand_point
        w=self.world;actor=w.fighters[name];m=w.motion[name]
        boxes=self.boxes(name,(*actor.position_m,m['body_reference_z']))
        w.world_bodies[name]=boxes;actor.body_origin_m=tuple(map(dec,body_origin_from_bounds(boxes)))
        low,high=combined_bounds(boxes);height=dec(high[2]-low[2])
        actor.pose_drop_m=dec(actor_body(w,name)['standing_placement']['combined_size_xyz_m'][2])-height
        q,v,_=self.at(name,w.time);row=self.states[name]
        nominal_crouch,_=w.posture_at(name,w.time)
        posture=('getting_up' if row.get_up_action_id is not None else 'prone' if q==1 else
            'falling' if v>0 else 'balance_recovery' if v<0 else 'partial_fall')
        actor.locomotion.update(posture=posture,balance_fraction=str(dec(q)),pose_drop_m=str(actor.pose_drop_m),
            crouch_fraction=str(nominal_crouch),nominal_crouch_drop_m=str(dec(self.basis(name).full_crouch_drop_m)*nominal_crouch),
            crouch_drop_m=str(actor.pose_drop_m),body_height_m=str(height),feet_z_m=str(dec(low[2])),
            height_above_ground_m=str(dec(low[2])-dec(w.scenario['encounter']['ground_z_m'])),
            hand_world_positions_m={hand:[str(dec(x)) for x in world_hand_point(w,actor,p)] for hand,p in actor.hands.items()})

    def pose_signature(self,name):
        m=self.world.motion[name]
        return (m.get('crouch_fraction'),tuple(sorted((m.get('pose_transition') or {}).items())))

    def dynamic(self,name):
        w=self.world;a=w.fighters[name];m=w.motion[name]
        if a.hp<=0:return False
        velocity,acceleration=w.raw_body_motion(name)
        return bool(m['speed'] or m['acceleration'] or any(velocity) or any(acceleration)
            or w.posture_at(name,w.time)[1] or self.moving(name,w.time))

    def needs_retry(self,name):
        row=self.states[name]
        names={name}|{n for n in row.clearance_blockers if n in self.world.fighters}
        return any(self.dynamic(n) for n in names)

    def drivers(self,name):
        w=self.world
        row=self.states[name];names={name}|{n for n in row.clearance_blockers if n in w.fighters}
        return (w.collider_system.registry.epoch,tuple((n,w.fighters[n].life_generation,w.fighters[n].hp>0,w.motion[n]['revision'],
            w.motion[n]['mode'],w.motion[n]['phase'],tuple((x.id,x.phase,x.revision) for x in w.fighters[n].live_actions()),
            'moving' if self.dynamic(n) else (tuple(w.fighters[n].position_m),w.motion[n]['body_reference_z'])) for n in sorted(names)))

    def matches(self,name,row):
        w=self.world;a=w.fighters[name];elapsed=w.time-row.anchor_ms
        return (abs(max(D(0),row.source_o-elapsed)-a.disorientation)<=STATUS_EPS
            and abs(max(D(0),row.source_u-elapsed)-a.instability)<=STATUS_EPS
            and row.pose_signature==self.pose_signature(name))

    def rebuild(self,name):
        w=self.world;a=w.fighters[name];row=self.state(name);q=self.at(name,w.time)[0]
        row.progress=q;row.anchor_ms=w.time;row.source_o=a.disorientation;row.source_u=a.instability
        row.pose_signature=self.pose_signature(name);row.revision+=1;row.event_at_ms=None
        action=a.action_by_id(row.get_up_action_id) if row.get_up_action_id is not None else None
        if row.blocked or a.hp<=0 or a.knocked_down and row.forced_rate is None and action is None:
            piece=BalancePiece(w.time,w.horizon,q,0,0,'held')
        elif action is not None and action.phase=='active':
            remaining=as_fraction(action.active_end_ms-w.time)
            piece=BalancePiece(w.time,action.active_end_ms,q,-1000*q/remaining if remaining else 0,0,'recovering')
        elif row.forced_rate is not None and q<1:
            piece=BalancePiece(w.time,w.horizon,q,row.forced_rate,0,'falling')
        else:piece=balance_piece(w.time,w.horizon,q,a.disorientation,a.instability)
        row.piece=piece;self.segments+=1
        self.record_interval(name,row,piece)
        self.schedule(name)
        w.body_paths.invalidate()

    def finish_interval(self,name):
        index=self.last_interval.pop(name,None)
        if index is not None:
            row=self.history[index]
            row['committed_end_ms']=str(self.world.time)

    def record_interval(self,name,state,piece):
        self.finish_interval(name)
        self.last_interval[name]=len(self.history)
        self.history.append({'actor':name,'life_generation':state.life_generation,'revision':state.revision,
            'begin_ms':str(self.world.time),'planned_end_ms':str(dec(piece.end_ms)),
            'committed_end_ms':None,'kind':piece.kind,
            'driver':('blocked' if state.blocked else 'get_up' if state.get_up_action_id is not None
                else 'explicit_knockdown' if state.forced_rate is not None else 'equilibrium'),
            'source_disorientation':str(state.source_o),'source_instability':str(state.source_u),
            'progress':ratio_text(piece.progress),'velocity_per_s':ratio_text(piece.velocity_per_s),
            'acceleration_per_s2':ratio_text(piece.acceleration_per_s2)})

    def schedule(self,name):
        w=self.world;row=self.states[name];piece=row.piece
        if row.blocked or row.waiting_get_up:
            candidates=[]
            if self.needs_retry(name):candidates.append(w.time+D(5))
            actor=w.fighters[name]
            if row.blocked and not row.waiting_get_up and actor.disorientation and actor.instability:
                candidates.append(w.time+min(actor.disorientation,actor.instability))
            if candidates:self.queue(name,min(w.horizon,min(candidates)),'retry')
            return
        if not self.carries(name):return
        end=piece.end_ms;target=None;kind='statuses'
        if piece.kind in ('falling','recovering'):
            value=F(1) if piece.kind=='falling' else F(0)
            bracket=piece.crossing(value,value_tolerance=F(1,10**(w.precision-8)))
            if bracket is not None and bracket[1]>piece.begin_ms:
                end=min(end,bracket[1]);target=value;kind='limit'
        m=w.motion[name];transition=m.get('pose_transition')
        if transition is not None:
            posture_end=as_fraction(transition['start_ms']+transition['duration_ms'])
            if posture_end<end:end=posture_end;target=None;kind='posture'
        q,v,a=self.at(name,w.time);c,cv=w.posture_at(name,w.time)
        duration=(end-as_fraction(w.time))/1000
        if duration>0:
            boundary=self.basis(name).geometry_boundary((q,v,a/2),(as_fraction(c),as_fraction(cv),F(0)),duration,precision=w.precision)
            if boundary is not None:
                candidate=as_fraction(w.time)+boundary[1]*1000
                if candidate<end:end=candidate;target=None;kind='geometry'
        if end>as_fraction(w.time) and (end<as_fraction(w.horizon) or target is not None):
            self.queue(name,end,kind,target)

    def queue(self,name,time,kind,target=None):
        w=self.world;row=self.states[name]
        if w.time>=w.horizon:return
        with localcontext(Context(prec=w.precision,rounding=ROUND_CEILING)):due=dec(time)
        due=min(w.horizon,max(w.time,due));row.event_at_ms=due
        w.push(due,'equilibrium_boundary',{'actor':name,'life_generation':row.life_generation,
            'revision':row.revision,'boundary_kind':kind,'target':ratio_text(target) if target is not None else None},priority=2)

    def event_live(self,p):
        row=self.states.get(p['actor']);a=self.world.fighters[p['actor']]
        return bool(row is not None and row.life_generation==p['life_generation']==a.life_generation
            and row.revision==p['revision'] and a.hp>0)

    def boundary(self,p):
        if not self.event_live(p):return
        name=p['actor'];row=self.states[name];q=self.at(name,self.world.time)[0]
        if p['target'] is not None:q=as_fraction(p['target'])
        row.progress=q;row.piece=None;self.boundaries+=1
        if q==1 and not self.world.fighters[name].knocked_down:
            self.knockdown(name,source='equilibrium');return
        if q==1:
            row.forced_rate=None
            self.world.request_decision(name,self.world.time)
        if p['boundary_kind']=='retry':
            row.driver_signature=None
            if row.waiting_get_up:self.world.request_decision(name,self.world.time)
        self.rebuild(name);self.world.refresh_mobile_locomotion()

    def settle(self):
        if not self.ready:return
        w=self.world
        for name,a in sorted(w.fighters.items()):
            row=self.state(name)
            if a.hp<=0:continue
            q,_,_=self.at(name,w.time)
            if q==1 and not a.knocked_down and row.get_up_action_id is None:
                self.knockdown(name,source='equilibrium');continue
            if row.blocked and (row.driver_signature!=self.drivers(name) or not self.matches(name,row)):
                self.try_resume(name)
            if row.piece is None or not self.matches(name,row):self.rebuild(name)
        w.refresh_mobile_locomotion()

    def freeze(self,name,reason,*,blockers=()):
        if not self.carries(name):return
        w=self.world;row=self.state(name);q=self.at(name,w.time)[0]
        row.progress=q;row.piece=None;row.blocked=True;row.clearance_blockers=tuple(blockers)
        action=w.fighters[name].action_by_id(row.get_up_action_id) if row.get_up_action_id is not None else None
        if action is not None:w.cancel_owned_action(w.fighters[name],action,reason)
        self.rebuild(name)
        row.driver_signature=self.drivers(name)
        w.log('equilibrium_deformation_blocked',actor=name,reason=reason,balance_fraction=dec(q))

    def try_resume(self,name):
        w=self.world;row=self.states[name]
        if row.waiting_get_up:
            row.driver_signature=self.drivers(name);w.request_decision(name,w.time);return
        row.blocked=False;self.rebuild(name)
        predicted=w.next_mobile_contacts(w.time)
        if predicted is not None and any(name in (c['first'],c['second']) for c in predicted[1]):
            row.blocked=True;self.rebuild(name)
            # Record the held driver, not the temporary moving pose used by
            # the clearance probe. Otherwise every unrelated event reopens
            # this same failed probe and creates another retry clock.
            row.driver_signature=self.drivers(name)
        else:w.log('equilibrium_deformation_resumed',actor=name,balance_fraction=dec(self.at(name,w.time)[0]))

    def retire_life(self,name):
        if not self.enabled or name not in self.states:return
        self.finish_interval(name)
        row=self.states[name];row.progress=self.at(name,self.world.time)[0];row.piece=None
        row.get_up_action_id=None;row.forced_rate=None;row.blocked=False;row.waiting_get_up=False
        row.revision+=1;row.event_at_ms=None

    def action_cancelled(self,actor,action,reason):
        if not self.enabled or action.kind!='get_up':return
        row=self.states.get(actor.id)
        if row is None or row.get_up_action_id!=action.id:return
        row.progress=self.at(actor.id,self.world.time)[0];row.piece=None;row.get_up_action_id=None
        c,_=self.world.posture_at(actor.id,self.world.time)
        self.world.motion[actor.id].update(crouch_fraction=c,pose_transition=None)
        self.rebuild(actor.id)

    def knockdown(self,name,*,source):
        from combat_sim.prone_actions import apply_knockdown
        return apply_knockdown(self,name,source=source)

    def result(self):
        if not self.enabled:return {}
        intervals=[dict(row) for row in self.history]
        for index in self.last_interval.values():intervals[index]['committed_end_ms']=str(self.world.time)
        return {'equilibrium_rules':{'mode':'status_balance_v1','source_tF_ms':'1500 / (1 + (O + U) / 400)',
                'partial_recovery':'zero-status base rate; full knockdown requires Get Up','pose':'convex standing/crouch/prone cuboids'},
            'equilibrium_segments':self.segments,'equilibrium_boundaries':self.boundaries,
            'equilibrium_intervals':intervals,
            'equilibrium_states':{name:{'life_generation':row.life_generation,'progress':str(dec(self.at(name,self.world.time)[0])),
                'exact_progress':ratio_text(self.at(name,self.world.time)[0]),'blocked':row.blocked,'revision':row.revision}
                for name,row in sorted(self.states.items())}}
