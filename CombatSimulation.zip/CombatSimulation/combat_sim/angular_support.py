"""Continuous positive-area face support on the existing saved angular paths.

These predicates clip a candidate reference lease; they never construct a new
translation or apply gravity. Static and living supports share the same rule.
"""
from fractions import Fraction as F
from decimal import Context,ROUND_CEILING,localcontext
from combat_sim.battle_models import decimal_value as dec

from combat_sim.angular_paths import RotatingBoxPath
from combat_sim.angular_intervals import Jet, _poly, _trig, _world, _all, _truth, bounded_cells
from combat_sim.box_motion import footprint_overlap
from combat_sim.orientation import scalar
from combat_sim.oriented_geometry import axes


def _references(path, begin):
    """Reference coefficients at a common absolute anchor."""
    if not isinstance(path,RotatingBoxPath):
        return tuple((scalar(p),F(0),F(0)) for p in path.centre_m)
    path._validate_interval(begin,begin)
    p=path.reference.slice(begin*1000,path.reference.end_ms)
    return tuple(zip(p.reference_m,p.velocity_mps,p.acceleration_mps2))


def _geometry(path, begin, end):
    if isinstance(path,RotatingBoxPath):
        left,right=begin-path.yaw.begin_s,end-path.yaw.begin_s
        size=tuple(_poly(*values,left,right) for values in zip(path.local_box.size_m,path.size_rate_mps,path.size_acceleration_mps2))
        local=tuple(_poly(*values,left,right) for values in zip(path.local_box.centre_m,path.local_velocity_mps,path.local_acceleration_mps2))
        c,s=_trig(path.yaw,begin,end)
        return size,((s,-c,Jet.lift(0)),(c,s,Jet.lift(0))),_world(local,c,s)
    return tuple(map(Jet.lift,path.size_m)),tuple(tuple(map(Jet.lift,n)) for n in axes(path)[:2]),(Jet.lift(0),)*3


def support_cells(first, second, begin_s, end_s, *, distance_epsilon, precision=50, first_boundary_only=True):
    """Open support cells, retaining an actual initial underside/top witness.

    Every footprint SAT axis needs positive intersection width beyond epsilon,
    including the two own projected widths. Vertical face separation stays
    inside the same closed contact band. Signed vertical/reference polynomials
    are combined before bounding, preserving co-moving/co-accelerating faces.
    """
    begin,end=map(scalar,(begin_s,end_s));eps=scalar(distance_epsilon)
    if begin<0 or end<begin or eps<=0:raise ValueError('Invalid angular support interval')
    for path in (first,second):
        if isinstance(path,RotatingBoxPath):path._validate_interval(begin,end)
    a_ref,b_ref=_references(first,begin),_references(second,begin)
    relative=tuple(tuple(x-y for x,y in zip(a,b)) for a,b in zip(a_ref,b_ref))
    # The support contact is an underside against a top, not a volumetric hit.
    top=second.vertical_face_coefficients(1,begin) if isinstance(second,RotatingBoxPath) else (second.bounds[1][2],0,0)
    bottom=first.vertical_face_coefficients(-1,begin) if isinstance(first,RotatingBoxPath) else (first.bounds[0][2],0,0)
    vertical=tuple(x-y for x,y in zip(bottom,top))
    def expressions(left,right):
        sa,na,ca=_geometry(first,left,right);sb,nb,cb=_geometry(second,left,right)
        delta=tuple(_poly(*p,left-begin,right-begin)+x-y for p,x,y in zip(relative,ca,cb))
        result=[]
        for owner,(normals,own_size) in enumerate(((na,sa),(nb,sb))):
            other_normals,other_size=(nb,sb) if owner==0 else (na,sa)
            for i,n in enumerate(normals):
                own=own_size[i]*F(1,2)
                other=sum((h*abs(sum((x*y for x,y in zip(basis,n)),Jet.lift(0)))
                           for h,basis in zip(other_size[:2],other_normals)),Jet.lift(0))*F(1,2)
                projection=sum((x*y for x,y in zip(delta,n)),Jet.lift(0))
                result.extend((own+other-projection-eps,own+other+projection-eps,2*own-eps,2*other-eps))
        gap=_poly(*vertical,left-begin,right-begin)
        return result,(eps-gap,eps+gap)
    def classify(left,right):
        h,z=expressions(left,right);mid=(left+right)/2;mh,mz=expressions(mid,mid);half=(right-left)/2
        return _all((*(_truth(x,y,half,strict=True) for x,y in zip(h,mh)),
                     *(_truth(x,y,half) for x,y in zip(z,mz))))
    def actual(time):
        a=first.at_time(time) if isinstance(first,RotatingBoxPath) else first
        b=second.at_time(time) if isinstance(second,RotatingBoxPath) else second
        return abs(a.bounds[0][2]-b.bounds[1][2])<=eps and footprint_overlap(a,b,distance_epsilon=eps)
    return bounded_cells(classify,actual,begin,end,precision=precision,
        first_boundary_only=first_boundary_only,preserve_initial=True,label='Angular support')


def support_departure(first,second,begin_s,end_s,*,distance_epsilon,precision=50):
    cells=support_cells(first,second,begin_s,end_s,distance_epsilon=distance_epsilon,precision=precision)
    if not cells[0][1]:return scalar(begin_s)
    if len(cells)<2:return None
    # Normalize the confirmed side at the actual absolute scheduling clock.
    # Subsequent nearest/floor conversions cannot undo that crossing.
    with localcontext(Context(prec=precision,rounding=ROUND_CEILING)):
        when=F(dec((scalar(begin_s)+F(cells[1][0]))*1000))/1000
    return min(when,scalar(end_s))
