"""Owned and released rate streams on the existing joint layer/HP timeline.

The component's historical name remains a compatibility seam. Both lifetimes
share one registry, shield allocation, immutable dose and HP commit path.
"""
from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.effort import output_after_instability
from combat_sim.mechanics.life import life_generation
from combat_sim.mechanics.rate_damage import RateDamageSource
from combat_sim.mechanics.recovery_flow import AffineRate
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite


@dataclass
class DamageStream:
    id: str
    source: EffectSource
    target: str
    target_life_generation: int
    base_dps: D
    started_at_ms: D
    expiry_ms: D
    ended_at_ms: D | None = None
    end_reason: str | None = None
    revision: int = 0
    family: str = 'constriction_tear'
    autonomous: bool = False
    source_collider: str | None = None

    def record(self):
        row={'id':self.id,'actor':self.source.actor,'ability':self.source.ability,'action_id':self.source.action_id,
            **self.source.life_record(),'target':self.target,'target_life_generation':self.target_life_generation,
            'kind':self.family,
            'base_damage_per_second':self.base_dps,'started_at_ms':self.started_at_ms,'expiry_ms':self.expiry_ms,
            'ended_at_ms':self.ended_at_ms,'end_reason':self.end_reason,'revision':self.revision,'autonomous':self.autonomous}
        if self.autonomous:
            row.update(lifetime='released',source_collider_id=self.source_collider)
            if self.source.projectile_id is not None:row['projectile_id']=self.source.projectile_id
        else:row.update(effort_phase='holding',category='intrinsic_sustained')
        return row


class ControlledDamage:
    def __init__(self,world,definition=None,released_definition=None):
        self.world=world;self.enabled=definition is not None;self.ids=count(1);self.streams={}
        self.released_enabled=released_definition is not None;self.released_ids=count(1)
        if self.enabled and (definition!={'mode':'controlled_layers_v1'} or not world.thermal_recovery.enabled
                or not world.life_cycles.enabled or not world.effort_system.enabled):
            raise UnsupportedMechanicError('Controlled rate damage requires owned lives and the joint layer solver')
        if self.released_enabled and (released_definition!={'mode':'released_layers_v1'} or not self.enabled):
            raise UnsupportedMechanicError('Released rate damage requires the current common rate/layer registry')

    def start(self,actor,action,target,*,base_dps,until_ms):
        if not self.enabled:raise UnsupportedMechanicError('Controlled rate damage is not enabled')
        base=finite(base_dps,'Sustained damage',positive=True);until=finite(until_ms,'Sustained expiry')
        if (actor.hp<=0 or actor.action_by_id(action.id) is not action or action.life_generation!=actor.life_generation
                or target not in self.world.fighters or self.world.fighters[target].hp<=0 or until<=self.world.time):
            raise ValueError('Sustained damage needs a current owned action, living target and future expiry')
        source=EffectSource(actor.id,action.ability_id,action.id,None,actor.life_generation)
        stream=DamageStream('stream:'+str(next(self.ids)),source,target,self.world.fighters[target].life_generation,
            base,self.world.time,until)
        self.streams[stream.id]=stream;self.invalidate(target)
        self.world.log('controlled_damage_started',stream=stream.record())
        return stream

    def start_released(self,packet,*,damage_type,base_dps,until_ms,source_collider=None):
        """Attach already released pressure to one current recipient life.

        Delivery and spatial membership belong to the caller. No controlled
        action or effort is acquired, and source death cannot withdraw release.
        Optional material support ends pressure when that collider is removed.
        All validation precedes identity, registry and queue changes.
        """
        if not self.released_enabled:
            raise UnsupportedMechanicError('Released rate damage is not enabled')
        w=self.world;required={'actor','ability','action_id','source_life_generation','target','target_life_generation'}
        if not isinstance(packet,dict) or not required<=set(packet) or set(packet)-required-{'projectile_id'}:
            raise ValueError('Released rate damage requires explicit source/action and recipient lives')
        if damage_type!='electrocution':raise UnsupportedMechanicError('Unsupported released rate-damage family')
        base=finite(base_dps,'Released damage rate',positive=True);until=finite(until_ms,'Released expiry')
        if until<=w.time:raise ValueError('Released damage needs a future expiry')
        if any(not isinstance(packet[k],str) or packet[k] not in w.fighters for k in ('actor','target')):
            raise ValueError('Released damage needs known source and recipient actors')
        actor=w.fighters[packet['actor']];target=w.fighters[packet['target']]
        if (not isinstance(packet['ability'],str) or not packet['ability']
                or packet['ability'] not in set(actor.profile['abilities'])|set(actor.profile.get('documented_abilities',{}))
                or type(packet['action_id']) is not int or packet['action_id']<=0):
            raise ValueError('Released damage needs an existing ability and positive action identity')
        for key in ('source_life_generation','target_life_generation'):
            if life_generation(packet[key]) is None:raise ValueError('Released damage needs explicit life generations')
        if not any(l['generation']==packet['source_life_generation'] for l in w.life_cycles.lives[actor.id]):
            raise ValueError('Released damage source life is unknown')
        if target.hp<=0 or target.life_generation!=packet['target_life_generation']:
            raise ValueError('Released damage recipient life is not current and living')
        projectile=packet.get('projectile_id')
        if projectile is not None and (not isinstance(projectile,str) or not projectile):
            raise ValueError('Released projectile attribution must be a nonempty identity')
        if source_collider is not None:
            if not isinstance(source_collider,str) or not w.collider_system.enabled:
                raise ValueError('Released material source needs a known active collider')
            obj=w.collider_system.registry.objects.get(source_collider)
            if obj is None or not obj.active(w.time):raise ValueError('Released material source is inactive')
        source=EffectSource(actor.id,packet['ability'],packet['action_id'],projectile,packet['source_life_generation'])
        stream=DamageStream('released-rate:'+str(next(self.released_ids)),source,target.id,target.life_generation,
            base,w.time,until,family=damage_type,autonomous=True,source_collider=source_collider)
        self.streams[stream.id]=stream;self.invalidate(target.id)
        w.push(until,'released_rate_expired',{'stream_id':stream.id},priority=0)
        w.log('released_damage_started',stream=stream.record())
        return stream

    def live(self,stream):
        if stream.ended_at_ms is not None:return False
        w=self.world;source=w.fighters[stream.source.actor];target=w.fighters[stream.target]
        if stream.autonomous:
            return (target.hp>0 and target.life_generation==stream.target_life_generation
                and (stream.source_collider is None or w.collider_system.registry.objects[stream.source_collider].active(w.time)))
        return (source.hp>0 and source.life_generation==stream.source.life_generation
            and source.action_by_id(stream.source.action_id) is not None
            and target.hp>0 and target.life_generation==stream.target_life_generation)

    def for_target(self,target):
        return tuple(s for s in self.streams.values() if s.target==target and self.live(s))

    def key(self,target):
        w=self.world
        return tuple((s.id,s.revision,s.source.life_generation,s.target_life_generation,s.base_dps,s.expiry_ms,
            ((s.family,dec(w.fighters[target].profile['resistances']['electrocution']),s.source_collider)
             if s.autonomous else
             w.time+w.fighters[s.source.actor].instability if w.fighters[s.source.actor].instability else None))
            for s in self.for_target(target))

    def compatible(self,target,captured):
        current=self.key(target)
        return len(current)==len(captured) and all(a[:-1]==b[:-1] and
            (isinstance(a[-1],tuple) and a[-1]==b[-1] or
             a[-1] is None and b[-1] is None or isinstance(a[-1],D) and isinstance(b[-1],D)
             and abs(a[-1]-b[-1])<=D('1e-24')) for a,b in zip(current,captured))

    def sources(self,target):
        w=self.world;result=[]
        for stream in self.for_target(target):
            if stream.autonomous:
                result.append(RateDamageSource(stream.id,AffineRate(stream.base_dps,w.time,D(0)),D(0),
                    family=stream.family,resistance=dec(w.fighters[target].profile['resistances']['electrocution'])))
                continue
            u=w.fighters[stream.source.actor].instability
            raw=dec(output_after_instability(stream.base_dps,u,'intrinsic_sustained'))
            slope=D(250) if u and raw>0 else D(0)
            if u and u==stream.base_dps*4:slope=D(250)
            result.append(RateDamageSource(stream.id,AffineRate(raw,w.time,slope),w.fighters[target].armor))
        return tuple(result)

    def next_boundary(self,target,end):
        w=self.world;finish=end
        for stream in self.for_target(target):
            finish=min(finish,stream.expiry_ms)
            if stream.autonomous:
                if stream.source_collider is not None:
                    expiry=w.collider_system.registry.objects[stream.source_collider].expires_at_ms
                    if expiry is not None:finish=min(finish,expiry)
                continue
            u=w.fighters[stream.source.actor].instability
            for time in (w.time+u,w.time+u-stream.base_dps*4):
                if w.time<time:finish=min(finish,time)
        return finish

    def invalidate(self,target):
        self.world.thermal_recovery.invalidate(target);self.world.healing.invalidate()

    def end(self,stream,reason):
        if stream.ended_at_ms is not None:return
        stream.ended_at_ms=self.world.time;stream.end_reason=reason;stream.revision+=1
        self.invalidate(stream.target)
        self.world.log('released_damage_ended' if stream.autonomous else 'controlled_damage_ended',stream=stream.record())

    def action_cancelled(self,actor,action,reason):
        for stream in self.streams.values():
            if not stream.autonomous and stream.source.actor==actor.id and stream.source.action_id==action.id:self.end(stream,reason)

    def retire_life(self,actor):
        for stream in self.streams.values():
            if stream.autonomous and stream.target==actor.id and stream.target_life_generation==actor.life_generation:
                self.end(stream,'recipient_life_ended')

    def settle(self):
        for stream in self.streams.values():
            if stream.ended_at_ms is None and (not self.live(stream) or self.world.time>=stream.expiry_ms):
                reason='duration_expired'
                if self.world.time<stream.expiry_ms:
                    reason=('recipient_life_ended' if self.world.fighters[stream.target].hp<=0 or
                        self.world.fighters[stream.target].life_generation!=stream.target_life_generation else
                        'source_collider_ended') if stream.autonomous else 'owned_action_or_life_ended'
                self.end(stream,reason)

    def event_live(self,payload):
        stream=self.streams.get(payload['stream_id'])
        return stream is not None and stream.autonomous and stream.ended_at_ms is None

    def expire(self,payload):
        if self.event_live(payload):self.end(self.streams[payload['stream_id']],'duration_expired')

    def result(self):
        result={'controlled_damage_rules':self.world.combat_locomotion_input['controlled_damage'],
            'controlled_damage_streams':[deepcopy(s.record()) for s in self.streams.values() if not s.autonomous]} if self.enabled else {}
        if self.released_enabled:
            result.update(released_rate_damage_rules=self.world.combat_locomotion_input['released_rate_damage'],
                released_damage_streams=[deepcopy(s.record()) for s in self.streams.values() if s.autonomous])
        return result
