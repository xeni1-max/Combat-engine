"""Anchored continuous yaw, local pose polynomials and swept box enclosures.

This is a query backend, not an additional body-reference writer or a native
turn controller. Times are absolute seconds; reference pieces retain their
existing absolute millisecond convention. No query extrapolates an interval.
"""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.bounded_yaw import bounded_degrees_frame, pi_bounds
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.mechanics.exact_ratio import ratio_text
from combat_sim.mechanics.kinematic_bounds import quadratic_range
from combat_sim.mechanics.turning import fixed_speed_turn_duration_ms
from combat_sim.orientation import YawFrame, scalar, vector3, dot
from combat_sim.oriented_geometry import OrientedCuboid, projected_size

ZERO = (F(0),)*3


def _cross_up(value):
    return -value[1], value[0], F(0)


def _max_abs(bounds):
    return max(map(abs, bounds))


@dataclass(frozen=True)
class PointKinematics:
    position_m: tuple
    velocity_mps: tuple
    acceleration_mps2: tuple
    position_error_m: tuple
    velocity_error_mps: tuple
    acceleration_error_mps2: tuple


@dataclass(frozen=True)
class YawArc:
    begin_s: F
    end_s: F
    initial_frame: YawFrame
    rate_degrees_per_second: F
    precision: int = 50
    anchor_s: F | None = None

    def __post_init__(self):
        for key in ('begin_s', 'end_s', 'rate_degrees_per_second'):
            object.__setattr__(self, key, scalar(getattr(self, key)))
        if self.begin_s < 0 or self.end_s < self.begin_s:
            raise ValueError('Invalid angular path interval')
        if not isinstance(self.initial_frame, YawFrame):
            raise ValueError('Angular path requires an immutable initial frame')
        pi_bounds(self.precision)
        object.__setattr__(self, 'anchor_s', self.begin_s if self.anchor_s is None else scalar(self.anchor_s))

    @classmethod
    def fixed_speed_turn(cls, begin_ms, initial_frame, angle_degrees, speed_mps, *, precision=50):
        """Author's duration for an explicit signed angle and supplied speed.

        This constructor selects neither runtime speed sampling nor steering.
        """
        begin, angle = scalar(begin_ms)/1000, scalar(angle_degrees)
        duration = fixed_speed_turn_duration_ms(angle, scalar(speed_mps))/1000
        return cls(begin, begin+duration, initial_frame, angle/duration if duration else 0, precision)

    def elapsed(self, time_s):
        time = scalar(time_s)
        if not self.begin_s <= time <= self.end_s:
            raise ValueError('Angular query lies outside its saved interval')
        return time-self.begin_s

    @property
    def frame_error(self):
        return F(1, 10**self.precision) if self.rate_degrees_per_second else F(0)

    @property
    def angular_speed_bounds(self):
        return tuple(sorted(v*self.rate_degrees_per_second/180 for v in pi_bounds(self.precision)))

    @property
    def angular_speed(self):
        low, high = self.angular_speed_bounds
        return (low+high)/2

    def frame_at(self, time_s):
        angle = (self.elapsed(time_s)+self.begin_s-self.anchor_s)*self.rate_degrees_per_second
        if not angle:
            return self.initial_frame
        relative, error = bounded_degrees_frame(angle, self.precision)
        # Composition can enlarge component error by at most |c|+|s| <= 2.
        assert 2*error <= self.frame_error
        c, s = self.initial_frame.cosine, self.initial_frame.sine
        return YawFrame(c*relative.cosine-s*relative.sine, s*relative.cosine+c*relative.sine)

    def point_state(self, time_s, reference, local_point, local_velocity=ZERO, local_acceleration=ZERO):
        """World point derivatives, including angular and Coriolis terms.

        Error bounds compare numerical output to ideal constant-rate yaw of
        the exact initial frame and supplied polynomial/reference state. They
        do not bound a caller's separately integrated reference trajectory.
        End derivatives are the left limit of this arc, not the next phase.
        """
        if not isinstance(reference, BodyPathPiece):
            raise ValueError('Angular point state requires a saved reference polynomial')
        frame = self.frame_at(time_s)
        point, velocity, acceleration = map(vector3, (local_point, local_velocity, local_acceleration))
        time_ms = scalar(time_s)*1000
        omega = self.angular_speed
        jpoint, jvelocity = _cross_up(point), _cross_up(velocity)
        local_v = tuple(v+omega*j for v, j in zip(velocity, jpoint))
        local_a = tuple(a+2*omega*j-omega*omega*p if i < 2 else a
                        for i, (a, j, p) in enumerate(zip(acceleration, jvelocity, point)))
        position = frame.to_world_point(point, reference.position(time_ms))
        world_v = tuple(a+b for a, b in zip(reference.velocity(time_ms), frame.to_world_vector(local_v)))
        world_a = tuple(a+b for a, b in zip(reference.acceleration_mps2, frame.to_world_vector(local_a)))
        p, v, a = (sum(map(abs, values[:2])) for values in (point, velocity, acceleration))
        error, dw = self.frame_error, (self.angular_speed_bounds[1]-self.angular_speed_bounds[0])/2
        pe = error*p
        ve = error*(v+abs(omega)*p)+dw*p
        ae = error*(a+2*abs(omega)*v+omega*omega*p)+2*dw*v+dw*(2*abs(omega)+dw)*p
        return PointKinematics(position, world_v, world_a, (pe, pe, F(0)), (ve, ve, F(0)), (ae, ae, F(0)))

    def record(self):
        result = {'begin_s': ratio_text(self.begin_s), 'end_s': ratio_text(self.end_s),
                'initial_frame': self.initial_frame.record(), 'rate_degrees_per_second': ratio_text(self.rate_degrees_per_second),
                'precision': self.precision, 'frame_component_error_bound': ratio_text(self.frame_error)}
        if self.anchor_s != self.begin_s:result['anchor_s'] = ratio_text(self.anchor_s)
        return result


@dataclass(frozen=True)
class RotatingBoxPath:
    reference: BodyPathPiece
    yaw: YawArc
    local_box: Cuboid
    local_velocity_mps: tuple = ZERO
    local_acceleration_mps2: tuple = ZERO
    size_rate_mps: tuple = ZERO
    size_acceleration_mps2: tuple = ZERO

    def __post_init__(self):
        if not isinstance(self.reference, BodyPathPiece) or not isinstance(self.yaw, YawArc) or not isinstance(self.local_box, Cuboid):
            raise ValueError('Rotating box requires saved reference, yaw and local box')
        if (self.reference.begin_ms, self.reference.end_ms) != (1000*self.yaw.begin_s, 1000*self.yaw.end_s):
            raise ValueError('Reference and yaw must own the same interval')
        for key in ('local_velocity_mps', 'local_acceleration_mps2', 'size_rate_mps', 'size_acceleration_mps2'):
            object.__setattr__(self, key, vector3(getattr(self, key)))
        duration = self.yaw.end_s-self.yaw.begin_s
        if any(quadratic_range(s, v, a, 0, duration)[0] <= 0 for s, v, a in
               zip(self.local_box.size_m, self.size_rate_mps, self.size_acceleration_mps2)):
            raise ValueError('Rotating box dimensions must stay positive throughout the interval')

    @property
    def part(self):
        return self.local_box.part

    @property
    def bounds(self):
        return self.at_time(self.yaw.begin_s).bounds

    def _local(self, time_s):
        t = self.yaw.elapsed(time_s)
        point = tuple(p+v*t+a*t*t/2 for p, v, a in
                      zip(self.local_box.centre_m, self.local_velocity_mps, self.local_acceleration_mps2))
        velocity = tuple(v+a*t for v, a in zip(self.local_velocity_mps, self.local_acceleration_mps2))
        size = tuple(p+v*t+a*t*t/2 for p, v, a in
                     zip(self.local_box.size_m, self.size_rate_mps, self.size_acceleration_mps2))
        return point, velocity, size

    def centre_state(self, time_s):
        point, velocity, _ = self._local(time_s)
        return self.yaw.point_state(time_s, self.reference, point, velocity, self.local_acceleration_mps2)

    def vertical_face_coefficients(self, sign, anchor_s=None):
        """Signed world face polynomial, combined before any interval bound."""
        if isinstance(sign,bool) or sign not in (-1,1):raise ValueError('Vertical face sign must be -1 or 1')
        anchor=self.yaw.begin_s if anchor_s is None else scalar(anchor_s)
        t=self.yaw.elapsed(anchor)
        point,velocity,size=self._local(anchor)
        return (self.reference.position(anchor*1000)[2]+point[2]+sign*size[2]/2,
            self.reference.velocity(anchor*1000)[2]+velocity[2]+sign*(self.size_rate_mps[2]+self.size_acceleration_mps2[2]*t)/2,
            self.reference.acceleration_mps2[2]+self.local_acceleration_mps2[2]+sign*self.size_acceleration_mps2[2]/2)

    def at_time(self, time_s):
        point, _, size = self._local(time_s)
        frame = self.yaw.frame_at(time_s)
        centre = frame.to_world_point(point, self.reference.position(scalar(time_s)*1000))
        return OrientedCuboid(self.part, centre, size, frame)

    def _validate_interval(self, begin_s, end_s):
        begin, end = scalar(begin_s), scalar(end_s)
        self.yaw.elapsed(begin)
        self.yaw.elapsed(end)
        if end < begin:
            raise ValueError('Angular enclosure interval is reversed')
        return begin, end

    def _chord_error(self, begin, end):
        """Per-coordinate vertex/chord error, including frame selection error."""
        left, right = begin-self.yaw.begin_s, end-self.yaw.begin_s
        p = v = a = F(0)
        for i in (0, 1):
            q, qv, qa = self.local_box.centre_m[i], self.local_velocity_mps[i], self.local_acceleration_mps2[i]
            s, sv, sa = self.local_box.size_m[i], self.size_rate_mps[i], self.size_acceleration_mps2[i]
            p += _max_abs(quadratic_range(q, qv, qa, left, right))+quadratic_range(s, sv, sa, left, right)[1]/2
            v += max(abs(qv+qa*left), abs(qv+qa*right))+max(abs(sv+sa*left), abs(sv+sa*right))/2
            a += abs(qa)+abs(sa)/2
        omega = _max_abs(self.yaw.angular_speed_bounds)
        xy = a+2*omega*v+omega*omega*p
        z = abs(self.local_acceleration_mps2[2])+abs(self.size_acceleration_mps2[2])/2
        dt = end-begin
        return tuple((abs(acc)+(xy if i < 2 else z))*dt*dt/8+
                     (2*self.yaw.frame_error*p if i < 2 else 0)
                     for i, acc in enumerate(self.reference.acceleration_mps2))

    def projection_range(self, axis, begin_s, end_s):
        """Conservative support interval along any supplied fixed world axis.

        The endpoint boxes alone are insufficient. The vertex acceleration
        bound encloses the continuous arc between them; frame errors enclose
        both chosen endpoints and intervening degree-selected frames.
        """
        begin, end = self._validate_interval(begin_s, end_s)
        axis = vector3(axis)
        if not axis[0] and not axis[1]:
            # Upright yaw cannot change a vertical face. Combine signed
            # centre/size coefficients *before* bounding: an anchored foot's
            # exact cancellation must not become a false dt² floor crossing.
            start,stop=begin-self.yaw.begin_s,end-self.yaw.begin_s
            ranges=[]
            for sign in (-1,1):
                p=self.reference.reference_m[2]+self.local_box.centre_m[2]+sign*self.local_box.size_m[2]/2
                v=self.reference.velocity_mps[2]+self.local_velocity_mps[2]+sign*self.size_rate_mps[2]/2
                a=self.reference.acceleration_mps2[2]+self.local_acceleration_mps2[2]+sign*self.size_acceleration_mps2[2]/2
                ranges.append(quadratic_range(p,v,a,start,stop))
            bounds=ranges[0][0],ranges[1][1]
            return tuple(sorted(x*axis[2] for x in bounds))
        shapes = (self.at_time(begin), self.at_time(end)) if begin != end else (self.at_time(begin),)
        lows = [dot(box.centre_m, axis)-projected_size(box, axis)/2 for box in shapes]
        highs = [dot(box.centre_m, axis)+projected_size(box, axis)/2 for box in shapes]
        error = dot(tuple(map(abs, axis)), self._chord_error(begin, end)) if begin != end else F(0)
        return min(lows)-error, max(highs)+error

    def enclosing_interval(self, begin_s, end_s):
        begin, end = self._validate_interval(begin_s, end_s)
        if begin == end:
            return self.at_time(begin)
        # A world AABB never tightens to a non-cardinal box, even as dt -> 0.
        # A fixed midpoint-frame enclosure does, allowing the existing rounded
        # sphere sweep to reject genuine clearances and empty AABB corners.
        frame = self.yaw.frame_at((begin+end)/2)
        bounds = [self.projection_range(axis, begin, end) for axis in frame.basis]
        centre = frame.to_world_vector(tuple((a+b)/2 for a, b in bounds))
        return OrientedCuboid(self.part, centre, tuple(b-a for a, b in bounds), frame)

    def record(self):
        return {'reference': self.reference.record(), 'yaw': self.yaw.record(),
                'part': self.part, 'local_centre_m': tuple(map(ratio_text, self.local_box.centre_m)),
                'local_size_m': tuple(map(ratio_text, self.local_box.size_m)),
                **{key: tuple(map(ratio_text, getattr(self, key))) for key in
                   ('local_velocity_mps', 'local_acceleration_mps2', 'size_rate_mps', 'size_acceleration_mps2')}}
