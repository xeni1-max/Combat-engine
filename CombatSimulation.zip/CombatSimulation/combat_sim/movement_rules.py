"""Scripted geometry/timing test on the shared combat event loop.

Explicitly excludes attacks, movement/jump statuses and resource payments.
Horizontal commands are forward-only, grounded and non-overlapping; air control
and airborne wall/body contact response are rejected until defined.
"""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.character_geometry import actor_body
from combat_sim.battle_models import ceil_ms, decimal_value as dec
from combat_sim.hitboxes import world_standing_cuboids
from combat_sim.models import UnsupportedMechanicError
from combat_sim.mechanics.gravity import GRAVITY_MPS2
from combat_sim.mechanics.support_geometry import crosses_finite_sheet
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M
from combat_sim.mechanics.stopping import calculate_stopping_slide
from combat_sim.movement_contacts import first_box_contact
from combat_sim.climb_rules import ScriptedClimbRules
from combat_sim.locomotion_features import LocomotionFeatureRules
from combat_sim.team_rules import TERRAIN_SCOPE

GRAVITY=dec(GRAVITY_MPS2)

MOVEMENT_SCOPE=dict(TERRAIN_SCOPE,movement='scripted_straight_line',
    dyspnea_eligibility='excluded_geometry_test',recovery_eligibility='excluded_geometry_test',
    status_effects='excluded_geometry_test',attacks='excluded_geometry_test')


class ScriptedMovementRules(ScriptedClimbRules,LocomotionFeatureRules):
    def setup_scripted_movement(self,movement_definition,jump_definition,climb_definition=None):
        if movement_definition is None or jump_definition is None:
            raise UnsupportedMechanicError('Scripted movement requires explicit movement and jump definitions')
        # Provenance labels are documentation, not mechanics or authorization.
        # Validate the actual units, equations, profiles and scope below.
        if movement_definition.get('stopping_rule')!='instability_slide_only':
            raise UnsupportedMechanicError('Linear stopping is superseded by instability-based sliding')
        if movement_definition.get('speed_curve')!='linear_during_active':
            raise UnsupportedMechanicError('Only the confirmed linear Active transition is supported')
        if (jump_definition.get('takeoff_timing')!='start_of_active' or
            jump_definition.get('upward_speed_rule')!='base_running_speed / 2' or
            jump_definition.get('horizontal_velocity_rule')!='retain_at_takeoff'):
            raise UnsupportedMechanicError('Unsupported jump flight/takeoff rules')
        if movement_definition.get('units')!={'speed':'m/s','duration':'ms'}:
            raise UnsupportedMechanicError('Movement input units must be m/s and ms')
        for values in movement_definition['characters'].values():
            expected={'walking_speed_mps','running_speed_mps','walk_run_active_ms','stopping_base_instability_per_mps'}
            if set(values)-{'source'}!=expected or any(dec(values[k])<=0 for k in expected):
                raise ValueError('Movement profile must provide positive speed/duration values')
        for values in jump_definition['characters'].values():
            gathering,active=dec(values['gathering_ms']),dec(values['active_ms'])
            if gathering<0 or active<=0 or active!=ceil_ms(active):
                raise ValueError('Jump profile requires nonnegative Gathering and positive integer-ms Active')
        special=movement_definition.get('special_stopping')
        if special is not None and special!={'slide_start':'start_of_active','duration':'base_stopping_instability_ms',
            'speed_curve':'linear_to_zero','distance_floor_m':0,
            'initial_slide_speed':'twice_mitigated_distance_divided_by_duration_seconds'}:
            raise UnsupportedMechanicError('Special stopping needs the author-confirmed mitigated-distance linear slide')
        self.movement_definition=deepcopy(movement_definition)
        self.jump_definition=deepcopy(jump_definition)
        self.motion={}
        self.choices=self.scenario['action_selection']
        if set(self.choices)!=set(self.fighters) or any(v!={'kind':'scripted_movement'} for v in self.choices.values()):
            raise UnsupportedMechanicError('Movement test requires scripted_movement policy for every actor')
        for name,actor in self.fighters.items():
            if actor.profile_id not in movement_definition['characters'] or actor.profile_id not in jump_definition['characters']:
                raise UnsupportedMechanicError('Missing authored locomotion character profile')
            if actor.hp<=0 or actor.disorientation or actor.instability or actor.dyspnea:
                raise UnsupportedMechanicError('Geometry test requires living actors with zero statuses and dyspnea')
            self.motion[name]={'mode':'standing','phase':None,'anchor_ms':D(0),
                'origin_xy':tuple(map(dec,actor.position_m)),'speed':D(0),'acceleration':D(0),
                'direction':(D(1) if actor.facing=='+x' else D(-1),D(0)),
                'revision':0,'jump':None,'ground_origin_z':actor.body_origin_m[2]}
            actor.metrics.update(movement_commands=0,jumps_started=0,landings=0,collision_stops=0)
            if special is not None:actor.metrics['special_stops']=0
        self.setup_locomotion_features()
        self.setup_climb_rules(climb_definition)
        self.update_movement_geometry(D(0))
        for item in self.scenario['movement_script']:
            expected={'actor','at_ms','action'}|({'target'} if item.get('action')=='climb' else set())
            if set(item)!=expected or item['actor'] not in self.fighters:
                raise ValueError('Movement command requires actor, at_ms and action')
            when=dec(item['at_ms'])
            if when<0 or when!=ceil_ms(when) or when>self.horizon:
                raise ValueError('Movement commands need integer-ms times within the horizon')
            if item['action']=='climb' and not isinstance(item['target'],str):
                raise ValueError('Climb target must be an object identity')
            if item['action'] not in ('walk','run','stop','jump','climb','crouch','stand','sprint'):
                raise UnsupportedMechanicError('Unsupported scripted movement command')
            self.push(when,'movement_command',dict(item),priority=5)
        self.validate_movement_scene()
        # Starting inside solid geometry is not a valid stop/contact scenario.
        for name,boxes in self.world_bodies.items():
            obstacles=[box for group,items in self.terrain_colliders.items()
                       if group!=self.terrain_definition['ground']['id'] for box in items]
            obstacles.extend(box for other,items in self.world_bodies.items() if other!=name for box in items)
            if any(first_box_contact(box,other,(0,0,0),(0,0,0),1)==0 for box in boxes for other in obstacles):
                raise UnsupportedMechanicError('Movement actors must not start overlapping solid bodies or cubes')

    def motion_at(self,name,time):
        m=self.motion[name]
        if m.get('climb') is not None:return self.climb_motion_at(name,time)
        seconds=(time-m['anchor_ms'])/1000
        speed=m['speed']+m['acceleration']*seconds
        distance=m['speed']*seconds+m['acceleration']*seconds*seconds/2
        xy=tuple(p+d*distance for p,d in zip(m['origin_xy'],m['direction']))
        height=vz=D(0)
        if m['jump'] is not None:
            t=(time-m['jump']['takeoff_ms'])/1000
            up=m['jump']['upward_speed']
            height=up*t-GRAVITY*t*t/2
            vz=up-GRAVITY*t
        velocity=tuple(d*speed for d in m['direction'])+(vz,)
        acceleration=tuple(d*m['acceleration'] for d in m['direction'])+(-GRAVITY if m['jump'] else D(0),)
        return xy,height,velocity,acceleration,speed

    def update_movement_geometry(self,time):
        for name,actor in self.fighters.items():
            m=self.motion[name]
            xy,height,velocity,_,speed=self.motion_at(name,time)
            actor.position_m=xy
            actor.body_origin_m=(*xy,m['ground_origin_z']+max(D(0),height))
            self.world_bodies[name]=world_standing_cuboids(actor_body(self,name),actor.body_origin_m,actor.facing)
            actor.locomotion={'mode':m['mode'],'phase':m['phase'],'speed_mps':str(speed),
                'velocity_mps':[str(v) for v in velocity],
                'height_above_ground_m':str(max(D(0),height)),'grounded':m['jump'] is None and m.get('climb') is None}
            if self.climb_definition is not None:
                feet_z=actor.body_origin_m[2]+dec(actor_body(self,name)['standing_placement']['ground_z_m'])
                actor.locomotion.update(support_id=m['support_id'],
                    support_surface_z_m=str(m['ground_origin_z']+dec(actor_body(self,name)['standing_placement']['ground_z_m'])),
                    height_above_support_m=str(max(D(0),height)),
                    height_above_ground_m=str(feet_z-dec(self.scenario['encounter']['ground_z_m'])))

        self.update_posture_geometry(time)

    def reanchor_motion(self,name,speed,acceleration=0):
        m=self.motion[name]
        m.update(anchor_ms=self.time,origin_xy=tuple(map(dec,self.fighters[name].position_m)),
                 speed=dec(speed),acceleration=dec(acceleration))

    def validate_movement_scene(self):
        ground=self.terrain_colliders[self.terrain_definition['ground']['id']][0]
        low,high=ground.bounds
        finite=getattr(getattr(self,'terrain_support',None),'finite_ground',False)
        for name,boxes in self.world_bodies.items():
            for box in boxes:
                a,b=box.bounds
                if finite and self.fighters[name].hp>0:
                    if crosses_finite_sheet(box,ground,distance_epsilon=CONTACT_DISTANCE_EPS_M):
                        raise ValueError('Body crosses the finite ground surface')
                elif not finite and any(a[i]<low[i] or b[i]>high[i] for i in (0,1)):
                    raise UnsupportedMechanicError('Movement test requires full body projection inside the ground footprint; edge response needs a footprint rule')

        self.validate_climb_support()

    def next_movement_contact(self,end):
        seconds=(end-self.time)/1000
        contacts=[]
        names=sorted(self.fighters)
        def check(a,b,left,right,v,acc):
            for box in left:
                offset,size_rate=self.pose_part_motion(a,box.part,self.time)
                for other in right:
                    other_offset,other_rate=(self.pose_part_motion(b,other.part,self.time) if b in self.motion
                                             else ((D(0),)*3,(D(0),)*3))
                    relative=tuple(x+y-z for x,y,z in zip(v,offset,other_offset))
                    t=first_box_contact(box,other,relative,acc,seconds,
                        left_size_rate_mps=size_rate,right_size_rate_mps=other_rate)
                    if t is not None:contacts.append((self.time+t*1000,a,b))
        for name in names:
            _,_,velocity,acceleration,_=self.motion_at(name,self.time)
            if not any(velocity) and not any(acceleration) and not self.posture_at(name,self.time)[1]:continue
            for obstacle,boxes in self.terrain_colliders.items():
                if obstacle==self.terrain_definition['ground']['id']:continue
                check(name,obstacle,self.world_bodies[name],boxes,velocity,acceleration)
        for i,name in enumerate(names):
            _,_,va,aa,_=self.motion_at(name,self.time)
            for other in names[i+1:]:
                _,_,vb,ab,_=self.motion_at(other,self.time)
                v=tuple(a-b for a,b in zip(va,vb));a=tuple(x-y for x,y in zip(aa,ab))
                if any(v) or any(a) or self.posture_at(name,self.time)[1] or self.posture_at(other,self.time)[1]:check(name,other,self.world_bodies[name],self.world_bodies[other],v,a)
        if not contacts:return None
        earliest=min(c[0] for c in contacts)
        return earliest,[(a,b) for t,a,b in contacts if abs(t-earliest)<D('1e-25')]

    def advance_movement(self,end):
        while self.time<end:
            contact=self.next_movement_contact(end)
            finish=contact[0] if contact else end
            if contact and 0<=end-finish<=D('1e-25'):
                # Roundoff at an expansion's analytic endpoint must not turn
                # an exact ceiling fit into an earlier penetrating contact.
                names={n for pair in contact[1] for n in pair if n in self.motion}
                if any(self.motion[n].get('pose_transition') is not None and
                       self.motion[n]['pose_transition']['start_ms']+self.motion[n]['pose_transition']['duration_ms']==end
                       for n in names):
                    finish=end
                    contact=(end,contact[1])
            self.update_movement_geometry(finish)
            self.time=finish
            self.validate_movement_scene()
            if not contact:return
            affected=set()
            for a,b in contact[1]:
                affected.add(a)
                if b in self.motion:affected.add(b)
            if any(self.motion[n].get('pose_transition') is not None for n in affected):
                ending=all((self.motion[n].get('pose_transition') is None or
                    self.time>=self.motion[n]['pose_transition']['start_ms']+self.motion[n]['pose_transition']['duration_ms'])
                    for n in affected)
                # A completed expansion may exactly touch a ceiling without
                # entering it. Re-evaluate with the now-zero pose size rate.
                if ending and self.next_movement_contact(self.time) is None:return
                raise UnsupportedMechanicError('Posture transition is obstructed; partial-pose contact response is undefined')
            if any(self.motion[n].get('climb') is not None for n in affected):
                raise UnsupportedMechanicError('Climb path is obstructed; response during climb requires an authored rule')
            if any(self.motion[n]['jump'] is not None for n in affected):
                raise UnsupportedMechanicError('Airborne body/obstacle collision response is not defined for this test')
            for name in sorted(affected):
                m=self.motion[name]
                if self.motion_at(name,self.time)[4]==0 and not m['acceleration']:continue
                # A physical contact removes movement; it is not an authored
                # interruption of an already requested climb's Gathering.
                if m['phase']=='climb_gathering':
                    m['mode']='standing'
                else:
                    m['revision']+=1
                    m.update(mode='standing',phase=None)
                self.reanchor_motion(name,0)
                self.fighters[name].metrics['collision_stops']+=1
                self.log('movement_blocked',actor=name,contacts=contact[1],response='temporary_stop_only')
            self.update_movement_geometry(self.time)
            self.sample('after_movement_contact')

    def process_movement_event(self,kind,p):
        if kind=='movement_pose_completed':return self.process_posture_event(p)
        if kind.startswith('movement_climb_'):return self.process_climb_event(kind,p)
        name=p['actor'];actor=self.fighters[name];m=self.motion[name]
        profile=self.movement_definition['characters'][actor.profile_id]
        jump=self.jump_definition['characters'][actor.profile_id]
        if kind=='movement_command':
            if m['phase'] is not None or m['jump'] is not None:
                raise UnsupportedMechanicError('Scripted commands cannot overlap transitions, jump Gathering/Active or flight')
            action=p['action'];speed=self.motion_at(name,self.time)[4]
            actor.metrics['movement_commands']+=1
            m['revision']+=1
            if self.handle_locomotion_feature_command(name,action):
                self.update_movement_geometry(self.time)
                return
            if action=='climb':
                self.request_climb(name,p['target'])
            elif action=='jump':
                m['phase']='jump_gathering'
                gathering=dec(jump['gathering_ms'])*(D('1.2') if m['mode']=='running' else 1)
                takeoff=ceil_ms(self.time+gathering)
                self.log('jump_requested',actor=name,takeoff_at_ms=takeoff,mode=m['mode'])
                self.push(takeoff,'movement_takeoff',{'actor':name,'revision':m['revision']})
            else:
                if action=='stop':
                    if self.movement_definition.get('special_stopping') is None:
                        raise UnsupportedMechanicError('Special stopping requires an explicit authored slide curve')
                    if not speed:
                        self.log('movement_command_no_change',actor=name,action=action)
                        return
                    slide=calculate_stopping_slide(speed,actor.profile['max_hp'],actor.armor,profile,precision=self.precision)
                    duration=dec(slide.duration_ms)
                    actor.metrics['special_stops']+=1
                    m.update(mode='stopping',phase='stopping_active',slide_distance=slide.distance_m)
                    self.reanchor_motion(name,slide.initial_slide_speed_mps,slide.acceleration_mps2)
                    self.log('special_stop_started',actor=name,original_speed_mps=speed,
                        raw_distance_m=slide.raw_distance_m,resistance_reduction_m=slide.resistance_reduction_m,
                        slide_distance_m=slide.distance_m,initial_slide_speed_mps=slide.initial_slide_speed_mps,
                        slide_duration_ms=duration,base_stopping_instability=duration,
                        active_end_ms=self.time+duration,speed_curve='linear_to_zero',
                        zero_distance_stops_travel_immediately=not bool(slide.distance_m))
                    self.push(self.time+duration,'movement_slide_ended',{'actor':name,'revision':m['revision']})
                    self.update_movement_geometry(self.time)
                    return
                target={'walk':dec(profile['walking_speed_mps']),'run':dec(profile['running_speed_mps']),'stop':D(0)}[action]
                if action=='run' and m['mode']=='standing':
                    raise UnsupportedMechanicError('This script must enter walking before running; direct stand-to-run timing is unspecified')
                if target==speed:
                    self.log('movement_command_no_change',actor=name,action=action)
                    return
                duration=(dec(profile['walk_run_active_ms']) if speed and target else
                          abs(target-speed)*dec(profile['stopping_base_instability_per_mps']))
                if duration!=ceil_ms(duration):
                    raise UnsupportedMechanicError('Fractional Active duration needs separate motion/event rounding treatment')
                m.update(phase='transition_active',target_speed=target,
                         target_mode={'walk':'walking','run':'running','stop':'standing'}[action])
                self.reanchor_motion(name,speed,(target-speed)/(duration/1000))
                self.log('movement_transition_started',actor=name,from_speed_mps=speed,to_speed_mps=target,
                         active_ms=duration,active_end_ms=self.time+duration,action=action)
                self.push(self.time+duration,'movement_transition_ended',{'actor':name,'revision':m['revision']})
        elif kind=='movement_slide_ended':
            m.update(mode='standing',phase=None)
            self.reanchor_motion(name,0)
            self.log('special_stop_completed',actor=name,speed_mps=0)
        elif kind=='movement_transition_ended':
            m.update(mode=m['target_mode'],phase=None)
            self.reanchor_motion(name,m['target_speed'])
            self.log('movement_transition_completed',actor=name,mode=m['mode'],speed_mps=m['speed'])
        elif kind=='movement_takeoff':
            speed=self.motion_at(name,self.time)[4]
            self.reanchor_motion(name,speed)
            up=dec(profile['running_speed_mps'])/2
            m.update(phase='jump_active',jump={'takeoff_ms':self.time,'upward_speed':up})
            actor.metrics['jumps_started']+=1
            active_end=self.time+dec(jump['active_ms'])
            landing=self.time+2*up/GRAVITY*1000
            self.log('jump_takeoff',actor=name,upward_speed_mps=up,horizontal_speed_mps=speed,
                     active_end_ms=active_end,landing_at_ms=landing)
            self.push(self.time+up/GRAVITY*1000,'movement_apex',{'actor':name,'revision':m['revision']})
            self.push(active_end,'movement_jump_active_ended',{'actor':name,'revision':m['revision']})
            self.push(landing,'movement_landed',{'actor':name,'revision':m['revision']})
        elif kind=='movement_apex':
            _,height,velocity,_,_=self.motion_at(name,self.time)
            extra={}
            if self.climb_definition is not None:
                extra['height_above_support_m']=height
                height+=m['ground_origin_z']+dec(actor_body(self,name)['standing_placement']['ground_z_m'])-dec(self.scenario['encounter']['ground_z_m'])
            self.log('jump_apex',actor=name,height_above_ground_m=height,vertical_velocity_mps=velocity[2],**extra)
        elif kind=='movement_jump_active_ended':
            m['phase']=None
            self.log('jump_active_completed',actor=name,airborne=True)
        elif kind=='movement_landed':
            m['jump']=None
            actor.metrics['landings']+=1
            self.log('jump_landed',actor=name,ground_z_m=(m['ground_origin_z']+dec(actor_body(self,name)['standing_placement']['ground_z_m'])
                         if self.climb_definition is not None else self.scenario['encounter']['ground_z_m']),
                     response='same_flat_ground_zero_vertical_velocity')
        else:raise RuntimeError('Unknown scripted movement event: '+kind)
        self.update_movement_geometry(self.time)

    def movement_result(self):
        return {'movement_definition':self.movement_definition,'jump_definition':self.jump_definition,
            **({'climb_definition':self.climb_definition} if self.climb_definition is not None else {}),
            'movement_test_scope':{'kind':'shared_engine_geometry_and_timing',
                'attacks':'excluded','statuses_and_dyspnea':'excluded_by_author_for_this_test',
                'jump_landing':('same_flat_support_only' if self.climb_definition is not None else 'same_flat_finite_ground_only'),'air_control':'not_implemented',
                'ground_edges':'reject_until_footprint_rule_defined','airborne_contacts':'reject_until_response_defined'}}
