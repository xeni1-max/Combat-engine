"""Life-bound resting body faces composed with the shared path constraints.

Pose changes retain the existing obstruction rule: closing deformation gets a
native contact; withdrawing deformation releases support. No pose copies,
horizontal carrying, new abilities or independent translation loop live here.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
from itertools import count

from combat_sim.character_geometry import actor_body,crouch_target
from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.support_geometry import vertical_witnesses,horizontal_gap_polynomials,first_overlap_departure
from combat_sim.mechanics.unilateral_velocity import ContactLimit
from combat_sim.models import UnsupportedMechanicError
from combat_sim.pose_kinematics import pose_acceleration
from combat_sim.angular_support import support_departure
from combat_sim.postures import world_posture_cuboids
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M as DIST,CONTACT_SPEED_EPS_MPS as SPEED,CONTACT_ACCEL_EPS_MPS2 as ACCEL


class BodySupport:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.ready=False
        self.ids=count(1);self.rows={};self.current={};self.epoch=0;self.cache_key=None
        self.boxes={};self.busy=False;self.settling=False;self.last_committed=None
        self.scan_uppers=set()
        if self.enabled and (definition!={'mode':'resting_body_faces_v1'} or not world.mobile_mode or
                not world.body_paths.enabled or not world.distance_constraints.enabled or not world.equilibrium.enabled):
            raise UnsupportedMechanicError('Body support requires current saved paths, equilibrium and shared contact/distance constraints')

    def attach(self):
        if self.enabled:self.ready=True;self.settle()

    def driver(self,name):
        m=self.world.motion[name]
        return (m.get('revision',0),m.get('spatial_revision',0),m['mode'],m['phase'],
            m.get('jump') is not None,m.get('support_id'),m.get('climb') is not None)

    def scene_key(self):
        w=self.world
        return (w.time,w.collider_system.registry.epoch,tuple((n,a.life_generation,a.hp>0,a.facing,tuple(a.position_m),
            w.motion[n].get('body_reference_z'),self.driver(n),
            tuple(w.motion[n]['jump']['velocity']) if w.motion[n].get('jump') is not None else None,
            w.motion[n].get('imposed_velocity'),w.equilibrium.at(n,w.time),w.equilibrium.pose_signature(n))
            for n,a in sorted(w.fighters.items())))

    def body_boxes(self,name):
        w=self.world;a=w.fighters[name];ref=(*a.position_m,w.motion[name]['body_reference_z'])
        if w.equilibrium.carries(name):return w.equilibrium.boxes(name,ref)
        return world_posture_cuboids(actor_body(w,name),ref,a.facing,w.posture_at(name,w.time)[0],
            crouch_target(w,name,w.crouch_definition['target_leg_height_m']))

    def end(self,key,reason):
        identity=self.current.pop(key);r=self.rows[identity]
        r.update(status='ended',ended_at_ms=self.world.time,end_reason=reason)
        self.epoch+=1;self.world.log('body_support_contact_ended',**deepcopy(r))

    def pair_motion(self,witness):
        w=self.world;u,l=witness.upper,witness.lower
        uv,us=w.pose_part_motion(u,witness.upper_part,w.time);lv,ls=w.pose_part_motion(l,witness.lower_part,w.time)
        ua,uq=pose_acceleration(w,u,witness.upper_part,w.time);la,lq=pose_acceleration(w,l,witness.lower_part,w.time)
        pose_v=uv[2]-us[2]/2-lv[2]-ls[2]/2
        pose_a=ua[2]-uq[2]/2-la[2]-lq[2]/2
        v,a=self.requested_motion(u);other,change=self.requested_motion(l)
        return pose_v,pose_a,v[2]-other[2]+pose_v,a[2]-change[2]+pose_a

    def requested_motion(self,name):
        # Query the existing grapple projection without asking this same
        # contact graph to supply its own support/acceleration recursively.
        w=self.world
        if w.grapple_links.joined(name):return w.grapple_links.motion(name,static_support_only=True)
        return w.free_mobile_motion(name)

    def scan(self):
        # Consumption updates references and driver components actor by actor
        # before the shared clock advances. Queries inside that transaction
        # retain the last coherent contact snapshot; they cannot discover or
        # retire support against an intermediate mix of endpoint states.
        if not self.ready or self.busy or self.world.body_paths.advancing:return
        w=self.world
        with localcontext(Context(prec=w.precision)):
            signature=self.scene_key()
            if signature==self.cache_key:return
            self.busy=True
            try:
                self.boxes={n:self.body_boxes(n) for n,a in sorted(w.fighters.items()) if a.hp>0}
                witnesses=vertical_witnesses(self.boxes,distance_epsilon=DIST);present={}
                self.scan_uppers={p.upper for p in witnesses}
                for witness in witnesses:
                    u,l=witness.upper,witness.lower
                    key=(witness,w.fighters[u].life_generation,w.fighters[l].life_generation)
                    pv,pa,v,a=self.pair_motion(witness)
                    if v>SPEED or abs(v)<=SPEED and a>ACCEL:continue
                    present[key]=(pv,pa,v,a)
                    if key not in self.current:
                        identity='body-support:'+str(next(self.ids));drivers=(self.driver(u),self.driver(l))
                        admitted=drivers if abs(v)<=SPEED and abs(pv)<=SPEED and abs(pa)<=ACCEL else None
                        r=dict(id=identity,upper=u,lower=l,upper_part=witness.upper_part,lower_part=witness.lower_part,
                            upper_life_generation=key[1],lower_life_generation=key[2],created_at_ms=w.time,status='active',
                            accepted_drivers=admitted)
                        self.current[key]=identity;self.rows[identity]=r;self.epoch+=1
                        w.log('body_support_contact_started',**deepcopy(r))
                    r=self.rows[self.current[key]];drivers=(self.driver(u),self.driver(l))
                    if r['accepted_drivers']!=drivers and abs(v)<=SPEED and abs(pv)<=SPEED and abs(pa)<=ACCEL:
                        r['accepted_drivers']=drivers;self.epoch+=1
                for key in tuple(self.current):
                    if key not in present:self.end(key,'geometry_motion_or_life_separated')
                self.cache_key=signature
            finally:self.busy=False

    def gravity(self,name):
        if not self.ready:return False
        requested=name in self.scan_uppers if self.busy else any(key[0].upper==name for key in self.current)
        if not requested:return False
        w=self.world
        # A real static support already supplies the gravity reaction. An
        # incidental underside witness against a falling neighbour must not
        # turn a floor-supported actor into an unsupported gravity requester.
        if w.motion[name]['jump'] is None and w.collider_system.static_support(w.fighters[name]) is not None:return False
        return True

    def admitted(self,key):
        witness=key[0];r=self.rows[self.current[key]]
        if self.world.body_paths.advancing:return r['accepted_drivers'] is not None
        pv,pa,_,_=self.pair_motion(witness)
        return (r['accepted_drivers']==(self.driver(witness.upper),self.driver(witness.lower)) and
            abs(pv)<=SPEED and abs(pa)<=ACCEL)

    def planes(self):
        self.scan()
        return tuple(sorted({ContactLimit(key[0].upper,(0,0,-1),key[0].lower)
            for key in self.current if self.admitted(key)},key=lambda c:(c.actor,c.other)))

    def active(self):return bool(self.planes())

    def names(self):return {n for p in self.planes() for n in (p.actor,p.other)}

    def signature(self):
        if not self.ready:return ()
        self.scan();return self.epoch,tuple(sorted(self.current.values()))

    def rooted(self,name,seen=()):
        if name in seen or self.world.fighters[name].hp<=0:return False
        w=self.world
        if w.motion[name]['jump'] is None and w.collider_system.static_support(w.fighters[name]) is not None:return True
        return any(key[0].upper==name and self.admitted(key) and self.rooted(key[0].lower,(*seen,name)) for key in self.current)

    def find_support(self,actor):
        self.scan()
        return next(((key[0].lower,key[0].lower_part) for key in sorted(self.current)
            if key[0].upper==actor.id and self.admitted(key) and self.rooted(key[0].lower)),None)

    def support_for_boxes(self,name,boxes,velocity):
        """Read-only prospective placement/restoration support query."""
        if not self.ready:return None
        self.scan();bodies={n:p for n,p in self.boxes.items() if n!=name};bodies[name]=tuple(boxes)
        for p in vertical_witnesses(bodies,distance_epsilon=DIST):
            if p.upper!=name or not self.rooted(p.lower):continue
            pv,pa,_,_=self.pair_motion(p)
            if abs(pv)>SPEED or abs(pa)>ACCEL:continue
            other=self.requested_motion(p.lower)[0]
            if abs(dec(velocity[2])-other[2])<=SPEED:return p.lower,p.lower_part
        return None

    def witness(self,upper,lower):
        self.scan()
        choices=[key[0] for key in self.current if key[0].upper==upper and key[0].lower==lower]
        def order(p):
            u=next(b for b in self.boxes[upper] if b.part==p.upper_part)
            l=next(b for b in self.boxes[lower] if b.part==p.lower_part)
            return -(l.bounds[1][2]-u.bounds[0][2]),p.upper_part,p.lower_part
        return min(choices,key=order,default=None)

    def contact_resolved(self,contacts):
        if not self.ready:return
        self.cache_key=None;self.scan()
        pairs={frozenset((c['first'],c['second'])) for c in contacts if c['second'] in self.world.fighters}
        for key,identity in self.current.items():
            p=key[0]
            if frozenset((p.upper,p.lower)) in pairs:
                self.rows[identity]['accepted_drivers']=(self.driver(p.upper),self.driver(p.lower));self.epoch+=1

    def departure(self,pieces,end):
        """Cut the existing saved prefix at actual contact-overlap departure."""
        if not self.ready:return end
        self.scan();w=self.world;now=F(w.time);by_name=dict(pieces);limit=F(end)
        for key in self.current:
            if not self.admitted(key):continue
            p=key[0];u=next(b for b in self.boxes[p.upper] if b.part==p.upper_part)
            l=next(b for b in self.boxes[p.lower] if b.part==p.lower_part)
            a,b=by_name[p.upper],by_name[p.lower]
            if w.turns.active(p.upper) or w.turns.active(p.lower):
                first=w.turns.path_from_piece(p.upper,u,a.slice(now,limit))
                second=w.turns.path_from_piece(p.lower,l,b.slice(now,limit))
                loss=support_departure(first,second,now/1000,limit/1000,distance_epsilon=DIST,precision=w.precision)
                if loss is not None:limit=min(limit,loss*1000)
                continue
            uv,us=w.pose_part_motion(p.upper,p.upper_part,w.time);lv,ls=w.pose_part_motion(p.lower,p.lower_part,w.time)
            ua,uq=pose_acceleration(w,p.upper,p.upper_part,w.time);la,lq=pose_acceleration(w,p.lower,p.lower_part,w.time)
            gaps=horizontal_gap_polynomials(u,l,tuple(x+F(y) for x,y in zip(a.velocity_mps,uv)),
                tuple(x+F(y) for x,y in zip(b.velocity_mps,lv)),tuple(x+F(y) for x,y in zip(a.acceleration_mps2,ua)),
                tuple(x+F(y) for x,y in zip(b.acceleration_mps2,la)),first_size_rate=us,second_size_rate=ls,
                first_size_acceleration=uq,second_size_acceleration=lq)
            exit=first_overlap_departure(gaps,(limit-now)/1000,distance_epsilon=DIST)
            if exit is not None:limit=min(limit,now+exit*1000)
        return limit

    def settle(self):
        if not self.ready or self.settling:return
        self.settling=True;w=self.world
        try:
            frame=w.body_paths.frame;before={}
            if frame is not None and frame.begin_ms<=F(w.time)<=frame.end_ms:
                before={n:tuple(map(dec,p.velocity(w.time))) for n,p in frame.pieces}
            self.scan()
            for n,a in sorted(w.fighters.items()):
                m=w.motion[n]
                if a.hp<=0:continue
                support=w.collider_system.find_support(a)
                static=w.terrain_support.enabled and not w._climbing(n)
                if (m.get('support_id') in w.fighters or static) and m['jump'] is None:
                    if support is None:
                        velocity=before[n] if n in before else self.requested_motion(n)[0]
                        reason='body_support_lost' if m.get('support_id') in w.fighters else 'static_support_lost'
                        w.spatial_transitions.release_support(a,reason,velocity=velocity)
                    elif (m.get('support_id'),m.get('support_part'))!=support:
                        old=m['support_id'];m['support_id'],m['support_part']=support
                        self.cache_key=None
                        if old!=support[0] or old in w.fighters:
                            event='body_support_parent_changed' if old in w.fighters else 'world_support_parent_changed'
                            w.log(event,actor=n,previous_support_id=old,support_id=support[0],support_part=support[1])
                elif w._airborne(n) and support is not None and support[0] in w.fighters:
                    velocity=w.mobile_motion(n)[0]
                    if abs(velocity[2])<=SPEED:
                        extra=w.apply_air_contact_velocity(a,velocity,[{'first':n,'second':support[0],'normals':[(0,0,1)]}])
                        if extra is not None and any(extra.values()):w.apply_target_status_additions(n,extra,a.armor)
        finally:self.settling=False

    def committed(self,frame,end):
        if self.ready and frame.constraints is not None and frame.constraints.path is not None and self.current:
            self.last_committed={'until_ms':str(end),'contact_ids':tuple(sorted(self.current.values())),
                'path':frame.constraints.path.record()}

    def result(self):
        if not self.enabled:return {}
        return {'body_support_rules':self.world.combat_locomotion_input['body_support'],
            'body_support_contacts':deepcopy(list(self.rows.values())),
            'last_committed_body_support_plan':deepcopy(self.last_committed)}


class BodySupportRules:
    def free_mobile_motion(self,name):
        velocity,acceleration=super().free_mobile_motion(name)
        support=getattr(self,'body_support',None)
        if support is not None and support.gravity(name) and self.motion[name]['jump'] is None:
            acceleration=(*acceleration[:2],-self.jump_gravity)
        return velocity,acceleration

    def mobile_motion(self,name):
        velocity,acceleration=super().mobile_motion(name)
        support=getattr(self,'body_support',None)
        if (support is not None and support.gravity(name) and not self.grapple_links.joined(name)
                and self.motion[name]['jump'] is None):acceleration=(*acceleration[:2],-self.jump_gravity)
        return velocity,acceleration
