"""Pure, replaceable decisions for the shared encounter runner."""
from dataclasses import dataclass
from decimal import Decimal


@dataclass(frozen=True)
class AbilityOption:
    ability_id: str
    ready_at_ms: Decimal
    ammo: int | None = None
    resource_ready_at_ms: Decimal = Decimal(0)


@dataclass(frozen=True)
class ActorOptions:
    actor: str
    target: str | None
    time_ms: Decimal
    busy_until_ms: Decimal
    abilities: tuple[AbilityOption, ...]
    reload_when_empty: bool = False


@dataclass(frozen=True)
class ActionDecision:
    kind: str
    at_ms: Decimal
    ability_id: str | None = None


class PriorityWhenReady:
    """Choose the first available ability; durations and legality are engine inputs."""
    def choose(self, options: ActorOptions) -> ActionDecision:
        if not options.abilities:
            raise ValueError('An action policy requires at least one ability')
        if options.busy_until_ms > options.time_ms:
            return ActionDecision('wait', options.busy_until_ms)
        future = []
        for ability in options.abilities:
            if ability.ammo == 0:
                if options.reload_when_empty:
                    if ability.resource_ready_at_ms > options.time_ms:
                        future.append(ability.resource_ready_at_ms)
                        continue
                    return ActionDecision('reload', options.time_ms, ability.ability_id)
                continue
            available = max(ability.ready_at_ms, ability.resource_ready_at_ms)
            if available <= options.time_ms:
                return ActionDecision('activate', options.time_ms, ability.ability_id)
            future.append(available)
        return ActionDecision('wait', min(future, default=Decimal('Infinity')))
