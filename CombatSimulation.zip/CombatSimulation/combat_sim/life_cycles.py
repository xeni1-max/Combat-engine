"""Actor lives on the shared timeline, separate from autonomous source identity.

The restoration API is an engine transition. The authored death-triggered
ability has its separate generation-bound controller in combat_sim.revival.
"""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.mechanics.life import life_generation
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite
from combat_sim.battle_models import decimal_value as dec
from combat_sim.oriented_geometry import OrientedCuboid,boxes_overlap

CONTROLLED_EVENTS = frozenset({'decision', 'active_started', 'active_completed',
    'recovery_completed', 'self_effect', 'movement_climb_corner',
    'movement_sprint_exhausted', 'action_restriction_expired','block_second_layer'})


class LifeCycles:
    def __init__(self, world, definition=None):
        self.world = world
        self.enabled = definition is not None
        if self.enabled and (definition != {'mode': 'actor_lives_v1'} or
                not world.applied_damage.enabled or not world.cooldown_system.enabled or
                not world.combat_locomotion_input.get('action_ownership')):
            raise UnsupportedMechanicError('Actor lives require owned actions, typed effects, cooldown work and HP history')
        self.lives = {}

    def attach(self):
        if not self.enabled:
            return
        for name, actor in self.world.fighters.items():
            actor.life_reporting = True
            self.lives[name] = [self._life(actor, 'initial_state')]

    def _life(self, actor, source):
        return {'generation': actor.life_generation, 'born_at_ms': self.world.time,
            'died_at_ms': None, 'restoration_source': source, 'initial_hp': actor.hp}

    def generation(self, name):
        return self.world.fighters[name].life_generation if self.enabled else None

    def target_fields(self, name):
        return {'target_life_generation': self.generation(name)} if self.enabled else {}

    def target_matches(self, payload):
        generation = payload.get('target_life_generation')
        return generation is None or generation == self.world.fighters[payload['target']].life_generation

    def stamp_event(self, kind, payload):
        if not self.enabled or kind not in CONTROLLED_EVENTS:
            return payload
        actor = self.world.fighters[payload['actor']]
        generation=life_generation(payload.get('actor_life_generation',actor.life_generation))
        if generation is None:raise ValueError('Controlled event needs its actor life')
        return {**payload, 'actor_life_generation': generation}

    def event_live(self, kind, payload):
        if not self.enabled or kind not in CONTROLLED_EVENTS:
            return True
        actor = self.world.fighters[payload['actor']]
        return (actor.hp > 0 and actor.died_at_ms is None and
            payload.get('actor_life_generation') == actor.life_generation)

    def finish_death(self, actor):
        if not self.enabled:
            return
        world = self.world
        world.healing.invalidate()
        world.controlled_damage.retire_life(actor)
        world.timed_gathering.retire_life(actor)
        world.portals.retire_life(actor)
        if getattr(world,'segment_fields',None) is not None:world.segment_fields.retire_life(actor)
        world.grapple_links.retire_life(actor)
        world.bindings.retire_life(actor)
        world.knock_motion.retire_life(actor)
        if getattr(world,'dodging',None) is not None:world.dodging.retire_life(actor)
        world.blocking.retire_life(actor)
        world.attack_modifiers.retire_life(actor)
        life = self.lives[actor.id][-1]
        if life['died_at_ms'] is not None:
            return
        life['died_at_ms'] = world.time
        world.applied_damage.history.observe_until(world.time)
        life['eligible_damage_last_10s_at_death'] = world.applied_damage.history.amount(
            actor=actor.id, end=world.time, window_ms=10000, eligible_only=True)
        world.projectile_system.retire_owner_life(actor.id,actor.life_generation)
        world.effect_system.retire_life(actor.id, actor.life_generation)
        world.poison_volumes.retire_life(actor.id,actor.life_generation)
        for key in list(world.restriction_clocks):
            if key[0] == actor.id:
                del world.restriction_clocks[key]
        if actor.action_registry is not None:
            actor.action_registry.blocks.clear()
        # Preserve known shield losses and absolute eligibility clocks, but an
        # old forecast may not commit into a later life or through a dead gap.
        world.shield_recovery[actor.id].invalidate_plans()
        for volume in world.cooldown_system.volumes.values():
            world.cooldown_system._membership(volume, actor.id, False)
        world.revival.on_death(actor)

    def revive(self, name, *, expected_generation, hp, source):
        """Restore a dead actor atomically at its retained physical body pose.

        Invalid inputs raise before mutation. A stale request or occupied body
        returns False; the authored caller must decide its own retry lifecycle.
        Retain armor, shield/debt, ammo, hands, fatigue/status and cooldown work.
        No old controlled action, target attachment or thermal memory transfers.
        """
        if not self.enabled:
            raise UnsupportedMechanicError('Life restoration requires explicit actor-life rules')
        if name not in self.world.fighters:
            raise ValueError('Unknown life restoration target')
        if life_generation(expected_generation) is None:
            raise ValueError('Restoration requires an expected life generation')
        amount = finite(hp, 'Restored HP', positive=True)
        if not isinstance(source, str) or not source:
            raise ValueError('Restoration needs source attribution')
        world = self.world
        actor = world.fighters[name]
        if amount > dec(actor.profile['max_hp']):
            raise ValueError('Restored HP exceeds the character maximum')
        if actor.life_generation != expected_generation or actor.died_at_ms is None or actor.hp > 0:
            return False
        if self.lives[name][-1]['died_at_ms'] is None or actor.live_actions():
            raise ValueError('Life death must settle before restoration')
        boxes = world.world_bodies[name]
        # Restoration's spatial preflight owns the finite-sheet crossing band.
        # Retain the solid/living-body early rejection without testing that
        # zero-thickness sheet again as a positive-volume solid.
        floor_id=world.terrain_definition['ground']['id'] if world.terrain_support.finite_ground else None
        obstacles = [part for key,parts in world.body_terrain_colliders().items() if key!=floor_id for part in parts]
        obstacles += [part for other, parts in world.world_bodies.items()
                      if other != name and world.fighters[other].hp > 0 for part in parts]
        if any((boxes_overlap(left,right,closed=False) if isinstance(left,OrientedCuboid) or isinstance(right,OrientedCuboid)
                else all(max(a,c) < min(b,d) for a,b,c,d in zip(
                    left.bounds[0], left.bounds[1], right.bounds[0], right.bounds[1])))
                for left in boxes for right in obstacles):
            world.log('life_restoration_blocked', actor=name, life_generation=expected_generation,
                reason='occupied_body_pose', source=source)
            return False
        spatial_plan = world.spatial_transitions.restoration_plan(actor,source)
        # All validation precedes the lifecycle commit. The frozen dead pose is
        # retained; unsupported air needs gravity rather than an invented floor.
        world.spatial_transitions.commit(spatial_plan,notify=False)
        actor.life_generation += 1
        world.healing.invalidate()
        actor.hp = amount
        actor.died_at_ms = None
        actor.decision_due = None
        actor.decision_revision += 1
        motion = world.motion[name]
        world.shield_recovery[name].invalidate_plans()
        world.thermal_recovery.invalidate(name)
        world.cooldown_system.resume_actor(actor)
        self.lives[name].append(self._life(actor, source))
        world.revival.on_restored(actor)
        world.refresh_mobile_locomotion()
        world.log('life_restored', actor=name, previous_life_generation=expected_generation,
            life_generation=actor.life_generation, hp=amount, source=source,
            support_id=motion['support_id'], state=actor.record())
        world.cooldown_system.settle()
        world.effect_system.settle()
        world.collider_system.dirty = True
        for living in world.fighters.values():
            if living.hp>0:
                living.decision_due=None;living.decision_revision+=1
                ready=max(world.time,dec(world.choices[living.id].get('start_ms',0)))
                # Weapon policy delays do not delay the common paid recovery
                # of a retained prone pose in a newly restored life.
                if world.equilibrium.enabled and living.knocked_down:ready=world.time
                world.request_decision(living.id,ready)
        return True

    def result(self):
        return {'life_cycle_rules': self.world.combat_locomotion_input['life_cycles'],
            'actor_lives': deepcopy(self.lives)} if self.enabled else {}
