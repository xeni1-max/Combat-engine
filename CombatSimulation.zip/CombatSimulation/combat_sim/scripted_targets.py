"""Explicit, frozen world targets beside the ordinary living-enemy policy."""
from copy import deepcopy

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.velocity_projection import vector
from combat_sim.models import UnsupportedMechanicError
from combat_sim.terrain_anchors import TerrainAnchorCandidate


PROJECTILE_MODELS=frozenset(('slash_projectile','direct_projectile','projectile_delayed_area',
    'marking_projectile','binding_projectile','impact_binding_area','impact_area_projectile','construct_projectile','hook_projectile'))


class ScriptedTargets:
    def __init__(self,world):
        self.world=world
        self.targets={}

    def validate(self,actor,config):
        definitions=config.get('ability_targets',{})
        if not isinstance(definitions,dict) or not set(definitions)<=set(config['abilities']):
            raise ValueError('Explicit targets must map selected ability IDs to targets')
        for ability_id,definition in definitions.items():
            ability=actor.profile['abilities'].get(ability_id,{})
            is_field=ability.get('execution_model') in ('contact_field','projectile_duplication_area','portal_pair','ballistic_leap')
            has_axis=ability.get('execution_model')=='contact_field'
            if ((not self.world.gravity_mode and not is_field) or
                    (ability.get('execution_model') not in PROJECTILE_MODELS and not is_field)):
                raise UnsupportedMechanicError('Explicit world targets require a shared physical projectile or contact field')
            if not isinstance(definition,dict) or definition.get('kind') not in ('world_point','surface'):
                raise ValueError('Explicit target needs world_point or surface kind')
            required={'kind','point_m'} | ({'collider_id','part'} if definition['kind']=='surface' else set())
            if (not required<=set(definition) or set(definition)-required-({'axis'} if has_axis else set())):
                raise ValueError('Explicit target fields do not match its kind')
            point=vector(definition['point_m'])
            target={'kind':definition['kind'],'point_m':tuple(map(dec,point))}
            if has_axis and 'axis' in definition:
                if definition['axis'] not in ('x','y'):raise ValueError('Field axis must be x or y')
                target['axis']=definition['axis']
            if definition['kind']=='surface':
                registry=self.world.collider_system.registry
                identity=definition['collider_id'];part=definition['part']
                if not isinstance(identity,str) or identity not in registry.objects or not isinstance(part,str):
                    raise ValueError('Surface target needs a registered collider and part')
                obj=registry.objects[identity]
                candidate=TerrainAnchorCandidate(identity,obj.collision_revision,part,point)
                if not self.world.terrain_anchors.valid_candidate(candidate):
                    raise ValueError('Surface target must lie on a current solid face')
                target.update(collider_id=identity,collider_revision=obj.collision_revision,part=part)
            self.targets[(actor.id,ability_id)]=target

    def for_ability(self,actor,ability_id):
        target=self.targets.get((actor.id,ability_id))
        return None if target is None else deepcopy(target)
