"""Prospective live shield stock for delivered venom and bypassing gas toxin."""
from decimal import Decimal as D

from combat_sim.effect_models import HeatExposure


def shield_view(world,target,begin,end):
    actor=world.fighters[target]
    if world.thermal_recovery.is_active(target):
        plan=world.thermal_recovery.caches[target]['thermal']
        return lambda time:max(D(0),plan.at(time)[0])
    plan=world.shield_recovery[target].plan(begin,end)
    stock=actor.shield
    heat=tuple(e for e in world.effect_system.effects.values() if isinstance(e,HeatExposure)
        and e.target==target and e.channel=='shield' and not e.ended)
    return lambda time:max(D(0),stock+plan.delivered(time)-sum(
        (e.integral(e.parameters.output,begin,time) for e in heat),D(0)))
