"""Native contact transactions and causally later, committed event delivery.

The receipt pins bodies, lives, groups and surfaces before collision responses
can end a hold. Observers never become character abilities. Future cast handlers
still own their actual cost, speed, contact damage and holding requirements.
"""
from decimal import Context,localcontext
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.contact_models import (ContactActor,ContactLink,ContactSurface,NativeContact,ContactObserver,
    ContactWave,ContactDelivery,PreparedContactWave)
from combat_sim.mechanics.life import life_generation
from combat_sim.models import UnsupportedMechanicError


EVENT='body_contact_signal'


class BodyContactSignals:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.owner=object();self.ids=count(1)
        self.observers={};self.rows={}
        if self.enabled and (definition!={'mode':'committed_body_contacts_v1'} or not world.mobile_mode or
                not world.life_cycles.enabled or not world.spatial_transitions.enabled or not world.body_paths.enabled):
            raise UnsupportedMechanicError('Body contact signals require current living saved-path physics')

    def watch(self,identity,actor,generation,handler,*,scope='owned',action_id=None,phases=('active',)):
        """Register a cast handler or explicitly labelled engineering observer."""
        if not self.enabled:raise UnsupportedMechanicError('Body contact signals are disabled')
        if not isinstance(identity,str) or not identity or identity in self.observers:raise ValueError('Observer identities are unique')
        generation=life_generation(generation)
        if generation is None or not isinstance(actor,str) or actor not in self.world.fighters or not callable(handler):raise ValueError('Observer needs an actor, life and handler')
        a=self.world.fighters[actor]
        if a.hp<=0 or a.life_generation!=generation:raise ValueError('Observer source life is not current and living')
        if scope not in ('owned','engineering'):raise ValueError('Observer scope must be explicit')
        if not isinstance(phases,(tuple,list)) or not phases or any(not isinstance(p,str) or not p for p in phases):
            raise ValueError('Observer phases must be nonempty names')
        ability=None
        if scope=='owned':
            if type(action_id) is not int or action_id<=0:raise ValueError('Owned observer needs an action')
            action=a.action_by_id(action_id)
            if action is None:raise ValueError('Observer action is not owned by this actor')
            ability=action.ability_id
        elif action_id is not None:raise ValueError('Engineering observers do not impersonate owned actions')
        observer=ContactObserver(identity,actor,generation,scope,action_id,ability,tuple(sorted(set(phases))),handler)
        self.observers[identity]=dict(observer=observer,status='active',created_at_ms=self.world.time)
        return observer

    def unwatch(self,identity,*,reason='released'):
        row=self.observers.get(identity)
        if row is None or row['status']!='active':return False
        if not isinstance(reason,str) or not reason:raise ValueError('Observer end needs a reason')
        row.update(status='ended',ended_at_ms=self.world.time,end_reason=reason);return True

    def settle(self):
        if not self.enabled:return
        for identity,row in self.observers.items():
            if row['status']!='active':continue
            o=row['observer'];a=self.world.fighters[o.actor]
            if a.hp<=0 or a.life_generation!=o.life_generation:self.unwatch(identity,reason='source_life_ended')
            elif o.scope=='owned' and a.action_by_id(o.action_id) is None:self.unwatch(identity,reason='owner_action_ended')

    def states(self):
        w=self.world
        return tuple(ContactActor(actor=n,life_generation=a.life_generation,alive=a.hp>0,facing=a.facing,
            reference_m=tuple(w.spatial_transitions.reference(n)),body_origin_m=tuple(a.body_origin_m),
            velocity_mps=tuple(w.mobile_motion(n)[0]),maximum_hp=dec(a.profile['max_hp']),hp=a.hp,armor=a.armor,
            shield=a.shield,status_resistance=w.target_status_resistance(a),dyspnea=a.dyspnea,
            disorientation=a.disorientation,instability=a.instability,
            actions=tuple(sorted((x.id,x.ability_id,x.kind,x.phase) for x in a.live_actions())))
            for n,a in sorted(w.fighters.items()))

    def links(self):
        w=self.world
        return tuple(ContactLink(identity,r['controller'],r['target'],r['controller_life_generation'],
            r['target_life_generation'],r.get('ability'),r.get('holding_action_id'))
            for identity,r in sorted(w.grapple_links.links.items()) if r['status']=='active' and all(
                w.fighters[n].hp>0 and w.fighters[n].life_generation==r[key] for n,key in
                ((r['controller'],'controller_life_generation'),(r['target'],'target_life_generation'))))

    def capture(self,contacts):
        if not self.enabled:return None
        with localcontext(Context(prec=self.world.precision)):
            return self._capture(contacts)

    def _capture(self,contacts):
        self.settle();w=self.world;receipts=[]
        for c in contacts:
            a,b=c['first'],c['second']
            if w.fighters[a].hp<=0 or b in w.fighters and w.fighters[b].hp<=0:continue
            surface=None
            if b not in w.fighters:
                obj=w.collider_system.registry.objects.get(b)
                if obj is None or not obj.active(w.time) or not obj.policy.bodies:continue
                if 'collider_id' in c and not w.collider_system.registry.contact_live(c,'bodies',w.time):continue
                surface=ContactSurface(b,obj.collision_revision,tuple(sorted(obj.identity.tags)),obj.hp,obj.permanent)
            normals=tuple(sorted(set(tuple(map(dec,n)) for n in c['normals'])))
            receipts.append(NativeContact(a,b,normals,bool(c.get('pose_only',False)),surface))
        if not receipts:return None
        receipts=tuple(sorted(receipts,key=lambda c:(c.first,c.second,c.normals,c.pose_only)))
        groups=w.grapple_links.groups();matches=[]
        for identity,row in sorted(self.observers.items()):
            if row['status']!='active':continue
            o=row['observer'];a=w.fighters[o.actor]
            if o.scope=='owned' and a.action_by_id(o.action_id).phase not in o.phases:continue
            group=next((g for g in groups if o.actor in g),(o.actor,))
            indices=tuple(i for i,c in enumerate(receipts) if not c.pose_only and (c.first in group or c.second in group))
            if indices:matches.append((o,indices))
        return PreparedContactWave(self.owner,'body-contact:'+str(next(self.ids)),w.time,receipts,
            self.states(),groups,self.links(),tuple(matches))

    def commit(self,prepared):
        if prepared is None:return
        with localcontext(Context(prec=self.world.precision)):
            return self._commit(prepared)

    def _commit(self,prepared):
        if (not self.enabled or not isinstance(prepared,PreparedContactWave) or prepared.owner is not self.owner or
                prepared.time_ms!=self.world.time):raise ValueError('Contact commit needs this transaction and clock')
        if prepared.identity in self.rows:raise ValueError('Contact transaction already committed')
        wave=ContactWave(prepared.identity,prepared.time_ms,prepared.contacts,prepared.before,self.states(),
            prepared.groups,self.world.grapple_links.groups(),prepared.links,self.links())
        deliveries=tuple(ContactDelivery(wave,o,indices) for o,indices in prepared.matches)
        self.rows[wave.identity]=dict(wave=wave,deliveries=deliveries,status='queued' if deliveries else 'recorded',
            dispatched_at_ms=None)
        self.world.log('body_contact_wave_committed',wave_id=wave.identity,contacts=len(wave.contacts),
            observer_ids=tuple(d.observer.identity for d in deliveries))
        if deliveries:self.world.push(self.world.time,EVENT,{'wave_id':wave.identity},priority=3)

    def live(self,payload):
        row=self.rows.get(payload.get('wave_id'));return row is not None and row['status']=='queued'

    def process(self,payload):
        with localcontext(Context(prec=self.world.precision)):
            return self._process(payload)

    def _process(self,payload):
        if not self.live(payload):return
        row=self.rows[payload['wave_id']];row.update(status='dispatched',dispatched_at_ms=self.world.time)
        for delivery in row['deliveries']:
            self.world.log('body_contact_signal_dispatched',**delivery.record())
            delivery.observer.handler(delivery)

    def result(self):
        if not self.enabled:return {}
        self.settle()
        return dict(body_contact_signal_rules=self.world.combat_locomotion_input['body_contact_signals'],
            body_contact_waves=[dict(**r['wave'].record(),status=r['status'],
                dispatched_at_ms=None if r['dispatched_at_ms'] is None else str(r['dispatched_at_ms']),
                deliveries=tuple(d.record() for d in r['deliveries'])) for r in self.rows.values()],
            body_contact_observers=[dict(**r['observer'].record(),**{k:str(v) if k.endswith('_ms') else v
                for k,v in r.items() if k!='observer'}) for r in self.observers.values()])
