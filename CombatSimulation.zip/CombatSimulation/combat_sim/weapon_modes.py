"""Owned weapon swaps, finite per-actor inventory and released poison carriers."""
from copy import deepcopy
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.dyspnea import validate_action_dyspnea_rule
from combat_sim.mechanics.effort import CATEGORIES
from combat_sim.projectile_entities import ProjectileContactPolicy
from combat_sim.effect_models import EffectSource
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite


class WeaponModes:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'owned_inventory_v1'} or not world.mobile_mode):
            raise UnsupportedMechanicError('Weapon modes require the shared moving world')
        self.configs={};self.inventories={};self.swaps={};self.bursts={};self.by_projectile={};self.ids=count(1)

    def attach_actor(self,actor):
        cfg=actor.profile.get('weapon_mode')
        if not self.enabled or cfg is None:return
        if (not isinstance(cfg,dict) or set(cfg)!={'activation_ability','attack_ability','capacity','cooldown_ms','swap','firing','source'}
                or cfg['activation_ability']==cfg['attack_ability'] or
                any(k not in actor.profile['abilities'] for k in (cfg['activation_ability'],cfg['attack_ability']))):
            raise ValueError('Weapon mode must name existing activation and replaced abilities')
        if type(cfg['capacity']) is not int or cfg['capacity']<=0:raise ValueError('Weapon capacity must be a positive integer')
        finite(cfg['cooldown_ms'],'Weapon-mode cooldown',positive=True)
        if (cfg['swap'].get('execution_model')!='weapon_swap' or cfg['swap'].get('target_mode')!='self' or
                cfg['swap'].get('swap_target','launcher')!='launcher' or
                cfg['swap'].get('dyspnea',{}).get('payment_timing')!='active_start' or
                cfg['firing'].get('execution_model')!='poison_projectile' or
                cfg['firing'].get('dyspnea',{}).get('payment_timing')!='active_firing_end' or
                dec(cfg['firing'].get('pre_mitigation_damage',-1))!=0 or dec(cfg['swap'].get('pre_mitigation_damage',-1))!=0 or
                cfg['firing'].get('weapon_cooldown_anchor')!='active_firing_end'):
            raise UnsupportedMechanicError('Weapon mode needs owned swap and zero-direct-damage poison firing')
        for definition in (cfg['swap'],cfg['firing']):
            timing=actor.profile['timing_profiles'][definition['timing_profile']]
            finite(timing['gathering_ms'],'Weapon preparation');finite(timing['active_ms'],'Weapon Active',positive=True)
            if dec(timing['active_ms'])!=dec(timing['active_ms']).to_integral_value():raise ValueError('Base weapon Active uses whole milliseconds')
            finite(definition['dyspnea']['base_value'],'Weapon effort')
            validate_action_dyspnea_rule(definition['dyspnea'])
            source=definition.get('effort_source_ability',cfg['activation_ability'] if definition is cfg['swap'] else cfg['attack_ability'])
            phase=actor.profile.get('documented_abilities',{}).get(source,{}).get('effort_phases',{}).get(definition.get('effort_phase'),{})
            if phase.get('category') not in CATEGORIES:raise ValueError('Weapon variant requires its reviewed effort source')
            if set(definition['hand_positions_m']['start'])!={'left','right'} or set(definition['hand_positions_m']['end'])!={'left','right'}:
                raise ValueError('Weapon swap and firing require their two authored hands')
            for phase in ('start','end'):
                for point in definition['hand_positions_m'][phase].values():
                    if len(point)!=3 or any(isinstance(x,bool) or not dec(x).is_finite() for x in point):
                        raise ValueError('Weapon hands require finite xyz points')
        poison=cfg['firing'].get('poison')
        if not isinstance(poison,dict) or set(poison)!={'radius_m','toxicity','duration_ms'}:
            raise ValueError('Poison carrier requires explicit released chemical parameters')
        for key,value in poison.items():finite(value,key,positive=True)
        finite(cfg['firing']['weapon_cooldown_ms'],'Weapon firing cooldown',positive=True)
        geometry=cfg['firing']['projectile_geometry']
        if (geometry.get('shape')!='sphere' or geometry.get('origin')!='ability_start_hand' or
                geometry.get('origin_hand') not in ('left','right') or geometry.get('aim')!='torso_centre'):
            raise UnsupportedMechanicError('Poison carrier needs current shared hand/torso geometry')
        finite(geometry['radius_m'],'Carrier radius')
        if ProjectileContactPolicy.from_definition(geometry.get('contact_policy'))!=ProjectileContactPolicy():
            raise UnsupportedMechanicError('Poison carrier detonates at its first physical collision')
        timing=actor.profile['timing_profiles'][cfg['firing']['timing_profile']]
        finite(timing['projectile_speed_mps'],'Carrier speed',positive=True)
        if timing.get('projectile_release_timing')!='after_active' or dec(timing.get('projectile_acceleration_mps2',0))!=0:
            raise UnsupportedMechanicError('Current poison carriers use ballistic end-of-firing release')
        self.configs[actor.id]=deepcopy(cfg)
        state={'mode':'main','rounds':0,'capacity':cfg['capacity']}
        self.inventories[actor.id]=state;actor.weapon_inventory=state
        actor.ability_resolver=lambda identity,actor=actor:self.definition(actor,identity)

    def validate(self,actor):
        w=self.world
        if (actor.id not in self.configs or not w.gravity_mode or not w.poison_volumes.enabled or
                not w.effort_system.enabled or not w.life_cycles.enabled or actor.action_registry is None):
            raise UnsupportedMechanicError('Actual launcher needs owned gravity projectiles, poison, effort and actor lives')

    def definition(self,actor,identity):
        cfg=self.configs.get(actor.id)
        if cfg is None:return None
        if identity==cfg['activation_ability']:return cfg['swap']
        if identity==cfg['attack_ability'] and self.inventories[actor.id]['mode']=='launcher':return cfg['firing']
        return None

    def slot(self,actor,identity):
        cfg=self.configs.get(actor.id)
        return cfg['attack_ability'] if cfg and identity in (cfg['activation_ability'],cfg['attack_ability']) else identity

    def empty(self,actor,identity):
        cfg=self.configs.get(actor.id);state=self.inventories.get(actor.id)
        return bool(cfg and identity==cfg['attack_ability'] and state['mode']=='launcher' and state['rounds']==0)

    def snapshot(self,actor,action,ability):
        cfg=self.configs.get(actor.id)
        if cfg and action.ability_id in (cfg['activation_ability'],cfg['attack_ability']):
            action.definition_snapshot=deepcopy(ability)
            action.definition_variant=('swap:'+ability.get('swap_target','launcher') if action.kind=='weapon_swap'
                else self.inventories[actor.id]['mode'])

    def selected(self,actor,action):
        if action.kind!='weapon_swap':return
        cfg=self.configs[actor.id];a=self.world.action_definition(actor,action)
        self.swaps[action.id]={'actor':actor.id,'action_id':action.id,'source_life_generation':actor.life_generation,
            'from_mode':self.inventories[actor.id]['mode'],'to_mode':a.get('swap_target','launcher'),
            'selected_at_ms':self.world.time,'status':'preparing','capacity':cfg['capacity']}
        self.world.log('weapon_swap_requested',**deepcopy(self.swaps[action.id]))

    def active(self,actor,action):
        row=self.swaps[action.id];row.update(status='active',active_at_ms=self.world.time)

    def complete(self,actor):
        w=self.world;action=actor.current;cfg=self.configs[actor.id];ability=w.action_definition(actor,action)
        state=self.inventories[actor.id];destination=ability.get('swap_target','launcher')
        if destination not in ('launcher','main'):raise ValueError('Unknown weapon swap destination')
        actor.hands.update(ability['hand_positions_m']['end'])
        if destination=='launcher':
            state.update(mode='launcher',rounds=cfg['capacity'])
            actor.ammo[cfg['attack_ability']]=cfg['capacity']
            w.cooldown_system.start(actor,cfg['activation_ability'],cfg['cooldown_ms'],action.id)
        else:
            state.update(mode='main',rounds=0);actor.ammo.pop(cfg['attack_ability'],None)
        row=self.swaps[action.id];row.update(status='completed',completed_at_ms=w.time)
        w.log('weapon_swap_completed',**deepcopy(row),inventory=deepcopy(state))
        actor.current=None;w.request_decision(actor.id,w.time)

    def try_return(self,actor):
        cfg=self.configs.get(actor.id);w=self.world
        if cfg is None or not self.empty(actor,cfg['attack_ability']):return False
        if (cfg['activation_ability'] in w.choices[actor.id]['abilities'] and
                w.cooldown_system.ready_at(actor,cfg['activation_ability'])<=w.time):
            return False
        if not w.weapon_requirements_available(actor,cfg['activation_ability'],False):return False
        ready=w.resource_ready_time(actor,cfg['swap']['dyspnea'])
        if ready>w.time:
            if ready.is_finite():w.request_decision(actor.id,ready)
            return False
        definition=deepcopy(cfg['swap']);definition['swap_target']='main'
        w.start_team_action(actor,actor.id,cfg['activation_ability'],False,None,None,definition)
        return True

    def consume(self,actor,action):
        state=self.inventories[actor.id];cfg=self.configs[actor.id]
        if state['mode']!='launcher' or state['rounds']<=0:raise ValueError('Poison firing needs a loaded launcher')
        state['rounds']-=1;actor.ammo[cfg['attack_ability']]=state['rounds']
        self.world.log('launcher_round_consumed',actor=actor.id,action_id=action.id,rounds_remaining=state['rounds'])

    def cancelled(self,actor,action,reason):
        row=self.swaps.get(action.id)
        if row and row['status'] not in ('completed','cancelled'):
            row.update(status='cancelled',cancelled_at_ms=self.world.time,end_reason=reason)

    def expand(self,packet):
        """One actual projectile collision creates one cloud and one status wave."""
        w=self.world;pid=packet['projectile_id']
        if pid in self.by_projectile:return []
        payload=w.projectile_flights[pid]['contact_payload'];poison=payload['poison']
        source=EffectSource(packet['actor'],packet['ability'],packet['action_id'],pid,packet['source_life_generation'])
        volume=w.poison_volumes.deploy(source,packet['location_m'],**poison)
        # The instantaneous pressure pulse follows area-blocking cover; the
        # separately released chemical volume keeps unoccluded membership.
        names=sorted(w.body_area_recipients(packet['location_m'],poison['radius_m'],'sphere',occlusion='world'))
        identity='poison-burst:'+str(next(self.ids))
        row={'id':identity,'projectile_id':pid,'at_ms':w.time,'actor':source.actor,'ability':source.ability,
            'action_id':source.action_id,**source.life_record(),'location_m':deepcopy(packet['location_m']),
            'volume_id':volume,'recipients':names,'target_effects':deepcopy(payload['target_effects'])}
        self.bursts[identity]=row;self.by_projectile[pid]=identity
        w.log('poison_grenade_detonated',**deepcopy(row))
        return [dict(actor=source.actor,ability=source.ability,action_id=source.action_id,projectile_id=pid,
            **source.life_record(),target=n,**w.life_cycles.target_fields(n),component='poison_area',
            collision_kind='body',location_m=deepcopy(packet['location_m']),poison_burst_id=identity) for n in names]

    def result(self):
        return {'weapon_mode_rules':deepcopy(self.world.combat_locomotion_input['weapon_modes']),
            'weapon_inventories':deepcopy(self.inventories),'weapon_swaps':deepcopy(list(self.swaps.values())),
            'poison_grenade_bursts':deepcopy(list(self.bursts.values()))} if self.enabled else {}
