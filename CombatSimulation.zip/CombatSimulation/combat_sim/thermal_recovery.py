"""Shared-clock coupling of incident heat, body temperature and shield recovery.

Old definitions retain their earlier adapter. Current definitions track incident
memory from deployment and switch a recipient to fluid layers at actual recovery
onset, never by inspecting future commands. Conditional dense epochs can be read
in arbitrary prefixes; observations neither select their step grids nor pay work.
"""
from dataclasses import dataclass
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import HeatExposure
from combat_sim.mechanics.heat import heat_coefficient
from combat_sim.mechanics.recovery_flow import RootRate,RecoveryCursor
from combat_sim.mechanics.thermal_balance import ThermalSource,build_thermal_plan
from combat_sim.mechanics.rate_damage import RateDamageSource
from combat_sim.mechanics.electrocution import FORMULA as ELECTROCUTION_FORMULA
from combat_sim.models import UnsupportedMechanicError
from combat_sim.mechanics.life import target_life_record


@dataclass
class IncidentHeat:
    id: str
    volume_id: str
    target: str
    source: object
    parameters: object
    reference: D
    q_reference: D = D(0)
    exposed: bool = True
    residual: bool = True
    revision: int = 0
    ended: bool = False
    target_life_generation: int | None = None

    def q_at(self,time):
        return self.q_reference if self.ended else max(D(0),self.q_reference+
            (D(1) if self.exposed else -self.parameters.decay)*(time-self.reference)/1000)

    @property
    def expiry(self):return None if self.exposed else self.reference+1000*self.q_reference/self.parameters.decay

    def record(self,time):
        return {'id':self.id,'kind':'incident_heat','volume_id':self.volume_id,'target':self.target,
            'actor':self.source.actor,'ability':self.source.ability,'action_id':self.source.action_id,
            'reference_ms':self.reference,'q_reference':self.q_reference,'q_seconds':self.q_at(time),
            'exposed':self.exposed,'shield_residual_attached':self.residual,'expiry':self.expiry,
            'revision':self.revision,'status':'ended' if self.ended else 'active',
            **self.source.life_record(), **target_life_record(self.target_life_generation)}


class ThermalRecovery:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'fluid_layers_v1'} or not world.shield_flow_enabled):
            raise UnsupportedMechanicError('Fluid heat layers require analytic recovery and the typed-effect world')
        self.ids=count(1);self.incidents={};self.by_pair={};self.body_ids={};self.active=set();self.caches={}
        self.reformed_at={}

    def is_active(self,target):return target in self.active

    def invalidate(self,target=None):
        if target is None:self.caches.clear()
        else:self.caches.pop(target,None)

    def _current(self,target):
        return [self.incidents[key] for (volume,name),key in self.by_pair.items()
            if name==target and not self.incidents[key].ended]

    def track(self,volume,target,eligible):
        if not self.enabled:return None
        world=self.world;key=(volume.id,target)
        incident=self.incidents.get(self.by_pair.get(key))
        if eligible and (incident is None or incident.ended):
            incident=IncidentHeat('incident:'+str(next(self.ids)),volume.id,target,volume.source,volume.parameters,world.time,
                target_life_generation=world.life_cycles.generation(target))
            self.incidents[incident.id]=incident;self.by_pair[key]=incident.id;self.invalidate(target)
        elif incident is not None and not incident.ended and incident.exposed!=eligible:
            incident.q_reference=incident.q_at(world.time);incident.reference=world.time
            incident.exposed=eligible;incident.residual=eligible or world.fighters[target].shield>0
            incident.revision+=1;self.invalidate(target)
            if not eligible:
                if incident.expiry<=world.time:self._end_incident(incident)
                else:world.push(incident.expiry,'incident_heat_expired',{'incident_id':incident.id,'revision':incident.revision})
        return incident

    def _end_incident(self,incident):
        incident.q_reference=D(0);incident.reference=self.world.time
        incident.ended=True;incident.revision+=1;incident.residual=False;self.invalidate(incident.target)
        if (incident.target in self.active and not self._current(incident.target)
                and not self.world.controlled_damage.for_target(incident.target)):
            manager=self.world.effect_system
            for other in self.incidents.values():
                if other.target!=incident.target:continue
                body=manager.effects.get(self.body_ids.get(other.id))
                if body is not None and not body.ended:
                    if body.q_at(self.world.time)>D('1e-10'):raise ArithmeticError('Body heat outlived incident thermal memory')
                    body.q_reference=D(0);body.reference_ms=self.world.time
                    manager.end_effect(body,'thermal_memory_zero')
            self.active.remove(incident.target)
            self.world.log('thermal_recovery_settled',target=incident.target)

    def retire_life(self,target,generation):
        for incident in self.incidents.values():
            if incident.target==target and incident.target_life_generation==generation and not incident.ended:
                incident.q_reference=incident.q_at(self.world.time);incident.reference=self.world.time
                incident.ended=True;incident.revision+=1;incident.exposed=False;incident.residual=False
        for key in list(self.by_pair):
            if key[1]==target:del self.by_pair[key]
        self.active.discard(target);self.reformed_at.pop(target,None);self.invalidate(target)

    def incident_live(self,payload):
        item=self.incidents.get(payload['incident_id'])
        return item is not None and not item.ended and item.revision==payload['revision']

    def expire_incident(self,payload):
        if not self.incident_live(payload):return
        incident=self.incidents[payload['incident_id']];self._end_incident(incident)
        self.world.log('incident_heat_expired',incident_id=incident.id,target=incident.target)

    def on_break(self,target):
        if not self.enabled:return
        for incident in self._current(target):
            if not incident.exposed:incident.residual=False
        self.invalidate(target)

    def _body(self,incident,initial=None):
        manager=self.world.effect_system;world=self.world
        effect=manager.effects.get(self.body_ids.get(incident.id))
        if effect is not None and not effect.ended:return effect
        if initial is None:initial=D(0)
        effect=HeatExposure('effect:'+str(next(manager.effect_ids)),incident.source,incident.volume_id,incident.target,'actor','hp',
            incident.parameters,world.time,world.time,initial,incident.exposed,evolution_model='fluid_layers_v1',
            target_life_generation=incident.target_life_generation)
        manager.effects[effect.id]=effect;self.body_ids[incident.id]=effect.id
        manager.tracks[(incident.volume_id,incident.target)]=effect.id
        world.log('heat_started',effect=effect.record(world.time),autonomous=True,model='fluid_body_memory')
        if not effect.exposed:
            if effect.expiry<=world.time:manager.end_effect(effect,'body_thermal_memory_zero')
            else:world.push(effect.expiry,'typed_effect_expired',{'effect_id':effect.id,'revision':effect.revision})
        return effect

    def _activate(self,target):
        world=self.world;manager=world.effect_system;self.active.add(target)
        for incident in self._current(target):
            old=manager.effects.get(manager.tracks.get((incident.volume_id,target)))
            q=old.q_at(world.time) if old is not None and not old.ended and old.channel=='hp' else D(0)
            if old is not None and not old.ended:manager.end_effect(old,'fluid_layer_transition')
            self._body(incident,q)
        if world.controlled_damage.for_target(target):
            world.log('continuous_damage_layers_activated',target=target,model='joint_continuous_layers_v1')
        else:world.log('thermal_recovery_activated',target=target,model='fluid_layers_v1')

    def set_eligible(self,volume,target,eligible,incident):
        manager=self.world.effect_system;world=self.world
        if incident is None or incident.ended and not eligible:return
        before=target in manager.members[volume.id]
        effect=manager.effects.get(self.body_ids.get(incident.id))
        if effect is None or effect.ended and eligible:effect=self._body(incident)
        if effect is None:return
        if not effect.ended and effect.set_exposed(world.time,eligible) and not eligible:
            if effect.expiry<=world.time:manager.end_effect(effect,'body_thermal_memory_zero')
            else:world.push(effect.expiry,'typed_effect_expired',{'effect_id':effect.id,'revision':effect.revision})
        if eligible:manager.members[volume.id].add(target)
        else:manager.members[volume.id].discard(target)
        if before!=eligible:
            world.log('heat_exposure_entered' if eligible else 'heat_exposure_left',volume_id=volume.id,
                effect_id=effect.id,target=target,target_kind='actor',q_seconds=effect.q_at(world.time),
                incident_q_seconds=incident.q_at(world.time))

    def _body_q(self,incident,time):
        effect=self.world.effect_system.effects.get(self.body_ids.get(incident.id))
        return effect.q_at(time) if effect is not None and not effect.ended else D(0)

    def _key(self,target):
        actor=self.world.fighters[target]
        return actor.armor,actor.profile['resistances']['heat'],tuple((i.id,i.revision,i.exposed,i.residual,
            i.reference,i.q_reference) for i in self._current(target))

    def _cache(self,target):
        world=self.world;actor=world.fighters[target];old=self.caches.get(target);now=world.time
        if (old is not None and old['key']==self._key(target) and old['thermal'].begin<=now<old['thermal'].end
                and world.controlled_damage.compatible(target,old.get('controlled_key',()))):
            stock,q,_,_=old['thermal'].at(now)
            if abs(actor.shield-stock)<=D('1e-18') and all(abs((D(0) if isinstance(s,RateDamageSource) else self._body_q(self.incidents[s.id],now))-v)<=D('1e-18')
                    for s,v in zip(old['thermal'].sources,q)):
                try:old['cursor']._validate();return old
                except ValueError:pass
        recovery=world.shield_recovery[target]
        if recovery.delay<=0:raise UnsupportedMechanicError('Fluid heat requires positive delayed recovery')
        end=now+min(D(250),recovery.delay/2)
        end=world.controlled_damage.next_boundary(target,end)
        incidents=self._current(target)
        for incident in incidents:
            if incident.expiry is not None and incident.expiry>now:end=min(end,incident.expiry)
        plan=recovery.plan(now,end,work_tolerance_hp=D('1e-24'));sources=[]
        for incident in incidents:
            coefficient=dec(heat_coefficient(incident.parameters.output,actor.armor,actor.profile['resistances']['heat'],incident.parameters.decay))
            pressure=RootRate(incident.parameters.output,incident.q_at(now),now,D(1) if incident.exposed else -incident.parameters.decay)
            sources.append(ThermalSource(incident.id,pressure,self._body_q(incident,now),coefficient,
                incident.exposed,incident.residual,incident.parameters.decay))
        sources.extend(world.controlled_damage.sources(target))
        thermal=build_thermal_plan(plan,actor.shield,sources)
        formations=[]
        for segment in thermal.segments:
            if not segment.shield_begin and not segment.limited:
                if segment.at(segment.end)[0]>0:formations.append(segment.begin)
        cache={'key':self._key(target),'controlled_key':world.controlled_damage.key(target),
            'recovery':plan,'cursor':RecoveryCursor(recovery,plan),'thermal':thermal,'formations':formations}
        self.caches[target]=cache
        return cache

    def prepare(self,end):
        if not self.enabled:return end
        world=self.world;finish=end
        for target,actor in world.fighters.items():
            if actor.hp<=0:continue
            controlled=world.controlled_damage.for_target(target)
            if target in self.active and not controlled and not self._current(target):
                self.active.remove(target);self.invalidate(target)
            if target not in self.active:
                if not self._current(target) and not controlled:continue
                if not controlled:
                    plan=world.shield_recovery[target].plan(world.time,end,work_tolerance_hp=D('1e-24'))
                    positive=[p for p in plan.pieces if p.shape.constant_per_second or p.shape.terms or p.shape.affine_terms]
                    if not positive:continue
                    onset=positive[0].begin
                    if onset>world.time:finish=min(finish,onset);continue
                self._activate(target)
            cache=self._cache(target)
            for time in cache['formations']:
                if time==world.time:self._note_reformed(target,time)
                elif time>world.time:finish=min(finish,time)
            finish=min(finish,cache['thermal'].end)
        return finish

    def _note_reformed(self,target,time):
        if self.reformed_at.get(target)==time:return
        self.reformed_at[target]=time
        self.world.log('shield_flow_reformed',target=target,onset_ms=time,
            meaning='Net positive flow can build stock; no shield HP is created at this instant')

    def components(self,begin,end):
        result={};world=self.world
        for target in sorted(self.active):
            if world.fighters[target].hp<=0:continue
            cache=self.caches[target];plan=cache['thermal']
            first,last=plan.at(begin),plan.at(end)
            hp=tuple(max(D(0),b-a) for a,b in zip(first[2],last[2]))
            shield=tuple(max(D(0),b-a) for a,b in zip(first[3],last[3]))
            total=max(D(0),first[0]+cache['recovery'].delivered(end)-cache['recovery'].delivered(begin)-last[0])
            nominal=sum(shield,D(0))
            shield=tuple(v*total/nominal for v in shield) if nominal else shield
            entries=[]
            for index,s in enumerate(plan.sources):
                if isinstance(s,RateDamageSource):
                    stream=world.controlled_damage.streams[s.id]
                    for channel,amount in (('hp',hp[index]),('shield',shield[index])):
                        if not amount:continue
                        entry={'effect_id':s.id,'kind':s.family,'actor':stream.source.actor,
                            'ability':stream.source.ability,'action_id':stream.source.action_id,
                            **stream.source.life_record(),'channel':channel,'amount':amount,
                            'inputs':{'curve_kind':'fluid_controlled_v1' if channel=='hp' else 'fluid_controlled_shield_v1',
                                'stream_id':s.id,'base_damage_per_second':stream.base_dps,'armor':s.armor if channel=='hp' else D(0),
                                'pressure':s.pressure.record(),'formula':'max(0, overflow_dps-25*armor^2/(4*overflow_dps))'}}
                        if s.family=='electrocution':
                            entry['inputs'].update(electrocution_resistance=s.resistance if channel=='hp' else D(0),
                                formula=ELECTROCUTION_FORMULA)
                            if stream.source.projectile_id is not None:entry['projectile_id']=stream.source.projectile_id
                        entries.append(entry)
                    continue
                incident=self.incidents[s.id]
                for channel,amount in (('hp',hp[index]),('shield',shield[index])):
                    if not amount:continue
                    entries.append({'effect_id':self.body_ids.get(s.id) if channel=='hp' else s.id,'kind':'heat',
                        'actor':incident.source.actor,'ability':incident.source.ability,'action_id':incident.source.action_id,
                        **incident.source.life_record(),
                        'channel':channel,'amount':amount,'coefficient':s.coefficient if channel=='hp' else incident.parameters.output,
                        'inputs':{'curve_kind':'fluid_body_v1' if channel=='hp' else 'fluid_shield_delivery_v1',
                            'volume_id':incident.volume_id,'incident_id':s.id,'q_begin':first[1][index],'q_end':last[1][index],
                            'incident_q_begin':incident.q_at(begin),'incident_q_end':incident.q_at(end),
                            'heat_output':incident.parameters.output,'k':incident.parameters.decay,
                            'coefficient':s.coefficient if channel=='hp' else incident.parameters.output,
                            'armor':world.fighters[target].armor if channel=='hp' else D(0),
                            'heat_resistance':world.fighters[target].profile['resistances']['heat'] if channel=='hp' else D(0)}})
            result[target]=entries
        return result

    def commit(self,target,begin,end):
        cache=self.caches[target];plan=cache['thermal'];world=self.world
        amount=cache['cursor'].consume(end)
        stock,q,_,_=plan.at(end)
        for time in cache['formations']:
            if time==end:self._note_reformed(target,time)
        for source,value in zip(plan.sources,q):
            if isinstance(source,RateDamageSource):continue
            incident=self.incidents[source.id];effect=world.effect_system.effects.get(self.body_ids.get(source.id))
            if effect is not None and not effect.ended:
                effect.q_reference=value;effect.reference_ms=end
        world.log('continuous_damage_flow_advanced' if any(isinstance(s,RateDamageSource) for s in plan.sources)
            else 'thermal_flow_advanced',target=target,interval_start_ms=begin,interval_end_ms=end,
            regenerated=amount,shield_after=stock,body_q={s.id:v for s,v in zip(plan.sources,q)},
            numerical_epoch=plan.record())
        prefix={'begin_ms':begin,'end_ms':end,'total':amount,'boundary_tolerance_ms':D('1e-25'),
            'work_roundoff_tolerance_hp':D('1e-24'),
            'pieces':[{'begin_ms':max(begin,p.begin),'end_ms':min(end,p.end),'curve':p.shape.record()}
                for p in cache['recovery'].pieces if max(begin,p.begin)<min(end,p.end)]}
        return amount,stock,prefix

    def record_losses(self,target,begin,end,actual):
        cache=self.caches[target];pieces=cache['thermal'].loss_pieces(begin,end)
        amounts=[shape.integral(a,b) for a,b,shape in pieces];nominal=sum(amounts,D(0))
        if not nominal:return
        for (a,b,shape),amount in zip(pieces,amounts):
            if not amount:continue
            contributors=[({'stream_id':s.id,'actor':self.world.controlled_damage.streams[s.id].source.actor,
                'ability':self.world.controlled_damage.streams[s.id].source.ability,
                'action_id':self.world.controlled_damage.streams[s.id].source.action_id} if isinstance(s,RateDamageSource) else
                {'incident_id':s.id,'actor':self.incidents[s.id].source.actor,
                'ability':self.incidents[s.id].source.ability,'action_id':self.incidents[s.id].source.action_id})
                for s in cache['thermal'].sources if (s.exposed or s.shield_residual) and s.pressure.rate((a+b)/2)>0]
            curve=shape.record();curve['contributors']=contributors
            self.world._record_shield_loss(target,amount*actual/nominal,a,'thermal-pool:'+target,curve,end=b)

    def result(self):
        if not self.enabled:return {}
        return {'heat_shield_coupling_rules':self.world.combat_locomotion_input['heat_shield_coupling'],
            'heat_shield_coupling_numerics':{'stock':'analytic reflected balance','body':'adaptive Decimal Dormand-Prince 5(4), quartic dense prefixes',
                'absolute_error_control':D('1e-14'),'relative_error_control':D('1e-13'),
                'rate_boundary_tolerance_ms':D('1e-12'),'stock_boundary_tolerance_ms':D('1e-25'),
                'signed_rate_resolution_hp_per_second':D('1e-18'),
                'signed_clock_normalization_quantum_s':D('1e-28'),
                'dense_hp_boundary_bisection_ms':D('1e-25'),
                'recovery_work_roundoff_tolerance_hp':D('1e-24'),
                'maximum_conditional_epoch_ms':D(250),'global_error_bound':'not certified; verified convergence/partition controls'},
            'incident_heat_instances':[i.record(self.world.time) for i in self.incidents.values()],
            'fluid_thermal_recipients':sorted(self.active)}

    def pending(self):
        return [i.record(self.world.time) for i in self.incidents.values() if not i.ended]
