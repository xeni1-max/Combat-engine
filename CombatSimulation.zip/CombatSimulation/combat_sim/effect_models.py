"""Typed source identity, bleed instances, heat memory and independent volumes."""
from dataclasses import dataclass
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.continuous_numeric import root_affine_integral
from combat_sim.world_colliders import finite
from combat_sim.mechanics.life import life_generation, target_life_record


@dataclass(frozen=True)
class EffectSource:
    actor: str
    ability: str
    action_id: int
    projectile_id: str | None = None
    life_generation: int | None = None

    def __post_init__(self):
        if (not isinstance(self.actor,str) or not self.actor or not isinstance(self.ability,str) or not self.ability
                or type(self.action_id) is not int or self.action_id<=0):
            raise ValueError('Effect source needs actor, ability and parent action identity')
        if self.projectile_id is not None and (not isinstance(self.projectile_id,str) or not self.projectile_id):
            raise ValueError('Effect projectile identity must be a nonempty string')
        life_generation(self.life_generation)

    def life_record(self):
        return {'source_life_generation': self.life_generation} if self.life_generation is not None else {}


@dataclass(frozen=True)
class HeatParameters:
    output: D
    decay: D = D(2)

    def __post_init__(self):
        object.__setattr__(self,'output',finite(self.output,'Heat output',positive=True))
        object.__setattr__(self,'decay',finite(self.decay,'Heat decay',positive=True))
        if self.decay!=2:raise ValueError('Current heat implements k=2')


@dataclass
class BleedingEffect:
    id: str
    source: EffectSource
    target: str
    start: D
    basis_y: D
    revision: int = 0
    ended: bool = False
    ended_at_ms: D | None = None
    end_reason: str | None = None
    target_life_generation: int | None = None

    def __post_init__(self):
        self.start=finite(self.start,'Bleed start')
        self.basis_y=finite(self.basis_y,'Bleed basis')
        life_generation(self.target_life_generation)

    @property
    def expiry(self):return self.start+8000

    def record(self,time):
        return {'id':self.id,'kind':'bleeding','actor':self.source.actor,'ability':self.source.ability,
            'action_id':self.source.action_id,'projectile_id':self.source.projectile_id,'target':self.target,
            'start':self.start,'expiry':self.expiry,'basis_y':self.basis_y,'revision':self.revision,
            'status':'ended' if self.ended else 'active','ended_at_ms':self.ended_at_ms,'end_reason':self.end_reason,
            **self.source.life_record(), **target_life_record(self.target_life_generation)}


@dataclass
class HeatExposure:
    id: str
    source: EffectSource
    volume_id: str
    target: str
    target_kind: str
    channel: str
    parameters: HeatParameters
    created_at: D
    reference_ms: D
    q_reference: D = D(0)
    exposed: bool = True
    revision: int = 0
    ended: bool = False
    ended_at_ms: D | None = None
    end_reason: str | None = None
    evolution_model: str = 'affine_exposure_v1'
    target_life_generation: int | None = None

    def __post_init__(self):
        if self.target_kind not in ('actor','collider') or self.channel not in ('hp','shield'):
            raise ValueError('Heat needs a supported target and defense channel')
        if self.target_kind=='collider' and self.channel!='hp':raise ValueError('Constructs have no inferred shield')
        self.created_at=finite(self.created_at,'Heat start');self.reference_ms=finite(self.reference_ms,'Heat reference')
        if self.reference_ms<self.created_at:raise ValueError('Heat reference cannot precede creation')
        self.q_reference=finite(self.q_reference,'Heat memory')
        life_generation(self.target_life_generation)

    @property
    def slope(self):return D(1) if self.exposed else -self.parameters.decay

    @property
    def expiry(self):
        return None if self.exposed else self.reference_ms+self.q_reference/self.parameters.decay*1000

    def q_at(self,time):
        time=finite(time,'Heat observation time')
        if time<self.reference_ms:raise ValueError('Heat clock cannot be read before its current reference')
        return self.q_reference if self.ended else max(D(0),self.q_reference+self.slope*(time-self.reference_ms)/1000)

    def set_exposed(self,time,exposed):
        time=finite(time,'Exposure transition time')
        if time<self.reference_ms or type(exposed) is not bool:raise ValueError('Invalid exposure transition')
        if self.ended or self.exposed==exposed:return False
        self.q_reference=self.q_at(time);self.reference_ms=time;self.exposed=exposed;self.revision+=1
        return True

    def integral(self,coefficient,begin,end):
        if self.evolution_model!='affine_exposure_v1':raise ValueError('Fluid body heat uses its coordinator-owned dense trajectory')
        end=min(end,self.expiry) if self.expiry is not None else end
        begin=max(begin,self.reference_ms)
        return root_affine_integral(coefficient,self.q_reference,self.reference_ms,self.slope,begin,end) if end>begin else D(0)

    def record(self,time):
        return {'id':self.id,'kind':'heat','actor':self.source.actor,'ability':self.source.ability,
            'action_id':self.source.action_id,'volume_id':self.volume_id,'target':self.target,
            'target_kind':self.target_kind,'mode':self.channel,'start':self.created_at,
            'heat_output':self.parameters.output,'k':self.parameters.decay,'reference_ms':self.reference_ms,
            'q_reference':self.q_reference,'q_seconds':self.q_at(time),'exposed':self.exposed,
            'expiry':self.expiry,'revision':self.revision,'status':'ended' if self.ended else 'active',
            'ended_at_ms':self.ended_at_ms,'end_reason':self.end_reason,
            **self.source.life_record(), **target_life_record(self.target_life_generation),
            **({'evolution_model':self.evolution_model} if self.evolution_model!='affine_exposure_v1' else {})}


@dataclass
class HeatColumn:
    id: str
    source: EffectSource
    centre: tuple
    radius: D
    start: D
    expiry: D
    parameters: HeatParameters
    active: bool = True
    revision: int = 0

    def __post_init__(self):
        self.centre=tuple(map(dec,self.centre))
        if len(self.centre)!=3:raise ValueError('Heat column centre needs three finite coordinates')
        self.radius=finite(self.radius,'Heat radius',positive=True)
        self.start=finite(self.start,'Volume start');self.expiry=finite(self.expiry,'Volume expiry')
        if self.expiry<=self.start:raise ValueError('Volume lifetime must be positive')

    def record(self,members):
        return {'id':self.id,'kind':'heat_column','actor':self.source.actor,'ability':self.source.ability,
            'action_id':self.source.action_id,'centre_m':self.centre,'radius_m':self.radius,'start':self.start,
            'expiry':self.expiry,'active':self.active,'revision':self.revision,'heat_output':self.parameters.output,
            'k':self.parameters.decay,'eligible_targets':sorted(members), **self.source.life_record()}


@dataclass
class CooldownPauseArea:
    id: str
    source: EffectSource
    centre: tuple
    radius: D
    start: D
    expiry: D
    active: bool = True
    revision: int = 0

    def __post_init__(self):
        self.centre=tuple(map(dec,self.centre))
        if len(self.centre)!=3:raise ValueError('Pause area needs three centre coordinates')
        self.radius=finite(self.radius,'Pause area radius',positive=True)
        self.start=finite(self.start,'Pause area start');self.expiry=finite(self.expiry,'Pause area expiry')
        if self.expiry<=self.start:raise ValueError('Pause area lifetime must be positive')

    def record(self,members):
        return {'id':self.id,'kind':'cooldown_pause_area','actor':self.source.actor,'ability':self.source.ability,
            'action_id':self.source.action_id,'centre_m':self.centre,'radius_m':self.radius,'start':self.start,
            'expiry':self.expiry,'active':self.active,'revision':self.revision,'eligible_targets':sorted(members),
            **self.source.life_record()}


@dataclass
class AttachedVenom:
    id: str
    source: EffectSource
    target: str
    target_life_generation: int
    blade_id: str
    target_part: str
    local_fraction: tuple
    start: D
    duration_ms: D
    damage_after_shield: D
    armor_snapshot: D
    piercing: D
    toxicity: D
    delivery: D
    revision: int = 0
    attached: bool = True
    terminal_position_m: tuple | None = None
    ended: bool = False
    ended_at_ms: D | None = None
    end_reason: str | None = None

    def __post_init__(self):
        life_generation(self.target_life_generation)
        for key in ('start','damage_after_shield','armor_snapshot','piercing','delivery'):
            setattr(self,key,finite(getattr(self,key),key))
        self.duration_ms=finite(self.duration_ms,'Attachment duration',positive=True)
        self.toxicity=finite(self.toxicity,'Toxicity',positive=True)
        self.local_fraction=tuple(map(dec,self.local_fraction))
        if len(self.local_fraction)!=3 or any(abs(v)>D('.5') for v in self.local_fraction) or self.delivery>1:
            raise ValueError('Invalid attached blade position/delivery')

    @property
    def detach_ms(self):return self.start+self.duration_ms

    @property
    def expiry(self):return self.start+2*self.duration_ms

    def record(self,time):
        observed=min(time,self.ended_at_ms) if self.ended else time
        q=max(D(0),min(observed-self.start,self.expiry-observed,self.duration_ms)/1000)
        return {'id':self.id,'kind':'venom','actor':self.source.actor,'ability':self.source.ability,
            'action_id':self.source.action_id,'target':self.target,'blade_id':self.blade_id,
            **self.source.life_record(),**target_life_record(self.target_life_generation),
            'target_part':self.target_part,'local_fraction':self.local_fraction,'start':self.start,
            'detaches_at_ms':self.detach_ms,'expiry':self.expiry,'attached':self.attached and not self.ended,
            'q_seconds':q,'delivery':self.delivery,'damage_after_shield':self.damage_after_shield,
            'armor_snapshot':self.armor_snapshot,'piercing':self.piercing,'toxicity':self.toxicity,
            'revision':self.revision,'status':'ended' if self.ended else 'active',
            'ended_at_ms':self.ended_at_ms,'end_reason':self.end_reason}
