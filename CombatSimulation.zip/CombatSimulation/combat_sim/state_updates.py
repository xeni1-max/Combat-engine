"""Shared shield regeneration and state-log utilities for scoped runners."""

from fractions import Fraction
from typing import Any

from combat_sim.events import EventLog
from combat_sim.mechanics.shield import shared_regenerable_amount
from combat_sim.models import CharacterState, UnsupportedMechanicError, as_fraction, fraction_record


def _state_snapshot(states: dict[str, CharacterState]) -> dict[str, Any]:
    return {name: state.to_record() for name, state in sorted(states.items())}


def _validate_shield_state(state: CharacterState, capacity: Fraction, name: str) -> None:
    if state.shield < 0 or state.shield > capacity:
        raise ValueError(f"{name} shield must be between 0 and its capacity ({capacity})")


def _advance_regeneration(
    states: dict[str, CharacterState],
    character_data: dict[str, Any],
    pending: list[dict[str, Any]],
    start_ms: int,
    end_ms: int,
    event_log: EventLog,
) -> None:
    if end_ms <= start_ms:
        return

    start_time = Fraction(start_ms)
    end_time = Fraction(end_ms)
    for target_name in sorted({cohort["target"] for cohort in pending}):
        target_cohorts = [cohort for cohort in pending if cohort["target"] == target_name]
        breakpoints = {start_time, end_time}
        breakpoints.update(
            Fraction(cohort["eligible_at_ms"])
            for cohort in target_cohorts
            if start_time < cohort["eligible_at_ms"] < end_time
        )
        points = sorted(breakpoints)
        target_character = character_data[target_name]
        regeneration = target_character.get("shield_regeneration")
        if regeneration is None:
            raise UnsupportedMechanicError(f"{target_name} has no documented shield regeneration data")
        rate = as_fraction(regeneration["rate_per_second"])

        for interval_start, interval_available_until in zip(points, points[1:]):
            if interval_available_until <= interval_start:
                continue
            active = sorted(
                (
                    cohort
                    for cohort in target_cohorts
                    if cohort["remaining"] > 0
                    and Fraction(cohort["eligible_at_ms"]) <= interval_start
                ),
                key=lambda cohort: (cohort["eligible_at_ms"], cohort["loss_instance"]),
            )
            if not active:
                continue

            elapsed_available_ms = interval_available_until - interval_start
            amount = shared_regenerable_amount(
                (cohort["remaining"] for cohort in active), rate, elapsed_available_ms
            )
            state = states[target_name]
            capacity = as_fraction(target_character["shield_capacity"])
            amount = min(amount, max(Fraction(0), capacity - state.shield))
            if amount <= 0:
                continue

            remaining_to_allocate = amount
            allocations: list[dict[str, Any]] = []
            for cohort in active:
                allocated = min(cohort["remaining"], remaining_to_allocate)
                if allocated <= 0:
                    continue
                cohort["remaining"] -= allocated
                remaining_to_allocate -= allocated
                allocations.append(
                    {
                        "loss_instance": cohort["loss_instance"],
                        "loss_at_ms": cohort["loss_at_ms"],
                        "eligible_from_ms": cohort["eligible_at_ms"],
                        "amount": fraction_record(allocated),
                    }
                )
                if remaining_to_allocate == 0:
                    break

            interval_duration_ms = amount * 1000 / rate
            interval_end = interval_start + interval_duration_ms
            shield_before = state.shield
            state.shield += amount
            event_log.record(
                {
                    "time_ms": _time_value(interval_end),
                    "type": "shield_regenerated",
                    "target": target_name,
                    "eligible_loss_allocations": allocations,
                    "regeneration_interval": {
                        "interval_start_ms": _time_value(interval_start),
                        "interval_end_ms": _time_value(interval_end),
                        "elapsed_available_ms": _time_value(elapsed_available_ms),
                        "regenerated_duration_ms": _time_value(interval_duration_ms),
                    },
                    "amount_regenerated": fraction_record(amount),
                    "shared_rate_per_second": str(rate),
                    "allocation_order": "oldest eligible loss first",
                    "shield_before": fraction_record(shield_before),
                    "shield_after": fraction_record(state.shield),
                    "source": regeneration["source"],
                }
            )
    pending[:] = [cohort for cohort in pending if cohort["remaining"] > 0]


def _time_value(value: Fraction | int) -> int | dict[str, str]:
    exact = as_fraction(value)
    if exact.denominator == 1:
        return exact.numerator
    return fraction_record(exact)


