"""Immutable source-life and causal identity for committed combat signals."""
from dataclasses import dataclass
from decimal import Decimal as D

from combat_sim.mechanics.life import life_generation
from combat_sim.world_colliders import finite


@dataclass(frozen=True)
class BlockSignal:
    id: str
    actor: str
    source_life_generation: int
    time_ms: D
    absorbed: D
    layer_ids: tuple[str,...]
    incoming_ids: tuple[str,...]
    parent_depth: int = 0

    def __post_init__(self):
        if life_generation(self.source_life_generation) is None:
            raise ValueError('A Block signal requires its source life')
        if (any(not isinstance(s,str) or not s for s in (self.id,self.actor)) or
                type(self.parent_depth) is not int or self.parent_depth<0):
            raise ValueError('A Block signal needs actor/source/causal identity')
        for name in ('layer_ids','incoming_ids'):
            values=tuple(getattr(self,name))
            if not values or len(set(values))!=len(values) or any(not isinstance(x,str) or not x for x in values):
                raise ValueError('A Block signal needs unique causal references')
            object.__setattr__(self,name,values)
        object.__setattr__(self,'time_ms',finite(self.time_ms,'Signal time'))
        object.__setattr__(self,'absorbed',finite(self.absorbed,'Blocked damage',positive=True))

    def record(self):
        return {'id':self.id,'kind':'block_absorbed','actor':self.actor,
            'source_life_generation':self.source_life_generation,'time_ms':self.time_ms,
            'absorbed':self.absorbed,'layer_ids':list(self.layer_ids),
            'incoming_ids':list(self.incoming_ids),'parent_depth':self.parent_depth}
