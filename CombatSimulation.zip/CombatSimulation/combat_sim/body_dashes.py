"""Existing dash abilities through owned actions and shared ballistic bodies."""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.body_launch import dash_launch
from combat_sim.models import UnsupportedMechanicError


class BodyDashes:
    def __init__(self, world):
        self.world = world
        self.launches = []

    def validate(self, actor, ability_id):
        w = self.world
        a = actor.profile['abilities'][ability_id]
        cfg = (w.combat_locomotion_input or {}).get('action_ownership', {}).get('actions', {}).get('ballistic_dash')
        if not (w.mobile_mode and w.airborne_enabled and w.life_cycles.enabled and w.effort_system.enabled):
            raise UnsupportedMechanicError('Body dash needs the shared living airborne and phase-effort world')
        if cfg != {'occupies':['locomotion'], 'requires':['lower_body']}:
            raise UnsupportedMechanicError('Body dash needs a lower-body owner independent of hands and weapons')
        if (a.get('direction') not in ('away_from_target','toward_target') or
                a.get('launch_timing') != 'active_start' or a.get('cooldown_anchor') != 'active_start' or
                a.get('trajectory') != 'same_height_ballistic_range' or
                a.get('dyspnea', {}).get('payment_timing') != 'active_start' or
                a.get('hand_positions_m') != {'start':{}, 'end':{}}):
            raise UnsupportedMechanicError('Unsupported dash trajectory, direction, effort or hand rules')
        if any(dec(a[k]) <= 0 for k in ('distance_m','cooldown_ms')):
            raise ValueError('Dash range and cooldown must be positive')
        for phase in ('takeoff','landing'):
            if set(a.get(phase+'_self_effects', {})) != {'disorientation','instability'} or any(
                    dec(v) < 0 for v in a[phase+'_self_effects'].values()):
                raise ValueError('Dash needs nonnegative takeoff and landing effects')

    def available(self, actor):
        w = self.world
        return (not w._airborne(actor.id) and not w._climbing(actor.id) and
            w.collider_system.find_support(actor) is not None)

    def start(self, actor):
        w = self.world
        action = actor.current
        a = actor.profile['abilities'][action.ability_id]
        if not self.available(actor):
            w.cancel_owned_action(actor, action, 'dash_requires_support')
            return
        if not w.pay_team_dyspnea(actor, 'active_start'):
            return
        target = action.aim_location_m
        direction = tuple(dec(p)-dec(q) for p,q in zip(target[:2], actor.position_m))
        if not any(direction):
            from combat_sim.facing import forward
            direction=tuple(map(dec,forward(actor.facing)[:2]))
        if a['direction'] == 'away_from_target':
            direction = tuple(-v for v in direction)
        launch = dash_launch(a['distance_m'], w.movement_definition['characters'][actor.profile_id]['running_speed_mps'],
            w.jump_gravity, direction, precision=w.precision)
        m = w.motion[actor.id]
        running = w.mobile_is_running(actor.id)
        factor = dec(w.combat_locomotion_definition['running_self_effect_multiplier']) if running else D(1)
        # Dash replaces the horizontal drive during flight. Resume the prior
        # ground pace on landing; sprint ends at launch instead of filling D
        # for a motor action that the dash has replaced.
        if w.mobile_sprint_effort(actor.id):
            m.update(mode='running', speed=dec(w.movement_definition['characters'][actor.profile_id]['running_speed_mps']),
                sprint_anchor=None)
        drive = tuple(v*m['speed'] for v in m['direction'])+(D(0),)
        m.pop('imposed_velocity', None)
        action.phase = 'active'
        action.active_end_ms = w.time+action.active_ms
        effects = {k:dec(v)*factor for k,v in a['takeoff_self_effects'].items()}
        for key,value in effects.items():setattr(actor,key,getattr(actor,key)+value)
        # Immutable, life-bound landing obligation survives the end/cancellation
        # of launch control and later external motion, but never death/revival.
        landing = (actor.life_generation, action.ability_id, action.id,
            dec(a['landing_self_effects']['disorientation']), dec(a['landing_self_effects']['instability']))
        w.launch_body(actor, launch.velocity_mps, ground_drive_velocity=drive, landing_effects=landing,
            motion_cause=('dash',actor.life_generation,action.id))
        w.cooldown_system.start(actor, action.ability_id, dec(a['cooldown_ms']), action.id)
        w.extend_parallel_gatherings(actor,effects['disorientation'],action.id)
        w.refresh_mobile_locomotion()
        record = {'actor':actor.id, 'ability':action.ability_id, 'action_id':action.id,
            'life_generation':actor.life_generation, 'launched_at_ms':w.time,
            'reference_m':w.spatial_transitions.reference(actor.id),
            'target_location_m':target, 'free_velocity_mps':launch.velocity_mps,
            'shared_velocity_mps':w.mobile_motion(actor.id)[0],
            'nominal_range_m':launch.nominal_range_m, 'nominal_same_height_duration_ms':launch.same_height_duration_ms,
            'active_end_ms':action.active_end_ms, 'self_effects':effects}
        self.launches.append(record)
        w.log('body_dash_launched', **deepcopy(record))
        w._schedule_phase(action,'active_completed',action.active_end_ms)

    def complete(self, actor):
        w = self.world
        action = actor.current
        actor.current = None
        w.log('body_dash_active_completed',actor=actor.id,ability=action.ability_id,action_id=action.id,
            airborne=w._airborne(actor.id))
        w.request_decision(actor.id,w.time)

    def result(self):
        return {'body_dash_launches':deepcopy(self.launches)} if self.launches else {}
