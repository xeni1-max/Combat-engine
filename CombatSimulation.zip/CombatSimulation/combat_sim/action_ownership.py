"""Action-instance ownership, selective restrictions and deferred cost capacity.

Required functions describe eligibility, not exclusive locks. Occupied resources
describe conflicts. The registry contains controlled actions only: released
projectiles, independent effects and physical flight have separate lifetimes.
"""
from contextlib import contextmanager
from dataclasses import dataclass, replace
from decimal import Decimal as D

from combat_sim.mechanics.dyspnea import apply_action_dyspnea
from combat_sim.battle_models import decimal_value as dec


@dataclass(frozen=True)
class ActionRequirements:
    occupies: frozenset[str]
    requires: frozenset[str]
    base_cost: D | None = None
    payment_phase: str | None = None

    def __post_init__(self):
        if isinstance(self.occupies,str) or isinstance(self.requires,str):
            raise ValueError('Resources and functions must be collections of names')
        if self.base_cost is not None:
            if isinstance(self.base_cost,bool):
                raise ValueError('An action cost must be numeric')
            object.__setattr__(self,'base_cost',dec(self.base_cost))
        object.__setattr__(self,'occupies',frozenset(self.occupies))
        object.__setattr__(self,'requires',frozenset(self.requires))
        if (not self.occupies or any(not isinstance(v,str) or not v for v in self.occupies|self.requires)
                or self.base_cost is not None and (not self.base_cost.is_finite() or self.base_cost<0)):
            raise ValueError('Action requirements need named resources/functions and a nonnegative finite cost')
        if (self.base_cost is None)!=(self.payment_phase is None) or self.payment_phase is not None and (not isinstance(self.payment_phase,str) or not self.payment_phase):
            raise ValueError('An action cost needs its authoritative payment phase')


class ActionConflict(RuntimeError):
    pass


@dataclass(frozen=True)
class ActionTransfer:
    owner: object
    dependency: tuple
    actions: tuple
    requirements: tuple
    reservations: tuple
    paid_phases: tuple
    new_action_states: tuple


class ActionRegistry:
    def __init__(self,requirements_for,dyspnea_value):
        self.requirements_for=requirements_for
        self.dyspnea_value=dyspnea_value
        self.actions={}
        self.requirements={}
        self.reservations={}
        self.paid_phases={}
        self.blocks={}
        self._selected=[]
        self._transfer_owner=object()

    def all(self):
        return tuple(self.actions[k] for k in sorted(self.actions))

    def selected_or_single(self):
        if self._selected:
            return self.actions.get(self._selected[-1])
        if len(self.actions)>1:
            raise ActionConflict('Multiple actions require an explicit action identity/context')
        return next(iter(self.actions.values()),None)

    @contextmanager
    def select(self,action_id):
        self._selected.append(action_id)
        try:yield self.actions.get(action_id)
        finally:self._selected.pop()

    def owner(self,resource):
        return next((self.actions[k] for k,r in self.requirements.items() if resource in r.occupies),None)

    def unavailable(self,requirements):
        resources=set().union(*(r.occupies for r in self.requirements.values())) if self.requirements else set()
        functions=set().union(*self.blocks.values()) if self.blocks else set()
        return requirements.occupies&resources,(requirements.requires|requirements.occupies)&functions

    def reserved(self,excluding=None):
        return sum((value for key,value in self.reservations.items() if key!=excluding),D(0))

    def affordable(self,base,current=None,excluding=None):
        current=dec(self.dyspnea_value() if current is None else current)
        payment=apply_action_dyspnea(current,base)
        return payment.allowed and dec(payment.after)+self.reserved(excluding)<=100

    def acquire(self,action):
        if action.id in self.actions:raise ActionConflict('Action identity already owns resources')
        return self._acquire(action,self.requirements_for(action))

    def _acquire(self,action,requirements,paid=()):
        if action.id in self.actions:
            raise ActionConflict('Action identity already owns resources')
        occupied,blocked=self.unavailable(requirements)
        if occupied or blocked:
            raise ActionConflict('Action conflicts with occupied resources or blocked functions')
        reservation=D(0)
        if requirements.base_cost is not None and requirements.payment_phase not in paid:
            if not self.affordable(requirements.base_cost):
                raise ActionConflict('Insufficient unreserved dyspnea capacity')
            remaining=100-dec(self.dyspnea_value())-self.reserved()
            # Cost is bounded by (Db+1)^2 while D<=100. Reserving the
            # remaining capacity when that bound is larger prevents another
            # action from raising D before this payment. No cost is paid here.
            reservation=min((requirements.base_cost+1)**2,remaining)
        self.actions[action.id]=action
        self.requirements[action.id]=requirements
        self.reservations[action.id]=reservation
        self.paid_phases[action.id]=set(paid)

    @staticmethod
    def _action_state(action):
        def freeze(value):
            if isinstance(value,dict):return tuple((key,freeze(v)) for key,v in sorted(value.items()))
            if isinstance(value,(list,tuple)):return tuple(map(freeze,value))
            if isinstance(value,(set,frozenset)):return frozenset(map(freeze,value))
            return value
        return tuple((key,freeze(value)) for key,value in sorted(vars(action).items()))

    def _transfer_dependency(self):
        return (dec(self.dyspnea_value()),tuple((key,self._action_state(action),self.requirements[key],
            self.reservations[key],frozenset(self.paid_phases[key])) for key,action in sorted(self.actions.items())),
            tuple(sorted(self.blocks.items())))

    def prepare_transfer(self,updates,acquisitions=()):
        """Validate all resource handoffs/new owners before changing the registry."""
        if not isinstance(updates,dict) or any(key not in self.actions for key in updates):
            raise ActionConflict('A phase transfer must update current action owners')
        acquisitions=tuple(acquisitions)
        if any(not isinstance(r,ActionRequirements) for r in updates.values()):
            raise ValueError('Phase transfers need explicit requirements')
        for action,requirements in acquisitions:
            if not isinstance(requirements,ActionRequirements):raise ValueError('Acquisitions need explicit requirements')
        new_ids=[a.id for a,_ in acquisitions]
        if len(set(new_ids))!=len(new_ids) or set(new_ids)&set(self.actions):raise ActionConflict('New ownership requires unique action identities')
        shadow=ActionRegistry(self.requirements_for,self.dyspnea_value)
        shadow.actions=dict(self.actions);shadow.requirements=dict(self.requirements);shadow.reservations=dict(self.reservations)
        shadow.paid_phases={key:set(value) for key,value in self.paid_phases.items()};shadow.blocks=dict(self.blocks)
        pending=[]
        for identity,requirements in updates.items():
            action=self.actions[identity];old=self.requirements[identity];paid=self.paid_phases[identity]
            if (old.base_cost is not None and old.payment_phase not in paid
                    and (old.base_cost,old.payment_phase)!=(requirements.base_cost,requirements.payment_phase)):
                raise ActionConflict('Cannot transfer away an unpaid action cost')
            shadow.release(identity);pending.append((action,requirements,paid))
        pending.extend((action,requirements,()) for action,requirements in acquisitions)
        for action,requirements,paid in sorted(pending,key=lambda row:row[0].id):shadow._acquire(action,requirements,paid)
        return ActionTransfer(self._transfer_owner,self._transfer_dependency(),tuple(sorted(shadow.actions.items())),
            tuple(sorted(shadow.requirements.items())),tuple(sorted(shadow.reservations.items())),
            tuple((key,frozenset(value)) for key,value in sorted(shadow.paid_phases.items())),
            tuple((action,self._action_state(action)) for action,_ in acquisitions))

    def commit_transfer(self,plan):
        if not isinstance(plan,ActionTransfer) or plan.owner is not self._transfer_owner:
            raise ActionConflict('Phase transfer belongs to another action registry')
        if (plan.dependency!=self._transfer_dependency() or
                any(self._action_state(action)!=state for action,state in plan.new_action_states)):
            raise ActionConflict('Phase transfer became stale before commit')
        self.actions=dict(plan.actions);self.requirements=dict(plan.requirements);self.reservations=dict(plan.reservations)
        self.paid_phases={key:set(value) for key,value in plan.paid_phases}

    def transfer(self,updates,acquisitions=()):
        self.commit_transfer(self.prepare_transfer(updates,acquisitions))

    def payment(self,action_id,base,phase):
        if action_id not in self.actions:
            raise ActionConflict('Payment requires a live owned action')
        if phase in self.paid_phases[action_id]:
            raise ActionConflict('Action phase already paid')
        requirements=self.requirements[action_id]
        if requirements.base_cost!=dec(base) or requirements.payment_phase!=phase:
            raise ActionConflict('Payment does not match the owned action rule')
        payment=apply_action_dyspnea(self.dyspnea_value(),base)
        if payment.allowed and dec(payment.after)+self.reserved(action_id)<=100:
            self.paid_phases[action_id].add(phase)
            self.reservations[action_id]=D(0)
        else:
            # Continuous exertion can invalidate an unpaid body action before
            # its payment phase. Authoritative phase checks then defer/cancel
            # it; no receipt is issued and no resource is debited here.
            return replace(payment,allowed=False,after=payment.before,
                reached_maximum=False,disorientation_trigger=0)
        return payment

    def release(self,action_id):
        action=self.actions.pop(action_id,None)
        self.requirements.pop(action_id,None)
        self.reservations.pop(action_id,None)
        self.paid_phases.pop(action_id,None)
        return action

    def release_selected(self):
        action=self.selected_or_single()
        return self.release(action.id) if action is not None else None

    def add_block(self,source,functions):
        if not isinstance(source,str) or not source or not functions or any(not isinstance(v,str) or not v for v in functions):
            raise ValueError('A restriction needs a source identity and named functions')
        self.blocks[source]=frozenset(functions)
        return tuple(action for action in self.all() if (
            self.requirements[action.id].requires|self.requirements[action.id].occupies)&self.blocks[source])

    def remove_block(self,source):
        return self.blocks.pop(source,None)

    def record(self):
        return [{'action':a.record(),'occupies':sorted(self.requirements[a.id].occupies),
            'requires':sorted(self.requirements[a.id].requires),
            'reserved_dyspnea_capacity':str(self.reservations[a.id]),
            'paid_phases':sorted(self.paid_phases[a.id])} for a in self.all()]
