"""Small, per-run summaries for the first simulation slice."""

from fractions import Fraction
from typing import Any

from combat_sim.models import fraction_record
from combat_sim.exact import ExactAmount, amount_from_record, number_record


def summarize(run: dict[str, Any]) -> dict[str, Any]:
    """Summarize impact events and the final target state."""
    if run.get("execution_model") == "shared_encounter":
        from combat_sim.battle_analysis import summarize_shared
        return summarize_shared(run)
    impacts = [event for event in run["events"] if event["type"] == "impact_resolved"]
    continuous = [event for event in run["events"] if event["type"] == "continuous_damage_resolved"]
    if not impacts and (continuous or run.get("execution_model") in {"heat_beam", "poison_grenade"}):
        return _summarize_continuous_only(run, continuous)
    event = impacts[0]
    target_state = run["final_states"][event["target"]]

    def total(path: tuple[str, ...]) -> dict[str, str]:
        amount = sum(
            (
                Fraction(_nested(item["damage_calculation"], path)["exact"])
                for item in impacts
            ),
            Fraction(0),
        )
        return fraction_record(amount)

    regenerated = sum(
        (
            Fraction(item["amount_regenerated"]["exact"])
            for item in run["events"]
            if item["type"] == "shield_regenerated"
        ),
        Fraction(0),
    )
    def state_loss(attribute: str) -> Fraction:
        return sum(
            (
                Fraction(item["state_changes"][f"{attribute}_before"]["exact"])
                - Fraction(item["state_changes"][f"{attribute}_after_impact"]["exact"])
                for item in impacts + continuous
            ),
            Fraction(0),
        )

    actual_hp_lost = state_loss("hp")
    actual_armor_lost = state_loss("armor")
    nominal_hp = total(("outputs", "y"))
    if continuous:
        nominal_hp = fraction_record(Fraction(nominal_hp["exact"]) + sum(
            (Fraction(item["nominal_hp_damage"]["exact"]) for item in continuous), Fraction(0),
        ))
    nominal_armor = total(("outputs", "Ar"))
    result = {
        "scenario_id": run["scenario_id"],
        "impact_count": len(impacts),
        "target": event["target"],
        "raw_damage": total(("incoming_damage",)),
        "shield_damage": total(("shield_handling", "damage_to_shield")),
        "damage_left_after_shield": total(("shield_handling", "damage_left_after_shield")),
        "hp_damage": fraction_record(actual_hp_lost),
        "armor_lost": fraction_record(actual_armor_lost),
        "nominal_hp_damage": nominal_hp,
        "nominal_armor_loss": nominal_armor,
        "excess_hp_damage": fraction_record(Fraction(nominal_hp["exact"]) - actual_hp_lost),
        "excess_armor_loss": fraction_record(Fraction(nominal_armor["exact"]) - actual_armor_lost),
        "shield_regenerated_total": fraction_record(regenerated),
        "final_hp": target_state["hp"],
        "final_armor": target_state["armor"],
        "final_shield": target_state["shield"],
        "run_until_ms": run["run_until_ms"],
    }
    if continuous or run.get("execution_model") == "slash_projectile":
        result["direct_hp_damage"] = fraction_record(sum(
            (Fraction(item["damage_calculation"]["applied_state_losses"]["hp"]["exact"]) for item in impacts), Fraction(0),
        ))
        result["continuous_hp_damage"] = fraction_record(sum(
            (Fraction(item["applied_hp_damage"]["exact"]) for item in continuous), Fraction(0),
        ))
        result["damage_by_effect"] = {
            effect: fraction_record(sum(
                (Fraction(item["components"][effect]["amount"]["exact"]) for item in continuous if effect in item["components"]), Fraction(0),
            )) for effect in sorted({key for item in continuous for key in item["components"]} | ({"bleeding"} if run.get("execution_model") == "slash_projectile" else set()))
        }
        result["raw_damage_scope"] = "Direct impacts only; continuous components are integrated post-mitigation damage"
    targets = sorted({item["target"] for item in impacts})
    if len(targets) > 1:
        for key in ("target", "final_hp", "final_armor", "final_shield"):
            result.pop(key)
        result["targets"] = targets
        result["per_target"] = {}
        for name in targets:
            selected = dict(run)
            selected["events"] = [item for item in run["events"] if item.get("target") == name]
            result["per_target"][name] = summarize(selected)
    else:
        for name in ("disorientation", "instability"):
            if name in target_state:
                result[f"final_{name}"] = target_state[name]
    return result


def _nested(values: dict[str, Any], path: tuple[str, ...]) -> dict[str, str]:
    for key in path:
        values = values[key]
    return values


def _summarize_continuous_only(run, events):
    """Summarize exact rational/radical continuous effects without a fake hit."""
    actual = sum((amount_from_record(e["applied_hp_damage"]) for e in events), ExactAmount())
    nominal = sum((amount_from_record(e["nominal_hp_damage"]) for e in events), ExactAmount())
    armor = sum((Fraction(e["state_changes"]["armor_before"]["exact"]) - Fraction(e["state_changes"]["armor_after_impact"]["exact"]) for e in events), Fraction(0))
    effects = sorted({effect for e in events for effect in e["components"]} | ({"poison"} if run.get("execution_model") == "poison_grenade" else set()))
    result = {
        "scenario_id": run["scenario_id"], "impact_count": 0, "damage_interval_count": len(events),
        "hp_damage": number_record(actual), "direct_hp_damage": fraction_record(Fraction(0)),
        "continuous_hp_damage": number_record(actual), "nominal_hp_damage": number_record(nominal),
        "excess_hp_damage": number_record(nominal - actual), "armor_lost": fraction_record(armor),
        "shield_damage": fraction_record(Fraction(0)), "shield_regenerated_total": fraction_record(Fraction(0)),
        "damage_by_effect": {effect: number_record(sum(
            (amount_from_record(e["components"][effect]["amount"]) for e in events if effect in e["components"]), ExactAmount(),
        )) for effect in effects},
        "run_until_ms": run["run_until_ms"],
    }
    targets = sorted({e["target"] for e in events} | set(run.get("continuous_targets", [])))
    if len(targets) == 1:
        name = targets[0]
        result["target"] = name
        for attribute in ("hp", "armor", "shield", "disorientation", "instability"):
            if attribute in run["final_states"][name]:
                result[f"final_{attribute}"] = run["final_states"][name][attribute]
    else:
        result["targets"] = targets
        result["per_target"] = {}
        for name in targets:
            selected = dict(run)
            selected["events"] = [e for e in run["events"] if e.get("target") == name]
            if "continuous_targets" in selected:
                selected["continuous_targets"] = [name]
            result["per_target"][name] = _summarize_continuous_only(selected, [e for e in events if e["target"] == name])
    return result
