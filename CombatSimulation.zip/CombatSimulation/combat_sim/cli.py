"""Command-line entry point for a reproducible scenario run."""

import argparse
import json
from pathlib import Path
from typing import Any

from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _load_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def main() -> None:
    parser = argparse.ArgumentParser(prog="combat-sim")
    subparsers = parser.add_subparsers(dest="command", required=True)
    run_parser = subparsers.add_parser("run", help="run a supported reproducible combat scenario")
    run_parser.add_argument(
        "scenario",
        nargs="?",
        default=str(PROJECT_ROOT / "scenarios" / "one_blunt_impact.json"),
        help="scenario JSON (defaults to the included one-impact scenario)",
    )
    run_parser.add_argument("--characters", default=str(PROJECT_ROOT / "data" / "characters.json"))
    run_parser.add_argument("--body-hitboxes",default=str(PROJECT_ROOT / "data" / "body_hitboxes.json"))
    run_parser.add_argument("--terrain",default=str(PROJECT_ROOT / "data" / "terrain" / "stationary_arena.json"))
    run_parser.add_argument("--movement",default=str(PROJECT_ROOT / "data/movement/walk_run.json"))
    run_parser.add_argument("--jump",default=str(PROJECT_ROOT / "data/movement/jump.json"))
    run_parser.add_argument("--combat-jump",default=str(PROJECT_ROOT / "data/movement/combat_jump.json"))
    run_parser.add_argument("--climb",default=str(PROJECT_ROOT / "data/movement/climb.json"))
    run_parser.add_argument("--combat-climb",default=str(PROJECT_ROOT / "data/movement/combat_climb.json"))
    run_parser.add_argument("--get-up",default=str(PROJECT_ROOT / "data/movement/get_up.json"))
    run_parser.add_argument("--combat-locomotion",default=str(PROJECT_ROOT / "data/movement/combat_locomotion.json"))
    run_parser.add_argument("--projectile-physics",default=str(PROJECT_ROOT / "data/physics/projectile_gravity.json"))
    run_parser.add_argument("--historical-airborne",action="store_true",
        help="select body flight explicitly with historical locomotion inputs lacking a world ruleset")
    run_parser.add_argument("--summary-only", action="store_true")
    args = parser.parse_args()

    scenario = _load_json(Path(args.scenario))
    characters = _load_json(Path(args.characters))["characters"]
    body = (_load_json(Path(args.body_hitboxes))
            if scenario.get('scope',{}).get('hit_eligibility') in ('swept_sphere_bodies','moving_sphere_bodies') else None)
    terrain = (_load_json(Path(args.terrain))
               if scenario.get('scope',{}).get('ground_collision') == 'finite_static_terrain' else None)
    movement = (_load_json(Path(args.movement))
                if scenario.get('scope',{}).get('movement') in ('scripted_straight_line','grounded_combat') else None)
    mobile = scenario.get('scope',{}).get('movement') == 'grounded_combat'
    combat_locomotion = _load_json(Path(args.combat_locomotion)) if mobile else None
    current_world = mobile and combat_locomotion.get('world',{}).get('ruleset')=='integrated_v2'
    jump = (_load_json(Path(args.jump)) if movement is not None and not mobile else None)
    if mobile and (current_world or args.historical_airborne):
        jump = _load_json(Path(args.combat_jump))
    climb = (_load_json(Path(args.combat_climb if mobile else args.climb)) if movement is not None and
             (current_world or (not mobile and any(item.get('action')=='climb' for item in scenario.get('movement_script',[])))) else None)
    get_up = (_load_json(Path(args.get_up)) if 'get_up' in scenario.get('common_abilities', []) else None)
    physics = (_load_json(Path(args.projectile_physics))
               if scenario.get('scope',{}).get('projectile_motion') == 'gravity_directional_deceleration' else None)
    result = run_scenario(scenario, characters,body_definition=body,terrain_definition=terrain,
                          movement_definition=movement,jump_definition=jump,climb_definition=climb,
                          get_up_definition=get_up,combat_locomotion_definition=combat_locomotion,projectile_physics_definition=physics)
    result["summary"] = summarize(result)
    if args.summary_only:
        result = {"scenario_id": result["scenario_id"], "summary": result["summary"]}
    print(json.dumps(result, indent=2, sort_keys=True))
