"""One released projectile contact becomes one instantaneous area damage wave.

The carrier has no additional direct hit. Body/material recipients and their
defenses are selected before that simultaneous wave mutates the world. Timed
effects are delivered after its HP/healing/death closure.
"""
from copy import deepcopy
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import UnsupportedMechanicError
from combat_sim.projectile_entities import ProjectileContactPolicy
from combat_sim.world_colliders import finite, OBJECT_DAMAGE_TYPES

EVENT = 'impact_area_effect_hit'


class ImpactAreas:
    def __init__(self, world, definition=None):
        self.world = world
        self.enabled = definition is not None
        self.ids = count(1)
        self.bursts, self.by_projectile, self.hits = {}, {}, {}
        if self.enabled and (definition != {'mode': 'released_impact_v1'} or not world.mobile_mode):
            raise UnsupportedMechanicError('Impact areas require current moving combat rules')

    def validate(self, actor, ability_id):
        w = self.world
        if not (self.enabled and w.gravity_mode and w.effort_system.enabled and
                w.timed_gathering.enabled and w.life_cycles.enabled and w.collider_system.instant_areas):
            raise UnsupportedMechanicError('Impact areas need gravity, released power, timed Gathering and shared area receivers')
        ability = actor.profile['abilities'][ability_id]
        cfg = ability.get('impact_area')
        if (not isinstance(cfg, dict) or set(cfg) != {'shape', 'radius_m', 'occlusion', 'gathering_modifier'}
                or cfg['shape'] != 'sphere' or cfg['occlusion'] != 'world'):
            raise UnsupportedMechanicError('Impact areas require spherical damage with current cover policy')
        finite(cfg['radius_m'], 'Impact area radius', positive=True)
        modifier = cfg['gathering_modifier']
        if not isinstance(modifier, dict) or set(modifier) != {'addition_ms', 'duration_ms'}:
            raise UnsupportedMechanicError('Impact area needs an explicit timed Gathering modifier')
        for key, value in modifier.items():
            finite(value, key, positive=True)
        finite(ability['pre_mitigation_damage'], 'Impact area damage')
        if ability.get('damage_type') not in OBJECT_DAMAGE_TYPES or ability.get('damage_type') == 'heat':
            raise UnsupportedMechanicError('Impact area requires an instantaneous shared damage family')
        if ProjectileContactPolicy.from_definition(ability['projectile_geometry'].get('contact_policy')) != ProjectileContactPolicy():
            raise UnsupportedMechanicError('Impact areas detonate on their first physical collision')
        timing = actor.profile['timing_profiles'][ability['timing_profile']]
        if dec(timing.get('projectile_acceleration_mps2', 0)) != 0:
            raise UnsupportedMechanicError('Current impact areas use ballistic gravity flight')

    def expand(self, packet):
        w = self.world
        projectile = packet['projectile_id']
        if projectile in self.by_projectile:
            return [], []
        payload = deepcopy(w.projectile_flights[projectile]['contact_payload'])
        cfg = payload['impact_area']
        identity = 'impact-area:' + str(next(self.ids))
        names = sorted(w.body_area_recipients(packet['location_m'], cfg['radius_m'], cfg['shape']))
        colliders = w.collider_system.area_recipients(packet['location_m'], cfg['radius_m'], cfg['shape'])
        row = {k: deepcopy(packet[k]) for k in ('actor', 'ability', 'action_id', 'source_life_generation', 'projectile_id')}
        row.update(id=identity, at_ms=w.time, location_m=deepcopy(packet['location_m']),
            definition=cfg, damage_type=payload['damage_type'], target_effects=payload['target_effects'],
            origin_contact=deepcopy(packet), recipients=names, collider_recipients=colliders, autonomous=True)
        self.bursts[identity] = row
        self.by_projectile[projectile] = identity
        w.log('impact_area_burst', **deepcopy(row))
        source = {k: packet[k] for k in ('actor', 'ability', 'action_id', 'source_life_generation', 'projectile_id')}
        source.update(component='impact_area', impact_area_burst_id=identity,
            location_m=deepcopy(packet['location_m']), radius_m=cfg['radius_m'])
        bodies = [dict(source, target=name, collision_kind='body', **w.life_cycles.target_fields(name)) for name in names]
        materials = [dict(source, target=name, collision_kind='terrain',
            **w.collider_system.registry.contact_fields(name)) for name in colliders]
        return bodies, materials

    def queue(self, packet):
        identity = packet.get('impact_area_burst_id')
        if identity is None:
            return
        key = identity + ':' + packet['target'] + ':' + str(packet['target_life_generation'])
        if key in self.hits:
            return
        self.hits[key] = {'id': key, 'burst_id': identity, 'packet': deepcopy(packet), 'status': 'queued'}
        self.world.push(self.world.time, EVENT, {'hit_id': key}, priority=3)

    def event_live(self, payload):
        row = self.hits.get(payload['hit_id'])
        return row is not None and row['status'] == 'queued'

    def process(self, payload):
        if not self.event_live(payload):
            return
        row = self.hits[payload['hit_id']]
        cfg = self.bursts[row['burst_id']]['definition']['gathering_modifier']
        identity = self.world.timed_gathering.create(row['packet'], **cfg)
        row.update(status='applied' if identity is not None else 'recipient_life_ended', modifier_id=identity)
        self.world.log('impact_area_effect_resolved', **deepcopy(row))

    def damage_type(self, packet, fallback):
        identity = packet.get('impact_area_burst_id')
        return self.bursts[identity]['damage_type'] if identity is not None else fallback

    def statuses(self, packet):
        return self.bursts[packet['impact_area_burst_id']]['target_effects']

    def result(self):
        return {'impact_area_rules': deepcopy(self.world.combat_locomotion_input['impact_areas']),
            'impact_area_bursts': deepcopy(list(self.bursts.values())),
            'impact_area_effect_hits': deepcopy(list(self.hits.values()))} if self.enabled else {}
