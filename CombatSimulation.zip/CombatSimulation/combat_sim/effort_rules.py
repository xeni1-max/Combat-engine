"""Phase-specific effort, sustained control and immutable released attack power.

The controller owns no projectiles, effects, weapon clocks or exclusive locks.
Its controls link ordinary owned actions; interruption cancels only unreleased
controlled actions through the existing action registry.
"""
from dataclasses import dataclass, field
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.effort import CATEGORIES, output_after_instability
from combat_sim.mechanics.body_part_damage import part_overrides,contact_component
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite


ZERO_U = D('1e-18')


@dataclass(frozen=True)
class ReleasedPower:
    actor: str
    ability: str
    action_id: int
    projectile_id: str | None
    phase: str
    category: str
    released_at_ms: D
    instability: D
    # (component name, authored base, released output). All entries immutable.
    components: tuple[tuple[str, D, D], ...]
    attack_id: str | None = None

    def __post_init__(self):
        EffectSource(self.actor, self.ability, self.action_id, self.projectile_id)
        if (self.projectile_id is None)==(self.attack_id is None):
            raise ValueError('Released power needs one projectile or direct attack identity')
        if self.attack_id is not None and (not isinstance(self.attack_id,str) or not self.attack_id):
            raise ValueError('Direct power needs an attack identity')
        if (not isinstance(self.phase, str) or not self.phase or not isinstance(self.category, str)
                or self.category not in CATEGORIES):
            raise ValueError('Released power requires a named effort phase and known category')
        object.__setattr__(self, 'released_at_ms', finite(self.released_at_ms, 'Release time'))
        object.__setattr__(self, 'instability', finite(self.instability, 'Release instability'))
        try:
            parts = tuple((name, finite(base, 'Base output'), finite(output, 'Released output'))
                          for name, base, output in self.components)
        except (TypeError, ValueError) as error:
            raise ValueError('Released power needs named base/output components') from error
        if (not parts or any(not isinstance(name, str) or not name or output > base for name, base, output in parts)
                or len({name for name, _, _ in parts}) != len(parts)):
            raise ValueError('Released power needs unique components with bounded output')
        object.__setattr__(self, 'components', parts)

    def amount(self, component):
        for name, _, output in self.components:
            if name == component:
                return output
        raise ValueError('Released attack has no component '+str(component))

    def record(self):
        return {'actor': self.actor, 'ability': self.ability, 'action_id': self.action_id,
                **({'attack_id':self.attack_id} if self.attack_id is not None else {'projectile_id':self.projectile_id}),
                'effort_phase': self.phase, 'category': self.category,
                'released_at_ms': self.released_at_ms, 'instability_at_release': self.instability,
                'components': {name: {'base': base, 'output': output}
                               for name, base, output in self.components}}


@dataclass
class SustainedControl:
    id: str
    actor: str
    ability: str
    phase: str
    started_at_ms: D
    resources: frozenset[str]
    functions: frozenset[str]
    action_ids: list[int] = field(default_factory=list)
    released_action_ids: list[int] = field(default_factory=list)
    own_instability: D = D(0)
    own_reference_ms: D = D(0)
    ended_at_ms: D | None = None
    end_reason: str | None = None

    def own_remaining(self, now):
        return max(D(0), self.own_instability-(now-self.own_reference_ms))

    def record(self):
        return {'id': self.id, 'actor': self.actor, 'ability': self.ability,
                'effort_phase': self.phase, 'started_at_ms': self.started_at_ms,
                'action_ids': list(self.action_ids), 'released_action_ids': list(self.released_action_ids),
                'ended_at_ms': self.ended_at_ms, 'end_reason': self.end_reason}


class EffortRules:
    def __init__(self, world, definition=None):
        self.world = world
        self.enabled = definition is not None
        if self.enabled and (definition != {'mode': 'phase_effort_v1'} or
                not world.mobile_mode or not world.effect_system.enabled or
                (world.combat_locomotion_input or {}).get('action_ownership', {}).get('mode') != 'declared_requirements_v1'):
            raise UnsupportedMechanicError('Phase effort requires the typed world and owned controlled actions')
        self.ids = count(1)
        self.phases = {}
        self.controls = {}
        self.active = {}
        self.releases = {}
        self.phase_instability = None

    def begin_phases(self):
        if self.enabled and self.phase_instability is None:
            self.phase_instability = {name: actor.instability for name, actor in self.world.fighters.items()}

    def finish_phases(self):
        self.phase_instability = None

    def validate_ability(self, actor, ability_id):
        if not self.enabled:
            return
        ability = self.world.attack_definition(actor.id,ability_id)
        phase = ability.get('effort_phase')
        if not isinstance(phase, str) or not phase:
            raise ValueError('Selected ability needs a source-reviewed effort phase')
        entries = actor.profile.get('documented_abilities', {}).get(ability_id, {}).get('effort_phases', {})
        entry = entries.get(phase) if isinstance(entries, dict) else None
        if not isinstance(entry, dict) or not isinstance(entry.get('category'), str) or entry['category'] not in CATEGORIES:
            raise ValueError('Selected ability needs a source-reviewed effort phase')
        category = entry['category']
        if 'body_part_damage' in ability:
            if ability['execution_model']!='direct_projectile' or not self.world.body_mode:
                raise UnsupportedMechanicError('Body-part output requires actual direct projectile contacts')
            part_overrides(ability['body_part_damage'],(box.part for box in self.world.world_bodies[actor.id]))
        if category == 'intrinsic_sustained' and ability.get('execution_model')!='weapon_swap':
            raise UnsupportedMechanicError('Intrinsic sustained damage delivery is not integrated yet')
        self.phases[(actor.id, ability_id)] = (phase, category)

    def ready_at(self, actor, ability_id, reload=False):
        if (not self.enabled or reload or
                self.selected_phase(actor,ability_id,self.world.attack_definition(actor.id,ability_id))[1] != 'extrinsic_sustained' or actor.instability <= ZERO_U):
            return self.world.time
        return self.world.time+actor.instability

    def action_started(self, actor, action):
        if not self.enabled:
            return
        if action.kind == 'reload':
            control = self.active.get((actor.id, action.ability_id))
            if control is not None:
                self.end(control, 'reload', cancel=False)
            return
        phase, category = self.selected_phase(actor,action.ability_id,self.world.action_definition(actor,action))
        if category != 'extrinsic_sustained':
            return
        if actor.instability > ZERO_U:
            raise ValueError('Cannot start sustained firing while unstable')
        key = (actor.id, action.ability_id)
        control = self.active.get(key)
        if control is None:
            requirements = actor.action_registry.requirements[action.id]
            control = SustainedControl('control:'+str(next(self.ids)), actor.id, action.ability_id,
                phase, self.world.time, requirements.occupies, requirements.requires)
            self.controls[control.id] = control
            self.active[key] = control
            self.world.log('sustained_control_started', control=control.record())
        control.action_ids.append(action.id)
        self.world.log('sustained_emission_started', actor=actor.id, ability=action.ability_id,
                       action_id=action.id, control_id=control.id)

    def own_recoil(self, actor, action, amount):
        if not self.enabled:
            return
        control = self.active.get((actor.id, action.ability_id))
        if control is not None and action.id in control.action_ids:
            control.own_instability = control.own_remaining(self.world.time)+amount
            control.own_reference_ms = self.world.time

    def capture_release(self, actor, action, ability, flight):
        if not self.enabled:
            return
        # A future multi-emission action can release different power at each
        # instant. Copies share the original entity's immutable root snapshot.
        key = flight['root_projectile_id']
        if key in self.releases:
            return self.releases[key]
        phase, category = self.selected_phase(actor,action.ability_id,ability)
        base = dec(ability['pre_mitigation_damage'])
        instability = actor.instability if self.phase_instability is None else self.phase_instability[actor.id]
        output = dec(output_after_instability(base, instability, category))
        names = ('projectile', 'delayed_blast') if ability['execution_model'] == 'projectile_delayed_area' else ('projectile',)
        if ability['execution_model']=='impact_area_projectile':names=('impact_area',)
        if ability['execution_model']=='poison_projectile':names=('projectile','poison_area')
        components=tuple((name,base,output) for name in names)
        if 'body_part_damage' in ability:
            overrides=part_overrides(ability['body_part_damage'],(box.part for box in self.world.world_bodies[actor.id]))
            components+=tuple(('projectile:'+part,dec(amount),dec(output_after_instability(amount,instability,category)))
                for part,amount in overrides)
        if ability['execution_model']=='impact_binding_area':components+=(('binding_burst',D(0),D(0)),)
        release = ReleasedPower(actor.id, action.ability_id, action.id, key, phase, category,
            self.world.time, instability, components)
        self.releases[key] = release
        control = self.active.get((actor.id, action.ability_id))
        if control is not None and action.id in control.action_ids and action.id not in control.released_action_ids:
            control.released_action_ids.append(action.id)
        self.world.log('attack_power_released', **release.record())
        return release

    def raw_damage(self, packet, ability):
        if not self.enabled:
            return dec(ability['pre_mitigation_damage'])
        key=packet.get('attack_id')
        if key is None:
            identity = self.world.projectiles.identities[packet['projectile_id']]
            key = identity.root_projectile_id
        if key not in self.releases:
            raise ValueError('A physical hit requires its immutable release power')
        release = self.releases[key]
        if (packet['actor'], packet['ability'], packet['action_id']) != (release.actor, release.ability, release.action_id):
            raise ValueError('A physical hit must retain its released source attribution')
        names={name for name,_,_ in release.components}
        component=packet['component']
        if any(name.startswith('projectile:') for name in names):
            component=contact_component(packet,names)
            packet['power_component']=component
        return release.amount(component)

    def selected_phase(self,actor,ability_id,ability):
        """A weapon variant can refer to its actual author's phase namespace."""
        source=ability.get('effort_source_ability')
        if source is None:return self.phases[(actor.id,ability_id)]
        phase=ability.get('effort_phase')
        entry=actor.profile.get('documented_abilities',{}).get(source,{}).get('effort_phases',{}).get(phase,{})
        if entry.get('category') not in CATEGORIES:raise ValueError('Selected variant lacks its reviewed effort source')
        return phase,entry['category']

    def capture_impact(self,actor,action,ability,attack_id):
        """An instantaneous melee frame has power without a fictitious projectile."""
        return self.capture_direct(actor,action.ability_id,action.id,ability,attack_id,action.component_id or 'strike')

    def capture_direct(self,actor,ability_id,action_id,ability,attack_id,component,*,instability_snapshot=None):
        """Freeze any direct emission's phase power before its future impacts."""
        if attack_id in self.releases:raise ValueError('Impact power was already captured')
        phase,category=self.phases[(actor.id,ability_id)]
        base=dec(ability['pre_mitigation_damage'])
        instability=actor.instability if self.phase_instability is None else self.phase_instability[actor.id]
        if instability_snapshot is not None:
            instability=dec(instability_snapshot)
            if not instability.is_finite() or instability<0:raise ValueError('Committed instability must be finite and nonnegative')
        output=dec(output_after_instability(base,instability,category))
        release=ReleasedPower(actor.id,ability_id,action_id,None,phase,category,
            self.world.time,instability,((component,base,output),),attack_id)
        self.releases[attack_id]=release
        self.world.log('attack_power_released',**release.record())
        return release

    def end(self, control, reason, *, cancel=True, disruption=None):
        if control.ended_at_ms is not None:
            return
        world = self.world
        actor = world.fighters[control.actor]
        control.ended_at_ms, control.end_reason = world.time, reason
        del self.active[(control.actor, control.ability)]
        # Mark ended first: cancellation receipts can call back into this controller.
        if cancel:
            for action in actor.live_actions():
                if action.id in control.action_ids:
                    world.cancel_owned_action(actor, action, 'sustained_control_'+reason, source=control.id)
        world.log('sustained_control_ended', control=control.record(), instability=actor.instability,
            own_recoil_remaining=control.own_remaining(world.time), disruptive_instability=disruption,
            released_effects_continue=True)
        world.request_decision(actor.id, world.time)

    def action_cancelled(self, actor, action, reason):
        if not self.enabled:
            return
        control = self.active.get((actor.id, action.ability_id))
        if control is not None and action.id in control.action_ids:
            self.end(control, reason, cancel=False)

    def stop_actor(self, actor):
        for control in list(self.active.values()):
            if control.actor == actor.id:
                self.end(control, 'death', cancel=False)

    def settle(self):
        """After a whole phase/hit/contact batch; never retract a due release."""
        if not self.enabled:
            return
        world = self.world
        for control in list(self.active.values()):
            actor = world.fighters[control.actor]
            if actor.died_at_ms is not None:
                self.end(control, 'death', cancel=False)
                continue
            disruption = max(D(0), actor.instability-control.own_remaining(world.time))
            if disruption > ZERO_U:
                self.end(control, 'instability', disruption=disruption)
                continue
            registry = actor.action_registry
            blocked = set().union(*registry.blocks.values()) if registry.blocks else set()
            if control.functions & blocked:
                self.end(control, 'function_restricted')
            elif any(action.id not in control.action_ids and
                    registry.requirements[action.id].occupies & control.resources for action in actor.live_actions()):
                self.end(control, 'resources_reassigned')
            elif actor.ammo.get(control.ability) == 0:
                self.end(control, 'empty_magazine', cancel=False)
            elif (not any(action.id in control.action_ids for action in actor.live_actions()) and
                    not any(enemy.hp > 0 and enemy.team != actor.team for enemy in world.fighters.values())):
                self.end(control, 'no_living_enemy', cancel=False)

    def result(self):
        if not self.enabled:
            return {}
        return {'effort_rules': self.world.combat_locomotion_input['effort_rules'],
                'sustained_controls': [c.record() for c in self.controls.values()],
                'released_attack_power': [r.record() for r in self.releases.values()]}
