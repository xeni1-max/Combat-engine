"""Owned moving ability volumes on saved body paths; never released projectiles."""
from copy import deepcopy
from decimal import Decimal as D
from itertools import count
from fractions import Fraction as F

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import Cuboid,local_to_world_point
from combat_sim.movement_contacts import first_box_contact
from combat_sim.pose_kinematics import pose_acceleration,projectile_pose_acceleration
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M as DIST,CONTACT_TIME_EPS_MS as TIME
from combat_sim.oriented_geometry import OrientedCuboid,projected_size,separating_axes
from combat_sim.orientation import dot,vector3,scalar,YawFrame
from combat_sim.box_motion import closest_point
from combat_sim.angular_contacts import box_path_contact
from combat_sim.spatial_motion import contact_boundary_time


EVENT='owned_contact'


class OwnedContacts:
    def __init__(self,world):
        self.world=world;self.ids=count(1);self.rows={}

    def validate_geometry(self,actor,geometry):
        w=self.world
        if (not isinstance(geometry,dict) or set(geometry)-{'mode','anchor_part','centre_offset_m','size_xyz_m','anchor_fraction'} or
                not {'mode','anchor_part','centre_offset_m','size_xyz_m'}<=set(geometry) or
                geometry['mode']!='body_part_box' or geometry['anchor_part'] not in {b.part for b in w.world_bodies[actor.id]} or
                any(not isinstance(geometry[k],(tuple,list)) or len(geometry[k])!=3 for k in ('centre_offset_m','size_xyz_m')) or
                any(not dec(v).is_finite() for k in ('centre_offset_m','size_xyz_m') for v in geometry[k]) or
                any(dec(v)<=0 for v in geometry['size_xyz_m'])):raise ValueError('Invalid owned contact volume geometry')
        if 'anchor_fraction' in geometry:
            f=geometry['anchor_fraction']
            if (not isinstance(f,(tuple,list)) or len(f)!=3 or
                    any(not dec(v).is_finite() or abs(dec(v))>D('.5') for v in f)):
                raise ValueError('Owned contact anchor fractions must lie within the body part')

    def start(self,actor,action,geometry,until,*,ordering='forward',apply_self_effects=True):
        w=self.world;until=None if until is None else dec(until)
        if (actor.hp<=0 or actor.action_by_id(action.id) is not action or action.phase!='active' or
                action.life_generation!=actor.life_generation or until is not None and (not until.is_finite() or until<=w.time)):
            raise ValueError('A contact volume needs a current owned Active and future clock')
        if ordering not in ('forward','down') or type(apply_self_effects) is not bool:
            raise ValueError('Owned contact needs explicit supported ordering/self-effect policy')
        self.validate_geometry(actor,geometry)
        row=dict(id='owned-contact:'+str(next(self.ids)),actor=actor.id,ability=action.ability_id,
            action_id=action.id,source_life_generation=actor.life_generation,facing=actor.facing,
            geometry=deepcopy(geometry),created_at_ms=self.world.time,until_ms=until,status='active')
        turns=getattr(w,'turns',None)
        if turns is not None and turns.enabled:row['follows_owner_heading']=True
        if ordering!='forward':row['ordering']=ordering
        if not apply_self_effects:row['apply_self_effects']=False
        self.rows[row['id']]=row
        self.world.log('owned_contact_volume_started',volume=deepcopy(row));return row

    def active(self,row):
        w=self.world;a=w.fighters[row['actor']];action=a.action_by_id(row['action_id'])
        return (row['status']=='active' and a.hp>0 and a.life_generation==row['source_life_generation'] and
            action is not None and action.phase=='active' and (row['until_ms'] is None or w.time<row['until_ms']))

    def end(self,row,reason):
        if row['status']!='active':return
        row.update(status='ended',ended_at_ms=self.world.time,end_reason=reason)
        self.world.log('owned_contact_volume_ended',volume=deepcopy(row))

    def geometry_row(self,row):
        if row.get('follows_owner_heading'):
            return dict(row,facing=self.world.fighters[row['actor']].facing)
        return row

    def box(self,row):
        row=self.geometry_row(row)
        w=self.world;g=row['geometry'];actor=w.fighters[row['actor']]
        anchor=next(b for b in w.world_bodies[actor.id] if b.part==g['anchor_part'])
        offset=tuple(map(dec,local_to_world_point(g['centre_offset_m'],(0,0,0),row['facing'])))
        size=tuple(map(dec,g['size_xyz_m']))
        if isinstance(row['facing'],YawFrame):
            frame=row['facing'];fraction=vector3(g.get('anchor_fraction',(0,0,0)))
            shift=frame.to_world_vector(tuple(f*s for f,s in zip(fraction,anchor.size_m)))
            centre=tuple(dec(p)+q+dec(s) for p,q,s in zip(anchor.centre_m,offset,shift))
            return OrientedCuboid(row['id'],centre,size,frame)
        if row['facing'] in ('+x','-x'):size=(size[1],size[0],size[2])
        if 'anchor_fraction' not in g:
            return Cuboid(row['id'],tuple(dec(p)+q for p,q in zip(anchor.centre_m,offset)),size)
        fraction=self.fraction(row)
        return Cuboid(row['id'],tuple(dec(p)+q+f*dec(s) for p,q,f,s in zip(anchor.centre_m,offset,fraction,anchor.size_m)),size)

    @staticmethod
    def fraction(row):
        return tuple(map(dec,local_to_world_point(row['geometry'].get('anchor_fraction',(0,0,0)),(0,0,0),row['facing'])))

    @staticmethod
    def anchor_displacement(row,values):
        if isinstance(row['facing'],YawFrame):
            fraction=vector3(row['geometry'].get('anchor_fraction',(0,0,0)))
            return tuple(map(dec,row['facing'].to_world_vector(tuple(f*s for f,s in zip(fraction,vector3(values))))))
        return tuple(f*r for f,r in zip(OwnedContacts.fraction(row),values))

    def groups(self,row):
        w=self.world
        for name,boxes in sorted(w.world_bodies.items()):
            if name==row['actor']:continue
            yield name,tuple(boxes) if w.fighters[name].hp>0 else (),False
            yield name,w.blocking.boxes(name),False
        for name,boxes in sorted(w.body_terrain_colliders().items()):yield name,boxes,True

    def order(self,row,name,box):
        row=self.geometry_row(row)
        w=self.world;origin=w.fighters[row['actor']].body_origin_m
        if row.get('ordering')=='down':return -dec(box.bounds[1][2]),name,box.part
        if isinstance(row['facing'],YawFrame):
            n=row['facing'].forward;delta=tuple(a-b for a,b in zip(vector3(box.centre_m),vector3(origin)))
            return max(D(0),dec(dot(delta,n)-projected_size(box,n)/2)),name,box.part
        axis=0 if row['facing'] in ('+x','-x') else 1;sign=D(1 if row['facing'][0]=='+' else -1)
        if isinstance(box,OrientedCuboid):
            n=tuple(1 if i==axis else 0 for i in range(3))
            return max(D(0),sign*(dec(box.centre_m[axis])-dec(origin[axis]))-dec(projected_size(box,n))/2),name,box.part
        return max(D(0),sign*(dec(box.centre_m[axis])-dec(origin[axis]))-dec(box.size_m[axis])/2),name,box.part

    @staticmethod
    def touching(first,second):
        if isinstance(first,OrientedCuboid) or isinstance(second,OrientedCuboid):
            delta=tuple(a-b for a,b in zip(vector3(first.centre_m),vector3(second.centre_m)))
            tolerance=scalar(DIST)
            return all(abs(dot(delta,n)) <= (projected_size(first,n)+projected_size(second,n))/2+tolerance for n in separating_axes(first,second))
        a,b=first.bounds;c,d=second.bounds
        return all(dec(a[i])<=dec(d[i])+DIST and dec(c[i])<=dec(b[i])+DIST for i in range(3))

    def next_contacts(self,end):
        w=self.world;found=[]
        for row in self.rows.values():
            if not self.active(row):continue
            row=self.geometry_row(row)
            source=row['actor'];box=self.box(row);limit=end if row['until_ms'] is None else min(end,row['until_ms'])
            seconds=(limit-w.time+TIME)/1000
            velocity,acceleration=w.mobile_motion(source)
            offset,rate=w.pose_part_motion(source,row['geometry']['anchor_part'],w.time)
            change,size_a=pose_acceleration(w,source,row['geometry']['anchor_part'],w.time)
            if 'anchor_fraction' in row['geometry']:
                offset=tuple(v+f for v,f in zip(offset,self.anchor_displacement(row,rate)))
                change=tuple(v+f for v,f in zip(change,self.anchor_displacement(row,size_a)))
            for name,boxes,static in self.groups(row):
                for other in boxes:
                    turns=getattr(w,'turns',None)
                    if turns is not None and (turns.active(source) or not static and turns.active(name)):
                        lease=min(limit,dec(w.body_paths.ensure(future=True).end_ms))
                        first=turns.owned_path(row,lease)
                        second=other if static else turns.path(name,other,lease)
                        hit=None if not self.touching(box,other) else F(w.time)/1000
                        if hit is None:
                            contact=box_path_contact(first,second,F(w.time)/1000,F(lease)/1000,
                                time_tolerance_s=F(1,10**28))
                            hit=None if contact is None else contact.time_upper_s
                        if hit is not None:
                            when=contact_boundary_time(dec(hit*1000),lease)
                            found.append((when,row['id'],self.order(row,name,other)))
                        continue
                    bv,ba,pose,rate=(((D(0),)*3,)*4 if static else w.blocking.kinematics(name,other.part,w.time))
                    pa,size_a=(((D(0),)*3,)*2 if static else projectile_pose_acceleration(w,name,other.part,w.time))
                    relative=tuple(x+y-z-q for x,y,z,q in zip(velocity,offset,bv,pose))
                    relative_a=tuple(x+y-z-q for x,y,z,q in zip(acceleration,change,ba,pa))
                    hit=D(0) if self.touching(box,other) else first_box_contact(box,other,relative,relative_a,seconds,
                        right_size_rate_mps=rate,right_size_acceleration_mps2=size_a,
                        allow_flat_static_right=static and any(dec(x)==0 for x in other.size_m))
                    if hit is None:continue
                    when=w.time+hit*1000
                    if when>end+TIME:continue
                    when=min(when,end)
                    found.append((when,row['id'],self.order(row,name,other)))
        if not found:return None
        first=min(x[0] for x in found)
        # One due event per source. Actual geometry is checked again after phases.
        return first,[{'volume_id':identity} for identity in sorted({identity for t,identity,_ in found if abs(t-first)<=TIME})]

    def live(self,payload):
        row=self.rows.get(payload.get('volume_id'));return row is not None and self.active(row)

    def resolve(self,payload):
        if not self.live(payload):return None
        w=self.world;row=self.rows[payload['volume_id']];box=self.box(row);found=[]
        for name,boxes,static in self.groups(row):
            for other in boxes:
                if self.touching(box,other):found.append((self.order(row,name,other),static,other))
        if not found:return None
        (_,name,part),static,other=min(found,key=lambda x:x[0])
        actor=w.fighters[row['actor']];action=actor.action_by_id(row['action_id'])
        ability=w.action_definition(actor,action)
        self.end(row,'contact_committed')
        w.effort_system.capture_impact(actor,action,ability,row['id'])
        w.attack_modifiers.capture(actor,action,row['id'])
        low,high=other.bounds
        point=(tuple(map(dec,closest_point(other,box.centre_m))) if isinstance(other,OrientedCuboid) else
            tuple(max(dec(a),min(dec(b),dec(p))) for a,b,p in zip(low,high,box.centre_m)))
        packet=dict(attack_id=row['id'],actor=actor.id,ability=action.ability_id,action_id=action.id,
            source_life_generation=actor.life_generation,aim_target=action.target,target=name,component='strike',
            delivery_kind='owned_box_sweep',collision_kind='terrain' if static else 'body',
            location_m=point,distance_m=D(0),hit_parts=[part])
        if static:packet.update(w.collider_system.registry.contact_fields(name))
        else:
            packet.update(w.life_cycles.target_fields(name));packet.update(w.blocking.contact_fields(part))
        if row.get('apply_self_effects',True):
            with actor.using_action(action):w.self_effect({'actor':actor.id,'melee_contact':True})
        w.log('owned_contact_committed',**packet)
        return packet

    def settle(self):
        for row in self.rows.values():
            if row['status']=='active' and not self.active(row):self.end(row,'source_phase_or_life_ended')

    def result(self):
        return {'owned_contact_volumes':deepcopy(list(self.rows.values()))} if self.rows else {}
