"""Validated atomic body relocation/velocity/support changes on the shared world.

Relocation changes a destination, not a swept path. Imposed velocities use the
ordinary continuous collision/flight machinery. Persistent links and authored
casts remain separate controllers; a group projection is instantaneous.
"""
from copy import deepcopy
from dataclasses import dataclass, replace
from decimal import Context,Decimal as D,localcontext
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import world_standing_cuboids
from combat_sim.character_geometry import actor_body,crouch_target
from combat_sim.mechanics.life import life_generation
from combat_sim.mechanics.velocity_projection import (VelocityNode,VelocityEquality,BlockedDirection,
    project_velocities,vector)
from combat_sim.mechanics.unilateral_velocity import project_unilateral
from combat_sim.mechanics.support_geometry import vertical_witnesses,crosses_finite_sheet
from combat_sim.oriented_geometry import OrientedCuboid,boxes_overlap
from combat_sim.models import UnsupportedMechanicError
from combat_sim.postures import world_posture_cuboids
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M,CONTACT_SPEED_EPS_MPS,CONTACT_ACCEL_EPS_MPS2


class StaleSpatialPlan(ValueError):pass


@dataclass(frozen=True)
class SpatialChange:
    actor: str
    expected_life_generation: int
    reference_m: tuple | None = None
    velocity_mps: tuple | None = None

    def __post_init__(self):
        if not isinstance(self.actor,str) or not self.actor:raise ValueError('Spatial change needs an actor identity')
        generation=life_generation(self.expected_life_generation)
        if generation is None:raise ValueError('Spatial changes require an expected actor life')
        object.__setattr__(self,'expected_life_generation',generation)
        for key in ('reference_m','velocity_mps'):
            if getattr(self,key) is not None:object.__setattr__(self,key,vector(getattr(self,key)))


@dataclass(frozen=True)
class PreparedBody:
    actor: str
    generation: int
    reference: tuple
    velocity: tuple
    before_reference: tuple
    before_velocity: tuple
    boxes: tuple
    support: tuple | None
    changed_reference: bool
    old_mode: str
    old_speed: D
    old_drive: tuple
    basic_jump: bool
    landing_effects: tuple | None
    motion_cause: tuple | None
    contact_obligations: tuple = ()


@dataclass(frozen=True)
class SpatialPlan:
    owner: object
    dependency: tuple
    source: str
    purpose: str
    bodies: tuple[PreparedBody,...]


class SpatialTransitions:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'atomic_body_v1'} or not world.mobile_mode
                or not world.life_cycles.enabled):
            raise UnsupportedMechanicError('Spatial transitions require the current living mobile world')
        self.owner=object();self.ids=count(1);self.records=[];self.interventions={};self.commands={}

    def load_interventions(self):
        rows=self.world.scenario.get('spatial_interventions',[])
        if not isinstance(rows,list):raise ValueError('Spatial interventions must be a list')
        if rows and not self.enabled:raise UnsupportedMechanicError('Spatial interventions require atomic spatial rules')
        pending=[]
        for index,row in enumerate(rows,1):
            if not isinstance(row,dict) or set(row)-{'at_ms','scope','source','changes','projection','grapple'}:
                raise ValueError('Unknown spatial intervention fields')
            if (row.get('scope')!='engineering' or not isinstance(row.get('source'),str) or not row['source']
                    or isinstance(row.get('at_ms'),bool) or 'at_ms' not in row):
                raise ValueError('Interventions need explicit engineering scope, source and time')
            time=dec(row['at_ms'])
            if time<0:raise ValueError('Intervention time cannot be negative')
            if sum(key in row for key in ('changes','projection','grapple'))!=1:
                raise ValueError('Intervention must change bodies, project velocities or update one grapple link')
            if 'changes' in row:
                if not isinstance(row['changes'],list) or not row['changes']:raise ValueError('Intervention needs body changes')
                entries=[]
                for change in row['changes']:
                    if (not isinstance(change,dict) or set(change)-{'actor','expected_life_generation','reference_m','velocity_mps'}
                            or not {'actor','expected_life_generation'}<=set(change)):
                        raise ValueError('Intervention changes need explicit actor/life and known coordinates')
                    entries.append(SpatialChange(**change))
                if len({c.actor for c in entries})!=len(entries):raise ValueError('Duplicate actor in intervention')
                actors={c.actor:c.expected_life_generation for c in entries};command=('changes',tuple(entries))
            elif 'grapple' in row:
                value=self.world.grapple_links.parse_command(row['grapple'])
                actors=value.actors;command=('grapple',value)
            else:
                p=row['projection']
                if (not isinstance(p,dict) or set(p)-{'actors','equalities','blocked_directions'}
                        or not isinstance(p.get('actors'),dict) or not p['actors']):
                    raise ValueError('Projection needs explicit actor-to-life identities')
                actors={name:life_generation(value) for name,value in p['actors'].items()}
                if any(value is None for value in actors.values()):raise ValueError('Projection needs expected actor lives')
                if (not isinstance(p.get('equalities',[]),list) or
                        any(not isinstance(pair,(list,tuple)) or len(pair)!=2 for pair in p.get('equalities',[])) or
                        not isinstance(p.get('blocked_directions',[]),list) or
                        any(not isinstance(c,dict) or set(c)!={'actor','normal'} for c in p.get('blocked_directions',[]))):
                    raise ValueError('Projection needs explicit equality pairs and blocked-direction records')
                edges=tuple(VelocityEquality(*pair) for pair in p.get('equalities',()))
                normals=tuple(BlockedDirection(c['actor'],c['normal']) for c in p.get('blocked_directions',()))
                # Reuse graph validation without reading future velocities/armor.
                project_velocities(tuple(VelocityNode(name,(0,0,0),1,0) for name in actors),edges,normals)
                command=('projection',actors,edges,normals)
            if any(name not in self.world.fighters for name in actors):raise ValueError('Unknown intervention actor')
            identity='intervention:'+str(index)
            record={'id':identity,'at_ms':time,'scope':'engineering','source':row['source'],
                'kind':command[0],'expected_lives':actors,'status':'queued'}
            pending.append((identity,record,command))
        for identity,record,command in pending:
            self.interventions[identity]=record;self.commands[identity]=command
            self.world.push(record['at_ms'],'spatial_intervention',{'intervention_id':identity},priority=5)

    def intervention_live(self,payload):
        return self.interventions[payload['intervention_id']]['status']=='queued'

    def process_intervention(self,payload):
        record=self.interventions[payload['intervention_id']]
        if record['status']!='queued':return
        command=self.commands[record['id']]
        try:
            if command[0]=='changes':plan=self.prepare(command[1],source=record['source'])
            elif command[0]=='grapple':plan=self.world.grapple_links.prepare(command[1],source=record['source'])
            else:
                projection,plan=self.prepare_projection(*command[1:],source=record['source'])
                record['projection']=projection.record()
        except StaleSpatialPlan as error:record.update(status='skipped',reason=str(error))
        except ValueError as error:record.update(status='rejected',reason=str(error))
        else:
            # Runtime bugs during commit/notification must propagate; they are
            # not a safely rejected preflight after a partially applied update.
            result=(self.world.grapple_links.commit(plan) if command[0]=='grapple' else self.commit(plan))
            record.update(status='applied' if result is not None else 'no_change',
                **{('grapple_link_id' if command[0]=='grapple' else 'transition_id'):result['id'] if result is not None else None})
        record['processed_at_ms']=self.world.time
        self.world.log('spatial_intervention_processed',intervention=deepcopy(record))

    def reference(self,name):
        actor=self.world.fighters[name];m=self.world.motion[name]
        return (*tuple(map(dec,actor.position_m)),dec(m.get('body_reference_z',actor.body_origin_m[2])))

    def _dependency(self):
        w=self.world
        return (w.time,w.collider_system.registry.epoch,getattr(getattr(w,'grapple_links',None),'epoch',0),
            getattr(getattr(w,'distance_constraints',None),'epoch',0),
            tuple((name,w.body_motion_dependency(name),
            a.hp,a.armor,a.dyspnea,a.disorientation,a.instability,
            w.motion[name]['mode'],w.motion[name]['phase'],w.motion[name]['speed'],w.motion[name]['acceleration'],
            w.motion[name].get('support_part'),w.motion[name].get('ground_origin_z'),
            w.motion[name].get('body_reference_z'),w.motion[name].get('revision'),
            w.free_mobile_motion(name),tuple(w.motion[name]['direction']),
            bool(w.motion[name].get('jump') and w.motion[name]['jump'].get('basic_jump',False)),
            w.motion[name]['jump'].get('landing_effects') if w.motion[name].get('jump') else None,
            w.motion[name]['jump'].get('contact_obligations',()) if w.motion[name].get('jump') else (),
            w.motion[name]['jump'].get('motion_cause') if w.motion[name].get('jump') else None,
            w.motion[name].get('imposed_velocity'),
            tuple((action.id,action.revision,action.phase) for action in a.live_actions()))
            for name,a in sorted(w.fighters.items())))

    @staticmethod
    def _overlap(left,right):
        if isinstance(left,OrientedCuboid) or isinstance(right,OrientedCuboid):return boxes_overlap(left,right,closed=False)
        return all(max(a,c)<min(b,d) for a,b,c,d in zip(left.bounds[0],left.bounds[1],right.bounds[0],right.bounds[1]))

    def _support(self,boxes):
        if self.world.terrain_support.enabled:
            return self.world.terrain_support.find_support('proposed-body',boxes)
        bottom=min(box.bounds[0][2] for box in boxes)
        feet=[box for box in boxes if box.bounds[0][2]==bottom]
        for key,parts in sorted(self.world.collider_system.registry.active('bodies',self.world.time).items()):
            for part in sorted(parts,key=lambda p:p.part):
                low,high=part.bounds
                if abs(dec(high[2])-dec(bottom))>CONTACT_DISTANCE_EPS_M:continue
                if any(all(max(a,c)<min(b,d) for a,b,c,d in zip(box.bounds[0][:2],box.bounds[1][:2],low[:2],high[:2]))
                        for box in feet):return key,part.part
        return None

    def prepare(self,changes,*,source):
        if not self.enabled:raise UnsupportedMechanicError('Atomic spatial updates are not enabled')
        with localcontext(Context(prec=self.world.precision)):
            return self._prepare(changes,source=source,purpose='external')

    def prepare_transport(self,changes,*,source):
        """Preflight voluntary relocation retaining independent motion inputs."""
        if not self.enabled:raise UnsupportedMechanicError('Atomic spatial updates are not enabled')
        changes=tuple(changes)
        if any(isinstance(c,SpatialChange) and c.velocity_mps is not None for c in changes):
            raise ValueError('Transport retains motion; velocity replacement is a separate spatial operation')
        with localcontext(Context(prec=self.world.precision)):
            return self._prepare(changes,source=source,purpose='transport')

    def _transport_supports(self,candidates,prepared):
        """Use all final placements together, including carried body stacks."""
        w=self.world
        shapes={n:tuple(candidates.get(n,w.world_bodies[n])) for n,a in w.fighters.items() if a.hp>0}
        velocities={n:tuple(map(dec,w.mobile_motion(n)[0])) for n in shapes}
        chosen={}
        for name,boxes in shapes.items():
            if w.motion[name]['jump'] is None and abs(velocities[name][2])<=CONTACT_SPEED_EPS_MPS:
                support=self._support(boxes)
                if support is not None:chosen[name]=support
        pairs=tuple(vertical_witnesses(shapes,distance_epsilon=CONTACT_DISTANCE_EPS_M))
        for _ in range(len(shapes)):
            changed=False
            for p in pairs:
                if p.upper in chosen or p.lower not in chosen or w.motion[p.upper]['jump'] is not None:continue
                pv,pa,_,_=w.body_support.pair_motion(p)
                if (abs(pv)>CONTACT_SPEED_EPS_MPS or abs(pa)>CONTACT_ACCEL_EPS_MPS2
                        or abs(velocities[p.upper][2]-velocities[p.lower][2])>CONTACT_SPEED_EPS_MPS):continue
                chosen[p.upper]=(p.lower,p.lower_part);changed=True
            if not changed:break
        return tuple(replace(b,support=chosen.get(b.actor)) for b in prepared)

    def _prepare(self,changes,*,source,purpose):
        w=self.world
        if not w.mobile_mode or not w.airborne_enabled:
            raise UnsupportedMechanicError('Atomic motion needs shared body gravity/support')
        if not isinstance(source,str) or not source:raise ValueError('Spatial transition needs its source')
        changes=tuple(changes)
        if not changes or any(not isinstance(c,SpatialChange) for c in changes):
            raise ValueError('Spatial transition needs typed body changes')
        if purpose in ('external','transport'):changes=w.grapple_links.expand_changes(changes)
        if len({c.actor for c in changes})!=len(changes):raise ValueError('A body may appear only once in a spatial transaction')
        candidates={};prepared=[];placements=set()
        floor=w.terrain_colliders[w.terrain_definition['ground']['id']][0]
        for change in sorted(changes,key=lambda c:c.actor):
            if change.actor not in w.fighters:raise ValueError('Unknown spatial actor')
            a=w.fighters[change.actor];m=w.motion[a.id]
            if a.life_generation!=change.expected_life_generation:raise StaleSpatialPlan('Spatial update belongs to another actor life')
            if purpose!='restoration' and (a.hp<=0 or a.died_at_ms is not None):
                raise StaleSpatialPlan('A dead actor cannot receive controlled spatial updates')
            before=self.reference(a.id);velocity=tuple(map(dec,w.mobile_motion(a.id)[0]))
            reference=tuple(map(dec,change.reference_m)) if change.reference_m is not None else before
            output=tuple(map(dec,change.velocity_mps)) if change.velocity_mps is not None else velocity
            moved=any(abs(x-y)>CONTACT_DISTANCE_EPS_M for x,y in zip(reference,before))
            changed_velocity=any(abs(x-y)>CONTACT_SPEED_EPS_MPS for x,y in zip(output,velocity))
            if not moved:reference=before
            if not changed_velocity:output=velocity
            if moved:
                if w.posture_ready:
                    fraction,_=w.posture_at(a.id,w.time)
                    boxes=(w.equilibrium.boxes(a.id,reference) if w.equilibrium.carries(a.id) else
                        world_posture_cuboids(actor_body(w,a.id),reference,a.facing,fraction,
                            crouch_target(w,a.id,w.crouch_definition['target_leg_height_m'])))
                else:boxes=world_standing_cuboids(actor_body(w,a.id),reference,a.facing)
            else:boxes=tuple(w.world_bodies[a.id])
            if not w.terrain_support.finite_ground:
                if any(box.bounds[0][i]<floor.bounds[0][i] or box.bounds[1][i]>floor.bounds[1][i]
                        for box in boxes for i in (0,1)):
                    raise UnsupportedMechanicError('Spatial destination outside finite ground footprint needs edge/fall integration')
                if dec(min(box.bounds[0][2] for box in boxes))<dec(floor.bounds[1][2])-CONTACT_DISTANCE_EPS_M:
                    raise ValueError('Spatial destination is below the ground surface')
            elif (moved or purpose=='restoration') and any(crosses_finite_sheet(box,floor,
                    distance_epsilon=CONTACT_DISTANCE_EPS_M) for box in boxes):
                raise ValueError('Spatial destination crosses the finite ground surface (partly below the ground)')
            candidates[a.id]=boxes
            if moved or purpose=='restoration':placements.add(a.id)
            if not moved and not changed_velocity and purpose in ('external','transport'):continue
            support=self._support(boxes) if abs(output[2])<=CONTACT_SPEED_EPS_MPS else None
            if support is None and w.body_support.ready:
                if moved or purpose=='restoration':support=w.body_support.support_for_boxes(a.id,boxes,output)
                else:
                    support=w.body_support.find_support(a)
                    if support is not None and abs(output[2]-w.raw_body_motion(support[0])[0][2])>CONTACT_SPEED_EPS_MPS:
                        support=None
            if (not w.terrain_support.enabled and support is not None and
                    support[0]!=w.terrain_definition['ground']['id'] and support[0] not in w.fighters):
                part=next(p for p in w.terrain_colliders[support[0]] if p.part==support[1])
                if any(box.bounds[0][i]<part.bounds[0][i] or box.bounds[1][i]>part.bounds[1][i]
                        for box in boxes for i in (0,1)):
                    raise UnsupportedMechanicError('Partial raised support needs ledge/fall integration')
            old_drive=tuple(v*m['speed'] for v in m['direction'])+(D(0),)
            prepared.append(PreparedBody(a.id,a.life_generation,reference,output,before,velocity,
                tuple(boxes),support,moved,m['mode'],m['speed'],old_drive,
                bool(m['jump'] is not None and m['jump'].get('basic_jump',False)),
                m['jump'].get('landing_effects') if m['jump'] is not None else None,
                m['jump'].get('motion_cause') if m['jump'] is not None else None,
                m['jump'].get('contact_obligations',()) if m['jump'] is not None else ()))
        # Validate final destinations together: swaps are legal, overlaps are not.
        # The finite zero-thickness sheet has its own crossing band above.
        # A solid-volume SAT test would reject valid sub-resolution contact.
        floor_id=w.terrain_definition['ground']['id'] if w.terrain_support.finite_ground else None
        solids=[p for key,parts in w.body_terrain_colliders().items() if key!=floor_id for p in parts]
        for name,boxes in candidates.items():
            others=[p for other,a in w.fighters.items() if other!=name and (a.hp>0 or other in candidates)
                for p in candidates.get(other,w.world_bodies[other])]
            # A velocity update reuses the current geometry; it cannot create
            # placement overlap. Contact roots may already lie microscopically
            # inside material. Validate every new placement against *all* final
            # bodies, including unchanged velocity recipients. Restoration is
            # a new occupancy even though its retained reference is unchanged.
            if name in placements and any(self._overlap(a,b) for a in boxes for b in solids+others):
                raise ValueError('Spatial destination overlaps a solid or living body')
            body=next((p for p in prepared if p.actor==name),None)
            if body is not None and body.support is None and body.velocity[2]<=CONTACT_SPEED_EPS_MPS and not w.body_support.ready:
                bottom=min(b.bounds[0][2] for b in boxes)
                if any(abs(dec(p.bounds[1][2])-dec(bottom))<=CONTACT_DISTANCE_EPS_M and
                        any(all(max(a,c)<min(b,d) for a,b,c,d in zip(box.bounds[0][:2],box.bounds[1][:2],p.bounds[0][:2],p.bounds[1][:2]))
                            for box in boxes) for p in others):
                    raise UnsupportedMechanicError('Dynamic body support is not integrated')
        if purpose=='transport':
            w.distance_constraints.validate_transport({b.actor:b.reference for b in prepared if b.changed_reference})
            prepared=self._transport_supports(candidates,prepared)
        return SpatialPlan(self.owner,self._dependency(),source,purpose,tuple(prepared))

    def commit(self,plan,*,notify=True):
        with localcontext(Context(prec=self.world.precision)):
            if not isinstance(plan,SpatialPlan) or plan.owner is not self.owner:raise ValueError('Spatial plan belongs to another world')
            if plan.dependency!=self._dependency():raise StaleSpatialPlan('World changed after spatial preparation')
            if not plan.bodies:return None
            if plan.purpose=='transport':return self._commit_transport(plan,notify=notify)
            w=self.world
            # All validation is complete before any cancellation or coordinate write.
            if plan.purpose!='restoration':
                for body in plan.bodies:
                    actor=w.fighters[body.actor];action=actor.body_action()
                    if action is not None:w.cancel_owned_action(actor,action,
                        'support_lost' if plan.purpose=='support_loss' else
                        'external_displacement' if body.changed_reference else 'external_velocity',
                        source=None if plan.purpose=='support_loss' else plan.source)
            for body in plan.bodies:
                a=w.fighters[body.actor];m=w.motion[a.id]
                if plan.purpose=='support_loss' and any(m.get('distance_inertial_velocity',(0,0,0))):
                    m['imposed_velocity']=(*body.old_drive[:2],D(0))
                m.pop('distance_inertial_velocity',None)
                m.pop('distance_force_driven',None)
                if body.changed_reference:w.set_body_reference(a.id,body.reference)
                elif plan.purpose!='support_loss':m['spatial_revision']=m.get('spatial_revision',0)+1
                if plan.purpose=='restoration':
                    m.pop('imposed_velocity',None)
                    m.update(mode='standing',phase=None,speed=D(0),acceleration=D(0),intents=[],active_intent=None,
                        climb=None,sprint_anchor=None,death_airborne=False)
                elif plan.purpose=='support_loss':
                    m.update(mode=body.old_mode,speed=body.old_speed,phase=None,acceleration=D(0))
                else:
                    m.update(mode='standing',phase=None,speed=D(0),acceleration=D(0),climb=None,sprint_anchor=None)
                    if any(body.velocity[:2]):m['imposed_velocity']=(*body.velocity[:2],D(0))
                    else:m.pop('imposed_velocity',None)
                m['support_id']=body.support[0] if body.support else None
                m['support_part']=body.support[1] if body.support else None
                obligation=body.landing_effects if plan.purpose=='external' else None
                contacts=body.contact_obligations if plan.purpose=='external' else ()
                if body.support and obligation is None and not contacts:
                    m.update(jump=None,ground_origin_z=body.reference[2])
                else:
                    flight={'velocity':body.velocity,'basic_jump':body.basic_jump if plan.purpose=='external' else False}
                    if obligation is not None:flight['landing_effects']=obligation
                    if contacts:flight['contact_obligations']=contacts
                    if (plan.purpose=='external' and body.motion_cause is not None and
                            all(abs(x-y)<=CONTACT_SPEED_EPS_MPS for x,y in zip(body.velocity,body.before_velocity))):
                        flight['motion_cause']=body.motion_cause
                    if plan.purpose=='support_loss':flight['ground_drive_velocity']=body.old_drive
                    m['jump']=flight
                if plan.purpose!='support_loss':m['revision']+=1
            if plan.purpose in ('external','restoration'):w.knock_motion.external_changed(plan.bodies)
            if plan.purpose in ('external','restoration'):w.distance_constraints.external_changed(plan.bodies)
            return self._finish(plan,notify=notify)

    def _commit_transport(self,plan,*,notify):
        w=self.world
        free={b.actor:tuple(map(dec,w.free_mobile_motion(b.actor)[0])) for b in plan.bodies}
        # All destinations/lives and the complete affected group were validated
        # before any controlled action or physical coordinate can change.
        for body in plan.bodies:
            if w._climbing(body.actor):
                actor=w.fighters[body.actor];action=actor.body_action()
                if action is not None:w.cancel_owned_action(actor,action,'transported_from_climb',source=plan.source)
        for body in plan.bodies:
            m=w.motion[body.actor]
            if body.changed_reference:w.set_body_reference(body.actor,body.reference)
            # Keep running/walking transitions, pose, jump/debt, independent
            # motor requests and released force components. Only actual loss
            # of support needs a free-flight driver; no second group average.
            if m['jump'] is None and body.support is None:
                m['jump']={'velocity':free[body.actor],'basic_jump':False,'ground_drive_velocity':body.old_drive}
            support=body.support if m['jump'] is None else None
            m['support_id']=support[0] if support else None
            m['support_part']=support[1] if support else None
            if support:m['ground_origin_z']=body.reference[2]
            m['revision']+=1
        w.distance_constraints.external_changed(plan.bodies)
        return self._finish(plan,notify=notify)

    def _finish(self,plan,*,notify):
        w=self.world
        record={'id':'spatial:'+str(next(self.ids)),'time_ms':w.time,'source':plan.source,'purpose':plan.purpose,
            'bodies':[{'actor':b.actor,'life_generation':b.generation,'reference_before_m':b.before_reference,
                'reference_after_m':b.reference,'velocity_before_mps':b.before_velocity,
                'velocity_after_mps':b.velocity,'support_id':b.support[0] if b.support else None} for b in plan.bodies]}
        if self.enabled:self.records.append(deepcopy(record));w.log('spatial_transition_committed',**deepcopy(record))
        if notify:
            w.healing.invalidate()
            for body in plan.bodies:w.thermal_recovery.invalidate(body.actor)
            w.refresh_mobile_locomotion();w.cooldown_system.settle();w.effect_system.settle()
            w.collider_system.dirty=True
            contact=w.next_mobile_contacts(w.time)
            if contact is not None:w.push(w.time,'movement_contact',w.mobile_contact_payload(contact[1]),priority=2)
            for actor in w.fighters.values():
                if actor.hp>0:w.request_decision(actor.id,w.time)
        return deepcopy(record)

    def apply(self,changes,*,source):
        return self.commit(self.prepare(changes,source=source))

    def prepare_projection(self,actors,equalities=(),blocked=(),*,source,taut=(),contacts=()):
        if not self.enabled:raise UnsupportedMechanicError('Atomic spatial updates are not enabled')
        with localcontext(Context(prec=self.world.precision)):
            nodes=[]
            if not isinstance(actors,dict) or not actors:raise ValueError('Projection needs actor-to-life identities')
            actors=dict(actors);equalities=tuple(equalities);taut=tuple(taut);contacts=tuple(contacts)
            for group in self.world.grapple_links.groups():
                if any(name in actors for name in group):
                    for name in group:actors.setdefault(name,self.world.fighters[name].life_generation)
                    equalities+=tuple(VelocityEquality(group[0],name) for name in group[1:])
            for name,generation in sorted(actors.items()):
                if name not in self.world.fighters:raise ValueError('Unknown projected actor')
                a=self.world.fighters[name]
                if a.life_generation!=life_generation(generation) or a.hp<=0:raise StaleSpatialPlan('Projection needs current living actors')
                nodes.append(VelocityNode(name,self.world.mobile_motion(name)[0],a.profile['max_hp'],a.armor))
            projection=(project_unilateral(nodes,taut=taut,contacts=contacts,equalities=equalities,blocked=blocked,
                precision=self.world.precision) if taut or contacts else
                project_velocities(nodes,equalities,blocked,precision=self.world.precision))
            plan=self.prepare(tuple(SpatialChange(name,actors[name],velocity_mps=value) for name,value in projection.velocities),source=source)
            return projection,plan

    def project(self,actors,equalities=(),blocked=(),*,source,taut=(),contacts=()):
        projection,plan=self.prepare_projection(actors,equalities,blocked,source=source,taut=taut,contacts=contacts)
        return projection,self.commit(plan)

    def release_support(self,actor,reason,*,velocity=None):
        support=self.world.collider_system.find_support(actor);m=self.world.motion[actor.id]
        if support is not None:m['support_id'],m['support_part']=support;return False
        plan=self._prepare((SpatialChange(actor.id,actor.life_generation,velocity_mps=velocity),),source='support:'+reason,purpose='support_loss')
        velocity=plan.bodies[0].velocity
        self.commit(plan,notify=False)
        self.world.log('world_support_lost',actor=actor.id,reason=reason,velocity_mps=velocity,
            jump_payment=False,basic_jump_landing_effects=False)
        return True

    def restoration_plan(self,actor,source):
        return self._prepare((SpatialChange(actor.id,actor.life_generation,velocity_mps=(0,0,0)),),
            source=source,purpose='restoration')

    def result(self):
        if not self.enabled:return {}
        return {'spatial_transition_rules':self.world.combat_locomotion_input['spatial_transitions'],
            'spatial_transitions':deepcopy(self.records),
            **({'spatial_interventions':deepcopy(list(self.interventions.values()))} if self.interventions else {})}
