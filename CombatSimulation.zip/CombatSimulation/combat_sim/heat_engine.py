"""One controlled k=2 beam with live interval defenses and exact root HP."""

from fractions import Fraction
from typing import Any

from combat_sim.actions import ScriptedActionSequence
from combat_sim.encounters import initial_states
from combat_sim.events import EventLog
from combat_sim.exact import ExactAmount, number_record
from combat_sim.mechanics import heat
from combat_sim.mechanics.status import decay_status
from combat_sim.mechanics.timing import impact_time_from_activation
from combat_sim.models import UnsupportedMechanicError, as_fraction, fraction_record
from combat_sim.state_updates import _state_snapshot, _time_value, _validate_shield_state
from combat_sim.status_events import _advance_statuses


def _ms(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a nonnegative integer millisecond")
    return value


def _is_nonlethal(hp, total):
    """Compare rational HP to this one-beam radical damage without rounding."""
    rational = total.as_fraction()
    if rational is not None:
        return hp > rational
    if total.rational != 0 or len(total.roots) != 1 or total.roots[0].coefficient < 0:
        raise UnsupportedMechanicError("This nonlethal precheck supports one beam with constant starting defenses")
    root = total.roots[0]
    return hp > 0 and hp**2 > root.coefficient**2 * root.radicand


def _advance_heat(states, profiles, recipients, ability, start, end, beam_start, beam_end, heat_end, log):
    """Integrate before processing the event at end; changes then affect future intervals."""
    if end <= start or start < beam_start or start >= heat_end:
        return
    duration = Fraction(ability["beam_duration_ms"], 1000)
    k = as_fraction(ability["k"])
    if end <= beam_end:
        phase = "exposure"
        q0, q1 = (start - beam_start) / 1000, (end - beam_start) / 1000
        th0, th1, to0, to1 = q0, q1, Fraction(0), Fraction(0)
    elif start >= beam_end and end <= heat_end:
        phase = "residual_heat"
        to0, to1 = (start - beam_end) / 1000, (end - beam_end) / 1000
        th0 = th1 = duration
        q0, q1 = duration - k * to0, duration - k * to1
    else:
        raise ValueError("Heat intervals must split at beam and residual-heat boundaries")
    for name in sorted(recipients):
        state = states[name]
        armor = state.armor
        resistance = as_fraction(profiles[name]["resistances"]["heat"])
        coefficient = heat.heat_coefficient(ability["heat_output"], armor, resistance, k)
        damage = heat.heat_damage_between(ability["heat_output"], armor, resistance, q0, q1, (end - start) / 1000, k)
        hp_before = state.hp
        state.hp = ExactAmount.of(state.hp) - damage
        log.record({
            "time_ms": _time_value(end), "type": "continuous_damage_resolved", "target": name,
            "interval_start_ms": _time_value(start), "interval_end_ms": _time_value(end),
            "damage_payment": "Exact continuous analytic integral; interval accounting is not a damage tick",
            "nominal_hp_damage": number_record(damage), "applied_hp_damage": number_record(damage),
            "components": {"heat": {
                "amount": number_record(damage), "phase": phase, "formula": heat.FORMULA,
                "inputs": {"ho": str(ability["heat_output"]), "a_current": str(armor), "Rh_current": str(resistance), "k": str(k),
                           "th_start_seconds": str(th0), "th_end_seconds": str(th1),
                           "to2_start_seconds": str(to0), "to2_end_seconds": str(to1)},
                "coefficient": fraction_record(coefficient), "root_input_start": str(q0), "root_input_end": str(q1),
                "integral": "C * integral(sqrt(q(t))) dt, exact for linear q and interval-constant current defenses",
                "defense_sampling": "Current armor and heat resistance at interval start; split on changes",
                "source": heat.SOURCE,
            }},
            "state_changes": {"target": name, "hp_before": number_record(hp_before), "hp_after_impact": number_record(state.hp),
                              "armor_before": fraction_record(armor), "armor_after_impact": fraction_record(state.armor),
                              "shield_before": fraction_record(state.shield), "shield_after_impact": fraction_record(state.shield)},
        })


def run_heat_scenario(scenario: dict[str, Any], profiles: dict[str, Any]) -> dict[str, Any]:
    if set(scenario) - {"id", "description", "encounter", "action_sequence", "run_until_ms"}:
        raise UnsupportedMechanicError("Unsupported heat scenario fields")
    encounter = scenario.get("encounter", {})
    if set(encounter) - {"initial_states", "movement"} or encounter.get("movement") != "stationary":
        raise UnsupportedMechanicError("Controlled heat requires stationary movement and initial states only")
    inputs = ScriptedActionSequence(scenario.get("action_sequence", [])).inputs()
    if len(inputs) != 1:
        raise UnsupportedMechanicError("Controlled heat requires one activation")
    action = inputs[0]
    if set(action) - {"kind", "action_start_ms", "actor", "ability", "targets", "exposure_confirmed"}:
        raise UnsupportedMechanicError("Unsupported heat action fields")
    if action.get("kind") != "activation" or action.get("exposure_confirmed") is not True:
        raise UnsupportedMechanicError("The scenario must confirm recipients remain exposed for the full beam duration")
    actor, ability_id = action.get("actor"), action.get("ability")
    recipients = action.get("targets")
    if not isinstance(recipients, list) or any(not isinstance(name, str) for name in recipients) or len(set(recipients)) != len(recipients):
        raise ValueError("targets must explicitly list unique heat recipients, or []")
    states = initial_states(encounter, track_statuses=True)
    if set(states) != {actor, *recipients}:
        raise UnsupportedMechanicError("Initial states must contain the actor and exactly the supplied heat recipients")
    for name, state in states.items():
        profile = profiles.get(name, {})
        if any(key not in profile for key in ("max_hp", "shield_capacity")) or "heat" not in profile.get("resistances", {}):
            raise UnsupportedMechanicError(f"{name} requires complete defender data including heat resistance")
        _validate_shield_state(state, as_fraction(profile["shield_capacity"]), name)
    if states[actor].statuses.instability != 0:
        raise UnsupportedMechanicError("This controlled beam requires zero initial caster instability; interruption rules are outside this stage")
    for name in recipients:
        if states[name].shield != 0:
            raise UnsupportedMechanicError("Shielded heat/exposure and continuous shield interactions are not specified; heat recipients must be unshielded")
    ability = profiles[actor]["abilities"][ability_id]
    if ability.get("damage_type") != "heat" or ability.get("armor_loss") != "none" or ability.get("status_effects") != "none" or ability.get("damage_payment") != "continuous" or ability.get("defense_sampling") != "current_armor_and_heat_resistance":
        raise UnsupportedMechanicError("Unsupported heat rules; this model uses continuous heat, current defenses, and no armor loss or added statuses")
    start = _ms(action.get("action_start_ms"), "action_start_ms")
    profile = profiles[actor]["timing_profiles"][ability["timing_profile"]]
    if profile.get("impact_timing") not in {"start_of_active", "middle_of_active", "end_of_active"}:
        raise UnsupportedMechanicError("Heat requires an explicitly defined Active-phase effect anchor")
    beam_start, timing = impact_time_from_activation(start, profile, disorientation_at_gathering_start=decay_status(states[actor].statuses.disorientation, start))
    timing["effect_start_ms"] = timing.pop("impact_time_ms")
    timing["effect_start_offset_ms"] = timing.pop("impact_offset_ms")
    timing["effect_start_anchor"] = timing.pop("impact_timing")
    beam_duration = _ms(ability["beam_duration_ms"], "beam_duration_ms")
    if beam_duration == 0:
        raise ValueError("Beam duration must be positive")
    # Validate k even when the explicit recipient list is empty.
    heat.heat_coefficient(ability["heat_output"], 0, 0, ability["k"])
    beam_start = Fraction(beam_start)
    beam_end = beam_start + beam_duration
    heat_end = beam_end + Fraction(beam_duration) / as_fraction(ability["k"])
    active_end = Fraction(timing["active_end_ms"])
    final_boundary = max(heat_end, active_end)
    until = Fraction(_ms(scenario["run_until_ms"], "run_until_ms")) if "run_until_ms" in scenario else final_boundary
    if until < final_boundary:
        raise ValueError("run_until_ms must include the complete beam, residual heat, and Active phase")
    for name in recipients:
        profile = profiles[name]
        total = heat.full_exposure_and_recovery_damage(ability["heat_output"], states[name].armor, profile["resistances"]["heat"], Fraction(beam_duration, 1000), ability["k"])
        if not _is_nonlethal(states[name].hp, total):
            raise UnsupportedMechanicError("This controlled heat model requires nonlethal initial conditions; death during continuous damage is not specified")
    initial = _state_snapshot(states)
    queue = [(Fraction(start), 0, "ability_started"), (beam_start, 1, "beam_started"),
             (active_end, 2, "active_completed"), (beam_end, 3, "beam_ended"), (heat_end, 4, "heat_expired")]
    current, log = Fraction(0), EventLog()
    for time, _, event in sorted(queue):
        _advance_heat(states, profiles, recipients, ability, current, time, beam_start, beam_end, heat_end, log)
        _advance_statuses(states, current, time, log)
        current = time
        entry = {"time_ms": _time_value(time), "type": event, "actor": actor, "ability": ability_id}
        if event == "ability_started":
            entry.update(timing_calculation=timing, availability="Activation supplied by scenario; costs/cooldown/Recovery eligibility not executed")
        elif event == "beam_started":
            entry.update(targets=sorted(recipients), radius_m=ability["radius_m"], heat_output=ability["heat_output"], k=ability["k"],
                         beam_ends_at_ms=_time_value(beam_end), residual_heat_ends_at_ms=_time_value(heat_end),
                         exposure_confirmation="Supplied by scenario; no automatic spatial hit testing", source=ability["source"])
        elif event == "active_completed":
            entry["actor_state"] = states[actor].to_record()
        log.record(entry)
    _advance_statuses(states, current, until, log)
    return {
        "scenario_id": scenario.get("id", "unnamed"), "execution_model": "heat_beam",
        "initial_states": initial, "encounter_configuration": {"movement": "stationary"}, "inputs": inputs,
        "run_until_ms": _time_value(until), "events": log.records(), "final_states": _state_snapshot(states),
        "active_continuous_effects_final": [], "pending_shield_regeneration": [],
        "outcome": "One controlled beam and its residual heat completed",
        "assumptions_and_limits": [
            "One stationary scenario-authorized k=2 beam; explicit recipients stay exposed for its full lifetime. No other actions, overlapping beams, movement, re-entry, or automatic radius detection.",
            "Beam starts at the documented Active anchor; 1E1 ability 4 starts at 180 ms, ends at 3180 ms, and residual heat ends at 4680 ms from an unmodified activation.",
            "Heat leaves armor unchanged and adds no self/target disorientation or instability, confirmed by the author. Existing statuses decay and current actor disorientation modifies Gathering.",
            "Heat uses current armor and heat resistance for each interval. A state-changing event must split the interval, then subsequent damage uses new defenses; existing venom snapshots are not reused.",
            "Damage integrates continuously and exactly; irrational roots remain symbolic. Decimal approximations are 50-digit display values only. Continuous expiry times may be exact fractional milliseconds.",
            "The nonlethal precheck assumes the constant defenses in this public single-action scenario. Synthetic regression instrumentation tests later defense changes without adding mixed-action support.",
            "Shielded exposure, caster instability/interrupts, death/revival, time-varying eligibility, cooldown/dyspnea costs, Recovery, and autonomous decisions remain outside this stage.",
        ],
    }
