"""Released finite knock impulses and temporary elasticity on shared bodies.

Impulses compose additively and retain individual clocks/lives. Static geometry,
gravity, collision penalties and the persistent grapple constraint remain owned
by their existing coordinators; this module supplies no second trajectory loop.
"""
from copy import deepcopy
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.knockback import KnockbackBody,resist_knockback,knock_direction
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality,project_velocities
from combat_sim.models import UnsupportedMechanicError
from combat_sim.spatial_transitions import SpatialChange
from combat_sim.spatial_motion import CONTACT_SPEED_EPS_MPS as SPEED
from combat_sim.mechanics.body_launch import upward_knock_speed


class KnockMotion:
    def __init__(self,world):
        self.world=world;self.ids=count(1);self.pending={};self.impulses={};self.applying=False
        self.contact_frames={}
        self.contact_inelastic=set();self.last_contacts={}
        timing=(getattr(world,'combat_locomotion_input',None) or {}).get('knock_group_timing')
        if timing is not None and (timing!={'mode':'at_impact_v1'} or not world.grapple_links.enabled or not world.life_cycles.enabled):
            raise UnsupportedMechanicError('Impact group timing requires current living grapple rules')
        self.at_impact=timing is not None

    def validate_knock(self,k):
        if (k.get('direction')!='knock_up' or k.get('trajectory')!='ballistic_height' or
                k.get('horizontal_response')!='remove_approach' or k.get('vertical')!='add' or
                dec(k.get('distance_m',0))<=0 or dec(k.get('elasticity',-1))!=0):
            raise UnsupportedMechanicError('Up-counter needs resisted ballistic height and an explicit approach response')

    def validate(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id];k=a.get('knock',{})
        if not (w.spatial_transitions.enabled and w.airborne_enabled and w.melee.enabled and w.effort_system.enabled):
            raise UnsupportedMechanicError('Knock melee requires shared living bodies, contacts, effort and atomic motion')
        cfg=w.ownership_definition['actions'].get('knock_melee') if w.ownership_definition else None
        if cfg!={'occupies':['hands','weapon'],'requires':['upper_body','attack']}:
            raise UnsupportedMechanicError('Knock melee needs explicit upper-body hand/weapon ownership')
        g=a.get('melee_geometry',{})
        if (a.get('direct_damage_type')!='blunt' or a.get('cooldown_anchor')!='active_start' or
                a.get('self_effects',{}).get('application_timing')!='impact' or
                a.get('dyspnea',{}).get('payment_timing')!='active_start' or
                g.get('mode')!='hand_capsule_at_impact' or g.get('aim')!='torso_location_at_active_start' or
                g.get('blocking')!='body_solids' or g.get('origin_hand') not in a['hand_positions_m']['start'] or
                k.get('direction')!='knock_away' or k.get('vertical')!='retain' or
                w.fighters[actor.id].profile['timing_profiles'][a['timing_profile']]['impact_timing']!='middle_of_active'):
            raise UnsupportedMechanicError('Unsupported knock contact, force or phase rule')
        if any(dec(v)<=0 for v in (k['distance_m'],k['duration_ms'],g['reach_m'],g['radius_m'],a['cooldown_ms'])):
            raise ValueError('Knock timing, range, contact geometry and cooldown must be positive')
        if not 0<=dec(k['elasticity'])<=1:raise ValueError('Elasticity must lie between zero and one')

    def snapshot(self):
        defenses={n:(a.life_generation,a.profile['max_hp'],a.armor) for n,a in self.world.fighters.items()}
        if not self.at_impact:return defenses
        return dict(defenses=defenses,groups={n:self.world.grapple_links.group(n) for n in self.world.fighters})

    def queue(self,packet,calculation,snapshot):
        w=self.world;a=w.attack_definition(packet['actor'],packet['ability'],packet.get('melee_component'))
        if 'knock' not in a:return
        identity='knock:'+str(next(self.ids))
        target=packet['target'];delta=tuple(dec(x)-dec(y) for x,y in zip(
            w.fighters[target].position_m,w.fighters[packet['actor']].position_m))
        if not any(delta):
            from combat_sim.facing import forward
            delta=forward(w.fighters[packet['actor']].facing)[:2]
        row={'id':identity,**{key:packet[key] for key in ('actor','ability','action_id','attack_id',
            'source_life_generation','target','target_life_generation')},'queued_at_ms':w.time,'status':'queued',
            'direction':knock_direction(a['knock']['direction'],(*delta,0),precision=w.precision),
            'physical_power':dec(calculation.incoming_damage),
            'defenses':deepcopy(snapshot['defenses'] if self.at_impact else snapshot),'definition':deepcopy(a['knock'])}
        if self.at_impact:row['group_at_impact']=tuple(snapshot['groups'][target])
        self.pending[identity]=row
        if not self.at_impact:w.push(w.time,'knock_impact',{'knock_id':identity},priority=3)
        if a['knock'].get('trajectory')=='ballistic_height':
            row['approach_normal']=knock_direction('knock_away',(*delta,0),precision=w.precision)

    def flush_impacts(self):
        """All HP/status calculations finish before force; fatigue follows force.

        This preserves a committed pair through the very hit that exhausts its
        controller. New attachments then see the already released velocities.
        Multiple impulses still add to the current physical velocity.
        """
        if not self.at_impact:return
        for row in tuple(self.pending.values()):
            if row['status']=='queued' and row['queued_at_ms']==self.world.time:
                self.process('knock_impact',{'knock_id':row['id']})

    def event_live(self,kind,payload):
        row=(self.pending if kind=='knock_impact' else self.impulses).get(payload.get('knock_id'))
        return row is not None and row['status']==('queued' if kind=='knock_impact' else 'active')

    def members(self,name):
        life=self.world.fighters[name].life_generation
        return [(row,row['components'][name]) for row in self.impulses.values() if row['status']=='active'
            and name in row['components'] and row['components'][name]['life_generation']==life]

    def elasticity(self,name):
        if name in self.contact_inelastic:return D(0)
        group=self.world.grapple_links.group(name)
        return max((dec(row['elasticity']) for n in group for row,_ in self.members(n)),default=D(0))

    def stabilize_repeats(self,contacts):
        """Absorb a rapid repeated contact instead of an elastic collapse.

        Keep collision/status/pose handling and finite impulse lifetimes. This
        selected numerical contact band never skips time or moves a body.
        """
        w=self.world;inelastic=set()
        for c in contacts:
            if c.get('pose_only'):continue
            a,b=c['first'],c['second']
            key=tuple(sorted((('body',a,w.fighters[a].life_generation),
                ('body',b,w.fighters[b].life_generation) if b in w.fighters else
                ('collider',b,w.collider_system.registry.objects[b].collision_revision))))
            previous=self.last_contacts.get(key);self.last_contacts[key]=w.time
            if previous is None or w.time-previous>=w.contact_repeat_ms:continue
            for name in (a,b):
                if name in w.fighters:inelastic.update(w.grapple_links.group(name))
            w.log('body_contact_stabilized',first=a,second=b,previous_contact_ms=previous,
                rapid_repeat_ms=w.contact_repeat_ms,rule='absorb_repeated_normal_motion')
        return inelastic

    def rebound_frames(self,contacts):
        """One pre-response frame per contacting body/joint component.

        Static material fixes that frame at zero. Otherwise use the existing
        HP/armor projection weights. Reflecting a body against world zero
        while its collision partner also travels can make them chase and
        reflect repeatedly in a shrinking gap. Their common frame prevents it.
        Zero elasticity retains the author's removal of each own component.
        """
        w=self.world;graph={};fixed=set()
        def join(names):
            names=tuple(names)
            for n in names:graph.setdefault(n,set()).update(set(names)-{n})
        for c in contacts:
            if c.get('pose_only'):continue
            a,b=c['first'],c['second'];join(w.grapple_links.group(a))
            if b in w.fighters:
                join(w.grapple_links.group(b));join((a,b))
            else:fixed.add(a)
        result={};pending=set(graph)
        while pending:
            todo=[min(pending)];group=set()
            while todo:
                n=todo.pop()
                if n not in group:group.add(n);todo.extend(graph[n]-group)
            pending-=group;group=tuple(sorted(group))
            if fixed.intersection(group):frame=(D(0),)*3
            else:
                nodes=tuple(VelocityNode(n,w.mobile_motion(n)[0],w.fighters[n].profile['max_hp'],w.fighters[n].armor) for n in group)
                frame=dict(project_velocities(nodes,tuple(VelocityEquality(group[0],n) for n in group[1:]),precision=w.precision).velocities)[group[0]]
            result.update((n,frame) for n in group)
        return result

    def elastic_response(self,name,before,projected,*,basis=()):
        e=self.elasticity(name)
        if not e:return projected
        frame=self.contact_frames.get(name,(D(0),)*3)
        normal_frame=[D(0)]*3
        for n in basis:
            dot=sum(x*y for x,y in zip(frame,n))
            normal_frame=[x+dot*y for x,y in zip(normal_frame,n)]
        return tuple(y-e*(x-y)+2*e*f for x,y,f in zip(before,projected,normal_frame))

    def transport_components(self,name,basis):
        e=self.elasticity(name)
        for row,component in self.members(name):
            velocity=component['velocity_mps']
            for normal in basis:
                dot=sum(v*n for v,n in zip(velocity,normal))
                velocity=tuple(v-(1+e)*dot*n for v,n in zip(velocity,normal))
            component['velocity_mps']=velocity

    def _apply(self,changes,source):
        self.applying=True
        try:
            plan=self.world.spatial_transitions.prepare(tuple(changes),source=source)
            return self.world.spatial_transitions.commit(plan)
        finally:self.applying=False

    def _rebase_group(self,group):
        # A newly imposed common velocity includes old impulses' weighted
        # components. Rebase each separately so its later expiry removes exactly
        # its shared contribution, including members which joined afterward.
        if len(group)<2:return
        w=self.world
        for row in self.impulses.values():
            if row['status']!='active' or not any(n in row['components'] for n in group):continue
            nodes=tuple(VelocityNode(n,row['components'].get(n,{}).get('velocity_mps',(0,0,0)),
                w.fighters[n].profile['max_hp'],w.fighters[n].armor) for n in group)
            edges=tuple(VelocityEquality(group[0],n) for n in group[1:])
            v=dict(project_velocities(nodes,edges,precision=w.precision).velocities)[group[0]]
            for n in group:
                row['components'][n]={'life_generation':w.fighters[n].life_generation,'velocity_mps':v}
                self._restrict(n,row)

    def _restrict(self,name,row):
        if row['expiry_ms'] is None:return
        self.world.apply_action_restriction(name,source=row['id'],functions=['lower_body'],until_ms=row['expiry_ms'],wake=False)

    def process(self,kind,payload):
        if not self.event_live(kind,payload):return
        if kind=='knock_motion_ended':return self.end(payload['knock_id'])
        w=self.world;p=self.pending[payload['knock_id']];p['status']='processed'
        target=w.fighters[p['target']]
        reason=('target_life_ended' if target.hp<=0 or target.life_generation!=p['target_life_generation'] else
            'blocked_or_zero_power' if p['physical_power']<=0 else None)
        if reason:
            p['outcome']=reason;w.log('knock_skipped',knock_id=p['id'],target=target.id,reason=reason);return
        group=(tuple(n for n in p['group_at_impact'] if w.fighters[n].hp>0 and
            w.fighters[n].life_generation==p['defenses'][n][0]) if self.at_impact else w.grapple_links.group(target.id))
        bodies=[]
        for n in group:
            a=w.fighters[n];old=p['defenses'][n]
            hp,armor=old[1:] if old[0]==a.life_generation else (a.profile['max_hp'],a.armor)
            bodies.append(KnockbackBody(n,hp,armor))
        assessment=resist_knockback(p['definition']['distance_m'],bodies,precision=w.precision)
        ballistic=p['definition'].get('trajectory')=='ballistic_height'
        duration=None if ballistic else dec(p['definition']['duration_ms'])
        delta=((D(0),D(0),upward_knock_speed(assessment.resisted_m,w.jump_gravity,precision=w.precision)) if ballistic else
            tuple(v*assessment.resisted_m/(duration/1000) for v in p['direction']))
        if not any(delta):
            p['outcome']='fully_resisted';w.log('knock_skipped',knock_id=p['id'],target=target.id,reason=p['outcome']);return
        before=w.mobile_motion(target.id)[0];base=before
        approach=sum(v*n for v,n in zip(before,p['approach_normal'])) if ballistic else D(0)
        if approach<0:base=tuple(v-approach*n for v,n in zip(before,p['approach_normal']))
        velocity=tuple(x+y for x,y in zip(base,delta))
        # Preflight the full group before changing an old impulse's bookkeeping.
        changes=tuple(SpatialChange(n,w.fighters[n].life_generation,velocity_mps=velocity) for n in group)
        plan=w.spatial_transitions.prepare(changes,source=p['id'])
        self.applying=True
        try:w.spatial_transitions.commit(plan)
        finally:self.applying=False
        self._rebase_group(group)
        if approach<0:
            for n in group:
                for _,component in self.members(n):
                    v=component['velocity_mps'];dot=sum(x*y for x,y in zip(v,p['approach_normal']))
                    component['velocity_mps']=tuple(x-dot*y for x,y in zip(v,p['approach_normal']))
        row={key:deepcopy(p[key]) for key in ('id','actor','ability','action_id','attack_id','source_life_generation',
            'target','target_life_generation','direction')}
        assessed=assessment.record()
        for key in ('nominal_m','maximum_hp_sum','armor_sum'):assessed[key]=dec(assessed[key])
        row.update(status='active',started_at_ms=w.time,expiry_ms=None if ballistic else w.time+duration,elasticity=dec(p['definition']['elasticity']),
            assessment=assessed,initial_velocity_delta_mps=delta,
            components={n:{'life_generation':w.fighters[n].life_generation,'velocity_mps':delta} for n in group})
        self.impulses[row['id']]=row;p['outcome']='applied'
        if ballistic:row.update(trajectory='ballistic_height',removed_approach_speed_mps=-min(D(0),approach))
        else:w.push(row['expiry_ms'],'knock_motion_ended',{'knock_id':row['id']},priority=0)
        for n in group:self._restrict(n,row)
        w.log('knock_applied',**deepcopy(row));w.refresh_mobile_locomotion()

    def _remove(self,name,row,reason):
        component=row['components'].pop(name,None)
        if component is None:return
        w=self.world;a=w.fighters[name]
        if a.action_registry is not None:a.action_registry.remove_block(row['id'])
        w.restriction_clocks.pop((name,row['id']),None)
        row.setdefault('retired_components',[]).append({'actor':name,**component,'ended_at_ms':w.time,'reason':reason})
        if not row['components']:row.update(status='ended',ended_at_ms=w.time,end_reason=reason)

    def end(self,identity):
        w=self.world;row=self.impulses[identity]
        changes=[]
        # Aggregate removal across a current grapple component. Its physical
        # input may have become shared since this impulse was first applied.
        groups={w.grapple_links.group(n) for n in row['components']}
        for group in sorted(groups):
            nodes=tuple(VelocityNode(n,row['components'].get(n,{}).get('velocity_mps',(0,0,0)),
                w.fighters[n].profile['max_hp'],w.fighters[n].armor) for n in group)
            edges=tuple(VelocityEquality(group[0],n) for n in group[1:])
            delta=dict(project_velocities(nodes,edges,precision=w.precision).velocities)[group[0]]
            before=w.mobile_motion(group[0])[0]
            # A projected/reflected component can differ from the saved
            # physical total by Decimal roundoff. Do not retain that cancelled
            # impulse as perpetual imposed movement after its expiry.
            velocity=tuple(D(0) if abs(x-y)<=SPEED else x-y for x,y in zip(before,delta))
            if all(not w._airborne(n) for n in group):velocity=(*velocity[:2],max(D(0),velocity[2]))
            changes.extend(SpatialChange(n,w.fighters[n].life_generation,velocity_mps=velocity) for n in group if w.fighters[n].hp>0)
        if changes:self._apply(changes,identity+':expired')
        for group in sorted(groups):self._rebase_group(group)
        for n in tuple(row['components']):self._remove(n,row,'duration_expired')
        w.log('knock_ended',knock_id=identity,reason='duration_expired')
        for a in w.fighters.values():
            if a.hp>0:w.request_decision(a.id,w.time)

    def external_changed(self,bodies):
        if self.applying:return
        for body in bodies:
            if not any(abs(x-y)>SPEED for x,y in zip(body.velocity,body.before_velocity)):continue
            for row,_ in tuple(self.members(body.actor)):self._remove(body.actor,row,'external_motion_replaced')

    def retire_life(self,actor):
        for row,_ in tuple(self.members(actor.id)):self._remove(actor.id,row,'participant_died')

    def settle_ballistic(self):
        w=self.world
        for row in self.impulses.values():
            if row['status']!='active' or row.get('trajectory')!='ballistic_height':continue
            for name in tuple(row['components']):
                if not w._airborne(name) and w.collider_system.find_support(w.fighters[name]) is not None:
                    self._remove(name,row,'landed')

    def result(self):
        if not self.pending:return {}
        return {'knock_impulses':deepcopy(list(self.impulses.values())),
            'knock_deliveries':[{k:deepcopy(v) for k,v in row.items() if k not in ('defenses','definition')}
                for row in self.pending.values()]}
