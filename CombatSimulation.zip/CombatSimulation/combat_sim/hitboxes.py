"""Exact cuboid geometry, independent of damage and targeting rules.

Confirmed sizes and standing placement live in body_hitboxes.json.
Combat hit detection supplies its separate attack/area rules. These helpers
describe closed axis-aligned solids in an explicitly supplied coordinate frame;
they do not choose battlefield facing, aim, projectile radius, or headshot rules.
"""
from dataclasses import dataclass
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from fractions import Fraction

from combat_sim.models import as_fraction
from combat_sim.orientation import YawFrame


def _vector3(values):
    if len(values) != 3:
        raise ValueError('Cuboid geometry requires three coordinates')
    return tuple(as_fraction(value) for value in values)


def _decimal(value):
    value = as_fraction(value)
    return Decimal(value.numerator)/Decimal(value.denominator)


def _distance_squared(point, low, high):
    return sum((max(a-p,p-b,Fraction(0))**2 for p,a,b in zip(point,low,high)),Fraction(0))


@dataclass(frozen=True)
class SphereContact:
    part: str
    parameter: Decimal
    centre_m: tuple
    closest_box_point_m: tuple


@dataclass(frozen=True)
class Cuboid:
    part: str
    centre_m: tuple
    size_m: tuple

    def __post_init__(self):
        centre, size = _vector3(self.centre_m), _vector3(self.size_m)
        if not self.part or any(length <= 0 for length in size):
            raise ValueError('A cuboid needs a part name and positive side lengths')
        object.__setattr__(self, 'centre_m', centre)
        object.__setattr__(self, 'size_m', size)

    @property
    def bounds(self):
        return (tuple(c-s/2 for c, s in zip(self.centre_m, self.size_m)),
                tuple(c+s/2 for c, s in zip(self.centre_m, self.size_m)))

    def contains(self, point):
        low, high = self.bounds
        return all(a <= p <= b for p, a, b in zip(_vector3(point), low, high))

    def intersects_sphere(self, centre_m, radius_m):
        """Closed sphere/cuboid overlap using exact nearest-point distance."""
        centre, radius = _vector3(centre_m), as_fraction(radius_m)
        if radius < 0:
            raise ValueError('Sphere radius must be nonnegative')
        low, high = self.bounds
        distance_squared = _distance_squared(centre,low,high)
        return distance_squared <= radius**2

    def intersects_vertical_column(self, centre_xy_m, radius_m):
        """Overlap with a closed vertical cylinder having no height limits.

        This is the geometric column test. A finite-height beam would also need
        explicit height bounds; none are inferred here.
        """
        if len(centre_xy_m) != 2:
            raise ValueError('A vertical column centre requires two coordinates')
        centre = tuple(as_fraction(value) for value in centre_xy_m)
        radius = as_fraction(radius_m)
        if radius < 0:
            raise ValueError('Column radius must be nonnegative')
        low, high = self.bounds
        distance_squared = sum((max(a-p, p-b, Fraction(0))**2
                                for p,a,b in zip(centre,low[:2],high[:2])), Fraction(0))
        return distance_squared <= radius**2

    def segment_interval(self, start, end):
        """Return exact entry/exit parameters in [0,1], or None for a miss.

        This is geometric intersection with the closed solid. It does not decide
        a combat hit when a segment touches a shared body-part boundary.
        """
        start, end = _vector3(start), _vector3(end)
        lower, upper = self.bounds
        enter, leave = Fraction(0), Fraction(1)
        for a, b, low, high in zip(start, end, lower, upper):
            direction = b-a
            if direction == 0:
                if a < low or a > high:
                    return None
                continue
            first, last = sorted(((low-a)/direction, (high-a)/direction))
            enter, leave = max(enter, first), min(leave, last)
            if enter > leave:
                return None
        return enter, leave

    def swept_sphere_contact(self, start, end, radius_m, *, precision=50):
        """First contact of a sphere moving along a straight segment.

        Exact rational face crossings partition squared point-to-box distance
        into quadratics. The first admissible root is evaluated at fixed
        Decimal precision. This preserves rounded corner geometry, unlike
        simply expanding the cuboid by the sphere radius on every axis.
        """
        if not isinstance(precision,int) or precision < 40:
            raise ValueError('Swept-sphere precision must be at least 40 digits')
        start,end = _vector3(start),_vector3(end)
        radius = as_fraction(radius_m)
        if radius < 0:
            raise ValueError('Projectile radius must be nonnegative')
        low,high = self.bounds
        direction = tuple(b-a for a,b in zip(start,end))

        def contact(parameter):
            centre = tuple(_decimal(a)+parameter*_decimal(d) for a,d in zip(start,direction))
            closest = tuple(min(_decimal(b),max(_decimal(a),p)) for p,a,b in zip(centre,low,high))
            return SphereContact(self.part,parameter,centre,closest)

        with localcontext(Context(prec=precision,rounding=ROUND_HALF_EVEN)):
            if _distance_squared(start,low,high) <= radius**2:
                return contact(Decimal(0))
            cuts = {Fraction(0),Fraction(1)}
            for a,d,lower,upper in zip(start,direction,low,high):
                if d:
                    for face in (lower,upper):
                        t = (face-a)/d
                        if 0 < t < 1:
                            cuts.add(t)
            ordered = sorted(cuts)
            for a,b in zip(ordered,ordered[1:]):
                mid = (a+b)/2
                aa,bb,cc = Fraction(0),Fraction(0),-radius**2
                for origin,d,lower,upper in zip(start,direction,low,high):
                    value = origin+d*mid
                    if value < lower:
                        offset = origin-lower
                    elif value > upper:
                        offset = origin-upper
                    else:
                        continue
                    aa += d*d
                    bb += 2*d*offset
                    cc += offset*offset
                fa = aa*a*a+bb*a+cc
                if fa <= 0:
                    return contact(_decimal(a))
                if aa == 0:
                    continue
                minimum_at = min(b,max(a,-bb/(2*aa)))
                if aa*minimum_at**2+bb*minimum_at+cc > 0:
                    continue
                linear = 2*aa*a+bb
                discriminant = linear**2-4*aa*fa
                root = _decimal(discriminant).sqrt()
                # Stable positive entry root relative to this interval's start.
                u = 2*_decimal(fa)/(-_decimal(linear)+root)
                parameter = min(_decimal(b),max(_decimal(a),_decimal(a)+u))
                return contact(parameter)
        return None


def standing_cuboids(definition):
    """Construct the confirmed fixed standing body in its local frame."""
    required = {'head', 'torso', 'left_arm', 'right_arm', 'left_leg', 'right_leg'}
    parts = definition['parts']
    placement = definition['standing_placement']
    if placement['status'] not in ('confirmed_by_author','scaled_from_confirmed_reference'):
        raise ValueError('Standing body placement must have confirmed source data')
    centres = placement['centres_xyz_m']
    if set(parts) != required or set(centres) != required:
        raise ValueError('The standing body needs exactly head, torso, two arms and two legs')
    if placement['orientation'] != 'cuboids_aligned_with_local_axes':
        raise ValueError('The fixed standing body requires explicitly axis-aligned cuboids')
    return tuple(Cuboid(name, centres[name], parts[name]['size_xyz_m']) for name in parts)


def world_standing_cuboids(definition, origin_m, facing):
    """Place local body parts at an explicit origin and fixed body heading.

    The local forward axis is +y. For facing +world-x, local right is -world-y;
    for facing -world-x it is +world-y. These quarter-turns are exact and retain
    axis-aligned world cuboids. No facing/ground height is inferred by default.
    """
    if isinstance(facing,YawFrame):
        from combat_sim.oriented_geometry import place_local_cuboids
        return place_local_cuboids(standing_cuboids(definition),origin_m,facing)
    boxes = []
    for box in standing_cuboids(definition):
        centre = local_to_world_point(box.centre_m,origin_m,facing)
        boxes.append(Cuboid(box.part, centre, (box.size_m[1],box.size_m[0],box.size_m[2])))
    return tuple(boxes)


def local_to_world_point(point_m, origin_m, facing):
    if isinstance(facing,YawFrame):return facing.to_world_point(point_m,origin_m)
    origin = _vector3(origin_m)
    x,y,z = _vector3(point_m)
    if facing not in ('+x','-x'):
        raise ValueError('This stationary placement supports explicit +x or -x facing')
    sign = 1 if facing == '+x' else -1
    return origin[0]+sign*y,origin[1]-sign*x,origin[2]+z


def combined_bounds(cuboids):
    boxes = tuple(cuboids)
    if not boxes:
        raise ValueError('Combined bounds require at least one cuboid')
    bounds = [box.bounds for box in boxes]
    return (tuple(min(low[axis] for low, _ in bounds) for axis in range(3)),
            tuple(max(high[axis] for _, high in bounds) for axis in range(3)))


def segment_intersections(cuboids, start, end):
    """Return all intersected parts; no gameplay priority breaks contact ties."""
    return {box.part: interval for box in cuboids
            if (interval := box.segment_interval(start, end)) is not None}
