"""Attached, independently expiring Block shields and shared rechargeable stock.

Interception boxes join projectile/melee queries, never body collision or area
membership. Released shields survive cancelled control; death freezes their
geometry and source life instead of transferring them onto a restored body.
"""
from copy import deepcopy
from dataclasses import replace
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import Cuboid, local_to_world_point
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.mechanics.charges import RechargeableCharges
from combat_sim.mechanics.defense_layers import DefenseLayer, allocate_layers
from combat_sim.mechanics.simultaneous import DamagePacket
from combat_sim.models import UnsupportedMechanicError


class Blocking:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'attached_layers_v1'} or not world.life_cycles.enabled
                or not world.effort_system.enabled):
            raise UnsupportedMechanicError('Block requires the current owned life/effect world')
        self.ids=count(1);self.layers={};self.pools={}

    def validate(self,actor,ability):
        a=actor.profile['abilities'][ability]
        if not self.enabled or a.get('block_family')!='basic_block':
            raise UnsupportedMechanicError('Unsupported Block family')
        if (a.get('charges')!=4 or dec(a.get('charge_cooldown_ms',0))!=4500 or
                a.get('dyspnea',{}).get('payment_timing')!='active_start'):
            raise UnsupportedMechanicError('Unsupported Block charges or effort payment')

    def attach(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            selected=[key for key in actor.ready if actor.profile['abilities'][key]['execution_model']=='block']
            if not selected:continue
            first=selected[0];clock=actor.cooldowns.clocks[first]
            for key in selected:del actor.cooldowns.clocks[key]
            actor.cooldowns.clocks['basic_block']=clock
            self.pools[actor.id]=RechargeableCharges(4,4500,clock=clock)
            actor.metrics.update(blocks_started=0,block_layers_summoned=0,block_damage_received=D(0))

    def held(self,actor,ability):
        return ability in self.world.choices[actor.id].get('held_blocks',[])

    def ready_at(self,actor,ability):
        time=self.pools[actor.id].ready_at(self.world.time,2 if self.held(actor,ability) else 1)
        return D('Infinity') if time is None else time

    def active_duration(self,actor,ability):
        profile=actor.profile['abilities'][ability]['timing_profile']
        return D(350) if self.held(actor,ability) else dec(actor.profile['timing_profiles'][profile]['active_ms'])

    def active_started(self,actor,action):
        self.pools[actor.id].spend(self.world.time,2 if self.held(actor,action.ability_id) else 1)
        actor.metrics['blocks_started']+=1
        self.world.cooldown_system._sync(actor)
        self.world.log('block_charges_spent',actor=actor.id,ability=action.ability_id,action_id=action.id,
            spent=2 if self.held(actor,action.ability_id) else 1,pool=self.pools[actor.id].record(self.world.time))
        self._deploy(actor,action)
        if self.held(actor,action.ability_id):
            self.world.push(self.world.time+100,'block_second_layer',
                {'actor':actor.id,'action_id':action.id,'revision':action.revision})

    def _deploy(self,actor,action):
        layer={'id':'block:'+str(next(self.ids)),'actor':actor.id,'ability':action.ability_id,
            'action_id':action.id,'source_life_generation':action.life_generation,
            'created_at_ms':self.world.time,'expires_at_ms':self.world.time+250,
            'hp':D(800),'capacity':D(800),'status':'active','frozen_box':None}
        self.layers[layer['id']]=layer;actor.metrics['block_layers_summoned']+=1
        self.world.push(layer['expires_at_ms'],'block_layer_expired',{'layer_id':layer['id']})
        self.world.log('block_layer_summoned',layer=self.record(layer))

    def active(self,layer):
        return layer['status']=='active' and layer['hp']>0 and self.world.time<layer['expires_at_ms']

    def event_live(self,kind,payload):
        if kind=='block_layer_expired':
            return self.layers[payload['layer_id']]['status']=='active'
        actor=self.world.fighters[payload['actor']];a=actor.action_by_id(payload['action_id'])
        return a is not None and a.kind=='block' and a.phase=='active' and a.revision==payload['revision']

    def process(self,kind,payload):
        if not self.event_live(kind,payload):return
        if kind=='block_second_layer':
            actor=self.world.fighters[payload['actor']]
            self._deploy(actor,actor.action_by_id(payload['action_id']))
        else:
            layer=self.layers[payload['layer_id']]
            layer['frozen_box']=self.box(layer);layer['status']='expired';layer['ended_at_ms']=self.world.time
            self.world.log('block_layer_expired',layer_id=layer['id'],actor=layer['actor'])

    def box(self,layer):
        if layer['frozen_box'] is not None:return layer['frozen_box']
        actor=self.world.fighters[layer['actor']]
        # Reference centre already lowers by half the crouch drop; the holding
        # upper body lowers by the other half. Rectangle dimensions stay fixed.
        centre=(self.world.equilibrium.block_centre(actor.id) if self.world.equilibrium.carries(actor.id) else
            local_to_world_point((0,D('.4'),-(actor.pose_drop_m or D(0))/2),actor.body_origin_m,actor.facing))
        if isinstance(actor.facing,YawFrame):return OrientedCuboid(layer['id'],centre,('.8','.02','1.75'),actor.facing)
        return Cuboid(layer['id'],centre,(D('.02'),D('.8'),D('1.75')))

    def boxes(self,name):
        return tuple(self.box(l) for l in self.layers.values() if l['actor']==name and self.active(l))

    def contact_fields(self,part):
        return {'block_layer_id':part} if part in self.layers else {}

    def kinematics(self,name,part,time):
        layer=self.layers.get(part)
        if layer is not None and layer['frozen_box'] is not None:
            return ((D(0),)*3,)*4
        velocity,acceleration=self.world.mobile_motion(name)
        offset,size_rate=self.world.pose_part_motion(name,part,time)
        return velocity,acceleration,offset,size_rate

    def contact_live(self,payload):
        layer=self.layers.get(payload.get('block_layer_id'))
        return layer is not None and layer['actor']==payload['target'] and self.active(layer)

    def retire_life(self,actor):
        if not self.enabled:return
        for layer in self.layers.values():
            if layer['actor']==actor.id and self.active(layer) and layer['frozen_box'] is None:
                layer['frozen_box']=self.box(layer)
                self.world.log('block_layer_detached',layer_id=layer['id'],actor=actor.id,
                    source_life_generation=layer['source_life_generation'],reason='holder_death')

    def resistance(self,actor):
        if not self.enabled or actor.hp<=0:return D(0)
        layers=[l for l in self.layers.values() if l['actor']==actor.id and self.active(l)
            and l['source_life_generation']==actor.life_generation and l['frozen_box'] is None]
        held={a.id for a in actor.live_actions() if a.kind=='block' and a.phase=='active'
            and self.held(actor,a.ability_id)}
        return D(100)*len(layers)+(D(400) if any(l['action_id'] in held for l in layers) else D(0))

    def route(self,name,packets,inputs):
        """Consume a complete target batch against shared pre-hit layer HP."""
        eligible={};actor=self.world.fighters[name]
        for i,p in enumerate(packets):
            if self.contact_live(p):
                generation=self.layers[p['block_layer_id']]['source_life_generation']
                eligible.setdefault(generation,[]).append(i)
        layers=[DefenseLayer(l['id'],l['hp'],tuple(eligible[l['source_life_generation']]))
            for l in self.layers.values() if l['actor']==name and self.active(l)
                and l['source_life_generation'] in eligible]
        allocation=allocate_layers((p.incoming_damage for p in inputs),layers,
            shielding_ignored=(p.shielding_ignored for p in inputs))
        signals={}
        for identity,shares in allocation.layer_shares:
            layer=self.layers[identity];loss=dec(sum(shares))
            if not loss:continue
            before=layer['hp'];layer['hp']=max(D(0),before-loss)
            if not layer['hp']:
                layer['frozen_box']=self.box(layer);layer['status']='broken';layer['ended_at_ms']=self.world.time
            actor.metrics['block_damage_received']+=loss
            self.world.log('block_layer_damage',layer_id=identity,actor=name,source_life_generation=layer['source_life_generation'],
                hp_before=before,hp_after=layer['hp'],absorbed=loss,shares=[dec(s) for s in shares])
            if self.world.reactions.enabled:
                signal=signals.setdefault(layer['source_life_generation'],{'amount':D(0),'layers':[],'incoming':set(),'depth':0})
                signal['amount']+=loss;signal['layers'].append(identity)
                for p,share in zip(packets,shares):
                    if share:
                        signal['incoming'].add(p.get('attack_id') or p.get('projectile_id') or 'action:'+str(p['action_id']))
                        signal['depth']=max(signal['depth'],p.get('reaction_depth',0))
        for generation,signal in sorted(signals.items()):
            self.world.reactions.blocked(name,generation,signal['amount'],signal['layers'],
                sorted(signal['incoming']),signal['depth'])
        result=[]
        for i,(packet,raw) in enumerate(zip(inputs,allocation.overflow)):
            p=packets[i]
            if 'block_layer_id' in p:
                p['block_absorbed']=dec(allocation.absorbed[i]);p['incoming_before_block']=dec(packet.incoming_damage)
                layer=self.layers[p['block_layer_id']]
                # An old-life detached surface remains a world obstacle, not a
                # route into the resurrected body's HP or status defenses.
                if actor.hp<=0 or layer['source_life_generation']!=actor.life_generation:raw=0
            result.append(replace(packet,incoming_damage=raw,shielding_ignored=allocation.bypass_remaining[i]))
        return result

    def record(self,layer):
        box=self.box(layer)
        return {k:deepcopy(v) for k,v in layer.items() if k!='frozen_box'}|{
            'attached':layer['frozen_box'] is None,'centre_m':tuple(map(dec,box.centre_m)),
            'size_m':tuple(map(dec,box.size_m)),
            **({'shape':'oriented_cuboid','yaw_frame':box.frame.record()} if isinstance(box,OrientedCuboid) else {})}

    def result(self):
        if not self.enabled:return {}
        return {'block_rules':self.world.combat_locomotion_input['blocking'],
            'block_layers':[self.record(l) for l in self.layers.values()],
            'block_charge_pools':{name:pool.record(self.world.time) for name,pool in sorted(self.pools.items())}}
