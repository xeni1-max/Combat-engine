"""Released, recipient-life modifiers of the existing Gathering phase.

Independent instances compose by maximum. A preparation commits the largest
modifier it has encountered; expiration cannot refund it, and repeated hits
cannot charge the same preparation again. This is not disorientation.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
from itertools import count

from combat_sim.battle_models import ceil_ms
from combat_sim.mechanics.life import life_generation
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite

EVENT = 'gathering_modifier_expired'


class TimedGathering:
    def __init__(self, world, definition=None):
        self.world = world
        self.enabled = definition is not None
        self.ids = count(1)
        self.instances, self.committed = {}, {}
        if self.enabled and (definition != {'mode': 'maximum_committed_v1'} or not world.mobile_mode):
            raise UnsupportedMechanicError('Timed Gathering requires current moving combat rules')

    def effective(self, actor):
        # Gathering phases are scheduled at whole milliseconds. Quantize the
        # effective work once, rather than rounding each stronger refresh's
        # fractional difference upward into another full millisecond.
        return ceil_ms(max((r['addition_ms'] for r in self.instances.values()
            if r['target'] == actor.id and r['target_life_generation'] == actor.life_generation
            and r['status'] == 'active' and self.world.time < r['expiry_ms']), default=D(0)))

    def commit(self, actor, action):
        """Add only previously uncommitted preparation work to an existing phase."""
        if not self.enabled:
            return action.active_due_ms
        if action.phase != 'gathering':
            raise ValueError('A Gathering modifier requires an actual Gathering phase')
        key = (actor.id, actor.life_generation, action.id)
        old = self.committed.get(key, D(0))
        effective = self.effective(actor)
        if effective > old:
            before = action.active_due_ms
            action.active_due_ms = ceil_ms(before + effective - old)
            self.committed[key] = effective
            self.world.log('gathering_modifier_committed', actor=actor.id, action_id=action.id,
                life_generation=actor.life_generation, previous_modifier_ms=old,
                committed_modifier_ms=effective, added_ms=effective-old,
                old_active_start_ms=before, new_active_start_ms=action.active_due_ms)
        return action.active_due_ms

    def create(self, packet, *, addition_ms, duration_ms):
        with localcontext(Context(prec=self.world.precision)):
            return self._create(packet, addition_ms, duration_ms)

    def _create(self, packet, addition_ms, duration_ms):
        w = self.world
        if not self.enabled or not w.life_cycles.enabled:
            raise UnsupportedMechanicError('Timed Gathering needs enabled recipient lives')
        addition = finite(addition_ms, 'Gathering addition', positive=True)
        duration = finite(duration_ms, 'Gathering modifier duration', positive=True)
        for key in ('actor', 'target'):
            if packet.get(key) not in w.fighters:
                raise ValueError('Gathering modifiers need known source and recipient actors')
        for key, actor_key in (('source_life_generation', 'actor'), ('target_life_generation', 'target')):
            generation = life_generation(packet.get(key))
            if generation is None or not any(r['generation'] == generation
                    for r in w.life_cycles.lives[packet[actor_key]]):
                raise ValueError('Gathering modifiers need known source and recipient lives')
        source = w.fighters[packet['actor']]
        if (packet.get('ability') not in source.profile.get('documented_abilities', {}) or
                type(packet.get('action_id')) is not int or packet['action_id'] <= 0):
            raise ValueError('Gathering modifiers need an existing ability and action identity')
        actor = w.fighters[packet['target']]
        if actor.hp <= 0 or actor.life_generation != packet['target_life_generation']:
            return None
        identity = 'gathering-modifier:' + str(next(self.ids))
        row = {k: deepcopy(packet[k]) for k in ('actor', 'ability', 'action_id',
            'source_life_generation', 'target', 'target_life_generation')}
        if 'projectile_id' in packet:
            row['projectile_id'] = packet['projectile_id']
        row.update(id=identity, addition_ms=addition, started_at_ms=w.time,
            expiry_ms=w.time+duration, status='active', autonomous=True)
        self.instances[identity] = row
        w.push(row['expiry_ms'], EVENT, {'modifier_id': identity})
        w.log('gathering_modifier_started', **deepcopy(row))
        for action in actor.live_actions():
            # Due phases have priority over this new incoming effect.
            if action.phase != 'gathering' or action.active_due_ms <= w.time:
                continue
            before = action.active_due_ms
            self.commit(actor, action)
            if action.active_due_ms != before:
                action.revision += 1
                w._schedule_phase(action, 'active_started', action.active_due_ms)
        return identity

    def event_live(self, payload):
        row = self.instances.get(payload['modifier_id'])
        return row is not None and row['status'] == 'active'

    def end(self, row, reason):
        if row['status'] != 'active':
            return
        row.update(status='ended', ended_at_ms=self.world.time, end_reason=reason)
        self.world.log('gathering_modifier_ended', **deepcopy(row))

    def expire(self, payload):
        if self.event_live(payload):
            self.end(self.instances[payload['modifier_id']], 'expired')

    def retire_life(self, actor):
        for row in self.instances.values():
            if row['target'] == actor.id and row['target_life_generation'] == actor.life_generation:
                self.end(row, 'recipient_death')

    def result(self):
        return {'timed_gathering_rules': deepcopy(self.world.combat_locomotion_input['timed_gathering']),
            'gathering_modifiers': deepcopy(list(self.instances.values()))} if self.enabled else {}
