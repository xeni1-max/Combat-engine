"""Shared body reference writes and dependencies for predicted contacts.

Time, geometry and closing motion have separate resolutions. Only contacts
within the time resolution of a known boundary share that boundary's ordering;
physical event times otherwise retain their fractional milliseconds.
"""
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import world_standing_cuboids
from combat_sim.character_geometry import actor_body,crouch_target
from combat_sim.postures import body_origin_from_bounds, world_posture_cuboids
from combat_sim.pose_kinematics import pose_acceleration
from combat_sim.mechanics.support_geometry import grazing_vertical_departure
from combat_sim.movement_contacts import stationary_face_tangency
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.box_motion import axis_motions,impact_normals
from combat_sim.mechanics.support_geometry import grazing_projected_departure

CONTACT_TIME_EPS_MS = D('1e-24')
CONTACT_DISTANCE_EPS_M = D('1e-20')
CONTACT_SPEED_EPS_MPS = D('1e-24')
CONTACT_ACCEL_EPS_MPS2 = D('1e-24')


def contact_boundary_time(time, boundary):
    """Classify a computed contact against one known phase/kinematic boundary."""
    return boundary if abs(time-boundary) <= CONTACT_TIME_EPS_MS else time


class SpatialMotionRules:
    def set_body_reference(self, name, reference_m):
        """Write an upright reference and derive its pose and collision cache.

        The reference is distinct from the recentered crouched body origin.
        This is a geometry transition, not an implicit teleport ability, change
        of velocity, support grant or climb reattachment.
        """
        reference = tuple(map(dec, reference_m))
        if len(reference) != 3 or not all(v.is_finite() for v in reference):
            raise ValueError('Body reference needs three finite coordinates')
        actor, motion = self.fighters[name], self.motion[name]
        actor.position_m = reference[:2]
        if self.posture_ready:
            motion['body_reference_z'] = reference[2]
            fraction, _ = self.posture_at(name, self.time)
            boxes=(self.equilibrium.boxes(name,reference) if self.equilibrium.carries(name) else
                world_posture_cuboids(actor_body(self,name),reference,actor.facing,fraction,
                    crouch_target(self,name,self.crouch_definition['target_leg_height_m'])))
            actor.body_origin_m = tuple(map(dec, body_origin_from_bounds(boxes)))
        else:
            actor.body_origin_m = reference
            boxes = world_standing_cuboids(actor_body(self,name), reference, actor.facing)
        self.world_bodies[name] = boxes
        motion['spatial_revision'] = motion.get('spatial_revision', 0) + 1

    def body_motion_dependency(self, name):
        """Value dependency, including legacy motion producers not yet migrated."""
        actor, motion = self.fighters[name], self.motion[name]
        def dependency(box):
            row=(box.part,box.bounds,self.pose_part_motion(name,box.part,self.time))
            if isinstance(box,OrientedCuboid):row=(*row,box.frame,box.size_m)
            acceleration=pose_acceleration(self,name,box.part,self.time)
            return (*row,acceleration) if any(acceleration[0]) or any(acceleration[1]) else row
        return (motion.get('spatial_revision', 0), actor.life_generation, actor.hp > 0, actor.facing,
            tuple(actor.body_origin_m), tuple(actor.position_m),
            self.mobile_motion(name), motion.get('support_id'),
            tuple(dependency(box) for box in self.world_bodies[name]))

    def mobile_contact_payload(self, contacts):
        names = sorted({name for contact in contacts
                        for name in (contact['first'], contact['second']) if name in self.fighters})
        return {'contacts': contacts, 'collider_epoch': self.collider_system.registry.epoch,
            'motion_dependencies': {name: self.body_motion_dependency(name) for name in names}}

    def revalidate_mobile_contacts(self, payload):
        """Recheck stale predictions before any interruption, status or impulse.

        A phase can replace inward motion with a tangential climb, or finish
        body deformation. A changed dependency requires a fresh touching-face
        and closing-motion test, rather than blindly cancelling the new action.
        """
        dependencies = payload.get('motion_dependencies', {})
        unchanged = dependencies and all(self.body_motion_dependency(name) == state
                                         for name, state in dependencies.items())
        accepted = []
        for contact in payload['contacts']:
            a, b = contact['first'], contact['second']
            if self.fighters[a].hp <= 0 or (b in self.fighters and self.fighters[b].hp <= 0):
                continue
            if 'collider_id' in contact and not self.collider_system.registry.contact_live(contact, 'bodies', self.time):
                continue
            # A prediction may end at a prone/crouch supporting
            # envelope switch. Payload dependencies are installed *after*
            # advancing to that endpoint, so equality alone cannot certify
            # the predictor's outgoing pose derivative. Check the actual
            # touching/closing parts before treating that switch as impact.
            if unchanged and not self.terrain_support.finite_ground:
                accepted.append(contact)
                continue
            current = self._current_contact(contact)
            if current is not None:
                accepted.append(current)
        return accepted

    def _current_contact(self, contact):
        if contact.get('angular_collision'):return self.turns.revalidate(contact)
        a, b = contact['first'], contact['second']
        va, aa = self.mobile_motion(a)
        vb, ab = self.mobile_motion(b) if b in self.fighters else ((D(0),)*3, (D(0),)*3)
        right = self.world_bodies[b] if b in self.fighters else self.body_terrain_colliders().get(b, ())
        normals = set()
        support = None
        for left_box in self.world_bodies[a]:
            offset_a, rate_a = self.pose_part_motion(a, left_box.part, self.time)
            acceleration_a,size_accel_a=pose_acceleration(self,a,left_box.part,self.time)
            for right_box in right:
                offset_b, rate_b = (self.pose_part_motion(b, right_box.part, self.time)
                    if b in self.fighters else ((D(0),)*3, (D(0),)*3))
                acceleration_b,size_accel_b=(pose_acceleration(self,b,right_box.part,self.time)
                    if b in self.fighters else ((D(0),)*3,)*2)
                low_a, high_a = left_box.bounds
                low_b, high_b = right_box.bounds
                if any(max(dec(x), dec(z)) > min(dec(y), dec(w)) + CONTACT_DISTANCE_EPS_M
                       for x, y, z, w in zip(low_a, high_a, low_b, high_b)):
                    continue
                if isinstance(left_box,OrientedCuboid) or isinstance(right_box,OrientedCuboid):
                    velocity=tuple(v-w+x-y for v,w,x,y in zip(va,vb,offset_a,offset_b))
                    acceleration=tuple(x-y+pa-pb for x,y,pa,pb in zip(aa,ab,acceleration_a,acceleration_b))
                    rows=axis_motions(left_box,right_box,velocity,acceleration,first_size_rate=rate_a,
                        second_size_rate=rate_b,first_size_acceleration=size_accel_a,second_size_acceleration=size_accel_b)
                    touching=impact_normals(rows,distance_epsilon=CONTACT_DISTANCE_EPS_M,
                        speed_epsilon=CONTACT_SPEED_EPS_MPS,acceleration_epsilon=CONTACT_ACCEL_EPS_MPS2)
                    if not touching:continue
                    if any(n[2] for n in touching) and grazing_projected_departure(rows,0,
                            distance_epsilon=CONTACT_DISTANCE_EPS_M,speed_epsilon=CONTACT_SPEED_EPS_MPS,
                            acceleration_epsilon=CONTACT_ACCEL_EPS_MPS2):continue
                    normals.update(tuple(map(dec,n)) for n in touching)
                    if b not in self.fighters and any(n[2]>0 for n in touching):
                        reference=self.motion[a].get('body_reference_z',self.fighters[a].body_origin_m[2])
                        candidate=(right_box.part,left_box.part,dec(high_b[2])-(dec(low_a[2])-dec(reference)))
                        if support is None or candidate[:2]<support[:2]:support=candidate
                    continue
                if getattr(getattr(self,'body_support',None),'ready',False):
                    delta=tuple(dec(x)-dec(y) for x,y in zip(left_box.centre_m,right_box.centre_m))
                    half=tuple((dec(x)+dec(y))/2 for x,y in zip(left_box.size_m,right_box.size_m))
                    velocity=tuple(v-w+x-y for v,w,x,y in zip(va,vb,offset_a,offset_b))
                    acceleration=tuple(x-y+pa-pb for x,y,pa,pb in zip(aa,ab,acceleration_a,acceleration_b))
                    rate=tuple((x+y)/2 for x,y in zip(rate_a,rate_b))
                    change=tuple((x+y)/2 for x,y in zip(size_accel_a,size_accel_b))
                    if stationary_face_tangency(delta,half,velocity,acceleration,rate,change,
                            resolution=(CONTACT_DISTANCE_EPS_M,CONTACT_SPEED_EPS_MPS,CONTACT_ACCEL_EPS_MPS2)):continue
                touching = []
                for axis in range(3):
                    sign = (1 if abs(dec(low_a[axis])-dec(high_b[axis])) <= CONTACT_DISTANCE_EPS_M
                            else -1 if abs(dec(high_a[axis])-dec(low_b[axis])) <= CONTACT_DISTANCE_EPS_M
                            else 0)
                    if sign:
                        touching.append(tuple(D(sign) if i == axis else D(0) for i in range(3)))
                closing = False
                for normal in touching:
                    speed = sum((v-w+x-y)*n-(r+s)*abs(n)/2
                        for v,w,x,y,r,s,n in zip(va,vb,offset_a,offset_b,rate_a,rate_b,normal))
                    acceleration = sum((x-y+pa-pb)*n-(sa+sb)*abs(n)/2
                        for x,y,pa,pb,sa,sb,n in zip(aa,ab,acceleration_a,acceleration_b,size_accel_a,size_accel_b,normal))
                    closing |= speed < -CONTACT_SPEED_EPS_MPS or (
                        abs(speed) <= CONTACT_SPEED_EPS_MPS and acceleration < -CONTACT_ACCEL_EPS_MPS2)
                if not closing:
                    continue
                support_layer=getattr(self,'body_support',None)
                if (support_layer is not None and support_layer.ready and
                        (b in self.fighters or self.terrain_support.enabled) and any(n[2] for n in touching)):
                    delta=tuple(dec(x)-dec(y) for x,y in zip(left_box.centre_m,right_box.centre_m))
                    half=tuple((dec(x)+dec(y))/2 for x,y in zip(left_box.size_m,right_box.size_m))
                    velocity=tuple(v-w+x-y for v,w,x,y in zip(va,vb,offset_a,offset_b))
                    rate=tuple((x+y)/2 for x,y in zip(rate_a,rate_b))
                    if grazing_vertical_departure(delta,half,velocity,rate,
                            distance_epsilon=CONTACT_DISTANCE_EPS_M,speed_epsilon=CONTACT_SPEED_EPS_MPS,
                            relative_acceleration=tuple(x-y+pa-pb for x,y,pa,pb in zip(aa,ab,acceleration_a,acceleration_b)),
                            half_size_acceleration=tuple((x+y)/2 for x,y in zip(size_accel_a,size_accel_b)),
                            acceleration_epsilon=CONTACT_ACCEL_EPS_MPS2):continue
                normals.update(touching)
                if b not in self.fighters and any(n[2] > 0 for n in touching):
                    reference = self.motion[a].get('body_reference_z', self.fighters[a].body_origin_m[2])
                    candidate = (right_box.part, left_box.part,
                        dec(high_b[2]) - (dec(low_a[2])-dec(reference)))
                    if support is None or candidate[:2] < support[:2]:
                        support = candidate
        if not normals:
            return None
        current = dict(contact, normals=sorted(normals))
        if support is not None:
            current.update(support_part=support[0], support_body_part=support[1], support_reference_z_m=support[2])
        return current
