"""Six local-axis body proxies between approved crouch/standing and prone.

These are declared collision poses, not an animated rigid-body rotation.
Standing dimensions are retained at the upright endpoint; prone exchanges the
local forward/vertical dimensions. Standing/crouch/prone weights are convex,
allowing concurrent linear crouch and quadratic balance without a cubic pose.
The lowest part remains on the reference plane. Boundaries cover weight and
support/envelope changes.
"""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.hitboxes import Cuboid,local_to_world_point,standing_cuboids
from combat_sim.models import as_fraction
from combat_sim.moving_projectiles import _roots,_trim,_quadratic_bounds,_evaluate
from combat_sim.mechanics.velocity_projection import number,vector
from combat_sim.postures import LEGS,crouch_drop_m
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import place_local_cuboids


@dataclass(frozen=True)
class ProneMorph:
    parts: tuple
    floor_m: F
    prone_height_m: F
    crouch_fraction: F = F(0)
    full_crouch_drop_m: F = F(2,5)

    def fraction(self,value):
        value=number(value)
        if not 0<=value<=1:raise ValueError('Prone fraction must be between zero and one')
        return value

    def floor_line(self,fraction,*,direction=1):
        """Supporting lower-bound line, including a deterministic one-sided tie."""
        q=self.fraction(fraction)
        saturated=q+self.crouch_fraction>1 or q+self.crouch_fraction==1 and direction>0
        lines=[(c[2]-s[2]/2,dc[2]-ds[2]/2,name) for name,c,s,dc,ds in self._linear_rows(saturated)]
        return min(lines,key=lambda row:(row[0]+row[1]*q,direction*row[1],row[2]))[:2]

    def _linear_rows(self,saturated):
        """One fixed-crouch branch, affine in prone progress."""
        r=F(1) if saturated else self.crouch_fraction
        return tuple((name,tuple(x+r*y for x,y in zip(c,cc)),tuple(x+r*y for x,y in zip(s,sc)),
            tuple(x-y if saturated else x for x,y in zip(cq,cc)),
            tuple(x-y if saturated else x for x,y in zip(sq,sc))) for name,c,s,cq,sq,cc,sc in self.parts)

    def knots(self):
        """All possible support/centre envelope switches in the unit interval."""
        hinge=1-self.crouch_fraction;active={F(0),hinge,F(1)}
        for begin,end,saturated in ((F(0),hinge,False),(hinge,F(1),True)):
            if begin==end:continue
            rows=self._linear_rows(saturated);points={begin,end}
            for axis in range(3):
                for sign in (-1,1):
                    lines=[(c[axis]+sign*s[axis]/2,dc[axis]+sign*ds[axis]/2) for _,c,s,dc,ds in rows]
                    for i,(a,b) in enumerate(lines):
                        for c,d in lines[i+1:]:
                            if b!=d:
                                q=(c-a)/(b-d)
                                if begin<q<end:points.add(q)
            ordered=sorted(points)
            for q,left,right in zip(ordered[1:-1],ordered,ordered[2:]):
                a,b=(left+q)/2,(q+right)/2
                for axis in range(3):
                    for sign in (-1,1):
                        lines=[(c[axis]+sign*s[axis]/2,dc[axis]+sign*ds[axis]/2) for _,c,s,dc,ds in rows]
                        choose=min if sign<0 else max
                        if choose(lines,key=lambda line:line[0]+line[1]*a)!=choose(lines,key=lambda line:line[0]+line[1]*b):active.add(q)
        return tuple(sorted(active))

    def local_parts(self,fraction):
        q=self.fraction(fraction);low,rate=self.floor_line(q)
        shift=self.floor_m-low-rate*q
        return tuple(Cuboid(name,tuple(x+dx*q+(shift if i==2 else 0) for i,(x,dx) in enumerate(zip(c,dc))),
            tuple(x+dx*q for x,dx in zip(s,ds))) for name,c,s,dc,ds in self._linear_rows(q+self.crouch_fraction>=1))

    def world_parts(self,reference_m,facing,fraction):
        reference=vector(reference_m)
        if isinstance(facing,YawFrame):return place_local_cuboids(self.local_parts(fraction),reference,facing)
        return tuple(Cuboid(p.part,local_to_world_point(p.centre_m,reference,facing),
            (p.size_m[1],p.size_m[0],p.size_m[2])) for p in self.local_parts(fraction))

    def part_derivatives(self,part,fraction,rate_per_s,acceleration_per_s2,facing,*,crouch_rate_per_s=0,crouch_acceleration_per_s2=0):
        """Centre velocity/acceleration and full-size velocity/acceleration."""
        q=self.fraction(fraction)
        if any(isinstance(x,bool) for x in (rate_per_s,acceleration_per_s2,crouch_rate_per_s,crouch_acceleration_per_s2)):raise ValueError('Pose derivatives must be numeric')
        v=as_fraction(rate_per_s);a=as_fraction(acceleration_per_s2)
        cv=as_fraction(crouch_rate_per_s);ca=as_fraction(crouch_acceleration_per_s2)
        row=next((r for r in self.parts if r[0]==part),None)
        if row is None:raise ValueError('Unknown prone body part')
        together=(v+cv,a+ca)
        saturated=q+self.crouch_fraction>1 or q+self.crouch_fraction==1 and together>(0,0)
        r=min(self.crouch_fraction,1-q);rv,ra=(-v,-a) if saturated else (cv,ca)
        def values(item):
            name,c,s,cq,sq,cc,sc=item
            centre=tuple(x+q*y+r*z for x,y,z in zip(c,cq,cc));size=tuple(x+q*y+r*z for x,y,z in zip(s,sq,sc))
            velocity=tuple(x*v+y*rv for x,y in zip(cq,cc));acceleration=tuple(x*a+y*ra for x,y in zip(cq,cc))
            size_v=tuple(x*v+y*rv for x,y in zip(sq,sc));size_a=tuple(x*a+y*ra for x,y in zip(sq,sc))
            return name,centre,size,velocity,acceleration,size_v,size_a
        rows=tuple(map(values,self.parts))
        floor=min((c[2]-s[2]/2,vel[2]-sv[2]/2,acc[2]-sa[2]/2,name) for name,c,s,vel,acc,sv,sa in rows)
        _,_,_,velocity,acceleration,size_v,size_a=next(item for item in rows if item[0]==part)
        velocity=(*velocity[:2],velocity[2]-floor[1]);acceleration=(*acceleration[:2],acceleration[2]-floor[2])
        def world(values):return local_to_world_point(values,(0,0,0),facing)
        if isinstance(facing,YawFrame):return world(velocity),world(acceleration),size_v,size_a
        return world(velocity),world(acceleration),(size_v[1],size_v[0],size_v[2]),(size_a[1],size_a[0],size_a[2])

    def geometry_boundary(self,progress_polynomial,crouch_polynomial,duration_s,*,precision=50):
        """First weight/envelope change for concurrent quadratic pose channels.

        Polynomials are ascending power coefficients in seconds from now.
        Returned rational bounds enclose the change; inactive face crossings
        and tangencies do not split the shape. This does not advance a clock.
        """
        q,c=(tuple(map(as_fraction,p)) for p in (progress_polynomial,crouch_polynomial))
        duration=number(duration_s)
        if len(q)!=3 or len(c)!=3 or type(precision) is not int or precision<40:
            raise ValueError('Pose boundaries need quadratic coefficients and owned precision')
        if not duration:return None
        hinge=_trim((q[0]+c[0]-1,q[1]+c[1],q[2]+c[2]))
        low,high=_quadratic_bounds(hinge,F(0),duration)
        branches=(False,) if high<=0 else (True,) if low>=0 else (False,True)
        polynomials=set()
        def add(poly):
            poly=_trim(poly)
            if len(poly)<=1:return
            low,high=_quadratic_bounds(poly,F(0),duration)
            if low>0 or high<0:return
            polynomials.add(tuple(x/poly[-1] for x in poly))
        if len(branches)==2:add(hinge)
        for saturated in branches:
            r=(1-q[0],-q[1],-q[2]) if saturated else c
            for axis in range(3):
                for sign in (-1,1):
                    faces=[]
                    for _,p,s,pq,sq,pc,sc in self.parts:
                        start=p[axis]+sign*s[axis]/2
                        q_scale=pq[axis]+sign*sq[axis]/2
                        c_scale=pc[axis]+sign*sc[axis]/2
                        faces.append(tuple((start if i==0 else 0)+q_scale*x+c_scale*y for i,(x,y) in enumerate(zip(q,r))))
                    for i,first in enumerate(faces):
                        for last in faces[i+1:]:add(tuple(x-y for x,y in zip(first,last)))
        speed=max(F(1),abs(q[1])+2*abs(q[2])*duration,abs(c[1])+2*abs(c[2])*duration)
        tolerance=F(1,10**(precision-8))/speed
        brackets=[]
        for poly in sorted(polynomials):
            for root in _roots(poly,F(0),duration):
                if root.high==0:continue
                while root.high-root.low>tolerance:root.refine()
                brackets.append((root.low,root.high))
        clusters=[]
        for low,high in sorted(brackets):
            if clusters and low<=clusters[-1][1]:clusters[-1]=(clusters[-1][0],max(clusters[-1][1],high))
            else:clusters.append((low,high))
        def key(time):
            progress,nominal=_evaluate(q,time),_evaluate(c,time)
            saturated=progress+nominal>1
            effective=min(nominal,1-progress)
            result=[saturated]
            for axis in range(3):
                for sign in (-1,1):
                    faces=[(p[axis]+sign*s[axis]/2,pq[axis]+sign*sq[axis]/2,pc[axis]+sign*sc[axis]/2)
                        for _,p,s,pq,sq,pc,sc in self.parts]
                    choose=min if sign<0 else max
                    result.append(choose(faces,key=lambda row:row[0]+row[1]*progress+row[2]*effective))
            return tuple(result)
        for i,(low,high) in enumerate(clusters):
            before=((clusters[i-1][1] if i else F(0))+low)/2
            after=(high+(clusters[i+1][0] if i+1<len(clusters) else duration))/2
            if after>high and key(before)!=key(after):return low,high
        return None

    def point_kinematics(self,start,prone_target,crouch_offset,fraction,rate_per_s,acceleration_per_s2,facing,
            *,crouch_rate_per_s=0,crouch_acceleration_per_s2=0):
        """A declared attachment point follows the same convex pose/floor law."""
        start,target,offset=map(vector,(start,prone_target,crouch_offset))
        q=self.fraction(fraction);v,a,cv,ca=map(as_fraction,(rate_per_s,acceleration_per_s2,crouch_rate_per_s,crouch_acceleration_per_s2))
        saturated=q+self.crouch_fraction>1 or q+self.crouch_fraction==1 and (v+cv,a+ca)>(0,0)
        r=min(self.crouch_fraction,1-q);rv,ra=(-v,-a) if saturated else (cv,ca)
        low,slope=self.floor_line(q);shift=self.floor_m-low-slope*q
        delta=tuple(b-a for a,b in zip(start,target))
        point=tuple(p+d*q+c*r+(shift if i==2 else 0) for i,(p,d,c) in enumerate(zip(start,delta,offset)))
        # A body part supplies the shared supporting-plane derivative; no
        # attachment point invents a separate floor or translation writer.
        row=self.parts[0];name,_,_,dq,_,dc,_=row
        body_v,body_a,_,_=self.part_derivatives(name,q,v,a,facing,
            crouch_rate_per_s=cv,crouch_acceleration_per_s2=ca)
        floor_v=dq[2]*v+dc[2]*rv-body_v[2]
        floor_a=dq[2]*a+dc[2]*ra-body_a[2]
        velocity=tuple(d*v+c*rv-(floor_v if i==2 else 0) for i,(d,c) in enumerate(zip(delta,offset)))
        acceleration=tuple(d*a+c*ra-(floor_a if i==2 else 0) for i,(d,c) in enumerate(zip(delta,offset)))
        return point,local_to_world_point(velocity,(0,0,0),facing),local_to_world_point(acceleration,(0,0,0),facing)


def prone_morph(definition,crouch_fraction=0,target_leg_height_m=F(2,5)):
    """Convex standing/crouch/prone basis; effective crouch=min(crouch,1-prone)."""
    standing=standing_cuboids(definition)
    floor=as_fraction(definition['standing_placement']['ground_z_m'])
    height=max(box.size_m[1] for box in standing)
    crouch_fraction=number(crouch_fraction)
    if crouch_fraction>1:raise ValueError('Invalid crouch fraction')
    drop=crouch_drop_m(definition,1,target_leg_height_m)
    rows=[]
    for box in standing:
        crouch_centre=[F(0)]*3;crouch_size=[F(0)]*3
        if box.part in LEGS:crouch_centre[2]=-drop/2;crouch_size[2]=-drop
        else:crouch_centre[2]=-drop
        target=(box.centre_m[0],box.centre_m[2],floor+height/2)
        target_size=(box.size_m[0],box.size_m[2],box.size_m[1])
        rows.append((box.part,box.centre_m,box.size_m,tuple(b-a for a,b in zip(box.centre_m,target)),
            tuple(b-a for a,b in zip(box.size_m,target_size)),tuple(crouch_centre),tuple(crouch_size)))
    return ProneMorph(tuple(rows),floor,height,crouch_fraction,drop)
