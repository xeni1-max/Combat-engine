"""Encounter setup loading, kept separate from character profiles."""

from typing import Any

from combat_sim.models import CharacterState


def initial_states(encounter: dict[str, Any], *, track_statuses: bool = False) -> dict[str, CharacterState]:
    values = encounter.get("initial_states", {})
    if not values:
        raise ValueError("Encounter must include initial_states")
    return {
        name: CharacterState.from_mapping(state, track_statuses=track_statuses)
        for name, state in values.items()
    }
