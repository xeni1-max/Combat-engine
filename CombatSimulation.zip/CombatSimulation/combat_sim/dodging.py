"""Owned physical downward evasion on shared posture and recharge primitives."""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.charges import RechargeableCharges
from combat_sim.models import UnsupportedMechanicError


class Dodging:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.pools={};self.rows={}
        if self.enabled and definition!={'mode':'posture_dip_v1'}:
            raise UnsupportedMechanicError('Unsupported Dodge geometry rules')

    def validate(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id]
        if not (self.enabled and w.mobile_mode and w.posture_ready and w.equilibrium.enabled
                and w.cooldown_system.enabled and actor.action_registry is not None):
            raise UnsupportedMechanicError('Dodge requires owned current posture, body physics and cooldown work')
        if (a.get('target_mode')!='self' or a.get('dodge_geometry')!={'mode':'crouch_and_return','peak_fraction':1}
                or a.get('hand_positions_m',{}).get('start')!={} or a['hand_positions_m'].get('end')!={}
                or a.get('dyspnea',{}).get('payment_timing')!='active_start'):
            raise UnsupportedMechanicError('Unsupported Dodge target, pose, hand or payment rule')
        timing=actor.profile['timing_profiles'][a['timing_profile']]
        active=dec(timing['active_ms'])
        if active<=0 or active!=active.to_integral_value() or dec(timing['gathering_ms'])<0:
            raise ValueError('Dodge requires positive integer Active and nonnegative Gathering')
        # Validate the reusable pool without consuming or installing its clock.
        RechargeableCharges(a['charges'],a['charge_cooldown_ms'])

    def attach(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            for key in actor.ready:
                a=actor.profile['abilities'][key]
                if a['execution_model']!='dodge':continue
                self.pools[(actor.id,key)]=RechargeableCharges(a['charges'],a['charge_cooldown_ms'],
                    clock=actor.cooldowns.clocks[key])
                actor.metrics.update(dodges_started=0,dodges_completed=0,dodges_interrupted=0)

    def ready_at(self,actor,ability_id):
        value=self.pools[(actor.id,ability_id)].ready_at(self.world.time)
        return D('Infinity') if value is None else value

    def available(self,actor):
        w=self.world
        return (not actor.knocked_down and not w._airborne(actor.id) and not w._climbing(actor.id)
            and w.posture_at(actor.id,w.time)[0]<1)

    def active_started(self,actor,action):
        w=self.world
        if not self.available(actor):
            # Availability can change during delayed Gathering. Payment is
            # preflighted before the common activation path enters here.
            raise RuntimeError('Dodge availability changed after Active preflight')
        pool=self.pools[(actor.id,action.ability_id)];pool.spend(w.time)
        w.cooldown_system._sync(actor)
        fraction,_=w.posture_at(actor.id,w.time);half=action.active_ms/2
        row={'actor':actor.id,'ability':action.ability_id,'action_id':action.id,
            'source_life_generation':actor.life_generation,'started_at_ms':w.time,
            'midpoint_ms':w.time+half,'active_end_ms':action.active_end_ms,
            'starting_crouch_fraction':fraction,'peak_crouch_fraction':D(1),'status':'active'}
        self.rows[(actor.id,action.id)]=row
        w.motion[actor.id]['pose_transition']={'from':fraction,'to':D(1),'start_ms':w.time,'duration_ms':half}
        actor.metrics['dodges_started']+=1
        w.log('dodge_charges_spent',actor=actor.id,ability=action.ability_id,action_id=action.id,
            spent=1,pool=pool.record(w.time))
        w.log('dodge_started',**deepcopy(row));w.refresh_mobile_locomotion()
        w._schedule_phase(action,'self_effect',row['midpoint_ms'])

    def turn(self,actor,action):
        w=self.world;row=self.rows[(actor.id,action.id)];m=w.motion[actor.id]
        fraction,_=w.posture_at(actor.id,w.time)
        m.update(crouch_fraction=fraction,pose_transition={'from':fraction,
            'to':row['starting_crouch_fraction'],'start_ms':w.time,'duration_ms':action.active_end_ms-w.time})
        w.log('dodge_return_started',actor=actor.id,ability=action.ability_id,action_id=action.id,
            crouch_fraction=fraction,active_end_ms=action.active_end_ms)
        w.refresh_mobile_locomotion()

    def complete(self,actor,action):
        w=self.world;row=self.rows[(actor.id,action.id)];m=w.motion[actor.id]
        m.update(crouch_fraction=row['starting_crouch_fraction'],pose_transition=None)
        row.update(status='completed',ended_at_ms=w.time);actor.metrics['dodges_completed']+=1
        actor.current=None;w.refresh_mobile_locomotion()
        w.log('dodge_completed',actor=actor.id,ability=action.ability_id,action_id=action.id,
            crouch_fraction=m['crouch_fraction']);w.request_decision(actor.id,w.time)

    def cancelled(self,actor,action,reason):
        row=self.rows.get((actor.id,action.id))
        if row is None or row['status']!='active':return
        self._freeze(actor,row,reason)

    def _freeze(self,actor,row,reason):
        w=self.world;fraction,_=w.posture_at(actor.id,w.time)
        w.motion[actor.id].update(crouch_fraction=fraction,pose_transition=None)
        row.update(status='cancelled',ended_at_ms=w.time,end_reason=reason,retained_crouch_fraction=fraction)
        actor.metrics['dodges_interrupted']+=1
        w.log('dodge_interrupted',actor=actor.id,ability=row['ability'],action_id=row['action_id'],
            reason=reason,crouch_fraction=fraction)
        w.refresh_mobile_locomotion()

    def retire_life(self,actor):
        for row in self.rows.values():
            if row['actor']==actor.id and row['source_life_generation']==actor.life_generation and row['status']=='active':
                self._freeze(actor,row,'death')

    def result(self):
        if not self.pools:return {}
        return {'dodge_actions':deepcopy(list(self.rows.values())),
            'dodge_charge_pools':{name:{key:pool.record(self.world.time) for (actor,key),pool in self.pools.items()
                if actor==name} for name in sorted({n for n,_ in self.pools})}}
