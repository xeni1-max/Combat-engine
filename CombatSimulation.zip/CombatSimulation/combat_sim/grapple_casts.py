"""Authored grab contacts and owned holding phases on the common combat world.

The complete grab tail and the persistent hold are separate action instances.
Motion, damage and effort retain their shared coordinators and life identities.
"""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.action_ownership import ActionRequirements
from combat_sim.battle_models import BattleAction,decimal_value as dec
from combat_sim.effect_models import EffectSource
from combat_sim.grapple_links import LinkCommand
from combat_sim.mechanics.grapple import GrappleState
from combat_sim.models import UnsupportedMechanicError


class GrappleCasts:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.holds={};self.contacts=set()
        if self.enabled and (definition!={'mode':'owned_grapple_v1'} or
                not all((world.melee.enabled,world.grapple_links.enabled,
                    world.controlled_damage.enabled,world.continuous_effort.enabled))):
            raise UnsupportedMechanicError('Owned grapples require shared contact, links, rate damage and effort')

    def validate(self,actor,ability_id):
        if not self.enabled:raise UnsupportedMechanicError('Grab delivery needs owned grapple rules')
        a=actor.profile['abilities'][ability_id];g=a.get('melee_geometry',{})
        if (self.world.ownership_definition is None or
                not {'grapple_grab','grapple_hold'}<=set(self.world.ownership_definition['actions'])):
            raise UnsupportedMechanicError('Grab and holding require explicit phase ownership')
        if (a.get('damage_type')!='contact' or dec(a.get('pre_mitigation_damage',-1))!=0 or
                a.get('self_effects',{}).get('application_timing')!='impact' or
                a.get('dyspnea',{}).get('payment_timing')!='active_start' or
                a.get('effort_phase')!='grab' or a.get('holding_effort_phase')!='holding' or
                a.get('holding_damage_type')!='constriction_tear' or
                a.get('cooldown_anchor')!='active_start' or
                g.get('mode')!='hand_capsule_at_impact' or g.get('aim')!='torso_location_at_active_start' or
                g.get('blocking')!='body_solids' or g.get('origin_hand') not in ('left','right')):
            raise UnsupportedMechanicError('Unsupported grab contact, holding or payment rules')
        hand=g['origin_hand']
        if (any(set(a['hand_positions_m'][phase])!={hand} for phase in ('start','end')) or
                actor.profile['timing_profiles'][a['timing_profile']].get('impact_timing')!='middle_of_active'):
            raise ValueError('A grab needs one explicit hand and a midpoint contact')
        if any(dec(a[key])<=0 for key in ('hold_duration_ms','holding_damage_per_second','cooldown_ms')) or any(
                dec(g[key])<=0 for key in ('reach_m','radius_m')) or dec(a.get('holding_base_dyspnea',-1))<0:
            raise ValueError('Grab geometry, duration, cooldown and holding rates must be valid')
        phases=actor.profile['documented_abilities'][ability_id].get('effort_phases',{})
        if (phases.get('grab',{}).get('category')!='intrinsic_momentary' or
                phases.get('holding',{}).get('category')!='intrinsic_sustained'):
            raise ValueError('Grab and holding need separate source effort categories')

    def active_started(self,actor,action):
        a=actor.profile['abilities'][action.ability_id]
        self.world.cooldown_system.start(actor,action.ability_id,dec(a['cooldown_ms']),action.id)

    def requirements(self,actor,action,*,pending):
        a=actor.profile['abilities'][action.ability_id];hand='hand:'+a['melee_geometry']['origin_hand']
        resources={'holding:'+str(action.id)} if pending else {hand,'weapon:'+action.ability_id}
        return ActionRequirements(frozenset(resources),frozenset((hand,'upper_body','attack')))

    def attach_batch(self,packets):
        """No attachment sees only a prefix of a simultaneous impact batch."""
        for packet in sorted(packets,key=lambda p:(p['actor'],p['action_id'],p['target'])):
            self.attach_contact(packet)

    def _reject(self,packet,reason):
        self.world.log('grapple_contact_rejected',actor=packet['actor'],ability=packet['ability'],
            action_id=packet['action_id'],target=packet['target'],attack_id=packet['attack_id'],reason=reason)

    def attach_contact(self,packet):
        if not self.enabled:raise UnsupportedMechanicError('Grab contact requires owned grapple rules')
        identity=packet['attack_id']
        if identity in self.contacts:return
        self.contacts.add(identity);w=self.world;actor=w.fighters[packet['actor']]
        if packet.get('collision_kind')!='body' or 'block_layer_id' in packet:
            return self._reject(packet,'intercepted_surface')
        target=w.fighters[packet['target']];parent=actor.action_by_id(packet['action_id'])
        if (parent is None or parent.kind not in ('grapple_grab','charge_grab') or parent.phase!='active' or
                actor.hp<=0 or target.hp<=0 or actor.life_generation!=packet['source_life_generation'] or
                target.life_generation!=packet['target_life_generation']):
            return self._reject(packet,'action_or_participant_life_ended')
        if parent.kind=='charge_grab':
            from combat_sim.facing import forward
            delta=tuple(a-b for a,b in zip(w.spatial_transitions.reference(target.id),w.spatial_transitions.reference(actor.id)))
            if sum(dec(n)*v for n,v in zip(forward(actor.facing),delta))<=0:
                return self._reject(packet,'charge_target_not_in_front')
        if parent.kind!='charge_grab' and any(w._airborne(n) or
                w.collider_system.find_support(w.fighters[n]) is None
                for n in (actor.id,target.id)):
            return self._reject(packet,'ground_drag_requires_supported_entry')
        if GrappleState(actor.dyspnea,actor.disorientation,actor.instability).exhausted:
            return self._reject(packet,'controller_exhausted')
        a=actor.profile['abilities'][parent.ability_id];until=w.time+dec(a['hold_duration_ms'])
        hold=BattleAction(next(w.action_ids),actor.id,target.id,parent.ability_id,'grapple_hold',w.time,
            w.time,dec(a['hold_duration_ms']),phase='holding_pending',active_end_ms=until,
            life_generation=actor.life_generation)
        requirements=self.requirements(actor,hold,pending=True)
        if any(actor.action_registry.unavailable(requirements)):
            return self._reject(packet,'holding_function_restricted')
        link_id='grapple:'+str(hold.id)
        ownership=actor.action_registry.prepare_transfer({},((hold,requirements),))
        link=w.grapple_links.prepare(LinkCommand('attach',link_id,actor.id,target.id,actor.life_generation,
            target.life_generation,until-w.time),source=identity,
            action_source=EffectSource(actor.id,parent.ability_id,hold.id,None,actor.life_generation))
        # Both plans have been checked. Link commit does not call observers;
        # registry transfer depends only on its unchanged owners/functions/D.
        w.grapple_links.commit(link,notify=False)
        actor.action_registry.commit_transfer(ownership)
        row={'id':link_id,'actor':actor.id,'ability':parent.ability_id,'target':target.id,
            'source_life_generation':actor.life_generation,'target_life_generation':target.life_generation,
            'grab_action_id':parent.id,'holding_action_id':hold.id,'attack_id':identity,
            'started_at_ms':w.time,'expiry_ms':until,'status':'active','hand_transferred_at_ms':None}
        self.holds[link_id]=row
        stream=w.controlled_damage.start(actor,hold,target.id,base_dps=a['holding_damage_per_second'],until_ms=until)
        effort=w.continuous_effort.start(actor,hold,tag='grapple_holding:'+link_id,kind='squared',
            base=a['holding_base_dyspnea'],until_ms=until)
        row.update(damage_stream_id=stream.id,effort_channel_id=effort.id)
        w.charge_grapples.attached(parent,row)
        w.log('grapple_holding_started',hold=deepcopy(row))
        w.grapple_links.notify()

    def grab_completed(self,actor,parent):
        """Move the occupied hand at authored grab end, without a free interval."""
        for row in self.holds.values():
            if row['status']!='active' or row['actor']!=actor.id or row['grab_action_id']!=parent.id:continue
            hold=actor.action_by_id(row['holding_action_id'])
            if hold is None:raise RuntimeError('A live grapple lost its owned holding action')
            paid=actor.action_registry.requirements[parent.id]
            tail=ActionRequirements(frozenset(('grab_completed:'+str(parent.id),)),paid.requires,
                paid.base_cost,paid.payment_phase)
            actor.action_registry.transfer({parent.id:tail,hold.id:self.requirements(actor,hold,pending=False)})
            hold.phase='holding';row['hand_transferred_at_ms']=self.world.time
            self.world.log('grapple_hand_transferred',hold=deepcopy(row))
        self.world.log('grapple_grab_completed',actor=actor.id,ability=parent.ability_id,action_id=parent.id)

    def link_ended(self,link):
        row=self.holds.get(link['id'])
        if row is not None:self.end(row,link['end_reason'],release_link=False)

    def end(self,row,reason,*,release_link=True,cancelling_action_id=None):
        if row['status']!='active':return
        w=self.world;row.update(status='ended',ended_at_ms=w.time,end_reason=reason)
        actor=w.fighters[row['actor']]
        w.controlled_damage.end(w.controlled_damage.streams[row['damage_stream_id']],reason)
        w.continuous_effort.end(w.continuous_effort.channels[row['effort_channel_id']],reason)
        hold=actor.action_by_id(row['holding_action_id'])
        if hold is not None and hold.id!=cancelling_action_id:
            hold.phase='ended';hold.revision+=1;actor.action_registry.release(hold.id)
        w.grapple_break.hold_ended(row,reason)
        w.charge_grapples.hold_ended(row,reason)
        if release_link:w.grapple_links.release(row['id'],reason=reason,source='owned_holding')
        w.log('grapple_holding_ended',hold=deepcopy(row))
        w.request_decision(actor.id,w.time)

    def action_cancelled(self,actor,action,reason):
        for row in self.holds.values():
            if row['status']!='active' or row['actor']!=actor.id:continue
            if action.id==row['holding_action_id'] or (action.id==row['grab_action_id'] and
                    row['hand_transferred_at_ms'] is None):
                self.end(row,reason,cancelling_action_id=action.id)

    def settle(self):
        for row in self.holds.values():
            if row['status']!='active':continue
            actor=self.world.fighters[row['actor']];target=self.world.fighters[row['target']]
            if (actor.hp<=0 or target.hp<=0 or actor.life_generation!=row['source_life_generation'] or
                    target.life_generation!=row['target_life_generation'] or
                    actor.action_by_id(row['holding_action_id']) is None):self.end(row,'participant_or_control_ended')

    def release(self,actor_id,link_id):
        row=self.holds.get(link_id)
        if row is None or row['status']!='active' or row['actor']!=actor_id:return False
        self.end(row,'controller_released');return True

    def result(self):
        return {'grapple_cast_rules':self.world.combat_locomotion_input['grapple_casts'],
            'grapple_holds':deepcopy(list(self.holds.values()))} if self.enabled else {}
