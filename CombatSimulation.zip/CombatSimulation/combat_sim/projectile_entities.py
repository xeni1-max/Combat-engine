"""Persistent projectile identity and contact policy, separate from actions.

Kinematics remain in the existing straight/gravity rules. The registry owns
identity, lifecycle revisions and duplication ancestry. Legacy trace projection
is a presentation adapter only; simulation lookups always use entity IDs.
"""
from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import UnsupportedMechanicError
from combat_sim.mechanics.life import life_generation


@dataclass(frozen=True)
class ProjectileContactPolicy:
    owner: str = 'ignore'
    other_bodies: str = 'impact'
    terrain: str = 'impact'

    def __post_init__(self):
        if (self.owner not in ('ignore','impact_after_separation','consume_after_separation')
                or self.other_bodies not in ('ignore','impact') or self.terrain not in ('ignore','impact')):
            raise UnsupportedMechanicError('Unsupported projectile contact policy')

    @classmethod
    def from_definition(cls,definition=None):
        if definition is None:
            return cls()
        if not isinstance(definition,dict) or set(definition)!={'owner','other_bodies','terrain'}:
            raise ValueError('Projectile contact policy needs owner, other_bodies and terrain')
        return cls(**definition)

    def record(self):
        return {'owner':self.owner,'other_bodies':self.other_bodies,'terrain':self.terrain}


@dataclass(frozen=True)
class ProjectileIdentity:
    id: str
    action_id: int
    owner: str
    ability: str
    created_at_ms: D
    parent_projectile_id: str | None
    root_projectile_id: str
    source_life_generation: int | None = None


class ProjectileRegistry:
    def __init__(self,definition=None):
        if definition is not None and definition!={'trace_schema':'entity_v1'}:
            raise UnsupportedMechanicError('Unsupported projectile entity definition')
        self.trace_schema='entity_v1' if definition is not None else 'action_linked_v1'
        self.ids=count(1)
        self.flights={}
        self.identities={}
        self.policies={}

    def create(self,*,action_id,owner,ability,created_at_ms,kinematics,policy=None,parent=None,source_life_generation=None):
        if (not isinstance(action_id,int) or isinstance(action_id,bool) or action_id<=0
                or not isinstance(owner,str) or not owner or not isinstance(ability,str) or not ability):
            raise ValueError('A projectile needs a parent action, owner and source ability')
        created=dec(created_at_ms)
        if not created.is_finite() or created<0:
            raise ValueError('Projectile creation time must be finite and nonnegative')
        policy=policy if policy is not None else ProjectileContactPolicy()
        life_generation(source_life_generation)
        if not isinstance(policy,ProjectileContactPolicy):
            raise ValueError('Projectile needs an explicit contact policy')
        if parent is not None:
            if parent not in self.identities:
                raise ValueError('Unknown parent projectile entity')
            identity=self.identities[parent]
            if (action_id,owner,ability)!=(identity.action_id,identity.owner,identity.ability):
                raise ValueError('A copied projectile retains its source attribution')
            if source_life_generation!=identity.source_life_generation:
                raise ValueError('A copied projectile retains its source life')
            if created<identity.created_at_ms:
                raise ValueError('A copied projectile cannot predate its parent')
        reserved={'id','action_id','actor','ability','created_at_ms','entity_kind','revision',
            'parent_projectile_id','root_projectile_id','contact_policy','owner_cleared_at_ms','duplication_sources',
            'source_life_generation'}
        if reserved&set(kinematics):
            raise ValueError('Kinematic fields cannot replace projectile identity/lifecycle')
        if kinematics.get('status')!='in_flight':
            raise ValueError('A new projectile begins in flight')
        entity_id='projectile:'+str(next(self.ids))
        identity=ProjectileIdentity(entity_id,action_id,owner,ability,created,parent,
            self.identities[parent].root_projectile_id if parent is not None else entity_id,source_life_generation)
        flight={**deepcopy(kinematics),'id':entity_id,'action_id':action_id,'actor':owner,'ability':ability,
            'entity_kind':'projectile','created_at_ms':created,'revision':0,'parent_projectile_id':parent,
            'root_projectile_id':identity.root_projectile_id,'contact_policy':policy.record(),
            'owner_cleared_at_ms':None,'duplication_sources':list(self.flights[parent]['duplication_sources']) if parent else []}
        if source_life_generation is not None:flight['source_life_generation']=source_life_generation
        self.identities[entity_id]=identity
        self.policies[entity_id]=policy
        self.flights[entity_id]=flight
        return flight

    def link(self,flight):
        identity=self.identities[flight['id']]
        return {'actor':identity.owner,'ability':identity.ability,'action_id':identity.action_id,
            'projectile_id':identity.id,'projectile_revision':flight['revision'],
            **({'source_life_generation':identity.source_life_generation} if identity.source_life_generation is not None else {})}

    def live(self,payload):
        flight=self.flights.get(payload.get('projectile_id'))
        return (flight is not None and flight['status']=='in_flight'
            and payload.get('projectile_revision')==flight['revision'])

    def terminal(self,flight,status,**details):
        if flight['status']!='in_flight':
            return False
        if status not in ('collided','consumed','stopped','removed'):
            raise ValueError('Projectile terminal state is explicit')
        flight.update(status=status,revision=flight['revision']+1,**details)
        return True

    def claim_duplication(self,entity_id,source):
        if not isinstance(source,str) or not source:
            raise ValueError('Duplication requires a source instance identity')
        flight=self.flights[entity_id]
        if flight['status']!='in_flight' or source in flight['duplication_sources']:
            return False
        flight['duplication_sources'].append(source)
        return True

    def serialize(self,value):
        """Project old one-projectile/action traces without changing live state."""
        if self.trace_schema=='entity_v1':
            return value
        if isinstance(value,list):
            return [self.serialize(item) for item in value]
        if not isinstance(value,dict):
            return value
        flight=value.get('entity_kind')=='projectile'
        hidden={'projectile_revision'} if 'projectile_id' in value else set()
        if flight:
            hidden|={'action_id','entity_kind','created_at_ms','revision','parent_projectile_id',
                'root_projectile_id','contact_policy','owner_cleared_at_ms','duplication_sources',
                'trajectory_started_at_ms','distance_offset_m'}
        result={key:self.serialize(item) for key,item in value.items() if key not in hidden}
        if flight:
            result['id']=value['action_id']
        if 'projectile_id' in result:
            identity=self.identities[result['projectile_id']]
            result['projectile_id']=identity.action_id
        return result
