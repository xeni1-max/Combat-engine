"""Existing common abilities on the shared action queue.

Get Up uses the same action identity/revision, resource, phase and death
handling as attacks. Current rules integrate the source equilibrium formula;
explicit knockdown effects share the same paid recovery. See GET_UP.md.
"""
from combat_sim.battle_models import BattleAction, decimal_value as dec
from combat_sim.mechanics.get_up import get_up_profile,derive_get_up_profile
from combat_sim.models import UnsupportedMechanicError


class CommonActionRules:
    def setup_common_actions(self, definition):
        declared = self.scenario.get('common_abilities', [])
        integrated=self.equilibrium.enabled
        if declared not in ([], ['get_up']):
            raise UnsupportedMechanicError('Supported common_abilities declaration is ["get_up"]')
        self.common_profiles = {}
        if not declared and not integrated:
            if definition is not None:
                raise ValueError('Get Up definitions require common_abilities=["get_up"]')
            return
        if not self.team_mode or self.movement_mode:
            raise UnsupportedMechanicError('Get Up currently requires shared team combat, without scripted movement')
        if definition is None and not integrated:
            raise ValueError('Get Up requires an explicit definition')
        for name, actor in self.fighters.items():
            if definition is None:
                jump=(self.jump_input or {}).get('characters',{}).get(actor.profile_id)
                if jump is None:raise ValueError('Integrated Get Up requires the source basic-jump dyspnea profile')
                self.common_profiles[name]=derive_get_up_profile(actor.profile['recovery_value'],jump['listed_dyspnea_value'])
            else:self.common_profiles[name] = get_up_profile(actor.profile_id, definition)
            self.common_profiles[name]['dyspnea']['base_value'] = dec(
                self.common_profiles[name]['dyspnea']['base_value'])
            raw = self.scenario['encounter']['participants'][name].get('initial_state', {})
            down = raw.get('knocked_down', False)
            if not isinstance(down, bool):
                raise ValueError('Initial knocked_down must be a boolean')
            actor.knocked_down = down
            actor.metrics.update(get_ups_started=0, get_ups_completed=0, knockdowns_received=0)

    def request_get_up(self, actor):
        """Recover before selecting attacks, including when no enemies remain."""
        if self.equilibrium.enabled:
            from combat_sim.prone_actions import request_get_up
            return request_get_up(self.equilibrium,actor)
        if not actor.knocked_down or actor.hp <= 0 or actor.current is not None:
            return False
        profile = self.common_profiles[actor.id]
        ready = self.resource_ready_time(actor, profile['dyspnea'])
        if ready > self.time:
            self.log('get_up_waiting_for_capacity', actor=actor.id,
                     resume_at_ms=ready, dyspnea=actor.dyspnea)
            if ready.is_finite():
                self.request_decision(actor.id, ready)
            return False
        action = BattleAction(next(self.action_ids), actor.id, actor.id,
                              'get_up', 'get_up', self.time, self.time,
                              dec(profile['active_ms']), phase='ready')
        actor.current = action
        self.log('get_up_requested', actor=actor.id, action_id=action.id,
                 active_start_ms=self.time, active_ms=action.active_ms)
        self._schedule_phase(action, 'active_started', self.time)
        return True

    def start_get_up(self, actor):
        if self.equilibrium.enabled:
            from combat_sim.prone_actions import start_get_up
            return start_get_up(self.equilibrium,actor)
        action = actor.current
        if not self.pay_team_dyspnea(actor, 'active_start'):return
        action.phase = 'active'
        action.active_end_ms = self.time + action.active_ms
        actor.metrics['activations_started'] += 1
        actor.metrics['get_ups_started'] += 1
        self.log('get_up_started', actor=actor.id, ability='get_up', action_id=action.id,
                 active_end_ms=action.active_end_ms, active_ms=action.active_ms)
        self._schedule_phase(action, 'active_completed', action.active_end_ms)

    def complete_get_up(self, actor):
        if self.equilibrium.enabled:
            from combat_sim.prone_actions import complete_get_up
            return complete_get_up(self.equilibrium,actor)
        action = actor.current
        actor.knocked_down = False
        actor.current = None
        actor.metrics['get_ups_completed'] += 1
        self.log('get_up_completed', actor=actor.id, action_id=action.id,
                 state=actor.record())
        self.request_decision(actor.id, self.time)

    def apply_knockdown(self, name, *, source):
        """Entry point for an existing ability's knockdown effect.

        Apply during impact resolution, after due phases at that timestamp.
        Reapplication cancels any current Get Up and permits a new attempt.
        Paid costs stay paid; released/deployed effects remain independent.
        """
        if self.equilibrium.enabled:return self.equilibrium.knockdown(name,source=source)
        if name not in self.common_profiles:
            raise UnsupportedMechanicError('Knockdown requires the Get Up common-action definition')
        actor = self.fighters[name]
        if actor.hp <= 0 or actor.died_at_ms is not None:
            return False
        cancelled = actor.current.record() if actor.current else None
        actor.current = None
        actor.knocked_down = True
        actor.decision_due = None
        actor.decision_revision += 1
        actor.metrics['knockdowns_received'] += 1
        self.log('knockdown_applied', actor=name, source=source,
                 cancelled_action=cancelled, state=actor.record())
        self.request_decision(name, self.time)
        return True
