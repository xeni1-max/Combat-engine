"""Moving life-bound anchor limits for released ballistic utility projectiles."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.distance_events import first_distance_exit
from combat_sim.mechanics.velocity_projection import vector


class AnchoredProjectileLimits:
    def __init__(self,world):self.world=world

    @staticmethod
    def policy(payload):
        if 'flight_limit' in payload:return payload['flight_limit']
        binding=payload.get('binding',{})
        return ({'kind':'live_source_distance','maximum_m':binding['maximum_m']} if binding.get('kind')=='distance' else {'kind':'ballistic'})

    def reachable_aim(self,ability,origin,aim,speed):
        """A range-limited miss for an algebraically unreachable target."""
        if ability.get('execution_model') not in ('binding_projectile','impact_binding_area','impact_area_projectile','poison_projectile','construct_projectile','hook_projectile'):return aim,None
        p=vector(origin);target=vector(aim);delta=tuple(b-a for a,b in zip(p,target))
        squared=sum(x*x for x in delta);v=F(speed);g=F(self.world.physics['gravity_mps2'])
        b=v*v-g*delta[2]
        if b>0 and b*b-g*g*squared>=0:return aim,None
        # Stay below the vertical energy limit in every direction. This is an
        # aim proxy only; actual contact and the live anchor envelope still
        # determine the projectile's fate. Numerical solver errors are not caught.
        policy=self.policy(ability);safe=v*v/(4*g)
        reach=min(F(policy['maximum_m']),safe) if policy['kind']=='live_source_distance' else safe
        with localcontext(Context(prec=self.world.precision)):
            scale=dec(reach)/dec(squared).sqrt()
            proxy=tuple(dec(a)+scale*dec(d) for a,d in zip(p,delta))
        return proxy,{'rule':'algebraically_unreachable_target_range_proxy','requested_aim_point_m':aim,
            'proxy_distance_m':dec(reach)}

    def boundary(self,flight,end):
        policy=self.policy(flight.get('contact_payload',{}))
        if policy['kind']!='live_source_distance':return None
        w=self.world
        actor=w.fighters[flight['actor']]
        if actor.hp<=0 or actor.life_generation!=flight['source_life_generation']:return None
        frame=w.body_paths.ensure(future=True);anchor=dict(frame.pieces)[actor.id]
        begin=max(anchor.begin_ms,F(flight['trajectory_started_at_ms']))
        finish=anchor.end_ms
        if finish<begin:return None
        # Use the saved lease's absolute interval, independently of observation
        # slices. Undecelerated gravity flight has one exact quadratic model.
        elapsed=(begin-F(flight['trajectory_started_at_ms']))/1000
        gravity=F(w.physics['gravity_mps2']);acceleration=(F(0),F(0),-gravity)
        initial=vector(flight['initial_velocity_mps']);origin=vector(flight['origin_m'])
        point=tuple(p+v*elapsed+a*elapsed*elapsed/2 for p,v,a in zip(origin,initial,acceleration))
        velocity=tuple(v+a*elapsed for v,a in zip(initial,acceleration))
        anchor=anchor.slice(begin,finish)
        relative=tuple(x-y for x,y in zip(point,anchor.reference_m))
        speed=tuple(x-y for x,y in zip(velocity,anchor.velocity_mps))
        change=tuple(x-y for x,y in zip(acceleration,anchor.acceleration_mps2))
        bracket=first_distance_exit(relative,speed,change,policy['maximum_m'],(finish-begin)/1000)
        if bracket is None:return None
        with localcontext(Context(prec=w.precision)):
            absolute=max(w.time,w._gravity_event_time(dec(begin+bracket[1]*1000)))
        if absolute>end or F(absolute)>finish:return None
        payload={**w.projectiles.link(flight),'projectile_event':'projectile_range_ended',
            'anchor_life_generation':actor.life_generation,'anchor_reference_m':tuple(map(dec,anchor.position(absolute))),
            'maximum_m':policy['maximum_m'],
            'range_bracket_ms':tuple(dec(begin+x*1000) for x in bracket)}
        return absolute,payload

    def ended(self,payload):
        w=self.world
        if not w.projectiles.live(payload):return
        flight=w.projectile_flights[payload['projectile_id']];actor=w.fighters[flight['actor']]
        if actor.hp<=0 or actor.life_generation!=payload['anchor_life_generation']:return
        if any(abs(a-b)>D('1e-18') for a,b in zip(w.spatial_transitions.reference(actor.id),payload['anchor_reference_m'])):return
        point,_,_,distance=w.mobile_flight_state(flight,w.time)
        w.projectiles.terminal(flight,'removed',removed_at_ms=w.time,terminal_reason='maximum_anchor_distance',
            terminal_location_m=point,traveled_distance_m=distance)
        w.log('projectile_range_ended',**payload,location_m=point,traveled_distance_m=distance,creates_impact=False)
