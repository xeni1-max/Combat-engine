"""Resolved hand/weapon reach against solid material, separate from pose requests.

No body translation or action clock is written here. All users share the same
pure resolution at the current geometry: hand reports, Recovery, melee origins
and physical projectile release. See PRISON.md for the selected proxy rules.
"""
from dataclasses import dataclass
from decimal import Context,localcontext
from fractions import Fraction as F

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import UnsupportedMechanicError,as_fraction
from combat_sim.postures import world_posture_cuboids
from combat_sim.character_geometry import actor_body,crouch_target
from combat_sim.pose_kinematics import base_world_hand_point
from combat_sim.world_colliders import finite
from combat_sim.orientation import YawFrame


@dataclass(frozen=True)
class HandResolution:
    requested_m: tuple
    point_m: tuple
    anchor_m: tuple
    blocker: object = None


class HandReach:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.ready=False
        self.signature=None;self.bodies={};self.groups=();self.cache={}
        if self.enabled:
            if (not isinstance(definition,dict) or set(definition)!={'mode','radius_m','inset_m'} or
                    definition['mode']!='solid_hand_reach_v1' or not world.mobile_mode or not world.body_paths.enabled):
                raise UnsupportedMechanicError('Solid hand reach requires current saved body paths and solid_hand_reach_v1 rules')
            self.radius=finite(definition['radius_m'],'Hand reach radius',positive=True)
            self.inset=finite(definition['inset_m'],'Hand reach inset',positive=True)
            if self.inset>=self.radius/100:raise ValueError('Hand reach inset must be small relative to its radius')

    def attach(self):
        if self.enabled:
            self.ready=True;self.world.refresh_mobile_locomotion()

    def scene_signature(self):
        w=self.world
        rows=[]
        for n,a in sorted(w.fighters.items()):
            m=w.motion[n];balance=w.equilibrium.states.get(n)
            rows.append((n,a.life_generation,a.hp>0,a.facing,tuple(a.position_m),m['body_reference_z'],
                m.get('crouch_fraction'),tuple(sorted((m.get('pose_transition') or {}).items())),
                (balance.life_generation,balance.revision,balance.progress,balance.piece) if balance is not None else None))
        return w.time,w.collider_system.registry.epoch,tuple(rows)

    def body_boxes(self,name):
        w=self.world;a=w.fighters[name];reference=(*a.position_m,w.motion[name]['body_reference_z'])
        if w.equilibrium.carries(name):return w.equilibrium.boxes(name,reference)
        if w.posture_ready:
            return world_posture_cuboids(actor_body(w,name),reference,a.facing,w.posture_at(name,w.time)[0],
                crouch_target(w,name,w.crouch_definition['target_leg_height_m']))
        return w.world_bodies[name]

    def prepare(self):
        signature=self.scene_signature()
        if signature==self.signature:return
        w=self.world;self.signature=signature;self.cache.clear()
        self.bodies={n:self.body_boxes(n) for n,a in sorted(w.fighters.items()) if a.hp>0}
        groups=[('body',n,parts) for n,parts in self.bodies.items()]
        groups.extend(('collider',n,parts) for n,parts in sorted(w.body_terrain_colliders().items()))
        self.groups=tuple(groups)

    def resolve(self,actor,point):
        with localcontext(Context(prec=self.world.precision)):
            requested=tuple(map(as_fraction,base_world_hand_point(self.world,actor,point)))
            if not self.ready or actor.hp<=0:return HandResolution(requested,requested,requested)
            self.prepare();key=actor.id,requested
            if key in self.cache:return self.cache[key]
            anchor=tuple(map(as_fraction,next(b.centre_m for b in self.bodies[actor.id] if b.part=='torso')))
            result=HandResolution(requested,requested,anchor)
            if anchor!=requested:
                radius=as_fraction(self.radius)
                low=tuple(min(a,b)-radius for a,b in zip(anchor,requested))
                high=tuple(max(a,b)+radius for a,b in zip(anchor,requested))
                hits=[]
                for kind,name,parts in self.groups:
                    if kind=='body' and name==actor.id:continue
                    for box in parts:
                        if any(b<c or d<a for a,b,c,d in zip(low,high,*box.bounds)):continue
                        hit=box.swept_sphere_contact(anchor,requested,radius,precision=self.world.precision)
                        if hit is not None:hits.append((hit.parameter,kind,name,box.part,hit))
                if hits:
                    t,kind,name,part,hit=min(hits,key=lambda row:row[:4])
                    delta=tuple(b-a for a,b in zip(anchor,requested));length=dec(sum(v*v for v in delta)).sqrt()
                    back=as_fraction(self.inset)/as_fraction(length)
                    at=max(F(0),as_fraction(t)-back)
                    resolved=tuple(a+at*v for a,v in zip(anchor,delta))
                    blocker={'kind':kind,'id':name,'part':part}
                    if kind=='collider':blocker.update(self.world.collider_system.registry.contact_fields(name))
                    else:blocker['life_generation']=self.world.fighters[name].life_generation
                    result=HandResolution(requested,resolved,anchor,blocker)
            self.cache[key]=result;return result

    def point(self,actor,point):return self.resolve(actor,point).point_m

    def local_point(self,actor,point):
        """Resolved point in the fixed-facing upright reference frame.

        Keep common translation out of Recovery's exact squared differences.
        The canonical requested pose remains in actor.hands.
        """
        x,y,z=self.point(actor,point);rx,ry=map(as_fraction,actor.position_m)
        rz=as_fraction(self.world.motion[actor.id]['body_reference_z'])
        if isinstance(actor.facing,YawFrame):return actor.facing.to_local_point((x,y,z),(rx,ry,rz))
        if actor.facing=='+x':return (-(y-ry),x-rx,z-rz)
        if actor.facing=='-x':return (y-ry,-(x-rx),z-rz)
        raise UnsupportedMechanicError('Solid hand reach requires supported fixed body facing')

    def release_fields(self,actor,ability):
        if not self.ready:return {}
        hand=ability['projectile_geometry']['origin_hand']
        row=self.resolve(actor,ability['hand_positions_m']['start'][hand])
        if row.blocker is None:return {}
        return {'requested_origin_m':tuple(map(dec,row.requested_m)),
            'origin_constraint':{'anchor_m':tuple(map(dec,row.anchor_m)),'blocker':row.blocker,
                'inset_m':self.inset,'rule':'solid_hand_reach_v1'}}

    def result(self):
        return {'hand_reach_rules':self.world.combat_locomotion_input['hand_reach']} if self.enabled else {}
