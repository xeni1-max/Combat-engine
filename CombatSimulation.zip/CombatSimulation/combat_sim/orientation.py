"""Immutable upright body frames with exact rational metric preservation.

Heading zero faces world +x; local axes remain right/forward/up. Degree input
selects a deterministic rational unit frame at owned precision. Geometry after
that selection is exact relative to the stored frame, without normalization
drift. This module does not advance a turn or choose movement steering.
"""
from dataclasses import dataclass
from decimal import Context,Decimal as D,ROUND_HALF_EVEN,localcontext
from fractions import Fraction as F
from functools import lru_cache

from combat_sim.models import as_fraction
from combat_sim.mechanics.exact_ratio import ratio_text


def scalar(value):
    try:
        if isinstance(value,bool):raise ValueError
        return as_fraction(value)
    except (TypeError,ValueError,ArithmeticError) as error:
        raise ValueError('Orientation requires finite numeric coordinates') from error


def vector3(values):
    try:
        if isinstance(values,(str,bytes)):raise ValueError
        values=tuple(scalar(v) for v in values)
        if len(values)!=3:raise ValueError
        return values
    except (TypeError,ValueError) as error:
        raise ValueError('Orientation vectors require three finite coordinates') from error


def dot(first,second):
    return sum((a*b for a,b in zip(first,second)),F(0))


@dataclass(frozen=True)
class YawFrame:
    cosine: F = F(1)
    sine: F = F(0)

    def __post_init__(self):
        c,s=scalar(self.cosine),scalar(self.sine)
        if c*c+s*s!=1:raise ValueError('Yaw coefficients must form an exact unit pair')
        object.__setattr__(self,'cosine',c);object.__setattr__(self,'sine',s)

    @classmethod
    def from_half_angle_tangent(cls,tangent):
        t=scalar(tangent);denominator=1+t*t
        return cls((1-t*t)/denominator,2*t/denominator)

    @classmethod
    def from_degrees(cls,degrees,*,precision=50):
        if type(precision) is not int or precision<40:
            raise ValueError('Yaw precision must be an integer of at least 40 digits')
        return _degrees_frame(scalar(degrees)%360,precision)

    @property
    def forward(self):return self.cosine,self.sine,F(0)

    @property
    def right(self):return self.sine,-self.cosine,F(0)

    @property
    def basis(self):return self.right,self.forward,(F(0),F(0),F(1))

    def to_world_vector(self,value):
        x,y,z=vector3(value);c,s=self.cosine,self.sine
        return s*x+c*y,-c*x+s*y,z

    def to_local_vector(self,value):
        x,y,z=vector3(value);c,s=self.cosine,self.sine
        return s*x-c*y,c*x+s*y,z

    def to_world_point(self,value,origin=(0,0,0)):
        return tuple(a+b for a,b in zip(self.to_world_vector(value),vector3(origin)))

    def to_local_point(self,value,origin=(0,0,0)):
        return self.to_local_vector(tuple(a-b for a,b in zip(vector3(value),vector3(origin))))

    def record(self):
        return {'cosine':ratio_text(self.cosine),'sine':ratio_text(self.sine)}


def _atan(value,threshold):
    square=-value*value;power=value;total=value;n=1
    while True:
        power*=square;term=power/(2*n+1);total+=term;n+=1
        if abs(term)<threshold:return total


@lru_cache(maxsize=256)
def _degrees_frame(angle,precision):
    quarter=int((angle+45)//90);offset=angle-90*quarter
    c,s=((1,0),(0,1),(-1,0),(0,-1))[quarter%4]
    if not offset:return YawFrame(c,s)
    with localcontext(Context(prec=precision+16,rounding=ROUND_HALF_EVEN)):
        threshold=D(1).scaleb(-(precision+16))
        pi=16*_atan(D(1)/5,threshold)-4*_atan(D(1)/239,threshold)
        half=(D(offset.numerator)/D(offset.denominator))*pi/360
        square=half*half;st=half;ct=D(1);sine=st;cosine=ct;n=1
        while max(abs(st),abs(ct))>=threshold:
            st=-st*square/((2*n)*(2*n+1))
            ct=-ct*square/((2*n-1)*(2*n))
            sine+=st;cosine+=ct;n+=1
        base=YawFrame.from_half_angle_tangent(sine/cosine)
    return YawFrame(c*base.cosine-s*base.sine,s*base.cosine+c*base.sine)
