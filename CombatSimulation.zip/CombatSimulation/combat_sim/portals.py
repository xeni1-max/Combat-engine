"""Authored allied portal pairs and voluntary atomic body transport.

The pair is released world state. Use is an explicit environmental command,
with per-life user reuse clocks in the shared cooldown book; it adds no new
character ability, effort owner, ammunition or resource debit.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.life import life_generation
from combat_sim.models import UnsupportedMechanicError
from combat_sim.spatial_transitions import SpatialChange
from combat_sim.world_colliders import finite

COMMANDS=('use_portal',)
EXPIRY='portal_pair_expired'


class PortalPairs:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        self.ids=count(1);self.use_ids=count(1)
        self.pairs={};self.deployments=[];self.uses=[];self.clocks={}
        if self.enabled and (definition!={'mode':'allied_transport_v1'} or not world.mobile_mode):
            raise UnsupportedMechanicError('Portal pairs require current moving combat')

    def validate(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id];cfg=a.get('portal_pair')
        if not (self.enabled and w.spatial_transitions.enabled and w.body_support.enabled and
                w.life_cycles.enabled and w.cooldown_system.enabled and w.effort_system.enabled and actor.action_registry is not None):
            raise UnsupportedMechanicError('Portals need owned lives, atomic body transport and shared cooldown work')
        if (not isinstance(cfg,dict) or set(cfg)!={'maximum_m','duration_ms','reuse_ms','use_radius_m'}
                or a.get('dyspnea',{}).get('kind')!='none' or a.get('deployment_timing')!='active_end'
                or a.get('cooldown_anchor')!='activation_start'):
            raise UnsupportedMechanicError('Portals need independent no-effort pair deployment and explicit limits')
        for key,value in cfg.items():finite(value,'Portal '+key,positive=True)
        finite(a['cooldown_ms'],'Portal cast cooldown',positive=True)

    def feet(self,name):
        w=self.world;a=w.fighters[name]
        return (*tuple(map(dec,a.position_m)),dec(min(b.bounds[0][2] for b in w.world_bodies[name])))

    def selected(self,actor,action):
        if action.target_snapshot is not None:return
        origin=self.feet(actor.id);point=self.feet(action.target)
        delta=tuple(b-a for a,b in zip(origin,point));length=sum(v*v for v in delta).sqrt()
        maximum=dec(actor.profile['abilities'][action.ability_id]['portal_pair']['maximum_m'])
        if length>maximum:
            scale=maximum/length
            point=tuple(a+v*scale for a,v in zip(origin,delta))
            # Round automatic normalization inward by representable steps,
            # only when the resulting point exceeds the exact limit. Explicit
            # targets remain exact and receive the ordinary release check.
            while sum((a-b)**2 for a,b in zip(origin,point))>maximum**2:
                scale=scale.next_minus()
                point=tuple(a+v*scale for a,v in zip(origin,delta))
        action.aim_location_m=point

    def deploy(self,actor,action,ability):
        w=self.world;cfg=deepcopy(ability['portal_pair']);origin=self.feet(actor.id)
        target=tuple(map(dec,action.aim_location_m));distance=sum((a-b)**2 for a,b in zip(origin,target))
        attempt=dict(actor=actor.id,ability=action.ability_id,action_id=action.id,
            source_life_generation=action.life_generation,at_ms=w.time,origin_m=origin,target_m=target,
            definition=cfg,status='rejected',reason=None)
        if distance>dec(cfg['maximum_m'])**2:
            attempt['reason']='target_out_of_range_at_release';self.deployments.append(attempt)
            w.log('portal_deployment_resolved',**deepcopy(attempt));return None
        identity='portal-pair:'+str(next(self.ids))
        row=dict(id=identity,actor=actor.id,ability=action.ability_id,action_id=action.id,
            source_life_generation=action.life_generation,team=actor.team,definition=cfg,
            endpoints_m=(origin,target),deployed_at_ms=w.time,expiry_ms=w.time+dec(cfg['duration_ms']),
            status='active',autonomous=True)
        self.pairs[identity]=row
        w.push(row['expiry_ms'],EXPIRY,{'portal_id':identity})
        attempt.update(status='deployed',portal_id=identity);self.deployments.append(attempt)
        w.log('portal_pair_deployed',**deepcopy(row));return identity

    def validate_control(self,actor,portal_id=None):
        if not self.enabled or actor not in self.world.fighters:
            raise ValueError('Portal use needs enabled portals and a known actor')
        if portal_id is not None and (not isinstance(portal_id,str) or not portal_id):
            raise ValueError('Portal identity must be a nonempty string')

    def live(self,row):return row['status']=='active' and self.world.time<row['expiry_ms']

    @staticmethod
    def clock_key(pair,name,generation):return pair,name,generation

    @staticmethod
    def clock_name(pair,generation):return 'portal-use:'+pair+':life:'+str(generation)

    def _ready(self,pair,name):
        a=self.world.fighters[name];key=self.clock_key(pair,name,a.life_generation)
        if key not in self.clocks or self.clocks[key]['status']!='active':return self.world.time
        return self.world.cooldown_system.background_ready_at(a,self.clocks[key]['clock_key'])

    def _start_clock(self,pair,name):
        w=self.world;a=w.fighters[name];key=self.clock_key(pair['id'],name,a.life_generation)
        if key not in self.clocks:
            clock_name=self.clock_name(pair['id'],a.life_generation)
            w.cooldown_system.register_background(a,clock_name)
            self.clocks[key]=dict(portal_id=pair['id'],actor=name,life_generation=a.life_generation,
                clock_key=clock_name,status='active')
        row=self.clocks[key];clock=a.cooldowns.clocks[row['clock_key']]
        clock.start(w.time,pair['definition']['reuse_ms'])
        w.log('portal_reuse_started',portal_id=pair['id'],actor=name,life_generation=a.life_generation,
            clock=clock.record(w.time),environmental_interaction=True)

    def use(self,actor,*,portal_id=None,expected_life_generation=None):
        with localcontext(Context(prec=self.world.precision)):
            return self._use(actor,portal_id,expected_life_generation)

    def _use(self,name,portal_id,expected_life_generation):
        self.validate_control(name,portal_id)
        w=self.world;a=w.fighters[name]
        generation=a.life_generation if expected_life_generation is None else life_generation(expected_life_generation)
        if generation is None:raise ValueError('Portal use needs an expected actor life')
        attempt=dict(id='portal-use:'+str(next(self.use_ids)),actor=name,expected_life_generation=generation,
            at_ms=w.time,requested_portal_id=portal_id,status='rejected',reason=None)
        self.uses.append(attempt)
        def finish(status,reason=None,**fields):
            attempt.update(status=status,reason=reason,**fields)
            w.log('portal_use_resolved',**deepcopy(attempt))
            return deepcopy(attempt)
        if a.hp<=0 or a.life_generation!=generation:return finish('ignored','actor_life_ended')
        if w.bindings.control_blocked(a,'portal_use'):return finish('rejected','whole_body_binding')
        point=self.feet(name);choices=[]
        for row in self.pairs.values():
            if not self.live(row) or row['team']!=a.team or portal_id is not None and row['id']!=portal_id:continue
            for index,origin in enumerate(row['endpoints_m']):
                distance=sum((x-y)**2 for x,y in zip(point,origin))
                if distance<=dec(row['definition']['use_radius_m'])**2:choices.append((distance,row['id'],index))
        if not choices:return finish('rejected','no_nearby_allied_portal')
        _,identity,index=min(choices);pair=self.pairs[identity]
        group=w.grapple_links.group(name)
        readiness={n:self._ready(identity,n) for n in group}
        waits={n:t for n,t in readiness.items() if t>w.time}
        if waits:
            return finish('rejected','reuse_not_ready',portal_id=identity,entry=index,
                ready_at_ms={n:t if t.is_finite() else None for n,t in waits.items()})
        origin,target=pair['endpoints_m'][index],pair['endpoints_m'][1-index]
        delta=tuple(b-a for a,b in zip(origin,target))
        reference=w.spatial_transitions.reference(name)
        try:
            plan=w.spatial_transitions.prepare_transport((SpatialChange(name,generation,
                reference_m=tuple(p+d for p,d in zip(reference,delta))),),source=identity)
        except (ValueError,UnsupportedMechanicError) as error:
            return finish('rejected','exit_unavailable',portal_id=identity,entry=index,detail=str(error))
        # Commit errors propagate: they are not a safely rejected preflight.
        transition=w.spatial_transitions.commit(plan)
        if transition is None:return finish('unchanged','coincident_endpoints',portal_id=identity,entry=index)
        for body in plan.bodies:self._start_clock(pair,body.actor)
        return finish('used',portal_id=identity,entry=index,exit=1-index,translation_m=delta,
            transported_actors=[b.actor for b in plan.bodies],transition_id=transition['id'])

    def _end_clock(self,key,reason):
        row=self.clocks[key]
        if row['status']!='active':return
        a=self.world.fighters[row['actor']];clock=a.cooldowns.clocks.pop(row['clock_key'])
        row.update(status='ended',ended_at_ms=self.world.time,end_reason=reason,final_clock=clock.record(self.world.time))

    def retire_life(self,actor):
        for key,row in self.clocks.items():
            if row['actor']==actor.id and row['life_generation']==actor.life_generation:self._end_clock(key,'user_life_ended')

    def event_live(self,p):
        row=self.pairs.get(p['portal_id']);return row is not None and row['status']=='active'

    def expire(self,p):
        if not self.event_live(p):return
        row=self.pairs[p['portal_id']];row.update(status='expired',ended_at_ms=self.world.time)
        for key,clock in self.clocks.items():
            if clock['portal_id']==row['id']:self._end_clock(key,'pair_expired')
        self.world.log('portal_pair_expired',portal_id=row['id'])

    def result(self):
        if not self.enabled:return {}
        clocks=[]
        for row in self.clocks.values():
            value=deepcopy(row)
            if row['status']=='active':value['clock']=self.world.fighters[row['actor']].cooldowns.clocks[row['clock_key']].record(self.world.time)
            clocks.append(value)
        return {'portal_rules':deepcopy(self.world.combat_locomotion_input['portals']),
            'portal_pairs':deepcopy(list(self.pairs.values())),'portal_deployments':deepcopy(self.deployments),
            'portal_uses':deepcopy(self.uses),'portal_reuse_clocks':clocks}
