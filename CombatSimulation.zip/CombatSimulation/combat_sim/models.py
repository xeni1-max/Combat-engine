"""Data types shared by the event runner and individual mechanics."""

from dataclasses import dataclass
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from fractions import Fraction
from typing import Any
from combat_sim.exact import ExactAmount, number_record


class UnsupportedMechanicError(ValueError):
    """Raised when a scenario asks for a rule this stage does not implement."""


def as_fraction(value: Any) -> Fraction:
    """Parse integers and decimal strings without introducing binary float error."""
    if isinstance(value, Fraction):
        return value
    if isinstance(value, float):
        return Fraction(str(value))
    return Fraction(value)


def fraction_record(value: Fraction) -> dict[str, str]:
    """Retain the existing rational-record API and fixed display precision."""
    return number_record(value)


@dataclass
class StatusState:
    disorientation: Decimal
    instability: Decimal

    @classmethod
    def from_mapping(cls, values: dict[str, Any]) -> "StatusState":
        amounts = []
        for name in ("disorientation", "instability"):
            value = as_fraction(values.get(name, 0))
            if value < 0:
                raise ValueError(f"Initial {name} must be nonnegative")
            with localcontext(Context(prec=40, rounding=ROUND_HALF_EVEN)):
                amounts.append(Decimal(value.numerator) / Decimal(value.denominator))
        return cls(*amounts)

    def to_record(self) -> dict[str, dict[str, str]]:
        # Mitigation has a fractional exponent, evaluated at fixed precision.
        # Decimal status values are not labeled exact rational game values.
        return {
            "disorientation": {"decimal": str(self.disorientation)},
            "instability": {"decimal": str(self.instability)},
        }


@dataclass
class CharacterState:
    hp: Fraction | ExactAmount
    armor: Fraction
    shield: Fraction
    statuses: StatusState | None = None

    @classmethod
    def from_mapping(cls, values: dict[str, Any], *, track_statuses: bool = False) -> "CharacterState":
        required = {"hp", "armor", "shield"}
        missing = required.difference(values)
        if missing:
            raise ValueError(f"Character state is missing: {', '.join(sorted(missing))}")
        allowed = required | ({"disorientation", "instability"} if track_statuses else set())
        unsupported = set(values) - allowed
        if unsupported:
            raise UnsupportedMechanicError(
                "Initial state fields are not implemented by this combat stage: "
                + ", ".join(sorted(unsupported))
            )
        state = cls(
            hp=as_fraction(values["hp"]),
            armor=as_fraction(values["armor"]),
            shield=as_fraction(values["shield"]),
            statuses=StatusState.from_mapping(values) if track_statuses else None,
        )
        if state.hp < 0 or state.armor < 0 or state.shield < 0:
            raise ValueError("Initial HP, armor, and shield must be nonnegative")
        return state

    def to_record(self) -> dict[str, Any]:
        record = {
            "hp": number_record(self.hp),
            "armor": fraction_record(self.armor),
            "shield": fraction_record(self.shield),
        }
        if self.statuses is not None:
            record.update(self.statuses.to_record())
        return record


@dataclass
class WeaponState:
    """Weapon-local resources and automatic cooldown, independent of actor state."""

    ammo: int
    capacity: int
    cooldown_ready_at_ms: int = 0
    reload_phase: str = 'none'

    def __post_init__(self):
        if any(isinstance(v, bool) or not isinstance(v, int) for v in (self.ammo, self.capacity)) or self.capacity <= 0 or not 0 <= self.ammo <= self.capacity:
            raise ValueError('Magazine capacity must be positive and ammo must be an integer within capacity')

    def to_record(self, time_ms):
        return {'ammo': self.ammo, 'magazine_capacity': self.capacity,
                'cooldown_ready_at_ms': self.cooldown_ready_at_ms, 'reload_phase': self.reload_phase,
                'can_fire_weapon': self.ammo > 0 and self.reload_phase == 'none' and time_ms >= self.cooldown_ready_at_ms}
