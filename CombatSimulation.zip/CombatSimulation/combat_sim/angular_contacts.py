"""Continuous box-path and curved-sphere queries for prescribed upright yaw.

Interval enclosures reject empty time ranges. Only actual oriented geometry
confirms a contact. An unresolved near-tangent range or exhausted search budget
fails explicitly; neither becomes a silent miss. These geometry queries do
not select eligible combat targets, apply impulses or own action lifetimes.
"""
from dataclasses import dataclass,replace
from fractions import Fraction as F
from math import isfinite

from combat_sim.angular_paths import RotatingBoxPath
from combat_sim.gravity_collisions import first_contact
from combat_sim.hitboxes import Cuboid
from combat_sim.models import UnsupportedMechanicError
from combat_sim.mechanics.kinematic_bounds import quadratic_range
from combat_sim.orientation import scalar, dot
from combat_sim.oriented_geometry import OrientedCuboid, WORLD_AXES, boxes_overlap, projected_size, separating_axes
from combat_sim.terrain import RectangularGround


@dataclass(frozen=True)
class BoxPathContact:
    time_lower_s: F
    time_upper_s: F
    first_box: object
    second_box: object


def _shape(path, time):
    return path.at_time(time) if isinstance(path, RotatingBoxPath) else path


def _projection(path, axis, begin, end):
    if isinstance(path, RotatingBoxPath):
        return path.projection_range(axis, begin, end)
    centre, half = dot(path.centre_m, axis), projected_size(path, axis)/2
    return centre-half, centre+half


def _relative_bounds(first,second,begin):
    """Cancel shared reference motion before bounding two moving shapes.

    Independent swept enclosures cannot reject a touching, co-falling pair:
    each sweeps through the other's earlier position. This additional bound
    retains both original paths for actual contact confirmation.
    """
    zero=(F(0),)*3
    local=tuple(replace(p,reference=replace(p.reference,reference_m=zero,velocity_mps=zero,acceleration_mps2=zero))
                for p in (first,second))
    p=tuple(x-y for x,y in zip(first.reference.position(begin*1000),second.reference.position(begin*1000)))
    v=tuple(x-y for x,y in zip(first.reference.velocity(begin*1000),second.reference.velocity(begin*1000)))
    a=tuple(x-y for x,y in zip(first.reference.acceleration_mps2,second.reference.acceleration_mps2))
    vertical=tuple(tuple(x-y for x,y in zip(first.vertical_face_coefficients(s,begin),second.vertical_face_coefficients(-s,begin)))
                   for s in (-1,1))
    def bounds(axis,left,right):
        if not axis[0] and not axis[1]:
            low=quadratic_range(*vertical[0],left-begin,right-begin)[0]
            high=quadratic_range(*vertical[1],left-begin,right-begin)[1]
            return tuple(sorted((low*axis[2],high*axis[2])))
        lo,hi=quadratic_range(dot(p,axis),dot(v,axis),dot(a,axis),left-begin,right-begin)
        x,y=(_projection(path,axis,left,right) for path in local)
        return lo+x[0]-y[1],hi+x[1]-y[0]
    return bounds


def box_path_contact(first, second, begin_s, end_s, *, time_tolerance_s=F(1, 10**12), node_limit=100000,
                     minimum_overlap_m=0):
    """First closed-box overlap within an explicit absolute-time interval.

    A time bracket encloses the first possible contact and ends at a confirmed
    overlap. Constant cuboids and saved rotating/resizing box paths may mix.
    This is geometric contact; closing/grazing response is the caller's policy.
    """
    if any(not isinstance(path, (Cuboid, OrientedCuboid, RotatingBoxPath, RectangularGround)) for path in (first, second)):
        raise ValueError('Box path contact requires cuboids or saved rotating box paths')
    begin, end, tolerance = map(scalar, (begin_s, end_s, time_tolerance_s))
    depth = scalar(minimum_overlap_m)
    if begin < 0 or end < begin or tolerance <= 0 or depth < 0 or type(node_limit) is not int or node_limit <= 0:
        raise ValueError('Invalid box path contact controls')
    for path in (first, second):
        if isinstance(path, RotatingBoxPath):
            path._validate_interval(begin, end)
    relative=_relative_bounds(first,second,begin) if all(isinstance(p,RotatingBoxPath) for p in (first,second)) else None
    def overlap(time):
        a, b = _shape(first, time), _shape(second, time)
        if not depth:return (a, b) if boxes_overlap(a, b) else None
        delta = tuple(x-y for x, y in zip(a.centre_m, b.centre_m))
        return (a, b) if all((projected_size(a,n)+projected_size(b,n))/2-abs(dot(delta,n)) >= depth
                             for n in separating_axes(a,b)) else None

    remaining, pending = node_limit, [(begin, end)]
    while pending:
        left, right = pending.pop()
        remaining -= 1
        if remaining < 0:
            raise UnsupportedMechanicError('Angular contact search budget exhausted: refine the query interval')
        touching = overlap(left)
        if touching is not None:
            return BoxPathContact(left, left, *touching)
        mid = (left+right)/2
        middle = _shape(first, mid), _shape(second, mid)
        # SAT axes at an interior time are fixed during this bound query.
        # Enclosures contain *all* vertices across the full interval; this is
        # not a stationary SAT test at the midpoint or an AABB hit substitute.
        separated = False
        for axis in dict.fromkeys((*WORLD_AXES, *separating_axes(*middle))):
            a, b = _projection(first, axis, left, right), _projection(second, axis, left, right)
            if a[1]-b[0] < depth or b[1]-a[0] < depth:
                separated = True
                break
            if relative is not None:
                low,high=relative(axis,left,right)
                if high<depth or -low<depth:
                    separated=True
                    break
        if separated:
            continue
        if right-left <= tolerance:
            for time in (mid, right):
                touching = overlap(time)
                if touching is not None:
                    return BoxPathContact(left, time, *touching)
            raise UnsupportedMechanicError('Near-tangent or unresolved angular contact: tighten numerical controls')
        # Iterative chronological subdivision avoids Python recursion limits
        # becoming an undocumented numerical or temporal resolution limit.
        pending.extend(((mid, right), (left, mid)))
    return None


class _FlightWindow:
    def __init__(self, trajectory, begin, end):
        self.trajectory, self.begin, self.end = trajectory, begin, end
        self.gravity, self.deceleration = trajectory.gravity, trajectory.deceleration
        knots = (begin, *(state.time_s for state in trajectory.states if begin < state.time_s < end), end)
        self.states = tuple(trajectory.at(time) for time in dict.fromkeys(knots))

    def at(self, time):
        if not self.begin <= time <= self.end:
            raise ValueError('Angular contact query lies outside its flight window')
        return self.trajectory.at(time)


def rotating_curve_contact(trajectory, path, radius_m, begin_s, end_s, *,
                           time_tolerance_s=1e-12, clearance_tolerance_m=1e-14, confirm_near_entry=False):
    """Query the original immutable world flight against a rotating box.

    World centre/surface coordinates and the flight's original traveled-distance
    brackets are retained. Its numerical trajectory uses the existing binary64
    curved-contact contract; rational shape enclosures do not certify that ODE.
    """
    if not isinstance(path, RotatingBoxPath):
        raise ValueError('Angular curve contact requires a saved rotating box path')
    begin, end = scalar(begin_s), scalar(end_s)
    path._validate_interval(begin, end)
    left, right = float(begin), float(end)
    if not all(map(isfinite, (left, right))) or not 0 <= left <= right <= trajectory.duration:
        raise ValueError('Angular contact interval must lie within the original flight horizon')
    # The existing flight backend uses binary64 clocks. Do not silently extend
    # a rational path lease when converting an explicit endpoint for that API.
    path._validate_interval(scalar(left), scalar(right))
    return first_contact(_FlightWindow(trajectory, left, right), (path,), radius_m,
                         time_tolerance_s=time_tolerance_s, clearance_tolerance_m=clearance_tolerance_m,
                         confirm_near_entry=confirm_near_entry)
