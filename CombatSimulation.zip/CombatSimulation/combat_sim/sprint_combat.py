"""Existing sprint transitions and continuous effort on the shared combat clock."""
from decimal import Decimal as D

from combat_sim.battle_models import BattleAction, decimal_value as dec
from combat_sim.mechanics.dyspnea import DyspneaContext, apply_action_dyspnea, advance_continuous_action_dyspnea
from combat_sim.mechanics.recovery import hand_recovery
from combat_sim.pose_kinematics import physical_hand_recovery
from combat_sim.models import UnsupportedMechanicError
from combat_sim.command_dispatch import IntentOutcome


class SprintCombatRules:
    def setup_mobile_combat(self, definition, effects):
        self.sprint_combat = effects.get('sprint') if effects else None
        if self.sprint_combat is not None:
            expected = {'continuous_interval':'entry_active_through_exit_active',
                'weapon_actions_allowed':False, 'exhaustion':'special_stop',
                'unaffordable_exit':'special_stop', 'inherits_running_modifiers':True,
                'hand_recovery':'before_active', 'end_pose':'start_pose'}
            if any(self.sprint_combat.get(k) != v for k,v in expected.items()):
                raise UnsupportedMechanicError('Unsupported sprint combat rule')
            sprint = definition.get('sprint', {})
            if sprint.get('attacks_allowed') is not False or sprint.get('speed_curve') != 'linear_during_active':
                raise UnsupportedMechanicError('Sprint requires the authored attack restriction and linear transition')
            for actor in self.fighters.values():
                p = sprint.get('characters', {}).get(actor.profile_id)
                if p is None:
                    raise UnsupportedMechanicError('Missing sprint character definition')
                if any(dec(p[k]) <= 0 for k in ('speed_bonus_mps','run_sprint_active_ms','base_continuous_dyspnea_per_second')):
                    raise ValueError('Sprint speed, duration and continuous base cost must be positive')
                if any(dec(p[k]) < 0 for k in ('self_disorientation_on_transition','self_instability_on_transition','listed_transition_dyspnea_value')):
                    raise ValueError('Sprint transition costs and statuses cannot be negative')
                poses = self.sprint_combat['hand_positions_m'][actor.profile_id]
                hand_recovery(actor.hands, poses, actor.profile['recovery_value'])
        super().setup_mobile_combat(definition, effects)
        if self.sprint_combat is not None:
            for actor in self.fighters.values():
                self.motion[actor.id]['sprint_anchor'] = None
                actor.metrics.update(sprint_transitions=0, sprint_exhaustions=0, sprint_dyspnea_gained=D(0))

    def mobile_is_running(self, name):
        return super().mobile_is_running(name) or (self.sprint_combat is not None and self.motion[name]['mode']=='sprinting')

    def mobile_sprint_effort(self, name):
        if self.sprint_combat is None:
            return False
        m = self.motion[name]
        return (self.fighters[name].hp > 0 and m['phase'] != 'stopping_active' and
                (m['mode']=='sprinting' or (m['phase']=='transition_active' and m.get('target_mode')=='sprinting')))

    def mobile_weapon_blocked(self, actor):
        return self.mobile_sprint_effort(actor.id)

    def mobile_dyspnea_context(self, actor):
        context = super().mobile_dyspnea_context(actor)
        if self.mobile_sprint_effort(actor.id):
            return DyspneaContext('sprinting', context.disoriented, context.unstable,
                context.on_grapple_ability, context.active, context.gathering, context.recovering)
        return context

    def resource_ready_time(self, actor, rule):
        if (self.mobile_mode and self.mobile_sprint_effort(actor.id) and rule['kind']!='none' and
                not apply_action_dyspnea(actor.dyspnea, rule['base_value']).allowed):
            return D('Infinity')
        return super().resource_ready_time(actor, rule)

    def _sprint_values(self, actor):
        return self.movement_definition['sprint']['characters'][actor.profile_id]

    def _sprint_cap_time(self, actor):
        start, initial = self.motion[actor.id]['sprint_anchor']
        base = dec(self._sprint_values(actor)['base_continuous_dyspnea_per_second'])
        return start+100000*(1/(base+initial/100)-1/(base+1))

    def next_mobile_knot(self, end):
        finish = super().next_mobile_knot(end)
        for actor in self.fighters.values():
            if self.mobile_sprint_effort(actor.id):
                finish = min(finish, max(self.time, self._sprint_cap_time(actor)))
        return finish

    def advance_sprint_dyspnea(self, actor, begin, end):
        start, initial = self.motion[actor.id]['sprint_anchor']
        base = dec(self._sprint_values(actor)['base_continuous_dyspnea_per_second'])
        before = actor.dyspnea
        # Evaluate from an effort/payment anchor, never by accumulating samples.
        actor.dyspnea = (D(100) if end >= self._sprint_cap_time(actor) else
            advance_continuous_action_dyspnea(initial, base, end-start,
                context=DyspneaContext('sprinting')).after)
        gain = actor.dyspnea-before
        actor.metrics['sprint_dyspnea_gained'] += gain
        if gain:
            self.log('sprint_dyspnea_gained', actor=actor.id, interval_start_ms=begin,
                interval_end_ms=end, amount=gain, after=actor.dyspnea, base_rate_per_second=base)
        if before < 100 and actor.dyspnea == 100:
            self._schedule_sprint_exhaustion(actor)

    def _schedule_sprint_exhaustion(self, actor):
        self.push(self.time,'movement_sprint_exhausted',{'actor':actor.id},priority=4)

    def request_sprint_transition(self, actor, command):
        m = self.motion[actor.id]
        if command=='sprint' and m['mode']=='sprinting':
            self.log('movement_command_no_change',actor=actor.id,action=command)
            return IntentOutcome.CONSUMED
        values = self._sprint_values(actor)
        rule = {'kind':'action','base_value':values['listed_transition_dyspnea_value']}
        ready = self.resource_ready_time(actor, rule)
        if ready > self.time:
            if m['mode']=='sprinting':
                self.log('sprint_exit_fallback',actor=actor.id,requested_action=command,reason='insufficient_capacity')
                return IntentOutcome.STOP_FALLBACK
            if ready.is_finite():
                self.request_decision(actor.id,ready)
            self.log('movement_waiting_for_capacity',actor=actor.id,action=command,resume_at_ms=ready)
            return IntentOutcome.WAITING
        poses = self.sprint_combat['hand_positions_m'][actor.profile_id]
        recovery, calculation = physical_hand_recovery(self,actor,actor.hands,poses,dec(actor.profile['recovery_value'])*D('1.2'))
        duration = dec(values['run_sprint_active_ms'])
        action = BattleAction(next(self.action_ids),actor.id,actor.id,command,'locomotion',
            self.time,self.time+recovery,duration,phase='recovery',recovery_end_ms=self.time+recovery)
        actor.current = action
        self.log('sprint_transition_requested',actor=actor.id,action=command,action_id=action.id,
            recovery_ms=recovery,individual_hands=calculation,recovery_end_ms=action.recovery_end_ms)
        self._schedule_phase(action,'recovery_completed',action.recovery_end_ms)
        return IntentOutcome.STARTED

    def complete_sprint_recovery(self, actor):
        m, action = self.motion[actor.id], actor.current
        values = self._sprint_values(actor)
        poses = self.sprint_combat['hand_positions_m'][actor.profile_id]
        actor.hands.update(poses)
        payment = self.action_payment(actor,action,values['listed_transition_dyspnea_value'])
        if not payment.allowed:
            self.note_action_cancelled(actor,action,'insufficient_capacity_after_recovery')
            actor.current = None
            self.block_mobile_intent(actor,'insufficient_capacity_after_recovery')
            self.log('sprint_exit_fallback',actor=actor.id,requested_action=action.ability_id,
                reason='insufficient_capacity_after_recovery')
            self.queue_mobile_intent(actor,'stop',front=True)
            return self.try_mobile_intent(actor)
        actor.dyspnea = dec(payment.after)
        actor.metrics['dyspnea_paid'] += dec(payment.action_value)
        self.log('dyspnea_paid',actor=actor.id,ability=action.ability_id,action_id=action.id,
            action_kind='locomotion',phase='active_start',before=dec(payment.before),
            amount=dec(payment.action_value),after=actor.dyspnea)
        target = dec(self.movement_definition['characters'][actor.profile_id]['running_speed_mps'])
        entering = action.ability_id=='sprint'
        if entering:
            target += dec(values['speed_bonus_mps'])
        factor = dec(self.combat_locomotion_definition['running_self_effect_multiplier'])
        additions = {k:dec(values['self_'+k+'_on_transition'])*factor for k in ('disorientation','instability')}
        for key, amount in additions.items():
            setattr(actor,key,getattr(actor,key)+amount)
        duration = dec(values['run_sprint_active_ms'])
        m.update(acceleration=(target-m['speed'])/(duration/1000),phase='transition_active',
            target_mode='sprinting' if entering else 'running',target_speed=target,
            sprint_anchor=(self.time,actor.dyspnea))
        action.phase='active'
        action.active_end_ms=self.time+duration
        self.extend_parallel_gatherings(actor,additions['disorientation'],action.id)
        actor.metrics['sprint_transitions'] += 1
        self.refresh_mobile_locomotion()
        self.log('movement_active_started',actor=actor.id,action=action.ability_id,action_id=action.id,
            active_end_ms=action.active_end_ms,self_effects=additions,nominal_target_speed_mps=target)
        self._schedule_phase(action,'active_completed',action.active_end_ms)
        if payment.reached_maximum:
            self._schedule_sprint_exhaustion(actor)

    def process_mobile_event(self, kind, payload):
        if kind!='movement_sprint_exhausted':
            return super().process_mobile_event(kind,payload)
        actor = self.fighters[payload['actor']]
        if actor.hp <= 0:
            return
        # This event follows interval status decay, same-time phases and impacts.
        added = D(200)*dec(self.combat_locomotion_definition['running_self_effect_multiplier'])
        actor.disorientation += added
        actor.metrics['sprint_exhaustions'] += 1
        self.log('maximum_dyspnea_trigger',actor=actor.id,added_disorientation=added,source='sprint')
        m = self.motion[actor.id]
        if self.mobile_sprint_effort(actor.id):
            if actor.current is not None:
                self.log('movement_active_cancelled',actor=actor.id,action_id=actor.current.id,reason='sprint_exhaustion')
                self.note_action_cancelled(actor,actor.current,'sprint_exhaustion')
                actor.current=None
            self.queue_mobile_intent(actor,'stop',front=True)
            self.try_mobile_intent(actor)
        else:
            self.request_decision(actor.id,self.time)
        self.refresh_mobile_locomotion()
