"""Continuous numerical entry of a projectile centre into a radial volume.

Curved paths use acceleration-bounded chord enclosures, with the same
binary64/explicit-ambiguity contract as physical curved contacts. Caller owns
projectile radius expansion, allegiance, lifetime, event rounding and ties.
"""
from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from math import hypot, isfinite, nextafter

from combat_sim.models import UnsupportedMechanicError


@dataclass(frozen=True)
class VolumeEntry:
    time_lower_s: float
    time_upper_s: float


def first_radial_entry(trajectory, centre, radius_m, begin_s, end_s, *, dimensions=2,
        acceleration_bound_mps2=0, time_tolerance_s=1e-12, clearance_tolerance_m=1e-14):
    """First closed disk/ball entry; no endpoint-only membership sampling.

``trajectory`` exposes at(t).position_m, duration and optional immutable times.
No-contact intervals are conservatively rejected using bounded acceleration;
an actual inside witness confirms entry. Unresolved near tangency raises.
"""
    values=(radius_m,begin_s,end_s,acceleration_bound_mps2,time_tolerance_s,clearance_tolerance_m)
    if dimensions not in (2,3) or isinstance(dimensions,bool) or any(isinstance(v,bool) for v in values):
        raise ValueError('Radial entry needs numeric controls and two or three dimensions')
    radius,begin,end,bound,tolerance,clearance=map(float,values)
    centre=tuple(centre)
    if (len(centre)!=dimensions or any(isinstance(v,bool) for v in centre)
            or not all(isfinite(float(v)) for v in centre)):
        raise ValueError('Radial centre needs finite coordinates')
    centre=tuple(map(float,centre))
    if (not all(isfinite(v) for v in (radius,begin,end,bound,tolerance,clearance))
            or radius<=0 or begin<0 or end<begin or end>trajectory.duration or bound<0 or tolerance<=0 or clearance<0):
        raise ValueError('Invalid radial entry interval, radius or tolerances')

    def point(time):
        return tuple(float(p)-c for p,c in zip(trajectory.at(time).position_m,centre))

    def inside(time):
        return hypot(*point(time))<=radius

    def possible(left,right):
        p,q=point(left),point(right)
        delta=tuple(b-a for a,b in zip(p,q));length=sum(d*d for d in delta)
        u=min(1.,max(0.,-sum(a*d for a,d in zip(p,delta))/length)) if length else 0.
        gap=hypot(*(a+u*d for a,d in zip(p,delta)))
        return gap<=radius+bound*(right-left)**2/8+clearance

    def search(left,right,interval_end):
        if inside(left):return VolumeEntry(left,left)
        if not possible(left,right):return None
        if right-left<=tolerance:
            if inside(right):return VolumeEntry(left,right)
            middle=(left+right)/2
            if inside(middle):return VolumeEntry(left,middle)
            confirmed=min(interval_end,left+tolerance)
            while confirmed-left>tolerance:confirmed=nextafter(confirmed,left)
            if confirmed>right and inside(confirmed):return VolumeEntry(left,confirmed)
            raise UnsupportedMechanicError('Near-tangent or unresolved projectile-volume entry: tighten numerical controls')
        middle=(left+right)/2
        if middle in (left,right):
            raise UnsupportedMechanicError('Projectile-volume entry cannot be resolved at numerical precision')
        return search(left,middle,interval_end) or search(middle,right,interval_end)

    if begin==end:return VolumeEntry(begin,begin) if inside(begin) else None
    times=getattr(trajectory,'times',())
    knots=(begin,*times[bisect_right(times,begin):bisect_left(times,end)],end)
    for left,right in zip(knots,knots[1:]):
        found=search(left,right,right)
        if found is not None:return found
    return None
