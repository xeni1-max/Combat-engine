"""Pure, replaceable enemy selection over an immutable world snapshot.

Policies choose identities only. The encounter owns legality, action resources,
movement and release snapshots. Horizontal distance retains the original
nearest-enemy convention; altitude is not a new implicit policy input.
"""
from dataclasses import dataclass
from types import MappingProxyType
from typing import ClassVar, Protocol

from combat_sim.mechanics.exact_ratio import ratio_text
from combat_sim.models import UnsupportedMechanicError, as_fraction
from combat_sim.stationary_geometry import nearest_living_enemy, squared_distance


class EnemyTargetPolicy(Protocol):
    name: str

    def choose(self, actor, participants) -> str | None: ...


def _team(value):
    if not isinstance(value,str):raise ValueError('Target-policy team identities must be strings')
    return value


def target_snapshot(participants):
    """Expose only copied identity/team, exact HP and horizontal position."""
    return MappingProxyType({name: MappingProxyType({
        'team': _team(state['team']), 'hp': as_fraction(state['hp']),
        'position_m': tuple(map(as_fraction, state['position_m'])),
    }) for name, state in participants.items()})


def living_enemies(actor, participants):
    source = participants[actor]
    if as_fraction(source['hp']) <= 0:
        return ()
    return tuple(name for name, state in participants.items()
                 if state['team'] != source['team'] and as_fraction(state['hp']) > 0)


@dataclass(frozen=True)
class NearestLivingEnemy:
    name: ClassVar[str] = 'nearest_living_enemy'

    def choose(self, actor, participants):
        return nearest_living_enemy(actor, participants)


@dataclass(frozen=True)
class LowestHPEnemy:
    name: ClassVar[str] = 'lowest_hp_enemy'

    def choose(self, actor, participants):
        source = participants[actor]
        return min(living_enemies(actor, participants), default=None,
                   key=lambda name: (as_fraction(participants[name]['hp']),
                       squared_distance(source['position_m'], participants[name]['position_m']), name))


POLICIES = MappingProxyType({
    NearestLivingEnemy.name: NearestLivingEnemy,
    LowestHPEnemy.name: LowestHPEnemy,
})


def make_target_policy(name):
    if not isinstance(name, str) or name not in POLICIES:
        raise UnsupportedMechanicError('Unsupported enemy target policy; expected ' + ', '.join(POLICIES))
    return POLICIES[name]()


def select_enemy(policy, actor, participants):
    """Enforce the same legal target boundary for built-ins and API policies."""
    if not isinstance(getattr(policy, 'name', None), str) or not policy.name or not callable(getattr(policy, 'choose', None)):
        raise ValueError('Enemy target policy requires a name and choose method')
    eligible=frozenset(living_enemies(actor,participants))
    target = policy.choose(actor, participants)
    if target is not None and (not isinstance(target, str) or target not in eligible):
        raise ValueError('Enemy target policy returned an ineligible living enemy')
    return target


def describe_selection(policy, actor, participants, target):
    source = participants[actor]
    return {'policy': policy.name, 'selected_enemy': target,
            'candidates': tuple({'actor': name, 'hp': ratio_text(participants[name]['hp']),
                'horizontal_distance_squared_m2': ratio_text(squared_distance(
                    source['position_m'], participants[name]['position_m']))}
                for name in sorted(living_enemies(actor, participants)))}
