"""Summaries of shared encounters, with each combatant accounted independently."""
from decimal import Context, Decimal as D, ROUND_HALF_EVEN, localcontext


def summarize_shared(run):
    with localcontext(Context(prec=run['numerics']['precision'], rounding=ROUND_HALF_EVEN)):
        participants = {}
        for name, final in sorted(run['final_states'].items()):
            initial = run['initial_states'][name]
            metrics = run['metrics'][name]
            participants[name] = {
                'character': final['character'], 'team': final['team'],
                'hp_damage_received': str(D(initial['hp'])-D(final['hp'])),
                'shield_damage_received': metrics['shield_damage_received'],
                'armor_lost': str(D(initial['armor'])-D(final['armor'])),
                'direct_hp_damage_received': metrics['direct_hp_damage_received'],
                'continuous_hp_damage_received': metrics['continuous_hp_damage_received'],
                'activations_started': metrics['activations_started'],
                'projectiles_released': metrics['projectiles_released'],
                'hits_resolved': metrics['hits_resolved'],
                'reloads_started': metrics['reloads_started'],
                'reloads_completed': metrics['reloads_completed'],
                'final_state': final,
            }
            if 'life_cycle_rules' in run:
                # Restoration increases HP; initial minus final no longer
                # measures the actual damage received over the encounter.
                participants[name]['hp_damage_received']=str(D(metrics['direct_hp_damage_received'])+
                    D(metrics['continuous_hp_damage_received']))
            if 'locomotion' in final:
                participants[name]['movement_metrics'] = {k:metrics[k] for k in
                    ('movement_commands','jumps_started','landings','collision_stops')}
                if 'special_stops' in metrics:
                    participants[name]['movement_metrics']['special_stops']=metrics['special_stops']
                if 'movement_actives_completed' in metrics:
                    participants[name]['movement_metrics']['movement_actives_completed']=metrics['movement_actives_completed']
                if 'climbs_started' in metrics:
                    participants[name]['movement_metrics'].update({k:metrics[k] for k in
                        ('climbs_started','climbs_completed','climb_requests_rejected')})
                for key in ('sprint_transitions','sprint_exhaustions','crouches_started','crouches_completed','stands_completed','stand_requests_rejected','posture_interruptions'):
                    if key in metrics:participants[name]['movement_metrics'][key]=metrics[key]
                if 'sprint_dyspnea_gained' in metrics:
                    participants[name]['sprint_dyspnea_gained']=metrics['sprint_dyspnea_gained']
            if 'terrain_contacts' in metrics:
                participants[name]['terrain_contacts'] = metrics['terrain_contacts']
            if 'hp_healed' in metrics:
                participants[name]['hp_healed']=metrics['hp_healed']
                participants[name]['healing_entitlement_discarded']=metrics['healing_entitlement_discarded']
            if 'get_ups_started' in metrics:
                participants[name]['common_action_metrics'] = {k: metrics[k] for k in
                    ('get_ups_started', 'get_ups_completed', 'knockdowns_received')}
            if 'alive' in final:
                participants[name].update(alive=final['alive'], died_at_ms=final['died_at_ms'],
                                          dyspnea_paid=metrics['dyspnea_paid'],
                                          shield_regenerated=metrics['shield_regenerated'])
        summary={'scenario_id': run['scenario_id'], 'run_until_ms': run['run_until_ms'],
                'requested_horizon_ms': run['requested_horizon_ms'],
                'stop_reason': run['stop_reason'], 'participants': participants,
                'shield_regenerated_total': run['shield_regenerated_total'],
                'outcome': ({'surviving_teams': run['surviving_teams'],
                             'survivors': [n for n, f in run['final_states'].items() if f['alive']]}
                            if 'surviving_teams' in run else 'Controlled observation; no death or victory rule inferred'),
                'scope': run['scope'], 'numerics': run['numerics']}
        colliders={key:{name:obj[name] for name in ('kind','status','hp','max_hp','expires_at_ms','owner','ability','blocking')}
            for key,obj in run.get('world_collider_states',{}).items()
            if obj['kind']=='deployed' or obj['revision']>0}
        if colliders:summary['world_colliders']=colliders
        if 'persistent_effect_rules' in run:
            summary['persistent_effects']={'rules':run['persistent_effect_rules'],
                'numerics':run['persistent_effect_numerics'],
                'active_instances':sum(e['status']=='active' for e in run['effect_instances']),
                'ended_instances':sum(e['status']=='ended' for e in run['effect_instances']),
                'volumes':{v['id']:{k:v[k] for k in ('kind','actor','ability','action_id','active','start','expiry','eligible_targets')}
                    for v in run['volume_instances']}}
        if 'heat_shield_coupling_rules' in run:
            summary['heat_shield_coupling']={'rules':run['heat_shield_coupling_rules'],
                'numerics':run['heat_shield_coupling_numerics'],
                'recipients':sorted({e['target'] for e in run['events'] if e['type']=='thermal_recovery_activated'})}
        if 'cooldown_clock_rules' in run:
            summary['cooldowns']={'rules':run['cooldown_clock_rules'],
                'pause_volumes':run['cooldown_pause_volumes']}
        if 'damage_ledger_rules' in run:
            summary['damage_credit']={'rules':run['damage_ledger_rules'],'totals':run['damage_credit_totals']}
        if 'life_cycle_rules' in run:
            summary['life_cycles']={'rules':run['life_cycle_rules'],'actor_lives':run['actor_lives']}
        if 'revival_rules' in run:
            summary['revival']={'rules':run['revival_rules'],'states':run['revival_states'],
                'attempts':run['revival_attempts']}
        if 'healing_rules' in run:
            summary['healing']={'rules':run['healing_rules'],'numerics':run['healing_numerics'],
                'records':len(run['healing_history']['entries'])}
        return summary
