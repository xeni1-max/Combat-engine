"""Physical impact carriers with an independent instantaneous binding burst.

Direct damage remains in the normal simultaneous impact wave. Burst recipients
join that same wave as zero-damage effect components; each later creates its
own recipient-life binding through the existing common Break controller.
"""
from copy import deepcopy
from decimal import Decimal as D
from itertools import count

from combat_sim.models import UnsupportedMechanicError
from combat_sim.projectile_entities import ProjectileContactPolicy
from combat_sim.world_colliders import finite
from combat_sim.battle_models import decimal_value as dec

EVENT='impact_binding_hit'
KINDS=frozenset(('upper_body','lower_body','whole_body'))


class ImpactBindings:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        self.ids=count(1);self.bursts={};self.by_projectile={};self.hits={}
        if self.enabled and (definition!={'mode':'contact_burst_v1'} or not world.bindings.enabled
                or not world.gravity_mode or not world.effort_system.enabled or not world.body_paths.enabled):
            raise UnsupportedMechanicError('Impact binding areas require current gravity, owned binding and released effort rules')

    def validate(self,actor,ability_id):
        a=actor.profile['abilities'][ability_id];cfg=a.get('impact_binding_area',{})
        if not self.enabled:raise UnsupportedMechanicError('Impact binding areas are not enabled')
        if (not isinstance(cfg,dict) or set(cfg)!={'shape','radius_m','occlusion','binding'} or cfg['shape']!='sphere' or cfg['occlusion']!='none'):
            raise UnsupportedMechanicError('Impact binding area needs a spherical all-body burst')
        finite(cfg['radius_m'],'Binding burst radius',positive=True)
        binding=cfg['binding']
        if (not isinstance(binding,dict) or set(binding)!={'kind','duration_ms','binding_value'} or binding['kind'] not in KINDS):
            raise UnsupportedMechanicError('Impact area requires a body-function binding')
        finite(binding['duration_ms'],'Binding duration',positive=True);finite(binding['binding_value'],'Binding value')
        finite(a['pre_mitigation_damage'],'Physical carrier damage')
        if a.get('damage_type') not in ('blunt','qard','slash'):
            raise UnsupportedMechanicError('Impact binding carriers require a supported direct damage family')
        if ProjectileContactPolicy.from_definition(a['projectile_geometry'].get('contact_policy'))!=ProjectileContactPolicy():
            raise UnsupportedMechanicError('Impact binding carriers detonate on their first physical collision')
        timing=actor.profile['timing_profiles'][a['timing_profile']]
        if dec(timing.get('projectile_acceleration_mps2',0))!=0:
            raise UnsupportedMechanicError('Current impact binding carriers use ballistic gravity flight')

    def expand(self,packet):
        """Consume one physical contact, selecting actual living geometry once."""
        w=self.world;projectile=packet['projectile_id']
        if projectile in self.by_projectile:return []
        flight=w.projectile_flights[projectile];cfg=deepcopy(flight['contact_payload']['impact_binding_area'])
        identity='binding-burst:'+str(next(self.ids))
        names=sorted(w.body_area_recipients(packet['location_m'],cfg['radius_m'],cfg['shape'],occlusion=cfg['occlusion']))
        row={'id':identity,'projectile_id':projectile,'actor':packet['actor'],'ability':packet['ability'],
            'source_life_generation':packet['source_life_generation'],'action_id':packet['action_id'],
            'at_ms':w.time,'location_m':deepcopy(packet['location_m']),'definition':cfg,
            'origin_contact':deepcopy(packet),'recipients':names,'autonomous':True}
        self.bursts[identity]=row;self.by_projectile[projectile]=identity
        w.log('impact_binding_burst',**deepcopy(row))
        source={key:packet[key] for key in ('actor','ability','action_id','source_life_generation','projectile_id')}
        return [dict(source,target=name,component='binding_burst',impact_binding_burst_id=identity,
            location_m=deepcopy(packet['location_m']),radius_m=cfg['radius_m'],collision_kind='body',
            **w.life_cycles.target_fields(name)) for name in names]

    def queue(self,packet):
        identity=packet.get('impact_binding_burst_id')
        if identity is None:return
        key=identity+':'+packet['target']+':'+str(packet['target_life_generation'])
        if key in self.hits:return
        self.hits[key]={'id':key,'burst_id':identity,'packet':deepcopy(packet),'status':'queued'}
        self.world.push(self.world.time,EVENT,{'hit_id':key},priority=3)

    def event_live(self,payload):
        row=self.hits.get(payload['hit_id']);return row is not None and row['status']=='queued'

    def process(self,payload):
        if not self.event_live(payload):return
        row=self.hits[payload['hit_id']];cfg=self.bursts[row['burst_id']]['definition']['binding']
        identity=self.world.bindings.create(row['packet'],kind=cfg['kind'],value=cfg['binding_value'],duration_ms=cfg['duration_ms'])
        row.update(status='applied' if identity is not None else 'recipient_life_ended',binding_id=identity)
        self.world.log('impact_binding_resolved',**deepcopy(row))

    def statuses(self,packet):
        if 'impact_binding_burst_id' in packet:return {'disorientation':D(0),'instability':D(0)}
        return self.world.projectile_flights[packet['projectile_id']]['contact_payload']['target_effects']

    def result(self):
        return {'impact_binding_rules':self.world.combat_locomotion_input['impact_bindings'],
            'impact_binding_bursts':deepcopy(list(self.bursts.values())),
            'impact_binding_hits':deepcopy(list(self.hits.values()))} if self.enabled else {}
