"""Committed combat signals and automatic, causally later direct emissions.

Signals describe damage already absorbed, not hypothetical contacts. Dispatch
occurs after incoming hits/deaths and body contacts; released packets are then
batched together before ordinary decisions. No controlled hand/body lock is
acquired by the authored automatic Block counterattack.
"""
from copy import deepcopy
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import local_to_world_point
from combat_sim.line_delivery import sweep_line
from combat_sim.mechanics.charges import RechargeableCharges
from combat_sim.models import UnsupportedMechanicError
from combat_sim.reaction_models import BlockSignal
from combat_sim.world_colliders import finite


class CombatReactions:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'causal_signals_v1'} or not world.blocking.enabled
                or not world.life_cycles.enabled or not world.effort_system.enabled):
            raise UnsupportedMechanicError('Combat reactions require current Block/life/effort rules')
        self.ids=count(1);self.attack_ids=count(1)
        self.signals={};self.emissions={};self.abilities={};self.pools={}

    def attach(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            for ability,cfg in actor.profile.get('automatic_abilities',{}).items():
                if cfg.get('execution_model')!='block_counter':continue
                if (cfg.get('trigger')!='block_absorbed' or cfg.get('damage_type')!='blunt'
                        or cfg.get('dyspnea',{}).get('kind')!='none'):
                    raise UnsupportedMechanicError('Unsupported Block reaction trigger, damage or effort')
                delivery=cfg.get('delivery',{})
                if (delivery.get('shape')!='piercing_line' or delivery.get('origin')!='torso_centre'
                        or delivery.get('direction')!='facing' or delivery.get('occlusion')!='projectile_solids'):
                    raise UnsupportedMechanicError('Unsupported direct reaction geometry')
                for name in ('length_m','radius_m'):finite(delivery[name],name,positive=True)
                for name in ('pre_mitigation_damage','charge_gain_interval_ms'):finite(cfg[name],name,positive=True)
                for name in ('disorientation','instability'):finite(cfg['target_effects'][name],name)
                key=(actor.id,ability)
                self.world.cooldown_system.register_background(actor,ability)
                pool=RechargeableCharges(cfg['maximum_charges'],cfg['charge_gain_interval_ms'],
                    clock=actor.cooldowns.clocks[ability])
                self.world.effort_system.validate_ability(actor,ability)
                if self.world.effort_system.phases[key][1]!='extrinsic_momentary':
                    raise UnsupportedMechanicError('Block counter requires extrinsic momentary release effort')
                self.abilities[key]=deepcopy(cfg);self.pools[key]=pool
                actor.metrics.setdefault('reactions_released',0)

    def blocked(self,actor,generation,amount,layers,incoming,depth=0):
        if not self.enabled:return
        identity='signal:'+str(next(self.ids))
        signal=BlockSignal(identity,actor,generation,self.world.time,amount,
            tuple(layers),tuple(incoming),depth)
        self.signals[identity]={'signal':signal,'status':'queued','decisions':[]}
        self.world.push(self.world.time,'combat_signal',{'signal_id':identity},priority=3)
        self.world.log('combat_signal_committed',signal=signal.record())

    def live(self,payload):
        state=self.signals.get(payload.get('signal_id'))
        return state is not None and state['status']=='queued'

    def process(self,payload):
        if not self.live(payload):return
        state=self.signals[payload['signal_id']];state['status']='dispatched'
        signal=state['signal'];actor=self.world.fighters[signal.actor]
        for key,cfg in self.abilities.items():
            if key[0]!=actor.id:continue
            ability=key[1];pool=self.pools[key]
            reason=('source_life_retired' if actor.life_generation!=signal.source_life_generation else
                'owner_dead' if actor.hp<=0 or actor.died_at_ms is not None else
                'no_charge' if pool.available(self.world.time)==0 else None)
            if reason is not None:
                state['decisions'].append({'ability':ability,'outcome':reason})
                self.world.log('combat_reaction_skipped',actor=actor.id,ability=ability,
                    signal_id=signal.id,reason=reason)
                continue
            pool.spend(self.world.time)
            frame=self.release_line(actor,ability,cfg,signal)
            state['decisions'].append({'ability':ability,'outcome':'released','attack_id':frame['id']})
            self.world.log('reaction_charge_spent',actor=actor.id,ability=ability,signal_id=signal.id,
                attack_id=frame['id'],pool=pool.record(self.world.time),dyspnea_cost=D(0))

    def release_line(self,actor,ability,cfg,signal):
        world=self.world;identity='direct:'+str(next(self.attack_ids));action_id=next(world.action_ids)
        origin=tuple(map(dec,next(b.centre_m for b in world.world_bodies[actor.id] if b.part=='torso')))
        length=dec(cfg['delivery']['length_m']);radius=dec(cfg['delivery']['radius_m'])
        end=tuple(map(dec,local_to_world_point((0,length,0),origin,actor.facing)))
        world.effort_system.capture_direct(actor,ability,action_id,cfg,identity,'reaction')
        receivers={}
        for name,target in world.fighters.items():
            if name==actor.id:continue
            if target.hp>0:receivers[(name,target.life_generation)]=list(world.world_bodies[name])
            # Frozen surfaces are independent receivers of their original life;
            # a body-piercing line may also hit the restored body behind them.
            for layer in world.blocking.layers.values():
                if layer['actor']==name and world.blocking.active(layer):
                    receivers.setdefault((name,layer['source_life_generation']),[]).append(world.blocking.box(layer))
        sweep=sweep_line(origin,end,radius,receivers,
            world.collider_system.registry.active('projectiles',world.time),precision=world.precision)
        base={'actor':actor.id,'ability':ability,'action_id':action_id,'attack_id':identity,
            'source_life_generation':actor.life_generation,'component':'reaction','delivery_kind':'piercing_line',
            'signal_id':signal.id,'reaction_depth':signal.parent_depth+1}
        packets=[]
        for (name,generation),hit in sweep.recipients:
            packets.append(dict(base,target=name,target_life_generation=generation,
                collision_kind='body',location_m=hit.closest_box_point_m,distance_m=hit.parameter*length,
                hit_parts=[hit.part],**world.blocking.contact_fields(hit.part)))
        if sweep.blocker is not None:
            name,hit=sweep.blocker
            packets.append(dict(base,target=name,collision_kind='terrain',location_m=hit.closest_box_point_m,
                distance_m=hit.parameter*length,hit_parts=[hit.part],
                **world.collider_system.registry.contact_fields(name)))
        frame={**base,'id':identity,'created_at_ms':world.time,'origin_m':origin,'end_m':end,'radius_m':radius,
            'recipients':deepcopy(packets),'solid_blocker':None if sweep.blocker is None else sweep.blocker[0]}
        self.emissions[identity]=frame;actor.metrics['reactions_released']+=1
        for packet in packets:world.push(world.time,'impact',packet,priority=1)
        world.log('combat_reaction_released',actor=actor.id,ability=ability,emission=deepcopy(frame),
            acquires_resources=False,autonomous_after_release=True)
        return frame

    def result(self):
        if not self.enabled:return {}
        pools={}
        for (name,ability),pool in sorted(self.pools.items()):
            pools.setdefault(name,{})[ability]=pool.record(self.world.time)
        return {'combat_reaction_rules':self.world.combat_locomotion_input['combat_reactions'],
            'combat_signals':[{**v['signal'].record(),'status':v['status'],'decisions':deepcopy(v['decisions'])}
                for v in self.signals.values()],
            'reaction_emissions':list(deepcopy(self.emissions).values()),
            'reaction_charge_pools':pools}
