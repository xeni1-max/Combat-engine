"""Shared-clock cooldown work and independently deployed spatial pause areas."""
from itertools import count
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import CooldownPauseArea,EffectSource
from combat_sim.mechanics.cooldown import CooldownBook,CooldownClock
from combat_sim.models import UnsupportedMechanicError
from combat_sim.volume_geometry import TIME_EPS_S


class CooldownFields:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'remaining_work_v1'} or not world.effect_system.enabled):
            raise UnsupportedMechanicError('Cooldown work requires the typed integrated world')
        self.ids=count(1);self.volumes={};self.members={};self.death_continuing=set()
        self.deferred_starts={};self.deferred_history=[]

    def background_ready_at(self,actor,key):
        if (actor.id,key) in self.deferred_starts:return D('Infinity')
        time=actor.cooldowns.clocks[key].ready_at(self.world.time)
        return D('Infinity') if time is None else time

    def defer_start(self,actor,key,duration,action_id,at_ms,source_life):
        if self.background_ready_at(actor,key)>self.world.time:raise ValueError('Branch cooldown is already committed')
        row={'actor':actor.id,'clock_key':key,'action_id':action_id,'source_life_generation':source_life,
            'committed_at_ms':self.world.time,'starts_at_ms':dec(at_ms),'work_ms':dec(duration),'status':'pending'}
        self.deferred_starts[(actor.id,key)]=row;self.deferred_history.append(row)
        self.world.push(at_ms,'deferred_cooldown_started',{'actor':actor.id,'clock_key':key,'action_id':action_id},priority=0)
        self.world.log('cooldown_start_committed',**row)

    def deferred_live(self,payload):
        row=self.deferred_starts.get((payload['actor'],payload['clock_key']))
        return row is not None and row['action_id']==payload['action_id']

    def finish_deferred(self,payload):
        if not self.deferred_live(payload):return
        row=self.deferred_starts.pop((payload['actor'],payload['clock_key']))
        actor=self.world.fighters[row['actor']];clock=actor.cooldowns.clocks[row['clock_key']]
        clock.start(self.world.time,row['work_ms'],allow_stopped=True)
        row.update(status='started',started_at_ms=self.world.time);self._sync(actor)
        self.world.log('deferred_cooldown_started',**row,clock=clock.record(self.world.time))

    def attach(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            actor.cooldowns=CooldownBook(lambda:self.world.time,actor.ready)

    def ready_at(self,actor,ability):
        if not self.enabled:return actor.ready[ability]
        if self.world.blocking.enabled and actor.profile['abilities'][ability]['execution_model']=='block':
            return self.world.blocking.ready_at(actor,ability)
        if getattr(self.world,'dodging',None) is not None and self.world.dodging.enabled and actor.profile['abilities'][ability]['execution_model']=='dodge':
            return self.world.dodging.ready_at(actor,ability)
        time=actor.cooldowns.clocks[ability].ready_at(self.world.time)
        return D('Infinity') if time is None else time

    def _sync(self,actor):
        for ability in actor.ready:actor.ready[ability]=self.ready_at(actor,ability)

    def register_background(self,actor,ability,*,continue_while_dead=False):
        """Register an automatic ability without adding it to living policies."""
        if not self.enabled:raise UnsupportedMechanicError('Background abilities require cooldown work')
        if ability in actor.cooldowns.clocks:raise ValueError('Cooldown ability is already registered')
        if type(continue_while_dead) is not bool:raise ValueError('Death progression must be explicit')
        sources={v.id for v in self.volumes.values() if v.active and v.expiry>self.world.time
            and actor.hp>0 and self._cells(v,actor.id,2*TIME_EPS_S)[0][1]}
        actor.cooldowns.clocks[ability]=CooldownClock(reference_ms=self.world.time,pauses=sources)
        if continue_while_dead:self.death_continuing.add((actor.id,ability))

    def start(self,actor,ability,duration,action_id):
        if not self.enabled:
            actor.ready[ability]=self.world.time+dec(duration)
            return
        clock=actor.cooldowns.clocks[ability];clock.start(self.world.time,duration);self._sync(actor)
        self.world.log('cooldown_started',actor=actor.id,ability=ability,action_id=action_id,
            clock=clock.record(self.world.time))

    def stop_actor(self,actor):
        if not self.enabled:return
        for ability,clock in actor.cooldowns.clocks.items():
            if (actor.id,ability) not in self.death_continuing:clock.stop(self.world.time)
        self._sync(actor)

    def resume_actor(self,actor):
        sources={v.id for v in self.volumes.values() if v.active and v.expiry>self.world.time
            and self._cells(v,actor.id,2*TIME_EPS_S)[0][1]}
        for ability,clock in actor.cooldowns.clocks.items():
            if clock.stopped:clock.resume(self.world.time,pause_sources=sources)
            elif (actor.id,ability) in self.death_continuing:
                for source in sorted(clock.pauses|sources):clock.pause(self.world.time,source,source in sources)
            else:raise ValueError('Ordinary cooldown must stop before life restoration')
        self._sync(actor)

    def _membership(self,volume,target,eligible):
        members=self.members[volume.id]
        if (target in members)==eligible:return
        actor=self.world.fighters[target]
        if eligible:members.add(target)
        else:members.discard(target)
        for clock in actor.cooldowns.clocks.values():clock.pause(self.world.time,volume.id,eligible)
        self._sync(actor)
        self.world.log('cooldown_pause_entered' if eligible else 'cooldown_pause_left',
            volume_id=volume.id,target=target,actor=volume.source.actor,ability=volume.source.ability)
        if actor.hp>0:
            actor.decision_due=None;actor.decision_revision+=1
            self.world.request_decision(target,self.world.time)

    def deploy(self,actor,action,ability):
        if not self.enabled:raise UnsupportedMechanicError('Pause areas require cooldown work')
        world=self.world
        volume=CooldownPauseArea('pause-volume:'+str(next(self.ids)),EffectSource(actor.id,action.ability_id,action.id,
            life_generation=action.life_generation),
            action.aim_location_m,ability['radius_m'],world.time,world.time+dec(ability['area_duration_ms']))
        self.volumes[volume.id]=volume;self.members[volume.id]=set()
        world.push(volume.expiry,'cooldown_pause_expired',{'volume_id':volume.id,'revision':volume.revision})
        self.settle()
        world.log('cooldown_pause_deployed',actor=actor.id,ability=action.ability_id,action_id=action.id,
            volume=volume.record(self.members[volume.id]))

    def _cells(self,volume,target,duration):
        return self.world.effect_system.cells(volume,target,'actor',duration,occluded=False)

    def prepare_interval(self,end):
        if not self.enabled:return end
        world=self.world;finish=end
        if world.turns.any_active() and any(v.active and v.expiry>world.time for v in self.volumes.values()):
            finish=world.effect_system.motion_limit(finish)
        query_end=finish
        for volume in self.volumes.values():
            if not volume.active or volume.expiry<=world.time:continue
            for target,actor in world.fighters.items():
                if actor.hp<=0:
                    self._membership(volume,target,False);continue
                cells=self._cells(volume,target,(query_end-world.time)/1000)
                self._membership(volume,target,cells[0][1])
                if len(cells)>1:finish=min(finish,world.time+cells[1][0]*1000)
        if world.queue:finish=min(finish,world.queue[0][0])
        return finish

    def settle(self):
        if not self.enabled:return
        for volume in self.volumes.values():
            if not volume.active or volume.expiry<=self.world.time:continue
            for target,actor in self.world.fighters.items():
                eligible=actor.hp>0 and self._cells(volume,target,2*TIME_EPS_S)[0][1]
                self._membership(volume,target,eligible)

    def event_live(self,payload):
        volume=self.volumes.get(payload['volume_id'])
        return volume is not None and volume.active and volume.revision==payload['revision']

    def expire(self,payload):
        if not self.event_live(payload):return
        volume=self.volumes[payload['volume_id']];volume.active=False;volume.revision+=1
        for target in sorted(self.members[volume.id]):self._membership(volume,target,False)
        self.world.log('cooldown_pause_expired',volume_id=volume.id)

    def result(self):
        if not self.enabled:return {}
        return {**({'deferred_cooldown_starts':[dict(r) for r in self.deferred_history]} if self.deferred_history else {}),
            'cooldown_clock_rules':self.world.combat_locomotion_input['cooldown_clocks'],
            'cooldown_pause_volumes':[v.record(self.members[v.id]) for v in self.volumes.values()]}

    def pending(self):
        return [v.record(self.members[v.id]) for v in self.volumes.values() if v.active and v.expiry>self.world.time]
