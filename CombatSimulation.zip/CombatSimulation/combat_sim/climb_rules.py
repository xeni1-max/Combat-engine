"""Climb phases attached to the author-approved shared geometry/timing test."""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.character_geometry import actor_body
from combat_sim.battle_models import ceil_ms, decimal_value as dec
from combat_sim.mechanics.climbing import ClimbPath, surface_distance_squared, within_climb_range
from combat_sim.models import UnsupportedMechanicError


class ScriptedClimbRules:
    def setup_climb_rules(self,definition):
        self.climb_definition=deepcopy(definition)
        if definition is None:return
        expected={'status','activation_distance_m','range_origin','range_inclusive','path','speed','characters','source','scope','activation_check','movement_during_gathering','movement_on_success'}
        if (set(definition)!=expected or definition['status']!='confirmed_by_author' or
            definition['range_origin']!='character_body_origin' or definition['range_inclusive'] is not True or
            definition['path']!='up_then_top_centre' or definition['speed']!='constant_along_path' or
            definition['activation_check']!='active_start_once' or
            definition['movement_during_gathering']!='continue' or definition['movement_on_success']!='use_climb_path'):
            raise UnsupportedMechanicError('Unsupported climb definition')
        if dec(definition['activation_distance_m'])<0:raise ValueError('Climb range must be nonnegative')
        for values in definition['characters'].values():
            g,a=dec(values['gathering_ms']),dec(values['active_ms'])
            if g<0 or a<=0 or a!=ceil_ms(a):raise ValueError('Climb requires valid Gathering and integer-ms Active')
        ground=self.terrain_definition['ground']['id']
        for name,m in self.motion.items():
            if self.fighters[name].profile_id not in definition['characters']:
                raise UnsupportedMechanicError('Missing climb character profile')
            m.update(climb=None,support_id=ground)
            self.fighters[name].metrics.update(climbs_started=0,climbs_completed=0,climb_requests_rejected=0)

    def request_climb(self,name,target):
        if self.climb_definition is None:
            raise UnsupportedMechanicError('Climb command requires an explicit climb definition')
        actor=self.fighters[name];m=self.motion[name]
        objects={item['id']:item for item in self.terrain_definition['obstacles']}
        reason=None
        if target not in objects:reason='unknown_climb_target'
        elif not objects[target].get('climbable',False):reason='target_not_climbable'
        if reason:
            actor.metrics['climb_requests_rejected']+=1
            self.log('climb_rejected',actor=name,target=target,reason=reason)
            return
        box=self.terrain_colliders[target][0]
        profile=self.climb_definition['characters'][actor.profile_id]
        m.update(phase='climb_gathering',climb_target=target)
        gathering=dec(profile['gathering_ms'])*(D('1.2') if m['mode']=='running' else 1)
        due=ceil_ms(self.time+gathering)
        self.log('climb_requested',actor=name,target=target,origin_m=actor.body_origin_m,
                 origin_surface_distance_squared_m2=dec(surface_distance_squared(actor.body_origin_m,box)),
                 activation_distance_m=dec(self.climb_definition['activation_distance_m']),active_start_ms=due,
                 range_check='once_at_active_start',movement_during_gathering='continue')
        self.push(due,'movement_climb_started',{'actor':name,'revision':m['revision']})

    def climb_motion_at(self,name,time):
        m=self.motion[name];climb=m['climb']
        path=climb['path']
        # Preserve the analytic segment boundary despite Decimal addition/
        # subtraction roundoff in non-terminating corner timestamps.
        elapsed=(path.corner_ms if time==climb['corner_at_ms'] else
                 path.duration if time==climb['end_at_ms'] else time-climb['start_ms'])
        state=path.at(elapsed)
        speed=sum(v*v for v in state.velocity_mps[:2]).sqrt()
        return state.position_m[:2],state.position_m[2]-m['ground_origin_z'],state.velocity_mps,(D(0),)*3,speed

    def process_climb_event(self,kind,p):
        name=p['actor'];actor=self.fighters[name];m=self.motion[name]
        target=m['climb_target'];box=self.terrain_colliders[target][0]
        if kind=='movement_climb_started':
            gap_squared=surface_distance_squared(actor.body_origin_m,box)
            allowed=within_climb_range(actor.body_origin_m,box,self.climb_definition['activation_distance_m'])
            self.log('climb_range_checked',actor=name,target=target,phase='active_start',
                     origin_m=actor.body_origin_m,origin_surface_distance_squared_m2=dec(gap_squared),allowed=allowed)
            if not allowed:
                m['phase']=None
                actor.metrics['climb_requests_rejected']+=1
                self.log('climb_rejected',actor=name,target=target,reason='outside_activation_range',
                         phase='active_start',movement_continues=True,collision_requires_actual_contact=True)
                self.update_movement_geometry(self.time)
                return
            profile=self.climb_definition['characters'][actor.profile_id]
            offset=-dec(actor_body(self,name)['standing_placement']['ground_z_m'])
            incoming_velocity=self.motion_at(name,self.time)[2]
            path=ClimbPath(actor.body_origin_m,box,offset,profile['active_ms'],precision=self.precision)
            m.update(mode='climbing',phase='climb_active',climb={'path':path,'start_ms':self.time,
                'corner_at_ms':self.time+path.corner_ms,'end_at_ms':self.time+path.duration})
            actor.metrics['climbs_started']+=1
            self.log('climb_active_started',actor=name,target=target,origin_m=path.origin,target_origin_m=path.target,
                     active_ms=path.duration,path_length_m=path.length,path_speed_mps=path.speed,
                     velocity_before_climb_mps=incoming_velocity,
                     top_reached_at_ms=self.time+path.corner_ms,active_end_ms=self.time+path.duration)
            if 0<path.corner_ms<path.duration:
                self.push(self.time+path.corner_ms,'movement_climb_top_reached',{'actor':name,'revision':m['revision']})
            self.push(self.time+path.duration,'movement_climb_completed',{'actor':name,'revision':m['revision']})
        elif kind=='movement_climb_top_reached':
            self.log('climb_top_reached',actor=name,target=target,feet_z_m=dec(box.bounds[1][2]))
        elif kind=='movement_climb_completed':
            path=m['climb']['path']
            m.update(mode='standing',phase=None,climb=None,support_id=target,ground_origin_z=path.target[2])
            self.reanchor_motion(name,0)
            actor.metrics['climbs_completed']+=1
            self.log('climb_completed',actor=name,target=target,body_origin_m=path.target,
                     feet_z_m=path.top_z,support_id=target)
        else:raise RuntimeError('Unknown climb event: '+kind)
        self.update_movement_geometry(self.time)
        self.validate_movement_scene()

    def validate_climb_support(self):
        if self.climb_definition is None:return
        ground=self.terrain_definition['ground']['id']
        for name,m in self.motion.items():
            if m['support_id']==ground or m.get('climb') is not None:continue
            low,high=self.terrain_colliders[m['support_id']][0].bounds
            if any(any(a[i]<low[i] or b[i]>high[i] for i in (0,1))
                   for a,b in (box.bounds for box in self.world_bodies[name])):
                raise UnsupportedMechanicError('Leaving a raised support needs an authored ledge/fall response')
