"""Author-approved crouch cuboids, anchored feet and upper-body hand offsets."""
from combat_sim.hitboxes import Cuboid, combined_bounds, world_standing_cuboids
from combat_sim.models import as_fraction
from combat_sim.oriented_geometry import OrientedCuboid

LEGS={'left_leg','right_leg'}


def crouch_drop_m(definition,fraction,target_leg_height_m):
    fraction,target=as_fraction(fraction),as_fraction(target_leg_height_m)
    heights={as_fraction(definition['parts'][name]['size_xyz_m'][2]) for name in LEGS}
    if len(heights)!=1:raise ValueError('This crouch model requires equal standing leg heights')
    height=heights.pop()
    if not 0<=fraction<=1 or not 0<target<=height:
        raise ValueError('Invalid crouch fraction or target leg height')
    return (height-target)*fraction


def world_posture_cuboids(definition,standing_origin_m,facing,fraction,target_leg_height_m):
    """Shorten legs from their tops; lower upper body by the same amount."""
    drop=crouch_drop_m(definition,fraction,target_leg_height_m)
    standing=world_standing_cuboids(definition,standing_origin_m,facing)
    result=[]
    for box in standing:
        c=list(box.centre_m);size=list(box.size_m)
        if box.part in LEGS:
            c[2]-=drop/2;size[2]-=drop
        else:c[2]-=drop
        result.append(OrientedCuboid(box.part,c,size,box.frame) if isinstance(box,OrientedCuboid) else Cuboid(box.part,c,size))
    bounds=combined_bounds(result)
    ground=as_fraction(standing_origin_m[2])+as_fraction(definition['standing_placement']['ground_z_m'])
    if bounds[0][2]!=ground:raise ValueError('Proposed posture does not keep its feet as the lowest body bound')
    return tuple(result)


def body_origin_from_bounds(boxes):
    boxes=tuple(boxes)
    if any(isinstance(b,OrientedCuboid) for b in boxes):
        if not isinstance(boxes[0],OrientedCuboid):raise ValueError('One body pose requires one common yaw frame')
        frame=boxes[0].frame
        if any(not isinstance(b,OrientedCuboid) or b.frame!=frame for b in boxes):
            raise ValueError('One body pose requires one common yaw frame')
        local=tuple(Cuboid(b.part,frame.to_local_point(b.centre_m),b.size_m) for b in boxes)
        low,high=combined_bounds(local)
        return frame.to_world_point(tuple((a+b)/2 for a,b in zip(low,high)))
    low,high=combined_bounds(boxes)
    return tuple((a+b)/2 for a,b in zip(low,high))


def pose_local_hand_position(point,crouch_drop):
    """Convert authored standing local pose to recentered crouch-body frame."""
    point=tuple(as_fraction(v) for v in point)
    if len(point)!=3:raise ValueError('Hand position requires xyz')
    return (point[0],point[1],point[2]-as_fraction(crouch_drop)/2)
