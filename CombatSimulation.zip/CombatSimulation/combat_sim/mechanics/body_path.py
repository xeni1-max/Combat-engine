"""Immutable exact translation polynomial on a bounded absolute-time interval."""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.mechanics.velocity_projection import number,vector
from combat_sim.mechanics.exact_ratio import ratio_text,read_ratio


@dataclass(frozen=True)
class BodyPathPiece:
    begin_ms: F
    end_ms: F
    reference_m: tuple
    velocity_mps: tuple
    acceleration_mps2: tuple

    def __post_init__(self):
        for key in ('begin_ms','end_ms'):object.__setattr__(self,key,number(getattr(self,key)))
        if self.end_ms<self.begin_ms:raise ValueError('Body path end precedes its beginning')
        for key in ('reference_m','velocity_mps','acceleration_mps2'):
            object.__setattr__(self,key,vector(getattr(self,key)))

    def elapsed(self,time_ms):
        time=number(time_ms)
        if not self.begin_ms<=time<=self.end_ms:raise ValueError('Body path query lies outside its saved interval')
        return (time-self.begin_ms)/1000

    def position(self,time_ms):
        t=self.elapsed(time_ms)
        return tuple(p+v*t+a*t*t/2 for p,v,a in zip(self.reference_m,self.velocity_mps,self.acceleration_mps2))

    def velocity(self,time_ms):
        t=self.elapsed(time_ms)
        return tuple(v+a*t for v,a in zip(self.velocity_mps,self.acceleration_mps2))

    def slice(self,begin_ms,end_ms):
        self.elapsed(end_ms)
        return BodyPathPiece(begin_ms,end_ms,self.position(begin_ms),self.velocity(begin_ms),self.acceleration_mps2)

    def record(self):
        return {'begin_ms':ratio_text(self.begin_ms),'end_ms':ratio_text(self.end_ms),
            'reference_m':tuple(map(ratio_text,self.reference_m)),'velocity_mps':tuple(map(ratio_text,self.velocity_mps)),
            'acceleration_mps2':tuple(map(ratio_text,self.acceleration_mps2))}

    @classmethod
    def from_record(cls,record):
        return cls(read_ratio(record['begin_ms']),read_ratio(record['end_ms']),
            *(tuple(map(read_ratio,record[key])) for key in ('reference_m','velocity_mps','acceleration_mps2')))
