"""Frozen linear parts of selected constraint responses for force accounting.

The affine offset belongs to the total/base motion once, never to each released
force. This is the selected response, not the nonlinear solver's Jacobian.
"""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.mechanics.unilateral_velocity import _solve
from combat_sim.mechanics.velocity_projection import vector


@dataclass(frozen=True)
class FrozenResponse:
    names: tuple
    mass: tuple
    equality_basis: tuple
    rows: tuple
    directions: tuple
    gram: tuple

    @classmethod
    def from_projection(cls,result):
        names=tuple(n for n,_ in result.exact_velocities);weights=dict(result.weights)
        mass=tuple(F(weights[n]) for n in names for _ in range(3));basis=result.equality_basis
        def weighted(a,b):return sum((m*x*y for m,x,y in zip(mass,a,b)),F(0))
        def nullspace(value):
            for prior in basis:
                scale=weighted(value,prior)/weighted(prior,prior)
                value=tuple(x-scale*y for x,y in zip(value,prior))
            return value
        rows=tuple(r for r,m in zip(result.rows,result.multipliers) if m>0)
        directions=tuple(nullspace(tuple(x/m for x,m in zip(row,mass))) for row in rows)
        gram=tuple(tuple(weighted(a,b) for b in directions) for a in directions)
        return cls(names,mass,basis,rows,directions,gram)

    def apply(self,field):
        field=dict(field)
        if set(field)-set(self.names):raise ValueError('A force response needs existing participants')
        value=tuple(x for n in self.names for x in vector(field.get(n,(0,0,0))))
        def weighted(a,b):return sum((m*x*y for m,x,y in zip(self.mass,a,b)),F(0))
        for prior in self.equality_basis:
            scale=weighted(value,prior)/weighted(prior,prior)
            value=tuple(x-scale*y for x,y in zip(value,prior))
        if self.rows:
            coefficients=_solve(self.gram,tuple(sum((x*y for x,y in zip(row,value)),F(0)) for row in self.rows))
            value=tuple(x-sum((c*d[i] for c,d in zip(coefficients,self.directions)),F(0)) for i,x in enumerate(value))
        return {n:value[3*i:3*i+3] for i,n in enumerate(self.names)}


def path_force_coefficients(path,field):
    """Return (initial velocity, acceleration) for one component on this path."""
    field={n:vector(v) for n,v in dict(field).items()};names=tuple(n for n,_ in path.pieces)
    if set(field)-set(names):raise ValueError('A force response needs existing participants')
    if not any(any(v) for v in field.values()):
        zero=(F(0),)*3
        return {n:(zero,zero) for n in names}
    initial=FrozenResponse.from_projection(path.initial_projection).apply(field)
    def finite_response(projection):
        values=FrozenResponse.from_projection(projection.linear_projection).apply(initial)
        scale=projection.feasible_scale
        if projection.anchor_projection is None:
            return {n:tuple(scale*x for x in v) for n,v in values.items()}
        anchor=FrozenResponse.from_projection(projection.anchor_projection).apply(initial)
        return {n:tuple(scale*x+(1-scale)*a for x,a in zip(v,anchor[n])) for n,v in values.items()}
    mid=finite_response(path.midpoint_projection);endpoint=finite_response(path.endpoint_projection)
    blend=path.control_blend
    h=(path.pieces[0][1].end_ms-path.pieces[0][1].begin_ms)/1000
    result={}
    for name in initial:
        start=tuple((1-blend)*x+blend*y for x,y in zip(mid[name],initial[name]))
        avg=endpoint[name]
        result[name]=(start,tuple(2*(b-a)/h for a,b in zip(start,avg)))
    return result
