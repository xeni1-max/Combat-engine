"""Ordered defense layers with proportional simultaneous raw-damage sharing."""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.mechanics.shield import split_simultaneous_damage
from combat_sim.models import as_fraction


@dataclass(frozen=True)
class DefenseLayer:
    identity: str
    hp: F
    eligible: tuple[int, ...]


@dataclass(frozen=True)
class LayerAllocation:
    absorbed: tuple[F, ...]
    overflow: tuple[F, ...]
    layer_shares: tuple[tuple[str, tuple[F, ...]], ...]
    bypass_remaining: tuple[F, ...] = ()


def allocate_layers(damage, layers, *, shielding_ignored=None):
    remaining=tuple(map(as_fraction,damage));layers=tuple(layers)
    if any(x<0 for x in remaining):raise ValueError('Incoming damage cannot be negative')
    bypass=list(map(as_fraction,shielding_ignored)) if shielding_ignored is not None else [F(0)]*len(remaining)
    if len(bypass)!=len(remaining) or any(x<0 for x in bypass):
        raise ValueError('Shield bypass needs one nonnegative budget per packet')
    names=set()
    for layer in layers:
        if (not isinstance(layer.identity,str) or not layer.identity or layer.identity in names or
                as_fraction(layer.hp)<0 or len(set(layer.eligible))!=len(layer.eligible) or
                any(type(i) is not int or not 0<=i<len(remaining) for i in layer.eligible)):
            raise ValueError('Defense layers need unique identities, nonnegative HP and valid packet indices')
        names.add(layer.identity)
    original=remaining;records=[]
    for layer in layers:
        shares=[F(0)]*len(remaining);after=list(remaining)
        split=split_simultaneous_damage((remaining[i] for i in layer.eligible),layer.hp,
            shielding_ignored=(bypass[i] for i in layer.eligible))
        for i,(absorbed,left) in zip(layer.eligible,split):shares[i]=absorbed;after[i]=left
        for i in layer.eligible:bypass[i]=max(F(0),bypass[i]-as_fraction(layer.hp))
        remaining=tuple(after);records.append((layer.identity,tuple(shares)))
    return LayerAllocation(tuple(a-b for a,b in zip(original,remaining)),remaining,tuple(records),tuple(bypass))
