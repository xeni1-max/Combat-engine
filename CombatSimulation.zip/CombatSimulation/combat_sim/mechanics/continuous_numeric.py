"""Analytic Decimal integrals; the caller supplies a fixed numerical context.

No tick interval or gameplay rounding is introduced. These are finite-precision
versions of the documented square-root heat and linear eight-second bleed curves.
"""
from decimal import Decimal as D


def root_integral(coefficient, q0, q1, seconds):
    if any(not x.is_finite() or x < 0 for x in (coefficient, q0, q1, seconds)):
        raise ValueError('Root integration requires finite nonnegative inputs')
    if not coefficient or not seconds or not (q0 or q1):
        return D(0)
    # Rationalize the difference of cubes to avoid cancellation when q0 ~= q1.
    r0, r1 = q0.sqrt(), q1.sqrt()
    return 2 * coefficient * seconds * (q1 + r0*r1 + q0) / (3 * (r1+r0))


def root_curve_integral(coefficient, start_ms, leave_ms, expiry_ms, begin_ms, end_ms, decay):
    if any(not x.is_finite() or x < 0 for x in
           (coefficient, start_ms, leave_ms, expiry_ms, begin_ms, end_ms, decay)):
        raise ValueError('Curve inputs must be finite and nonnegative')
    if not start_ms <= leave_ms <= expiry_ms or end_ms < begin_ms or decay <= 0:
        raise ValueError('Curve clocks must be ordered and decay must be positive')
    exposure = (leave_ms-start_ms)/1000
    begin, end = max(begin_ms, start_ms), min(end_ms, expiry_ms, leave_ms+(leave_ms-start_ms)/decay)
    if end <= begin:
        return D(0)
    total = D(0)
    if begin < leave_ms:
        stop = min(end, leave_ms)
        total += root_integral(coefficient, (begin-start_ms)/1000,
                               (stop-start_ms)/1000, (stop-begin)/1000)
    if end > leave_ms:
        first = max(begin, leave_ms)
        total += root_integral(coefficient, max(D(0), exposure-decay*(first-leave_ms)/1000),
                               max(D(0), exposure-decay*(end-leave_ms)/1000), (end-first)/1000)
    return total


def root_affine_integral(coefficient,q_reference,reference_ms,slope,begin_ms,end_ms):
    """Integrate a linear nonnegative heat-memory segment, clipped at cooling zero."""
    if (any(not v.is_finite() for v in (coefficient,q_reference,reference_ms,slope,begin_ms,end_ms))
            or min(coefficient,q_reference,reference_ms,begin_ms,end_ms)<0 or begin_ms<reference_ms or end_ms<begin_ms):
        raise ValueError('Invalid affine heat curve or interval')
    if slope<0:end_ms=min(end_ms,reference_ms-q_reference/slope*1000)
    if end_ms<=begin_ms:return D(0)
    q0=max(D(0),q_reference+slope*(begin_ms-reference_ms)/1000)
    q1=max(D(0),q_reference+slope*(end_ms-reference_ms)/1000)
    return root_integral(coefficient,q0,q1,(end_ms-begin_ms)/1000)


def recorded_root_integral(curve,begin,end):
    if curve.get('curve_kind') in ('sum_root_v1','sum_rates_v1'):
        if end<begin:raise ValueError('Curve end must follow begin')
        if not curve['constant_per_second'].is_finite() or curve['constant_per_second']<0:
            raise ValueError('Recorded constant rate must be finite and nonnegative')
        return curve['constant_per_second']*(end-begin)/1000+sum(
            (recorded_root_integral(term,begin,end) for term in tuple(curve['terms'])+tuple(curve.get('affine_terms',()))),D(0))
    if curve.get('curve_kind')=='affine_rate_v1':
        return affine_rate_integral(curve['value_reference'],curve['reference_ms'],curve['slope_per_second'],begin,end)
    if curve.get('curve_kind')=='affine_root_v1':
        if end<begin:raise ValueError('Curve end must follow begin')
        begin=max(begin,curve['reference_ms'])
        if end<=begin:return D(0)
        return root_affine_integral(curve['coefficient'],curve['q_reference'],curve['reference_ms'],
            curve['slope_per_second'],begin,end)
    if curve.get('curve_kind') is not None:raise ValueError('Unknown continuous root curve kind')
    return root_curve_integral(curve['coefficient'],curve['start_ms'],curve['leave_ms'],curve['expiry_ms'],begin,end,curve['k'])


def recorded_root_rate(curve,time):
    """Right-continuous supply rate in HP/s for a recorded continuous loss."""
    kind=curve.get('curve_kind')
    if kind in ('sum_root_v1','sum_rates_v1'):
        if not curve['constant_per_second'].is_finite() or curve['constant_per_second']<0:
            raise ValueError('Recorded constant rate must be finite and nonnegative')
        return curve['constant_per_second']+sum((recorded_root_rate(term,time)
            for term in tuple(curve['terms'])+tuple(curve.get('affine_terms',()))),D(0))
    if kind=='affine_rate_v1':
        if time<curve['reference_ms']:return D(0)
        return max(D(0),curve['value_reference']+curve['slope_per_second']*(time-curve['reference_ms'])/1000)
    if kind=='affine_root_v1':
        q=curve['q_reference']+curve['slope_per_second']*(time-curve['reference_ms'])/1000
    elif kind is None:
        if time<curve['start_ms'] or time>curve['expiry_ms']:return D(0)
        q=((time-curve['start_ms'])/1000 if time<=curve['leave_ms'] else
            (curve['leave_ms']-curve['start_ms']-curve['k']*(time-curve['leave_ms']))/1000)
    else:raise ValueError('Unknown continuous root curve kind')
    coefficient=curve['coefficient']
    if not coefficient.is_finite() or coefficient<0:raise ValueError('Recorded root rate must be finite and nonnegative')
    return coefficient*max(D(0),q).sqrt()


def recorded_root_knots(curve):
    """Times where one stored rate changes its affine-root expression."""
    kind=curve.get('curve_kind')
    if kind in ('sum_root_v1','sum_rates_v1'):
        return {time for term in tuple(curve['terms'])+tuple(curve.get('affine_terms',())) for time in recorded_root_knots(term)}
    if kind=='affine_rate_v1':
        slope=curve['slope_per_second']
        return {curve['reference_ms']-1000*curve['value_reference']/slope} if slope else set()
    if kind=='affine_root_v1':
        slope=curve['slope_per_second']
        return {curve['reference_ms']-1000*curve['q_reference']/slope} if slope<0 else set()
    if kind is None:return {curve['leave_ms'],curve['expiry_ms']}
    raise ValueError('Unknown continuous root curve kind')


def affine_rate_integral(value,reference,slope,begin,end):
    """Integral of a nonnegative affine rate, with exact zero-clipping time."""
    if any(not v.is_finite() for v in (value,reference,slope,begin,end)) or min(value,reference,begin,end)<0 or end<begin:
        raise ValueError('Invalid affine rate or interval')
    # reference is a value clock, not an activation timestamp. Clip at the
    # affine zero in either direction, consistently with recorded_root_rate.
    if slope>0:begin=max(begin,reference-1000*value/slope)
    elif slope<0:end=min(end,reference-1000*value/slope)
    if end<=begin:return D(0)
    first=max(D(0),value+slope*(begin-reference)/1000)
    last=max(D(0),value+slope*(end-reference)/1000)
    return (first+last)*(end-begin)/2000


def bleed_integral(basis_y, start_ms, begin_ms, end_ms, duration_ms=D(8000)):
    if any(not x.is_finite() or x < 0 for x in (basis_y, start_ms, begin_ms, end_ms)):
        raise ValueError('Bleed integration requires finite nonnegative inputs')
    if end_ms < begin_ms or duration_ms != 8000:
        raise ValueError('Bleeds last eight seconds and interval end must follow start')
    a, b = max(start_ms, begin_ms), min(end_ms, start_ms+duration_ms)
    if b <= a:
        return D(0)
    t0, t1 = (a-start_ms)/1000, (b-start_ms)/1000
    return basis_y * (t1-t0) * (8-(t0+t1)/2) / 320
