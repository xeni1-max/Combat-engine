"""Source constriction/tear rate, separate from control, armor loss and shields."""
from fractions import Fraction as F

from combat_sim.models import as_fraction

SOURCE='Damage types.odt p24-p32/Object 11; y2=d2-25*armor^2/(4*d2)'


def damage_rate(raw_per_second,armor):
    if isinstance(raw_per_second,bool) or isinstance(armor,bool):raise ValueError('Rates and armor must be numeric')
    raw,a=map(as_fraction,(raw_per_second,armor))
    if min(raw,a)<0:raise ValueError('Rates and armor must be nonnegative')
    return max(F(0),raw-F(25,4)*a*a/raw) if raw else F(0)
