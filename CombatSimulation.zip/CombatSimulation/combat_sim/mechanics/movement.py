"""Exact straight-line speed transitions, independent of combat scheduling.

Explicit endpoints and duration specify a constant-acceleration Active segment.
No start/stop timing, collision response, facing modifier or status application
is inferred by this primitive. Those belong to movement/combat rules.
"""
from dataclasses import dataclass
from fractions import Fraction

from combat_sim.models import as_fraction, UnsupportedMechanicError


def xy(values):
    values=tuple(as_fraction(v) for v in values)
    if len(values)!=2:
        raise ValueError('Straight-line ground motion requires two coordinates')
    return values


@dataclass(frozen=True)
class MovementState:
    elapsed_ms: Fraction
    position_m: tuple
    speed_mps: Fraction
    distance_m: Fraction


@dataclass(frozen=True)
class LinearSpeedTransition:
    origin_m: tuple
    direction_xy: tuple
    initial_speed_mps: Fraction
    final_speed_mps: Fraction
    duration_ms: Fraction

    def __post_init__(self):
        object.__setattr__(self,'origin_m',xy(self.origin_m))
        object.__setattr__(self,'direction_xy',xy(self.direction_xy))
        for name in ('initial_speed_mps','final_speed_mps','duration_ms'):
            object.__setattr__(self,name,as_fraction(getattr(self,name)))
        if sum(v*v for v in self.direction_xy)!=1:
            raise ValueError('Direction must be an explicit unit vector')
        if min(self.initial_speed_mps,self.final_speed_mps)<0 or self.duration_ms<=0:
            raise ValueError('Speeds must be nonnegative and Active duration positive')
        if self.initial_speed_mps>0 and self.final_speed_mps==0:
            raise UnsupportedMechanicError('Linear stopping is removed; use the instability-based slide mechanic')

    @property
    def acceleration_mps2(self):
        return (self.final_speed_mps-self.initial_speed_mps)/(self.duration_ms/1000)

    def at(self,elapsed_ms):
        elapsed=as_fraction(elapsed_ms)
        if not 0<=elapsed<=self.duration_ms:
            raise ValueError('Time is outside the specified Active transition')
        seconds=elapsed/1000
        speed=self.initial_speed_mps+self.acceleration_mps2*seconds
        distance=self.initial_speed_mps*seconds+self.acceleration_mps2*seconds**2/2
        position=tuple(p+d*distance for p,d in zip(self.origin_m,self.direction_xy))
        return MovementState(elapsed,position,speed,distance)


def standing_to_walk_transition(origin_m,direction_xy,profile):
    """Start walking using the stopping rate applied to the 0 -> walk change.

    Recovery/3 is superseded in both standing/walking directions. This covers
    the isolated acceleration segment; it does not apply stopping slide effects.
    """
    speed=as_fraction(profile['walking_speed_mps'])
    duration=stopping_slide_duration_ms(speed,profile)
    return LinearSpeedTransition(origin_m,direction_xy,0,speed,duration)


def stopping_slide_duration_ms(initial_speed_mps,profile):
    """Slide duration equals the base instability contributed by stopping.

    Running's +20% self-effect modifier is excluded from this duration by author
    clarification. This does not define a linear stopping trajectory. Returns
    duration only; the authored slide curve is implemented in mechanics/stopping.py.
    """
    speed=as_fraction(initial_speed_mps)
    coefficient=as_fraction(profile['stopping_base_instability_per_mps'])
    if speed<0 or coefficient<=0:
        raise ValueError('Stopping requires nonnegative speed and a positive duration coefficient')
    return speed*coefficient
