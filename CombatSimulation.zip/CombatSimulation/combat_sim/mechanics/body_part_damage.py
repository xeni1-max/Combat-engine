"""Authored body-part output and actual-contact selection, without targeting AI."""
from combat_sim.models import as_fraction


def part_overrides(values,known_parts):
    if not isinstance(values,dict):raise ValueError('Body-part damage must map actual part names to base output')
    known=frozenset(known_parts);rows=[]
    for part,base in values.items():
        if not isinstance(part,str) or part not in known or isinstance(base,bool):
            raise ValueError('Body-part damage needs a known body part and numeric base')
        amount=as_fraction(base)
        if amount<0:raise ValueError('Body-part damage must be nonnegative')
        rows.append((part,amount))
    return tuple(sorted(rows))


def contact_component(packet,available):
    """Pick from frozen outputs using the actual receiver, never the aim point.

    Existing closed-contact ties use stable lexical part identity. A solid or
    Block intercept has no anatomical hit, even if the aim target was a head.
    """
    component=packet['component']
    if component!='projectile' or packet.get('collision_kind')!='body' or 'block_layer_id' in packet:
        return component
    parts=packet.get('hit_parts')
    if not isinstance(parts,(list,tuple)) or not parts or any(not isinstance(p,str) or not p for p in parts):
        raise ValueError('Body-part damage requires actual contacted parts')
    selected='projectile:'+min(parts)
    return selected if selected in available else component
