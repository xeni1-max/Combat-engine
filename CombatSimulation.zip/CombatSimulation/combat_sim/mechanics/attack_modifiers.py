"""Immutable, composable attack values independent of actions and world state."""
from dataclasses import dataclass, fields
from fractions import Fraction as F

from combat_sim.models import as_fraction


@dataclass(frozen=True)
class ModifierValues:
    additional_piercing: F = F(0)
    additional_armor_loss: F = F(0)
    shielding_ignored: F = F(0)
    bleeding_multiplier: F = F(1)

    def __post_init__(self):
        for field in fields(self):
            if isinstance(getattr(self,field.name),bool):raise ValueError('Attack modifier values must be numeric')
            value=as_fraction(getattr(self,field.name))
            if value<0:raise ValueError('Attack modifier values must be nonnegative')
            object.__setattr__(self,field.name,value)

    def combine(self,other):
        return ModifierValues(self.additional_piercing+other.additional_piercing,
            self.additional_armor_loss+other.additional_armor_loss,
            self.shielding_ignored+other.shielding_ignored,
            self.bleeding_multiplier*other.bleeding_multiplier)

    def record(self):
        return {f.name:getattr(self,f.name) for f in fields(self)}
