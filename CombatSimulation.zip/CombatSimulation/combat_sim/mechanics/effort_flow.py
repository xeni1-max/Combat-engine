"""One bounded resource trajectory for additive sustained and fixed-rate effort.

Squared source costs add as rates before advancing the single dyspnea bar.
Equal-base and fixed-fill cases retain exact source solutions; mixed inputs
use one conditional dense solution, independent of observation prefixes.
"""
from dataclasses import dataclass
from decimal import Context,Decimal as D,localcontext

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.dense_rk import integrate
from combat_sim.mechanics.dyspnea import DyspneaContext,advance_continuous_action_dyspnea
from combat_sim.world_colliders import finite


@dataclass(frozen=True)
class EffortInput:
    id: str
    kind: str
    base: D

    def __post_init__(self):
        if not isinstance(self.id,str) or not self.id or self.kind not in ('squared','fill'):
            raise ValueError('Effort input needs an identity and squared/fill kind')
        object.__setattr__(self,'base',finite(self.base,'Continuous effort base'))


@dataclass(frozen=True)
class EffortPlan:
    begin: D
    end: D
    initial: D
    inputs: tuple
    precision: int
    mode: str
    cap_ms: D | None
    dense: object | None

    def knots(self):
        times={self.begin,self.end}
        if self.cap_ms is not None:times.add(self.cap_ms)
        if self.dense is not None:times.update(t for step in self.dense.steps for t in (step.begin,step.end))
        return tuple(sorted(times))

    def rate_bounds(self,begin,end):
        """Bounds for the committed D derivative, per second, on this interval."""
        with localcontext(Context(prec=self.precision)):
            if not self.begin<=begin<=end<=self.end:raise ValueError('Effort rate query is outside its plan')
            if self.mode=='constant' or self.cap_ms is not None and begin>=self.cap_ms:return D(0),D(0)
            end=min(end,self.cap_ms) if self.cap_ms is not None else end
            if self.mode=='linear':
                value=sum((i.base for i in self.inputs),D(0));low=high=value
            elif self.mode=='equal_squared':
                base=self.inputs[0].base
                low=len(self.inputs)*(base+self.at(begin)[0]/100)**2
                high=len(self.inputs)*(base+self.at(end)[0]/100)**2
            else:
                bounds=[]
                def polynomial(coefficients,a,b):
                    lo=hi=D(0)
                    for coefficient in reversed(coefficients):
                        products=(lo*a,lo*b,hi*a,hi*b)
                        lo,hi=min(products)+coefficient,max(products)+coefficient
                    return lo,hi
                for step in self.dense.steps:
                    if step.end<begin or step.begin>end:continue
                    a=(max(begin,step.begin)-step.begin)/(step.end-step.begin)
                    b=(min(end,step.end)-step.begin)/(step.end-step.begin);lo=hi=D(0)
                    for initial,q in zip(step.initial[1:],step.coefficients[1:]):
                        h=(step.end-step.begin)/1000
                        gain_low,gain_high=polynomial((initial,*(h*v for v in q)),a,b)
                        dl,dh=polynomial(tuple((i+1)*v for i,v in enumerate(q)),a,b)
                        if gain_high<=0:dl=dh=D(0)
                        elif gain_low<0:dl,dh=min(D(0),dl),max(D(0),dh)
                        lo+=dl;hi+=dh
                    bounds.append((lo,hi))
                low=min(b[0] for b in bounds);high=max(b[1] for b in bounds)
            if self.cap_ms is not None and end>=self.cap_ms:low=min(low,D(0))
            return low,high

    def at(self,time):
        with localcontext(Context(prec=self.precision)):
            time=finite(time,'Effort prefix time')
            if not self.begin<=time<=self.end:raise ValueError('Effort prefix is outside its plan')
            capped=self.cap_ms is not None and time>=self.cap_ms
            time=min(time,self.cap_ms) if self.cap_ms is not None else time
            seconds=(time-self.begin)/1000
            if self.mode=='constant':after=self.initial;gains=(D(0),)*len(self.inputs)
            elif self.mode=='linear':
                gains=tuple(i.base*seconds for i in self.inputs);after=self.initial+sum(gains,D(0))
            elif self.mode=='equal_squared':
                after=dec(advance_continuous_action_dyspnea(self.initial,self.inputs[0].base,
                    (time-self.begin)*len(self.inputs),context=DyspneaContext('airborne')).after)
                gains=((after-self.initial)/len(self.inputs),)*len(self.inputs)
            else:
                raw=self.dense.at(time);gains=tuple(max(D(0),g) for g in raw[1:])
                after=self.initial+sum(gains,D(0))
            after=D(100) if capped else min(D(100),after)
            total=sum(gains,D(0));actual=after-self.initial
            if total and total!=actual:gains=tuple(g*actual/total for g in gains)
            return after,gains


def build_effort_plan(begin,end,initial,inputs,*,precision=50,absolute=D('1e-14'),relative=D('1e-13')):
    if type(precision) is not int or precision<40:raise ValueError('Effort precision must be at least 40')
    with localcontext(Context(prec=precision)):
        begin,end,initial=(finite(v,n) for v,n in ((begin,'Effort begin'),(end,'Effort end'),(initial,'Dyspnea')))
        inputs=tuple(inputs)
        if end<=begin or initial>100 or any(not isinstance(i,EffortInput) for i in inputs):raise ValueError('Invalid effort interval or inputs')
        if len({i.id for i in inputs})!=len(inputs):raise ValueError('Effort inputs must have unique identities')
        mode='dense';dense=None;cap=None
        if initial==100 or not inputs or all(i.kind=='fill' and not i.base for i in inputs):mode='constant'
        elif all(i.kind=='fill' for i in inputs):
            mode='linear';rate=sum((i.base for i in inputs),D(0))
            time=begin+1000*(100-initial)/rate
            if time<=end:cap=time
        elif all(i.kind=='squared' and i.base==inputs[0].base for i in inputs):
            mode='equal_squared';base=inputs[0].base;value=base+initial/100
            if value:
                time=begin+100000*(1/value-1/(base+1))/len(inputs)
                if time<=end:cap=time
        else:
            def derivative(time,state):
                value=min(D(100),max(D(0),state[0]))
                rates=tuple((i.base+value/100)**2 if i.kind=='squared' else i.base for i in inputs)
                return (sum(rates,D(0)),*rates)
            dense=integrate(derivative,begin,end,(initial,)+(D(0),)*len(inputs),absolute=absolute,relative=relative)
            if dense.at(end)[0]>=100:
                low,high=begin,end
                for _ in range(precision*4):
                    if high-low<=D('1e-25'):break
                    middle=(low+high)/2
                    if dense.at(middle)[0]>=100:high=middle
                    else:low=middle
                cap=high
        return EffortPlan(begin,end,initial,inputs,precision,mode,cap,dense)
