"""Exact venomous damage-rate equation from the primary damage-types document."""

from fractions import Fraction

from combat_sim.models import as_fraction
from combat_sim.mechanics.slash import post_mitigation_damage as slash_damage
from combat_sim.exact import ExactRootProduct


SOURCE = "Damage types.odt, Venomous"
FORMULA = (
    "Td = 0 if d=0; otherwise max(0, (d^2 - max(0,a-p)^2) / d^2) "
    "* max(0, (Tp^2 - 10*max(0,RT-p/5)^2) / Tp) * sqrt(tT - to)"
)
DELIVERY_RATIO_FORMULA = "delivery = 0 if d=0, otherwise slash_post_armor_damage(d,a,p)/d; d is post-shield/pre-armor"


def venom_delivery_ratio(damage_after_shield, armor_before_thrust, piercing) -> Fraction:
    """Calculate how much of the slash component enables toxin delivery.

    Both numerator and denominator concern the slash damage left after shield.
    The numerator is its post-armor formula result, not HP loss capped by the
    victim's remaining HP. The author specifies zero delivery if shields absorb
    the entire thrust; d=0 therefore returns zero without dividing.
    """
    damage, armor, penetration = map(as_fraction, (damage_after_shield, armor_before_thrust, piercing))
    if min(damage, armor, penetration) < 0:
        raise ValueError("Venom delivery inputs must be nonnegative")
    if damage == 0:
        return Fraction(0)
    return slash_damage(damage, armor, penetration) / damage


def venomous_damage_rate(
    damage: Fraction,
    armor: Fraction,
    piercing: Fraction,
    toxicity: Fraction,
    toxin_resistance: Fraction,
    exposure_seconds: Fraction,
    non_exposure_seconds: Fraction,
) -> ExactRootProduct:
    """Evaluate Td exactly, retaining its square root without numeric rounding.

    The author confirms d is slash damage left after shields and before armor
    mitigation. This pure helper accepts that explicit amount; it does not
    perform the shield split. The author confirms armor is captured before
    the thrust/armor loss. The shared definitions of a and p are armor and
    piercing; the caller supplies the confirmed snapshot and clock values.
    Adjusted armor and resistance floor at zero before squaring, per user
    clarification. Each damage factor also floors at zero before multiplication,
    as separately confirmed by the user; two negative factors cannot produce
    positive damage. Every venomous attack contains a slash delivery component;
    the first factor is its post-armor/pre-armor ratio, both after shielding.
    Fully shielded d=0 gives no toxin damage, per explicit author clarification.
    Inputs outside the mathematical domain are rejected.
    """
    d = as_fraction(damage)
    a = as_fraction(armor)
    p = as_fraction(piercing)
    tp = as_fraction(toxicity)
    rt = as_fraction(toxin_resistance)
    tt = as_fraction(exposure_seconds)
    to = as_fraction(non_exposure_seconds)

    if tp == 0:
        raise ValueError("Venomous formula is undefined for Tp=0 (division by zero)")
    if min(d, a, p, tp, rt, tt, to) < 0:
        raise ValueError("Venomous formula inputs must be nonnegative")

    radicand = tt - to
    if radicand < 0:
        raise ValueError("Venomous formula requires tT >= to for a real square root")

    delivery_factor = venom_delivery_ratio(d, a, p)
    effective_resistance = max(Fraction(0), rt - p / 5)
    toxin_factor = max(
        Fraction(0), (tp**2 - 10 * effective_resistance**2) / tp,
    )
    coefficient = delivery_factor * toxin_factor
    if coefficient <= 0 or radicand == 0:
        return ExactRootProduct(Fraction(0), Fraction(0))
    return ExactRootProduct(coefficient, radicand)


def venomous_full_phase_damage(
    damage, armor, piercing, toxicity, toxin_resistance, exposure_seconds,
) -> ExactRootProduct:
    """Exact integral over one full exposure or post-exposure decay phase.

    With fixed delivery/defense inputs, Td=C*sqrt(q). The author confirms q
    grows 0→T during attachment and decays T→0 after detachment at one second
    per second. Either complete phase integrates to (2/3)*C*T*sqrt(T).
    This helper does not infer overlaps, shielded toxin rules, or snapshots.
    """
    duration = as_fraction(exposure_seconds)
    if duration < 0:
        raise ValueError("Exposure duration must be nonnegative")
    rate_at_one = venomous_damage_rate(damage, armor, piercing, toxicity, toxin_resistance, 1, 0)
    if duration == 0 or rate_at_one.coefficient == 0:
        return ExactRootProduct(Fraction(0), Fraction(0))
    return ExactRootProduct(Fraction(2, 3) * rate_at_one.coefficient * duration, duration)
