"""Persistent gravity trajectories with an explicit numerical stopping rule.

This bounded extension leaves the isolated gravity model unchanged. Positive
deceleration must exceed gravity, so speed decreases strictly until the first
configured speed-floor crossing. The trajectory then stays inert. Stopping is
not a collision and does not create damage or an impact location.

The precomputed state tuples never depend on observation queries. Binary64
adaptive RK4 and integrated arc length follow the existing gravity helper.
"""
from bisect import bisect_right
from math import ceil, hypot, isfinite

from combat_sim.mechanics.gravity import GRAVITY_MPS2, MotionState, ProjectileTrajectory
from combat_sim.models import UnsupportedMechanicError


def _number(value, name, *, positive=False):
    if isinstance(value, bool):
        raise ValueError(f'{name} must be a finite number')
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f'{name} must be a finite number') from error
    if not isfinite(result) or result < 0 or (positive and result == 0):
        raise ValueError(f'{name} must be finite and {"positive" if positive else "nonnegative"}')
    return result


def _vector(values, name):
    try:
        values = tuple(values)
        if len(values) != 3 or any(isinstance(value, bool) for value in values):
            raise ValueError
        result = tuple(float(value) for value in values)
        if not all(isfinite(value) for value in result):
            raise ValueError
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f'{name} needs three finite components') from error
    return result


class PersistentProjectileTrajectory(ProjectileTrajectory):
    """An immutable sampled path plus deterministic intermediate queries.

    ``duration`` remains the requested horizon. ``stopping_time_s`` is None
    unless deceleration reaches the numerical speed floor within that horizon.
    At and after stopping, position and traveled distance stay fixed and
    velocity is zero. The crossing bracket bounds the numerical solution;
    it is not a certified enclosure of the exact differential equation.

    Undecelerated flight uses the existing analytic ballistic formulas, with
    no stopping at the apex or at a small speed. Positive deceleration at or
    below gravity is explicitly outside this bounded stopping model.
    """

    def __init__(self, origin_m, velocity_mps, duration_s, *, deceleration_mps2=0,
                 gravity_mps2=GRAVITY_MPS2, max_step_s=.01, relative_tolerance=1e-11,
                 absolute_tolerance=1e-12, speed_floor_mps=1e-6,
                 stop_time_tolerance_s=1e-9):
        self.origin = _vector(origin_m, 'Origin')
        self.velocity = _vector(velocity_mps, 'Velocity')
        self.duration = _number(duration_s, 'Duration')
        self.deceleration = _number(deceleration_mps2, 'Deceleration')
        self.gravity = _number(gravity_mps2, 'Gravity')
        self.max_step = _number(max_step_s, 'Maximum step', positive=True)
        self.rtol = _number(relative_tolerance, 'Relative tolerance', positive=True)
        self.atol = _number(absolute_tolerance, 'Absolute tolerance', positive=True)
        self.speed_floor = _number(speed_floor_mps, 'Speed floor', positive=True)
        self.stop_time_tolerance = _number(stop_time_tolerance_s, 'Stop-time tolerance', positive=True)
        if self.deceleration and self.deceleration <= self.gravity:
            raise UnsupportedMechanicError('Persistent stopping requires deceleration greater than gravity')

        self.stopping_time_s = None
        self.stopping_time_bracket_s = None
        self.stopping_state = None
        initial = MotionState(0., self.origin, self.velocity, 0.)
        if not self.deceleration:
            count = max(1, ceil(self.duration / self.max_step))
            states = (tuple(self._ballistic(self.duration*i/count) for i in range(count+1))
                      if self.duration else (initial,))
        elif initial.speed_mps <= self.speed_floor:
            self.stopping_time_s = 0.
            self.stopping_time_bracket_s = (0., 0.)
            self.stopping_state = MotionState(0., self.origin, (0., 0., 0.), 0.)
            states = (self.stopping_state,)
        else:
            samples, bracket = self._integrate_safe(initial, self.duration, detect_stop=True)
            states = (initial, *samples)
            if bracket is not None:
                self.stopping_time_s = states[-1].time_s
                self.stopping_time_bracket_s = bracket
                end = states[-1]
                self.stopping_state = MotionState(end.time_s, end.position_m, (0., 0., 0.), end.distance_m)
                states = (*states[:-1], self.stopping_state)
        if self.stopping_time_s is not None and self.stopping_time_s < self.duration:
            stopped = self.stopping_state
            states = (*states, MotionState(self.duration, stopped.position_m, (0., 0., 0.), stopped.distance_m))
        self.states = tuple(states)
        self.times = tuple(state.time_s for state in self.states)

    def _two_half_steps(self, values, duration):
        return self._step(self._step(values, duration/2), duration/2)

    def _floor_crossing(self, start_time, values, duration, end_values):
        """Refine the first floor crossing within one accepted safe step."""
        low, high = 0., duration
        upper_values = end_values
        while high-low > self.stop_time_tolerance:
            middle = (low+high)/2
            if middle in (low, high):
                break
            candidate = self._two_half_steps(values, middle)
            if hypot(*candidate[3:6]) <= self.speed_floor:
                high, upper_values = middle, candidate
            else:
                low = middle
        return MotionState(start_time+high, upper_values[:3], upper_values[3:6], upper_values[6]), (
            start_time+low, start_time+high)

    def _integrate_safe(self, state, end, *, detect_stop):
        t = state.time_s
        values = (*state.position_m, *state.velocity_mps, state.distance_m)
        step = min(self.max_step, end-t)
        result = []
        while t < end:
            # The acceleration magnitude is bounded by d+g. Every RK stage
            # stays away from zero, including the full-step error estimator.
            safe_step = .8*hypot(*values[3:6])/(self.deceleration+self.gravity)
            step = min(step, end-t, safe_step)
            if t+step == t:
                raise ArithmeticError('Persistent trajectory step cannot advance at binary64 precision')
            whole = self._step(values, step)
            half = self._two_half_steps(values, step)
            if not all(isfinite(value) for value in (*whole, *half)):
                raise ArithmeticError('Persistent trajectory produced a nonfinite state')
            error = max(abs(a-b)/(15*(self.atol+self.rtol*max(abs(c), abs(b))))
                        for a, b, c in zip(whole, half, values))
            if error <= 1:
                if detect_stop and hypot(*half[3:6]) <= self.speed_floor:
                    stopped, bracket = self._floor_crossing(t, values, step, half)
                    result.append(stopped)
                    return result, bracket
                values = half
                t = end if step == end-t else t+step
                result.append(MotionState(t, values[:3], values[3:6], values[6]))
            factor = 2 if error == 0 else min(2, max(.1, .9*error**(-.2)))
            step = min(self.max_step, step*factor)
        return result, None

    def at(self, time_s):
        t = _number(time_s, 'Query time')
        if t > self.duration:
            raise ValueError('Requested time is outside the explicit trajectory horizon')
        if not self.deceleration:
            return self._ballistic(t)
        if self.stopping_time_s is not None and t >= self.stopping_time_s:
            stopped = self.stopping_state
            return MotionState(t, stopped.position_m, (0., 0., 0.), stopped.distance_m)
        state = self.states[bisect_right(self.times, t)-1]
        if state.time_s == t:
            return state
        samples, _ = self._integrate_safe(state, t, detect_stop=False)
        return samples[-1]
