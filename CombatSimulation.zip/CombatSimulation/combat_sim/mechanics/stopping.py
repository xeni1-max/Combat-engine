"""Instability-based special slide, independent of statuses and event scheduling.

Distance follows Details.odt with the author's zero floor. Duration uses base
stopping instability; speed decays linearly over that duration. The resulting
initial slide speed is derived from distance and duration, not the old running
speed. This is not the discarded ordinary linear braking rule.
"""
from dataclasses import dataclass
from decimal import Decimal as D, Context, ROUND_HALF_EVEN, localcontext
from fractions import Fraction

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.movement import stopping_slide_duration_ms
from combat_sim.models import as_fraction


@dataclass(frozen=True)
class SlideState:
    distance_m: D
    speed_mps: D


@dataclass(frozen=True)
class StoppingSlide:
    raw_distance_m: D
    resistance_reduction_m: D
    distance_m: D
    duration_ms: Fraction
    initial_slide_speed_mps: D
    acceleration_mps2: D
    precision: int

    def at(self,elapsed_ms):
        elapsed=as_fraction(elapsed_ms)
        if not 0<=elapsed<=self.duration_ms:
            raise ValueError('Time is outside the special slide duration')
        if not self.duration_ms:
            return SlideState(D(0),D(0))
        with localcontext(Context(prec=self.precision,rounding=ROUND_HALF_EVEN)):
            q=dec(elapsed)/dec(self.duration_ms)
            return SlideState(self.distance_m*(2*q-q*q),self.initial_slide_speed_mps*(1-q))


def calculate_stopping_slide(initial_speed_mps,max_hp,armor,profile,*,precision=50):
    """Calculate the confirmed fixed distance, duration and linear slide curve."""
    speed,hp,a=map(as_fraction,(initial_speed_mps,max_hp,armor))
    if min(speed,hp,a)<0:
        raise ValueError('Stopping speed, maximum HP and current armor must be nonnegative')
    if not isinstance(precision,int) or precision<40:
        raise ValueError('Stopping precision must be at least 40 digits')
    duration=stopping_slide_duration_ms(speed,profile)
    with localcontext(Context(prec=precision,rounding=ROUND_HALF_EVEN)):
        raw=dec(speed)/20
        resistance=(dec(hp)/500+dec(a)/10)**D('1.1')/250
        distance=max(D(0),raw-resistance)
        seconds=dec(duration)/1000
        start=2*distance/seconds if seconds else D(0)
        acceleration=-start/seconds if seconds else D(0)
        return StoppingSlide(raw,resistance,distance,duration,start,acceleration,precision)
