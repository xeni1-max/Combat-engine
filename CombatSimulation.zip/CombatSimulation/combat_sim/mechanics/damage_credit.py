"""Shield exclusion for damage-based healing and revival in root Details2.odt."""

from fractions import Fraction

from combat_sim.models import as_fraction


SOURCE = "Details2.odt, damage-based healing and revival"


def recovery_damage_basis(total_damage_done: Fraction, shield_damage_done: Fraction) -> Fraction:
    """Exclude shield damage from a supplied damage total.

    Callers supply damage actually credited by the relevant rule. This helper
    does not decide overkill, armor loss, damage ownership, or history windows.
    """
    total = as_fraction(total_damage_done)
    shield = as_fraction(shield_damage_done)
    if total < 0 or shield < 0 or shield > total:
        raise ValueError("Damage must satisfy 0 <= shield damage <= total damage")
    return total - shield


def damage_based_recovery_amount(
    total_damage_done: Fraction,
    shield_damage_done: Fraction,
    damage_fraction: Fraction,
) -> Fraction:
    """Calculate an entitlement before healing caps or revival state changes.

    The ratio is 1/5 for 2E4's 20% healing, or 1 for its damage-equal revival.
    No maximum ratio or HP cap is invented here.
    """
    ratio = as_fraction(damage_fraction)
    if ratio < 0:
        raise ValueError("Damage fraction must be nonnegative")
    return recovery_damage_basis(total_damage_done, shield_damage_done) * ratio
