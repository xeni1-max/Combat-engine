"""Simultaneous direct hits evaluated against one shared defense snapshot.

Author clarification for the stationary 2v2: shields absorb proportional raw
damage shares; each overflow then uses the defenses from before the batch.
These pure calculations do not schedule phase boundaries, attribute overkill,
apply statuses, or decide which controlled actions death cancels.
"""
from dataclasses import dataclass
from fractions import Fraction

from combat_sim.mechanics import blunt, qard, slash
from combat_sim.mechanics.shield import split_simultaneous_damage
from combat_sim.models import as_fraction


@dataclass(frozen=True)
class DamagePacket:
    damage_type: str
    incoming_damage: Fraction
    piercing: Fraction = Fraction(0)
    shielding_ignored: Fraction = Fraction(0)
    additional_armor_loss: Fraction = Fraction(0)


@dataclass(frozen=True)
class SnapshotImpact:
    pre_hit_armor: Fraction
    incoming_damage: Fraction
    shield_absorbed: Fraction
    damage_left_after_shield: Fraction
    raw_hp_damage: Fraction
    hp_damage: Fraction
    raw_armor_loss: Fraction
    armor_loss: Fraction


def calculate_simultaneous_impacts(packets, armor, shield, qard_resistance):
    """Return nominal per-hit results, preserving the supplied packet order.

    The caller applies the combined losses to shared state with its established
    HP/armor floors. Every packet here uses the same pre-batch armor regardless
    of another packet's armor loss. Per-packet HP damage remains its own bleed
    basis under the existing slash rule.
    """
    packets = tuple(packets)
    armor, resistance = map(as_fraction, (armor, qard_resistance))
    if armor < 0 or resistance < 0:
        raise ValueError('Armor and Qard resistance must be nonnegative')
    for packet in packets:
        if packet.damage_type not in ('slash', 'qard','blunt','contact'):
            raise ValueError('Only supported direct damage or contact packets can share this batch')
        if packet.damage_type=='contact' and any(as_fraction(v) for v in (
                packet.incoming_damage,packet.piercing,packet.shielding_ignored,packet.additional_armor_loss)):
            raise ValueError('A contact-only packet cannot carry damage or damage modifiers')
        if as_fraction(packet.piercing) < 0:
            raise ValueError('Piercing must be nonnegative')
        if as_fraction(packet.shielding_ignored)<0 or as_fraction(packet.additional_armor_loss)<0:
            raise ValueError('Shield bypass and additional armor loss must be nonnegative')
        if packet.damage_type=='blunt' and as_fraction(packet.piercing):
            raise ValueError('The authored blunt equation has no piercing input')
    shares = split_simultaneous_damage((p.incoming_damage for p in packets), shield,
        shielding_ignored=(p.shielding_ignored for p in packets))
    results = []
    for packet, (absorbed, overflow) in zip(packets, shares):
        incoming = as_fraction(packet.incoming_damage)
        if packet.damage_type=='contact':
            raw_y=y=raw_ar=ar=Fraction(0)
        elif packet.damage_type == 'slash':
            hit = slash.calculate_impact(incoming, armor, packet.piercing, absorbed)
            raw_y, y, raw_ar, ar = (hit.raw_hp_damage, hit.hp_damage,
                                    hit.raw_armor_loss, hit.armor_loss)
        elif packet.damage_type=='blunt':
            raw_y=blunt.raw_post_mitigation_damage(overflow,armor) if overflow else Fraction(0)
            raw_ar=blunt.raw_armor_reduction(overflow,armor) if overflow else Fraction(0)
            y,ar=max(Fraction(0),raw_y),max(Fraction(0),raw_ar)
        else:
            raw_y = qard.raw_post_mitigation_damage(overflow, armor, resistance) if overflow else Fraction(0)
            y, raw_ar, ar = max(Fraction(0), raw_y), Fraction(0), Fraction(0)
        if overflow:
            raw_ar+=as_fraction(packet.additional_armor_loss)
            ar+=as_fraction(packet.additional_armor_loss)
        results.append(SnapshotImpact(armor, incoming, absorbed, overflow, raw_y, y, raw_ar, ar))
    return tuple(results)
