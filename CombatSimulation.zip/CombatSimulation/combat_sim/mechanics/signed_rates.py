"""Root isolation for signed sums of affine-root flow rates.

Interval bounds and derivative signs prove open-cell signs. Equal clock terms
are combined to avoid interval dependency on cancelling expressions. Clock
normalization is below the coupled solver's declared HP error budget.
"""
from dataclasses import dataclass
from decimal import Decimal as D

TIME_TOLERANCE_MS=D('1e-12')
CLOCK_QUANTUM=D('1e-28')
RATE_EPS=D('1e-24')
SIGN_RATE_TOLERANCE=D('1e-18')


@dataclass(frozen=True)
class SignedRate:
    origin: D
    constant: D
    terms: tuple  # (coefficient, normalized q at origin, slope +/-1)
    pairs: tuple = ()  # c*(sqrt(q_a+s*t)-sqrt(q_b+s*t)), evaluated stably
    linear_per_second: D = D(0)
    clipped_affine: tuple = ()

    @classmethod
    def combine(cls,origin,shapes):
        constant=D(0);terms={};linear=D(0);affine={}
        for multiplier,shape in shapes:
            constant+=multiplier*shape.constant_per_second
            for term in shape.affine_terms:
                value=term.value_reference+term.slope_per_second*(origin-term.reference_ms)/1000
                if value<=0 and term.slope_per_second<=0:continue
                if value>=0 and term.slope_per_second>=0:
                    constant+=multiplier*value;linear+=multiplier*term.slope_per_second
                else:
                    key=(value,term.slope_per_second)
                    affine[key]=affine.get(key,D(0))+multiplier
            for term in shape.terms:
                coefficient=multiplier*term.coefficient;slope=term.slope_per_second
                q=max(D(0),term.q_reference+slope*(origin-term.reference_ms)/1000)
                if not slope:
                    constant+=coefficient*q.sqrt();continue
                if not q and slope<0:continue
                scale=abs(slope)
                key=((q/scale).quantize(CLOCK_QUANTUM),D(1) if slope>0 else D(-1))
                terms[key]=terms.get(key,D(0))+coefficient*scale.sqrt()
        values=[[c,q,s] for (q,s),c in sorted(terms.items()) if abs(c)>RATE_EPS];pairs=[]
        for positive in values:
            if positive[0]<=0:continue
            negatives=sorted((v for v in values if v[0]<0 and v[2]==positive[2]),key=lambda v:abs(v[1]-positive[1]))
            for negative in negatives:
                amount=min(positive[0],-negative[0])
                if not amount:continue
                if positive[1]!=negative[1]:pairs.append((amount,positive[1],negative[1],positive[2]))
                positive[0]-=amount;negative[0]+=amount
                if not positive[0]:break
        result=tuple(tuple(v) for v in values if abs(v[0])>RATE_EPS)
        clipped=tuple((c,q,s) for (q,s),c in sorted(affine.items()) if c)
        return cls(origin,D(0) if abs(constant)<=RATE_EPS else constant,result,tuple(pairs),linear,clipped)

    def _pair_value(self,pair,time,derivative=False):
        c,a,b,s=pair;qa=max(D(0),a+s*(time-self.origin)/1000);qb=max(D(0),b+s*(time-self.origin)/1000)
        if derivative:
            return -c*s*(a-b)/(2*qa.sqrt()*qb.sqrt()*(qa.sqrt()+qb.sqrt()))
        denominator=qa.sqrt()+qb.sqrt()
        return c*(qa-qb)/denominator if denominator else D(0)

    def value(self,time):
        result=(self.constant+sum((c*max(D(0),q+s*(time-self.origin)/1000).sqrt() for c,q,s in self.terms),D(0))+
            sum((self._pair_value(pair,time) for pair in self.pairs),D(0)))
        if self.linear_per_second:result+=self.linear_per_second*(time-self.origin)/1000
        if self.clipped_affine:result+=sum(c*max(D(0),q+s*(time-self.origin)/1000) for c,q,s in self.clipped_affine)
        return result

    def bounds(self,begin,end,*,derivative=False):
        low=high=D(0) if derivative else self.constant
        if self.linear_per_second:
            if derivative:low=high=self.linear_per_second
            else:
                a=self.linear_per_second*(begin-self.origin)/1000;b=self.linear_per_second*(end-self.origin)/1000
                low+=min(a,b);high+=max(a,b)
        for c,q,s in self.clipped_affine:
            a=q+s*(begin-self.origin)/1000;b=q+s*(end-self.origin)/1000
            if derivative:
                if max(a,b)<=0:x=y=D(0)
                elif min(a,b)>=0:x=y=c*s
                else:x,y=D(0),c*s
            else:x,y=c*max(D(0),a),c*max(D(0),b)
            low+=min(x,y);high+=max(x,y)
        for c,q,s in self.terms:
            a=max(D(0),q+s*(begin-self.origin)/1000)
            b=max(D(0),q+s*(end-self.origin)/1000)
            if derivative:
                numerator=c*s
                minimum,maximum=min(a,b),max(a,b)
                if not maximum:continue
                near=numerator/(2*maximum.sqrt())
                far=numerator/(2*minimum.sqrt()) if minimum else (D('Infinity') if numerator>0 else D('-Infinity'))
                x,y=near,far
                if not minimum:
                    low+=min(x,y,D(0));high+=max(x,y,D(0));continue
            else:x,y=c*a.sqrt(),c*b.sqrt()
            low+=min(x,y);high+=max(x,y)
        for pair in self.pairs:
            c,a,b,s=pair
            clocks=[q+s*(t-self.origin)/1000 for q in (a,b) for t in (begin,end)]
            if min(clocks)>0:x,y=self._pair_value(pair,begin,derivative),self._pair_value(pair,end,derivative)
            elif derivative:x,y=D('-Infinity'),D('Infinity')
            else:x,y=D(0),c*abs(a-b).sqrt()*((a>b)-(a<b))
            low+=min(x,y);high+=max(x,y)
        return low,high

    def cells(self,begin,end):
        """(begin,end,sign) intervals; root uncertainty is <= time tolerance."""
        pending=[(begin,end)];cells=[];count=0
        while pending:
            a,b=pending.pop();count+=1
            if count>30000:raise ArithmeticError('Signed rate root isolation exceeded its work bound')
            lo,hi=self.bounds(a,b)
            if max(abs(lo),abs(hi))<=SIGN_RATE_TOLERANCE:sign=0
            elif lo>=0:sign=1 if hi else 0
            elif hi<=0:sign=-1
            else:
                va,vb=self.value(a),self.value(b)
                dl,dh=self.bounds(a,b,derivative=True)
                if dl>=0 and va>=0 or dh<=0 and vb>=0:sign=1
                elif dl>=0 and vb<=0 or dh<=0 and va<=0:sign=-1
                elif b-a<=TIME_TOLERANCE_MS:
                    value=self.value((a+b)/2);sign=(value>0)-(value<0)
                else:
                    middle=(a+b)/2;pending.extend(((middle,b),(a,middle)));continue
            if cells and cells[-1][2]==sign:
                cells[-1]=(cells[-1][0],b,sign)
            else:cells.append((a,b,sign))
        return cells
