"""Author-defined whole-body angular speed, independent of steering policy.

For every 90 degrees: 150 ms + 200 ms per 5 m/s current movement speed.
The helpers take an explicit scalar speed; they do not choose a heading,
rotation direction, movement steering or a speed-sampling policy.
"""
from fractions import Fraction
from combat_sim.models import as_fraction


def quarter_turn_time_ms(current_speed_mps):
    speed=as_fraction(current_speed_mps)
    if speed<0:raise ValueError('Movement speed must be nonnegative')
    return Fraction(150)+Fraction(200)*speed/5


def turn_rate_degrees_per_second(current_speed_mps):
    return Fraction(90000)/quarter_turn_time_ms(current_speed_mps)


def fixed_speed_turn_duration_ms(angle_degrees,current_speed_mps):
    """Duration for an explicit angle magnitude at unchanged movement speed."""
    return abs(as_fraction(angle_degrees))*quarter_turn_time_ms(current_speed_mps)/90


def fixed_speed_turn_progress_degrees(elapsed_ms,current_speed_mps):
    elapsed=as_fraction(elapsed_ms)
    if elapsed<0:raise ValueError('Elapsed turn time must be nonnegative')
    return elapsed*90/quarter_turn_time_ms(current_speed_mps)
