"""Source equilibrium-loss clock, separate from geometry, actions and policy.

Progress integrates 1/tF while both statuses are positive. Statuses decay at
one unit per millisecond. Partial loss recovers at the zero-status base rate;
completed knockdown requires the independently defined Get Up ability.
"""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.mechanics.velocity_projection import number


BASE_FALL_MS=F(1500)
STATUS_SCALE=F(400)


def fall_duration_ms(disorientation,instability):
    o,u=number(disorientation),number(instability)
    return BASE_FALL_MS/(1+(o+u)/STATUS_SCALE)


@dataclass(frozen=True)
class BalancePiece:
    """Exact progress polynomial until the first status/range boundary.

    Velocity/acceleration use seconds; start/end use milliseconds. The caller
    chooses interval boundaries and owns knockdown/recovery lifecycle.
    """
    begin_ms: F
    end_ms: F
    progress: F
    velocity_per_s: F
    acceleration_per_s2: F
    kind: str

    def __post_init__(self):
        for name in ('begin_ms','end_ms','progress','velocity_per_s','acceleration_per_s2'):
            # Rates may be negative; Fraction rejects NaN and infinities.
            value=getattr(self,name)
            if isinstance(value,bool):raise ValueError('Balance coefficients must be numeric')
            object.__setattr__(self,name,F(value))
        if self.begin_ms<0 or self.end_ms<self.begin_ms or not 0<=self.progress<=1:
            raise ValueError('Invalid balance clock/progress')
        if self.kind not in ('falling','recovering','held'):raise ValueError('Invalid balance segment kind')

    def at(self,time_ms):
        time=number(time_ms)
        if not self.begin_ms<=time<=self.end_ms:raise ValueError('Balance query outside its interval')
        seconds=(time-self.begin_ms)/1000
        return self.progress+self.velocity_per_s*seconds+self.acceleration_per_s2*seconds*seconds/2

    def rate(self,time_ms):
        time=number(time_ms)
        if not self.begin_ms<=time<=self.end_ms:raise ValueError('Balance query outside its interval')
        return self.velocity_per_s+self.acceleration_per_s2*(time-self.begin_ms)/1000

    def crossing(self,value,*,value_tolerance=F(1,10**42)):
        """Rational bracket of a monotone progress crossing, or None.

        Tolerance controls progress, independent of potentially huge status
        speeds. Exact endpoints return zero-width brackets. No float root or
        observation interval supplies the crossing.
        """
        value=number(value);tolerance=number(value_tolerance,positive=True)
        low,high=self.begin_ms,self.end_ms;first,last=self.at(low),self.at(high)
        if value==first:return low,low
        if value==last:return high,high
        if not min(first,last)<value<max(first,last):return None
        if not self.acceleration_per_s2 and self.velocity_per_s:
            exact=self.begin_ms+(value-self.progress)*1000/self.velocity_per_s
            return exact,exact
        sign=1 if last>first else -1
        if self.rate(low)*sign<0 or self.rate(high)*sign<0:
            raise ValueError('Balance crossing requires a monotone segment')
        while abs(self.at(high)-self.at(low))>tolerance:
            middle=(low+high)/2
            current=self.at(middle)
            if current==value:return middle,middle
            if (current-value)*sign<0:low=middle
            else:high=middle
        return low,high


def balance_piece(begin_ms,end_ms,progress,disorientation,instability,*,held=False):
    """Build source-rate progress; split before either status expires.

    The declared interval may reach past progress 0/1. ``crossing`` locates
    its first terminal boundary, which the shared coordinator must commit.
    """
    begin,end,q,o,u=map(number,(begin_ms,end_ms,progress,disorientation,instability))
    if end<begin or not 0<=q<=1 or type(held) is not bool:raise ValueError('Invalid balance interval')
    if held or q==1:
        return BalancePiece(begin,end,q,0,0,'held')
    if o and u:
        end=min(end,begin+min(o,u))
        velocity=1000/fall_duration_ms(o,u)
        acceleration=-F(2_000_000)/(BASE_FALL_MS*STATUS_SCALE)
        return BalancePiece(begin,end,q,velocity,acceleration,'falling')
    return BalancePiece(begin,end,q,-1000/BASE_FALL_MS if q else 0,0,'recovering' if q else 'held')
