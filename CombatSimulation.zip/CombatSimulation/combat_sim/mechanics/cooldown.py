"""Cooldown progress as work, with independently composable pause sources."""
from dataclasses import dataclass, field
from decimal import Decimal as D

from combat_sim.world_colliders import finite


@dataclass
class CooldownClock:
    reference_ms: D = D(0)
    remaining_ms: D = D(0)
    pauses: set = field(default_factory=set)
    revision: int = 0
    stopped: bool = False

    def __post_init__(self):
        self.reference_ms=finite(self.reference_ms,'Cooldown reference')
        self.remaining_ms=finite(self.remaining_ms,'Cooldown work')
        self.pauses=set(self.pauses)
        for source in self.pauses:self._source(source)

    @staticmethod
    def _source(source):
        if not isinstance(source,str) or not source:raise ValueError('Pause source needs a nonempty identity')

    def remaining(self,time):
        time=finite(time,'Cooldown time')
        if time<self.reference_ms:raise ValueError('Cooldown cannot be read before its reference')
        return self.remaining_ms if self.pauses or self.stopped else max(D(0),self.remaining_ms-time+self.reference_ms)

    def ready_at(self,time):
        self.remaining(time)
        if self.stopped or self.pauses and self.remaining_ms:return None
        return self.reference_ms+self.remaining_ms if not self.pauses else self.reference_ms

    def start(self,time,work_ms,*,allow_stopped=False):
        time=finite(time,'Cooldown time');work=finite(work_ms,'Cooldown work');remaining=self.remaining(time)
        if type(allow_stopped) is not bool:raise ValueError('Stopped commitment must be explicit')
        if self.stopped and not allow_stopped:raise ValueError('Stopped cooldown needs an explicit lifecycle transition')
        if remaining:raise ValueError('Cannot restart an unfinished cooldown')
        self.reference_ms=time;self.remaining_ms=work;self.revision+=1

    def pause(self,time,source,enabled):
        self._source(source)
        if type(enabled) is not bool:raise ValueError('Pause state must be boolean')
        time=finite(time,'Cooldown time');remaining=self.remaining(time)
        if self.stopped or (source in self.pauses)==enabled:return False
        self.reference_ms=time;self.remaining_ms=remaining
        if enabled:self.pauses.add(source)
        else:self.pauses.remove(source)
        self.revision+=1
        return True

    def add_work(self,time,work_ms):
        """Append recharge work while preserving progress and all pause sources."""
        time=finite(time,'Cooldown time');work=finite(work_ms,'Additional cooldown work')
        remaining=self.remaining(time)
        if self.stopped:raise ValueError('Stopped cooldown needs an explicit lifecycle transition')
        if work<=0:raise ValueError('Additional cooldown work must be positive')
        self.reference_ms=time;self.remaining_ms=remaining+work;self.revision+=1

    def stop(self,time):
        time=finite(time,'Cooldown time');remaining=self.remaining(time)
        if self.stopped:return
        self.remaining_ms=remaining;self.reference_ms=time;self.stopped=True;self.revision+=1

    def resume(self,time,*,pause_sources=()):
        time=finite(time,'Cooldown resume time')
        self.remaining(time)
        sources=set(pause_sources)
        for source in sources:self._source(source)
        if not self.stopped:raise ValueError('Only a stopped cooldown can resume')
        self.reference_ms=time;self.pauses=sources;self.stopped=False;self.revision+=1

    def record(self,time):
        remaining=self.remaining(time)
        return {'remaining_work_ms':remaining,'reference_ms':self.reference_ms,'revision':self.revision,
            'pause_sources':sorted(self.pauses),'ready_at_ms':self.ready_at(time),
            'state':'stopped' if self.stopped else 'ready' if not remaining else 'paused' if self.pauses else 'running'}


class CooldownBook:
    """An actor's clocks inherit current area pauses when new work starts."""
    def __init__(self,now,abilities):
        self.now=now
        self.clocks={key:CooldownClock() for key in abilities}

    def record(self):return {key:clock.record(self.now()) for key,clock in sorted(self.clocks.items())}
