"""Integer-millisecond impact timing for explicitly documented attack timelines."""

from decimal import Context, Decimal, ROUND_CEILING, ROUND_HALF_EVEN, localcontext
from fractions import Fraction
from typing import Any

from combat_sim.models import UnsupportedMechanicError

TIMING_PRECISION = 50
TIMING_CONTEXT = Context(prec=TIMING_PRECISION, rounding=ROUND_HALF_EVEN)


def _decimal(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, Fraction):
        with localcontext(TIMING_CONTEXT):
            return Decimal(value.numerator) / Decimal(value.denominator)
    return Decimal(str(value))


def _ceil(value: Decimal) -> int:
    return int(value.to_integral_value(rounding=ROUND_CEILING))


def _number_text(value: Decimal) -> str:
    with localcontext(TIMING_CONTEXT):
        return format(value.normalize(), "f")


def _number_value(value: Decimal) -> int | str:
    if value == value.to_integral_value():
        return int(value)
    return _number_text(value)


def _projectile_travel_time_ms(
    distance_m: Decimal,
    initial_speed_mps: Decimal,
    acceleration_mps2: Decimal,
) -> tuple[int, Decimal, str]:
    if distance_m < 0:
        raise ValueError("Target distance must be nonnegative")
    if initial_speed_mps <= 0:
        raise ValueError("Projectile initial speed must be positive")
    if distance_m == 0:
        return 0, Decimal(0), "distance = speed × time + 1/2 × acceleration × time²"

    with localcontext(TIMING_CONTEXT):
        if acceleration_mps2 == 0:
            travel_seconds = distance_m / initial_speed_mps
            formula = "time = distance / speed"
        else:
            discriminant = initial_speed_mps**2 + Decimal(2) * acceleration_mps2 * distance_m
            if discriminant < 0:
                raise UnsupportedMechanicError(
                    "Projectile distance exceeds the reachable distance under the documented constant acceleration"
                )
            root = discriminant.sqrt()
            denominator = initial_speed_mps + root
            if denominator <= 0:
                raise UnsupportedMechanicError("Projectile timing has no positive travel-time solution")
            travel_seconds = (Decimal(2) * distance_m) / denominator
            formula = "distance = initial_speed × time + 1/2 × acceleration × time²"
        travel_ms = travel_seconds * Decimal(1000)
        return _ceil(travel_ms), travel_ms, formula


def impact_time_from_activation(
    action_start_ms: int | Fraction,
    ability: dict[str, Any],
    target_distance_m: Any | None = None,
    *,
    disorientation_at_gathering_start: Any = 0,
    is_running_at_gathering_start: bool = False,
) -> tuple[int, dict[str, Any]]:
    """Return a whole-millisecond impact time and a calculation record.

    For projectile paths, listed acceleration is interpreted as constant along
    the travel direction. Fractional millisecond results are rounded upward.
    The caller supplies current disorientation at Gathering start; J=O adds
    that many milliseconds after running modifies only base Gathering.
    Current disorientation already includes any earlier self-status running
    penalty. This helper does not apply or decay status events.
    The default zero calculates the unmodified timeline.
    """
    with localcontext(TIMING_CONTEXT):
        return _impact_time_from_activation(
            action_start_ms, ability, target_distance_m,
            disorientation_at_gathering_start=disorientation_at_gathering_start,
            is_running_at_gathering_start=is_running_at_gathering_start,
        )


def self_effect_time_from_activation(
    action_start_ms: int | Fraction,
    ability: dict[str, Any],
    application_timing: str,
    target_distance_m: Any | None = None,
    *,
    disorientation_at_gathering_start: Any = 0,
    is_running_at_gathering_start: bool = False,
) -> tuple[int, dict[str, Any]]:
    """Calculate a specified self-effect trigger, without applying its status.

    The author confirms projectile self effects described as on firing/on throw
    occur at the middle of Active, independently of release or target impact.
    Other abilities explicitly specify on-impact self effects. A contact event
    still requires an external timestamp; this helper does not infer geometry.
    Status magnitude, mitigation, and later decay are separate calculations.
    """
    if application_timing not in {"middle_of_active", "impact"}:
        raise UnsupportedMechanicError(
            f"Self-effect timing {application_timing!r} has no supported explicit event anchor"
        )
    anchored_ability = dict(ability)
    if application_timing == "middle_of_active":
        anchored_ability["impact_timing"] = "middle_of_active"
    event_time, calculation = impact_time_from_activation(
        action_start_ms, anchored_ability, target_distance_m,
        disorientation_at_gathering_start=disorientation_at_gathering_start,
        is_running_at_gathering_start=is_running_at_gathering_start,
    )
    calculation.pop("impact_timing")
    calculation["ability_impact_timing"] = ability.get("impact_timing")
    calculation["self_effect_application_timing"] = application_timing
    calculation["self_effect_offset_ms"] = calculation.pop("impact_offset_ms")
    calculation["self_effect_time_ms"] = calculation.pop("impact_time_ms")
    return event_time, calculation


def _impact_time_from_activation(
    action_start_ms: int | Fraction,
    ability: dict[str, Any],
    target_distance_m: Any | None,
    *,
    disorientation_at_gathering_start: Any,
    is_running_at_gathering_start: bool,
) -> tuple[int, dict[str, Any]]:
    start = _decimal(action_start_ms)
    if start < 0 or start != start.to_integral_value():
        raise ValueError("Action start time must be a nonnegative integer millisecond")

    try:
        preparation = _decimal(ability.get("preparation_ms", 0))
        gathering = _decimal(ability["gathering_ms"])
        active = _decimal(ability["active_ms"])
        anchor = ability["impact_timing"]
    except KeyError as exc:
        raise UnsupportedMechanicError(
            f"Ability timing is missing required field {exc.args[0]!r}"
        ) from exc
    if preparation < 0 or gathering < 0 or active < 0:
        raise ValueError("Preparation, Gathering, and Active durations must be nonnegative")
    additional_gathering = _decimal(disorientation_at_gathering_start)
    if additional_gathering < 0:
        raise ValueError("Disorientation at Gathering start must be nonnegative")
    if not isinstance(is_running_at_gathering_start, bool):
        raise ValueError("Running at Gathering start must be a boolean")

    action_start = int(start)
    preparation_ms = _number_value(preparation)
    gathering_ms = _number_value(gathering)
    active_ms = _number_value(active)
    running_multiplier = Decimal("1.2") if is_running_at_gathering_start else Decimal(1)
    modified_base_gathering = gathering * running_multiplier
    effective_gathering = modified_base_gathering + additional_gathering
    before_active = preparation + effective_gathering
    before_active_ms = _ceil(before_active)
    active_start_ms = action_start + before_active_ms
    timing_record: dict[str, Any] = {
        "action_start_ms": action_start,
        "preparation_ms": preparation_ms,
        "gathering_ms": gathering_ms,
        "is_running_at_gathering_start": is_running_at_gathering_start,
        "running_gathering_multiplier": _number_value(running_multiplier),
        "modified_base_gathering_ms": _number_value(modified_base_gathering),
        "additional_gathering_ms": _number_value(additional_gathering),
        "effective_gathering_ms": _number_value(effective_gathering),
        "disorientation_at_gathering_start": _number_value(additional_gathering),
        "gathering_modifier_rule": "Collision details.odt: added Gathering J equals current disorientation O",
        "active_ms": active_ms,
        "active_end_ms": action_start + _ceil(before_active + active),
        "impact_timing": anchor,
        "rounding_rule": "round fractional event times up to the next whole millisecond",
    }

    if anchor in {"start_of_active", "middle_of_active", "end_of_active"}:
        impact_offset = (
            _ceil(before_active) if anchor == "start_of_active" else
            _ceil(before_active + active / 2)
            if anchor == "middle_of_active"
            else _ceil(before_active + active)
        )
        timing_record["active_start_ms"] = active_start_ms
        timing_record["impact_offset_ms"] = impact_offset
        timing_record["impact_time_ms"] = action_start + impact_offset
        return action_start + impact_offset, timing_record

    if anchor != "projectile":
        raise UnsupportedMechanicError(f"Unsupported impact timing anchor {anchor!r}")

    if target_distance_m is None:
        fallback = ability.get("fallback_anchor")
        if fallback not in {"middle_of_active", "end_of_active"}:
            raise UnsupportedMechanicError(
                "Projectile target distance is required because this ability has no documented fallback impact anchor"
            )
        impact_offset = (
            _ceil(before_active + active / 2)
            if fallback == "middle_of_active"
            else _ceil(before_active + active)
        )
        timing_record.update(
            {
                "used_fallback": fallback,
                "active_start_ms": active_start_ms,
                "impact_offset_ms": impact_offset,
                "impact_time_ms": action_start + impact_offset,
            }
        )
        return action_start + impact_offset, timing_record

    if ability.get("projectile_release_timing") != "after_active":
        raise UnsupportedMechanicError("Projectile release timing is not specified as after Active")
    if "projectile_speed_mps" not in ability:
        raise UnsupportedMechanicError("Projectile speed is required to calculate travel time")

    distance = _decimal(target_distance_m)
    initial_speed = _decimal(ability["projectile_speed_mps"])
    acceleration = _decimal(ability.get("projectile_acceleration_mps2", 0))
    travel_ms, exact_travel_ms, formula = _projectile_travel_time_ms(
        distance, initial_speed, acceleration
    )
    release_offset_ms = _ceil(before_active + active)
    impact_offset = release_offset_ms + travel_ms
    timing_record.update(
        {
            "projectile_release_timing": "after_active",
            "projectile_release_time_ms": action_start + release_offset_ms,
            "target_distance_m": _number_text(distance),
            "projectile_initial_speed_mps": _number_text(initial_speed),
            "projectile_acceleration_mps2": _number_text(acceleration),
            "travel_time_formula": formula,
            "travel_time_unrounded_ms": _number_text(exact_travel_ms),
            "travel_time_ms": travel_ms,
            "impact_offset_ms": impact_offset,
            "impact_time_ms": action_start + impact_offset,
            "projectile_distance_interpretation": "target_distance_m is path length from release point to target",
            "projectile_speed_interpretation": "listed projectile speed or velocity is treated as speed at release",
            "acceleration_interpretation": "constant along the travel direction",
            "travel_solution": "earliest positive travel-time root",
        }
    )
    return action_start + impact_offset, timing_record
