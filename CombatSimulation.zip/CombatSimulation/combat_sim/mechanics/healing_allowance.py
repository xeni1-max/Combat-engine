"""Consumable FIFO healing capacity backed by actual recent incoming HP loss.

Each incoming HP unit funds a fraction of one healing HP. A cumulative funding
cursor retires spent or expired units, so aging never makes a spent wound pay
again and old healing does not permanently penalize genuinely new wounds.
"""
from dataclasses import dataclass,field
from decimal import Decimal as D,localcontext

from combat_sim.world_colliders import finite


@dataclass(frozen=True)
class HealingQuote:
    actor: str
    time: D
    requested: D
    amount: D
    funding_total: D
    funding_expired: D
    cursor_before: D
    cursor_base: D
    cursor_after: D
    revision: int
    history_bound: D
    history_entries: int
    owner: object = field(repr=False,compare=False)

    def record(self):
        return {key:value for key,value in vars(self).items()
            if key not in ('owner','revision','history_bound','history_entries')}


class HealingAllowance:
    def __init__(self,history,*,fraction=D('.9'),window_ms=8000):
        self.history=history
        with localcontext(history.context):
            self.fraction=finite(fraction,'Healing cap fraction',positive=True)
            self.window=finite(window_ms,'Healing cap window',positive=True)
        if self.fraction>1:raise ValueError('Healing cap fraction cannot exceed one')
        self.cursors={};self.revisions={};self.claims={};self.last_time=D(0);self.owner=object()

    @staticmethod
    def _actor(actor):
        if not isinstance(actor,str) or not actor:raise ValueError('Healing requires an actor identity')

    def funding(self,actor,time):
        self._actor(actor)
        with localcontext(self.history.context):
            time=finite(time,'Healing time')
            total=self.fraction*self.history.amount(target=actor,end=time)
            expired=(self.fraction*self.history.amount(target=actor,end=time-self.window)
                if time>=self.window else D(0))
            return total,expired

    def available(self,actor,time):
        with localcontext(self.history.context):
            total,expired=self.funding(actor,time)
            return max(D(0),total-max(self.cursors.get(actor,D(0)),expired))

    def quote(self,actor,time,requested,*,missing_hp,alive=True):
        with localcontext(self.history.context):
            time=finite(time,'Healing time');requested=finite(requested,'Requested healing')
            missing=finite(missing_hp,'Missing HP')
            if type(alive) is not bool:raise ValueError('Healing liveness must be explicit')
            if time<self.last_time:raise ValueError('Healing cannot be paid in the past')
            total,expired=self.funding(actor,time)
            cursor=self.cursors.get(actor,D(0));base=max(cursor,expired)
            amount=min(requested,missing,max(D(0),total-base)) if alive else D(0)
            return HealingQuote(actor,time,requested,amount,total,expired,cursor,base,base+amount,
                self.revisions.get(actor,0),self.history.observed_until,len(self.history.entries),self.owner)

    def commit(self,receipt,quote):
        """Commit a fresh quote once; all validation precedes mutation."""
        if not isinstance(receipt,str) or not receipt or receipt in self.claims:
            raise ValueError('Healing receipt must be distinct and nonempty')
        if not isinstance(quote,HealingQuote) or quote.owner is not self.owner:
            raise ValueError('Healing quote belongs to another allowance')
        if (quote.revision!=self.revisions.get(quote.actor,0) or quote.time<self.last_time
                or quote.history_bound!=self.history.observed_until
                or quote.history_entries!=len(self.history.entries)):
            raise ValueError('Healing quote is stale')
        self.cursors[quote.actor]=quote.cursor_after
        self.revisions[quote.actor]=quote.revision+1;self.last_time=quote.time
        self.claims[receipt]=quote
        return quote.amount

    def claim(self,receipt,actor,time,requested,*,missing_hp,alive=True):
        quote=self.quote(actor,time,requested,missing_hp=missing_hp,alive=alive)
        self.commit(receipt,quote)
        return quote

    def commit_flow(self,receipt,actor,begin,end,requested,amount,cursor_after):
        """Commit a prepared FIFO trajectory after its actual damage is journaled."""
        with localcontext(self.history.context):
            if not isinstance(receipt,str) or not receipt or receipt in self.claims:
                raise ValueError('Healing receipt must be distinct and nonempty')
            begin,end,requested,amount,cursor_after=map(lambda v:finite(v,'Healing flow'),
                (begin,end,requested,amount,cursor_after))
            if end<=begin or end<self.last_time:raise ValueError('Healing flow clocks are out of order')
            total,expired=self.funding(actor,end);_,old_expired=self.funding(actor,begin)
            before=self.cursors.get(actor,D(0));base=max(before,old_expired)
            tolerance=D('1e-8')
            lower=max(base+amount,expired);upper=max(base,expired)+amount
            if (amount>requested+tolerance or cursor_after<lower-tolerance
                    or cursor_after>min(total,upper)+tolerance):
                raise ValueError('Healing flow violates its entitlement or funding capacity')
            # Only finite solver roundoff can enter these projections.
            cursor_after=min(total,max(lower,cursor_after))
            quote=HealingQuote(actor,end,requested,amount,total,expired,before,base,cursor_after,
                self.revisions.get(actor,0),self.history.observed_until,len(self.history.entries),self.owner)
            self.commit(receipt,quote)
            return quote

    def record(self):
        return {'fraction':self.fraction,'window_ms':self.window,'last_payment_ms':self.last_time,
            'funding_cursors':dict(sorted(self.cursors.items())),
            'claims':[{'receipt_id':key,**value.record()} for key,value in self.claims.items()]}
