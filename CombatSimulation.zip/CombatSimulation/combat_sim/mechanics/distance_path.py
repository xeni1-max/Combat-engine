"""Quadratic reference paths certified over their complete interval.

Feasible quadratic Bezier control points supply a safe path. Retaining as much
of the initial tangent as possible, under an exact Bernstein certificate,
avoids unnecessarily replacing the entire path with that control cage.
"""
from dataclasses import dataclass
from decimal import Decimal as D
from fractions import Fraction as F

from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.mechanics.distance_projection import project_distances,validate_distances,feasible_fraction,dot,FixedDistance,relative_position,fixed_points
from combat_sim.mechanics.unilateral_velocity import project_unilateral,TautDistance,ContactLimit
from combat_sim.mechanics.velocity_projection import VelocityNode,number,vector
from combat_sim.mechanics.exact_ratio import ratio_text


@dataclass(frozen=True)
class DistancePathStep:
    pieces: tuple
    bernstein_certificate: tuple
    control_blend: F
    initial_projection: object
    midpoint_projection: object
    endpoint_projection: object
    fixed_points: tuple = ()

    def record(self):
        def plain(value):
            if isinstance(value,F):return ratio_text(value)
            if isinstance(value,D):return str(value)
            if isinstance(value,dict):return {k:plain(v) for k,v in value.items()}
            if isinstance(value,(tuple,list)):return tuple(plain(v) for v in value)
            return value
        record={'pieces':{n:p.record() for n,p in self.pieces},'control_blend':ratio_text(self.control_blend),
            'bernstein_certificate':tuple({'first':a,'second':b,'maximum_m':ratio_text(length),
                'distance_squared_minus_limit_squared':tuple(map(ratio_text,coefficients))}
                for a,b,length,coefficients in self.bernstein_certificate),
            'initial_projection':plain(self.initial_projection.record()),
            'midpoint_projection':self.midpoint_projection.record(),
            'endpoint_projection':self.endpoint_projection.record()}
        if self.fixed_points:record['fixed_points']={n:tuple(map(ratio_text,p)) for n,p in self.fixed_points}
        return record


def build_distance_path(nodes,references,begin_ms,end_ms,distances=(),contacts=(),equalities=(),blocked=(),*,
        accelerations=None,precision=50,maximum_error_mps='1e-10'):
    """Plan one finite quadratic path, preserving the supplied start positions.

    This pure planner does not choose physics knots, commit momentum, transport
    finite forces, register a binding or replace the world's motion controller.
    Certificates cover reference translation, not future body/terrain clearance.
    """
    begin=number(begin_ms);end=number(end_ms)
    if end<=begin:raise ValueError('A finite distance path needs positive duration')
    seconds=(end-begin)/1000
    nodes,refs,edges=validate_distances(nodes,references,distances)
    contacts=tuple(contacts);equalities=tuple(equalities);blocked=tuple(blocked)
    source_acceleration={n.identity:(0,0,0) for n in nodes} if accelerations is None else accelerations
    acceleration={n:vector(v) for n,v in source_acceleration.items()}
    if set(acceleration)!=set(refs):raise ValueError('Accelerations must describe exactly the participating bodies')
    taut=[];initial_contacts=list(contacts)
    for edge in edges:
        r=relative_position(edge,refs)
        if dot(r,r)==edge.maximum_m**2:
            if isinstance(edge,FixedDistance):initial_contacts.append(ContactLimit(edge.first,tuple(-x for x in r)))
            else:taut.append(TautDistance(edge.first,edge.second,r))
    initial=project_unilateral(nodes,taut,initial_contacts,equalities,blocked,precision=precision)
    velocity=dict(initial.exact_velocities)
    node=lambda n,v:VelocityNode(n.identity,v,n.maximum_hp,n.armor)
    endpoint=project_distances(tuple(node(n,tuple(v+a*seconds/2 for v,a in zip(velocity[n.identity],acceleration[n.identity])))
        for n in nodes),refs,seconds,edges,contacts,equalities,blocked,
        precision=precision,maximum_error_mps=maximum_error_mps)
    # A stationary contact normal at both ends cannot acquire an invented
    # quadratic hop through its middle control point. Keep that normal closed
    # while projecting the midpoint; genuine outgoing velocity/end separation
    # still permits lift-off. This also works for a relative body/body plane.
    end_velocity=dict(endpoint.exact_velocities);middle_contacts=list(contacts)
    def normal_rate(values,contact):
        other=values[contact.other] if contact.other is not None else (F(0),)*3
        return dot(tuple(a-b for a,b in zip(values[contact.actor],other)),contact.toward_obstacle)
    for contact in contacts:
        if normal_rate(velocity,contact)==0 and normal_rate(end_velocity,contact)==0:
            reverse=ContactLimit(contact.actor,tuple(-v for v in contact.toward_obstacle),contact.other)
            if reverse not in middle_contacts:middle_contacts.append(reverse)
    mid=project_distances(tuple(node(n,velocity[n.identity]) for n in nodes),refs,seconds/2,edges,
        middle_contacts,equalities,blocked,precision=precision,maximum_error_mps=maximum_error_mps)
    low={n:tuple(p+v*seconds/2 for p,v in zip(refs[n],v)) for n,v in mid.exact_velocities}
    high={n:tuple(p+v*seconds/2 for p,v in zip(refs[n],v)) for n,v in velocity.items()}
    finish={n:tuple(p+v*seconds for p,v in zip(refs[n],v)) for n,v in endpoint.exact_velocities}
    blend=F(1)
    for edge in edges:
        delta=lambda values:relative_position(edge,values)
        r0=delta(refs);r2=delta(finish);lo=delta(low);hi=delta(high)
        change=tuple(b-a for a,b in zip(lo,hi));length2=edge.maximum_m**2
        constraints=((dot(r0,lo)-length2,dot(r0,change),F(0)),
            ((dot(r0,r2)+2*dot(lo,lo))/3-length2,4*dot(lo,change)/3,2*dot(change,change)/3),
            (dot(lo,r2)-length2,dot(change,r2),F(0)))
        for c,b,a in constraints:blend=min(blend,feasible_fraction(c,b,a,precision))
    middle={n:tuple(a+blend*(b-a) for a,b in zip(low[n],high[n])) for n in refs}
    certificates=[]
    for edge in edges:
        relative=tuple(relative_position(edge,values) for values in (refs,middle,finish))
        a,b,c=relative;l2=edge.maximum_m**2
        coefficients=(dot(a,a)-l2,dot(a,b)-l2,(dot(a,c)+2*dot(b,b))/3-l2,dot(b,c)-l2,dot(c,c)-l2)
        if any(x>0 for x in coefficients):raise ArithmeticError('A distance path failed its whole-interval certificate')
        certificates.append((edge.first,edge.second,edge.maximum_m,coefficients))
    pieces=tuple((n,BodyPathPiece(begin,end,refs[n],tuple(2*(b-a)/seconds for a,b in zip(refs[n],middle[n])),
        tuple(2*(c-2*b+a)/(seconds*seconds) for a,b,c in zip(refs[n],middle[n],finish[n])))) for n in sorted(refs))
    return DistancePathStep(pieces,tuple(certificates),blend,initial,mid,endpoint,fixed_points(edges))
