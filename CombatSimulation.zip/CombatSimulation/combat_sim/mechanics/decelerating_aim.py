"""Stationary-target short-arc aim with gravity and direction-following drag.

Constant-magnitude deceleration always opposes the current velocity. A shooting
solve uses the existing adaptive trajectory integrator. Its chosen branch is
continued from the analytic fastest ballistic launch; it is not a global search
over trajectories beyond the integrator's positive-speed safety domain.
"""
from dataclasses import dataclass
from math import atan2, cos, hypot, isfinite, pi, sin, sqrt

from combat_sim.mechanics.aiming import AimedLaunch, fastest_ballistic_launch
from combat_sim.mechanics.gravity import GRAVITY_MPS2, ProjectileTrajectory, vector
from combat_sim.models import UnsupportedMechanicError


@dataclass(frozen=True)
class DeceleratingAimedLaunch(AimedLaunch):
    position_error_m: float
    refinement_error_m: float
    trajectory_evaluations: int
    branch: str
    conservative_horizon_s: float | None


def _finite(value, name, *, positive=False):
    if isinstance(value, bool):
        raise ValueError(f'{name} must be a finite number')
    try:
        value = float(value)
    except (ValueError, TypeError, OverflowError) as error:
        raise ValueError(f'{name} must be a finite number') from error
    if not isfinite(value) or value < 0 or (positive and value == 0):
        raise ValueError(f'{name} must be finite and {"positive" if positive else "nonnegative"}')
    return value


def short_arc_decelerating_launch(origin_m, target_m, speed_mps, *,
                                  deceleration_mps2,
                                  gravity_mps2=GRAVITY_MPS2,
                                  position_tolerance_m=1e-7,
                                  max_step_s=.01,
                                  relative_tolerance=1e-11,
                                  absolute_tolerance=1e-12,
                                  max_iterations=24):
    """Compensate fall toward one fixed point, returning launch and diagnostics.

    For positive deceleration the solution must satisfy
    ``flight_time < speed / (deceleration + gravity)`` with a small numerical
    margin. Four continuation stages connect the zero-deceleration fastest arc
    to the requested deceleration. Each uses a damped two-variable shooting
    solve (elevation and flight time), followed by tighter-integration validation.
    No slow arc, zero-speed continuation, target motion prediction, cover
    avoidance or turn delay is inferred. A failure to resolve this branch is
    reported as unsupported, not as a proven globally unreachable target.

    The reported residual and refinement difference are numerical diagnostics,
    not formally certified integration-error bounds. Finite inputs, positive
    tolerances and an integer iteration limit of at least two are required.
    """
    origin, target = vector(origin_m), vector(target_m)
    speed = _finite(speed_mps, 'Launch speed', positive=True)
    deceleration = _finite(deceleration_mps2, 'Deceleration')
    gravity = _finite(gravity_mps2, 'Gravity')
    tolerance = _finite(position_tolerance_m, 'Position tolerance', positive=True)
    step = _finite(max_step_s, 'Maximum integration step', positive=True)
    rtol = _finite(relative_tolerance, 'Relative integration tolerance', positive=True)
    atol = _finite(absolute_tolerance, 'Absolute integration tolerance', positive=True)
    if isinstance(max_iterations, bool) or not isinstance(max_iterations, int) or max_iterations < 2:
        raise ValueError('Aim iteration limit must be an integer of at least two')
    delta = tuple(b-a for a, b in zip(origin, target))
    distance = hypot(*delta)
    if distance == 0:
        raise UnsupportedMechanicError('Coincident origin/aim point has no positive-flight short arc')
    if not isfinite(distance):
        raise ValueError('Origin-to-target displacement must be finite')
    horizontal = hypot(*delta[:2])
    height = delta[2]
    horizon = speed/(deceleration+gravity) if deceleration else None
    safe_horizon = horizon*(1-1e-10) if horizon is not None else None
    evaluations = 0

    def evaluate(velocity, time, drag, *, refined=False):
        nonlocal evaluations
        evaluations += 1
        trajectory = ProjectileTrajectory((0, 0, 0), velocity, time,
            deceleration_mps2=drag, gravity_mps2=gravity,
            max_step_s=step/(2 if refined else 1),
            relative_tolerance=rtol/(10 if refined else 1),
            absolute_tolerance=atol/(10 if refined else 1))
        return trajectory.at(time)

    def finish(velocity, time, branch):
        if safe_horizon is not None and not 0 < time < safe_horizon:
            raise UnsupportedMechanicError('Aim is outside the supported positive-speed short-arc horizon')
        ordinary = evaluate(velocity, time, deceleration)
        refined = evaluate(velocity, time, deceleration, refined=True)
        residual = hypot(*(a-b for a, b in zip(refined.position_m, delta)))
        difference = hypot(*(a-b for a, b in zip(ordinary.position_m, refined.position_m)))
        if residual > tolerance or difference > tolerance/4:
            raise UnsupportedMechanicError('Short-arc aim did not meet position/refinement tolerances')
        return DeceleratingAimedLaunch(tuple(velocity), time, residual, difference,
                                      evaluations, branch, horizon)

    if deceleration == 0:
        launch = fastest_ballistic_launch((0, 0, 0), delta, speed, gravity_mps2=gravity)
        return finish(launch.velocity_mps, launch.flight_time_s, 'fastest_ballistic')

    # The speed obeys ds/dt <= gravity-deceleration. This path-length bound
    # can reject targets unreachable *within this horizon*, without implying
    # anything about an unimplemented later zero-speed regime.
    max_length = speed*safe_horizon + (gravity-deceleration)*safe_horizon**2/2
    if distance > max_length:
        raise UnsupportedMechanicError('Target is unreachable within the supported short-arc horizon')

    if gravity == 0 or horizontal == 0:
        slowdown = deceleration if gravity == 0 else deceleration+(gravity if height > 0 else -gravity)
        discriminant = speed*speed-2*slowdown*distance
        if discriminant < 0:
            raise UnsupportedMechanicError('Target is unreachable on the supported first-pass arc')
        time = 2*distance/(speed+sqrt(discriminant))
        velocity = tuple(speed*value/distance for value in delta)
        return finish(velocity, time, 'direct_first_pass' if gravity == 0 else 'vertical_first_pass')

    planar_target = (horizontal, 0, height)
    launch = fastest_ballistic_launch((0, 0, 0), planar_target, speed, gravity_mps2=gravity)
    angle = atan2(launch.velocity_mps[2], launch.velocity_mps[0])
    flight = launch.flight_time_s

    def planar_velocity(theta):
        return speed*cos(theta), 0., speed*sin(theta)

    def solve(theta, time, drag):
        limit = speed/(drag+gravity)*(1-1e-10)
        if not 0 < time < limit:
            raise UnsupportedMechanicError('Short-arc continuation reached the positive-speed horizon')
        for _ in range(max_iterations):
            state = evaluate(planar_velocity(theta), time, drag)
            fx, fz = state.position_m[0]-horizontal, state.position_m[2]-height
            residual = hypot(fx, fz)
            if residual <= tolerance/8:
                return theta, time
            # The endpoint time derivative is its physical final velocity.
            # A central angular difference supplies the other Jacobian column.
            angular_step = 1e-5
            plus = evaluate(planar_velocity(theta+angular_step), time, drag)
            minus = evaluate(planar_velocity(theta-angular_step), time, drag)
            a = (plus.position_m[0]-minus.position_m[0])/(2*angular_step)
            c = (plus.position_m[2]-minus.position_m[2])/(2*angular_step)
            b, d = state.velocity_mps[0], state.velocity_mps[2]
            determinant = a*d-b*c
            if not isfinite(determinant) or abs(determinant) <= 1e-14*max(1., abs(a*d), abs(b*c)):
                raise UnsupportedMechanicError('Short-arc shooting Jacobian is singular near its branch boundary')
            angle_change = (-fx*d+b*fz)/determinant
            time_change = (-a*fz+c*fx)/determinant
            # Damping maintains the same local branch and strictly improves
            # endpoint residual; it never jumps across a zero-speed boundary.
            fraction = min(1., .25/max(abs(angle_change), .25))
            for _ in range(24):
                next_angle, next_time = theta+fraction*angle_change, time+fraction*time_change
                if -pi/2 < next_angle < pi/2 and 0 < next_time < limit:
                    trial = evaluate(planar_velocity(next_angle), next_time, drag)
                    if hypot(trial.position_m[0]-horizontal, trial.position_m[2]-height) < residual:
                        theta, time = next_angle, next_time
                        break
                fraction /= 2
            else:
                raise UnsupportedMechanicError('Short-arc continuation could not reduce its endpoint error')
        raise UnsupportedMechanicError('Short-arc aim exceeded its iteration limit')

    for stage in range(1, 5):
        angle, flight = solve(angle, flight, deceleration*stage/4)
    horizontal_speed = speed*cos(angle)
    velocity = (horizontal_speed*delta[0]/horizontal,
                horizontal_speed*delta[1]/horizontal, speed*sin(angle))
    return finish(velocity, flight, 'continuation_from_fastest_ballistic')
