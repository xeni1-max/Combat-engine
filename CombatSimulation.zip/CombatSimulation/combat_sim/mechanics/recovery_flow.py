"""Immutable analytic flow plans for delayed, rate-limited recovery.

Known point arrivals and positive affine-root loss rates form a work queue.
Supply-limited pieces preserve those roots; busy pieces supply a constant rate.
That family is closed under delaying recovered work into another loss history.
No simulation time or source state changes while constructing/reading a plan.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.continuous_numeric import recorded_root_integral, recorded_root_knots, root_affine_integral,affine_rate_integral
from combat_sim.world_colliders import finite

TIME_TOLERANCE_MS=D('1e-25')


def history_key(value):
    """Immutable value key also detects edits through the legacy public list."""
    if isinstance(value,dict):return tuple((k,history_key(v)) for k,v in sorted(value.items()))
    if isinstance(value,(tuple,list)):return tuple(map(history_key,value))
    return value


@dataclass(frozen=True)
class RootRate:
    coefficient: D
    q_reference: D
    reference_ms: D
    slope_per_second: D

    def __post_init__(self):
        for key in ('coefficient','q_reference','reference_ms'):
            object.__setattr__(self,key,finite(getattr(self,key),key))
        if isinstance(self.slope_per_second,bool):raise ValueError('Rate slope must be finite')
        object.__setattr__(self,'slope_per_second',dec(self.slope_per_second))

    def rate(self,time):
        return self.coefficient*max(D(0),self.q_reference+self.slope_per_second*(time-self.reference_ms)/1000).sqrt()

    def integral(self,begin,end):
        return root_affine_integral(self.coefficient,self.q_reference,self.reference_ms,self.slope_per_second,begin,end)

    def record(self):
        return {'curve_kind':'affine_root_v1','coefficient':self.coefficient,'q_reference':self.q_reference,
            'reference_ms':self.reference_ms,'slope_per_second':self.slope_per_second}


@dataclass(frozen=True)
class AffineRate:
    value_reference: D
    reference_ms: D
    slope_per_second: D

    def __post_init__(self):
        for key in ('value_reference','reference_ms'):object.__setattr__(self,key,finite(getattr(self,key),key))
        if isinstance(self.slope_per_second,bool):raise ValueError('Rate slope must be finite')
        object.__setattr__(self,'slope_per_second',dec(self.slope_per_second))

    def rate(self,time):return max(D(0),self.value_reference+self.slope_per_second*(time-self.reference_ms)/1000)

    def integral(self,begin,end):return affine_rate_integral(self.value_reference,self.reference_ms,self.slope_per_second,begin,end)

    def record(self):return {'curve_kind':'affine_rate_v1','value_reference':self.value_reference,
        'reference_ms':self.reference_ms,'slope_per_second':self.slope_per_second}


@dataclass(frozen=True)
class RateShape:
    constant_per_second: D = D(0)
    terms: tuple = ()
    affine_terms: tuple = ()

    def __post_init__(self):
        object.__setattr__(self,'constant_per_second',finite(self.constant_per_second,'Constant rate'))
        object.__setattr__(self,'terms',tuple(self.terms))
        object.__setattr__(self,'affine_terms',tuple(self.affine_terms))
        if any(not isinstance(term,RootRate) for term in self.terms):raise ValueError('Unknown rate term')
        if any(not isinstance(term,AffineRate) for term in self.affine_terms):raise ValueError('Unknown affine rate term')

    def rate(self,time):return self.constant_per_second+sum((term.rate(time) for term in self.terms+self.affine_terms),D(0))

    def integral(self,begin,end):
        return self.constant_per_second*(end-begin)/1000+sum((term.integral(begin,end) for term in self.terms+self.affine_terms),D(0))

    def record(self):
        return {'curve_kind':'sum_rates_v1' if self.affine_terms else 'sum_root_v1','constant_per_second':self.constant_per_second,
            'terms':[term.record() for term in self.terms],
            **({'affine_terms':[term.record() for term in self.affine_terms]} if self.affine_terms else {})}


@dataclass(frozen=True)
class RecoveryPiece:
    begin: D
    end: D
    delivered_before: D
    shape: RateShape

    def record(self):
        return {'begin_ms':self.begin,'end_ms':self.end,'delivered_before':self.delivered_before,'curve':self.shape.record()}


@dataclass(frozen=True)
class RecoveryPlan:
    begin: D
    end: D
    initial_recovered: D
    pieces: tuple
    generation: int
    owner_token: object = field(repr=False,compare=False)
    source_history_key: tuple = field(repr=False,compare=False)
    eligible_history_key: tuple = field(repr=False,compare=False)
    work_tolerance_hp: D = D(0)

    def delivered(self,time):
        time=finite(time,'Recovery plan time')
        if not self.begin<=time<=self.end:raise ValueError('Time is outside the recovery plan')
        for piece in self.pieces:
            if time<=piece.end:
                return piece.delivered_before+piece.shape.integral(piece.begin,time)
        return D(0)

    def rate(self,time):
        time=finite(time,'Recovery plan time')
        if not self.begin<=time<=self.end:raise ValueError('Time is outside the recovery plan')
        for piece in self.pieces:
            if time<piece.end:return piece.shape.rate(time)
        return self.pieces[-1].shape.rate(time) if self.pieces else D(0)

    @property
    def total(self):return self.delivered(self.end)

    def record(self):
        return {'begin_ms':self.begin,'end_ms':self.end,'initial_recovered':self.initial_recovered,
            'total':self.total,'boundary_tolerance_ms':TIME_TOLERANCE_MS,
            'pieces':[piece.record() for piece in self.pieces],
            **({'work_roundoff_tolerance_hp':self.work_tolerance_hp} if self.work_tolerance_hp else {})}


def _bisect(function,begin,end,*,increasing):
    for _ in range(320):
        if end-begin<=TIME_TOLERANCE_MS:break
        middle=(begin+end)/2
        if (function(middle)<0)==increasing:begin=middle
        else:end=middle
    else:raise ArithmeticError('Recovery boundary did not converge')
    return (begin+end)/2


def _rate_crossings(shape,begin,end,limit):
    """A nonnegative sum of affine roots is concave between supplied knots."""
    if not any(term.slope_per_second for term in shape.terms+shape.affine_terms):return []
    low,high=begin,end
    for _ in range(240):
        if high-low<=TIME_TOLERANCE_MS:break
        p,q=(2*low+high)/3,(low+2*high)/3
        if shape.rate(p)<shape.rate(q):low=p
        else:high=q
    peak=max((begin,(low+high)/2,end),key=shape.rate)
    if shape.rate(peak)<=limit:return []
    difference=lambda t:shape.rate(t)-limit
    result=[]
    if shape.rate(begin)<limit:
        result.append(_bisect(difference,begin,peak,increasing=True))
    if shape.rate(end)<limit:
        result.append(_bisect(difference,peak,end,increasing=False))
    return [t for t in result if begin<t<end]


def _translate_curve(curve,source_time,reference,scale):
    """Represent the current arrival rate with clocks at this plan's time."""
    kind=curve.get('curve_kind')
    if kind in ('sum_root_v1','sum_rates_v1'):
        constant=curve['constant_per_second']*scale;terms=[];affine=[]
        for child in tuple(curve['terms'])+tuple(curve.get('affine_terms',())):
            item=_translate_curve(child,source_time,reference,scale)
            constant+=item.constant_per_second;terms.extend(item.terms);affine.extend(item.affine_terms)
        return RateShape(constant,tuple(terms),tuple(affine))
    if kind=='affine_rate_v1':
        if scale<0:raise ValueError('Recovery rates must be nonnegative')
        slope=curve['slope_per_second'];value=curve['value_reference']+slope*(source_time-curve['reference_ms'])/1000
        # Plans already split at recorded zeros. A future increasing ramp is
        # zero on this whole cell; reanchoring it at zero would create supply.
        if value<0:return RateShape()
        if not value and slope<0 or not scale:return RateShape()
        return RateShape(affine_terms=(AffineRate(value*scale,reference,slope*scale),))
    if kind=='affine_root_v1':
        slope=curve['slope_per_second']
        q=curve['q_reference']+slope*(source_time-curve['reference_ms'])/1000
    elif kind is None:
        slope=D(1) if source_time<curve['leave_ms'] else -curve['k']
        q=((source_time-curve['start_ms'])/1000 if slope>0 else
            (curve['leave_ms']-curve['start_ms']-curve['k']*(source_time-curve['leave_ms']))/1000)
    else:raise ValueError('Unknown recovery supply curve kind')
    coefficient=curve['coefficient']*scale
    if coefficient<0:raise ValueError('Recovery rates must be nonnegative')
    if not coefficient or q<=0 and slope<=0:return RateShape()
    return RateShape(terms=(RootRate(coefficient,max(D(0),q),reference,slope),))


def build_recovery_plan(recovery,begin,end,*,work_tolerance_hp=D(0)):
    begin,end=finite(begin,'Plan begin'),finite(end,'Plan end')
    work_tolerance_hp=finite(work_tolerance_hp,'Recovery work roundoff tolerance')
    if end<begin:raise ValueError('Plan cannot run backwards')
    losses=deepcopy(recovery.losses)
    if any(loss['amount']<0 for loss in losses):raise ValueError('Recovery supply cannot be negative')
    initial=recovery.recovered
    limit=recovery.rate*1000

    def eligible(time,*,left_limit=False):
        total=D(0)
        for loss in losses:
            if time<loss['begin'] or left_limit and time==loss['begin']:continue
            if time>=loss['end']:total+=loss['amount']
            elif 'curve' in loss:
                total+=loss['scale']*recorded_root_integral(loss['curve'],loss['begin']-recovery.delay,time-recovery.delay)
        return total

    if initial>eligible(begin)+max(D('1e-24'),recovery.rate*TIME_TOLERANCE_MS):
        raise ValueError('Recovery work already exceeds supply at plan begin')
    cuts={begin,end}
    for loss in losses:
        cuts.update(t for t in (loss['begin'],loss['end']) if begin<t<end)
        if 'curve' in loss:
            cuts.update(t+recovery.delay for t in recorded_root_knots(loss['curve']) if begin<t+recovery.delay<end)
    pieces=[];delivered=D(0)

    def append(a,b,shape):
        nonlocal delivered
        if b<=a:return
        pieces.append(RecoveryPiece(a,b,delivered,shape))
        delivered+=shape.integral(a,b)

    busy=RateShape(limit)
    points=sorted(cuts)
    for a,b in zip(points,points[1:]):
        constant=D(0);terms=[];affine=[]
        for loss in losses:
            if 'curve' not in loss or loss['begin']>=b or loss['end']<=a:continue
            scale=loss['scale']
            if work_tolerance_hp:
                basis=recorded_root_integral(loss['curve'],loss['begin']-recovery.delay,loss['end']-recovery.delay)
                if abs(loss['amount']-basis)<=work_tolerance_hp/max(1,len(losses)):scale=D(1)
            shape=_translate_curve(loss['curve'],a-recovery.delay,a,scale)
            constant+=shape.constant_per_second;terms.extend(shape.terms);affine.extend(shape.affine_terms)
        supply=RateShape(constant,tuple(terms),tuple(affine))
        cells=[a,*_rate_crossings(supply,a,b,limit),b]
        for first,last in zip(cells,cells[1:]):
            if supply.rate((first+last)/2)>=limit:
                append(first,last,busy);continue
            recovered=initial+delivered
            backlog=eligible(first)-recovered
            if backlog<=work_tolerance_hp:
                append(first,last,supply);continue
            remaining=lambda t:eligible(t,left_limit=t==last)-recovered-limit*(t-first)/1000
            if remaining(last)>=0:
                append(first,last,busy);continue
            empty=(first+1000*backlog/(limit-supply.rate(first)) if
                not any(term.slope_per_second for term in supply.terms+supply.affine_terms) else
                _bisect(remaining,first,last,increasing=False))
            append(first,empty,busy)
            append(empty,last,supply)
    return RecoveryPlan(begin,end,initial,tuple(pieces),recovery._plan_generation,recovery._plan_token,history_key(losses),
        history_key([loss for loss in losses if loss['begin']<=end]),work_tolerance_hp)


class RecoveryCursor:
    """Consume one conditional trajectory in increasing prefixes without replay.

    Newly incurred losses beyond the plan horizon cannot affect its flow. Other
    eligible history edits and other work consumers invalidate the cursor.
    """
    def __init__(self,recovery,plan):
        self.recovery,self.plan,self.time=recovery,plan,plan.begin
        self._validate()

    def _validate(self):
        r,p=self.recovery,self.plan
        if (p.owner_token is not r._plan_token or
                p.eligible_history_key!=history_key([loss for loss in r.losses if loss['begin']<=p.end]) or
                abs(r.recovered-(p.initial_recovered+p.delivered(self.time)))>max(D('1e-24'),2*p.work_tolerance_hp)):
            raise ValueError('Recovery cursor is stale or belongs to another stream')

    def consume(self,end):
        end=finite(end,'Recovery cursor time')
        if not self.time<end<=self.plan.end:raise ValueError('Recovery cursor must advance within its plan')
        self._validate()
        work=min(self.plan.initial_recovered+self.plan.delivered(end),self.recovery.eligible(end,left_limit=True))
        amount=max(D(0),work-self.recovery.recovered)
        self.recovery.recovered+=amount;self.recovery._plan_generation+=1;self.time=end
        return amount
