"""Deterministic release cones around compensated launch velocity.

A disk sample is a dimensionless tangent-plane offset, not a hit probability.
The immutable shot key keeps experiments independent of event/observation order.
"""
from decimal import Context,Decimal as D,localcontext
from hashlib import sha256
import json

from combat_sim.battle_models import decimal_value as dec


def nonnegative(value):
    if isinstance(value,bool):raise ValueError('Accuracy values must be numbers')
    result=dec(value)
    if result<0:raise ValueError('Accuracy values must be nonnegative')
    return result


def spread_radius(base_cm,unaimed_cm,disorientation,*,running=False,precision=50):
    if not isinstance(running,bool):raise ValueError('Running must be boolean')
    with localcontext(Context(prec=precision)):
        return sum((nonnegative(v) for v in (base_cm,unaimed_cm,disorientation)),D(0))*(D('1.2') if running else 1)


def disk_sample(seed,actor,profile,generation,ability,ordinal):
    if (any(not isinstance(v,str) or not v for v in (actor,profile,ability)) or
            any(not isinstance(v,int) or isinstance(v,bool) or v<low for v,low in
                ((seed,0),(generation,1),(ordinal,1)))):raise ValueError('Invalid stable accuracy sample key')
    key=json.dumps(['accuracy-disk-v1',seed,actor,profile,generation,ability,ordinal],ensure_ascii=True,separators=(',',':'))
    scale=1<<63
    for attempt in range(1024):
        bits=sha256((key+':'+str(attempt)).encode()).digest()
        x=int.from_bytes(bits[:8],'big')-scale;y=int.from_bytes(bits[8:16],'big')-scale
        if x*x+y*y<=scale*scale:
            # Division by 2**63 terminates exactly; own enough precision even
            # when the caller supplies a deliberately small Decimal context.
            with localcontext(Context(prec=100)):return D(x)/scale,D(y)/scale
    raise ArithmeticError('Accuracy sample rejection limit exceeded')


def dispersed_velocity(velocity,radius_cm,sample,*,precision=50):
    with localcontext(Context(prec=precision)):
        if len(velocity)!=3 or len(sample)!=2:raise ValueError('Accuracy needs a velocity vector and disk point')
        value=tuple(map(dec,velocity));x,y=map(dec,sample);radius=nonnegative(radius_cm)
        if x*x+y*y>1:raise ValueError('Accuracy sample must be inside the unit disk')
        squared=sum(v*v for v in value)
        if not squared:raise ValueError('Accuracy needs positive launch speed')
        if radius==0:return value
        speed=squared.sqrt();forward=tuple(v/speed for v in value)
        pole=(D(0),D(1),D(0)) if abs(forward[2])>D('.9') else (D(0),D(0),D(1))
        def cross(a,b):return a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]
        right=cross(forward,pole);norm=sum(v*v for v in right).sqrt();right=tuple(v/norm for v in right)
        up=cross(right,forward);slope=radius/10000
        direction=tuple(f+slope*(x*r+y*u) for f,r,u in zip(forward,right,up))
        norm=sum(v*v for v in direction).sqrt()
        return tuple(speed*v/norm for v in direction)
