"""Disorientation and instability accumulation/decay primitives."""

from fractions import Fraction
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from typing import Any

from combat_sim.models import as_fraction

SOURCE = "Collision details.odt decay equations; user clarification on additive values and zero floor"
MITIGATION_PRECISION = 40
STATUS_CONTEXT = Context(prec=MITIGATION_PRECISION, rounding=ROUND_HALF_EVEN)


def self_status_value(base_value: Any, *, is_running_at_application: bool = False) -> Fraction:
    """Apply a listed self amount, including running's 20% increase.

    The author explicitly exempts self disorientation/instability from HP,
    armor, and additional-resistance mitigation. Application timing is separate.
    """
    base = as_fraction(base_value)
    if base < 0:
        raise ValueError("Base self-status value must be nonnegative")
    if not isinstance(is_running_at_application, bool):
        raise ValueError("Running at self-status application must be a boolean")
    return base * (Fraction(6, 5) if is_running_at_application else Fraction(1))


def _decimal(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, Fraction):
        with localcontext(STATUS_CONTEXT):
            return Decimal(value.numerator) / Decimal(value.denominator)
    return Decimal(str(value))


def mitigate_status(
    incoming: Any,
    max_hp: Any,
    armor: Any,
    resistance: Any = 0,
) -> Decimal:
    """Apply the documented collision mitigation to one incoming value, floor 0.

    `resistance` is the explicitly supplied additional resistance R. Shield
    presence alone supplies no bonus: use a shield's stated bonus only while
    its documented condition applies. Shield absorption does not cancel the
    status event. Selecting active bonuses belongs to the caller.
    """
    amount = _decimal(incoming)
    hp = _decimal(max_hp)
    current_armor = _decimal(armor)
    extra_resistance = _decimal(resistance)
    if hp < 0 or current_armor < 0 or extra_resistance < 0:
        raise ValueError("HP, armor, and status resistance must be nonnegative")
    with localcontext(STATUS_CONTEXT):
        reduction = body_status_weight(hp, current_armor)
        return max(Decimal(0), amount - reduction - extra_resistance)


def body_status_weight(max_hp: Any, armor: Any) -> Decimal:
    """Shared (H/500+a/10)^1.1 term for status resistance/grapple movement.

    H is maximum HP and a is current armor. Additional status resistance and
    shield HP are not part of the grapple weighting formula. Keep the existing
    owned 40-digit status context so extracting this term preserves traces.
    """
    hp, current_armor = _decimal(max_hp), _decimal(armor)
    if hp < 0 or current_armor < 0:
        raise ValueError('HP and armor must be nonnegative')
    with localcontext(STATUS_CONTEXT):
        return (hp/Decimal(500)+current_armor/Decimal(10))**Decimal('1.1')


def apply_self_status(current: Any, incoming: Any, *, is_running_at_application: bool = False) -> Decimal:
    """Add an unmitigated self effect; defenses are deliberately not inputs."""
    return add_status(current, self_status_value(
        incoming, is_running_at_application=is_running_at_application,
    ))


def add_status(current: Any, added: Any) -> Decimal:
    """Stack a new adjusted status value additively, with no negative state."""
    existing = max(Decimal(0), _decimal(current))
    increment = max(Decimal(0), _decimal(added))
    with localcontext(STATUS_CONTEXT):
        return existing + increment


def apply_status(
    current: Any,
    incoming: Any,
    max_hp: Any,
    armor: Any,
    resistance: Any = 0,
) -> Decimal:
    """Apply collision mitigation to the new value, then add it.

    Use apply_self_status for self effects, which the author explicitly exempts
    from all mitigation. Running still increases self effects by 20%.
    """
    return add_status(current, mitigate_status(incoming, max_hp, armor, resistance))


def decay_status(current: Any, elapsed_ms: int | Fraction) -> Decimal:
    """Apply the documented one-status-point-per-ms decay and floor at zero."""
    value = _decimal(current)
    elapsed = _decimal(elapsed_ms)
    if elapsed < 0:
        raise ValueError("Elapsed time must be nonnegative")
    with localcontext(STATUS_CONTEXT):
        return max(Decimal(0), value - elapsed)
