"""Work-conserving shared shield recovery from delayed point/continuous losses.

The eligible-loss supply is each observed loss shifted by its own delay. A
single service rate recovers eligible backlog. Continuous heat losses retain
their analytic curve; no recovery/damage ticks are introduced.
"""
from decimal import Decimal as D
from copy import deepcopy

from combat_sim.mechanics.continuous_numeric import recorded_root_integral, recorded_root_knots, recorded_root_rate


class DelayedShieldRecovery:
    def __init__(self, delay_ms, rate_per_second):
        self.delay, self.rate = D(delay_ms), D(rate_per_second)/1000
        if self.delay < 0 or self.rate <= 0:
            raise ValueError('Shield delay must be nonnegative and rate positive')
        self.losses = []
        self.recovered = D(0)
        self._plan_generation=0
        self._plan_token=object()

    def add_impact(self, time, amount):
        self.losses.append({'begin': time+self.delay, 'end': time+self.delay, 'amount': amount})
        self._plan_generation+=1

    def add_curve(self, begin, end, amount, curve):
        curve = deepcopy(curve)
        total = recorded_root_integral(curve,begin,end)
        if total <= 0 or amount < 0:
            raise ValueError('Continuous shield loss must have a positive analytic basis')
        self.losses.append({'begin': begin+self.delay, 'end': end+self.delay,
                            'amount': amount, 'curve': curve, 'scale': amount/total})
        self._plan_generation+=1

    def eligible(self, time, *, left_limit=False):
        total = D(0)
        for loss in self.losses:
            if time < loss['begin'] or (left_limit and time == loss['begin']):
                continue
            if time >= loss['end']:
                total += loss['amount']
            elif 'curve' in loss:
                c = loss['curve']
                total += loss['scale']*recorded_root_integral(c,loss['begin']-self.delay,time-self.delay)
        return total

    def _supply_rate(self, time, active):
        total = D(0)
        for loss in active:
            c, t = loss['curve'], time-self.delay
            if c.get('curve_kind') in ('sum_root_v1','sum_rates_v1','affine_rate_v1'):
                total+=loss['scale']*recorded_root_rate(c,t)/1000
                continue
            q = (c['q_reference']+c['slope_per_second']*(t-c['reference_ms'])/1000 if c.get('curve_kind')=='affine_root_v1' else
                (t-c['start_ms'])/1000 if t<=c['leave_ms'] else
                (c['leave_ms']-c['start_ms']-c['k']*(t-c['leave_ms']))/1000)
            total += loss['scale']*c['coefficient']*max(D(0), q).sqrt()/1000
        return total

    def advance(self, begin, end):
        if end < begin:
            raise ValueError('Shield recovery cannot advance backwards')
        if end>begin:self._plan_generation+=1
        if end == begin or self.eligible(end, left_limit=True) <= self.recovered:
            return D(0)
        before = self.recovered
        cuts = {begin, end}
        for loss in self.losses:
            for time in (loss['begin'], loss['end']):
                if begin < time < end:
                    cuts.add(time)
            if 'curve' in loss:
                for knot in recorded_root_knots(loss['curve']):
                    turn=knot+self.delay
                    if begin<turn<end:cuts.add(turn)
        points = sorted(cuts)
        for a, b in zip(points, points[1:]):
            active = [loss for loss in self.losses if 'curve' in loss
                      and loss['begin'] < b and loss['end'] > a]
            candidates = [self.recovered, self.eligible(a),
                          self.eligible(b, left_limit=True)-self.rate*(b-a)]
            # On a piece between curve boundaries, supply rate is a sum of
            # square roots of affine nonnegative clocks, hence concave. There
            # is at most one upward rate crossing; it is the only possible
            # interior minimum of eligible(t)-rate*(t-a).
            if active and self._supply_rate(a, active) < self.rate:
                low, high = a, b
                for _ in range(180):
                    if high-low <= D('1e-25'):
                        break
                    p, q = (2*low+high)/3, (low+2*high)/3
                    if self._supply_rate(p, active) < self._supply_rate(q, active):
                        low = p
                    else:
                        high = q
                peak = (low+high)/2
                if self._supply_rate(peak, active) > self.rate:
                    low, high = a, peak
                    for _ in range(200):
                        if high-low <= D('1e-25'):
                            break
                        mid = (low+high)/2
                        if self._supply_rate(mid, active) < self.rate:
                            low = mid
                        else:
                            high = mid
                    turn = (low+high)/2
                    candidates.append(self.eligible(turn)-self.rate*(turn-a))
            self.recovered = max(self.recovered, min(self.eligible(b, left_limit=True),
                                                    self.rate*(b-a)+min(candidates)))
        return self.recovered-before

    def invalidate_plans(self):
        """End a physical epoch without discarding its known recovery debt."""
        self._plan_generation+=1

    def plan(self,begin,end,*,work_tolerance_hp=D(0)):
        """Immutable, conditional forecast of recovery from currently known losses."""
        from combat_sim.mechanics.recovery_flow import build_recovery_plan
        return build_recovery_plan(self,begin,end,work_tolerance_hp=work_tolerance_hp)

    def commit_plan(self,plan,until_ms=None):
        """Consume a forecast once, only while its source history is unchanged."""
        from combat_sim.mechanics.recovery_flow import history_key
        if (plan.owner_token is not self._plan_token or plan.generation!=self._plan_generation
                or plan.initial_recovered!=self.recovered or plan.source_history_key!=history_key(self.losses)):
            raise ValueError('Recovery plan is stale or belongs to another recovery stream')
        end=plan.end if until_ms is None else until_ms
        amount=plan.delivered(end)
        if plan.work_tolerance_hp:amount=max(D(0),min(amount,self.eligible(end,left_limit=True)-self.recovered))
        self.recovered+=amount;self._plan_generation+=1
        return amount
