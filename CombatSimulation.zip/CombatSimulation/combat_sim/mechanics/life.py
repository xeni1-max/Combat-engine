"""Life-generation validation shared by owned work, effects and damage history."""


def life_generation(value):
    """None denotes an explicitly historical record without life attribution."""
    if value is not None and (type(value) is not int or value < 1):
        raise ValueError('Life generation must be a positive integer')
    return value


def target_life_record(generation):
    return {'target_life_generation': generation} if generation is not None else {}
