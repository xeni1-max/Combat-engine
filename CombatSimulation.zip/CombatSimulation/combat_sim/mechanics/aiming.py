"""Fastest compensated aim for stationary targets under constant gravity.

This solver covers undecelerated ballistic projectiles (the supported Qard).
It selects minimum flight time geometrically, without cover avoidance, target
prediction, facing/turn timing or shared-combat integration.
"""
from dataclasses import dataclass
from math import hypot, isfinite, sqrt

from combat_sim.mechanics.gravity import GRAVITY_MPS2, vector
from combat_sim.models import UnsupportedMechanicError


@dataclass(frozen=True)
class AimedLaunch:
    velocity_mps: tuple
    flight_time_s: float


def fastest_ballistic_launch(origin_m,target_m,speed_mps,*,gravity_mps2=GRAVITY_MPS2):
    """Return earliest positive-time solution at the supplied launch speed.

    Squared flight time solves (g²/4)T² + (g*dz-v²)T + |r|² = 0.
    Rationalizing the smaller root avoids cancellation for short fast shots.
    """
    origin,target = vector(origin_m),vector(target_m)
    speed,g = float(speed_mps),float(gravity_mps2)
    if not isfinite(speed) or not isfinite(g) or speed <= 0 or g < 0:
        raise ValueError('Launch speed must be positive and gravity nonnegative')
    delta = tuple(b-a for a,b in zip(origin,target))
    distance = hypot(*delta)
    if distance == 0:
        raise UnsupportedMechanicError('Coincident origin/aim point has no earliest positive-flight solution')
    if g == 0:
        t = distance/speed
    else:
        b = speed*speed-g*delta[2]
        discriminant = b*b-g*g*distance*distance
        if b <= 0 or discriminant < 0:
            raise UnsupportedMechanicError('Target is unreachable at the supplied ballistic launch speed')
        t = sqrt(2*distance*distance/(b+sqrt(discriminant)))
    velocity = (delta[0]/t,delta[1]/t,delta[2]/t+g*t/2)
    return AimedLaunch(velocity,t)
