"""Pure fixed-point placement of a hollow cube around bodies and joint groups."""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.hitboxes import Cuboid,combined_bounds
from combat_sim.mechanics.exact_ratio import ratio_text
from combat_sim.mechanics.velocity_projection import number


def penetrates(left,right):
    return all(max(a,c)<min(b,d) for a,b,c,d in zip(*left.bounds,*right.bounds))


def contains(bounds,body_bounds):
    low,high=bounds;a,b=body_bounds
    return all(x<=u and v<=y for x,y,u,v in zip(low,high,a,b))


@dataclass(frozen=True)
class EnclosurePlan:
    inner_min_m: tuple
    inner_max_m: tuple
    parts: tuple
    occupants: tuple
    required: tuple
    iterations: int
    body_bounds: tuple

    def record(self):
        return {'inner_min_m':list(map(ratio_text,self.inner_min_m)),
            'inner_max_m':list(map(ratio_text,self.inner_max_m)),
            'occupants':list(self.occupants),'required':list(self.required),'iterations':self.iterations,
            'body_bounds':{n:{'minimum_m':list(map(ratio_text,low)),'maximum_m':list(map(ratio_text,high))}
                for n,(low,high) in self.body_bounds}}


def cube_shell(inner_low,side,thickness):
    low=tuple(map(F,inner_low));side=number(side,positive=True);t=number(thickness,positive=True)
    if len(low)!=3:raise ValueError('Cube needs xyz bounds')
    high=tuple(x+side for x in low);centre=tuple((a+b)/2 for a,b in zip(low,high));outer=side+2*t
    rows=[]
    for axis,names in enumerate((('west','east'),('south','north'),('floor','roof'))):
        for sign,name in zip((-1,1),names):
            point=list(centre);point[axis]=(low[axis]-t/2 if sign<0 else high[axis]+t/2)
            size=[outer]*3;size[axis]=t
            rows.append(Cuboid(name,tuple(point),tuple(size)))
    return tuple(rows)


def fit_enclosure(bodies,required,*,groups=(),minimum_inner_side_m=2,wall_thickness_m=F(1,10),clearance_m=F(1,10)):
    """Monotone finite closure; no body is moved or cut by new material.

    Add all contained bodies, proposed material intersections and actual joint
    partners together per iteration. Stable sorted input makes placement
    independent of actor dictionary order. Static world overlap is a separate
    registry policy, not an implicit actor teleport or placement failure.
    """
    minimum=number(minimum_inner_side_m,positive=True);thickness=number(wall_thickness_m,positive=True)
    clearance=number(clearance_m)
    if not isinstance(bodies,dict) or not bodies:raise ValueError('Enclosure needs living body geometry')
    bodies={name:tuple(parts) for name,parts in bodies.items()}
    if any(not isinstance(name,str) or not name or not parts for name,parts in bodies.items()):
        raise ValueError('Enclosure needs named nonempty bodies')
    bounds={name:combined_bounds(parts) for name,parts in bodies.items()}
    needed=set(required)
    if not needed or not needed<=set(bodies):raise ValueError('Required enclosure bodies must exist')
    partners={name:{name} for name in bodies}
    for group in groups:
        members=set(group)
        if not members<=set(bodies):raise ValueError('Enclosure joint groups must be living bodies')
        for name in members:partners[name].update(members)
    included=set(needed);iterations=0
    while True:
        iterations+=1
        for name in tuple(included):included.update(partners[name])
        low=tuple(min(bounds[n][0][i] for n in included) for i in range(3))
        high=tuple(max(bounds[n][1][i] for n in included) for i in range(3))
        side=max(minimum,*(b-a+2*clearance for a,b in zip(low,high)))
        inner=((low[0]+high[0]-side)/2,(low[1]+high[1]-side)/2,low[2]-clearance)
        top=tuple(a+side for a in inner);parts=cube_shell(inner,side,thickness)
        additions=set()
        for name,(a,b) in sorted(bounds.items()):
            hull=Cuboid(name,tuple((x+y)/2 for x,y in zip(a,b)),tuple(y-x for x,y in zip(a,b)))
            if contains((inner,top),(a,b)) or any(penetrates(hull,wall) for wall in parts):
                additions.add(name);additions.update(partners[name])
        additions-=included
        if not additions:
            occupants=tuple(n for n in sorted(bodies) if contains((inner,top),bounds[n]))
            if any(penetrates(body,wall) for body_parts in bodies.values() for body in body_parts for wall in parts):
                raise RuntimeError('Enclosure placement penetrates living geometry')
            return EnclosurePlan(inner,top,parts,occupants,tuple(sorted(needed)),iterations,tuple(sorted(bounds.items())))
        included.update(additions)
