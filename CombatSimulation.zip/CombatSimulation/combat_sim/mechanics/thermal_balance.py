"""Reflected shield stock and continuous body temperature on a recovery plan.

Shield absorption/history remains analytic. A zero shield uses the available
recovery flow immediately; body exposure is the uncovered fraction. Only the
nonlinear temperature/dose portion needs adaptive dense integration.
"""
from dataclasses import dataclass,replace
from decimal import Decimal as D

from combat_sim.mechanics.continuous_numeric import root_affine_integral
from combat_sim.mechanics.dense_rk import DenseSolution,integrate
from combat_sim.mechanics.recovery_flow import RateShape,RootRate,AffineRate,_bisect
from combat_sim.mechanics.rate_damage import RateDamageSource
from combat_sim.mechanics.signed_rates import SignedRate
from combat_sim.world_colliders import finite

ABSOLUTE=D('1e-14');RELATIVE=D('1e-13')


@dataclass(frozen=True)
class ThermalSource:
    id: str
    pressure: object  # RootRate: incident q and output
    body_q: D
    coefficient: D
    exposed: bool
    shield_residual: bool
    decay: D = D(2)

    def __post_init__(self):
        object.__setattr__(self,'body_q',finite(self.body_q,'Body heat memory'))
        object.__setattr__(self,'coefficient',finite(self.coefficient,'Body heat coefficient'))
        object.__setattr__(self,'decay',finite(self.decay,'Heat decay',positive=True))
        if self.decay!=2:raise ValueError('Current fluid heat implements k=2')
        if type(self.exposed) is not bool or type(self.shield_residual) is not bool:raise ValueError('Heat coverage flags must be booleans')

    def q_incident(self,time):
        p=self.pressure
        return max(D(0),p.q_reference+p.slope_per_second*(time-p.reference_ms)/1000)


def _root_leading(shape,time):
    return sum((t.coefficient*t.slope_per_second.sqrt() for t in shape.terms
        if t.q_reference+t.slope_per_second*(time-t.reference_ms)/1000==0 and t.slope_per_second>0),D(0))


@dataclass(frozen=True)
class ThermalSegment:
    begin: D
    end: D
    sources: tuple
    body_begin: tuple
    shield_begin: D
    recovery: RateShape
    pressure: RateShape
    limited: bool
    slopes: tuple | None
    dense: object | None
    hp_before: tuple
    shield_before: tuple
    depletion: bool = False

    @property
    def loss_curve(self):return self.recovery if self.limited else self.pressure

    def at(self,time):
        count=len(self.sources)
        if self.dense is not None:
            values=self.dense.at(time)
            q=tuple(min(source.q_incident(time),max(D(0),v)) for source,v in zip(self.sources,values[:count]))
            hp=tuple(max(D(0),v) for v in values[count:2*count])
            shield=tuple(max(D(0),v) for v in values[2*count:])
        else:
            q=tuple(max(D(0),v+s*(time-self.begin)/1000) for v,s in zip(self.body_begin,self.slopes))
            hp=tuple(root_affine_integral(source.coefficient,v,self.begin,s,self.begin,time)
                if not isinstance(source,RateDamageSource) else D(0)
                for source,v,s in zip(self.sources,self.body_begin,self.slopes))
            shield=tuple(source.pressure.integral(self.begin,time) if source.exposed or source.shield_residual else D(0)
                for source in self.sources)
        total=self.loss_curve.integral(self.begin,time)
        nominal=sum(shield,D(0))
        shield=tuple(v*total/nominal for v in shield) if nominal else (D(0),)*count
        stock=(D(0) if self.limited or self.depletion and time==self.end else max(D(0),
            self.shield_begin+self.recovery.integral(self.begin,time)-total))
        return stock,q,tuple(a+b for a,b in zip(self.hp_before,hp)),tuple(a+b for a,b in zip(self.shield_before,shield))


@dataclass(frozen=True)
class ThermalPlan:
    begin: D
    end: D
    initial_shield: D
    sources: tuple
    segments: tuple
    depleted: bool
    absolute: D = ABSOLUTE
    relative: D = RELATIVE

    def at(self,time):
        if not self.begin<=time<=self.end:raise ValueError('Thermal query is outside the plan')
        for segment in self.segments:
            if time<=segment.end:return segment.at(time)
        return self.initial_shield,tuple(s.body_q for s in self.sources),(D(0),)*len(self.sources),(D(0),)*len(self.sources)

    def loss_pieces(self,begin,end):
        return [(max(begin,s.begin),min(end,s.end),s.loss_curve) for s in self.segments
            if max(begin,s.begin)<min(end,s.end)]

    def record(self):
        return {'begin_ms':self.begin,'end_ms':self.end,'depleted':self.depleted,
            'absolute_error_control':self.absolute,'relative_error_control':self.relative,
            'segments':[{'begin_ms':s.begin,'end_ms':s.end,'limited_by_recovery':s.limited,
                'adaptive_steps':len(s.dense.steps) if s.dense else 0,
                'evaluations':s.dense.evaluations if s.dense else 0} for s in self.segments]}


def _zero_body_flow(begin,end,sources,body,recovery,pressure,absolute,relative):
    count=len(sources)
    def derivative(time,state):
        raw=pressure.rate(time);available=recovery.rate(time)
        if raw:
            fraction=min(D(1),max(D(0),available/raw))
        elif available:fraction=D(1)
        else:
            lead=_root_leading(pressure,time);supplied=_root_leading(recovery,time)
            if lead:fraction=min(D(1),supplied/lead)
            else:
                p=sum((term.slope_per_second for term in pressure.affine_terms if term.rate(time)==0 and term.slope_per_second>0),D(0))
                r=sum((term.slope_per_second for term in recovery.affine_terms if term.rate(time)==0 and term.slope_per_second>0),D(0))
                fraction=D(1) if supplied else min(D(1),r/p) if p else D(0)
        slopes=tuple(D(0) if isinstance(s,RateDamageSource) else
            1-(1+s.decay)*fraction if s.exposed else -s.decay for s in sources)
        temperature=tuple(rate if q>0 or rate>0 else D(0) for q,rate in zip(state,slopes))
        hp=tuple(s.hp_rate(time,fraction) if isinstance(s,RateDamageSource) else
            s.coefficient*max(D(0),q).sqrt() for s,q in zip(sources,state[:count]))
        shield=tuple(available*s.pressure.rate(time)/raw if raw and (s.exposed or s.shield_residual) else D(0) for s in sources)
        return temperature+hp+shield
    initial=body+(D(0),)*(2*count);state=initial;steps=[];evaluations=rejected=0
    switches=SignedRate.combine(begin,((D(1),pressure),(D(-3),recovery))).cells(begin,end)
    for a,b,_ in switches:
        part=integrate(derivative,a,b,state,absolute=absolute,relative=relative)
        state=part.at(b);state=tuple(max(D(0),v) for v in state[:count])+state[count:]
        steps.extend(part.steps);evaluations+=part.evaluations;rejected+=part.rejected
    return DenseSolution(begin,end,initial,tuple(steps),evaluations,rejected)


def build_thermal_plan(recovery,shield,sources,*,absolute=ABSOLUTE,relative=RELATIVE):
    shield=finite(shield,'Shield stock')
    begin,end=recovery.begin,recovery.end
    sources=tuple(replace(s,shield_residual=False) if not shield and not s.exposed else s for s in sources)
    count=len(sources)
    body=tuple(s.body_q for s in sources);hp=allocated=(D(0),)*count
    incoming=tuple(s.pressure for s in sources if s.exposed or s.shield_residual and shield>0)
    pressure=RateShape(terms=tuple(s for s in incoming if isinstance(s,RootRate)),
        affine_terms=tuple(s for s in incoming if isinstance(s,AffineRate)))
    segments=[];stock=shield
    for piece in recovery.pieces:
        a,b=piece.begin,piece.end
        difference=SignedRate.combine(a,((D(1),piece.shape),(D(-1),pressure)))
        for first,last,sign in difference.cells(a,b):
            limited=not stock and sign<=0
            depleted=False
            if not limited and sign<0:
                balance=lambda t:stock+piece.shape.integral(first,t)-pressure.integral(first,t)
                if balance(last)<=0:
                    last=_bisect(balance,first,last,increasing=False);depleted=True
            if limited and sign<0 and (piece.shape.constant_per_second or piece.shape.terms or piece.shape.affine_terms
                    or any(isinstance(s,RateDamageSource) for s in sources)):
                slopes=None;dense=_zero_body_flow(first,last,sources,body,piece.shape,pressure,absolute,relative)
            else:
                slopes=tuple(D(0) if isinstance(s,RateDamageSource) else
                    D(1) if limited and sign<0 and s.exposed else -s.decay for s in sources);dense=None
            segment=ThermalSegment(first,last,sources,body,stock,piece.shape,pressure,bool(limited),slopes,dense,hp,allocated,depleted)
            segments.append(segment)
            stock,body,hp,allocated=segment.at(last)
            if depleted:return ThermalPlan(begin,last,shield,sources,tuple(segments),True,absolute,relative)
    return ThermalPlan(begin,end,shield,sources,tuple(segments),False,absolute,relative)
