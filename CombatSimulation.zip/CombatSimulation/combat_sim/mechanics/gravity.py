"""Isolated projectile physics with explicit launch velocity; no aiming policy.

Uses SI units and binary64 adaptive RK4 step doubling for velocity-dependent
acceleration. Undecelerated ballistic position, velocity and arc length have
closed forms. Numerical tolerances are solver controls, not combat rules.
"""
from bisect import bisect_right
from dataclasses import dataclass
from math import asinh, ceil, hypot, isfinite

from combat_sim.models import UnsupportedMechanicError

GRAVITY_MPS2 = 9.81


def vector(values):
    result = tuple(float(x) for x in values)
    if len(result) != 3 or not all(isfinite(x) for x in result):
        raise ValueError('Expected three finite vector components')
    return result


@dataclass(frozen=True)
class MotionState:
    time_s: float
    position_m: tuple
    velocity_mps: tuple
    distance_m: float

    @property
    def speed_mps(self):
        return hypot(*self.velocity_mps)


class ProjectileTrajectory:
    """Finite test trajectory, independent of abilities, target selection or HP.

    Positive deceleration acts opposite instantaneous velocity. To avoid choosing
    undefined behavior at zero speed, decelerating trajectories require the
    conservative bound |v0| - (deceleration + gravity)*duration > 0.
    """
    def __init__(self, origin_m, velocity_mps, duration_s, *, deceleration_mps2=0,
                 gravity_mps2=GRAVITY_MPS2, max_step_s=.01, relative_tolerance=1e-11,
                 absolute_tolerance=1e-12):
        self.origin = vector(origin_m)
        self.velocity = vector(velocity_mps)
        self.duration = float(duration_s)
        self.deceleration = float(deceleration_mps2)
        self.gravity = float(gravity_mps2)
        self.max_step = float(max_step_s)
        self.rtol = float(relative_tolerance)
        self.atol = float(absolute_tolerance)
        if not all(isfinite(x) for x in (self.duration,self.deceleration,self.gravity,self.max_step,self.rtol,self.atol)):
            raise ValueError('Trajectory controls must be finite')
        if min(self.duration,self.deceleration,self.gravity) < 0 or min(self.max_step,self.rtol,self.atol) <= 0:
            raise ValueError('Invalid trajectory duration, acceleration or numerical controls')
        if self.deceleration and hypot(*self.velocity) <= (self.deceleration+self.gravity)*self.duration:
            raise UnsupportedMechanicError('Duration reaches the conservative zero-speed safety boundary; no stopping rule is defined')
        initial = MotionState(0.,self.origin,self.velocity,0.)
        if not self.deceleration:
            count = max(1,ceil(self.duration/self.max_step))
            self.states = tuple(self._ballistic(self.duration*i/count) for i in range(count+1)) if self.duration else (initial,)
        else:
            self.states = (initial,*self._integrate(initial,self.duration))
        self.times = tuple(s.time_s for s in self.states)

    def _ballistic(self,t):
        x,y,z = self.origin
        vx,vy,vz = self.velocity
        g = self.gravity
        position = (x+vx*t,y+vy*t,z+vz*t-g*t*t/2)
        velocity = (vx,vy,vz-g*t)
        horizontal = hypot(vx,vy)
        if g == 0:
            distance = hypot(*self.velocity)*t
        elif horizontal == 0:
            u = vz-g*t
            distance = (vz*abs(vz)-u*abs(u))/(2*g)
        else:
            # Definite integral of speed; asinh form handles upward/downward arcs.
            def primitive(u):
                return (u*hypot(horizontal,u)+horizontal**2*asinh(u/horizontal))/2
            distance = (primitive(vz)-primitive(vz-g*t))/g
        return MotionState(t,position,velocity,distance)

    def _derivative(self,y):
        velocity = y[3:6]
        speed = hypot(*velocity)
        if speed == 0:
            raise UnsupportedMechanicError('Deceleration direction is undefined at zero speed')
        acceleration = tuple(-self.deceleration*v/speed for v in velocity)
        return (*velocity,acceleration[0],acceleration[1],acceleration[2]-self.gravity,speed)

    def _step(self,y,h):
        k1 = self._derivative(y)
        k2 = self._derivative(tuple(a+h*b/2 for a,b in zip(y,k1)))
        k3 = self._derivative(tuple(a+h*b/2 for a,b in zip(y,k2)))
        k4 = self._derivative(tuple(a+h*b for a,b in zip(y,k3)))
        return tuple(a+h*(b+2*c+2*d+e)/6 for a,b,c,d,e in zip(y,k1,k2,k3,k4))

    def _integrate(self,state,end):
        t = state.time_s
        y = (*state.position_m,*state.velocity_mps,state.distance_m)
        h = min(self.max_step,end-t)
        result = []
        while t < end:
            h = min(h,end-t)
            if t+h == t:
                raise ArithmeticError('Trajectory step cannot advance at binary64 precision')
            whole = self._step(y,h)
            half = self._step(self._step(y,h/2),h/2)
            error = max(abs(a-b)/(15*(self.atol+self.rtol*max(abs(c),abs(b)))) for a,b,c in zip(whole,half,y))
            if error <= 1:
                y = half
                t = end if h == end-t else t+h
                result.append(MotionState(t,y[:3],y[3:6],y[6]))
            factor = 2 if error == 0 else min(2,max(.1,.9*error**(-.2)))
            h = min(self.max_step,h*factor)
        return result

    def at(self,time_s):
        t = float(time_s)
        if not isfinite(t) or not 0 <= t <= self.duration:
            raise ValueError('Requested time is outside the explicit trajectory horizon')
        if not self.deceleration:
            return self._ballistic(t)
        index = bisect_right(self.times,t)-1
        state = self.states[index]
        return state if state.time_s == t else self._integrate(state,t)[-1]
