"""Exact first outward crossing of a quadratic pair's spherical distance limit."""
from fractions import Fraction as F
from math import comb

from combat_sim.moving_projectiles import _roots, _evaluate
from combat_sim.mechanics.velocity_projection import number, vector


def first_distance_exit(relative_position, relative_velocity, relative_acceleration, maximum_m, seconds,
                        *, tolerance_s=F(1,10**18)):
    p,v,a=map(vector,(relative_position,relative_velocity,relative_acceleration))
    length=number(maximum_m,positive=True);end=number(seconds);tolerance=number(tolerance_s,positive=True)
    q=tuple(x/2 for x in a)
    dot=lambda x,y:sum((i*j for i,j in zip(x,y)),F(0))
    poly=(dot(p,p)-length*length,2*dot(p,v),dot(v,v)+2*dot(p,q),2*dot(v,q),dot(q,q))
    if poly[0]>0 or poly[0]==0 and next((c for c in poly[1:] if c),F(0))>0:return F(0),F(0)
    if not end:return None
    roots=_roots(poly,F(0),end)
    for root in roots:
        while root.high-root.low>tolerance:root.refine()
    roots.sort(key=lambda r:r.low)
    for index,root in enumerate(roots):
        if root.high==0:continue
        after=(root.high+(roots[index+1].low if index+1<len(roots) else end))/2
        if after>root.high and _evaluate(poly,after)>0:return root.low,root.high
        if root.low==root.high==end:
            # At a supplied endpoint, the first nonzero right Taylor term
            # decides whether reaching the limit is an outward crossing.
            derivatives=(sum((poly[k]*comb(k,j)*end**(k-j) for k in range(j,len(poly))),F(0))
                for j in range(1,len(poly)))
            right=next((value for value in derivatives if value),F(0))
            if right>0:return root.low,root.high
    return None
