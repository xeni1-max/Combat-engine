"""Finite-interval maximum-distance response with an exact feasible answer.

Supporting-plane QPs provide lower objective bounds. A feasible radial scaling
provides the upper bound. Strong convexity certifies the distance from the true
weighted minimum; no sequential pair correction is accepted as the answer.
"""
from dataclasses import dataclass
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F

from combat_sim.mechanics.affine_velocity import VelocityLimit,project_affine,dot
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality,BlockedDirection,number,vector
from combat_sim.mechanics.unilateral_velocity import ContactLimit
from combat_sim.mechanics.exact_ratio import ratio_text


@dataclass(frozen=True)
class MaximumDistance:
    first: str
    second: str
    maximum_m: F

    def __post_init__(self):
        if any(not isinstance(n,str) or not n for n in (self.first,self.second)) or self.first==self.second:
            raise ValueError('A maximum distance needs two distinct named bodies')
        object.__setattr__(self,'maximum_m',number(self.maximum_m,positive=True))


@dataclass(frozen=True)
class FixedPoint:
    identity: str
    position_m: tuple

    def __post_init__(self):
        if not isinstance(self.identity,str) or not self.identity:raise ValueError('A fixed point needs an identity')
        object.__setattr__(self,'position_m',vector(self.position_m))


@dataclass(frozen=True)
class FixedDistance:
    first: str
    anchor: FixedPoint
    maximum_m: F

    def __post_init__(self):
        if (not isinstance(self.first,str) or not self.first or not isinstance(self.anchor,FixedPoint)
                or self.first==self.anchor.identity):raise ValueError('A fixed distance needs distinct actor/point identities')
        object.__setattr__(self,'maximum_m',number(self.maximum_m,positive=True))

    @property
    def second(self):return self.anchor.identity


def relative_position(edge,values):
    second=edge.anchor.position_m if isinstance(edge,FixedDistance) else values[edge.second]
    return tuple(b-a for a,b in zip(values[edge.first],second))


def relative_velocity(edge,values):
    second=(0,0,0) if isinstance(edge,FixedDistance) else values[edge.second]
    return tuple(b-a for a,b in zip(values[edge.first],second))


def fixed_points(edges):
    return tuple(sorted({e.anchor.identity:e.anchor.position_m for e in edges if isinstance(e,FixedDistance)}.items()))


@dataclass(frozen=True)
class DistanceProjection:
    velocities: tuple
    exact_velocities: tuple
    linear_projection: object
    feasible_scale: F
    objective_lower: F
    objective_upper: F
    maximum_error_mps: F
    cut_rounds: int
    precision: int
    anchor_projection: object = None

    def record(self):
        return {'velocities_mps':{n:tuple(map(str,v)) for n,v in self.velocities},
            'exact_velocities_mps':{n:tuple(map(ratio_text,v)) for n,v in self.exact_velocities},
            'linear_projection':self.linear_projection.record(),'feasible_scale':ratio_text(self.feasible_scale),
            'objective_lower':ratio_text(self.objective_lower),'objective_upper':ratio_text(self.objective_upper),
            'maximum_error_mps':ratio_text(self.maximum_error_mps),'supporting_plane_rounds':self.cut_rounds,
            'precision':self.precision,
            **({'feasible_anchor_projection':self.anchor_projection.record()} if self.anchor_projection is not None else {})}


def sqrt_bound(value,precision,*,upper):
    """A checked rational bound; Decimal's rounded square root is not a bound."""
    value=F(value)
    if value<0:raise ValueError('Square-root bound needs a nonnegative value')
    if not value:return F(0)
    with localcontext(Context(prec=max(60,precision+10))) as context:
        root=(D(value.numerator)/D(value.denominator)).sqrt()
        if upper:
            while F(root)**2<value:root=context.next_plus(root)
        else:
            while F(root)**2>value:root=context.next_minus(root)
        return F(root)


def feasible_fraction(c,b,a,precision):
    """Largest certified lower alpha in [0,1] with a*alpha²+b*alpha+c<=0.

    Here a>=0,c<=0. Convexity makes every prefix through the returned alpha
    feasible, including a boundary/tangent point whose only legal alpha is 0.
    """
    c,b,a=map(F,(c,b,a))
    if a<0 or c>0:raise ValueError('A feasible fraction needs a convex origin-feasible quadratic')
    if a+b+c<=0:return F(1)
    if not a:return max(F(0),min(F(1),-c/b))
    if not c and b>=0:return F(0)
    root=sqrt_bound(b*b-4*a*c,precision,upper=False)
    alpha=max(F(0),min(F(1),(-b+root)/(2*a)))
    if a*alpha*alpha+b*alpha+c>0:raise ArithmeticError('Radial feasibility bound failed')
    return alpha


def validate_distances(nodes,references,distances):
    nodes=tuple(nodes)
    if any(not isinstance(n,VelocityNode) for n in nodes):raise ValueError('Distances need typed velocity nodes')
    names={n.identity for n in nodes}
    if len(names)!=len(nodes):raise ValueError('Distance node identities must be unique')
    refs={n:vector(v) for n,v in dict(references).items()}
    if set(refs)!=names:raise ValueError('References must describe exactly the participating bodies')
    selected={};fixed={};points={}
    for edge in distances:
        if isinstance(edge,FixedDistance):
            if edge.first not in names or edge.second in names:raise ValueError('A fixed distance needs an actor and a non-actor point')
            if edge.second in points and points[edge.second]!=edge.anchor.position_m:raise ValueError('A fixed identity cannot name different positions')
            points[edge.second]=edge.anchor.position_m
            key=(edge.first,edge.second)
            if key not in fixed or edge.maximum_m<fixed[key].maximum_m:fixed[key]=edge
            continue
        if not isinstance(edge,MaximumDistance):raise ValueError('Expected a typed maximum or fixed distance')
        if edge.first not in names or edge.second not in names:raise ValueError('Distance endpoints must exist')
        pair=tuple(sorted((edge.first,edge.second)))
        selected[pair]=min(selected.get(pair,edge.maximum_m),edge.maximum_m)
    edges=tuple(MaximumDistance(*pair,length) for pair,length in sorted(selected.items()))+tuple(fixed[k] for k in sorted(fixed))
    for edge in edges:
        r=relative_position(edge,refs)
        if dot(r,r)>edge.maximum_m**2:raise ValueError('A distance step must start within its limits')
    return nodes,refs,edges


def project_distances(nodes,references,seconds,distances=(),contacts=(),equalities=(),blocked=(),*,
        precision=50,maximum_error_mps='1e-10',maximum_rounds=96):
    """Weighted closest velocities whose finite endpoints obey every limit.

    Contacts constrain departure from an already touching plane; continuous
    body/terrain sweeps still belong to the world. Equality/blocked semantics
    are unchanged. The exact returned endpoints are feasible, and their
    Euclidean error from the true optimum is bounded by maximum_error_mps.
    """
    if type(precision) is not int or precision<40:raise ValueError('Distance precision must be at least 40')
    if type(maximum_rounds) is not int or maximum_rounds<=0:raise ValueError('Distance iteration limit must be positive')
    seconds=number(seconds,positive=True);error=number(maximum_error_mps,positive=True)
    nodes,refs,edges=validate_distances(nodes,references,distances)
    contacts=tuple(contacts);equalities=tuple(equalities);blocked=tuple(blocked)
    limits=[]
    for contact in contacts:
        if not isinstance(contact,ContactLimit):raise ValueError('Expected a typed contact limit')
        terms=((contact.actor,contact.toward_obstacle),)
        if contact.other is not None:terms+=((contact.other,tuple(-x for x in contact.toward_obstacle)),)
        limits.append(VelocityLimit(terms,0))
    contact_limits=tuple(limits)
    wanted={n.identity:n.velocity_mps for n in nodes}
    radii={edge:relative_position(edge,refs) for edge in edges}

    def cut(edge,normal):
        # Any rounded normal still defines a valid supporting plane. Bound
        # numerator growth before feeding the exact rational linear solver.
        scale=max(map(abs,normal))
        if not scale:return
        with localcontext(Context(prec=precision)):
            n=tuple(F(D((x/scale).numerator)/D((x/scale).denominator)) for x in normal)
        length=sqrt_bound(dot(n,n),precision,upper=True)
        bound=(edge.maximum_m*length-dot(n,radii[edge]))/seconds
        if bound<0:raise ArithmeticError('A supporting plane excluded zero motion')
        terms=((edge.first,tuple(-x for x in n)),)
        if not isinstance(edge,FixedDistance):terms+=((edge.second,n),)
        limits.append(VelocityLimit(terms,bound))

    for edge in edges:cut(edge,radii[edge])
    anchor=None
    for iteration in range(maximum_rounds):
        linear=project_affine(nodes,limits,equalities,blocked,precision=precision)
        values=dict(linear.exact_velocities);weights=dict(linear.weights);violated=[];alpha=F(1)
        for edge in edges:
            r=radii[edge];delta=tuple(seconds*x for x in relative_velocity(edge,values))
            end=tuple(x+y for x,y in zip(r,delta))
            if dot(end,end)>edge.maximum_m**2:
                violated.append((edge,end))
                alpha=min(alpha,feasible_fraction(dot(r,r)-edge.maximum_m**2,2*dot(r,delta),dot(delta,delta),precision))
        feasible={n:tuple(alpha*x for x in v) for n,v in values.items()}
        def objective(v):return sum((weights[n]*dot(tuple(a-b for a,b in zip(v[n],wanted[n])),
            tuple(a-b for a,b in zip(v[n],wanted[n])))/2 for n in values),F(0))
        lower=objective(values);upper=objective(feasible);minimum_weight=min(weights.values(),default=F(1))
        selected_anchor=None
        if iteration>=8 and upper-lower>minimum_weight*error*error/2:
            # Near tangency, rounding the supporting normal can make the only
            # certified radial scale almost zero. Preserve feasible common
            # translation instead of shrinking it with the relative motion.
            # Equal endpoint velocities keep every distance unchanged; fixed
            # endpoints require zero velocity. Contacts remain homogeneous.
            if anchor is None:
                common=list(equalities);stationary=list(blocked)
                for edge in edges:
                    if isinstance(edge,FixedDistance):
                        stationary.extend(BlockedDirection(edge.first,tuple(int(i==j) for i in range(3))) for j in range(3))
                    else:common.append(VelocityEquality(edge.first,edge.second))
                anchor=project_affine(nodes,contact_limits,common,stationary,precision=precision)
            origin=dict(anchor.exact_velocities)
            candidate={n:tuple(a+alpha*(x-a) for a,x in zip(origin[n],v)) for n,v in values.items()}
            candidate_upper=objective(candidate)
            if candidate_upper<upper:feasible=candidate;upper=candidate_upper;selected_anchor=anchor
        if upper<lower:raise ArithmeticError('Distance objective bounds reversed')
        if upper-lower<=minimum_weight*error*error/2:
            # Recheck strict nonlinear feasibility independently of the root
            # bound. Scaling preserves homogeneous equalities and b>=0 rows.
            for edge in edges:
                end=tuple(x+seconds*v for x,v in zip(radii[edge],relative_velocity(edge,feasible)))
                if dot(end,end)>edge.maximum_m**2:raise ArithmeticError('Distance response is not feasible')
            exact=tuple(sorted(feasible.items()))
            with localcontext(Context(prec=precision)):
                presented=tuple((n,tuple(D(x.numerator)/D(x.denominator) for x in v)) for n,v in exact)
            return DistanceProjection(presented,exact,linear,alpha,lower,upper,error,iteration,precision,selected_anchor)
        # Active planes alone retain the previous exact QP optimum/certificate.
        # Discarding zero-multiplier cuts prevents a grazing intersection from
        # accumulating a quadratic-sized Gram matrix over many refinements.
        limits=list(contact_limits)
        for row,bound,multiplier in zip(linear.rows,linear.bounds,linear.multipliers):
            if multiplier:
                terms=tuple((name,row[3*i:3*i+3]) for i,name in enumerate(linear.node_order)
                    if any(row[3*i:3*i+3]))
                limits.append(VelocityLimit(terms,bound))
        for edge,end in violated:cut(edge,end)
    raise ArithmeticError('Finite distance projection did not meet its objective/error certificate')
