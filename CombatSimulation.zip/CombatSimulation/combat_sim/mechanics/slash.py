"""Slash impact, armor loss, and isolated bleeding-rate formulas.

These helpers do not schedule bleed payments, choose stacking, or execute an
entire ability. The caller supplies y for the isolated bleeding-rate equation.
"""

from fractions import Fraction
from dataclasses import dataclass

from combat_sim.models import as_fraction
from combat_sim.mechanics.shield import split_damage
from combat_sim.mechanics.blunt import (
    ARMOR_REDUCTION_FORMULA,
    armor_reduction as _shared_armor_reduction,
    raw_armor_reduction as _shared_raw_armor_reduction,
)


SOURCE = "Damage types.odt, Slash; user clarification on adjusted defense floors"
FORMULA = "y = (d^2 - max(0, a-p)^2) / d; final damage minimum zero"
ARMOR_SOURCE = "Damage types.odt, Slash, armor reduced per attack (p19/p21)"
BLEED_SOURCE = "Damage types.odt, Slash, bleeding rate and 8-second duration (p13/p17)"
BLEED_FORMULA = "b = y * max(0, 8-tb) / 320; tb in seconds"
BLEED_DURATION_SECONDS = Fraction(8)


@dataclass(frozen=True)
class SlashImpact:
    """One confirmed slash calculation using a single pre-hit armor snapshot.

    No status ordering, bleed/venom creation, or mutable HP state is inferred.
    """

    pre_hit_armor: Fraction
    shield_damage: Fraction
    shield_after: Fraction
    damage_left_after_shield: Fraction
    raw_hp_damage: Fraction
    hp_damage: Fraction
    raw_armor_loss: Fraction
    armor_loss: Fraction


def calculate_impact(incoming_damage, current_armor, piercing, current_shield) -> SlashImpact:
    """Split shields first and calculate HP/armor outputs from pre-hit armor.

    The author confirms HP damage precedes armor loss. Both equations use
    this original armor; the caller applies resulting state floors separately.
    Fully shielded/zero incoming hits bypass the equations' zero denominators.
    """
    armor, penetration, shield = map(as_fraction, (current_armor, piercing, current_shield))
    if armor < 0 or penetration < 0:
        raise ValueError("Armor and piercing must be nonnegative")
    absorbed, damage = split_damage(incoming_damage, shield)
    raw_y = raw_post_mitigation_damage(damage, armor, penetration) if damage else Fraction(0)
    raw_ar = raw_armor_reduction(damage, armor) if damage else Fraction(0)
    return SlashImpact(
        armor, absorbed, shield - absorbed, damage, raw_y, max(Fraction(0), raw_y),
        raw_ar, max(Fraction(0), raw_ar),
    )


def raw_armor_reduction(pre_mitigation_damage: Fraction, armor: Fraction) -> Fraction:
    """Slash explicitly uses the same Ar equation as Blunt, without piercing."""
    return _shared_raw_armor_reduction(pre_mitigation_damage, armor)


def armor_reduction(pre_mitigation_damage: Fraction, armor: Fraction) -> Fraction:
    """Apply the documented slash Ar equation and confirmed zero floor."""
    return _shared_armor_reduction(pre_mitigation_damage, armor)


def bleeding_damage_rate(post_mitigation_damage: Fraction, elapsed_seconds: Fraction) -> Fraction:
    """Evaluate one bleed's instantaneous DPS; no stacking or payout inferred."""
    damage = as_fraction(post_mitigation_damage)
    elapsed = as_fraction(elapsed_seconds)
    if damage < 0 or elapsed < 0:
        raise ValueError("Bleeding damage input and elapsed seconds must be nonnegative")
    return damage * max(Fraction(0), BLEED_DURATION_SECONDS - elapsed) / 320


def bleeding_damage_between(post_mitigation_damage, start_seconds, end_seconds) -> Fraction:
    """Integrate the documented linear bleed exactly over an elapsed interval.

    The author confirms continuous accumulation. This is one bleed; overlap
    and creation policy remain the encounter controller's responsibility.
    """
    damage, start, end = map(as_fraction, (post_mitigation_damage, start_seconds, end_seconds))
    if min(damage, start, end) < 0 or end < start:
        raise ValueError("Bleed inputs must be nonnegative and end must not precede start")
    start, end = min(start, BLEED_DURATION_SECONDS), min(end, BLEED_DURATION_SECONDS)
    return damage * (BLEED_DURATION_SECONDS * (end - start) - (end**2 - start**2) / 2) / 320


def raw_post_mitigation_damage(
    pre_mitigation_damage: Fraction, armor: Fraction, piercing: Fraction,
) -> Fraction:
    damage = as_fraction(pre_mitigation_damage)
    current_armor = as_fraction(armor)
    penetration = as_fraction(piercing)
    if damage == 0:
        raise ValueError("Slash formula is undefined for d=0 (division by zero)")
    if min(damage, current_armor, penetration) < 0:
        raise ValueError("Damage, armor, and piercing must be nonnegative")
    effective_armor = max(Fraction(0), current_armor - penetration)
    return (damage**2 - effective_armor**2) / damage


def post_mitigation_damage(
    pre_mitigation_damage: Fraction, armor: Fraction, piercing: Fraction,
) -> Fraction:
    """Apply the documented equation with defense and final-damage floors."""
    return max(Fraction(0), raw_post_mitigation_damage(pre_mitigation_damage, armor, piercing))
