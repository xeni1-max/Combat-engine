"""Exact scalar bounds for constant-acceleration geometry intervals."""
from combat_sim.models import as_fraction


def quadratic_range(value,velocity,acceleration,begin_s,end_s):
    values=(value,velocity,acceleration,begin_s,end_s)
    if any(isinstance(v,bool) for v in values):raise ValueError('Kinematic bounds require numeric inputs')
    try:p,v,a,begin,end=map(as_fraction,values)
    except (TypeError,ValueError,ArithmeticError) as error:raise ValueError('Kinematic bounds must be finite') from error
    if begin<0 or end<begin:raise ValueError('Invalid kinematic bound interval')
    def at(t):return p+v*t+a*t*t/2
    result=[at(begin),at(end)]
    if a and begin<-v/a<end:result.append(at(-v/a))
    return min(result),max(result)
