"""Exact decimal ratio records without changing Python's integer-string limit."""
from decimal import Decimal as D
from fractions import Fraction as F


def ratio_text(value):
    value=F(value)
    numerator=format(D(value.numerator),'f')
    return numerator if value.denominator==1 else numerator+'/'+format(D(value.denominator),'f')


def read_ratio(value):
    if isinstance(value,bool):raise ValueError('An exact ratio cannot be boolean')
    if isinstance(value,str):
        numerator,slash,denominator=value.partition('/')
        # Decimal parsing and as_integer_ratio preserve all digits without
        # Python int(decimal_text), whose process-wide guard remains enabled.
        return F(D(numerator))/F(D(denominator)) if slash else F(D(numerator))
    return F(value)
