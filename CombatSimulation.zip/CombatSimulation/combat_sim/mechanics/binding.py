"""Binding escape threshold from the primary MathML, with a real-valued floor."""
from decimal import Context, Decimal as D, localcontext

from combat_sim.mechanics.velocity_projection import number


def escape_work(binding_value, maximum_hp, *, precision=40):
    if type(precision) is not int or precision < 40:
        raise ValueError('Binding precision must be at least 40')
    value = number(binding_value)
    hp = number(maximum_hp, positive=True)
    with localcontext(Context(prec=precision)):
        base = max(D(0), 20*D(value.numerator)/value.denominator-D(hp.numerator)/hp.denominator/500)
        return base**D('0.9') if base else D(0)
