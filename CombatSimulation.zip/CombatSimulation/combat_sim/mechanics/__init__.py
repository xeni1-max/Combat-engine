"""Pure formula implementations, each linked to its source rule."""
