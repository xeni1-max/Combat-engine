"""Documented continuous projectile range falloff, separate from travel timing."""
from fractions import Fraction
from combat_sim.models import as_fraction

FORMULA = 'incoming = max(0, base_damage - damage_loss * distance_m / loss_distance_m)'
SOURCE = '1E2.odt p69; author confirms continuous 5 damage per 20 m'


def damage_after_distance(base_damage, distance_m, damage_loss, loss_distance_m):
    base, distance, loss, interval = map(as_fraction, (base_damage, distance_m, damage_loss, loss_distance_m))
    if min(base, distance, loss) < 0 or interval <= 0:
        raise ValueError('Range falloff requires nonnegative damage/distance/loss and a positive loss interval')
    return max(Fraction(0), base - loss * distance / interval)
