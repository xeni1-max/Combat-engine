"""Poisonous gas: no slash delivery factor, exact continuously accumulated toxin."""
from fractions import Fraction
from combat_sim.exact import ExactAmount, ExactRootProduct
from combat_sim.models import as_fraction

SOURCE='Damage types.odt, Poisonous p42/p44/p46; author confirms elapsed exposure then residual, shield bypass and unchanged armor'
FORMULA='Td = max(0,(Tp^2-10*RT^2)/Tp) * sqrt(tT-to)'


def poison_coefficient(toxicity,toxin_resistance):
    tp,rt=map(as_fraction,(toxicity,toxin_resistance))
    if tp<=0 or rt<0: raise ValueError('Poison requires positive toxicity and nonnegative toxin resistance')
    return max(Fraction(0),(tp**2-10*rt**2)/tp)


def poison_damage_rate(toxicity,toxin_resistance,exposure_seconds,non_exposure_seconds=0):
    coefficient=poison_coefficient(toxicity,toxin_resistance)
    exposure,non_exposure=map(as_fraction,(exposure_seconds,non_exposure_seconds))
    if min(exposure,non_exposure)<0 or non_exposure>exposure:
        raise ValueError('Poison requires nonnegative clocks and exposure >= non-exposure')
    return ExactRootProduct(coefficient,exposure-non_exposure)


def poison_damage_between(toxicity,toxin_resistance,root_input_start,root_input_end,elapsed_seconds):
    """Integral C*sqrt(q) for linear q and unchanged resistance in the interval."""
    coefficient=poison_coefficient(toxicity,toxin_resistance)
    q0,q1,elapsed=map(as_fraction,(root_input_start,root_input_end,elapsed_seconds))
    if min(q0,q1,elapsed)<0: raise ValueError('Poison integration inputs must be nonnegative')
    if elapsed==0:
        if q0!=q1: raise ValueError('Zero elapsed time cannot change exposure')
        return ExactAmount()
    if q0==q1: return ExactAmount.of(ExactRootProduct(coefficient*elapsed,q0))
    factor=Fraction(2,3)*coefficient*elapsed/(q1-q0)
    return ExactAmount(roots=(ExactRootProduct(factor*q1,q1),ExactRootProduct(-factor*q0,q0)))


def full_exposure_and_recovery_damage(toxicity,toxin_resistance,exposure_seconds):
    duration=as_fraction(exposure_seconds)
    if duration<0: raise ValueError('Exposure duration must be nonnegative')
    return poison_damage_between(toxicity,toxin_resistance,0,duration,duration)+poison_damage_between(toxicity,toxin_resistance,duration,0,duration)
