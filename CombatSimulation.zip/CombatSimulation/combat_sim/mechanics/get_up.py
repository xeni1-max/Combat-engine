"""Get Up timing and cost profiles; action scheduling lives in the engine.

The author defines two times Recovery and two times jump dyspnea. Under the
author's delegated mechanics decisions, those mean the numeric Recovery value
in milliseconds and the jump's base value before the action-cost formula.
"""
from collections.abc import Mapping
from fractions import Fraction

from combat_sim.models import UnsupportedMechanicError, as_fraction


def _number(value, name, *, positive=False):
    if isinstance(value, bool):
        raise ValueError(f'{name} must be a number, not a boolean')
    try:
        number = as_fraction(value)
    except (TypeError, ValueError, ZeroDivisionError, OverflowError) as error:
        raise ValueError(f'{name} must be a finite number') from error
    if number < 0 or (positive and number == 0):
        raise ValueError(f'{name} must be {"positive" if positive else "nonnegative"}')
    return number


def get_up_profile(character_id, definition):
    """Return a fresh exact timing/cost profile for one defined character.

This function does not check whether an actor is down or alive, apply costs,
alter posture, or schedule completion. The dyspnea rule can be passed directly
to ``apply_action_dyspnea_at_phase`` at Active start.
    """
    if not isinstance(definition, Mapping):
        raise ValueError('Get Up definition must be a mapping')
    characters = definition.get('characters')
    if not isinstance(characters, Mapping) or character_id not in characters:
        raise UnsupportedMechanicError(f'No Get Up profile for character {character_id!r}')
    character = characters[character_id]
    if not isinstance(character, Mapping):
        raise ValueError('Get Up character profile must be a mapping')
    required = ('active_recovery_multiplier', 'dyspnea_jump_base_multiplier',
                'gathering_ms', 'physical_recovery_ms', 'capacity_check_timing',
                'payment_timing')
    missing = set(required) - set(definition)
    missing_character = {'recovery_value', 'jump_base_dyspnea'} - set(character)
    if missing or missing_character:
        raise ValueError(f'Incomplete Get Up definition: {sorted(missing | missing_character)}')
    if (definition['capacity_check_timing'] != 'active_start' or
            definition['payment_timing'] != 'active_start'):
        raise UnsupportedMechanicError('Get Up checks and pays dyspnea at Active start')
    for phase in ('gathering_ms', 'physical_recovery_ms'):
        if _number(definition[phase], phase) != 0:
            raise UnsupportedMechanicError('Get Up has no Gathering or additional hand Recovery')
    recovery = _number(character['recovery_value'], 'Recovery', positive=True)
    jump_base = _number(character['jump_base_dyspnea'], 'Jump base dyspnea')
    active_multiplier = _number(definition['active_recovery_multiplier'],
                                'Active Recovery multiplier', positive=True)
    cost_multiplier = _number(definition['dyspnea_jump_base_multiplier'],
                              'Jump dyspnea multiplier', positive=True)
    return derive_get_up_profile(recovery,jump_base,active_multiplier=active_multiplier,cost_multiplier=cost_multiplier)


def derive_get_up_profile(recovery,jump_base,*,active_multiplier=2,cost_multiplier=2):
    """Use source values already supplied by a current actor/basic-jump profile."""
    recovery=_number(recovery,'Recovery',positive=True)
    jump_base=_number(jump_base,'Jump base dyspnea')
    active_multiplier=_number(active_multiplier,'Active Recovery multiplier',positive=True)
    cost_multiplier=_number(cost_multiplier,'Jump dyspnea multiplier',positive=True)
    return {
        'gathering_ms': Fraction(0),
        'active_ms': recovery * active_multiplier,
        'dyspnea': {
            'kind': 'action',
            'base_value': jump_base * cost_multiplier,
            'capacity_check_timing': 'active_start',
            'payment_timing': 'active_start',
        },
    }
