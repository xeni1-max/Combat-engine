"""Earliest nonnegative comparison using interval slope bounds, not end signs.

The caller supplies bounds for its actual saved trajectory between input knots.
Tangencies are isolated to clock resolution and checked at margin resolution.
"""
from decimal import Context,Decimal as D,localcontext

TIME_RESOLUTION_MS=D('1e-24')
MARGIN_RESOLUTION=D('1e-18')


def first_nonnegative(value,slope_bounds,begin,end,*,precision=50):
    if type(precision) is not int or precision<40:raise ValueError('Escape precision must be at least 40')
    with localcontext(Context(prec=precision)):
        if not begin.is_finite() or not end.is_finite() or begin<0 or end<begin:
            raise ValueError('Escape interval must use increasing nonnegative finite clocks')
        first,last=value(begin),value(end)
        if first>=0:return begin
        pending=[(begin,end,first,last)];work=0
        while pending:
            a,b,fa,fb=pending.pop();work+=1
            if work>30000:raise ArithmeticError('Escape isolation exceeded its work bound')
            if fa>=0:return a
            low,high=slope_bounds(a,b)
            if low>high or not low.is_finite() or not high.is_finite():raise ValueError('Invalid escape slope bounds')
            width=b-a
            upper=min(fa+max(D(0),high)*width,fb+max(D(0),-low)*width)
            if upper<0:continue
            if width<=TIME_RESOLUTION_MS:
                if fb>=0 or max(fa,fb)>=-MARGIN_RESOLUTION:return b
                raise ArithmeticError('Escape trajectory is unresolved at clock resolution')
            middle=(a+b)/2;fm=value(middle)
            # Left interval is visited first even with two crossings hidden
            # inside a cell whose endpoint margins are both negative.
            pending.append((middle,b,fm,fb));pending.append((a,middle,fa,fm))
        return None
