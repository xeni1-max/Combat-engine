"""One weighted velocity projection for an entire equality-constraint graph.

The grapple source gives the two-body weighted mean. Its delegated graph
extension projects all connected participants together, independently of edge
order. This is an instantaneous calculation, not a persistent link controller.
"""
from dataclasses import dataclass
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F

from combat_sim.mechanics.status import body_status_weight
from combat_sim.models import as_fraction


def number(value,*,positive=False):
    try:
        if isinstance(value,bool):raise ValueError
        value=as_fraction(value)
        if value<0 or positive and value==0:raise ValueError
        return value
    except (TypeError,ValueError,ArithmeticError) as error:
        raise ValueError('Projection weight inputs must be finite and nonnegative') from error


def vector(value):
    try:
        if not isinstance(value,(tuple,list)) or len(value)!=3 or any(isinstance(x,bool) for x in value):raise ValueError
        return tuple(as_fraction(x) for x in value)
    except (TypeError,ValueError,ArithmeticError) as error:
        raise ValueError('Velocity and normal vectors need three finite coordinates') from error


@dataclass(frozen=True)
class VelocityNode:
    identity: str
    velocity_mps: tuple
    maximum_hp: F
    armor: F

    def __post_init__(self):
        if not isinstance(self.identity,str) or not self.identity:raise ValueError('Projection node needs an identity')
        object.__setattr__(self,'velocity_mps',vector(self.velocity_mps))
        object.__setattr__(self,'maximum_hp',number(self.maximum_hp,positive=True))
        object.__setattr__(self,'armor',number(self.armor))


@dataclass(frozen=True)
class VelocityEquality:
    first: str
    second: str


@dataclass(frozen=True)
class BlockedDirection:
    actor: str
    normal: tuple

    def __post_init__(self):
        value=vector(self.normal)
        if not any(value):raise ValueError('Blocked direction cannot be zero')
        object.__setattr__(self,'normal',value)


@dataclass(frozen=True)
class VelocityProjection:
    velocities: tuple[tuple[str,tuple[D,...]],...]
    weights: tuple[tuple[str,D],...]
    components: tuple[tuple[str,...],...]
    precision: int

    def record(self):
        return {'velocities_mps':dict(self.velocities),'weights':dict(self.weights),
            'components':self.components,'precision':self.precision}


def project_velocities(nodes,equalities=(),blocked=(),*,precision=50):
    if type(precision) is not int or precision<40:raise ValueError('Projection precision must be at least 40')
    nodes=tuple(nodes);equalities=tuple(equalities);blocked=tuple(blocked)
    if any(not isinstance(n,VelocityNode) for n in nodes):raise ValueError('Projection needs typed velocity nodes')
    by_id={n.identity:n for n in nodes}
    if len(by_id)!=len(nodes):raise ValueError('Projection node identities must be unique')
    graph={name:set() for name in by_id}
    for edge in equalities:
        if (not isinstance(edge,VelocityEquality) or edge.first not in graph or edge.second not in graph
                or edge.first==edge.second):raise ValueError('Velocity equality needs two distinct existing nodes')
        graph[edge.first].add(edge.second);graph[edge.second].add(edge.first)
    for constraint in blocked:
        if not isinstance(constraint,BlockedDirection) or constraint.actor not in graph:
            raise ValueError('Blocked direction needs an existing node')
    weights={name:body_status_weight(n.maximum_hp,n.armor) for name,n in sorted(by_id.items())}
    components=[];pending=set(graph)
    while pending:
        frontier=[min(pending)];group=set()
        while frontier:
            name=frontier.pop()
            if name in group:continue
            group.add(name);frontier.extend(graph[name]-group)
        pending-=group;components.append(tuple(sorted(group)))
    output={}
    with localcontext(Context(prec=precision)):
        decimal=lambda x:D(x.numerator)/D(x.denominator)
        for group in components:
            total=sum((as_fraction(weights[name]) for name in group),F(0))
            value=tuple(sum((as_fraction(weights[name])*by_id[name].velocity_mps[i]
                for name in group),F(0))/total for i in range(3))
            # Exact rational orthogonalization avoids order-dependent pair
            # updates, square roots, duplicated rows and singular systems.
            basis=[]
            for normal in sorted({c.normal for c in blocked if c.actor in group}):
                direction=normal
                for previous in basis:
                    factor=sum(a*b for a,b in zip(direction,previous))/sum(x*x for x in previous)
                    direction=tuple(a-factor*b for a,b in zip(direction,previous))
                if any(direction):basis.append(direction)
            for direction in basis:
                factor=sum(a*b for a,b in zip(value,direction))/sum(x*x for x in direction)
                value=tuple(a-factor*b for a,b in zip(value,direction))
            for name in group:output[name]=tuple(decimal(x) for x in value)
    return VelocityProjection(tuple(sorted(output.items())),tuple(weights.items()),tuple(components),precision)
