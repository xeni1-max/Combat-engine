"""Straight-line hand Recovery with parallel required-hand movements."""
from decimal import Decimal as D
from math import isqrt

from combat_sim.models import as_fraction


def hand_recovery(current_hands, required_hands, value_ms_per_m):
    """Return per-hand calculations and exact upward-rounded total milliseconds.

    All required hands start moving together. Required hand times overlap, so
    the longest controls Gathering eligibility. Squared rational arithmetic
    determines the ceiling without rounding a nearly integral square root.
    The caller supplies its fixed Decimal context for displayed distances.
    """
    value = as_fraction(value_ms_per_m)
    if value < 0 or not required_hands:
        raise ValueError('Recovery requires nonnegative ms/m and explicit hand poses')
    calculations, maximum_squared = {}, as_fraction(0)
    for hand, destination in required_hands.items():
        if hand not in current_hands:
            raise ValueError(f'Missing current position for required hand: {hand}')
        origin = current_hands[hand]
        if len(origin) != 3 or len(destination) != 3:
            raise ValueError('Hand positions require three coordinates')
        squared = sum(((as_fraction(b)-as_fraction(a))**2 for a, b in zip(origin, destination)), as_fraction(0))
        squared_time = squared * value**2
        maximum_squared = max(maximum_squared, squared_time)
        distance = (D(squared.numerator)/D(squared.denominator)).sqrt()
        calculations[hand] = {'start_m': list(origin), 'required_m': list(destination),
                              'distance_m': distance,
                              'duration_ms': distance*D(value.numerator)/D(value.denominator)}
    whole = isqrt(maximum_squared.numerator // maximum_squared.denominator)
    if whole**2 * maximum_squared.denominator < maximum_squared.numerator:
        whole += 1
    return whole, calculations
