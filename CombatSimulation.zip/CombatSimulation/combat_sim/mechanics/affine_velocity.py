"""Certified origin-feasible affine velocity projection.

Finite distance steps introduce nonzero bounds. Their dual active sets can
contain a newly violated direction dependent on existing directions, unlike
the homogeneous problem. An exact multiplier pivot handles that case.
"""
from dataclasses import dataclass
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F

from combat_sim.mechanics.status import body_status_weight
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality,BlockedDirection,number,vector
from combat_sim.mechanics.unilateral_velocity import _solve
from combat_sim.models import as_fraction
from combat_sim.mechanics.exact_ratio import ratio_text


@dataclass(frozen=True)
class VelocityLimit:
    terms: tuple
    bound: F

    def __post_init__(self):
        terms=tuple((name,vector(normal)) for name,normal in self.terms)
        if not terms or any(not isinstance(n,str) or not n for n,_ in terms):
            raise ValueError('A velocity limit needs named vector terms')
        object.__setattr__(self,'terms',terms)
        object.__setattr__(self,'bound',number(self.bound))


@dataclass(frozen=True)
class AffineProjection:
    velocities: tuple
    exact_velocities: tuple
    weights: tuple
    node_order: tuple
    rows: tuple
    bounds: tuple
    multipliers: tuple
    equality_basis: tuple
    pivots: int
    precision: int

    def record(self):
        ratios=lambda values:tuple(ratio_text(x) if isinstance(x,F) else str(x) for x in values)
        return {'velocities_mps':{n:ratios(v) for n,v in self.velocities},
            'exact_velocities_mps':{n:ratios(v) for n,v in self.exact_velocities},
            'weights':{n:ratio_text(w) for n,w in self.weights},'node_order':self.node_order,
            'constraint_rows':tuple(ratios(r) for r in self.rows),'bounds':ratios(self.bounds),
            'multipliers':ratios(self.multipliers),'equality_basis':tuple(ratios(r) for r in self.equality_basis),
            'dependent_direction_pivots':self.pivots,'precision':self.precision}


def dot(a,b):return sum((x*y for x,y in zip(a,b)),F(0))


def project_affine(nodes,limits=(),equalities=(),blocked=(),*,precision=50):
    """Minimize sum(weight*|v-u|²)/2 with A*v<=b and homogeneous equalities.

    Bounds must be nonnegative: zero velocity is feasible. This intentional
    contract supplies the feasibility needed by finite-distance path planners;
    it is not an arbitrary/infeasible affine-programming API.
    """
    if type(precision) is not int or precision<40:raise ValueError('Projection precision must be at least 40')
    nodes=tuple(nodes);limits=tuple(limits);equalities=tuple(equalities);blocked=tuple(blocked)
    if any(not isinstance(n,VelocityNode) for n in nodes):raise ValueError('Projection needs typed velocity nodes')
    by_id={n.identity:n for n in nodes};names=tuple(sorted(by_id));size=3*len(names)
    if len(by_id)!=len(nodes):raise ValueError('Projection node identities must be unique')
    offsets={n:3*i for i,n in enumerate(names)}
    weights={n:as_fraction(body_status_weight(by_id[n].maximum_hp,by_id[n].armor)) for n in names}
    mass=tuple(weights[n] for n in names for _ in range(3))
    wanted=tuple(v for n in names for v in by_id[n].velocity_mps)

    def row(terms):
        result=[F(0)]*size
        for name,normal in terms:
            if name not in offsets:raise ValueError('A constraint needs existing nodes')
            for axis,x in enumerate(normal):result[offsets[name]+axis]+=x
        return tuple(result)

    bilateral=[]
    for edge in equalities:
        if not isinstance(edge,VelocityEquality) or edge.first==edge.second:
            raise ValueError('An equality needs distinct existing nodes')
        for axis in range(3):
            n=tuple(F(i==axis) for i in range(3))
            bilateral.append(row(((edge.first,n),(edge.second,tuple(-x for x in n)))))
    for edge in blocked:
        if not isinstance(edge,BlockedDirection):raise ValueError('Expected a typed blocked direction')
        bilateral.append(row(((edge.actor,edge.normal),)))

    def canonical(values,signed):
        first=next((x for x in values if x),None)
        if first is None:return values,F(1)
        scale=first if signed else abs(first)
        return tuple(x/scale for x in values),scale

    inequalities={}
    for limit in limits:
        if not isinstance(limit,VelocityLimit):raise ValueError('Expected a typed velocity limit')
        values,scale=canonical(row(limit.terms),False)
        if not any(values):continue
        bound=limit.bound/scale
        inequalities[values]=min(inequalities.get(values,bound),bound)
    rows=tuple(sorted(inequalities));bounds=tuple(inequalities[r] for r in rows)
    basis=[]
    def weighted(a,b):return sum((m*x*y for m,x,y in zip(mass,a,b)),F(0))
    def nullspace(direction):
        for prior in basis:
            scale=weighted(direction,prior)/weighted(prior,prior)
            direction=tuple(x-scale*y for x,y in zip(direction,prior))
        return direction
    for values in sorted({canonical(v,True)[0] for v in bilateral}):
        direction=nullspace(tuple(x/m for x,m in zip(values,mass)))
        if any(direction):basis.append(direction)
    base=nullspace(wanted)
    directions=tuple(nullspace(tuple(x/m for x,m in zip(r,mass))) for r in rows)
    gram=tuple(tuple(weighted(a,b) for b in directions) for a in directions)
    rhs=tuple(dot(r,base)-b for r,b in zip(rows,bounds))
    multipliers=[F(0)]*len(rows);active=[];steps=0;pivots=0

    def tick():
        nonlocal steps
        steps+=1
        if steps>max(1000,8*len(rows)**2):raise ArithmeticError('Affine projection active set did not converge')

    while True:
        violation=tuple(q-sum((gram[i][j]*multipliers[j] for j in active),F(0)) for i,q in enumerate(rhs))
        entering=next((i for i,v in enumerate(violation) if i not in active and v>0),None)
        if entering is None:break
        tick()
        if active:
            matrix=tuple(tuple(gram[i][j] for j in active) for i in active)
            combination=_solve(matrix,tuple(gram[i][entering] for i in active))
            residual=gram[entering][entering]-sum((x*gram[i][entering] for i,x in zip(active,combination)),F(0))
            if residual<0:raise ArithmeticError('Negative exact affine Gram residual')
            if not residual:
                # Keep the primal fixed while transferring dual weight to the
                # tighter dependent row. A positive coefficient must exist:
                # all b>=0 and a violated dependent row rule out the opposite.
                leaving=[multipliers[i]/x for i,x in zip(active,combination) if x>0]
                if not leaving:raise ArithmeticError('Origin-feasible affine constraints lost feasibility')
                step=min(leaving);multipliers[entering]=step
                for i,x in zip(active,combination):multipliers[i]-=step*x
                active=[i for i in active if multipliers[i]>0];pivots+=1
        elif not gram[entering][entering]:
            raise ArithmeticError('A null inequality cannot violate an origin-feasible problem')
        active.append(entering);active.sort()
        while True:
            tick()
            trial=_solve(tuple(tuple(gram[i][j] for j in active) for i in active),tuple(rhs[i] for i in active))
            if all(x>=0 for x in trial):
                for i,x in zip(active,trial):multipliers[i]=x
                active=[i for i in active if multipliers[i]>0]
                break
            alpha=min(multipliers[i]/(multipliers[i]-x) for i,x in zip(active,trial) if x<0)
            for i,x in zip(active,trial):multipliers[i]+=alpha*(x-multipliers[i])
            active=[i for i in active if multipliers[i]>0]

    value=tuple(u-sum((multipliers[i]*directions[i][axis] for i in active),F(0)) for axis,u in enumerate(base))
    residuals=tuple(dot(r,value)-b for r,b in zip(rows,bounds))
    if (any(dot(r,value) for r in bilateral) or any(x>0 for x in residuals) or
            any(x<0 for x in multipliers) or any(x*y for x,y in zip(multipliers,residuals))):
        raise ArithmeticError('Affine projection failed its exact certificate')
    exact=tuple((n,value[offsets[n]:offsets[n]+3]) for n in names)
    with localcontext(Context(prec=precision)):
        output=tuple((n,tuple(D(x.numerator)/D(x.denominator) for x in v)) for n,v in exact)
    return AffineProjection(output,exact,tuple(weights.items()),names,rows,bounds,tuple(multipliers),tuple(basis),pivots,precision)
