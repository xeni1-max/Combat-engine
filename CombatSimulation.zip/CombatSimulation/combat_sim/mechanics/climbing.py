"""Origin-to-surface climb eligibility and author-approved up/across path."""
from dataclasses import dataclass
from decimal import Decimal as D, Context, ROUND_HALF_EVEN, localcontext

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import as_fraction
from combat_sim.oriented_geometry import OrientedCuboid


def surface_distance_squared(origin_m,box):
    if isinstance(box,OrientedCuboid):return surface_distance_squared(box.frame.to_local_point(origin_m,box.centre_m),box.local_box)
    point=tuple(as_fraction(v) for v in origin_m)
    if len(point)!=3:raise ValueError('Climb range origin requires xyz')
    low,high=box.bounds
    outside=sum((max(a-p,p-b,0)**2 for p,a,b in zip(point,low,high)),as_fraction(0))
    if outside:return outside
    return min(min(p-a,b-p)**2 for p,a,b in zip(point,low,high))


def within_climb_range(origin_m,box,distance_m):
    distance=as_fraction(distance_m)
    if distance<0:raise ValueError('Climb activation distance must be nonnegative')
    return surface_distance_squared(origin_m,box)<=distance**2


@dataclass(frozen=True)
class ClimbState:
    position_m: tuple
    velocity_mps: tuple
    stage: str


class ClimbPath:
    """Rise until feet reach top, then move to top centre at constant speed.

    Uses an explicitly supplied body-origin-to-feet offset. Exact corner/end
    timestamps are path boundaries; no animation or arbitrary halfway split.
    """
    def __init__(self,origin_m,box,body_origin_above_feet_m,duration_ms,*,precision=50):
        if not isinstance(precision,int) or precision<40:raise ValueError('Climb precision must be at least 40')
        self.precision=precision
        with localcontext(Context(prec=precision,rounding=ROUND_HALF_EVEN)):
            self.origin=tuple(dec(v) for v in origin_m)
            if len(self.origin)!=3:raise ValueError('Climb origin requires xyz')
            self.duration=dec(duration_ms)
            offset=dec(body_origin_above_feet_m)
            if self.duration<=0 or offset<=0:raise ValueError('Climb duration and body offset must be positive')
            self.top_z=dec(box.bounds[1][2])
            self.target=(dec(box.centre_m[0]),dec(box.centre_m[1]),self.top_z+offset)
            self.rise=self.target[2]-self.origin[2]
            if self.rise<0:raise ValueError('Climb path cannot lower the feet onto the target')
            self.delta_xy=tuple(b-a for a,b in zip(self.origin[:2],self.target[:2]))
            self.horizontal_length=sum(v*v for v in self.delta_xy).sqrt()
            self.length=self.rise+self.horizontal_length
            if not self.length:raise ValueError('Climb origin is already at its destination')
            self.speed=self.length/(self.duration/1000)
            self.corner_ms=self.duration*self.rise/self.length

    def at(self,elapsed_ms):
        with localcontext(Context(prec=self.precision,rounding=ROUND_HALF_EVEN)):
            t=dec(elapsed_ms)
            if not 0<=t<=self.duration:raise ValueError('Time is outside climb Active')
            if t==self.duration:return ClimbState(self.target,(D(0),)*3,'complete')
            if t<self.corner_ms:
                return ClimbState((*self.origin[:2],self.origin[2]+self.speed*t/1000),
                                  (D(0),D(0),self.speed),'up')
            if not self.horizontal_length:
                return ClimbState(self.target,(D(0),)*3,'complete')
            u=(t-self.corner_ms)/(self.duration-self.corner_ms)
            xy=tuple(a+d*u for a,d in zip(self.origin[:2],self.delta_xy))
            v=tuple(d/self.horizontal_length*self.speed for d in self.delta_xy)
            return ClimbState((*xy,self.target[2]),(*v,D(0)),'across')
