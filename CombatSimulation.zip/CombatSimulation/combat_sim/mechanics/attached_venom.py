"""A wound's frozen delivery and the authored attached/residual toxin clocks."""
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.venom import venom_delivery_ratio
from combat_sim.world_colliders import finite


def delivery_ratio(damage_after_shield,armor,piercing):
    return dec(venom_delivery_ratio(damage_after_shield,armor,piercing))


def coefficient(delivery,toxicity,piercing,toxin_resistance):
    delivery=finite(delivery,'Wound delivery')
    toxicity=finite(toxicity,'Toxicity',positive=True)
    piercing=finite(piercing,'Piercing');resistance=finite(toxin_resistance,'Toxin resistance')
    if delivery>1:raise ValueError('Delivery cannot exceed one')
    adjusted=max(D(0),resistance-piercing/5)
    return delivery*max(D(0),(toxicity*toxicity-10*adjusted*adjusted)/toxicity)


def exposure_segment(start,detach,begin):
    """Affine q reference for one exposure or residual interval, in seconds."""
    return (D(0),start,D(1)) if begin<detach else ((detach-start)/1000,detach,D(-1))
