"""Pure dyspnea calculations from the primary Dyspnea details document."""

from dataclasses import dataclass
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from fractions import Fraction

from combat_sim.mechanics.status import apply_self_status
from combat_sim.models import UnsupportedMechanicError, as_fraction


SOURCE = "Dyspnea details.odt, revised recovery rules; user action/cap clarifications"
MAX_DYSPNEA = Fraction(100)
MAXIMUM_DYSPNEA_DISORIENTATION = Fraction(200)
CONTINUOUS_DYSPNEA_PRECISION = 50
CONTINUOUS_CONTEXT = Context(prec=CONTINUOUS_DYSPNEA_PRECISION, rounding=ROUND_HALF_EVEN)


@dataclass(frozen=True)
class DyspneaContext:
    """Known movement and recovery blockers during one unchanged interval.

    Callers must split intervals at movement/phase changes and status expiry.
    A positive disorientation/instability state sets its corresponding flag.
    """

    movement: str
    disoriented: bool = False
    unstable: bool = False
    on_grapple_ability: bool = False
    active: bool = False
    gathering: bool = False
    recovering: bool = False


def dyspnea_loss_rate(context: DyspneaContext) -> Fraction:
    """Recovery blockers override walking/stationary 30/s or running 18/s."""
    rates = {"stationary": 30, "walking": 30, "running": 18, "sprinting": 0, "airborne": 0}
    blockers = (
        context.disoriented, context.unstable, context.on_grapple_ability,
        context.active, context.gathering, context.recovering,
    )
    if any(not isinstance(value, bool) for value in blockers):
        raise ValueError("Dyspnea recovery blockers must be boolean flags")
    if any(blockers):
        return Fraction(0)
    if context.movement not in rates:
        raise ValueError("Dyspnea movement must be stationary, walking, running, sprinting, or airborne when recovery is unblocked")
    return Fraction(rates[context.movement])


@dataclass(frozen=True)
class ActionDyspneaTransition:
    allowed: bool
    before: Fraction
    available_capacity: Fraction
    action_value: Fraction
    after: Fraction
    reached_maximum: bool
    disorientation_trigger: Fraction


@dataclass(frozen=True)
class ContinuousDyspneaTransition:
    before: Fraction
    after: Decimal
    base_rate_per_second: Fraction
    elapsed_ms: Fraction
    loss_rate_per_second: Fraction
    context: DyspneaContext
    reached_maximum: bool
    disorientation_trigger: Fraction


def action_dyspnea_value(base_value: Fraction, current_dyspnea: Fraction) -> Fraction:
    """Calculate Da = (Db + D/100)^2 for one action."""
    base = as_fraction(base_value)
    current = _validate_current(current_dyspnea)
    if base < 0:
        raise ValueError("Base action dyspnea must be nonnegative")
    return (base + current / 100) ** 2


def continuous_action_dyspnea_rate(
    base_rate_per_second: Fraction,
    current_dyspnea: Fraction,
) -> Fraction:
    """Calculate Dc = (Dd + D/100)^2 for a continuous action."""
    base_rate = as_fraction(base_rate_per_second)
    current = _validate_current(current_dyspnea)
    if base_rate < 0:
        raise ValueError("Base continuous dyspnea rate must be nonnegative")
    return (base_rate + current / 100) ** 2


def net_continuous_action_dyspnea_rate(
    base_rate_per_second: Fraction,
    current_dyspnea: Fraction,
    *,
    context: DyspneaContext,
) -> Fraction:
    """Return the current action gain minus context-dependent recovery.

    This is the instantaneous net rate. Callers simulating an action over time
    must recalculate it as D changes.
    """
    return continuous_action_dyspnea_rate(base_rate_per_second, current_dyspnea) - dyspnea_loss_rate(context)


def apply_action_dyspnea(
    current_dyspnea: Fraction,
    base_value: Fraction,
) -> ActionDyspneaTransition:
    """Check an action's available bar space, then add Da when it can happen."""
    current = _validate_current(current_dyspnea)
    value = action_dyspnea_value(base_value, current)
    available = MAX_DYSPNEA - current
    if value > available:
        return ActionDyspneaTransition(
            allowed=False,
            before=current,
            available_capacity=available,
            action_value=value,
            after=current,
            reached_maximum=False,
            disorientation_trigger=Fraction(0),
        )

    after = current + value
    reached_maximum = current < MAX_DYSPNEA and after == MAX_DYSPNEA
    return ActionDyspneaTransition(
        allowed=True,
        before=current,
        available_capacity=available,
        action_value=value,
        after=after,
        reached_maximum=reached_maximum,
        disorientation_trigger=(
            MAXIMUM_DYSPNEA_DISORIENTATION if reached_maximum else Fraction(0)
        ),
    )


def validate_action_dyspnea_rule(rule):
    """Validate a deferred-payment rule and return its anchor or exemption."""
    if rule.get('kind')=='none':
        return None
    if rule.get('kind')!='action':
        raise UnsupportedMechanicError('Action dyspnea requires an explicit action cost or exemption')
    anchor=rule.get('payment_timing')
    if anchor not in ('active_start','active_firing_end'):
        raise UnsupportedMechanicError('Action dyspnea payment timing remains unspecified')
    if rule.get('capacity_check_timing')!=anchor:
        raise UnsupportedMechanicError('Separate capacity-check/payment timing is not defined for this subset')
    return anchor


def apply_action_dyspnea_at_phase(
    current_dyspnea, rule, phase, *, cancelled_before_payment=False,
) -> ActionDyspneaTransition | None:
    """Calculate/check/pay a recorded action cost only at its authored phase.

    Return None when no payment occurs. Beam's explicit exemption never runs
    the action formula with Db=0. A death cancellation before the payment event
    incurs no cost. This helper does not schedule phases, release a projectile,
    refund prior payments, or define a failed payment's effect on firing.
    The current confirmed subset checks capacity at its payment phase.
    """
    _validate_current(current_dyspnea)
    if not isinstance(cancelled_before_payment, bool):
        raise ValueError('Cancellation must be a boolean flag')
    if cancelled_before_payment:
        return None
    anchor=validate_action_dyspnea_rule(rule)
    if anchor is None:
        return None
    if phase != anchor:
        return None
    return apply_action_dyspnea(current_dyspnea, rule['base_value'])


def apply_maximum_dyspnea_disorientation(
    current_disorientation: Fraction | Decimal,
    *,
    is_running_at_application: bool = False,
) -> Decimal:
    """Add the unmitigated 200 self trigger, including running if applicable.

    Defenses do not reduce self effects. This helper does not schedule the
    encounter trigger or decide when the dyspnea threshold is crossed.
    """
    return apply_self_status(
        current_disorientation,
        MAXIMUM_DYSPNEA_DISORIENTATION,
        is_running_at_application=is_running_at_application,
    )


def advance_continuous_action_dyspnea(
    current_dyspnea: Fraction | Decimal,
    base_rate_per_second: Fraction | Decimal,
    elapsed_ms: int | Fraction,
    *,
    context: DyspneaContext,
) -> ContinuousDyspneaTransition:
    """Advance D under Dc(D) minus recovery for an unchanged context.

    Treating the documented current-D formula as an instantaneous rate gives
    dD/dt = (Dd + D/100)^2 - L, where L is the context's recovery rate.
    The closed-form solution uses 50-digit Decimal precision. Callers split
    at context changes; no simulation tick or status lifetime is assumed.
    Crossing 100 from below emits one 200-disorientation trigger.
    """
    before = _validate_current(current_dyspnea)
    base = as_fraction(base_rate_per_second)
    elapsed = as_fraction(elapsed_ms)
    loss_rate = dyspnea_loss_rate(context)
    if base < 0:
        raise ValueError("Base continuous dyspnea rate must be nonnegative")
    if elapsed < 0:
        raise ValueError("Elapsed time must be nonnegative")

    with localcontext(CONTINUOUS_CONTEXT):
        d = _decimal_fraction(before)
        dd = _decimal_fraction(base)
        seconds = _decimal_fraction(elapsed) / Decimal(1000)
        loss = _decimal_fraction(loss_rate)
        x0 = dd + d / Decimal(100)
        reached_maximum = False

        if seconds == 0:
            result = d
        elif d == Decimal(100) and x0**2 >= loss:
            # Already capped; avoid evolving past a later mathematical pole.
            result = Decimal(100)
        elif loss == 0:
            if x0 == 0:
                result = d
            else:
                time_to_max = Decimal(100) * (Decimal(1) / x0 - Decimal(1) / (dd + 1))
                if seconds >= time_to_max:
                    result = Decimal(100)
                    reached_maximum = True
                else:
                    x = x0 / (Decimal(1) - x0 * seconds / Decimal(100))
                    result = Decimal(100) * (x - dd)
        else:
            root = loss.sqrt()
            result, reached_maximum = _advance_with_positive_loss(d, dd, x0, root, seconds)

        result = min(Decimal(100), max(Decimal(0), result))
        return ContinuousDyspneaTransition(
            before=before,
            after=+result,
            base_rate_per_second=base,
            elapsed_ms=elapsed,
            loss_rate_per_second=loss_rate,
            context=context,
            reached_maximum=reached_maximum,
            disorientation_trigger=(
                MAXIMUM_DYSPNEA_DISORIENTATION if reached_maximum else Fraction(0)
            ),
        )


def _advance_with_positive_loss(
    d: Decimal, dd: Decimal, x0: Decimal, root: Decimal, seconds: Decimal,
) -> tuple[Decimal, bool]:
    if x0 == root:
        return d, False
    q0 = (x0 - root) / (x0 + root)
    if x0 > root:
        x_max = dd + Decimal(1)
        q_max = (x_max - root) / (x_max + root)
        time_to_max = Decimal(50) / root * (q_max / q0).ln()
        if seconds >= time_to_max:
            return Decimal(100), True
    else:
        if d == 0:
            return Decimal(0), False
        q_zero = (dd - root) / (dd + root)
        time_to_zero = Decimal(50) / root * (q_zero / q0).ln()
        if seconds >= time_to_zero:
            return Decimal(0), False
    q = q0 * (Decimal(2) * root * seconds / Decimal(100)).exp()
    x = root * (Decimal(1) + q) / (Decimal(1) - q)
    return Decimal(100) * (x - dd), False


def decay_dyspnea(
    current_dyspnea: Fraction, elapsed_ms: int | Fraction, *, context: DyspneaContext,
) -> Fraction:
    """Apply the recovery rate for one unchanged context, floored at zero."""
    current = _validate_current(current_dyspnea)
    elapsed = as_fraction(elapsed_ms)
    if elapsed < 0:
        raise ValueError("Elapsed time must be nonnegative")
    return max(Fraction(0), current - dyspnea_loss_rate(context) * elapsed / 1000)


def _validate_current(value: Fraction) -> Fraction:
    current = as_fraction(value)
    if current < 0 or current > MAX_DYSPNEA:
        raise ValueError("Current dyspnea must be between 0 and 100")
    return current


def _decimal_fraction(value: Fraction) -> Decimal:
    return Decimal(value.numerator) / Decimal(value.denominator)
