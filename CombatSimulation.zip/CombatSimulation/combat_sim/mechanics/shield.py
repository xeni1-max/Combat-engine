"""Shield-layer rules clarified by the user."""

from fractions import Fraction
from typing import Iterable

from combat_sim.models import as_fraction


SOURCE = "user clarification in current conversation"


def split_damage(incoming_damage: Fraction, current_shield: Fraction) -> tuple[Fraction, Fraction]:
    """Return raw damage absorbed by shield and the raw amount left for HP."""
    damage = as_fraction(incoming_damage)
    shield = as_fraction(current_shield)
    if damage < 0:
        raise ValueError("Incoming damage must be nonnegative")
    if shield < 0:
        raise ValueError("Current shield must be nonnegative")
    absorbed = min(damage, shield)
    return absorbed, damage - absorbed


def split_simultaneous_damage(
    incoming_damages: Iterable[Fraction], current_shield: Fraction, *, shielding_ignored=None,
) -> tuple[tuple[Fraction, Fraction], ...]:
    """Split one shield across simultaneous hits in proportion to raw damage.

    Author clarification, stationary 2v2: if their combined damage breaks a
    shield, each hit absorbs its raw-damage share of that shield. Return each
    hit's (shield absorption, pre-mitigation HP overflow), preserving input
    order. Defenses and armor loss are evaluated separately from one pre-hit
    snapshot; allocation does not select any event/phase ordering.
    """
    damages = tuple(as_fraction(value) for value in incoming_damages)
    shield = as_fraction(current_shield)
    if shield < 0 or any(damage < 0 for damage in damages):
        raise ValueError("Incoming damage and current shield must be nonnegative")
    if shielding_ignored is not None:
        ignored=tuple(map(as_fraction,shielding_ignored))
        if len(ignored)!=len(damages) or any(x<0 for x in ignored):
            raise ValueError('Shield bypass needs one nonnegative budget per packet')
        if any(ignored):
            # Each packet skips capacity, not damage or another packet's stock.
            # Redistribute proportional shares when a packet reaches its cap.
            caps=tuple(min(d,max(Fraction(0),shield-b)) for d,b in zip(damages,ignored))
            remaining=min(shield,sum(caps,Fraction(0)))
            shares=[Fraction(0)]*len(damages)
            active={i for i,c in enumerate(caps) if c}
            while remaining and active:
                weight=sum((damages[i] for i in active),Fraction(0))
                proposed={i:remaining*damages[i]/weight for i in active}
                capped={i for i in active if proposed[i]>=caps[i]}
                if not capped:
                    for i in active:shares[i]=proposed[i]
                    break
                for i in capped:shares[i]=caps[i];remaining-=caps[i]
                active-=capped
            return tuple((a,d-a) for d,a in zip(damages,shares))
    total = sum(damages, Fraction(0))
    if not total or total <= shield:
        return tuple((damage, Fraction(0)) for damage in damages)
    return tuple((damage * shield / total, damage * (total - shield) / total)
                 for damage in damages)


def regenerable_amount(
    shield_hp_lost: Fraction,
    rate_per_second: Fraction,
    elapsed_after_delay_ms: int | Fraction,
) -> Fraction:
    """Recover no more than the recorded loss, at the documented per-second rate."""
    lost = as_fraction(shield_hp_lost)
    rate = as_fraction(rate_per_second)
    elapsed = as_fraction(elapsed_after_delay_ms)
    if lost < 0 or rate < 0 or elapsed < 0:
        raise ValueError("Shield loss, regeneration rate, and elapsed time must be nonnegative")
    return min(lost, rate * elapsed / 1000)


def shared_regenerable_amount(
    eligible_losses: Iterable[Fraction],
    shared_rate_per_second: Fraction,
    elapsed_ms: int | Fraction,
) -> Fraction:
    """Calculate shield recovery under one shared rate for eligible losses."""
    losses = [as_fraction(loss) for loss in eligible_losses]
    rate = as_fraction(shared_rate_per_second)
    elapsed = as_fraction(elapsed_ms)
    if any(loss < 0 for loss in losses) or rate < 0 or elapsed < 0:
        raise ValueError("Shield losses, regeneration rate, and elapsed time must be nonnegative")
    return min(sum(losses, Fraction(0)), rate * elapsed / 1000)
