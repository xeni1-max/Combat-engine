"""Instant Qard damage from Damage types.odt; armor loss is explicitly zero."""

from fractions import Fraction

from combat_sim.models import as_fraction

SOURCE = "Damage types.odt, Qard, instant; user confirmation that Qard does not reduce armor"
FORMULA = "dq2 = max(0, (dq^2 - (a/2 + Rq)^2) / dq)"


def raw_post_mitigation_damage(damage, armor, resistance) -> Fraction:
    dq, a, rq = map(as_fraction, (damage, armor, resistance))
    if dq == 0:
        raise ValueError("Instant Qard formula is undefined for dq=0")
    if min(dq, a, rq) < 0:
        raise ValueError("Qard damage, armor, and resistance must be nonnegative")
    return (dq**2 - (a / 2 + rq)**2) / dq


def post_mitigation_damage(damage, armor, resistance) -> Fraction:
    return max(Fraction(0), raw_post_mitigation_damage(damage, armor, resistance))
