"""Source knock distance resistance with author-confirmed grapple stat sums.

This module calculates resistance/direction, not the ability's motion timing.
"""
from dataclasses import dataclass
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F

from combat_sim.mechanics.status import body_status_weight
from combat_sim.mechanics.velocity_projection import number,vector


@dataclass(frozen=True)
class KnockbackBody:
    actor: str
    maximum_hp: F
    armor: F

    def __post_init__(self):
        if not isinstance(self.actor,str) or not self.actor:raise ValueError('Knockback body needs an actor identity')
        object.__setattr__(self,'maximum_hp',number(self.maximum_hp,positive=True))
        object.__setattr__(self,'armor',number(self.armor))


@dataclass(frozen=True)
class KnockbackDistance:
    actors: tuple[str,...]
    nominal_m: F
    maximum_hp_sum: F
    armor_sum: F
    resistance_m: D
    resisted_m: D
    precision: int

    def record(self):return dict(self.__dict__)


def resist_knockback(nominal_m,bodies,*,precision=50):
    if type(precision) is not int or precision<40:raise ValueError('Knockback precision must be at least 40')
    nominal=number(nominal_m);bodies=tuple(bodies)
    if not bodies or any(not isinstance(b,KnockbackBody) for b in bodies):raise ValueError('Knockback needs typed bodies')
    if len({b.actor for b in bodies})!=len(bodies):raise ValueError('Count each knocked actor once')
    hp=sum((b.maximum_hp for b in bodies),F(0));armor=sum((b.armor for b in bodies),F(0))
    with localcontext(Context(prec=precision)):
        resistance=body_status_weight(hp,armor)/150
        distance=max(D(0),D(nominal.numerator)/D(nominal.denominator)-resistance)
    return KnockbackDistance(tuple(sorted(b.actor for b in bodies)),nominal,hp,armor,resistance,distance,precision)


def knock_direction(kind,away=None,*,precision=50):
    if type(precision) is not int or precision<40:raise ValueError('Knockback precision must be at least 40')
    if not isinstance(kind,str):raise ValueError('Unknown knock direction')
    key=kind.strip().lower().replace('-','_').replace(' ','_')
    if key in ('knock_up','knockup'):return D(0),D(0),D(1)
    if key in ('knock_down','knockdown'):return D(0),D(0),D(-1)
    if key not in ('knockback','knock_back','knock_away','knockaway'):raise ValueError('Unknown knock direction')
    value=vector(away)
    if not any(value):raise ValueError('Knock away needs a nonzero direction')
    with localcontext(Context(prec=precision)):
        values=tuple(D(v.numerator)/D(v.denominator) for v in value)
        length=sum(v*v for v in values).sqrt()
        return tuple(v/length for v in values)
