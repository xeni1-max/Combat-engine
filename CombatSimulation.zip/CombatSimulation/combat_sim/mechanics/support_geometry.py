"""Vertical body-face witnesses and analytic loss of horizontal overlap.

This is contact geometry, not a second translation integrator or a character
ability. Callers retain gravity, collision response, poses and life ownership.
"""
from dataclasses import dataclass
from fractions import Fraction as F

from combat_sim.mechanics.velocity_projection import vector,number
from combat_sim.moving_projectiles import _roots,_evaluate
from combat_sim.oriented_geometry import OrientedCuboid,projected_size
from combat_sim.box_motion import axis_motions,footprint_overlap,value


@dataclass(frozen=True,order=True)
class SupportWitness:
    upper: str
    lower: str
    upper_part: str
    lower_part: str


def vertical_witnesses(bodies,*,distance_epsilon):
    """Positive-area underside/top-face contacts, independent of input order."""
    eps=number(distance_epsilon,positive=True);rows=[]
    for upper,parts in sorted(bodies.items()):
        for lower,other_parts in sorted(bodies.items()):
            if upper==lower:continue
            for first in parts:
                a,b=first.bounds
                for second in other_parts:
                    c,d=second.bounds
                    if abs(a[2]-d[2])>eps:continue
                    overlap=(footprint_overlap(first,second,distance_epsilon=eps)
                        if isinstance(first,OrientedCuboid) or isinstance(second,OrientedCuboid) else
                        all(min(b[i],d[i])-max(a[i],c[i])>eps for i in (0,1)))
                    if overlap:
                        rows.append(SupportWitness(upper,lower,first.part,second.part))
    return tuple(sorted(rows))


def static_witnesses(upper, parts, colliders, *, distance_epsilon):
    """Same positive-area contact rule for body undersides on static tops."""
    eps=number(distance_epsilon,positive=True);rows=[]
    for first in parts:
        low,high=first.bounds
        for lower,others in sorted(colliders.items()):
            for second in others:
                a,b=second.bounds
                if abs(low[2]-b[2])>eps:continue
                overlap=(footprint_overlap(first,second,distance_epsilon=eps)
                    if isinstance(first,OrientedCuboid) or isinstance(second,OrientedCuboid) else
                    all(min(high[i],b[i])-max(low[i],a[i])>eps for i in (0,1)))
                if overlap:
                    rows.append(SupportWitness(upper,lower,first.part,second.part))
    return tuple(sorted(rows))


def static_face_gaps(first, second, velocity, acceleration, *, size_rate=(0,0,0),
        size_acceleration=(0,0,0), distance_epsilon):
    """XY overlap and the shared vertical contact band on a quadratic pose."""
    eps=number(distance_epsilon,positive=True)
    v,a,s,q=map(vector,(velocity,acceleration,size_rate,size_acceleration))
    horizontal=horizontal_gap_polynomials(first,second,v,(0,0,0),a,(0,0,0),
        first_size_rate=s,first_size_acceleration=q)
    gap=first.bounds[0][2]-second.bounds[1][2]
    rate=v[2]-s[2]/2;change=(a[2]-q[2]/2)/2
    # first_overlap_departure subtracts eps from each opposing-face gap.
    return horizontal+((2*eps-gap,-rate,-change),(2*eps+gap,rate,change))


def first_overlap_departure(gaps,duration_s,*,distance_epsilon,time_epsilon_s=F(1,10**32)):
    """First loss of a positive XY overlap cell on quadratic face paths.

    Each gap is (constant, velocity, acceleration/2) for one opposing horizontal
    face pair. Returning an upper root bound crosses the selected contact band;
    returning a lower bound could repeatedly re-plan the same tiny prefix.
    """
    duration=number(duration_s);eps=number(distance_epsilon,positive=True)
    tolerance=number(time_epsilon_s,positive=True);departures=[]
    for values in gaps:
        p,v,a=vector(values);poly=(p-eps,v,a)
        if poly[0]<=0 and next((x for x in poly[1:] if x),F(0))<=0:return F(0)
        roots=_roots(poly,F(0),duration)
        for root in roots:
            while root.high-root.low>tolerance:root.refine()
        roots.sort(key=lambda r:r.low)
        for i,root in enumerate(roots):
            after=(root.high+(roots[i+1].low if i+1<len(roots) else duration))/2
            if after>root.high and _evaluate(poly,after)<0:
                departures.append(root.high);break
            if root.high==duration and _evaluate(poly,duration)==0:
                derivative=poly[1]+2*poly[2]*duration
                if derivative<0:departures.append(duration)
    return min(departures,default=None)


def horizontal_gap_polynomials(first,second,first_velocity,second_velocity,first_acceleration,second_acceleration,
        *,first_size_rate=(0,0,0),second_size_rate=(0,0,0),first_size_acceleration=(0,0,0),second_size_acceleration=(0,0,0)):
    """Four exact opposing-face gaps for the full quadratic XY interval."""
    va,vb,aa,ab,sa,sb,qa,qb=map(vector,(first_velocity,second_velocity,first_acceleration,second_acceleration,
        first_size_rate,second_size_rate,first_size_acceleration,second_size_acceleration))
    if isinstance(first,OrientedCuboid) or isinstance(second,OrientedCuboid):
        rows=[]
        for row in axis_motions(first,second,tuple(a-b for a,b in zip(va,vb)),tuple(a-b for a,b in zip(aa,ab)),
                first_size_rate=sa,second_size_rate=sb,first_size_acceleration=qa,second_size_acceleration=qb):
            if row.normal[2]:continue
            rows.extend(row.gaps())
            # Intersection width is the minimum of both opposing gaps and
            # the two own projected widths. Include deforming thin parts.
            for box,rate,change in ((first,sa,qa),(second,sb,qb)):
                rows.append((projected_size(box,row.normal),projected_size(box,row.normal,rate),
                    projected_size(box,row.normal,change)/2))
        return tuple(rows)
    lo,hi=first.bounds;low,high=second.bounds;rows=[]
    for axis in (0,1):
        rows.append((hi[axis]-low[axis],va[axis]-vb[axis]+(sa[axis]+sb[axis])/2,
            (aa[axis]-ab[axis])/2+(qa[axis]+qb[axis])/4))
        rows.append((high[axis]-lo[axis],vb[axis]-va[axis]+(sa[axis]+sb[axis])/2,
            (ab[axis]-aa[axis])/2+(qa[axis]+qb[axis])/4))
    return tuple(rows)


def grazing_vertical_departure(delta,half,relative_velocity,half_size_rate,*,distance_epsilon,speed_epsilon,
        relative_acceleration=(0,0,0),half_size_acceleration=(0,0,0),acceleration_epsilon=None):
    """A separating zero-area edge cannot establish another standing contact."""
    d,h,v,s=map(vector,(delta,half,relative_velocity,half_size_rate))
    eps=number(distance_epsilon,positive=True);speed=number(speed_epsilon,positive=True)
    a,q=map(vector,(relative_acceleration,half_size_acceleration))
    change=number(acceleration_epsilon,positive=True) if acceleration_epsilon is not None else None
    for i in (0,1):
        if h[i]-abs(d[i])>eps:continue
        sign=1 if d[i]>=0 else -1
        rate=s[i]-sign*v[i]
        if rate < -speed or (change is not None and abs(rate)<=speed and q[i]-sign*a[i]<-change):return True
    return False


def crosses_finite_sheet(box,sheet,*,distance_epsilon):
    """New occupancy crosses a finite zero-thickness sheet, beyond contact error."""
    eps=number(distance_epsilon,positive=True)
    low,high=box.bounds;a,b=sheet.bounds
    overlap=(footprint_overlap(box,sheet,distance_epsilon=eps) if isinstance(box,OrientedCuboid) else
        all(min(high[i],b[i])-max(low[i],a[i])>eps for i in (0,1)))
    return low[2]<a[2]-eps and high[2]>a[2]+eps and overlap


def grazing_projected_departure(rows,time,*,distance_epsilon,speed_epsilon,acceleration_epsilon):
    """The same separating contact-band rule on arbitrary footprint axes."""
    t=F(time);eps=number(distance_epsilon,positive=True);speed=number(speed_epsilon,positive=True)
    change=number(acceleration_epsilon,positive=True)
    for row in rows:
        if row.normal[2]:continue
        delta,half=value(row.delta,t),value(row.half,t)
        if half-abs(delta)>eps:continue
        sign=1 if delta>=0 else -1
        rate=row.half[1]+2*row.half[2]*t-sign*(row.delta[1]+2*row.delta[2]*t)
        acceleration=2*(row.half[2]-sign*row.delta[2])
        if rate < -speed or abs(rate)<=speed and acceleration < -change:return True
    return False
