"""Joint weighted velocity projection for taut distances and one-sided contact.

This is the instantaneous linear problem, not a tether trajectory/controller.
Rational arithmetic supplies an exact feasibility/complementarity certificate;
only the final public velocity presentation is rounded to owned precision.
"""
from dataclasses import dataclass
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F

from combat_sim.mechanics.status import body_status_weight
from combat_sim.mechanics.velocity_projection import VelocityNode, VelocityEquality, BlockedDirection, vector
from combat_sim.models import as_fraction
from combat_sim.mechanics.exact_ratio import ratio_text


@dataclass(frozen=True)
class TautDistance:
    first: str
    second: str
    toward_second: tuple

    def __post_init__(self):
        normal=vector(self.toward_second)
        if not any(normal):raise ValueError('A taut distance needs a nonzero radial direction')
        object.__setattr__(self,'toward_second',normal)


@dataclass(frozen=True)
class ContactLimit:
    actor: str
    toward_obstacle: tuple
    other: str | None = None

    def __post_init__(self):
        normal=vector(self.toward_obstacle)
        if not any(normal):raise ValueError('A contact limit needs a nonzero approach direction')
        if self.other is not None and (not isinstance(self.other,str) or not self.other or self.other==self.actor):
            raise ValueError('A relative contact needs a distinct named second body')
        object.__setattr__(self,'toward_obstacle',normal)


@dataclass(frozen=True)
class UnilateralProjection:
    velocities: tuple
    exact_velocities: tuple
    weights: tuple
    rows: tuple
    multipliers: tuple
    equality_basis: tuple
    precision: int

    def record(self):
        ratios=lambda values:tuple(ratio_text(v) for v in values)
        return {'velocities_mps':dict(self.velocities),
            'exact_velocities_mps':{name:ratios(v) for name,v in self.exact_velocities},
            'weights':{name:ratio_text(v) for name,v in self.weights},
            'constraint_rows':tuple(ratios(row) for row in self.rows),'multipliers':ratios(self.multipliers),
            'equality_basis':tuple(ratios(row) for row in self.equality_basis),'node_order':tuple(n for n,_ in self.velocities),
            'precision':self.precision}


def _dot(left,right):return sum((a*b for a,b in zip(left,right)),F(0))


def _solve(matrix,rhs):
    """Exact elimination; entering violated rows must add an independent direction."""
    size=len(rhs);a=[list(row)+[value] for row,value in zip(matrix,rhs)]
    for column in range(size):
        pivot=next((i for i in range(column,size) if a[i][column]),None)
        if pivot is None:raise ArithmeticError('Dependent active directions in unilateral projection')
        a[column],a[pivot]=a[pivot],a[column]
        scale=a[column][column];a[column]=[x/scale for x in a[column]]
        for i in range(size):
            if i==column:continue
            scale=a[i][column]
            if scale:a[i]=[x-scale*y for x,y in zip(a[i],a[column])]
    return tuple(row[-1] for row in a)


def project_unilateral(nodes,taut=(),contacts=(),equalities=(),blocked=(),*,precision=50):
    """Minimize sum(weight*|v-u|²)/2 with homogeneous equalities/inequalities.

    TautDistance constrains (v_second-v_first)·toward_second <= 0. A contact
    constrains v_actor·toward_obstacle <= 0, allowing departure. Existing
    BlockedDirection remains bilateral, as required by its original contract.
    Slack/taut activation, positions, curvature and friction belong to callers.
    """
    if type(precision) is not int or precision<40:raise ValueError('Projection precision must be at least 40')
    nodes=tuple(nodes);taut=tuple(taut);contacts=tuple(contacts)
    equalities=tuple(equalities);blocked=tuple(blocked)
    if any(not isinstance(n,VelocityNode) for n in nodes):raise ValueError('Projection needs typed velocity nodes')
    by_id={n.identity:n for n in nodes};names=tuple(sorted(by_id))
    if len(by_id)!=len(nodes):raise ValueError('Projection node identities must be unique')
    offsets={name:3*i for i,name in enumerate(names)};size=3*len(names)
    weights={name:as_fraction(body_status_weight(by_id[name].maximum_hp,by_id[name].armor)) for name in names}
    mass=tuple(weights[name] for name in names for _ in range(3))
    wanted=tuple(x for name in names for x in by_id[name].velocity_mps)
    bilateral=[];limits=[]

    def row(terms):
        values=[F(0)]*size
        for name,normal in terms:
            if name not in offsets:raise ValueError('A constraint needs existing nodes')
            for i,x in enumerate(normal):values[offsets[name]+i]+=x
        return tuple(values)

    for edge in equalities:
        if not isinstance(edge,VelocityEquality) or edge.first==edge.second:
            raise ValueError('An equality needs distinct existing nodes')
        for axis in range(3):
            normal=tuple(F(i==axis) for i in range(3))
            bilateral.append(row(((edge.first,normal),(edge.second,tuple(-x for x in normal)))))
    for edge in blocked:
        if not isinstance(edge,BlockedDirection):raise ValueError('Expected a typed blocked direction')
        bilateral.append(row(((edge.actor,edge.normal),)))
    for edge in taut:
        if not isinstance(edge,TautDistance) or edge.first==edge.second:
            raise ValueError('A taut distance needs distinct existing nodes')
        limits.append(row(((edge.first,tuple(-x for x in edge.toward_second)),(edge.second,edge.toward_second))))
    for edge in contacts:
        if not isinstance(edge,ContactLimit):raise ValueError('Expected a typed contact limit')
        terms=((edge.actor,edge.toward_obstacle),)
        if edge.other is not None:terms+=((edge.other,tuple(-x for x in edge.toward_obstacle)),)
        limits.append(row(terms))

    def canonical(values,*,signed):
        first=next((v for v in values if v),None)
        if first is None:return values
        scale=first if signed else abs(first)
        return tuple(v/scale for v in values)

    # Bilateral weighted orthogonalization is exact, including redundant cycles.
    basis=[]
    def weighted(left,right):return sum((m*a*b for m,a,b in zip(mass,left,right)),F(0))
    def nullspace(direction):
        for prior in basis:
            scale=weighted(direction,prior)/weighted(prior,prior)
            direction=tuple(a-scale*b for a,b in zip(direction,prior))
        return direction
    for values in sorted({canonical(v,signed=True) for v in bilateral}):
        direction=nullspace(tuple(v/m for v,m in zip(values,mass)))
        if any(direction):basis.append(direction)
    base=nullspace(wanted)
    rows=tuple(sorted({canonical(v,signed=False) for v in limits}))
    directions=tuple(nullspace(tuple(v/m for v,m in zip(values,mass))) for values in rows)
    gram=tuple(tuple(weighted(a,b) for b in directions) for a in directions)
    rhs=tuple(_dot(values,base) for values in rows)
    multipliers=[F(0)]*len(rows);active=[];steps=0
    # Exact nonnegative dual active set. Select first violated row canonically;
    # negative trial multipliers leave at the first nonnegative boundary.
    while True:
        violation=tuple(q-sum((gram[i][j]*multipliers[j] for j in active),F(0)) for i,q in enumerate(rhs))
        entering=next((i for i,v in enumerate(violation) if i not in active and v>0),None)
        if entering is None:break
        active.append(entering);active.sort()
        while True:
            steps+=1
            if steps>max(1000,4*len(rows)**2):raise ArithmeticError('Unilateral projection active set did not converge')
            trial=_solve(tuple(tuple(gram[i][j] for j in active) for i in active),tuple(rhs[i] for i in active))
            if all(v>0 for v in trial):
                for i,v in zip(active,trial):multipliers[i]=v
                break
            alpha=min(multipliers[i]/(multipliers[i]-v) for i,v in zip(active,trial) if v<=0)
            for i,v in zip(active,trial):multipliers[i]+=alpha*(v-multipliers[i])
            active=[i for i in active if multipliers[i]>0]
    value=tuple(u-sum((multipliers[i]*directions[i][axis] for i in active),F(0)) for axis,u in enumerate(base))
    # A failed certificate is a solver error, never permission to return a
    # merely plausible velocity or a sequential pair approximation.
    residuals=tuple(_dot(r,value) for r in rows)
    if (any(_dot(r,value) for r in bilateral) or any(v>0 for v in residuals) or
            any(v<0 for v in multipliers) or any(a*b for a,b in zip(multipliers,residuals))):
        raise ArithmeticError('Unilateral projection failed its exact certificate')
    exact=tuple((name,value[offsets[name]:offsets[name]+3]) for name in names)
    with localcontext(Context(prec=precision)):
        output=tuple((name,tuple(D(x.numerator)/D(x.denominator) for x in v)) for name,v in exact)
    return UnilateralProjection(output,exact,tuple(weights.items()),rows,tuple(multipliers),tuple(basis),precision)
