"""Saved actual-healing measures with fixed-precision rolling queries."""
from copy import deepcopy
from decimal import Context,Decimal as D,ROUND_HALF_EVEN,localcontext
from types import MappingProxyType

from combat_sim.mechanics.damage_ledger import dose_from_record
from combat_sim.mechanics.life import life_generation
from combat_sim.world_colliders import finite


class HealingHistory:
    @classmethod
    def from_record(cls,record):
        precision=record['precision']
        if type(precision) is not int or precision<40:raise ValueError('Healing history needs its stored precision')
        result=cls();result.context=Context(prec=precision,rounding=ROUND_HALF_EVEN)
        with localcontext(result.context):
            result.observed_until=finite(record['observed_until_ms'],'Healing observation bound')
            result.curves=MappingProxyType({key:dose_from_record(value) for key,value in record['curves'].items()})
            rows=[];ids=set()
            for value in record['entries']:
                row=deepcopy(value);identity=row['id'];actor=row['actor']
                if not isinstance(identity,str) or not identity or identity in ids or not isinstance(actor,str) or not actor:
                    raise ValueError('Invalid healing receipt identity')
                begin,end,amount,requested=map(lambda v:finite(v,'Stored healing'),
                    (row['begin_ms'],row['end_ms'],row['applied_healing_hp'],row['requested_hp']))
                if end<begin or end>result.observed_until or amount>requested+D('1e-8'):
                    raise ValueError('Invalid stored healing time or amount')
                if life_generation(row['recipient_life_generation']) is None:raise ValueError('Healing needs its recipient life')
                curve=result.curves.get(row['curve_id']);basis=row['curve_basis_hp']
                if row['curve_id'] is not None and curve is None:raise ValueError('Unknown healing curve identity')
                if amount and begin!=end:
                    basis=finite(basis,'Healing curve basis',positive=True)
                    if curve is None or abs(curve.integral(begin,end)-basis)>max(D('1e-8'),basis*D('1e-12')):
                        raise ValueError('Healing curve disagrees with its receipt')
                    if abs(amount-basis)>max(D('1e-8'),basis*D('1e-12')):
                        raise ValueError('Healing payout exceeds its numerical curve correction budget')
                elif curve is not None or basis is not None:raise ValueError('Only continuous paid healing has a curve')
                rows.append((row,begin,end,amount,basis,curve));ids.add(identity)
            result._rows=tuple(rows)
        return result

    @classmethod
    def from_run(cls,run):return cls.from_record(run['healing_history'])

    def amount(self,*,actor=None,end=None,window_ms=None,recipient_life_generation=None):
        with localcontext(self.context):
            time=self.observed_until if end is None else finite(end,'Healing query end')
            if time>self.observed_until:raise ValueError('Healing query exceeds observed time')
            width=None if window_ms is None else finite(window_ms,'Healing window',positive=True)
            first=D(-1) if width is None else time-width
            life_generation(recipient_life_generation);total=D(0)
            for row,begin,last,amount,basis,curve in self._rows:
                if actor is not None and actor!=row['actor']:continue
                if recipient_life_generation is not None and recipient_life_generation!=row['recipient_life_generation']:continue
                if not amount:continue
                if begin==last:
                    if first<last<=time:total+=amount
                else:
                    a,b=max(first,begin),min(time,last)
                    if b>a:total+=amount if a==begin and b==last else amount*curve.integral(a,b)/basis
            return total

    def record(self):
        return {'precision':self.context.prec,'observed_until_ms':self.observed_until,
            'curves':{key:curve.record() for key,curve in self.curves.items()},
            'entries':[deepcopy(row) for row,*_ in self._rows]}
