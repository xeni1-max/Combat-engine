"""Character effort is independent of weapon/effect lifetime and resource cost."""
from fractions import Fraction

from combat_sim.models import as_fraction


CATEGORIES = frozenset(('intrinsic_momentary', 'intrinsic_sustained',
                        'extrinsic_momentary', 'extrinsic_sustained'))


def output_after_instability(base, instability, category):
    """Return damage (momentary) or DPS (sustained), before target defenses.

    Collision details.odt: M=U/10 and M2=5U/20. Sampling and controlled
    interruption belong to the shared timeline, not this pure calculation.
    """
    if not isinstance(category, str) or category not in CATEGORIES:
        raise ValueError('Unknown character effort category')
    if isinstance(base, bool) or isinstance(instability, bool):
        raise ValueError('Damage and instability must be nonnegative numbers')
    base, instability = map(as_fraction, (base, instability))
    if min(base, instability) < 0:
        raise ValueError('Damage and instability must be nonnegative')
    divisor = {'intrinsic_momentary': 10, 'intrinsic_sustained': 4}.get(category)
    return max(Fraction(0), base-instability/divisor) if divisor else base
