"""Immutable applied-HP measures and fixed-precision rolling history queries."""
from dataclasses import dataclass
from decimal import Context, Decimal as D, ROUND_HALF_EVEN, getcontext, localcontext

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.life import life_generation, target_life_record
from combat_sim.mechanics.continuous_numeric import bleed_integral,recorded_root_integral
from combat_sim.world_colliders import finite


@dataclass(frozen=True)
class BleedDose:
    basis_y: D
    start_ms: D

    def __post_init__(self):
        for key in ('basis_y','start_ms'):object.__setattr__(self,key,finite(getattr(self,key),key))

    def integral(self,begin,end):return bleed_integral(self.basis_y,self.start_ms,begin,end)
    def record(self):return {'curve_kind':'bleeding_v1','basis_y':self.basis_y,'start_ms':self.start_ms}


@dataclass(frozen=True)
class AffineHeatDose:
    coefficient: D
    q_reference: D
    reference_ms: D
    slope_per_second: D

    def __post_init__(self):
        for key in ('coefficient','q_reference','reference_ms'):
            object.__setattr__(self,key,finite(getattr(self,key),key))
        object.__setattr__(self,'slope_per_second',dec(self.slope_per_second))

    def integral(self,begin,end):return recorded_root_integral(self.record(),begin,end)
    def record(self):return {'curve_kind':'affine_root_v1','coefficient':self.coefficient,
        'q_reference':self.q_reference,'reference_ms':self.reference_ms,'slope_per_second':self.slope_per_second}


@dataclass(frozen=True)
class QuarticDose:
    begin: D
    end: D
    initial: D
    final: D
    coefficients: tuple

    def __post_init__(self):
        for key in ('begin','end','initial','final'):object.__setattr__(self,key,finite(getattr(self,key),key))
        object.__setattr__(self,'coefficients',tuple(map(dec,self.coefficients)))
        if self.end<=self.begin or self.final<self.initial or len(self.coefficients)!=4:
            raise ValueError('Invalid dense HP-dose piece')
        endpoint=self.initial+(self.end-self.begin)/1000*sum(self.coefficients,D(0))
        tolerance=max(D(1),self.initial,self.final)*D(10)**(8-getcontext().prec)
        if abs(endpoint-self.final)>tolerance:raise ValueError('Dense HP endpoint disagrees with coefficients')

    def _at(self,time):
        if time==self.end:return self.final
        x=(time-self.begin)/(self.end-self.begin);q=self.coefficients
        return max(D(0),self.initial+(self.end-self.begin)/1000*x*(q[0]+x*(q[1]+x*(q[2]+x*q[3]))))

    def integral(self,begin,end):
        begin=max(begin,self.begin);end=min(end,self.end)
        return max(D(0),self._at(end)-self._at(begin)) if end>begin else D(0)

    def record(self):return {'curve_kind':'quartic_hp_dose_v1','begin_ms':self.begin,'end_ms':self.end,
        'initial_hp':self.initial,'final_hp':self.final,'coefficients':self.coefficients}


@dataclass(frozen=True)
class PiecewiseDose:
    pieces: tuple

    def __post_init__(self):
        values=tuple((finite(a,'Dose piece begin'),finite(b,'Dose piece end'),curve) for a,b,curve in self.pieces)
        previous=D(0)
        for begin,end,curve in values:
            if end<=begin or begin<previous or not isinstance(curve,(BleedDose,AffineHeatDose,QuarticDose)):
                raise ValueError('Dose pieces must be ordered, disjoint and supported')
            previous=end
        object.__setattr__(self,'pieces',values)

    def integral(self,begin,end):return sum((curve.integral(max(begin,a),min(end,b)) for a,b,curve in self.pieces
        if max(begin,a)<min(end,b)),D(0))

    def record(self):return {'curve_kind':'piecewise_hp_dose_v1','pieces':[
        {'begin_ms':a,'end_ms':b,'curve':curve.record()} for a,b,curve in self.pieces]}


DOSE_TYPES=(BleedDose,AffineHeatDose,QuarticDose,PiecewiseDose)


def dose_rate(curve,time):
    """Nonnegative per-second rate of a saved analytic/dense HP measure."""
    time=dec(time)
    if isinstance(curve,BleedDose):
        elapsed=(time-curve.start_ms)/1000
        return curve.basis_y*(8-elapsed)/320 if 0<=elapsed<8 else D(0)
    if isinstance(curve,AffineHeatDose):
        q=max(D(0),curve.q_reference+curve.slope_per_second*(time-curve.reference_ms)/1000)
        return curve.coefficient*q.sqrt()
    if isinstance(curve,QuarticDose):
        if not curve.begin<=time<=curve.end:return D(0)
        x=(time-curve.begin)/(curve.end-curve.begin);a,b,c,d=curve.coefficients
        return max(D(0),a+x*(2*b+x*(3*c+x*4*d)))
    if isinstance(curve,PiecewiseDose):
        for i,(begin,end,part) in enumerate(curve.pieces):
            if begin<=time<end or i==len(curve.pieces)-1 and time==end:return dose_rate(part,time)
        return D(0)
    raise ValueError('Unknown HP dose rate')


def dose_knots(curve):
    """Structural rate boundaries; these are physical knots, not damage ticks."""
    if isinstance(curve,BleedDose):return (curve.start_ms,curve.start_ms+8000)
    if isinstance(curve,AffineHeatDose):
        if curve.slope_per_second<0:return (curve.reference_ms-1000*curve.q_reference/curve.slope_per_second,)
        return (curve.reference_ms,) if curve.q_reference==0 and curve.slope_per_second>0 else ()
    if isinstance(curve,QuarticDose):return (curve.begin,curve.end)
    if isinstance(curve,PiecewiseDose):
        return tuple(sorted({time for a,b,part in curve.pieces for time in (a,b,*dose_knots(part))}))
    raise ValueError('Unknown HP dose boundaries')


def dose_from_record(record):
    kind=record.get('curve_kind')
    if kind=='bleeding_v1':return BleedDose(record['basis_y'],record['start_ms'])
    if kind=='affine_root_v1':return AffineHeatDose(*(record[k] for k in
        ('coefficient','q_reference','reference_ms','slope_per_second')))
    if kind=='quartic_hp_dose_v1':return QuarticDose(*(record[k] for k in
        ('begin_ms','end_ms','initial_hp','final_hp','coefficients')))
    if kind=='piecewise_hp_dose_v1':return PiecewiseDose(tuple(
        (p['begin_ms'],p['end_ms'],dose_from_record(p['curve'])) for p in record['pieces']))
    raise ValueError('Unknown applied-HP dose curve')


@dataclass(frozen=True)
class DamageContribution:
    source: EffectSource
    nominal_hp: D
    kind: str
    eligible: bool
    curve: object | None = None
    effect_id: str | None = None
    volume_id: str | None = None
    component: str = ''

    def __post_init__(self):
        if not isinstance(self.source,EffectSource) or type(self.eligible) is not bool:
            raise ValueError('Damage needs an explicit source and eligibility snapshot')
        object.__setattr__(self,'nominal_hp',finite(self.nominal_hp,'Nominal HP loss'))
        if not isinstance(self.kind,str) or not self.kind or not isinstance(self.component,str):
            raise ValueError('Damage needs a kind and component identifier')
        for identity in (self.effect_id,self.volume_id):
            if identity is not None and (not isinstance(identity,str) or not identity):raise ValueError('Invalid damage identity')
        if self.curve is not None and not isinstance(self.curve,DOSE_TYPES):raise ValueError('Unsupported HP-dose curve')

    @property
    def key(self):return (self.source.actor,self.source.ability,self.source.action_id,
        self.source.projectile_id or '',self.effect_id or '',self.volume_id or '',self.component,self.kind,
        self.source.life_generation or 0,self.nominal_hp)


@dataclass(frozen=True)
class AppliedLoss:
    id: str
    receipt: str
    target: str
    contribution: DamageContribution
    begin: D
    end: D
    amount: D
    curve_basis: D | None
    curve_id: str | None
    target_life_generation: int | None = None

    def __post_init__(self):
        life_generation(self.target_life_generation)

    def between(self,begin,end):
        if self.begin==self.end:return self.amount if begin<self.end<=end else D(0)
        first,last=max(begin,self.begin),min(end,self.end)
        if last<=first:return D(0)
        if first==self.begin and last==self.end:return self.amount
        return self.amount*self.contribution.curve.integral(first,last)/self.curve_basis

    def record(self):
        c=self.contribution;s=c.source
        return {'id':self.id,'receipt_id':self.receipt,'target':self.target,'actor':s.actor,'ability':s.ability,
            'action_id':s.action_id,'projectile_id':s.projectile_id,'effect_id':c.effect_id,'volume_id':c.volume_id,
            'component':c.component,'kind':c.kind,'credit_eligible':c.eligible,'begin_ms':self.begin,'end_ms':self.end,
            'nominal_hp_damage':c.nominal_hp,'applied_hp_damage':self.amount,'curve_basis_hp':self.curve_basis,'curve_id':self.curve_id,
            **s.life_record(), **target_life_record(self.target_life_generation)}


class DamageLedger:
    def __init__(self,precision=50):
        if type(precision) is not int or precision<40:raise ValueError('Ledger precision must be at least 40')
        self.context=Context(prec=precision,rounding=ROUND_HALF_EVEN)
        self._entries=[];self._receipts={};self._curves={};self._curve_ids={};self.observed_until=D(0)

    def roundoff(self,amount):return max(D(1),amount)*D(10)**(8-self.context.prec)

    @property
    def entries(self):return tuple(self._entries)

    def observe_until(self,time):
        with localcontext(self.context):
            time=finite(time,'Observed time')
            if time<self.observed_until:raise ValueError('Ledger observation cannot move backwards')
            self.observed_until=time

    def record_loss(self,receipt,target,begin,end,contributions,actual_hp,*,target_life_generation=None):
        """Validate an entire receipt, then atomically allocate actual HP loss."""
        with localcontext(self.context):
            if not isinstance(receipt,str) or not receipt or receipt in self._receipts:
                raise ValueError('Loss receipt must be distinct and nonempty')
            if not isinstance(target,str) or not target:raise ValueError('Loss target needs an identity')
            target_life_generation=life_generation(target_life_generation)
            begin,end,actual=map(lambda v:finite(v,'Loss time/amount'),(begin,end,actual_hp))
            if end<begin or end<self.observed_until:raise ValueError('Loss clocks are out of order')
            values=tuple(contributions)
            if any(not isinstance(c,DamageContribution) for c in values):raise ValueError('Unknown damage contribution')
            values=tuple(sorted(values,key=lambda c:c.key))
            nominal=sum((c.nominal_hp for c in values),D(0))
            if actual and not nominal:raise ValueError('Positive applied HP requires positive nominal loss')
            if actual>nominal+self.roundoff(nominal):raise ValueError('Applied HP cannot exceed nominal HP loss')
            if any((c.curve is None)!=(begin==end) for c in values):raise ValueError('Continuous loss requires its actual dose curve')
            drafts=[]
            shares=[actual*c.nominal_hp/nominal if nominal else D(0) for c in values]
            if shares:
                largest=max(range(len(values)),key=lambda i:values[i].nominal_hp)
                shares[largest]=actual-sum((v for i,v in enumerate(shares) if i!=largest),D(0))
            for c,share in zip(values,shares):
                if not share:continue
                basis=c.curve.integral(begin,end) if c.curve is not None else None
                if basis is not None and (basis<=0 or abs(basis-c.nominal_hp)>max(D('1e-8'),c.nominal_hp*D('1e-12'))):
                    raise ArithmeticError('Continuous HP shape disagrees with applied component')
                if share<0:raise ArithmeticError('Negative applied HP allocation')
                drafts.append((c,share,basis))
            created=[]
            for c,share,basis in drafts:
                curve_id=None
                if c.curve is not None:
                    curve_id=self._curve_ids.get(c.curve)
                    if curve_id is None:
                        curve_id='loss-curve:'+str(len(self._curves)+1)
                        self._curves[curve_id]=c.curve;self._curve_ids[c.curve]=curve_id
                entry=AppliedLoss('hp-loss:'+str(len(self._entries)+1),receipt,target,c,begin,end,share,basis,curve_id,target_life_generation)
                self._entries.append(entry);created.append(entry)
            self._receipts[receipt]=(target,begin,end,actual,target_life_generation);self.observed_until=end
            return tuple(created)

    def amount(self,*,actor=None,target=None,end=None,window_ms=None,eligible_only=False,
               source_life_generation=None,target_life_generation=None):
        with localcontext(self.context):
            time=self.observed_until if end is None else finite(end,'History end')
            if time>self.observed_until:raise ValueError('History query exceeds observed time')
            width=None if window_ms is None else finite(window_ms,'History window',positive=True)
            begin=D(-1) if width is None else time-width
            if type(eligible_only) is not bool:raise ValueError('Eligibility filter must be boolean')
            life_generation(source_life_generation);life_generation(target_life_generation)
            return sum((e.between(begin,time) for e in self._entries
                if (actor is None or e.contribution.source.actor==actor) and (target is None or e.target==target)
                and (source_life_generation is None or e.contribution.source.life_generation==source_life_generation)
                and (target_life_generation is None or e.target_life_generation==target_life_generation)
                and (not eligible_only or e.contribution.eligible)),D(0))

    def record(self):
        return {'precision':self.context.prec,'observed_until_ms':self.observed_until,
            'receipts':[{'id':key,'target':target,'begin_ms':begin,'end_ms':end,'applied_hp_damage':actual,
                **target_life_record(generation)}
                for key,(target,begin,end,actual,generation) in sorted(self._receipts.items())],
            'curves':{key:curve.record() for key,curve in self._curves.items()},
            'entries':[e.record() for e in self._entries]}

    @classmethod
    def from_record(cls,record):
        ledger=cls(record['precision'])
        with localcontext(ledger.context):
            ledger._curves={key:dose_from_record(curve) for key,curve in record['curves'].items()}
            ledger._curve_ids={curve:key for key,curve in ledger._curves.items()}
            for row in record['receipts']:
                key=row['id']
                if not isinstance(key,str) or not key or key in ledger._receipts:raise ValueError('Invalid receipt identity')
                begin,end,actual=map(lambda v:finite(v,'Stored receipt'),(row['begin_ms'],row['end_ms'],row['applied_hp_damage']))
                if not isinstance(row['target'],str) or not row['target'] or end<begin:raise ValueError('Invalid receipt')
                ledger._receipts[key]=(row['target'],begin,end,actual,life_generation(row.get('target_life_generation')))
            ids=set()
            for row in record['entries']:
                curve=ledger._curves.get(row['curve_id']) if row['curve_id'] is not None else None
                if row['curve_id'] is not None and curve is None:raise ValueError('Missing HP-dose curve')
                source=EffectSource(row['actor'],row['ability'],row['action_id'],row['projectile_id'],row.get('source_life_generation'))
                c=DamageContribution(source,row['nominal_hp_damage'],row['kind'],row['credit_eligible'],curve,
                    row['effect_id'],row['volume_id'],row['component'])
                begin,end,amount=map(lambda v:finite(v,'Stored HP loss'),(row['begin_ms'],row['end_ms'],row['applied_hp_damage']))
                basis=finite(row['curve_basis_hp'],'Curve basis',positive=True) if curve is not None else None
                if (row['receipt_id'] not in ledger._receipts or end<begin or amount<=0 or amount>c.nominal_hp+ledger.roundoff(c.nominal_hp)
                        or (curve is None)!=(begin==end)):
                    raise ValueError('Invalid stored HP loss')
                if not isinstance(row['id'],str) or not row['id'] or row['id'] in ids:raise ValueError('Invalid loss identity')
                ids.add(row['id'])
                receipt=ledger._receipts[row['receipt_id']]
                if (row['target'],begin,end)!=receipt[:3]:raise ValueError('Loss disagrees with receipt')
                generation=life_generation(row.get('target_life_generation'))
                if generation!=receipt[4]:raise ValueError('Loss life disagrees with receipt')
                if curve is not None and abs(curve.integral(begin,end)-basis)>ledger.roundoff(basis):
                    raise ValueError('Stored HP curve basis disagrees')
                ledger._entries.append(AppliedLoss(row['id'],row['receipt_id'],row['target'],c,begin,end,amount,basis,row['curve_id'],generation))
            for key,receipt in ledger._receipts.items():
                shares=[e.amount for e in ledger._entries if e.receipt==key];total=sum(shares,D(0))
                if receipt[3] and not shares or abs(total-receipt[3])>ledger.roundoff(receipt[3]):
                    raise ValueError('Receipt does not conserve applied HP')
            ledger.observe_until(record['observed_until_ms'])
            if any(e.end>ledger.observed_until for e in ledger._entries):raise ValueError('Stored loss exceeds observation')
        return ledger
