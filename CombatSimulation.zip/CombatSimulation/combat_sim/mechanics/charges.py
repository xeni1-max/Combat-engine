"""Bounded serial recharge on an existing, independently pausable work clock.

The clock stores all outstanding work. Ceil(work / period) charges are missing;
crossing each multiple restores one charge without scheduled refill mutations.
Queries never consume work or bank progress while the pool is full.
"""
from decimal import Decimal as D, ROUND_CEILING

from combat_sim.mechanics.cooldown import CooldownClock
from combat_sim.world_colliders import finite


class RechargeableCharges:
    def __init__(self, capacity, recharge_ms, *, clock=None):
        self._count(capacity)
        self.capacity = capacity
        self.recharge_ms = finite(recharge_ms, 'Charge recharge duration')
        if self.recharge_ms <= 0:
            raise ValueError('Charge recharge duration must be positive')
        self.clock = CooldownClock() if clock is None else clock
        if not isinstance(self.clock, CooldownClock):
            raise ValueError('Charges need a remaining-work cooldown clock')
        if self.clock.remaining_ms > self.capacity*self.recharge_ms:
            raise ValueError('Outstanding work exceeds charge capacity')

    @staticmethod
    def _count(value):
        if type(value) is not int or value <= 0:
            raise ValueError('Charge counts must be positive integers')

    def available(self, time):
        missing = (self.clock.remaining(time)/self.recharge_ms).to_integral_value(rounding=ROUND_CEILING)
        return self.capacity-int(missing)

    def ready_at(self, time, count=1):
        self._count(count)
        if count > self.capacity:
            raise ValueError('Requested charges exceed capacity')
        time = finite(time, 'Charge readiness time')
        remaining = self.clock.remaining(time)
        threshold = (self.capacity-count)*self.recharge_ms
        if self.clock.stopped:
            return None
        if remaining <= threshold:
            return time
        return None if self.clock.pauses else time+remaining-threshold

    def spend(self, time, count=1):
        self._count(count)
        time = finite(time, 'Charge spending time')
        if count > self.capacity or self.available(time) < count:
            raise ValueError('Insufficient charges')
        self.clock.add_work(time, count*self.recharge_ms)

    def record(self, time):
        return {'capacity': self.capacity, 'available': self.available(time),
                'recharge_ms': self.recharge_ms, 'recharge_policy': 'serial',
                'next_charge_at_ms': (None if self.available(time)==self.capacity
                    else self.ready_at(time, self.available(time)+1)),
                'clock': self.clock.record(time)}
