"""Small Decimal Dormand-Prince 5(4) integrator with quartic dense output.

Mathematical tableau/dense coefficients checked against SciPy's primary source:
https://github.com/scipy/scipy/blob/v1.15.3/scipy/integrate/_ivp/rk.py
No SciPy/NumPy dependency or runtime source download. This implementation uses
ms clocks, derivatives per second, explicit work bounds and immutable outputs.
Error estimates are diagnostics, not certified global error bounds.
"""
from dataclasses import dataclass
from decimal import Decimal as D
from fractions import Fraction

from combat_sim.battle_models import decimal_value as dec

C=('0','1/5','3/10','4/5','8/9','1')
A=((),('1/5',),('3/40','9/40'),('44/45','-56/15','32/9'),
   ('19372/6561','-25360/2187','64448/6561','-212/729'),
   ('9017/3168','-355/33','46732/5247','49/176','-5103/18656'))
B=('35/384','0','500/1113','125/192','-2187/6784','11/84')
E=('-71/57600','0','71/16695','-71/1920','17253/339200','-22/525','1/40')
P=(('1','-8048581381/2820520608','8663915743/2820520608','-12715105075/11282082432'),
   ('0','0','0','0'),('0','131558114200/32700410799','-68118460800/10900136933','87487479700/32700410799'),
   ('0','-1754552775/470086768','14199869525/1410260304','-10690763975/1880347072'),
   ('0','127303824393/49829197408','-318862633887/49829197408','701980252875/199316789632'),
   ('0','-282668133/205662961','2019193451/616988883','-1453857185/822651844'),
   ('0','40617522/29380423','-110615467/29380423','69997945/29380423'))


@dataclass(frozen=True)
class DenseStep:
    begin: D
    end: D
    initial: tuple
    final: tuple
    coefficients: tuple

    def at(self,time):
        if not self.begin<=time<=self.end:raise ValueError('Dense step query is outside its interval')
        if time==self.end:return self.final
        x=(time-self.begin)/(self.end-self.begin);h=(self.end-self.begin)/1000
        return tuple(y+h*x*(q[0]+x*(q[1]+x*(q[2]+x*q[3]))) for y,q in zip(self.initial,self.coefficients))


@dataclass(frozen=True)
class DenseSolution:
    begin: D
    end: D
    initial: tuple
    steps: tuple
    evaluations: int
    rejected: int

    def at(self,time):
        if not self.begin<=time<=self.end:raise ValueError('Dense solution query is outside its interval')
        for step in self.steps:
            if time<=step.end:return step.at(time)
        return self.initial


def integrate(function,begin,end,initial,*,absolute=D('1e-14'),relative=D('1e-13'),max_step_ms=D(20)):
    """Integrate once; arbitrary observation reads cannot change accepted steps."""
    if end<begin or absolute<=0 or relative<=0 or max_step_ms<=0:raise ValueError('Invalid integration controls')
    convert=lambda values:tuple(dec(Fraction(v)) for v in values)
    cc,aa,bb,ee,pp=convert(C),tuple(map(convert,A)),convert(B),convert(E),tuple(map(convert,P))
    y=tuple(map(dec,initial));time=begin;steps=[];evaluations=rejected=0
    h=min(max_step_ms,end-begin);f=tuple(function(time,y));evaluations+=1
    for _ in range(100000):
        if time>=end:break
        h=min(h,end-time,max_step_ms)
        if h<=0 or time+h==time:raise ArithmeticError('Adaptive thermal step cannot advance the clock')
        hs=h/1000;k=[f]
        for i in range(1,6):
            state=tuple(v+hs*sum((a*row[j] for a,row in zip(aa[i],k)),D(0)) for j,v in enumerate(y))
            k.append(tuple(function(time+cc[i]*h,state)));evaluations+=1
        new=tuple(v+hs*sum((a*row[j] for a,row in zip(bb,k)),D(0)) for j,v in enumerate(y))
        last=tuple(function(time+h,new));k.append(last);evaluations+=1
        error=max((abs(hs*sum((a*row[j] for a,row in zip(ee,k)),D(0)))/
                   (absolute+relative*max(abs(y[j]),abs(new[j]))) for j in range(len(y))),default=D(0))
        if not error.is_finite():raise ArithmeticError('Nonfinite thermal integration error')
        factor=D(5) if not error else min(D(5),max(D('.1'),D('.9')*error**D('-.2')))
        if error<=1:
            q=tuple(tuple(sum((k[i][j]*pp[i][p] for i in range(7)),D(0)) for p in range(4)) for j in range(len(y)))
            steps.append(DenseStep(time,time+h,y,new,q));time+=h;y=new;f=last
        else:rejected+=1;factor=min(D('.9'),factor)
        h*=factor
    else:raise ArithmeticError('Adaptive thermal integration exceeded its work bound')
    return DenseSolution(begin,end,tuple(map(dec,initial)),tuple(steps),evaluations,rejected)
