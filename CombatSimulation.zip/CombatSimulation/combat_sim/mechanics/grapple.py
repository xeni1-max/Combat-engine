"""Source grapple calculations; control/Break timing and constraints are separate.

Grapple abilities.odt contains four embedded formulas. These functions accept
current adjusted statuses, not raw incoming status amounts, and never mitigate
them again. They do not cast an ability, create a link, or advance a world.
"""
from dataclasses import dataclass
from decimal import Context, Decimal as D, ROUND_HALF_EVEN, localcontext
from fractions import Fraction as F

from combat_sim.mechanics.dyspnea import MAX_DYSPNEA
from combat_sim.mechanics.status import body_status_weight
from combat_sim.models import as_fraction


SOURCE = 'Grapple abilities.odt p3/p7/p10/p14/p17/p21/p25/p29 and embedded Objects 1/2/3/4'
BREAK_FILL_PER_SECOND = F(20)
MOTION_PRECISION = 50


def _value(value, name, *, nonnegative=True):
    try:
        if isinstance(value, bool):
            raise ValueError
        result = as_fraction(value)
        if nonnegative and result < 0:
            raise ValueError
    except (ValueError, TypeError, ArithmeticError) as error:
        raise ValueError(name+' must be a finite '+('nonnegative ' if nonnegative else '')+'number') from error
    return result


@dataclass(frozen=True)
class GrappleState:
    """A participant's current D, O and U after their actual application rules."""
    dyspnea: F
    disorientation: F = F(0)
    instability: F = F(0)

    def __post_init__(self):
        for name in ('dyspnea', 'disorientation', 'instability'):
            object.__setattr__(self, name, _value(getattr(self, name), name))
        if self.dyspnea > MAX_DYSPNEA:
            raise ValueError('Current dyspnea cannot exceed its 100-point capacity')

    @property
    def empty_capacity(self):
        return MAX_DYSPNEA-self.dyspnea

    @property
    def exhaustion_limit(self):
        # Delegated physical floor: a negative full-bar threshold means zero
        # remaining capacity for holding; it never creates a negative D state.
        return max(F(0), MAX_DYSPNEA-(self.disorientation+self.instability)/10)

    @property
    def exhausted(self):
        return self.dyspnea >= self.exhaustion_limit


@dataclass(frozen=True)
class BreakAssessment:
    attacker_exhaustion_limit: F
    attacker_exhausted: bool
    empty_capacity_advantage: F
    required_advantage: F
    margin: F
    escape_condition_met: bool

    def record(self):
        return {name: value if isinstance(value, bool) else str(value)
                for name, value in self.__dict__.items()}


def assess_break(attacker: GrappleState, defender: GrappleState) -> BreakAssessment:
    """Evaluate the source comparison; an active grapple/Break request is separate.

    E_defender-E_attacker = D_attacker-D_defender. Source Object 2 raises
    the required advantage from zero by (O_b-O_a+U_b-U_a)/10. Preserve its
    sign: an impaired attacker makes escape easier, an impaired defender harder.
    Equality meets the comparison. Exhaustion is reported independently so the
    future lifecycle can explicitly arbitrate simultaneous termination causes.
    """
    if not isinstance(attacker, GrappleState) or not isinstance(defender, GrappleState):
        raise ValueError('Break assessment needs two adjusted grapple states')
    advantage = defender.empty_capacity-attacker.empty_capacity
    required = (defender.disorientation-attacker.disorientation+
                defender.instability-attacker.instability)/10
    margin = advantage-required
    return BreakAssessment(attacker.exhaustion_limit, attacker.exhausted,
                           advantage, required, margin, margin >= 0)


def break_effort_gain(elapsed_ms, *, rate_per_second=BREAK_FILL_PER_SECOND):
    """Uncapped extra Break filling; callers count actual gain and split pauses.

    Default20/s is the specific Break rule, not ordinary recovery with its sign
    reversed. The caller owns response windows, pauses, caps and shared effort.
    """
    elapsed = _value(elapsed_ms, 'Elapsed time')
    rate = _value(rate_per_second, 'Break filling rate')
    return rate*elapsed/1000


def break_status_base(actual_break_dyspnea):
    """D=3A for one declared accumulated Break-effort measure A (Object4).

    Which actors contribute to A and how resulting statuses are applied belong
    to the eventual contest profile; this helper neither invents effort nor
    applies mitigation or a self-status multiplier.
    """
    return 3*_value(actual_break_dyspnea, 'Actual Break dyspnea')


def shared_velocity(first_velocity, second_velocity, *, first_max_hp, first_armor,
                    second_max_hp, second_armor, precision=MOTION_PRECISION):
    """Object3's 3D vector average, weighted by maximum HP/current armor.

    This is a velocity calculation, not collision response or a constraint
    solver. A binding chain does not become a rigid grapple merely because it
    can move two bodies together when taut.
    """
    if not isinstance(precision, int) or isinstance(precision, bool) or precision < 40:
        raise ValueError('Grapple motion precision must be at least 40 digits')
    try:
        if (not isinstance(first_velocity, (tuple, list)) or not isinstance(second_velocity, (tuple, list)) or
                len(first_velocity) != 3 or len(second_velocity) != 3):
            raise ValueError
        first = tuple(_value(v, 'Velocity', nonnegative=False) for v in first_velocity)
        second = tuple(_value(v, 'Velocity', nonnegative=False) for v in second_velocity)
    except (TypeError, ValueError) as error:
        raise ValueError('Shared motion needs two finite three-component velocities') from error
    hp1, hp2 = _value(first_max_hp, 'First maximum HP'), _value(second_max_hp, 'Second maximum HP')
    a1, a2 = _value(first_armor, 'First armor'), _value(second_armor, 'Second armor')
    if not hp1 or not hp2:
        raise ValueError('Grapple participants need positive maximum HP')
    w1, w2 = body_status_weight(hp1, a1), body_status_weight(hp2, a2)
    with localcontext(Context(prec=precision, rounding=ROUND_HALF_EVEN)):
        decimal = lambda value: D(value.numerator)/D(value.denominator)
        return tuple((w1*decimal(v1)+w2*decimal(v2))/(w1+w2) for v1, v2 in zip(first, second))
