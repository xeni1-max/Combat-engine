"""Author-defined collision components and incoming statuses.

Character pairs use their centre line; obstacles use the contacted surface
normal through the character centre. This pure response does not choose a face
at an edge/corner, detect contact or solve multiple simultaneous contacts.
"""
from dataclasses import dataclass
from decimal import Context, Decimal as D, ROUND_HALF_EVEN, localcontext
from fractions import Fraction

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.status import mitigate_status
from combat_sim.models import as_fraction, UnsupportedMechanicError


def vector(values):
    values=tuple(as_fraction(v) for v in values)
    if len(values)!=3:raise ValueError('Body collision vectors require three components')
    return values


@dataclass(frozen=True)
class CollisionCharacter:
    centre_m: tuple
    velocity_mps: tuple
    max_hp: Fraction
    armor: Fraction
    status_resistance: Fraction=Fraction(0)

    def __post_init__(self):
        for name in ('centre_m','velocity_mps'):
            object.__setattr__(self,name,vector(getattr(self,name)))
        for name in ('max_hp','armor','status_resistance'):
            value=as_fraction(getattr(self,name))
            if value<0:raise ValueError('Collision defenses must be nonnegative')
            object.__setattr__(self,name,value)


@dataclass(frozen=True)
class CharacterCollisionResponse:
    velocity_before_mps: tuple
    velocity_after_mps: tuple
    removed_velocity_mps: tuple
    raw_disorientation: D
    raw_instability: D
    added_disorientation: D
    added_instability: D


@dataclass(frozen=True)
class DirectionalCollision:
    direction_unit: tuple
    relative_speed_in_direction_mps: D
    first: CharacterCollisionResponse
    second: CharacterCollisionResponse | None
    precision: int
    status_mitigation_precision: int=40


def unit_direction(direction):
    direction=tuple(dec(v) for v in direction)
    length=sum(v*v for v in direction).sqrt()
    if not length:
        raise UnsupportedMechanicError('Collision direction must be nonzero: distinct character centres or an explicit surface normal')
    return tuple(v/length for v in direction)


def calculate(first,second,direction,precision):
    if not isinstance(precision,int) or precision<40:
        raise ValueError('Collision response precision must be at least 40 digits')
    with localcontext(Context(prec=precision,rounding=ROUND_HALF_EVEN)):
        n=unit_direction(direction)
        a=tuple(dec(v) for v in first.velocity_mps)
        b=tuple(dec(v) for v in second.velocity_mps) if second else (D(0),)*3
        relative=abs(sum((x-y)*d for x,y,d in zip(a,b,n)))
        raw=relative*60  # 300 disorientation/instability per 5 m/s.
        def response(actor,velocity):
            component=sum(v*d for v,d in zip(velocity,n))
            removed=tuple(component*d for d in n)
            after=tuple(v-r for v,r in zip(velocity,removed))
            value=mitigate_status(raw,actor.max_hp,actor.armor,actor.status_resistance)
            return CharacterCollisionResponse(velocity,after,removed,raw,raw,value,value)
        return DirectionalCollision(n,relative,response(first,a),response(second,b) if second else None,precision)


def collide_characters(first,second,*,precision=50):
    """Both receive full relative-speed status; each loses its own component."""
    direction=tuple(b-a for a,b in zip(first.centre_m,second.centre_m))
    return calculate(first,second,direction,precision)


def collide_static_obstacle(character,*,surface_normal,precision=50):
    """Remove motion perpendicular to the contacted static obstacle surface.

    The collision line passes through the character centre, parallel to this
    explicit normal. Obstacle centre is not used. The contact detector/caller
    supplies the selected surface; no nearest-face or corner tie is invented.
    """
    return calculate(character,None,vector(surface_normal),precision)


def collide_ground(character,*,precision=50):
    """Flat ground's collision line is perpendicular through the body centre."""
    return collide_static_obstacle(character,surface_normal=(0,0,1),precision=precision)
