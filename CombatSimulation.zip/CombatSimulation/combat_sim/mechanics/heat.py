"""k=2 heat rate and exact continuous interval integrals from the sources."""

from fractions import Fraction

from combat_sim.exact import ExactAmount, ExactRootProduct
from combat_sim.models import UnsupportedMechanicError, as_fraction

SOURCE = "Damage types.odt, Heat; 1E1.odt ability 4 k=2; author confirms continuous accumulation"
FORMULA = "hd = max(0,(ho^2-(a^2+Rh^2)/2)/ho) * sqrt(th-2*to2)"


def heat_coefficient(heat_output, armor, heat_resistance, k=2):
    output, armor, resistance, root_order = map(as_fraction, (heat_output, armor, heat_resistance, k))
    if output <= 0:
        raise ValueError("Heat output must be positive")
    if min(armor, resistance) < 0:
        raise ValueError("Armor and heat resistance must be nonnegative")
    if root_order < 2:
        raise ValueError("Heat k must be at least 2")
    if root_order != 2:
        raise UnsupportedMechanicError("This stage implements k=2 heat only; other roots are not approximated")
    return max(Fraction(0), (output**2 - (armor**2 + resistance**2) / 2) / output)


def heat_damage_rate(heat_output, armor, heat_resistance, exposure_seconds, non_exposure_seconds=0, k=2):
    coefficient = heat_coefficient(heat_output, armor, heat_resistance, k)
    exposure, non_exposure = map(as_fraction, (exposure_seconds, non_exposure_seconds))
    if min(exposure, non_exposure) < 0:
        raise ValueError("Heat clock values must be nonnegative")
    radicand = exposure - as_fraction(k) * non_exposure
    if radicand < 0:
        raise ValueError("Heat root requires th >= k*to2; the controller must end damage at zero")
    if coefficient == 0 or radicand == 0:
        return ExactRootProduct(0, 0)
    return ExactRootProduct(coefficient, radicand)


def heat_damage_between(heat_output, armor, heat_resistance, root_input_start, root_input_end, elapsed_seconds, k=2):
    """Integrate C*sqrt(q) while q changes linearly over this interval.

    Defenses must remain constant within the interval. A stat change splits the
    interval; the next call uses the new current armor/resistance, never a
    permanent exposure-start snapshot. Exact roots cancel across boundaries.
    """
    coefficient = heat_coefficient(heat_output, armor, heat_resistance, k)
    q0, q1, elapsed = map(as_fraction, (root_input_start, root_input_end, elapsed_seconds))
    if min(q0, q1, elapsed) < 0:
        raise ValueError("Heat integration inputs must be nonnegative")
    if elapsed == 0:
        if q0 != q1:
            raise ValueError("A zero-duration interval cannot change heat exposure")
        return ExactAmount()
    if q0 == q1:
        return ExactAmount.of(ExactRootProduct(coefficient * elapsed, q0))
    factor = Fraction(2, 3) * coefficient * elapsed / (q1 - q0)
    return ExactAmount(roots=(ExactRootProduct(factor * q1, q1), ExactRootProduct(-factor * q0, q0)))


def full_exposure_and_recovery_damage(heat_output, armor, heat_resistance, exposure_seconds, k=2):
    """For unchanged defenses, integrate growing exposure and the full tail."""
    duration = as_fraction(exposure_seconds)
    if duration <= 0:
        raise ValueError("Full heat exposure duration must be positive")
    return (heat_damage_between(heat_output, armor, heat_resistance, 0, duration, duration, k)
            + heat_damage_between(heat_output, armor, heat_resistance, duration, 0, duration / as_fraction(k), k))
