"""Blunt damage equations from the primary Damage types document."""

from fractions import Fraction

from combat_sim.models import as_fraction


SOURCE = "Damage types.odt, Blunt"
POST_MITIGATION_FORMULA = "y = (d^2 - a^2) / d"
ARMOR_REDUCTION_FORMULA = "Ar = (d^2 - a^3/700) / (50d)"


def post_mitigation_damage(pre_mitigation_damage: Fraction, armor: Fraction) -> Fraction:
    """Calculate y with the user-confirmed minimum of zero."""
    return max(Fraction(0), raw_post_mitigation_damage(pre_mitigation_damage, armor))


def raw_post_mitigation_damage(pre_mitigation_damage: Fraction, armor: Fraction) -> Fraction:
    """Evaluate the documented blunt equation before the zero-floor rule."""
    damage = as_fraction(pre_mitigation_damage)
    current_armor = as_fraction(armor)
    if damage == 0:
        raise ValueError("Blunt formula is undefined for d=0 (division by zero)")
    if damage < 0 or current_armor < 0:
        raise ValueError("Damage and armor must be nonnegative")
    return (damage**2 - current_armor**2) / damage


def armor_reduction(pre_mitigation_damage: Fraction, armor: Fraction) -> Fraction:
    """Calculate Ar with the user-confirmed minimum of zero."""
    return max(Fraction(0), raw_armor_reduction(pre_mitigation_damage, armor))


def raw_armor_reduction(pre_mitigation_damage: Fraction, armor: Fraction) -> Fraction:
    """Evaluate the documented armor-loss equation before the zero-floor rule."""
    damage = as_fraction(pre_mitigation_damage)
    current_armor = as_fraction(armor)
    if damage == 0:
        raise ValueError("Blunt armor-reduction formula is undefined for d=0")
    if damage < 0 or current_armor < 0:
        raise ValueError("Damage and armor must be nonnegative")
    return (damage**2 - current_armor**3 / 700) / (50 * damage)
