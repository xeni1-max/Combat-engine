"""Isolated basic jump flight and takeoff timing; no landing collision policy."""
from dataclasses import dataclass
from fractions import Fraction

from combat_sim.mechanics.gravity import GRAVITY_MPS2
from combat_sim.mechanics.timing import impact_time_from_activation
from combat_sim.models import as_fraction


def jump_initial_speed_mps(base_running_speed_mps):
    """Upward takeoff speed uses base running speed, not current movement."""
    speed=as_fraction(base_running_speed_mps)
    if speed<=0:
        raise ValueError('Base running speed must be positive')
    return speed/2


@dataclass(frozen=True)
class JumpState:
    elapsed_s: Fraction
    position_m: tuple
    velocity_mps: tuple


@dataclass(frozen=True)
class JumpFlight:
    """Exact gravity flight from an explicit origin with retained horizontal v.

    Valid through return to takeoff height. That return is a geometric marker,
    not a terrain contact: an actual landing needs body/terrain collision rules.
    """
    origin_m: tuple
    horizontal_velocity_mps: tuple
    base_running_speed_mps: Fraction
    gravity_mps2: Fraction=as_fraction(GRAVITY_MPS2)

    def __post_init__(self):
        for name,size in (('origin_m',3),('horizontal_velocity_mps',2)):
            values=tuple(as_fraction(v) for v in getattr(self,name))
            if len(values)!=size:
                raise ValueError('Jump origin requires xyz; horizontal velocity requires xy')
            object.__setattr__(self,name,values)
        for name in ('base_running_speed_mps','gravity_mps2'):
            object.__setattr__(self,name,as_fraction(getattr(self,name)))
        jump_initial_speed_mps(self.base_running_speed_mps)
        if self.gravity_mps2<=0:
            raise ValueError('Jump gravity must be positive')

    @property
    def initial_upward_speed_mps(self):
        return jump_initial_speed_mps(self.base_running_speed_mps)

    @property
    def apex_time_s(self):
        return self.initial_upward_speed_mps/self.gravity_mps2

    @property
    def apex_rise_m(self):
        return self.initial_upward_speed_mps**2/(2*self.gravity_mps2)

    @property
    def same_height_return_time_s(self):
        return 2*self.apex_time_s

    def at(self,elapsed_s):
        t=as_fraction(elapsed_s)
        if not 0<=t<=self.same_height_return_time_s:
            raise ValueError('Time is outside the isolated same-height jump flight')
        x,y,z=self.origin_m
        vx,vy=self.horizontal_velocity_mps
        up=self.initial_upward_speed_mps
        return JumpState(t,(x+vx*t,y+vy*t,z+up*t-self.gravity_mps2*t*t/2),
                         (vx,vy,up-self.gravity_mps2*t))


def basic_jump_takeoff_time_ms(action_start_ms,profile,*,disorientation_at_gathering_start=0,
                               is_running_at_gathering_start=False):
    """Take off at Active start using existing Gathering/running/rounding rules.

    Scheduling only: does not pay dyspnea, add statuses or resolve collisions.
    Active end is distinct from the later return to launch height.
    """
    timing={'gathering_ms':profile['gathering_ms'],'active_ms':profile['active_ms'],
            'impact_timing':'start_of_active'}
    return impact_time_from_activation(action_start_ms,timing,
        disorientation_at_gathering_start=disorientation_at_gathering_start,
        is_running_at_gathering_start=is_running_at_gathering_start)
