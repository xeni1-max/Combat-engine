"""Primary continuous electrocution response, independent of armor and duration."""
from fractions import Fraction

from combat_sim.models import as_fraction

SOURCE = 'Damage types.odt p56-p60/Object 9; de2=(de^2-Re^2)/de'
FORMULA = 'max(0, overflow_dps-electrocution_resistance^2/overflow_dps)'


def damage_rate(raw_per_second, resistance):
    if isinstance(raw_per_second, bool) or isinstance(resistance, bool):
        raise ValueError('Electrocution rate and resistance must be numeric')
    raw, resistance = map(as_fraction, (raw_per_second, resistance))
    if min(raw, resistance) < 0:
        raise ValueError('Electrocution rate and resistance must be nonnegative')
    return max(Fraction(0), raw-resistance*resistance/raw) if raw else Fraction(0)
