"""Immutable non-heat continuous pressure/body response for the layer solver."""
from dataclasses import dataclass
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics import constriction,electrocution
from combat_sim.mechanics.recovery_flow import AffineRate
from combat_sim.world_colliders import finite


@dataclass(frozen=True)
class RateDamageSource:
    id: str
    pressure: AffineRate
    armor: D
    family: str = 'constriction_tear'
    body_q: D = D(0)
    exposed: bool = True
    shield_residual: bool = False
    resistance: D = D(0)

    def __post_init__(self):
        if not isinstance(self.id,str) or not self.id or not isinstance(self.pressure,AffineRate):
            raise ValueError('Rate damage needs an identity and affine pressure')
        object.__setattr__(self,'armor',finite(self.armor,'Continuous armor'))
        object.__setattr__(self,'resistance',finite(self.resistance,'Continuous resistance'))
        if (self.family not in ('constriction_tear','electrocution') or self.body_q!=0
                or self.exposed is not True or self.shield_residual is not False):
            raise ValueError('Unsupported rate-damage family or memory state')
        if ((self.family=='constriction_tear' and self.resistance)
                or (self.family=='electrocution' and self.armor)):
            raise ValueError('Rate source must use only the defenses defined for its damage family')

    def q_incident(self,time):return D(0)

    def hp_rate(self,time,absorbed_fraction):
        if not 0<=absorbed_fraction<=1:raise ValueError('Absorption fraction must be between zero and one')
        overflow=self.pressure.rate(time)*(1-absorbed_fraction)
        if self.family=='electrocution':return dec(electrocution.damage_rate(overflow,self.resistance))
        return dec(constriction.damage_rate(overflow,self.armor))
