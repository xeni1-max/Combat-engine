"""Nominal ballistic body launches, independent of actions and collision rules.

The source gives dash range but no vertical launch. The selected model reuses
the confirmed basic jump's upward speed and solves horizontal speed for range
at the same height. Terrain and links determine the actual landing separately.
"""
from dataclasses import dataclass
from decimal import Context, Decimal as D, localcontext

from combat_sim.mechanics.jumping import jump_initial_speed_mps
from combat_sim.mechanics.velocity_projection import number, vector
from combat_sim.models import UnsupportedMechanicError


@dataclass(frozen=True)
class DirectedLaunch:
    velocity_mps: tuple
    flight_time_ms: D


def directed_launch(origin_m,target_m,speed_mps,gravity_mps2,*,precision=50):
    """Fastest constant-gravity arc at a fixed speed, in body Decimal precision."""
    if type(precision) is not int or precision<40:raise ValueError('Body launch precision must be at least 40')
    origin=vector(origin_m);target=vector(target_m)
    speed=number(speed_mps,positive=True);gravity=number(gravity_mps2,positive=True)
    with localcontext(Context(prec=precision)):
        dec=lambda value:D(value.numerator)/D(value.denominator)
        delta=tuple(dec(b-a) for a,b in zip(origin,target));squared=sum(x*x for x in delta)
        if not squared:raise UnsupportedMechanicError('Coincident body launch point has no positive-flight arc')
        v=dec(speed);g=dec(gravity);b=v*v-g*delta[2];discriminant=b*b-g*g*squared
        if b<=0 or discriminant<0:raise UnsupportedMechanicError('Body launch point is unreachable at the declared speed')
        # Stable smaller time root, avoiding cancellation near a short shot.
        duration=(2*squared/(b+discriminant.sqrt())).sqrt()
        velocity=tuple(d/duration for d in delta[:2])+(delta[2]/duration+g*duration/2,)
        return DirectedLaunch(velocity,duration*1000)


@dataclass(frozen=True)
class BallisticLaunch:
    velocity_mps: tuple
    same_height_duration_ms: D
    nominal_range_m: D


def upward_knock_speed(height_m,gravity_mps2,*,precision=50):
    """Initial upward increment for a nominal resisted apex rise from rest."""
    if type(precision) is not int or precision<40:raise ValueError('Body launch precision must be at least 40')
    height=number(height_m);gravity=number(gravity_mps2,positive=True)
    with localcontext(Context(prec=precision)):
        value=2*height*gravity
        return (D(value.numerator)/D(value.denominator)).sqrt()


def dash_launch(distance_m, base_running_speed_mps, gravity_mps2, direction_xy, *, precision=50):
    if type(precision) is not int or precision < 40:
        raise ValueError('Body launch precision must be at least 40')
    distance = number(distance_m, positive=True)
    up = jump_initial_speed_mps(number(base_running_speed_mps, positive=True))
    gravity = number(gravity_mps2, positive=True)
    if len(direction_xy) != 2:
        raise ValueError('Dash direction needs two horizontal components')
    direction = vector((*direction_xy, 0))[:2]
    if not any(direction):
        raise ValueError('Dash direction cannot be zero')
    with localcontext(Context(prec=precision)):
        def dec(value):return D(value.numerator)/D(value.denominator)
        duration = dec(2*up/gravity)
        components = tuple(map(dec, direction))
        length = sum(v*v for v in components).sqrt()
        speed = dec(distance*gravity/(2*up))
        return BallisticLaunch(tuple(v/length*speed for v in components)+(dec(up),),
            duration*1000, dec(distance))
