"""Conditional continuous HP/healing flow on immutable incoming/outgoing doses.

Plans may be consumed in prefixes. Healing is an instantaneous fraction of
eligible damage, limited by missing HP and unspent recent-wound funding.
Dense integration is a numerical solver, not a damage/healing tick.
"""
from dataclasses import dataclass
from decimal import Decimal as D

from combat_sim.mechanics.damage_ledger import DOSE_TYPES,PiecewiseDose,QuarticDose,dose_rate
from combat_sim.mechanics.dense_rk import integrate
from combat_sim.world_colliders import finite

ABSOLUTE=D('1e-13');RELATIVE=D('1e-13');CONTACT_HP=D('1e-12')


@dataclass(frozen=True)
class DoseSum:
    terms: tuple = ()  # (nonnegative multiplier, immutable dose)

    def __post_init__(self):
        terms=tuple((finite(value,'Dose multiplier'),curve) for value,curve in self.terms)
        if any(not isinstance(curve,DOSE_TYPES) for _,curve in terms):raise ValueError('Unknown healing dose')
        object.__setattr__(self,'terms',terms)

    def integral(self,begin,end):return sum((factor*curve.integral(begin,end) for factor,curve in self.terms),D(0))
    def rate(self,time):return sum((factor*dose_rate(curve,time) for factor,curve in self.terms),D(0))


@dataclass(frozen=True)
class ExpiringFunding:
    begin: D
    end: D
    window: D
    fraction: D
    initial: D
    entries: tuple

    @classmethod
    def snapshot(cls,history,target,begin,end,*,window=8000,fraction=D('.9')):
        window=D(window);first=begin-window;last=end-window
        entries=tuple(e for e in history.entries if e.target==target)
        initial=fraction*sum((e.between(D(-1),first) for e in entries),D(0))
        changing=tuple(e for e in entries if e.end>first and e.begin<=last)
        return cls(begin,end,window,fraction,initial,changing)

    def amount(self,time,*,left=False):
        first=self.begin-self.window;last=time-self.window
        value=self.initial+self.fraction*sum((e.between(first,last) for e in self.entries),D(0))
        if left and time>self.begin:
            value-=self.fraction*sum((e.amount for e in self.entries if e.begin==e.end==last),D(0))
        return value

    def rate(self,time):
        old=time-self.window
        return self.fraction*sum((e.amount*dose_rate(e.contribution.curve,old)/e.curve_basis
            for e in self.entries if e.begin<=old<e.end),D(0))

    def next_point(self):
        return min((e.end+self.window for e in self.entries if e.begin==e.end
            and self.begin<e.end+self.window<=self.end),default=self.end)


@dataclass(frozen=True)
class HealingFlowPlan:
    begin: D
    end: D
    initial_hp: D
    max_hp: D
    incoming: DoseSum
    entitlement: DoseSum
    funding_total: D
    funding_cursor: D
    cap_fraction: D
    expiring: ExpiringFunding
    dense: object

    def at(self,time):
        if not self.begin<=time<=self.end:raise ValueError('Healing query exceeds its prepared epoch')
        raw_heal,budget,gap,missing=self.dense.at(time)
        damage=self.incoming.integral(self.begin,time)
        total=self.funding_total+self.cap_fraction*damage
        expired=self.expiring.amount(time)
        raw_cursor=max(total-budget,self.expiring.amount(time,left=True)+gap)
        heal=max(D(0),raw_heal)
        heal=min(heal,max(D(0),self.max_hp-self.initial_hp+damage),max(D(0),total-self.funding_cursor))
        heal=max(D(0),heal-max(D(0),raw_cursor-total))
        cursor=min(total,max(self.funding_cursor+heal,expired,raw_cursor-(max(D(0),raw_heal)-heal)))
        return self.initial_hp-damage+heal,heal,cursor

    def death(self,begin=None,end=None,*,initial_hp=None):
        first=self.begin if begin is None else begin;last=self.end if end is None else end
        start_hp=self.at(first)[0] if initial_hp is None else initial_hp
        start_heal=self.at(first)[1]
        hp_at=lambda time:start_hp+max(D(0),self.at(time)[1]-start_heal)-self.incoming.integral(first,time)
        # The conditional ODE turns healing off at zero HP; after its first
        # crossing the body cannot recover in this same life. Inspect dense
        # steps and refine against exact incoming-dose prefixes.
        for step in self.dense.steps:
            a,b=max(first,step.begin),min(last,step.end)
            if b<=a:continue
            if hp_at(b)>0:continue
            for _ in range(200):
                if b-a<=D('1e-20'):break
                mid=(a+b)/2
                if hp_at(mid)<=0:b=mid
                else:a=mid
            return b
        return None

    def healing_curve(self):
        pieces=[]
        for s in self.dense.steps:
            if s.final[0]<s.initial[0]:
                if s.initial[0]-s.final[0]>CONTACT_HP:raise ArithmeticError('Healing dose decreased')
                continue
            curve=QuarticDose(s.begin,s.end,s.initial[0],s.final[0],s.coefficients[0])
            pieces.append((s.begin,s.end,curve))
        return PiecewiseDose(tuple(pieces))

    def record(self):
        return {'begin_ms':self.begin,'end_ms':self.end,'initial_hp':self.initial_hp,
            'funding_cursor':self.funding_cursor,'absolute_tolerance_hp':ABSOLUTE,
            'relative_tolerance':RELATIVE,'constraint_tolerance_hp':CONTACT_HP,
            'adaptive_steps':len(self.dense.steps),'rate_evaluations':self.dense.evaluations}


def build_healing_flow(begin,end,*,hp,max_hp,incoming,entitlement,funding_total,cursor,expiring,
                       cap_fraction=D('.9')):
    hp=finite(hp,'Flow HP',positive=True);max_hp=finite(max_hp,'Maximum HP',positive=True)
    funding_total=finite(funding_total,'Funded HP');cursor=finite(cursor,'Funding cursor')
    if hp>max_hp or cursor>funding_total or end<=begin:raise ValueError('Invalid healing flow initial state')
    if end>expiring.next_point():raise ValueError('Healing epoch must split at point-funding expiry')
    cursor=max(cursor,expiring.amount(begin))

    def derivative(time,state):
        heal,budget,gap,missing=state
        rate=incoming.rate(time);expiration=expiring.rate(time)
        payment=entitlement.rate(time) if missing<max_hp else D(0)
        if missing<=CONTACT_HP:payment=min(payment,rate)
        if budget<=CONTACT_HP:payment=min(payment,cap_fraction*rate)
        spending=max(payment,expiration) if gap<=CONTACT_HP else payment
        # The active reflected balances have exactly zero derivative. Avoid
        # subtracting two independently integrated cumulative curves to decide
        # whether a constraint is active: that cancellation caused chatter.
        return payment,cap_fraction*rate-spending,spending-expiration,rate-payment

    initial=(D(0),funding_total-cursor,cursor-expiring.amount(begin),max_hp-hp)
    dense=integrate(derivative,begin,end,initial,absolute=ABSOLUTE,relative=RELATIVE,max_step_ms=D(20))
    return HealingFlowPlan(begin,end,hp,max_hp,incoming,entitlement,funding_total,cursor,cap_fraction,expiring,dense)
