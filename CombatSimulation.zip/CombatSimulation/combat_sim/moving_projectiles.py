"""Continuous sphere/cuboid contact under quadratic translation and linear resizing.

Projectile and box each have constant acceleration over the supplied interval.
Their relative trajectory is quadratic. Each of the box's nearest-point regions
therefore has a quartic squared-distance equation. Rational polynomial root
isolation finds contacts, including tangencies, without time sampling or an
expanded-box approximation. Cuboid dimensions may change linearly; rotation is
not modeled.
"""
from dataclasses import dataclass
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN, localcontext
from fractions import Fraction as F
from itertools import product

from combat_sim.models import as_fraction
from combat_sim.oriented_geometry import OrientedCuboid,decimal_point


@dataclass(frozen=True)
class MovingSphereContact:
    part: str
    time_s: Decimal
    centre_m: tuple
    closest_box_point_m: tuple
    time_lower_s: Decimal
    time_upper_s: Decimal


def _number(value, name):
    if isinstance(value, bool):
        raise ValueError(f'{name} must be a finite number')
    try:
        return as_fraction(value)
    except (TypeError, ValueError, ZeroDivisionError, OverflowError) as error:
        raise ValueError(f'{name} must be a finite number') from error


def _vector(value, name):
    try:
        result = tuple(_number(v, name) for v in value)
    except TypeError as error:
        raise ValueError(f'{name} must have three coordinates') from error
    if len(result) != 3:
        raise ValueError(f'{name} must have three coordinates')
    return result


def _trim(poly):
    poly = list(poly)
    while len(poly) > 1 and poly[-1] == 0:
        poly.pop()
    return tuple(poly)


def _evaluate(poly, value):
    result = F(0)
    for coefficient in reversed(poly):
        result = result * value + coefficient
    return result


def _derivative(poly):
    return _trim(tuple(i * value for i, value in enumerate(poly))[1:] or (F(0),))


def _divide(numerator, denominator):
    remaining = list(_trim(numerator))
    denominator = _trim(denominator)
    if denominator == (0,):
        raise ZeroDivisionError('Zero polynomial divisor')
    quotient = [F(0)] * max(1, len(remaining) - len(denominator) + 1)
    while remaining != [0] and len(remaining) >= len(denominator):
        offset = len(remaining) - len(denominator)
        factor = remaining[-1] / denominator[-1]
        quotient[offset] += factor
        for i, coefficient in enumerate(denominator):
            remaining[offset+i] -= factor * coefficient
        remaining = list(_trim(remaining))
    return _trim(quotient), tuple(remaining)


def _gcd(left, right):
    while right != (0,):
        left, right = right, _divide(left, right)[1]
    return tuple(value / left[-1] for value in left) if left != (0,) else left


def _sturm(poly):
    sequence = [poly, _derivative(poly)]
    while sequence[-1] != (0,):
        remainder = _divide(sequence[-2], sequence[-1])[1]
        if remainder == (0,):
            break
        # Positive normalization preserves signs and controls coefficient size.
        scale = abs(remainder[-1])
        sequence.append(tuple(-value / scale for value in remainder))
    return tuple(sequence)


def _variations(sequence, value):
    signs = [(result > 0) - (result < 0) for poly in sequence
             if (result := _evaluate(poly, value)) != 0]
    return sum(a != b for a, b in zip(signs, signs[1:]))


@dataclass
class _Root:
    poly: tuple
    sturm: tuple
    low: F
    high: F

    def refine(self):
        if self.low == self.high:
            return
        middle = (self.low + self.high) / 2
        if _evaluate(self.poly, middle) == 0:
            self.low = self.high = middle
        elif _variations(self.sturm, self.low) > _variations(self.sturm, middle):
            self.high = middle
        else:
            self.low = middle


def _roots(poly, low, high):
    """Isolate each distinct real root; intervals exclude low and include high."""
    poly = _trim(poly)
    if len(poly) == 1:
        return []
    poly = _divide(poly, _gcd(poly, _derivative(poly)))[0]
    sequence = _sturm(poly)
    result = []
    if _evaluate(poly, low) == 0:
        result.append(_Root(poly, sequence, low, low))
    pending = [(low, high, _variations(sequence, low) - _variations(sequence, high))]
    while pending:
        start, end, count = pending.pop()
        if count == 0:
            continue
        if count == 1:
            result.append(_Root(poly, sequence, end if _evaluate(poly, end) == 0 else start, end))
            continue
        middle = (start + end) / 2
        left_count = _variations(sequence, start) - _variations(sequence, middle)
        pending.append((middle, end, count-left_count))
        pending.append((start, middle, left_count))
    return result


def _quadratic_bounds(poly, low, high):
    values = [_evaluate(poly, low), _evaluate(poly, high)]
    if len(poly) == 3 and poly[2]:
        vertex = -poly[1] / (2*poly[2])
        if low < vertex < high:
            values.append(_evaluate(poly, vertex))
    return min(values), max(values)


def _has_root(poly, low, high):
    if len(poly) <= 1:
        return False
    if low == high:
        return _evaluate(poly, low) == 0
    sequence = _sturm(poly)
    return _variations(sequence, low) > _variations(sequence, high)


def _sign_at_root(poly, root):
    """Exact sign of a rational quadratic at an isolated algebraic root."""
    poly = _trim(poly)
    if poly == (0,):
        return 0
    common = None
    while root.low != root.high:
        lower, upper = _quadratic_bounds(poly, root.low, root.high)
        if lower > 0:
            return 1
        if upper < 0:
            return -1
        if common is None:
            common = _gcd(root.poly, poly)
        if _has_root(common, root.low, root.high):
            return 0
        root.refine()
    value = _evaluate(poly, root.low)
    return (value > 0) - (value < 0)


def _earlier(left, right):
    """Compare exact roots from potentially different contact polynomials."""
    common = None
    while True:
        if left.high < right.low:
            return True
        if left.low > right.high:
            return False
        if left.low == left.high and right.low == right.high:
            return left.low < right.low
        if common is None:
            common = _gcd(left.poly, right.poly)
        low, high = max(left.low, right.low), min(left.high, right.high)
        if low == high:
            # An isolation interval excludes its lower endpoint. A different
            # root of the same polynomial may sit exactly on that endpoint.
            contains_left = left.low == left.high == low or left.low < low <= left.high
            contains_right = right.low == right.high == low or right.low < low <= right.high
            if not (contains_left and contains_right):
                return left.high <= right.low
        if _has_root(common, low, high):
            return False
        left.refine()
        right.refine()


def _distance_polynomial(coordinates, half, half_rate, region, radius,half_quadratic=(0,0,0)):
    result = [-radius*radius] + [F(0)] * 4
    for poly, extent, rate, side,curve in zip(coordinates, half, half_rate, region,half_quadratic):
        if side == 0:
            continue
        offset = (poly[0] - side*extent, poly[1] - side*rate, poly[2]-side*curve)
        for i, left in enumerate(offset):
            for j, right in enumerate(offset):
                result[i+j] += left*right
    return _trim(result)


def earliest_moving_sphere_contact(origin, velocity, acceleration, radius, box,
                                   box_velocity, box_acceleration, duration_s,
                                   precision=50, *, box_size_rate_mps=(0, 0, 0),box_size_acceleration_mps2=(0,0,0)):
    """Return first closed-bounds contact during ``[0, duration_s]``, or None.

    ``box`` supplies ``part`` and ``bounds`` (lower/upper xyz). Zero extents are
    allowed, including finite ground with no invented thickness.
    Motion vectors are xyz world coordinates in metres and seconds, evaluated at
    the interval start. ``box_size_rate_mps`` gives each initial full-side
    length rate; optional ``box_size_acceleration_mps2`` gives its constant
    acceleration. These are full dimensions along the shape's local axes, not
    half-extents. An OrientedCuboid retains a fixed yaw over the interval and
    uses the same solver in its exact local frame. Sizes stay nonnegative
    throughout the interval; a zero dimension is a closed surface. Both
    accelerations remain constant for this interval;
    callers split at phase, velocity-law, pose, death and terrain boundaries.
    Contact roots are isolated using exact rational arithmetic, then narrowed
    to at most ``10**(-(precision-8))`` seconds. Decimal bounds are rounded
    outward. ``time_s`` and contact coordinates approximate that isolated root
    at the requested precision. Initial overlap/touch returns time zero.

    This helper does not select eligible bodies, add projectile gravity,
    clamp deceleration at zero speed, or decide damage/event ordering.
    """
    if isinstance(precision, bool) or not isinstance(precision, int) or precision < 40:
        raise ValueError('Moving contact precision must be at least 40 digits')
    if not getattr(box, 'part', None):
        raise ValueError('Moving contact requires a named bounds collider')
    if isinstance(box,OrientedCuboid):
        frame=box.frame
        result=earliest_moving_sphere_contact(
            frame.to_local_point(_vector(origin,'Projectile origin'),box.centre_m),
            frame.to_local_vector(_vector(velocity,'Projectile velocity')),
            frame.to_local_vector(_vector(acceleration,'Projectile acceleration')),radius,box.local_box,
            frame.to_local_vector(_vector(box_velocity,'Cuboid velocity')),
            frame.to_local_vector(_vector(box_acceleration,'Cuboid acceleration')),duration_s,precision,
            box_size_rate_mps=box_size_rate_mps,box_size_acceleration_mps2=box_size_acceleration_mps2)
        if result is None:return None
        with localcontext(Context(prec=precision,rounding=ROUND_HALF_EVEN)):
            return MovingSphereContact(box.part,result.time_s,
                decimal_point(frame.to_world_point(result.centre_m,box.centre_m)),
                decimal_point(frame.to_world_point(result.closest_box_point_m,box.centre_m)),
                result.time_lower_s,result.time_upper_s)
    try:
        lower, upper = box.bounds
    except (AttributeError, TypeError, ValueError) as error:
        raise ValueError('Moving contact requires lower and upper xyz bounds') from error
    lower, upper = _vector(lower, 'Lower bounds'), _vector(upper, 'Upper bounds')
    if any(a > b for a, b in zip(lower, upper)):
        raise ValueError('Collider lower bounds must not exceed upper bounds')
    initial_box_centre = tuple((a+b)/2 for a, b in zip(lower, upper))
    origin = _vector(origin, 'Projectile origin')
    velocity = _vector(velocity, 'Projectile velocity')
    acceleration = _vector(acceleration, 'Projectile acceleration')
    box_velocity = _vector(box_velocity, 'Cuboid velocity')
    box_acceleration = _vector(box_acceleration, 'Cuboid acceleration')
    size_rate = _vector(box_size_rate_mps, 'Cuboid size rate')
    size_acceleration = _vector(box_size_acceleration_mps2, 'Cuboid size acceleration')
    radius = _number(radius, 'Projectile radius')
    duration = _number(duration_s, 'Contact duration')
    if radius < 0 or duration < 0:
        raise ValueError('Radius and contact duration must be nonnegative')
    half = tuple((b-a)/2 for a, b in zip(lower, upper))
    half_rate = tuple(rate/2 for rate in size_rate)
    half_quadratic=tuple(a/4 for a in size_acceleration)
    if any(_quadratic_bounds((extent,rate,curve),F(0),duration)[0]<0
            for extent,rate,curve in zip(half,half_rate,half_quadratic)):
        raise ValueError('Collider dimensions must remain nonnegative throughout the interval')
    coordinates = tuple((p-c, v-bv, (a-ba)/2) for p, c, v, bv, a, ba in
                        zip(origin, initial_box_centre, velocity, box_velocity,
                            acceleration, box_acceleration))
    initial_distance = sum(max(abs(poly[0])-extent, F(0))**2
                           for poly, extent in zip(coordinates, half))
    earliest = None
    if initial_distance <= radius*radius:
        earliest = _Root((F(0), F(1)), ((F(0), F(1)), (F(1),)), F(0), F(0))
    elif duration == 0:
        return None
    else:
        regions = []
        for poly, extent, rate,curve in zip(coordinates, half, half_rate,half_quadratic):
            below = (poly[0]+extent, poly[1]+rate, poly[2]+curve)
            above = (poly[0]-extent, poly[1]-rate, poly[2]-curve)
            below_low, below_high = _quadratic_bounds(below, F(0), duration)
            above_low, above_high = _quadratic_bounds(above, F(0), duration)
            if above_low > radius or below_high < -radius:
                return None
            regions.append(tuple(side for side, possible in (
                (-1, below_low <= 0), (0, below_high >= 0 and above_low <= 0),
                (1, above_high >= 0)) if possible))
        for region in product(*regions):
            if region == (0, 0, 0):
                continue
            polynomial = _distance_polynomial(coordinates, half, half_rate, region, radius,half_quadratic)
            for root in _roots(polynomial, F(0), duration):
                valid = True
                for poly, extent, rate, side,curve in zip(coordinates, half, half_rate, region,half_quadratic):
                    lower = (poly[0]+extent, poly[1]+rate, poly[2]+curve)
                    upper = (poly[0]-extent, poly[1]-rate, poly[2]-curve)
                    if ((side <= 0 and _sign_at_root(lower, root) * (1 if side == -1 else -1) > 0)
                            or (side >= 0 and _sign_at_root(upper, root) * (-1 if side == 1 else 1) > 0)):
                        valid = False
                        break
                if valid and (earliest is None or _earlier(root, earliest)):
                    earliest = root
        if earliest is None:
            return None
    tolerance = F(1, 10**(precision-8))
    while earliest.high-earliest.low > tolerance:
        earliest.refine()
    with localcontext(Context(prec=precision, rounding=ROUND_HALF_EVEN)):
        def decimal(value):
            return Decimal(value.numerator) / Decimal(value.denominator)
        time = decimal((earliest.low+earliest.high)/2)
        centre = tuple(decimal(p) + decimal(v)*time + decimal(a)*time*time/2
                       for p, v, a in zip(origin, velocity, acceleration))
        box_centre = tuple(decimal(p) + decimal(v)*time + decimal(a)*time*time/2
                           for p, v, a in zip(initial_box_centre, box_velocity, box_acceleration))
        contact_half = tuple(decimal(h)+decimal(rate)*time+decimal(curve)*time*time if curve else
            decimal(h)+decimal(rate)*time if rate else decimal(h)
            for h,rate,curve in zip(half,half_rate,half_quadratic))
        closest = tuple(min(c+h, max(c-h, p))
                        for p, c, h in zip(centre, box_centre, contact_half))
        with localcontext() as context:
            context.rounding = ROUND_FLOOR
            lower = decimal(earliest.low)
            context.rounding = ROUND_CEILING
            upper = decimal(earliest.high)
        return MovingSphereContact(box.part, time, centre, closest, lower, upper)
