"""First whole-body separation for a projectile's birth-owner immunity.

This uses continuous interval enclosures, not observation/frame sampling.
The binary64 bounds have the same numerical scope as curved contact helpers;
an unresolved boundary fails explicitly instead of inventing an armed shot.
"""
from dataclasses import dataclass
from math import hypot, isfinite, sqrt

from combat_sim.models import UnsupportedMechanicError
from combat_sim.mechanics.kinematic_bounds import quadratic_range


@dataclass(frozen=True)
class Separation:
    time_lower_s: float
    time_upper_s: float


def _distance(point,low,high):
    return sqrt(sum(max(a-p,0.,p-b)**2 for p,a,b in zip(point,low,high)))


def first_owner_separation(trajectory,boxes,begin_s,end_s,*,time_tolerance_s=1e-12,
                            clearance_tolerance_m=1e-14,acceleration_bound_mps2=None):
    """Find first clearance from the union of moving/resizing owner cuboids.

    ``boxes`` contains (collider, velocity, acceleration, size_rate) at begin_s,
    optionally followed by full-size acceleration. Quadratic interior extrema
    participate in both dimension validation and interval containment.
    A positive clearance witness arms owner contact permanently. Closed touch
    remains immune until separation exceeds the existing numerical clearance
    tolerance. Returned times use the trajectory's own clock. A trajectory must
    expose at(t).position_m and a bound on its acceleration magnitude.
    """
    if any(isinstance(v,bool) for v in (begin_s,end_s,time_tolerance_s,clearance_tolerance_m,acceleration_bound_mps2,trajectory.radius_m)):
        raise ValueError('Owner-separation controls must be numeric')
    begin,end=float(begin_s),float(end_s)
    tolerance=float(time_tolerance_s)
    clearance=float(clearance_tolerance_m)
    bound=(float(acceleration_bound_mps2) if acceleration_bound_mps2 is not None
        else float(trajectory.gravity)+float(trajectory.deceleration))
    if (not all(isfinite(v) for v in (begin,end,tolerance,clearance,bound))
            or begin<0 or end<begin or tolerance<=0 or clearance<0 or bound<0):
        raise ValueError('Invalid owner-separation interval or tolerances')
    shapes=[]
    for item in boxes:
        if len(item) not in (4,5):raise ValueError('Owner cuboid needs box, velocity, acceleration, size rate and optional size acceleration')
        box,velocity,acceleration,size_rate=item[:4]
        size_acceleration=item[4] if len(item)==5 else (0,0,0)
        if any(isinstance(v,bool) for values in (*box.bounds,velocity,acceleration,size_rate,size_acceleration) for v in values):
            raise ValueError('Owner cuboid motion must be numeric')
        low,high=(tuple(map(float,v)) for v in box.bounds)
        velocity,acceleration,size_rate,size_acceleration=(tuple(map(float,v)) for v in (velocity,acceleration,size_rate,size_acceleration))
        invalid=(any(a>b or quadratic_range(b-a,r,q,0,end-begin)[0]<0 for a,b,r,q in zip(low,high,size_rate,size_acceleration))
            if any(size_acceleration) else any(a>b or b-a+r*(end-begin)<0 for a,b,r in zip(low,high,size_rate)))
        if (any(len(v)!=3 or not all(isfinite(x) for x in v) for v in (low,high,velocity,acceleration,size_rate,size_acceleration))
                or invalid):
            raise ValueError('Invalid owner cuboid motion')
        shapes.append((low,high,velocity,acceleration,size_rate,size_acceleration))
    if not shapes:
        return Separation(begin,begin)
    radius=float(trajectory.radius_m)
    if not isfinite(radius) or radius<0:
        raise ValueError('Projectile radius must be finite and nonnegative')

    def shape_at(shape,time):
        low,high,v,a,rate,change=shape
        dt=time-begin
        shift=tuple(x*dt+y*dt*dt/2 for x,y in zip(v,a))
        if any(change):
            delta=tuple(r*dt/2+q*dt*dt/4 for r,q in zip(rate,change))
            return (tuple(x+d-r for x,d,r in zip(low,shift,delta)),tuple(x+d+r for x,d,r in zip(high,shift,delta)))
        return (tuple(x+d-r*dt/2 for x,d,r in zip(low,shift,rate)),
            tuple(x+d+r*dt/2 for x,d,r in zip(high,shift,rate)))

    def gap(time):
        point=trajectory.at(time).position_m
        return min(_distance(point,*shape_at(shape,time))-radius for shape in shapes)

    def contained(left,right):
        """Prove every point in an interval remains near at least one box."""
        p,q=trajectory.at(left).position_m,trajectory.at(right).position_m
        for low,high,v,a,rate,change in shapes:
            def relative(point,time):
                dt=time-begin
                return tuple(x-y*dt-z*dt*dt/2 for x,y,z in zip(point,v,a))
            first,last=relative(p,left),relative(q,right)
            margin=(bound+hypot(*a))*(right-left)**2/8
            mins=tuple(min(x,y)-margin for x,y in zip(first,last))
            maxs=tuple(max(x,y)+margin for x,y in zip(first,last))
            # Intersection of endpoint boxes is contained in every intervening
            # linearly resized box in this relative frame.
            if any(change):
                delta=[float(quadratic_range(0,r/2,q/2,left-begin,right-begin)[0]) for r,q in zip(rate,change)]
                inner_low=tuple(x-d for x,d in zip(low,delta));inner_high=tuple(x+d for x,d in zip(high,delta))
            else:
                inner_low=tuple(max(x-r*(left-begin)/2,x-r*(right-begin)/2) for x,r in zip(low,rate))
                inner_high=tuple(min(x+r*(left-begin)/2,x+r*(right-begin)/2) for x,r in zip(high,rate))
            if any(x>y for x,y in zip(inner_low,inner_high)):
                continue
            farthest=sqrt(sum(max(a-x,0.,y-b)**2 for x,y,a,b in zip(mins,maxs,inner_low,inner_high)))
            if farthest-radius<=clearance:
                return True
        return False

    if gap(begin)>clearance:
        return Separation(begin,begin)
    pending=[(begin,end,0)]
    while pending:
        left,right,depth=pending.pop()
        if contained(left,right):
            continue
        outside=gap(right)>clearance
        if right-left<=tolerance and outside:
            return Separation(left,right)
        middle=(left+right)/2
        if middle in (left,right) or depth>=80:
            if outside:
                return Separation(left,right)
            raise UnsupportedMechanicError('Owner separation is unresolved at numerical precision')
        pending.append((middle,right,depth+1))
        pending.append((left,middle,depth+1))
    return None
