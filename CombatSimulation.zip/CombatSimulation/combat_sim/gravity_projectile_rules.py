"""Gravity-enabled persistent flights on the shared movement/combat timeline."""
from copy import deepcopy
from decimal import Decimal as D, ROUND_CEILING
from math import hypot
from fractions import Fraction as F

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import local_to_world_point
from combat_sim.mechanics.decelerating_aim import short_arc_decelerating_launch
from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.moving_gravity_collisions import moving_curve_contact
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.postures import pose_local_hand_position
from combat_sim.pose_kinematics import projectile_pose_acceleration,world_hand_point


class GravityProjectileRules:
    def setup_projectile_physics(self, definition):
        if not self.gravity_mode:
            if definition is not None:
                raise UnsupportedMechanicError('Projectile physics definitions require the gravity combat scope')
            return
        if definition is None:
            raise ValueError('Gravity combat requires an explicit projectile physics definition')
        self.confirm_curved_entry=definition.get('schema_version')==2
        fixed = {'schema_version': 2 if self.confirm_curved_entry else 1, 'aim': 'short_arc_current_torso_no_lead',
                 'deceleration': 'opposite_current_velocity', 'terminal_rule': 'inert_at_speed_floor'}
        if self.confirm_curved_entry:fixed['contact_refinement']='confirmed_entry_v2'
        numeric = ('gravity_mps2', 'max_step_s', 'relative_tolerance', 'absolute_tolerance',
                   'aim_position_tolerance_m', 'contact_time_tolerance_s',
                   'contact_clearance_tolerance_m', 'event_quantum_ms',
                   'speed_floor_mps', 'stop_time_tolerance_s')
        if set(definition) - set(fixed) - set(numeric) - {'authority'}:
            raise ValueError('Unknown projectile physics fields')
        if any(definition.get(k) != v for k, v in fixed.items()):
            raise UnsupportedMechanicError('Unsupported projectile physics model or timing rule')
        self.physics = {}
        for key in numeric:
            value = dec(definition[key])
            if not value.is_finite() or value <= 0 or isinstance(definition[key], bool):
                raise ValueError('Projectile physics controls must be finite and positive: '+key)
            self.physics[key] = value
        if self.physics['contact_time_tolerance_s']*1000 >= self.physics['event_quantum_ms']:
            raise ValueError('Contact bracket must be narrower than the event quantum')
        self.projectile_physics_definition = deepcopy(definition)
        self.gravity_trajectories = {}
        self.gravity_deferred_contacts = {}

    def gravity_numerics(self):
        return {'projectile_physics': self.projectile_physics_definition,
                'geometry': 'Rational body kinematics; binary64 adaptive RK4 curved projectile contacts',
                'projectile_precision': 'binary64, independent of combat Decimal precision',
                'event_times': 'Gathering/Recovery ceil ms; curved contacts ceil to event_quantum_ms; body contacts retain fractional ms',
                'error_limits': 'Trajectory refinement and contact brackets are numerical diagnostics, not certified ODE error bounds'}

    def _gravity_event_time(self, value):
        quantum = self.physics['event_quantum_ms']
        return (value/quantum).to_integral_value(rounding=ROUND_CEILING)*quantum

    def release_body_projectile(self, actor, action, ability, timing):
        if not self.gravity_mode:
            return super().release_body_projectile(actor, action, ability, timing)
        geometry = ability['projectile_geometry']
        if (geometry['shape'] != 'sphere' or geometry['aim'] != 'torso_centre' or
                geometry['origin'] != 'ability_start_hand'):
            raise UnsupportedMechanicError('Gravity projectile requires sphere/hand/torso geometry')
        hand = ability['hand_positions_m']['start'][geometry['origin_hand']]
        origin = tuple(map(dec,world_hand_point(self,actor,hand)))
        aim = tuple(map(dec,self.projectile_aim_point(action)))
        speed = dec(timing['projectile_speed_mps'])
        acceleration = dec(timing.get('projectile_acceleration_mps2', 0))
        radius = dec(geometry['radius_m'])
        if speed <= 0 or radius < 0 or acceleration > 0:
            raise ValueError('Gravity gun requires positive speed, nonnegative radius and nonpositive deceleration')
        aim_fallback=None
        if ability.get('execution_model') in ('binding_projectile','impact_binding_area','impact_area_projectile','poison_projectile','construct_projectile','hook_projectile'):
            aim,aim_fallback=self.projectile_system.limits.reachable_aim(ability,origin,aim,speed)
        controls = {key: float(self.physics[key]) for key in
                    ('gravity_mps2', 'max_step_s', 'relative_tolerance', 'absolute_tolerance')}
        launch = short_arc_decelerating_launch(origin, aim, speed,
            deceleration_mps2=-acceleration,
            position_tolerance_m=float(self.physics['aim_position_tolerance_m']), **controls)
        actual_velocity,accuracy=self.accuracy.release(actor,action,ability,launch.velocity_mps)
        trajectory = PersistentProjectileTrajectory(origin, actual_velocity,
            float((self.horizon-self.time)/1000), deceleration_mps2=-acceleration,
            speed_floor_mps=float(self.physics['speed_floor_mps']),
            stop_time_tolerance_s=float(self.physics['stop_time_tolerance_s']), **controls)
        flight = self.projectile_system.create(actor,action,ability,{
            'aim_target': action.target, 'released_at_ms': self.time,
            'trajectory_started_at_ms':self.time,'distance_offset_m':D(0),'origin_m': origin,
            'aim_point_m': aim, 'initial_velocity_mps': actual_velocity, 'radius_m': radius,
            **({'accuracy':accuracy} if accuracy is not None else {}),
            'initial_speed_mps': speed, 'acceleration_mps2': acceleration, 'status': 'in_flight',
            'aim_solver': {'branch': launch.branch, 'flight_time_s': launch.flight_time_s,
                'position_error_m': launch.position_error_m, 'refinement_error_m': launch.refinement_error_m,
                'trajectory_evaluations': launch.trajectory_evaluations,
                'conservative_horizon_s': launch.conservative_horizon_s,
                **({'accuracy_applied_after_compensation':True} if accuracy is not None else {}),
                **({'range_limited_aim':aim_fallback} if aim_fallback is not None else {})}})
        self.gravity_trajectories[flight['id']] = trajectory
        if trajectory.stopping_time_s is not None:
            flight['stops_at_ms'] = self._gravity_event_time(self.time+dec(trajectory.stopping_time_s)*1000)
            flight['stopping_time_bracket_s'] = trajectory.stopping_time_bracket_s
            # A confirmed impact in the same numerical tick consumes the shot
            # before the inert terminal event can discard it.
            self.projectile_system.schedule_stop(flight,priority=3)
        self.projectile_system.initialize_owner(flight)
        self.log('projectile_released', actor=actor.id, target=action.target, aim_target=action.target,
            ability=action.ability_id, action_id=action.id, projectile_id=flight['id'],
            origin_m=origin, aim_point_m=aim, radius_m=radius,
            initial_velocity_mps=actual_velocity, aim_solver=flight['aim_solver'],
            weapon_ready_at_ms=actor.ready[action.ability_id], ammo=actor.ammo.get(action.ability_id),
            contact_prediction='Immutable gravity trajectory checked against current moving bodies; no target lead')

    def mobile_flight_state(self, flight, time):
        if not self.gravity_mode:
            return super().mobile_flight_state(flight, time)
        trajectory = self.gravity_trajectories[flight['id']]
        state = trajectory.at(min(trajectory.duration, float((time-flight['trajectory_started_at_ms'])/1000)))
        speed = hypot(*state.velocity_mps)
        acceleration = tuple(-trajectory.deceleration*v/speed for v in state.velocity_mps) if speed else (0.,)*3
        acceleration = (*acceleration[:2], acceleration[2]-trajectory.gravity) if speed else acceleration
        return (tuple(map(dec, state.position_m)), tuple(map(dec, state.velocity_mps)),
                tuple(map(dec, acceleration)), dec(state.distance_m)+flight['distance_offset_m'])

    def next_mobile_projectile_contacts(self, end):
        if not self.gravity_mode:
            return super().next_mobile_projectile_contacts(end)
        contacts = []
        # Current body/pose derivatives are independent of the queried flight.
        # Keep this cache inside one read-only prediction call; no clock or
        # actor mutation can leak a stale value into a later event/query.
        kinematics_cache={}
        def kinematics(name,part):
            key=(name,part)
            if key not in kinematics_cache:
                kinematics_cache[key]=(self.blocking.kinematics(name,part,self.time),
                    projectile_pose_acceleration(self,name,part,self.time))
            return kinematics_cache[key]
        for flight in self.projectile_flights.values():
            if flight['status'] != 'in_flight':
                self.gravity_deferred_contacts.pop(flight['id'], None)
                continue
            limit=self.projectile_system.limits.boundary(flight,end)
            if limit is not None:contacts.append(limit)
            flight_end=limit[0] if limit is not None else end
            separation=self.projectile_system.clearance_boundary(flight,flight_end)
            if separation is not None:
                contacts.append(separation)
            deferred = self.gravity_deferred_contacts.pop(flight['id'], None)
            if deferred is not None:
                confirmed_at, absolute, payload = deferred
                target_live = (self.collider_system.registry.contact_live(payload,'projectiles',self.time)
                    if payload['collision_kind']=='terrain' else self.blocking.contact_live(payload)
                        if 'block_layer_id' in payload else self.fighters[payload['target']].hp>0
                        and self.life_cycles.target_matches(payload))
                if self.time >= confirmed_at and target_live and self.projectiles.live(payload):
                    # The previous advance reached this contact before a boundary.
                    # Keep the evidence even if a very brief grazing overlap has
                    # ended before its rounded event time. A prior interruption
                    # before confirmed_at invalidates the prediction instead.
                    if absolute <= end:
                        contacts.append((max(self.time, absolute), payload))
                    else:
                        self.gravity_deferred_contacts[flight['id']] = deferred
                    continue
            trajectory = self.gravity_trajectories[flight['id']]
            release = flight['trajectory_started_at_ms']
            begin_s = float((self.time-release)/1000)
            end_s = min(trajectory.duration, float((flight_end-release)/1000))
            if trajectory.stopping_time_s is not None:
                end_s = min(end_s, trajectory.stopping_time_s)
            if begin_s > end_s:
                continue
            found = []
            groups = self.projectile_system.groups(flight)
            for name, boxes, static in groups:
                for box in boxes:
                    ((bv,ba,offset,size_rate),(pose_accel,size_accel))=(
                        (((D(0),)*3,)*4,((D(0),)*3,)*2) if static else kinematics(name,box.part))
                    box_acceleration=tuple(a+b for a,b in zip(ba,pose_accel)) if any(pose_accel) else ba
                    box_velocity = tuple(v+o for v,o in zip(bv,offset))
                    angular_path=None
                    if not static and self.turns.active(name):
                        hit,angular_path=self.turns.curve_contact(name,box,trajectory,flight,begin_s,end_s,flight_end)
                    else:
                        hit = moving_curve_contact(trajectory, box, flight['radius_m'], begin_s, end_s,
                            box_velocity=box_velocity, box_acceleration=box_acceleration,box_size_rate_mps=size_rate,
                            box_size_acceleration_mps2=size_accel,
                            time_tolerance_s=float(self.physics['contact_time_tolerance_s']),
                            clearance_tolerance_m=float(self.physics['contact_clearance_tolerance_m']),
                            confirm_near_entry=self.confirm_curved_entry)
                    if hit is None:
                        continue
                    absolute = max(self.time, self._gravity_event_time(release+dec(hit.time_upper_s)*1000))
                    found.append((absolute, name, box.part, static, hit, box, box_velocity, box_acceleration,size_rate,size_accel,angular_path))
            if not found:
                continue
            absolute, name, part, static, hit, box, bv, ba,size_rate,size_accel,angular_path = min(found, key=lambda item: item[:3])
            centre, _, _, distance = self.mobile_flight_state(flight, absolute)
            elapsed = (absolute-self.time)/1000
            offset = tuple(v*elapsed+a*elapsed*elapsed/2 for v, a in zip(bv, ba))
            low, high = box.bounds
            if angular_path is not None:
                from combat_sim.angular_paths import RotatingBoxPath
                time=F(absolute)/1000
                shifted=(angular_path.at_time(max(angular_path.yaw.begin_s,min(angular_path.yaw.end_s,time)))
                         if isinstance(angular_path,RotatingBoxPath) else angular_path)
                from combat_sim.box_motion import closest_point
                surface=tuple(map(dec,closest_point(shifted,centre)))
            elif isinstance(box,OrientedCuboid):
                dimensions=tuple(dec(s)+r*elapsed+a*elapsed*elapsed/2 for s,r,a in zip(box.size_m,size_rate,size_accel))
                shifted=OrientedCuboid(box.part,tuple(dec(p)+q for p,q in zip(box.centre_m,offset)),dimensions,box.frame)
                surface=tuple(map(dec,shifted.closest_point(centre)))
            elif any(size_accel):
                extent_delta=tuple(r*elapsed/2+q*elapsed*elapsed/4 for r,q in zip(size_rate,size_accel))
                surface=tuple(min(dec(b)+d+e,max(dec(a)+d-e,p)) for a,b,d,e,p in zip(low,high,offset,extent_delta,centre))
            else:
                surface = tuple(min(dec(b)+d+r*elapsed/2, max(dec(a)+d-r*elapsed/2, p))
                    for a,b,d,p,r in zip(low,high,offset,centre,size_rate))
            payload = {**self.projectiles.link(flight),'target': name,'aim_target': flight['aim_target'],
                'component': 'projectile', 'collision_kind': 'terrain' if static else 'body',
                'distance_m': distance, 'location_m': surface, 'projectile_centre_m': centre,
                'radius_m': flight['radius_m'], 'hit_parts': [part], 'impact_time_ms': absolute,
                'trajectory_contact_bracket_s': [hit.time_lower_s, hit.time_upper_s]}
            if static:payload.update(self.collider_system.registry.contact_fields(name))
            else:
                payload.update(self.life_cycles.target_fields(name))
                payload.update(self.blocking.contact_fields(part))
            if absolute <= end:
                contacts.append((absolute, payload))
            else:
                self.gravity_deferred_contacts[flight['id']] = (
                    min(end, release+dec(hit.time_upper_s)*1000), absolute, payload)
        if not contacts:
            return None
        first = min(t for t, _ in contacts)
        return first, [p for t, p in contacts if t == first]
