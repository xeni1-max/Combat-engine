"""Immutable native-contact states; no movement or ability rules live here."""
from dataclasses import dataclass
from decimal import Decimal as D
from combat_sim.facing import record as facing_record


@dataclass(frozen=True)
class ContactActor:
    actor: str
    life_generation: int
    alive: bool
    facing: str
    reference_m: tuple
    body_origin_m: tuple
    velocity_mps: tuple
    maximum_hp: D
    hp: D
    armor: D
    shield: D
    status_resistance: D
    dyspnea: D
    disorientation: D
    instability: D
    actions: tuple

    def record(self):
        return dict(actor=self.actor,life_generation=self.life_generation,alive=self.alive,facing=facing_record(self.facing),
            reference_m=tuple(map(str,self.reference_m)),body_origin_m=tuple(map(str,self.body_origin_m)),
            velocity_mps=tuple(map(str,self.velocity_mps)),maximum_hp=str(self.maximum_hp),hp=str(self.hp),
            armor=str(self.armor),shield=str(self.shield),status_resistance=str(self.status_resistance),
            dyspnea=str(self.dyspnea),disorientation=str(self.disorientation),
            instability=str(self.instability),actions=tuple(dict(id=i,ability=a,kind=k,phase=p) for i,a,k,p in self.actions))


@dataclass(frozen=True)
class ContactLink:
    identity: str
    controller: str
    target: str
    controller_life: int
    target_life: int
    ability: str | None
    holding_action_id: int | None

    def record(self):
        return dict(id=self.identity,controller=self.controller,target=self.target,
            controller_life_generation=self.controller_life,target_life_generation=self.target_life,
            ability=self.ability,holding_action_id=self.holding_action_id)


@dataclass(frozen=True)
class ContactSurface:
    identity: str
    collision_revision: int
    tags: tuple
    hp: D | None
    permanent: bool

    def record(self):
        return dict(id=self.identity,collision_revision=self.collision_revision,tags=self.tags,
            hp=None if self.hp is None else str(self.hp),permanent=self.permanent)


@dataclass(frozen=True)
class NativeContact:
    first: str
    second: str
    normals: tuple
    pose_only: bool
    surface: ContactSurface | None

    def record(self):
        return dict(first=self.first,second=self.second,normals=tuple(tuple(map(str,n)) for n in self.normals),
            pose_only=self.pose_only,surface=None if self.surface is None else self.surface.record())


@dataclass(frozen=True)
class ContactObserver:
    identity: str
    actor: str
    life_generation: int
    scope: str
    action_id: int | None
    ability: str | None
    phases: tuple
    handler: object

    def record(self):
        return dict(id=self.identity,actor=self.actor,life_generation=self.life_generation,scope=self.scope,
            action_id=self.action_id,ability=self.ability,phases=self.phases)


@dataclass(frozen=True)
class ContactWave:
    identity: str
    time_ms: D
    contacts: tuple
    before: tuple
    after: tuple
    groups_before: tuple
    groups_after: tuple
    links_before: tuple
    links_after: tuple

    def record(self):
        return dict(id=self.identity,time_ms=str(self.time_ms),contacts=tuple(c.record() for c in self.contacts),
            after_stage='native_kinematics_before_outer_phase_settlement',
            before={s.actor:s.record() for s in self.before},after={s.actor:s.record() for s in self.after},
            groups_before=self.groups_before,groups_after=self.groups_after,
            links_before=tuple(l.record() for l in self.links_before),links_after=tuple(l.record() for l in self.links_after))


@dataclass(frozen=True)
class ContactDelivery:
    wave: ContactWave
    observer: ContactObserver
    contact_indices: tuple

    def record(self):
        return dict(wave_id=self.wave.identity,observer=self.observer.record(),contact_indices=self.contact_indices)


@dataclass(frozen=True)
class PreparedContactWave:
    owner: object
    identity: str
    time_ms: D
    contacts: tuple
    before: tuple
    groups: tuple
    links: tuple
    matches: tuple
