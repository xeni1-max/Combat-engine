"""Ground locomotion and combat advanced together on the shared event queue.

Ordinary pace is reduced by current instability. Commands are intents, and
movement Active occupies the same controlled-action slot as weapon actions.
Geometry-only historical scopes continue through their original path.
"""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.character_geometry import actor_body
from combat_sim.battle_models import BattleAction, ceil_ms, decimal_value as dec
from combat_sim.hitboxes import world_standing_cuboids
from combat_sim.mechanics.dyspnea import DyspneaContext, apply_action_dyspnea
from combat_sim.mechanics.stopping import calculate_stopping_slide
from combat_sim.mechanics.body_collision import CollisionCharacter, collide_characters, collide_static_obstacle
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite
from combat_sim.command_dispatch import IntentOutcome
from combat_sim.movement_contacts import first_box_contact
from combat_sim.pose_kinematics import pose_acceleration,pose_moving
from combat_sim.mechanics.support_geometry import grazing_vertical_departure
from combat_sim.mechanics.support_geometry import grazing_projected_departure
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.orientation import YawFrame
from combat_sim.box_motion import axis_motions,at_boundary,impact_normals
from combat_sim.spatial_motion import (SpatialMotionRules, CONTACT_TIME_EPS_MS,
    CONTACT_DISTANCE_EPS_M, CONTACT_SPEED_EPS_MPS, CONTACT_ACCEL_EPS_MPS2, contact_boundary_time)
from combat_sim.team_rules import TERRAIN_SCOPE


MOBILE_SCOPE = dict(TERRAIN_SCOPE, movement='grounded_combat',
                    hit_eligibility='moving_sphere_bodies',
                    projectile_motion='straight_piecewise_kinematic',
                    status_effects='integrated', attacks='slash_projectile')
GRAVITY_MOBILE_SCOPE = dict(MOBILE_SCOPE, projectile_motion='gravity_directional_deceleration')
EPS = D('1e-24')


class MovingCombatRules(SpatialMotionRules):
    def setup_mobile_combat(self, definition, effects):
        if definition is None or effects is None:
            raise ValueError('Moving combat requires movement and locomotion-effect definitions')
        if definition.get('stopping_rule') != 'instability_slide_only':
            raise UnsupportedMechanicError('Moving combat uses the confirmed instability slide')
        if effects.get('schema_version') != 1:
            raise ValueError('Unsupported combat locomotion definition version')
        contact_rule=effects.get('body_contact_response')
        if contact_rule is not None and (not isinstance(contact_rule,dict) or
                set(contact_rule)!={'mode','rapid_repeat_ms'} or contact_rule['mode']!='reference_contacts_v1'):
            raise UnsupportedMechanicError('Unsupported body contact response')
        self.closing_reference_contacts=contact_rule is not None
        self.contact_repeat_ms=finite(contact_rule['rapid_repeat_ms'],'Rapid contact window',positive=True) if contact_rule is not None else None
        anchors = ('self_effect_timing','dyspnea_capacity_check_timing','dyspnea_payment_timing')
        if any(effects.get(key) != 'active_start' for key in anchors):
            raise UnsupportedMechanicError('Locomotion costs and self statuses occur at Active start')
        if effects.get('walk_run_running_modifier') != 'source_or_destination':
            raise UnsupportedMechanicError('Walk/run self effects use either running endpoint')
        if (effects['stand_to_walk']['dyspnea_kind'] != 'none' or effects['stop']['dyspnea_kind'] != 'none' or
                effects['stop']['duration_uses'] != 'base_instability' or
                effects['stop']['instability_speed_penalty'] != 'not_applied_to_prescribed_slide'):
            raise UnsupportedMechanicError('Unsupported start-walking or special-stop rule')
        if (dec(effects['instability']['decay_per_ms']) != 1 or
                dec(effects['instability']['speed_floor_mps']) != 0 or
                dec(effects['instability']['speed_penalty_divisor']) <= 0):
            raise UnsupportedMechanicError('Integrated status decay is one/ms with zero speed floor')
        if definition.get('speed_curve') != 'linear_during_active':
            raise UnsupportedMechanicError('Ground pace transitions require linear Active curves')
        self.movement_definition = deepcopy(definition)
        self.combat_locomotion_definition = deepcopy(effects)
        self.motion = {}
        self.crouch_definition = self.sprint_definition = self.climb_definition = None
        for name, actor in self.fighters.items():
            if actor.profile_id not in definition['characters'] or actor.profile_id not in effects['characters']:
                raise UnsupportedMechanicError('Missing combat locomotion profile')
            values = definition['characters'][actor.profile_id]
            if any(dec(values[k]) <= 0 for k in ('walking_speed_mps','running_speed_mps','walk_run_active_ms','stopping_base_instability_per_mps')):
                raise ValueError('Ground movement speeds and durations must be positive')
            if any(dec(effects['characters'][actor.profile_id]['walk_run'][k]) < 0
                   for k in ('disorientation','instability','dyspnea_base_value')):
                raise ValueError('Movement costs and self effects cannot be negative')
            direction = self.scenario['encounter']['participants'][name].get(
                'movement_direction', actor.facing.forward[:2] if isinstance(actor.facing,YawFrame) else [1 if actor.facing == '+x' else -1, 0])
            if len(direction) != 2:
                raise ValueError('Movement direction needs two components')
            direction = tuple(map(dec, direction))
            length = sum(v*v for v in direction).sqrt()
            if not length:
                raise ValueError('Movement direction must be nonzero')
            self.motion[name] = {'mode':'standing', 'phase':None, 'speed':D(0),
                'acceleration':D(0), 'direction':tuple(v/length for v in direction),
                'revision':0, 'intents':[], 'jump':None, 'ground_origin_z':actor.body_origin_m[2]}
            actor.metrics.update(movement_commands=0, movement_actives_completed=0,
                jumps_started=0, landings=0, collision_stops=0, special_stops=0)
        for item in self.scenario['movement_script']:
            expected = {'actor','at_ms','action'} | ({'target'} if item.get('action')=='climb' else set())
            if set(item) != expected or item['actor'] not in self.fighters:
                raise ValueError('Movement intent requires actor, at_ms and action')
            if item.get('action')=='climb' and not isinstance(item['target'],str):
                raise ValueError('Climb target must be an object identity')
            when = dec(item['at_ms'])
            if when < 0 or when > self.horizon or when != ceil_ms(when):
                raise ValueError('Movement intent times must be integer ms within the horizon')
            allowed = ('walk','run','stop','sprint') if self.sprint_combat is not None else ('walk','run','stop')
            if self.jump_actions_enabled:
                allowed += ('jump',)
            if self.posture_combat is not None:
                allowed += ('crouch','stand')
            if self.climb_enabled:
                allowed += ('climb',)
            if item['action'] not in allowed:
                raise UnsupportedMechanicError('Unsupported integrated movement command: '+item['action'])
            self.push(when, 'movement_command', dict(item), priority=5)
        self.refresh_mobile_locomotion()
        self.validate_movement_scene()
        names = sorted(self.fighters)
        for i, name in enumerate(names):
            others = [b for key, boxes in self.body_terrain_colliders().items()
                      if key != self.terrain_definition['ground']['id'] for b in boxes]
            others += [b for other in names[i+1:] for b in self.world_bodies[other]]
            if any(first_box_contact(a,b,(0,0,0),(0,0,0),1) == 0
                   for a in self.world_bodies[name] for b in others):
                raise ValueError('Actors must start outside solid bodies and obstacles')

    def mobile_is_running(self, name):
        m = self.motion[name]
        return m['mode'] == 'running'

    def mobile_dyspnea_context(self, actor):
        m = self.motion[actor.id]
        pace = 'running' if m['mode'] == 'running' else ('walking' if m['mode'] == 'walking' else 'stationary')
        actions = actor.live_actions()
        return DyspneaContext(pace, disoriented=actor.disorientation > 0,
            unstable=actor.instability > 0, active=any(a.phase=='active' for a in actions),
            gathering=any(a.phase=='gathering' for a in actions),
            recovering=any(a.phase=='recovery' for a in actions))

    def mobile_kinematics(self, name):
        """Current actual speed/acceleration up to the next U or floor knot."""
        actor, m = self.fighters[name], self.motion[name]
        if actor.hp <= 0:
            return D(0), D(0)
        if m.get('imposed_velocity') is not None:
            return sum(v*v for v in m['imposed_velocity'][:2]).sqrt(),D(0)
        if m['phase'] == 'stopping_active':
            return max(D(0), m['speed']), m['acceleration']
        divisor = dec(self.combat_locomotion_definition['instability']['speed_penalty_divisor'])
        factor=self.ground_speed_multiplier(name)
        raw = m['speed']*factor - actor.instability/divisor
        acceleration = m['acceleration']*factor + (1000/divisor if actor.instability > 0 else 0)
        if raw < -EPS or (abs(raw) <= EPS and acceleration < 0):
            return D(0), D(0)
        return max(D(0), raw), acceleration

    def ground_speed_multiplier(self,name):
        bonuses=getattr(self,'ground_speed',None)
        return bonuses.factor(name) if bonuses is not None else D(1)

    def mobile_motion(self, name):
        m=self.motion[name]
        if m.get('imposed_velocity') is not None and self.fighters[name].hp>0:
            return m['imposed_velocity'],(D(0),)*3
        speed, acceleration = self.mobile_kinematics(name)
        direction = self.motion[name]['direction']
        base=tuple(v*speed for v in direction)+(D(0),)
        inertia=m.get('distance_inertial_velocity',(D(0),)*3)
        return tuple(v+i for v,i in zip(base,inertia)), tuple(v*acceleration for v in direction)+(D(0),)

    def mobile_contact_velocity(self,name,seconds):
        """Translation velocity at a candidate contact, including endpoint rules."""
        velocity,acceleration = self.mobile_motion(name)
        return tuple(v+a*seconds for v,a in zip(velocity,acceleration))

    def next_mobile_knot(self, end):
        finish = end
        divisor = dec(self.combat_locomotion_definition['instability']['speed_penalty_divisor'])
        for name, actor in self.fighters.items():
            if actor.hp <= 0:
                continue
            if self._airborne(name):
                continue
            m = self.motion[name]
            if m.get('imposed_velocity') is not None:continue
            if m['phase'] == 'stopping_active':
                continue
            if actor.instability:
                finish = min(finish, self.time+actor.instability)
            factor=self.ground_speed_multiplier(name)
            raw = m['speed']*factor-actor.instability/divisor
            acceleration = m['acceleration']*factor+(1000/divisor if actor.instability else 0)
            if acceleration:
                crossing = -raw/acceleration*1000
                if crossing > EPS:
                    finish = min(finish, self.time+crossing)
        return finish

    def advance_mobile_geometry(self, begin, end):
        seconds = (end-begin)/1000
        for name, actor in self.fighters.items():
            m = self.motion[name]
            velocity, acceleration = self.mobile_motion(name)
            xy = tuple(dec(p)+v*seconds+a*seconds*seconds/2
                       for p,v,a in zip(actor.position_m,velocity,acceleration))
            actor.position_m = xy
            actor.body_origin_m = (*xy,m['ground_origin_z'])
            self.world_bodies[name] = world_standing_cuboids(actor_body(self,name), actor.body_origin_m, actor.facing)
            if actor.hp > 0:
                m['speed'] = max(D(0), m['speed']+m['acceleration']*seconds)

    def refresh_mobile_locomotion(self):
        for name, actor in self.fighters.items():
            m = self.motion[name]
            speed, _ = self.mobile_kinematics(name)
            velocity, _ = self.mobile_motion(name)
            actor.locomotion = {'mode':m['mode'], 'phase':m['phase'],
                'speed_mps':str(speed), 'nominal_speed_mps':str(m['speed']),
                'velocity_mps':[str(v) for v in velocity],
                'height_above_ground_m':'0', 'grounded':True}
            if m.get('imposed_velocity') is not None:
                actor.locomotion['motion_driver']='imposed'

    def process_mobile_event(self,kind,payload):
        if kind=='movement_contact':
            contacts = self.revalidate_mobile_contacts(payload)
            if contacts:
                return self.resolve_mobile_contacts(contacts)
            return
        raise RuntimeError('Unknown integrated movement event: '+kind)

    def try_ground_step(self,actor,step):
        m = self.motion[actor.id]
        profile = self.movement_definition['characters'][actor.profile_id]
        target = {'walk':dec(profile['walking_speed_mps']), 'run':dec(profile['running_speed_mps']), 'stop':D(0)}[step]
        target_mode = {'walk':'walking','run':'running','stop':'standing'}[step]
        if m.get('imposed_velocity') is None and not any(m.get('distance_inertial_velocity',(0,0,0))) and ((step=='stop' and m['speed']==0) or (m['mode']==target_mode and m['speed']==target)):
            if step=='stop':
                m['mode']='standing'
            self.log('movement_command_no_change',actor=actor.id,action=step)
            return IntentOutcome.CONSUMED
        rules = self.combat_locomotion_definition
        base = rules['characters'][actor.profile_id]['walk_run']
        transition = step != 'stop' and m['mode'] != 'standing'
        cost = {'kind':'action', 'base_value':base['dyspnea_base_value']} if transition else {'kind':'none'}
        ready = self.resource_ready_time(actor, cost)
        if ready > self.time:
            if ready.is_finite():
                self.request_decision(actor.id, ready)
            self.log('movement_waiting_for_capacity', actor=actor.id, action=step, resume_at_ms=ready)
            return IntentOutcome.WAITING
        # Acquire this action's resources before its immediate payment. No
        # state/phase event can interleave with this atomic construction.
        action = BattleAction(next(self.action_ids),actor.id,actor.id,step,'locomotion',
            self.time,self.time,D(0),phase='active',active_end_ms=self.time)
        actor.current = action
        cap_disorientation=D(0)
        if cost['kind'] == 'action':
            payment = self.action_payment(actor,action,cost['base_value'])
            actor.dyspnea = dec(payment.after)
            actor.metrics['dyspnea_paid'] += dec(payment.action_value)
            if payment.reached_maximum:
                cap_disorientation=dec(payment.disorientation_trigger)
                actor.disorientation += cap_disorientation
                self.log('maximum_dyspnea_trigger', actor=actor.id, added_disorientation=dec(payment.disorientation_trigger))
            self.log('dyspnea_paid', actor=actor.id, ability=step, action_kind='locomotion',
                phase='active_start', before=dec(payment.before), amount=dec(payment.action_value), after=actor.dyspnea,
                **({'action_id':action.id} if actor.action_registry is not None else {}))
        running = self.mobile_is_running(actor.id)
        speed = self.mobile_kinematics(actor.id)[0]
        if m.get('imposed_velocity') is not None or m.get('distance_inertial_velocity') is not None:
            velocity=m['imposed_velocity'] if m.get('imposed_velocity') is not None else self.free_mobile_motion(actor.id)[0]
            m.pop('imposed_velocity',None);m.pop('distance_inertial_velocity',None)
            m.pop('distance_force_driven',None)
            speed=sum(v*v for v in velocity[:2]).sqrt()
            if speed:m['direction']=tuple(v/speed for v in velocity[:2])
            m['speed']=(speed+actor.instability/dec(rules['instability']['speed_penalty_divisor']))/self.ground_speed_multiplier(actor.id) if speed else D(0)
        if step == 'stop':
            slide = calculate_stopping_slide(speed, actor.profile['max_hp'], actor.armor, profile, precision=self.precision)
            duration = dec(slide.duration_ms)
            additions = {k:dec(rules['stop'][k+'_per_mps'])*speed for k in ('disorientation','instability')}
            m.update(speed=slide.initial_slide_speed_mps, acceleration=slide.acceleration_mps2,
                     phase='stopping_active', target_mode='standing', target_speed=D(0))
            actor.metrics['special_stops'] += 1
            self.log('special_stop_started', actor=actor.id, original_speed_mps=speed,
                slide_distance_m=slide.distance_m, slide_duration_ms=duration)
        else:
            duration = dec(profile['walk_run_active_ms']) if transition else target*dec(profile['stopping_base_instability_per_mps'])
            additions = {k:dec(base[k]) if transition else dec(rules['stand_to_walk'][k])
                         for k in ('disorientation','instability')}
            running = running or step == 'run'
            m.update(acceleration=(target-m['speed'])/(duration/1000), phase='transition_active',
                     target_mode='walking' if step == 'walk' else 'running', target_speed=target)
        factor = dec(rules['running_self_effect_multiplier']) if running else D(1)
        for status, value in additions.items():
            setattr(actor, status, getattr(actor,status)+value*factor)
        self.extend_parallel_gatherings(actor,additions['disorientation']*factor+cap_disorientation,action.id)
        action.active_ms=duration
        action.active_end_ms=self.time+duration
        self.refresh_mobile_locomotion()
        self.log('movement_active_started', actor=actor.id, action=step, action_id=action.id,
            active_end_ms=action.active_end_ms, self_effects={k:v*factor for k,v in additions.items()},
            nominal_target_speed_mps=m['target_speed'])
        self._schedule_phase(action,'active_completed',action.active_end_ms)
        return IntentOutcome.STARTED

    def complete_mobile_action(self, actor):
        m = self.motion[actor.id]
        command, action_id = actor.current.ability_id, actor.current.id
        m.update(mode=m['target_mode'],speed=m['target_speed'],acceleration=D(0),phase=None)
        actor.current = None
        actor.metrics['movement_actives_completed'] += 1
        self.refresh_mobile_locomotion()
        self.log('movement_active_completed',actor=actor.id,action=command,action_id=action_id,state=actor.record())
        self.request_decision(actor.id,self.time)

    def cancel_mobile_motion(self, actor):
        if actor.id not in self.motion:
            return
        m = self.motion[actor.id]
        m.pop('distance_inertial_velocity',None);m.pop('distance_force_driven',None)
        m.pop('imposed_velocity',None)
        m.update(mode='standing',phase=None,speed=D(0),acceleration=D(0),intents=[])
        m['revision'] += 1
        self.refresh_mobile_locomotion()

    def next_mobile_contacts(self, end):
        # Search through endpoint roundoff, then classify against the known
        # boundary. Never let an observation partition choose phase ordering.
        seconds = (end-self.time+CONTACT_TIME_EPS_MS)/1000
        contacts = []
        names = [n for n in sorted(self.fighters) if self.fighters[n].hp > 0]
        # This query does not advance or resolve motion. Each actor/part has
        # one current derivative throughout all pair tests; cache only here,
        # so a later query at the same clock still sees intervening changes.
        motion_cache,pose_cache={},{}
        def motion(name):
            if name not in motion_cache:motion_cache[name]=self.mobile_motion(name)
            return motion_cache[name]
        def part_pose(name,part):
            key=(name,part)
            if key not in pose_cache:
                offset,rate=self.pose_part_motion(name,part,self.time)
                acceleration,size_acceleration=pose_acceleration(self,name,part,self.time)
                pose_cache[key]=(offset,rate,acceleration,size_acceleration)
            return pose_cache[key]
        def check(a,b,left,right,velocity,acceleration):
            if self.turns.active(a) or b in self.fighters and self.turns.active(b):
                contacts.extend(self.turns.pair_contacts(a,b,left,right,end))
                return
            for box in left:
                offset,left_rate,pose_a,left_accel=part_pose(a,box.part)
                for other in right:
                    other_offset,right_rate,pose_b,right_accel=(part_pose(b,other.part) if b in self.motion
                        else ((D(0),)*3,)*4)
                    relative = tuple(v+x-y for v,x,y in zip(velocity,offset,other_offset))
                    relative_acceleration=(tuple(v+x-y for v,x,y in zip(acceleration,pose_a,pose_b))
                        if any(pose_a) or any(pose_b) else acceleration)
                    half_rate = tuple((x+y)/2 for x,y in zip(left_rate,right_rate))
                    half_accel=tuple((x+y)/2 for x,y in zip(left_accel,right_accel))
                    oriented=isinstance(box,OrientedCuboid) or isinstance(other,OrientedCuboid)
                    deforming=oriented and (any(left_rate) or any(right_rate) or any(left_accel) or any(right_accel))
                    if not any(relative) and not any(relative_acceleration) and not any(half_rate) and not any(half_accel) and not deforming:
                        continue
                    t = first_box_contact(box,other,relative,relative_acceleration,seconds,
                        left_size_rate_mps=left_rate,right_size_rate_mps=right_rate,
                        left_size_acceleration_mps2=left_accel,right_size_acceleration_mps2=right_accel,
                        allow_flat_static_right=self.terrain_support.finite_ground and b==self.terrain_definition['ground']['id'],
                        contact_resolution=(CONTACT_DISTANCE_EPS_M,CONTACT_SPEED_EPS_MPS,CONTACT_ACCEL_EPS_MPS2)
                            if self.body_support.ready else None)
                    if t is not None:
                        if oriented:
                            projected=axis_motions(box,other,relative,relative_acceleration,
                                first_size_rate=left_rate,second_size_rate=right_rate,
                                first_size_acceleration=left_accel,second_size_acceleration=right_accel)
                        else:
                            delta = tuple(dec(x)-dec(y)+v*t+q*t*t/2
                                for x,y,v,q in zip(box.centre_m,other.centre_m,relative,relative_acceleration))
                            half = tuple((dec(x)+dec(y))/2+r*t+q*t*t/2 for x,y,r,q in zip(box.size_m,other.size_m,half_rate,half_accel))
                            axes = [i for i in range(3) if abs(abs(delta[i])-half[i]) < CONTACT_DISTANCE_EPS_M]
                            if not axes:
                                raise RuntimeError('Contact has no touching surface; overlapping solids')
                            normals = [tuple(D(1 if delta[i] >= 0 else -1) if i==j else D(0) for j in range(3)) for i in axes]
                        # At a completed pose's exact endpoint, deformation
                        # stops. An exact ceiling fit is not a new impact.
                        contact_offset=tuple(v+q*t for v,q in zip(offset,pose_a)) if any(pose_a) else offset
                        contact_left_rate=tuple(v+q*t for v,q in zip(left_rate,left_accel)) if any(left_accel) else left_rate
                        contact_other_offset=tuple(v+q*t for v,q in zip(other_offset,pose_b)) if any(pose_b) else other_offset
                        contact_right_rate=tuple(v+q*t for v,q in zip(right_rate,right_accel)) if any(right_accel) else right_rate
                        for name,is_left in ((a,True),(b,False)):
                            pose = self.motion[name].get('pose_transition') if name in self.motion else None
                            if pose is not None and abs(self.time+t*1000-pose['start_ms']-pose['duration_ms']) <= EPS:
                                if is_left:
                                    contact_offset=contact_left_rate=(D(0),)*3
                                else:
                                    contact_other_offset=contact_right_rate=(D(0),)*3
                        left_velocity = self.mobile_contact_velocity(a,t)
                        right_velocity = self.mobile_contact_velocity(b,t) if b in self.motion else (D(0),)*3
                        at_velocity = tuple(v-w+x-y for v,w,x,y in
                            zip(left_velocity,right_velocity,contact_offset,contact_other_offset))
                        contact_half_rate = tuple((x+y)/2 for x,y in zip(contact_left_rate,contact_right_rate))
                        if oriented:
                            boundary=at_boundary(projected,t,box,other,at_velocity,relative_acceleration,
                                first_size_rate=contact_left_rate,second_size_rate=contact_right_rate,
                                first_size_acceleration=left_accel,second_size_acceleration=right_accel)
                            normals=[tuple(map(dec,n)) for n in impact_normals(boundary,
                                distance_epsilon=CONTACT_DISTANCE_EPS_M,speed_epsilon=CONTACT_SPEED_EPS_MPS,
                                acceleration_epsilon=CONTACT_ACCEL_EPS_MPS2)]
                            if not normals:continue
                            if any(n[2] for n in normals) and grazing_projected_departure(boundary,0,
                                    distance_epsilon=CONTACT_DISTANCE_EPS_M,speed_epsilon=CONTACT_SPEED_EPS_MPS,
                                    acceleration_epsilon=CONTACT_ACCEL_EPS_MPS2):continue
                        if (not oriented and self.body_support.ready and (b in self.fighters or self.terrain_support.enabled) and any(n[2] for n in normals) and
                                grazing_vertical_departure(delta,half,at_velocity,contact_half_rate,
                                    distance_epsilon=CONTACT_DISTANCE_EPS_M,speed_epsilon=CONTACT_SPEED_EPS_MPS,
                                    relative_acceleration=relative_acceleration,half_size_acceleration=half_accel,
                                    acceleration_epsilon=CONTACT_ACCEL_EPS_MPS2)):
                            continue
                        # A rounded contact position can lie microscopically
                        # inside a face. Persistent rest/tangency is not a new
                        # impact; require renewed inward speed or acceleration.
                        closing = oriented
                        for normal in normals:
                            if oriented:break
                            rate = sum(v*n-r*abs(n) for v,n,r in zip(at_velocity,normal,contact_half_rate))
                            change = sum(q*n-h*abs(n) for q,h,n in zip(relative_acceleration,half_accel,normal))
                            closing |= rate < -CONTACT_SPEED_EPS_MPS or (
                                abs(rate) <= CONTACT_SPEED_EPS_MPS and change < -CONTACT_ACCEL_EPS_MPS2)
                        if not closing:
                            continue
                        payload={'first':a,'second':b,'normals':normals}
                        if b not in self.fighters:
                            payload.update(self.collider_system.registry.contact_fields(b))
                            if any(n[2]>0 for n in normals):
                                reference=self.motion[a].get('body_reference_z',self.fighters[a].body_origin_m[2])
                                local_bottom=(dec(box.bounds[0][2])-dec(reference)+(offset[2]-left_rate[2]/2)*t
                                    +(pose_a[2]-left_accel[2]/2)*t*t/2)
                                payload.update(support_part=other.part,support_body_part=box.part,
                                    support_reference_z_m=dec(other.bounds[1][2])-local_bottom)
                        contacts.append((contact_boundary_time(self.time+t*1000,end),payload))
        for i,name in enumerate(names):
            va, aa = motion(name)
            if any(va) or any(aa) or pose_moving(self,name):
                for key, boxes in self.body_terrain_colliders().items():
                    if key != self.terrain_definition['ground']['id'] or self.terrain_support.finite_ground:
                        check(name,key,self.world_bodies[name],boxes,va,aa)
            for other in names[i+1:]:
                vb, ab = motion(other)
                check(name,other,self.world_bodies[name],self.world_bodies[other],
                      tuple(x-y for x,y in zip(va,vb)),tuple(x-y for x,y in zip(aa,ab)))
        if not contacts:
            return None
        first = min(t for t,_ in contacts)
        grouped = {}
        for time,c in contacts:
            if abs(time-first) <= CONTACT_TIME_EPS_MS:
                key = (c['first'],c['second'])
                group=grouped.setdefault(key,{'first':key[0],'second':key[1],'normals':set()})
                group['normals'].update(c['normals'])
                if c.get('angular_collision') and ('first_part' not in group or
                        (c['first_part'],c['second_part'])<(group['first_part'],group['second_part'])):
                    group.update({k:c[k] for k in ('angular_collision','first_part','second_part')})
                if 'collider_id' in c:group.update(self.collider_system.registry.contact_fields(c['collider_id']))
                if 'support_part' in c and ('support_part' not in group or
                        (c['support_part'],c['support_body_part'])<(group['support_part'],group['support_body_part'])):
                    for field in ('support_part','support_body_part','support_reference_z_m'):group[field]=c[field]
        return first,[dict(c,normals=sorted(c['normals'])) for _,c in sorted(grouped.items())]

    def reference_contact_closing(self,contact):
        """Pose expansion can touch material while the body travels away.

        Stop the deformation at that contact, without reflecting a separating
        reference velocity or giving a rigid joint an internal momentum kick.
        """
        a,b=contact['first'],contact['second'];va,aa=self.mobile_motion(a)
        vb,ab=self.mobile_motion(b) if b in self.fighters else ((D(0),)*3,)*2
        for normal in contact['normals']:
            rate=sum((x-y)*n for x,y,n in zip(va,vb,normal))
            change=sum((x-y)*n for x,y,n in zip(aa,ab,normal))
            if rate < -CONTACT_SPEED_EPS_MPS or (abs(rate)<=CONTACT_SPEED_EPS_MPS and change < -CONTACT_ACCEL_EPS_MPS2):return True
        return False

    def resolve_mobile_contacts(self, contacts):
        # Snapshot all statuses/velocities before simultaneous contact responses.
        snapshots = {name:CollisionCharacter(f.body_origin_m,self.mobile_motion(name)[0],
            f.profile['max_hp'],f.armor,self.target_status_resistance(f)) for name,f in self.fighters.items()}
        constraints, additions, accepted_contacts = {}, {}, []
        for contact in contacts:
            a,b = contact['first'],contact['second']
            if self.fighters[a].hp <= 0 or (b in self.fighters and self.fighters[b].hp <= 0):
                continue
            if 'collider_id' in contact and not self.collider_system.registry.contact_live(contact,'bodies',self.time):
                continue
            if contact.get('pose_only'):
                self.log('body_pose_contact',first=a,second=b,normals=contact['normals'],
                    response='deformation_stops_reference_motion_preserved')
                continue
            accepted_contacts.append(contact)
            if b in self.fighters:
                first=snapshots[a];second=snapshots[b]
                if contact.get('angular_collision'):
                    first=CollisionCharacter(first.centre_m,contact['first_contact_velocity_mps'],
                        first.max_hp,first.armor,first.status_resistance)
                    second=CollisionCharacter(second.centre_m,contact['second_contact_velocity_mps'],
                        second.max_hp,second.armor,second.status_resistance)
                response = collide_characters(first,second,precision=self.precision)
                responses = [(a,response.first),(b,response.second)]
                directions = [response.direction_unit]
            else:
                # At an exact edge/corner, use the sum of contacting face normals
                # for one status impulse; enforce every face separately below.
                normal = tuple(sum(n[i] for n in contact['normals']) for i in range(3))
                first=snapshots[a]
                if contact.get('angular_collision'):
                    first=CollisionCharacter(first.centre_m,contact['first_contact_velocity_mps'],
                        first.max_hp,first.armor,first.status_resistance)
                response = collide_static_obstacle(first,surface_normal=normal,precision=self.precision)
                responses = [(a,response.first)]
                directions = []
            for name,r in responses:
                constraints.setdefault(name,[]).extend(directions+contact['normals'])
                additions[name] = additions.get(name,D(0))+r.added_disorientation
            self.log('body_contact',first=a,second=b,relative_speed_mps=response.relative_speed_in_direction_mps,
                collision_direction=response.direction_unit,normals=contact['normals'],raw_status=response.first.raw_disorientation)
        for name in sorted(constraints):
            actor,m = self.fighters[name],self.motion[name]
            had_distance_inertia=m.pop('distance_inertial_velocity',None) is not None
            velocity = tuple(map(dec,snapshots[name].velocity_mps))
            basis = []
            for normal in constraints[name]:
                direction = tuple(map(dec,normal))
                for previous in basis:
                    dot = sum(v*n for v,n in zip(direction,previous))
                    direction = tuple(v-dot*n for v,n in zip(direction,previous))
                length = sum(v*v for v in direction).sqrt()
                if length > EPS:
                    basis.append(tuple(v/length for v in direction))
            for normal in basis:
                dot = sum(v*n for v,n in zip(velocity,normal))
                velocity = tuple(v-dot*n for v,n in zip(velocity,normal))
            before=tuple(map(dec,snapshots[name].velocity_mps))
            velocity=self.knock_motion.elastic_response(name,before,velocity,basis=basis)
            if self.knock_motion.elasticity(name):
                self.log('elastic_body_response',actor=name,elasticity=self.knock_motion.elasticity(name),
                    velocity_before_mps=before,velocity_after_mps=velocity,constraints=basis)
            if not self.grapple_links.joined(name):self.knock_motion.transport_components(name,basis)
            velocity = self.constrain_mobile_support(actor,velocity,basis)
            if m.get('imposed_velocity') is not None or had_distance_inertia:
                m['imposed_velocity']=(*velocity[:2],D(0))
            extra = self.apply_air_contact_velocity(actor,velocity,accepted_contacts)
            if extra is not None:
                actor.metrics['collision_stops'] += 1
                self.apply_target_status_additions(name,{k:additions[name]+extra[k]
                    for k in ('disorientation','instability')},actor.armor)
                continue
            speed = sum(v*v for v in velocity[:2]).sqrt()
            if speed < EPS:
                speed = D(0)
            if speed:
                m['direction'] = tuple(v/speed for v in velocity[:2])
            divisor = dec(self.combat_locomotion_definition['instability']['speed_penalty_divisor'])
            nominal = (speed+actor.instability/divisor)/self.ground_speed_multiplier(name) if speed else D(0)
            continuing_stop = (self.sprint_combat is not None and m['phase']=='stopping_active' and
                actor.current is not None and actor.current.kind=='locomotion' and
                actor.current.active_end_ms > self.time)
            if continuing_stop:
                # Contact removes normal travel without undoing the stop intent.
                # Decelerate surviving tangential slide to the original endpoint;
                # do not reapply penalties, charge sprint effort or subtract U.
                remaining = (actor.current.active_end_ms-self.time)/1000
                m.update(speed=speed,acceleration=-speed/remaining)
                self.log('stopping_slide_redirected',actor=name,speed_mps=speed,
                    active_end_ms=actor.current.active_end_ms)
            else:
                m.update(speed=nominal,acceleration=D(0),phase=None)
                if not speed:
                    m['mode'] = 'standing'
            if not continuing_stop and actor.current is not None and actor.current.kind == 'locomotion':
                self.log('movement_active_cancelled',actor=name,action_id=actor.current.id,reason='body_contact')
                self.note_action_cancelled(actor,actor.current,'body_contact')
                actor.current = None
                self.request_decision(name,self.time)
            actor.metrics['collision_stops'] += 1
            self.apply_target_status_additions(name,{'disorientation':additions[name],'instability':additions[name]},actor.armor)
            if self.sprint_combat is not None and actor.current is None:
                self.request_decision(name,self.time)
        self.refresh_mobile_locomotion()

    def advance_mobile(self,end):
        while self.time < end:
            self.settle_climb_constraints()
            self.distance_constraints.prepare()
            finish = self.next_mobile_knot(end)
            finish = self.bindings.prepare(finish)
            finish = self.continuous_effort.prepare(finish)
            finish = self.grapple_break.prepare(finish)
            finish = self.cooldown_system.prepare_interval(finish)
            finish = self.effect_system.prepare_interval(finish)
            finish = self.healing.prepare(finish)
            bodies = self.next_mobile_contacts(finish)
            shots = self.next_mobile_projectile_contacts(finish)
            owned = self.owned_contacts.next_contacts(finish)
            duplication = self.projectile_duplication.next_boundary(finish)
            leap = self.body_leaps.next_boundary(finish)
            if bodies is not None:
                finish = min(finish,bodies[0])
            if shots is not None:
                finish = min(finish,shots[0])
            if owned is not None:finish=min(finish,owned[0])
            if duplication is not None:finish=min(finish,duplication[0])
            if leap is not None:finish=min(finish,leap[0])
            self.advance_team(finish,one_interval=True)
            self.controlled_damage.settle()
            self.continuous_effort.settle()
            self.grapple_links.settle()
            self.grapple_casts.settle()
            self.bindings.settle()
            self.segment_fields.settle()
            if self.time < end:
                self.finish_team_deaths()
            self.refresh_mobile_locomotion()
            self.body_support.settle()
            self.validate_movement_scene()
            # A continuous HP/resource boundary may precede a projected contact.
            if self.time < finish:
                continue
            # Continuous resources can insert a new event at this boundary.
            scheduled = bool(self.queue and self.queue[0][0] <= self.time)
            if shots is not None and abs(shots[0]-self.time) <= EPS:
                for payload in shots[1]:
                    kind=payload.get('projectile_event','impact')
                    self.push(self.time,kind,payload)
                scheduled = True
            if duplication is not None and abs(duplication[0]-self.time)<=EPS:
                for payload in duplication[1]:self.projectile_duplication.enqueue(payload,self.time)
                scheduled=True
            if leap is not None and abs(leap[0]-self.time)<=EPS:
                for payload in leap[1]:self.push(self.time,'leap_vertical_gate',payload,priority=0)
                scheduled=True
            if owned is not None and abs(owned[0]-self.time)<=EPS:
                for payload in owned[1]:self.push(self.time,'owned_contact',payload,priority=1)
                scheduled=True
            if bodies is not None and abs(bodies[0]-self.time) <= EPS:
                self.push(self.time,'movement_contact',self.mobile_contact_payload(bodies[1]),priority=2)
                scheduled = True
            if scheduled:
                return

    def mobile_result(self):
        return {'movement_definition':self.movement_definition,
            'combat_locomotion_definition':self.combat_locomotion_definition,
            'movement_combat_scope':{'kind':'integrated_ground_combat',
                'actions':['walk','run','stop']+(['sprint'] if self.sprint_combat is not None else []),
                'gravity':'integrated' if self.gravity_mode else 'pending_integration','posture':'upright','facing':'fixed',
                'projectile_contact':'relative_curved_motion' if self.gravity_mode else 'relative_quadratic_motion',
                'contact_order':'phases_then_projectiles_then_body_contacts'}}
