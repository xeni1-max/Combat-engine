"""Persistent straight projectile flights against the current moving scene."""
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import local_to_world_point
from combat_sim.moving_projectiles import earliest_moving_sphere_contact
from combat_sim.models import UnsupportedMechanicError
from combat_sim.postures import pose_local_hand_position
from combat_sim.pose_kinematics import projectile_pose_acceleration,world_hand_point


class MovingProjectileRules:
    def release_body_projectile(self, actor, action, ability, timing):
        if not self.mobile_mode:
            return super().release_body_projectile(actor,action,ability,timing)
        geometry = ability['projectile_geometry']
        if (geometry['shape'] != 'sphere' or geometry['aim'] != 'torso_centre' or
                geometry['origin'] != 'ability_start_hand'):
            raise UnsupportedMechanicError('Moving projectile requires authored sphere/hand/torso geometry')
        hand = ability['hand_positions_m']['start'][geometry['origin_hand']]
        origin = tuple(map(dec,world_hand_point(self,actor,hand)))
        aim = tuple(map(dec,self.projectile_aim_point(action)))
        direction = tuple(b-a for a,b in zip(origin,aim))
        length = sum(v*v for v in direction).sqrt()
        if not length:
            raise UnsupportedMechanicError('Coincident projectile origin and aim')
        direction = tuple(v/length for v in direction)
        speed = dec(timing['projectile_speed_mps'])
        acceleration = dec(timing.get('projectile_acceleration_mps2',0))
        radius = dec(geometry['radius_m'])
        if speed <= 0 or radius < 0:
            raise ValueError('Invalid moving projectile speed or radius')
        actual,accuracy=self.accuracy.release(actor,action,ability,tuple(v*speed for v in direction))
        if accuracy is not None:direction=tuple(v/speed for v in actual)
        flight = self.projectile_system.create(actor,action,ability,{
            'aim_target':action.target,'released_at_ms':self.time,'trajectory_started_at_ms':self.time,
            'distance_offset_m':D(0),'origin_m':origin,
            'aim_point_m':aim,'direction':direction,'radius_m':radius,
            **({'accuracy':accuracy} if accuracy is not None else {}),
            'initial_speed_mps':speed,'acceleration_mps2':acceleration,'status':'in_flight'})
        if acceleration < 0:
            flight['stops_at_ms'] = self.time-speed/acceleration*1000
            self.projectile_system.schedule_stop(flight)
        self.projectile_system.initialize_owner(flight)
        self.log('projectile_released',actor=actor.id,target=action.target,aim_target=action.target,
            ability=action.ability_id,action_id=action.id,projectile_id=flight['id'],
            origin_m=origin,aim_point_m=aim,radius_m=radius,
            weapon_ready_at_ms=actor.ready[action.ability_id],ammo=actor.ammo.get(action.ability_id),
            contact_prediction='Recomputed against moving bodies at each kinematic boundary')

    def mobile_flight_state(self, flight, time):
        elapsed = (time-flight['trajectory_started_at_ms'])/1000
        v0,a = flight['initial_speed_mps'],flight['acceleration_mps2']
        distance = v0*elapsed+a*elapsed*elapsed/2
        speed = max(D(0),v0+a*elapsed)
        point = tuple(p+d*distance for p,d in zip(flight['origin_m'],flight['direction']))
        velocity = tuple(d*speed for d in flight['direction'])
        acceleration = tuple(d*a for d in flight['direction'])
        return point,velocity,acceleration,distance+flight['distance_offset_m']

    def next_mobile_projectile_contacts(self, end):
        contacts = []
        seconds = (end-self.time)/1000
        for flight in self.projectile_flights.values():
            if flight['status'] != 'in_flight':
                continue
            separation=self.projectile_system.clearance_boundary(flight,end)
            if separation is not None:
                contacts.append(separation)
            origin, velocity, acceleration, _ = self.mobile_flight_state(flight,self.time)
            found = []
            groups = self.projectile_system.groups(flight)
            for name,boxes,static in groups:
                for box in boxes:
                    bv,ba,offset,size_rate=(((D(0),)*3,)*4 if static else
                        self.blocking.kinematics(name,box.part,self.time))
                    pose_accel,size_accel=(((D(0),)*3,)*2 if static else
                        projectile_pose_acceleration(self,name,box.part,self.time))
                    box_acceleration=tuple(a+b for a,b in zip(ba,pose_accel)) if any(pose_accel) else ba
                    hit = earliest_moving_sphere_contact(origin,velocity,acceleration,flight['radius_m'],
                        box,tuple(v+o for v,o in zip(bv,offset)),box_acceleration,seconds,precision=self.precision,
                        box_size_rate_mps=size_rate,box_size_acceleration_mps2=size_accel)
                    if hit is not None:
                        found.append((hit.time_s,name,box.part,static,hit))
            if not found:
                continue
            # Closed contact ties use stable object/part identity; one projectile
            # is consumed by one collider, rather than duplicating damage.
            hit_time,name,part,static,hit = min(found,key=lambda item:(item[0],item[1],item[2]))
            absolute = self.time+hit_time*1000
            _,_,_,distance = self.mobile_flight_state(flight,absolute)
            payload = {**self.projectiles.link(flight),'target':name,'aim_target':flight['aim_target'],
                'component':'projectile','collision_kind':'terrain' if static else 'body',
                'distance_m':distance,'location_m':hit.closest_box_point_m,'projectile_centre_m':hit.centre_m,
                'radius_m':flight['radius_m'],'hit_parts':[part],'impact_time_ms':absolute}
            if static:payload.update(self.collider_system.registry.contact_fields(name))
            else:
                payload.update(self.life_cycles.target_fields(name))
                payload.update(self.blocking.contact_fields(part))
            contacts.append((absolute,payload))
        if not contacts:
            return None
        first = min(t for t,_ in contacts)
        return first,[p for t,p in contacts if abs(t-first) <= D('1e-24')]

    def live_body_projectile_payload(self, payload):
        if not self.mobile_mode:
            return super().live_body_projectile_payload(payload)
        if not self.projectiles.live(payload):
            return None
        flight = self.projectile_flights[payload['projectile_id']]
        if (payload['collision_kind'] == 'body' and self.fighters[payload['target']].hp <= 0
                and 'block_layer_id' not in payload):
            return None
        return self.projectile_system.collide(flight,payload)

    def stop_mobile_projectile(self, payload):
        if not self.projectiles.live(payload):
            return
        flight = self.projectile_flights[payload['projectile_id']]
        point,_,_,distance = self.mobile_flight_state(flight,self.time)
        self.projectiles.terminal(flight,'stopped',stopped_at_ms=self.time,stopped_location_m=point,
                      traveled_distance_m=distance)
        self.log('projectile_stopped',projectile_id=flight['id'],actor=flight['actor'],
                 location_m=point,traveled_distance_m=distance,creates_impact=False)

    def body_result(self):
        result = super().body_result()
        if self.mobile_mode:
            result['pending_projectiles'] = [f for f in self.projectile_flights.values() if f['status'] == 'in_flight']
        return result
