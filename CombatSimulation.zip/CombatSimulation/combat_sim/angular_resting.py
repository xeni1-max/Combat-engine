"""Lifetime of a fixed-normal contact token on saved rotating body paths.

Geometry only. These queries retire historical reference-plane eligibility;
they do not remove an obstacle, drop a link or provide a translation response.
"""
from decimal import Context,ROUND_CEILING,localcontext
from fractions import Fraction as F

from combat_sim.angular_paths import RotatingBoxPath
from combat_sim.angular_intervals import Jet,_poly,_all,_truth,bounded_cells
from combat_sim.angular_support import _geometry,_references,support_departure
from combat_sim.battle_models import decimal_value as dec
from combat_sim.box_motion import touching_normals
from combat_sim.orientation import scalar


def contact_departure(first,second,outward,begin_s,end_s,*,distance_epsilon,precision=50):
    """First departure from the current fixed-normal contact band.

    The supplied outward normal must remain an axis of a nonrotating shape,
    or be vertical. Tokens whose only normal provider rotates are retired by
    the caller instead of pretending their old world direction stays a face.
    """
    begin,end=map(scalar,(begin_s,end_s));eps=scalar(distance_epsilon);outward=tuple(map(scalar,outward))
    if len(outward)!=3 or eps<=0 or begin<0 or end<begin:raise ValueError('Invalid angular resting query')
    if outward[2]:
        return (support_departure(first,second,begin,end,distance_epsilon=eps,precision=precision) if outward[2]>0 else
                support_departure(second,first,begin,end,distance_epsilon=eps,precision=precision))
    for p in (first,second):
        if isinstance(p,RotatingBoxPath):p._validate_interval(begin,end)
    refs=tuple(tuple(x-y for x,y in zip(a,b)) for a,b in zip(_references(first,begin),_references(second,begin)))
    def face(p,sign):return p.vertical_face_coefficients(sign,begin) if isinstance(p,RotatingBoxPath) else (p.bounds[sign>0][2],0,0)
    vertical=tuple(tuple(x-y for x,y in zip(face(first,s),face(second,-s))) for s in (-1,1))
    def expressions(left,right):
        sa,na,ca=_geometry(first,left,right);sb,nb,cb=_geometry(second,left,right)
        delta=tuple(_poly(*p,left-begin,right-begin)+x-y for p,x,y in zip(refs,ca,cb))
        dot=lambda a,b:sum((x*y for x,y in zip(a,b)),Jet.lift(0))
        extent=lambda sizes,normals,n:sum((h*abs(dot(b,n)) for h,b in zip(sizes[:2],normals)),Jet.lift(0))*F(1,2)
        values=[]
        for n in (*na,*nb):
            half=extent(sa,na,n)+extent(sb,nb,n);projection=dot(delta,n)
            values.extend((half-projection+eps,half+projection+eps))
        low=_poly(*vertical[0],left-begin,right-begin);high=_poly(*vertical[1],left-begin,right-begin)
        values.extend((eps-low,eps+high))
        gap=extent(sa,na,outward)+extent(sb,nb,outward)-dot(delta,outward)
        return (*values,eps-gap,eps+gap)
    def classify(left,right):
        values=expressions(left,right);mid=(left+right)/2;middle=expressions(mid,mid)
        return _all(_truth(v,m,(right-left)/2) for v,m in zip(values,middle))
    def actual(time):
        a=first.at_time(time) if isinstance(first,RotatingBoxPath) else first
        b=second.at_time(time) if isinstance(second,RotatingBoxPath) else second
        return outward in touching_normals(a,b,distance_epsilon=eps,vertical_area=True)
    cells=bounded_cells(classify,actual,begin,end,precision=precision,preserve_initial=True,
        first_boundary_only=True,label='Angular resting contact')
    if not cells[0][1]:return begin
    if len(cells)<2:return None
    with localcontext(Context(prec=precision,rounding=ROUND_CEILING)):
        clock=F(dec((begin+F(cells[1][0]))*1000))/1000
    return min(end,clock)
