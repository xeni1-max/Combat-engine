"""Continuous column membership and fixed-cover boundaries for moving cuboids.

Fixed-heading boundaries come from rational polynomials. Saved yaw paths use
the shared angular interval backend. Both classify open exposure cells rather
than stepping time. Isolated tangencies add no heat.
"""
from decimal import Context,Decimal as D,ROUND_CEILING,localcontext
from fractions import Fraction as F
from itertools import product

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import as_fraction
from combat_sim.moving_projectiles import _roots, _trim
from combat_sim.mechanics.kinematic_bounds import quadratic_range
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.box_motion import axis_motions,footprint_contains
from combat_sim.angular_paths import RotatingBoxPath

TIME_EPS_S=D('1e-27')


def _value(poly,time):
    return sum((coefficient*time**power for power,coefficient in enumerate(poly)),F(0))


def _minus(poly,value):return _trim((poly[0]-value,*poly[1:]))


def _square_sum(polys,radius):
    result=[-radius*radius]+[F(0)]*4
    for poly in polys:
        for i,a in enumerate(poly):
            for j,b in enumerate(poly):result[i+j]+=a*b
    return _trim(result)


def _motion_bounds(item,duration):
    if len(item) not in (4,5):raise ValueError('Volume part needs geometry, velocity, acceleration, size rate and optional size acceleration')
    box,velocity,acceleration,size_rate=item[:4]
    size_acceleration=item[4] if len(item)==5 else (0,0,0)
    low,high=box.bounds
    velocity,acceleration,size_rate,size_acceleration=(tuple(map(as_fraction,v)) for v in (velocity,acceleration,size_rate,size_acceleration))
    if any(len(v)!=3 for v in (velocity,acceleration,size_rate,size_acceleration)):raise ValueError('Volume motion needs xyz vectors')
    lower=tuple((as_fraction(p),v-r/2,a/2-q/4) for p,v,a,r,q in zip(low,velocity,acceleration,size_rate,size_acceleration))
    upper=tuple((as_fraction(p),v+r/2,a/2+q/4) for p,v,a,r,q in zip(high,velocity,acceleration,size_rate,size_acceleration))
    invalid=(any(quadratic_range(b-a,r,q,0,duration)[0]<0 for a,b,r,q in zip(low,high,size_rate,size_acceleration))
        if any(size_acceleration) else any(_value(b,duration)<_value(a,duration) for a,b in zip(lower,upper)))
    if invalid:raise ValueError('Volume query cannot shrink a part below zero size')
    return lower,upper


def _swept_bounds(lower,upper,duration):
    """Exact enclosing faces, including interior acceleration/size extrema."""
    low=tuple(quadratic_range(p[0],p[1],2*p[2],0,duration)[0] for p in lower)
    high=tuple(quadratic_range(p[0],p[1],2*p[2],0,duration)[1] for p in upper)
    return low,high


def _column_reachable(lower,upper,point,radius,duration):
    low,high=_swept_bounds(lower[:2],upper[:2],duration)
    return sum((min(b,max(a,c))-c)**2 for a,b,c in zip(low,high,point))<=radius*radius


def _local_item(item):
    if len(item) not in (4,5):raise ValueError('Volume part needs geometry, velocity, acceleration, size rate and optional size acceleration')
    box,v,a,rate=item[:4];change=item[4] if len(item)==5 else (0,0,0)
    if isinstance(box,OrientedCuboid):
        return (box.local_box,box.frame.to_local_vector(v),box.frame.to_local_vector(a),rate,change),box.frame,box.centre_m
    return item,None,(F(0),)*3


def _world_polys(xy,frame,origin):
    if frame is None:return xy
    return tuple(tuple((origin[i] if k==0 else 0)+frame.right[i]*xy[0][k]+frame.forward[i]*xy[1][k]
        for k in range(3)) for i in (0,1))


def _local_xy_polys(xy,box):
    if not isinstance(box,OrientedCuboid):return xy,box.bounds[0][:2],box.bounds[1][:2]
    shifted=tuple((p[0]-box.centre_m[i],p[1],p[2]) for i,p in enumerate(xy))
    local=tuple(tuple(sum(basis[i]*shifted[i][k] for i in (0,1)) for k in range(3)) for basis in box.frame.basis[:2])
    return local,tuple(-v/2 for v in box.size_m[:2]),tuple(v/2 for v in box.size_m[:2])


def _oriented_column_cells(centre,radius,parts,blockers,duration,precision):
    """Same vertical-witness policy with real rotated footprints and cover."""
    shapes=[];polynomials=set()
    blockers=tuple(b for b in blockers if b.intersects_vertical_column(centre[:2],radius))
    for item in parts:
        local,frame,origin=_local_item(item);lower,upper=_motion_bounds(local,duration)
        point=frame.to_local_point(centre,origin) if frame is not None else centre
        if not _column_reachable(lower,upper,point,radius,duration):continue
        shapes.append((lower,upper,point,frame,origin))
        options=[(_minus(lower[i],point[i]),(F(0),),_minus(upper[i],point[i])) for i in (0,1)]
        for choices in product(*options):polynomials.add(_square_sum(choices,radius))
        witnesses=[(lower[i],(point[i],F(0),F(0)),upper[i]) for i in (0,1)]
        top=(upper[2][0]+origin[2],*upper[2][1:]) if frame is not None else upper[2]
        for blocker in blockers:
            for choices in product(*witnesses):
                world=_world_polys(choices,frame,origin)
                projected,lo,hi=_local_xy_polys(world,blocker)
                for i in (0,1):
                    for face in (lo[i],hi[i]):polynomials.add(_minus(projected[i],face))
            polynomials.add(_minus(top,blocker.bounds[1][2]))
    def eligible(time):
        for lower,upper,point,frame,origin in shapes:
            low,high=tuple(_value(p,time) for p in lower),tuple(_value(p,time) for p in upper)
            xy=tuple(min(b,max(a,c)) for a,b,c in zip(low[:2],high[:2],point[:2]))
            if sum((c-p)**2 for c,p in zip(point[:2],xy))>radius*radius:continue
            world=frame.to_world_point((*xy,0),origin) if frame is not None else (*xy,0)
            top=high[2]+origin[2] if frame is not None else high[2]
            if not any(footprint_contains(b,world,closed=False) and top<b.bounds[1][2] for b in blockers):return True
        return False
    return _partition(polynomials,eligible,duration,precision)


def _partition(polynomials,eligible,duration,precision,*,upper_boundaries=False):
    if not duration:return [(D(0),eligible(F(0)))]
    tolerance=F(1,10**(precision-8));end=dec(duration);cuts=[]
    for polynomial in sorted(polynomials):
        if len(polynomial)<=1:continue
        for root in _roots(polynomial,F(0),duration):
            while root.high-root.low>tolerance:root.refine()
            if upper_boundaries:
                # A contact-induced stop must retain actual closed overlap.
                # The midpoint may still be outside and lose contact as soon
                # as binding removes the approach velocity. Use the certified
                # upper bracket, rounded upward at the declared precision.
                with localcontext(Context(prec=precision,rounding=ROUND_CEILING)):
                    time=dec(root.high)
            else:time=dec((root.high+root.low)/2)
            if TIME_EPS_S<time<end-TIME_EPS_S:cuts.append(time)
    points=[D(0)]
    for time in sorted(cuts):
        if time-points[-1]>TIME_EPS_S:points.append(time)
    points.append(end);cells=[]
    for a,b in zip(points,points[1:]):
        state=eligible(as_fraction((a+b)/2))
        if not cells or cells[-1][1]!=state:cells.append((a,state))
    return cells


def column_cells(centre,radius,moving_parts,blockers,duration_s,*,precision=50,first_boundary_only=False):
    """Return (relative start seconds, eligible) for each open exposure cell.

    Parts are (box, velocity, acceleration, full-size-rate) at the query start,
    optionally followed by full-size acceleration.
    Blockers are fixed cuboids; the caller excludes the target object's own
    parts. The beam travels downward from above all geometry. A part's top
    witness is eligible iff it overlaps the column and its vertical ray is clear.
    """
    duration=as_fraction(duration_s);radius=as_fraction(radius)
    if duration<0 or radius<=0:raise ValueError('Column radius must be positive and duration nonnegative')
    centre=tuple(map(as_fraction,centre))
    if len(centre)!=3:raise ValueError('Column centre needs three coordinates')
    moving_parts,blockers=tuple(moving_parts),tuple(blockers)
    if any(isinstance(item,RotatingBoxPath) for item in moving_parts):
        from combat_sim.angular_volumes import angular_cells
        return angular_cells('column',moving_parts,duration,centre=centre,radius=radius,blockers=blockers,
            precision=precision,first_boundary_only=first_boundary_only)
    if any(item and isinstance(item[0],OrientedCuboid) for item in moving_parts) or any(isinstance(b,OrientedCuboid) for b in blockers):
        return _oriented_column_cells(centre,radius,moving_parts,blockers,duration,precision)
    shapes=[];polynomials=set()
    blockers=tuple(box for box in blockers if box.intersects_vertical_column(centre[:2],radius))
    for item in moving_parts:
        lower,upper=_motion_bounds(item,duration)
        if not _column_reachable(lower,upper,centre,radius,duration):continue
        shapes.append((lower,upper))
        options=[(_minus(lower[i],centre[i]),(F(0),),_minus(upper[i],centre[i])) for i in (0,1)]
        for choices in product(*options):polynomials.add(_square_sum(choices,radius))
        for blocker in blockers:
            lo,hi=blocker.bounds
            for i in (0,1):
                for face in (lower[i],upper[i]):
                    for value in (lo[i],hi[i]):polynomials.add(_minus(face,value))
            polynomials.add(_minus(upper[2],hi[2]))

    def eligible(time):
        for lower,upper in shapes:
            low=tuple(_value(p,time) for p in lower);high=tuple(_value(p,time) for p in upper)
            xy=tuple(min(b,max(a,c)) for a,b,c in zip(low[:2],high[:2],centre[:2]))
            if sum((c-p)**2 for c,p in zip(centre,xy))>radius*radius:continue
            if not any(all(a<p<b for a,p,b in zip(box.bounds[0][:2],xy,box.bounds[1][:2]))
                    and high[2]<box.bounds[1][2] for box in blockers):return True
        return False

    return _partition(polynomials,eligible,duration,precision)


def box_cells(fixed_parts,moving_parts,duration_s,*,precision=50,first_boundary_only=False):
    """Continuous union contact for fixed cuboids and quadratic/affine bodies.

    Closed persistent contact conducts. Isolated zero-duration tangencies do
    not create an open exposure cell. Multiple overlaps remain one recipient.
    """
    duration=as_fraction(duration_s)
    if duration<0:raise ValueError('Box duration must be nonnegative')
    if type(precision) is not int or precision<40:raise ValueError('Volume precision must be at least 40')
    fixed_parts,moving_parts=tuple(fixed_parts),tuple(moving_parts)
    if any(isinstance(item,RotatingBoxPath) for item in moving_parts):
        from combat_sim.angular_volumes import angular_cells
        return angular_cells('box',moving_parts,duration,fixed=fixed_parts,precision=precision,first_boundary_only=first_boundary_only)
    if any(isinstance(b,OrientedCuboid) for b in fixed_parts) or any(item and isinstance(item[0],OrientedCuboid) for item in moving_parts):
        pairs=[];polynomials=set()
        for item in moving_parts:
            local,_,_=_local_item(item);_motion_bounds(local,duration)
            box,v,a,rate=item[:4];change=item[4] if len(item)==5 else (0,0,0)
            for fixed in fixed_parts:
                rows=axis_motions(box,fixed,v,a,first_size_rate=rate,first_size_acceleration=change)
                gaps=tuple(gap for row in rows for gap in row.gaps())
                if any(quadratic_range(p[0],p[1],2*p[2],0,duration)[1]<0 for p in gaps):continue
                pairs.append(gaps)
                polynomials.update(_trim(p) for p in gaps)
        def eligible(time):return any(all(_value(p,time)>=0 for p in gaps) for gaps in pairs)
        return _partition(polynomials,eligible,duration,precision,upper_boundaries=True)
    fixed=tuple(box.bounds for box in fixed_parts);shapes=[];polynomials=set()
    for item in moving_parts:
        lower,upper=_motion_bounds(item,duration)
        swept_low,swept_high=_swept_bounds(lower,upper,duration)
        possible=tuple((low,high) for low,high in fixed if
            all(a<=d and c<=b for a,b,c,d in zip(swept_low,swept_high,low,high)))
        if not possible:continue
        shapes.append((lower,upper))
        for low,high in possible:
            for i in range(3):
                polynomials.add(_minus(lower[i],high[i]))
                polynomials.add(_minus(upper[i],low[i]))
    def eligible(time):
        return any(all(_value(lower[i],time)<=high[i] and _value(upper[i],time)>=low[i] for i in range(3))
            for lower,upper in shapes for low,high in fixed)
    return _partition(polynomials,eligible,duration,precision,upper_boundaries=True)


def sphere_cells(centre,radius,moving_parts,duration_s,*,precision=50,first_boundary_only=False):
    """Open cells of union overlap between a sphere and deforming cuboids.

    Each closest coordinate is a lower face, the sphere centre, or an upper
    face. All 27 combinations supply the complete quartic boundary candidates;
    the exact closest-point predicate classifies the intervening open cells.
    """
    centre=tuple(centre)
    if any(isinstance(v,bool) for v in (*centre,radius,duration_s)):
        raise ValueError('Sphere geometry requires finite numeric coordinates')
    centre=tuple(map(as_fraction,centre));radius=as_fraction(radius);duration=as_fraction(duration_s)
    if len(centre)!=3 or radius<=0 or duration<0:
        raise ValueError('Sphere needs xyz centre, positive radius and nonnegative duration')
    if type(precision) is not int or precision<40:raise ValueError('Volume precision must be at least 40')
    moving_parts=tuple(moving_parts)
    if any(isinstance(item,RotatingBoxPath) for item in moving_parts):
        from combat_sim.angular_volumes import angular_cells
        return angular_cells('sphere',moving_parts,duration,centre=centre,radius=radius,precision=precision,
            first_boundary_only=first_boundary_only)
    shapes=[];polynomials=set()
    for item in moving_parts:
        local,frame,origin=_local_item(item);lower,upper=_motion_bounds(local,duration)
        point=frame.to_local_point(centre,origin) if frame is not None else centre
        # Exact swept enclosure: distant bodies need no quartic candidates.
        # Include interior extrema, not just endpoints, so accelerating
        # flybys and changing part sizes cannot be rejected prematurely.
        swept_low,swept_high=_swept_bounds(lower,upper,duration)
        if sum((min(b,max(a,c))-c)**2 for a,b,c in zip(swept_low,swept_high,point))>radius*radius:
            continue
        shapes.append((lower,upper,point))
        options=[(_minus(lower[i],point[i]),(F(0),),_minus(upper[i],point[i])) for i in range(3)]
        for choices in product(*options):polynomials.add(_square_sum(choices,radius))
    def eligible(time):
        return any(sum((min(_value(b,time),max(_value(a,time),c))-c)**2
                       for a,b,c in zip(lower,upper,point))<=radius*radius
                   for lower,upper,point in shapes)
    return _partition(polynomials,eligible,duration,precision)
