"""Released spherical gas, recipient-life toxin memory and continuous HP dose."""
from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.damage_ledger import AffineHeatDose,PiecewiseDose,QuarticDose
from combat_sim.mechanics.dense_rk import integrate
from combat_sim.mechanics.poison import FORMULA,poison_coefficient
from combat_sim.models import UnsupportedMechanicError
from combat_sim.toxin_defenses import shield_view
from combat_sim.volume_geometry import TIME_EPS_S,sphere_cells
from combat_sim.world_colliders import finite

VOLUME_EXPIRED='poison_volume_expired'
EXPOSURE_EXPIRED='poison_exposure_expired'
EVENTS=frozenset((VOLUME_EXPIRED,EXPOSURE_EXPIRED))


@dataclass
class PoisonExposure:
    id: str
    source: EffectSource
    volume_id: str
    target: str
    target_life_generation: int
    toxicity: D
    created_at_ms: D
    reference_ms: D
    q_reference: D = D(0)
    exposed: bool = True
    revision: int = 0
    ended: bool = False
    ended_at_ms: D | None = None
    end_reason: str | None = None

    @property
    def slope(self):return D(1) if self.exposed else D(-1)

    @property
    def expiry(self):return None if self.exposed else self.reference_ms+self.q_reference*1000

    def q_at(self,time):
        if time<self.reference_ms:raise ValueError('Toxin observation precedes its current clock')
        return self.q_reference if self.ended else max(D(0),self.q_reference+self.slope*(time-self.reference_ms)/1000)

    def transition(self,time,exposed):
        self.q_reference=self.q_at(time);self.reference_ms=time;self.exposed=exposed;self.revision+=1

    def record(self,time):
        return {'id':self.id,'kind':'poison','actor':self.source.actor,'ability':self.source.ability,
            'action_id':self.source.action_id,'projectile_id':self.source.projectile_id,
            **self.source.life_record(),'volume_id':self.volume_id,'target':self.target,
            'target_life_generation':self.target_life_generation,'toxicity':self.toxicity,
            'created_at_ms':self.created_at_ms,'reference_ms':self.reference_ms,'q_reference':self.q_reference,
            'q_seconds':self.q_at(time),'exposed':self.exposed,'expiry':self.expiry,'revision':self.revision,
            'status':'ended' if self.ended else 'active','ended_at_ms':self.ended_at_ms,'end_reason':self.end_reason}


class PoisonVolumes:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'spherical_toxin_v1'} or not world.mobile_mode
                or not world.effect_system.enabled or not world.life_cycles.enabled or not world.shield_flow_enabled):
            raise UnsupportedMechanicError('Gas needs shared moving geometry, typed effects, actor lives and shield flow')
        self.ids=count(1);self.effect_ids=count(1)
        self.volumes={};self.effects={};self.members={};self.tracks={};self.caches={}

    def deploy(self,source,centre,*,radius_m,toxicity,duration_ms):
        """Accept a released source, including an already-dead source life.

        This shared API is independent of the future authored weapon controller.
        All validation precedes any world/queue/effect mutation.
        """
        if not self.enabled:raise UnsupportedMechanicError('Poison volumes are not selected')
        w=self.world
        if not isinstance(source,EffectSource) or source.life_generation is None:
            raise ValueError('Released gas requires its original source life identity')
        actor=w.fighters.get(source.actor)
        if actor is None or source.ability not in actor.profile['abilities']:
            raise ValueError('Gas must name an existing source and ability')
        lives=w.life_cycles.lives[source.actor]
        if not any(l['generation']==source.life_generation and l['born_at_ms']<=w.time for l in lives):
            raise ValueError('Gas source life does not exist')
        centre=tuple(map(dec,centre))
        if len(centre)!=3 or any(not p.is_finite() for p in centre):raise ValueError('Gas needs a finite xyz centre')
        radius=finite(radius_m,'Gas radius',positive=True);power=finite(toxicity,'Gas toxicity')
        duration=finite(duration_ms,'Gas duration',positive=True)
        identity='poison-volume:'+str(next(self.ids))
        row=dict(id=identity,source=source,centre_m=centre,radius_m=radius,toxicity=power,
            start_ms=w.time,expiry_ms=w.time+duration,active=True,revision=0)
        self.volumes[identity]=row;self.members[identity]=set()
        w.push(row['expiry_ms'],VOLUME_EXPIRED,{'id':identity,'revision':0})
        self.settle()
        w.log('poison_volume_deployed',volume=self.volume_record(row),autonomous=True)
        return identity

    def volume_record(self,row):
        source=row['source']
        return {k:deepcopy(v) for k,v in row.items() if k!='source'}|{
            'actor':source.actor,'ability':source.ability,'action_id':source.action_id,
            'projectile_id':source.projectile_id,**source.life_record(),
            'eligible_targets':sorted(self.members[row['id']])}

    def cells(self,row,target,seconds):
        parts,seconds=self.world.effect_system.field_motion(target,'actor',seconds)
        return self.world.effect_system.query_cache.query(sphere_cells,row['centre_m'],row['radius_m'],
            parts,seconds,precision=self.world.precision,first_boundary_only=True)

    def end(self,effect,reason):
        if effect.ended:return
        w=self.world;effect.q_reference=effect.q_at(w.time);effect.reference_ms=w.time
        if reason=='toxin_load_zero':effect.q_reference=D(0)
        effect.ended=True;effect.revision+=1;effect.ended_at_ms=w.time;effect.end_reason=reason
        w.healing.invalidate()
        w.log('poison_exposure_ended',effect_id=effect.id,target=effect.target,
            target_life_generation=effect.target_life_generation,reason=reason)

    def eligible(self,row,target,exposed):
        w=self.world;key=(row['id'],target);before=target in self.members[row['id']]
        effect=self.effects.get(self.tracks.get(key));actor=w.fighters[target]
        if exposed:
            # A due phase may reconcile membership before the zero timer is
            # dispatched. The physical expiry, rather than queue insertion
            # order, decides whether this is a new exposure episode.
            if effect is not None and not effect.ended and effect.expiry is not None and w.time>=effect.expiry:
                self.end(effect,'toxin_load_zero')
            if effect is not None and not effect.ended and effect.target_life_generation!=actor.life_generation:
                self.end(effect,'target_life_ended')
            if effect is None or effect.ended:
                effect=PoisonExposure('poison-effect:'+str(next(self.effect_ids)),row['source'],row['id'],target,
                    actor.life_generation,row['toxicity'],w.time,w.time)
                self.effects[effect.id]=effect;self.tracks[key]=effect.id
                w.healing.invalidate()
                w.log('poison_exposure_started',effect=effect.record(w.time),autonomous=True)
            elif not effect.exposed:
                effect.transition(w.time,True);w.healing.invalidate()
            self.members[row['id']].add(target)
        else:
            self.members[row['id']].discard(target)
            if effect is not None and not effect.ended and effect.exposed:
                effect.transition(w.time,False);w.healing.invalidate()
                if effect.expiry<=w.time:self.end(effect,'toxin_load_zero')
                else:w.push(effect.expiry,EXPOSURE_EXPIRED,{'id':effect.id,'revision':effect.revision})
        if before!=exposed:
            w.log('poison_exposure_entered' if exposed else 'poison_exposure_left',volume_id=row['id'],target=target,
                effect_id=effect.id,target_life_generation=effect.target_life_generation,q_seconds=effect.q_at(w.time))

    def retire_life(self,target,generation):
        if not self.enabled:return
        for effect in self.effects.values():
            if effect.target==target and effect.target_life_generation==generation:self.end(effect,'target_life_ended')
        for members in self.members.values():members.discard(target)

    def prepare_geometry(self,end,*,physical_only=False):
        if not self.enabled:return end
        w=self.world;finish=end
        active=[v for v in self.volumes.values() if v['active'] and v['expiry_ms']>w.time]
        if active:finish=w.effect_system.motion_limit(finish,physical_only=physical_only)
        for row in active:
            finish=min(finish,row['expiry_ms'])
        query_end=finish
        for row in active:
            for name,actor in sorted(w.fighters.items()):
                if actor.hp<=0:continue
                cells=self.cells(row,name,(query_end-w.time)/1000)
                self.eligible(row,name,cells[0][1])
                if len(cells)>1:finish=min(finish,w.time+cells[1][0]*1000)
        for effect in self.effects.values():
            if not effect.ended and effect.expiry is not None:finish=min(finish,effect.expiry)
        return finish

    def settle(self):
        if not self.enabled:return
        w=self.world
        for row in self.volumes.values():
            if not row['active'] or row['expiry_ms']<=w.time:continue
            for name,actor in sorted(w.fighters.items()):
                if actor.hp>0:self.eligible(row,name,self.cells(row,name,2*TIME_EPS_S)[0][1])

    def _coefficient(self,effect,resistance):
        return dec(poison_coefficient(effect.toxicity,resistance)) if effect.toxicity else D(0)

    def _ensure(self,effect,begin,end):
        w=self.world;actor=w.fighters[effect.target]
        resistance=dec(actor.profile['resistances']['toxin']);bonus=dec(actor.profile.get('shield_toxin_resistance_per_hp',0))
        key=(begin,effect.revision,resistance,bonus,actor.shield,w.shield_recovery[effect.target]._plan_generation)
        cached=self.caches.get(effect.id)
        if cached is not None and cached['key']==key and cached['end']>=end:return cached
        q,reference,slope=effect.q_reference,effect.reference_ms,effect.slope
        inputs={'volume_id':effect.volume_id,'toxicity':effect.toxicity,'formula':FORMULA,
            'shield_handling':'bypasses absorption; explicit shield toxin resistance remains live'}
        if not bonus:
            coefficient=self._coefficient(effect,resistance)
            curve=AffineHeatDose(coefficient,q,reference,slope)
            inputs.update(curve_kind='affine_root_v1',coefficient=coefficient,q_reference=q,
                reference_ms=reference,slope_per_second=slope,toxin_resistance=resistance)
        else:
            shield=shield_view(w,effect.target,begin,end)
            def rate(time,state):
                coefficient=self._coefficient(effect,resistance+bonus*shield(time))
                return (coefficient*max(D(0),q+slope*(time-reference)/1000).sqrt(),)
            dense=integrate(rate,begin,end,(D(0),),absolute=D('1e-12'),relative=D('1e-12'),max_step_ms=D(20))
            curve=PiecewiseDose(tuple((s.begin,s.end,QuarticDose(s.begin,s.end,s.initial[0],s.final[0],s.coefficients[0]))
                for s in dense.steps))
            inputs.update(curve_kind='poison_live_resistance_v1',base_toxin_resistance=resistance,
                shield_toxin_resistance_per_hp=bonus,epoch_begin_ms=begin,epoch_end_ms=end,
                absolute_tolerance_hp=D('1e-12'),relative_tolerance=D('1e-12'),rate_evaluations=dense.evaluations)
        cached=dict(key=key,begin=begin,end=end,curve=curve,inputs=inputs);self.caches[effect.id]=cached
        return cached

    def prepare_doses(self,end):
        if self.enabled and end>self.world.time:
            for effect in self.effects.values():
                if not effect.ended:self._ensure(effect,self.world.time,end)
        return end

    def components(self,begin,end):
        parts={}
        if not self.enabled or end<=begin:return parts
        for effect in self.effects.values():
            actor=self.world.fighters[effect.target]
            if effect.ended or actor.hp<=0 or actor.life_generation!=effect.target_life_generation:continue
            cached=self._ensure(effect,begin,end);amount=cached['curve'].integral(begin,end)
            if amount:parts.setdefault(effect.target,[]).append(dict(effect_id=effect.id,kind='poison',
                actor=effect.source.actor,ability=effect.source.ability,action_id=effect.source.action_id,
                projectile_id=effect.source.projectile_id,**effect.source.life_record(),channel='hp',
                inputs=cached['inputs'],amount=amount))
        return parts

    def curve(self,effect_id,begin,end):
        cached=self.caches[effect_id]
        if not cached['begin']<=begin<=end<=cached['end']:raise ValueError('Gas history exceeds its prepared dose')
        return cached['curve']

    def event_live(self,kind,payload):
        item=(self.volumes if kind==VOLUME_EXPIRED else self.effects).get(payload['id'])
        if item is None:return False
        return (item['active'] and item['revision']==payload['revision'] if kind==VOLUME_EXPIRED
            else not item.ended and not item.exposed and item.revision==payload['revision'])

    def process(self,kind,payload):
        if not self.event_live(kind,payload):return
        if kind==VOLUME_EXPIRED:
            row=self.volumes[payload['id']];row.update(active=False,revision=row['revision']+1)
            for name in sorted(self.members[row['id']]):self.eligible(row,name,False)
            self.world.log('poison_volume_expired',volume_id=row['id'])
        else:self.end(self.effects[payload['id']],'toxin_load_zero')

    def pending(self):
        return [e.record(self.world.time) for e in self.effects.values() if not e.ended]

    def result(self):
        return {'poison_volume_rules':deepcopy(self.world.combat_locomotion_input['poison_volumes']),
            'poison_volumes':[self.volume_record(v) for v in self.volumes.values()],
            'poison_exposures':[e.record(self.world.time) for e in self.effects.values()]} if self.enabled else {}
