"""Timed melee contact and independent replacement weapons on the shared clock."""
from copy import deepcopy
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import BattleAction, ceil_ms, decimal_value as dec
from combat_sim.hitboxes import local_to_world_point
from combat_sim.mechanics.recovery import hand_recovery
from combat_sim.models import UnsupportedMechanicError
from combat_sim.postures import pose_local_hand_position
from combat_sim.pose_kinematics import world_hand_point,physical_hand_recovery


class SharedMelee:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'timed_melee_v1'} or not world.life_cycles.enabled
                or not world.effort_system.enabled):
            raise UnsupportedMechanicError('Timed melee requires the current owned life/effect world')
        self.ids=count(1);self.blade_ids=count(1)
        self.attacks={};self.items={};self.supplies={};self.components={};self.action_frames={}

    def validate(self,actor,ability_id):
        if not self.enabled:raise UnsupportedMechanicError('Venomous thrust requires timed melee rules')
        a=actor.profile['abilities'][ability_id]
        if a['execution_model']=='grapple_grab':return self.world.grapple_casts.validate(actor,ability_id)
        if a['execution_model']=='knock_melee':return self.world.knock_motion.validate(actor,ability_id)
        if a['execution_model']=='conditional_melee':return self.world.conditional_melee.validate(actor,ability_id)
        if a['execution_model']=='component_melee':
            return self.validate_components(actor,ability_id)
        if (a.get('melee_geometry',{}).get('mode')!='hand_capsule_at_impact' or
                a.get('direct_damage_type')!='slash' or a.get('venom_armor_snapshot')!='before_thrust_armor_loss' or
                a.get('venom_damage_input')!='slash_damage_after_shield_before_armor' or
                a.get('self_effects',{}).get('application_timing')!='impact' or
                a['dyspnea'].get('payment_timing')!='active_start'):
            raise UnsupportedMechanicError('Unsupported melee delivery/snapshot/payment rules')
        g=a['melee_geometry'];r=a['replacement_blade']
        if (g.get('aim')!='torso_location_at_active_start' or g.get('blocking')!='body_solids'
                or r.get('grab_delay_anchor')!='impact' or r.get('next_thrust')!='after_grab_active'
                or r.get('dyspnea',{}).get('kind')!='none'):
            raise UnsupportedMechanicError('Unsupported melee aim/blocking or replacement rules')
        if any(dec(g[k])<=0 for k in ('reach_m','radius_m')) or any(dec(r[k])<=0 for k in ('grab_delay_ms','active_grab_ms')):
            raise ValueError('Melee geometry and replacement timings must be positive')
        if actor.profile['timing_profiles'][a['timing_profile']].get('impact_timing')!='middle_of_active':
            raise UnsupportedMechanicError('Timed thrust impacts at Active midpoint')
        if g['origin_hand'] not in a['hand_positions_m']['start']:
            raise ValueError('Melee origin needs its occupied hand')

    def validate_components(self,actor,ability_id):
        a=actor.profile['abilities'][ability_id];parts=a.get('melee_components')
        if (not self.world.attack_modifiers.enabled or self.world.ownership_definition is None or
                'component_melee' not in self.world.ownership_definition['actions']):
            raise UnsupportedMechanicError('Component melee requires owned actions and release modifiers')
        g=a.get('melee_geometry',{})
        if (a.get('direct_damage_type')!='slash' or a.get('self_effects',{}).get('application_timing')!='impact'
                or a.get('dyspnea',{}).get('payment_timing')!='active_start'
                or g.get('mode')!='hand_capsule_at_impact' or g.get('aim')!='torso_location_at_active_start'
                or g.get('blocking')!='body_solids' or a.get('sequence_advance')!='emission'
                or a.get('continuation_recovery')!='none'):
            raise UnsupportedMechanicError('Unsupported component melee delivery/sequence rules')
        if not isinstance(parts,dict) or not parts or a.get('initial_component') not in parts:
            raise ValueError('Component melee requires a nonempty cycle and initial component')
        for identity,part in parts.items():
            if (not isinstance(identity,str) or not identity or not isinstance(part,dict)
                    or set(part)!={'next','pre_mitigation_damage','origin_hand','hand_positions_m'}
                    or part['next'] not in parts or part['origin_hand'] not in ('left','right')
                    or set(part['hand_positions_m'])!={'start','end'}
                    or any(set(part['hand_positions_m'][phase])!={part['origin_hand']} for phase in ('start','end'))):
                raise ValueError('Each component needs a next component, one explicit hand and damage')
            if dec(part['pre_mitigation_damage'])<=0:raise ValueError('Component damage must be positive')
            hand_recovery(actor.hands,part['hand_positions_m']['start'],actor.profile['recovery_value'])
            hand_recovery(actor.hands,part['hand_positions_m']['end'],actor.profile['recovery_value'])
        visited=set();cursor=a['initial_component']
        while cursor not in visited:visited.add(cursor);cursor=parts[cursor]['next']
        if cursor!=a['initial_component'] or visited!=set(parts):raise ValueError('Components must form one complete cycle')
        if (actor.profile['timing_profiles'][a['timing_profile']].get('impact_timing')!='middle_of_active'
                or any(dec(g[k])<=0 for k in ('reach_m','radius_m'))):
            raise ValueError('Component melee needs positive geometry and midpoint impact')

    def next_component(self,actor,ability,target=None):
        a=actor.profile.get('abilities',{}).get(ability,{})
        if a.get('execution_model')=='conditional_melee':return self.world.conditional_melee.select(actor,ability,target)
        if a.get('execution_model')!='component_melee':return None
        state=self.components.get((actor.id,ability))
        return state['next_component'] if state is not None else a['initial_component']

    def definition(self,actor,ability,component=None):
        from combat_sim.automatic_abilities import ability_definition
        a=ability_definition(actor,ability)
        if a['execution_model'] not in ('component_melee','conditional_melee'):return a
        component=component if component is not None else self.next_component(actor,ability)
        part=a['melee_components'][component]
        if a['execution_model']=='conditional_melee':
            return a|{k:v for k,v in part.items() if k not in ('next','origin_hand')}|{
                'melee_geometry':a['melee_geometry']|{'origin_hand':part['origin_hand']}}
        return a|{'pre_mitigation_damage':part['pre_mitigation_damage'],
            'hand_positions_m':part['hand_positions_m'],'melee_geometry':a['melee_geometry']|{'origin_hand':part['origin_hand']}}

    def continues_now(self,actor,ability,component=None):
        state=self.components.get((actor.id,ability))
        if (actor.profile['abilities'][ability]['execution_model']=='conditional_melee' and
                component not in actor.profile['abilities'][ability]['normal_cycle']):return False
        return state is not None and state['continuation_at_ms']==self.world.time

    def completed(self,actor,action):
        state=self.components.get((actor.id,action.ability_id))
        if state is not None:
            conditional=actor.profile['abilities'][action.ability_id]['execution_model']=='conditional_melee'
            state['continuation_at_ms']=None if conditional and action.component_id not in actor.profile['abilities'][action.ability_id]['normal_cycle'] else self.world.time

    def attach(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            for ability in actor.ready:
                model=actor.profile['abilities'][ability]['execution_model']
                if model in ('component_melee','conditional_melee'):
                    self.components[(actor.id,ability)]={'actor':actor.id,'ability':ability,
                        'next_component':actor.profile['abilities'][ability]['initial_component'],
                        'emitted_components':0,'continuation_at_ms':None}
                    actor.metrics.update(melee_frames=0,melee_contacts=0,melee_misses=0)
                    if model=='conditional_melee':self.world.conditional_melee.attach(actor,ability)
                    continue
                if model in ('grapple_grab','knock_melee'):
                    actor.metrics.update(melee_frames=0,melee_contacts=0,melee_misses=0)
                    continue
                if model!='venomous_thrust':continue
                item=self._item(actor,ability,'held',self.world.time)
                self.supplies[(actor.id,ability)]={'held_id':item['id'],'pending_id':None,'grab_action_id':None}
                actor.metrics.update(melee_frames=0,melee_contacts=0,melee_misses=0,
                    replacement_blades_summoned=0,blade_grabs_started=0,blade_grabs_completed=0)

    def _item(self,actor,ability,status,ready,*,action_id=None,source_generation=None):
        item={'id':'blade:'+str(next(self.blade_ids)),'actor':actor.id,'ability':ability,
            'source_life_generation':source_generation if source_generation is not None else actor.life_generation,
            'parent_action_id':action_id,'created_at_ms':self.world.time,
            'ready_at_ms':ready,'status':status}
        self.items[item['id']]=item
        return item

    def ready_at(self,actor,ability):
        supply=self.supplies.get((actor.id,ability))
        return self.world.time if supply is None or supply['held_id'] is not None else D('Infinity')

    def active_started(self,actor,action):
        supply=self.supplies.get((actor.id,action.ability_id))
        if supply is not None and supply['held_id'] is None:
            raise RuntimeError('Cannot start a thrust without a held blade')
        # Lock the intended location at Active start; later motion/death does
        # not turn a miss into a confirmed selected-target hit.
        action.aim_location_m=tuple(map(dec,next(b.centre_m for b in
            self.world.world_bodies[action.target] if b.part=='torso')))

    def emit_frame(self,actor,action):
        if action.id in self.action_frames:return self.attacks[self.action_frames[action.id]]
        attack_id='melee:'+str(next(self.ids))
        ability=self.definition(actor,action.ability_id,action.component_id)
        self.world.effort_system.capture_impact(actor,action,ability,attack_id)
        self.world.attack_modifiers.capture(actor,action,attack_id)
        frame={'attack_id':attack_id,'actor':actor.id,'ability':action.ability_id,'action_id':action.id,
            'source_life_generation':action.life_generation,'aim_target':action.target,
            'aim_point_m':action.aim_location_m,'created_at_ms':self.world.time,'status':'pending'}
        if action.component_id is not None:
            state=self.components[(actor.id,action.ability_id)]
            conditional=ability['execution_model']=='conditional_melee'
            counter=conditional and action.component_id==ability['counter_component']
            if not counter and state['next_component']!=action.component_id:raise RuntimeError('Component emission lost its pinned sequence identity')
            frame['melee_component']=action.component_id
            state.update(next_component=state['next_component'] if counter else ability['melee_components'][action.component_id]['next'],
                emitted_components=state['emitted_components']+1,continuation_at_ms=None)
        elif (actor.id,action.ability_id) in self.supplies:
            frame['blade_id']=self.supplies[(actor.id,action.ability_id)]['held_id']
        self.attacks[attack_id]=frame
        self.action_frames[action.id]=attack_id
        actor.metrics['melee_frames']+=1
        self.world.push(self.world.time,'melee_impact',{'attack_id':attack_id},priority=1)

    def live(self,payload):
        item=self.attacks.get(payload['attack_id'])
        return item is not None and item['status']=='pending'

    def resolve_frame(self,payload):
        if not self.live(payload):return None
        world=self.world;frame=self.attacks[payload['attack_id']]
        actor=world.fighters[frame['actor']];ability=self.definition(actor,frame['ability'],frame.get('melee_component'))
        geometry=ability['melee_geometry'];hand=ability['hand_positions_m']['start'][geometry['origin_hand']]
        origin=tuple(map(dec,world_hand_point(world,actor,hand)))
        delta=tuple(p-o for p,o in zip(frame['aim_point_m'],origin));length=sum(x*x for x in delta).sqrt()
        from combat_sim.facing import forward
        direction=tuple(x/length for x in delta) if length else tuple(map(dec,forward(actor.facing)))
        end=tuple(o+d*dec(geometry['reach_m']) for o,d in zip(origin,direction))
        groups=[(name,(() if world.fighters[name].hp<=0 else tuple(boxes))+world.blocking.boxes(name),False)
                for name,boxes in world.world_bodies.items() if name!=actor.id]
        groups.extend((name,boxes,True) for name,boxes in world.body_terrain_colliders().items())
        found=[]
        for name,boxes,static in groups:
            for box in boxes:
                hit=box.swept_sphere_contact(origin,end,geometry['radius_m'],precision=world.precision)
                if hit is not None:found.append((hit.parameter,name,box.part,static,hit))
        frame.update(status='missed' if not found else 'resolved',origin_m=origin,tip_m=end,
            radius_m=dec(geometry['radius_m']))
        if not found:
            actor.metrics['melee_misses']+=1
            world.log('melee_missed',**deepcopy(frame));return None
        _,target,part,static,hit=min(found,key=lambda row:row[:3])
        packet={k:frame[k] for k in ('attack_id','actor','ability','action_id','source_life_generation','aim_target','blade_id','melee_component') if k in frame}
        packet.update(target=target,component=frame.get('melee_component','strike'),delivery_kind='melee_sweep',
            collision_kind='terrain' if static else 'body',location_m=hit.closest_box_point_m,
            distance_m=hit.parameter*dec(geometry['reach_m']),hit_parts=[part])
        if static:packet.update(world.collider_system.registry.contact_fields(target))
        else:
            packet.update(world.life_cycles.target_fields(target))
            packet.update(world.blocking.contact_fields(part))
        frame['contact']=deepcopy(packet);actor.metrics['melee_contacts']+=1
        action=actor.action_by_id(frame['action_id'])
        if action is not None and actor.hp>0:
            with actor.using_action(action):world.self_effect({'actor':actor.id,'melee_contact':True})
        if 'blade_id' in frame:self._consume(actor,frame)
        world.log('melee_contact',**packet)
        return packet

    def _consume(self,actor,frame):
        supply=self.supplies[(actor.id,frame['ability'])]
        if supply['held_id']!=frame['blade_id']:raise RuntimeError('Melee frame lost its physical blade')
        old=self.items[supply['held_id']];old.update(status='spent',contact=deepcopy(frame['contact']))
        supply['held_id']=None
        ability=actor.profile['abilities'][frame['ability']];ready=self.world.time+dec(ability['replacement_blade']['grab_delay_ms'])
        item=self._item(actor,frame['ability'],'summoning',ready,
            action_id=frame['action_id'],source_generation=frame['source_life_generation'])
        supply['pending_id']=item['id'];actor.metrics['replacement_blades_summoned']+=1
        self.world.push(ready,'replacement_blade_ready',{'blade_id':item['id']})
        self.world.log('replacement_blade_summoning',blade=deepcopy(item),follows_actor=True)

    def item_ready(self,payload):
        item=self.items[payload['blade_id']]
        if item['status']!='summoning':return
        item['status']='available'
        self.world.log('replacement_blade_available',blade=deepcopy(item))
        self.world.request_decision(item['actor'],self.world.time)

    def try_prepare(self,actor):
        if not self.enabled or actor.hp<=0:return
        world=self.world
        for (name,ability_id),supply in self.supplies.items():
            if name!=actor.id or supply['pending_id'] is None or supply['grab_action_id'] is not None:continue
            item=self.items[supply['pending_id']]
            if item['status']!='available':continue
            requirements=world.action_requirements(actor,'replacement_grab',ability_id,'recovery')
            if any(actor.action_registry.unavailable(requirements)):continue
            a=actor.profile['abilities'][ability_id];poses=a['replacement_blade']['hand_positions_m']
            factor=D('1.2') if world.mobile_is_running(name) else D(1)
            recovery,_=physical_hand_recovery(world,actor,actor.hands,poses['start'],dec(actor.profile['recovery_value'])*factor)
            action=BattleAction(next(world.action_ids),name,name,ability_id,'replacement_grab',world.time,
                world.time+D(recovery),dec(a['replacement_blade']['active_grab_ms']),phase='recovery',
                recovery_end_ms=world.time+D(recovery),base_gathering_ms=D(0))
            actor.current=action;supply['grab_action_id']=action.id;item['status']='grabbing'
            actor.metrics['blade_grabs_started']+=1
            world.log('blade_grab_requested',actor=name,ability=ability_id,action_id=action.id,
                blade_id=item['id'],life_generation=actor.life_generation,recovery_end_ms=action.recovery_end_ms)
            world._schedule_phase(action,'recovery_completed',action.recovery_end_ms)

    def grab_recovery_completed(self,actor,action):
        poses=actor.profile['abilities'][action.ability_id]['replacement_blade']['hand_positions_m']
        actor.hands.update(poses['start']);action.phase='gathering'
        action.active_due_ms=ceil_ms(self.world.time+actor.disorientation)
        self.world.timed_gathering.commit(actor,action)
        self.world._schedule_phase(action,'active_started',action.active_due_ms)
        self.world.log('blade_grab_gathering',actor=actor.id,action_id=action.id,active_start_ms=action.active_due_ms)

    def grab_active_started(self,actor,action):
        action.phase='active';action.active_end_ms=self.world.time+action.active_ms
        self.world.log('blade_grab_started',actor=actor.id,action_id=action.id,active_end_ms=action.active_end_ms)
        self.world._schedule_phase(action,'active_completed',action.active_end_ms)

    def grab_completed(self,actor,action):
        supply=self.supplies[(actor.id,action.ability_id)];item=self.items[supply['pending_id']]
        item['status']='held';supply.update(held_id=item['id'],pending_id=None,grab_action_id=None)
        actor.hands.update(actor.profile['abilities'][action.ability_id]['replacement_blade']['hand_positions_m']['end'])
        actor.current=None;actor.metrics['blade_grabs_completed']+=1
        self.world.log('blade_equipped',actor=actor.id,action_id=action.id,blade=deepcopy(item),life_generation=actor.life_generation)
        self.world.request_decision(actor.id,self.world.time)

    def action_cancelled(self,actor,action):
        if action.kind!='replacement_grab':return
        supply=self.supplies[(actor.id,action.ability_id)]
        if supply['grab_action_id']!=action.id:return
        self.items[supply['pending_id']]['status']='available';supply['grab_action_id']=None

    def result(self):
        if not self.enabled:return {}
        items=[]
        for item in self.items.values():
            row=deepcopy(item)
            if item['status'] in ('summoning','available','grabbing','held'):
                actor=self.world.fighters[item['actor']]
                local=actor.profile['abilities'][item['ability']]['hand_positions_m']['start']
                point=local[next(iter(local))]
                row['position_m']=tuple(map(dec,world_hand_point(self.world,actor,point)))
            items.append(row)
        return {'melee_rules':self.world.combat_locomotion_input['melee'],
            **({'melee_component_sequences':[deepcopy(v) for v in self.components.values()]} if self.components else {}),
            'melee_attacks':deepcopy(list(self.attacks.values())),'blade_items':items}
