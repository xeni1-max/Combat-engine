"""One life-aware script dispatcher for combat controls, independent of ability rules."""
from copy import deepcopy
from decimal import Context,localcontext

from combat_sim.grapple_break import COMMANDS as BREAK_COMMANDS
from combat_sim.aim_control import COMMANDS as AIM_COMMANDS
from combat_sim.portals import COMMANDS as PORTAL_COMMANDS
from combat_sim.mechanics.life import life_generation
from combat_sim.world_colliders import finite


class CombatControls:
    def __init__(self,world):
        self.world=world
        # Preserve the public historical Break view while this coordinator owns
        # parsing/dispatch for every command family.
        self.commands=world.grapple_break.commands

    @property
    def enabled(self):return self.world.grapple_break.enabled or self.world.bindings.enabled or self.world.aim_control.enabled or self.world.portals.enabled

    def load_script(self):
        with localcontext(Context(prec=self.world.precision)):
            if not self.enabled:return
            if self.commands:raise ValueError('The control script has already been loaded')
            rows=self.world.scenario.get('control_script',[])
            if not isinstance(rows,list):raise ValueError('Control script must be a list')
            parsed=[]
            for index,row in enumerate(rows):
                fields={'actor','at_ms','command','link_id','expected_life_generation'}
                if self.world.bindings.enabled:fields.add('binding_id')
                if self.world.portals.enabled:fields.add('portal_id')
                allowed=(BREAK_COMMANDS if self.world.grapple_break.enabled or self.world.bindings.enabled else ())+\
                    (AIM_COMMANDS if self.world.aim_control.enabled else ())+\
                    (PORTAL_COMMANDS if self.world.portals.enabled else ())
                if (not isinstance(row,dict) or set(row)-fields or not {'actor','at_ms','command'}<=set(row) or
                        not isinstance(row['actor'],str) or row['actor'] not in self.world.fighters or
                        row['command'] not in allowed or 'link_id' in row and
                        (not isinstance(row['link_id'],str) or not row['link_id'])):
                    raise ValueError('A control needs a known actor, time, command and optional link/life')
                if row['command'] in PORTAL_COMMANDS:
                    if 'link_id' in row or 'binding_id' in row:raise ValueError('Portal use cannot select a grapple or binding')
                    self.world.portals.validate_control(row['actor'],row.get('portal_id'))
                elif 'portal_id' in row:raise ValueError('Only portal use selects a portal identity')
                elif row['command'] in AIM_COMMANDS:
                    if 'link_id' in row or 'binding_id' in row:raise ValueError('Aim cannot select a grapple or binding')
                    self.world.aim_control.validate_actor(row['actor'])
                else:self.world.grapple_break.validate_binding_control(row['command'],row.get('link_id'),row.get('binding_id'))
                time=finite(row['at_ms'],'Control time');generation=life_generation(row.get('expected_life_generation',1))
                if generation is None:raise ValueError('A control needs an expected actor life')
                parsed.append({'id':'combat-control:'+str(index+1),'actor':row['actor'],'command':row['command'],
                    'at_ms':time,'link_id':row.get('link_id'),'expected_life_generation':generation,'status':'queued'})
                if 'binding_id' in row:parsed[-1]['binding_id']=row['binding_id']
                if 'portal_id' in row:parsed[-1]['portal_id']=row['portal_id']
            for row in parsed:
                self.commands[row['id']]=row;self.world.push(row['at_ms'],'combat_control',{'command_id':row['id']},priority=5)

    def command(self,actor,command,*,link_id=None,binding_id=None,portal_id=None,expected_life_generation=None):
        if command in PORTAL_COMMANDS:
            if link_id is not None or binding_id is not None:raise ValueError('Portal use cannot select a grapple or binding')
            return self.world.portals.use(actor,portal_id=portal_id,expected_life_generation=expected_life_generation)
        if portal_id is not None:raise ValueError('Only portal use selects a portal identity')
        if command in AIM_COMMANDS:
            if link_id is not None or binding_id is not None:raise ValueError('Aim cannot select a grapple or binding')
            return self.world.aim_control.command(actor,command,expected_life_generation=expected_life_generation)
        return self.world.grapple_break.command(actor,command,link_id=link_id,binding_id=binding_id,
            expected_life_generation=expected_life_generation)

    def live(self,p):return self.commands[p['command_id']]['status']=='queued'

    def process(self,p):
        if not self.live(p):return
        row=self.commands[p['command_id']];row['status']='applied'
        row['result']=self.command(row['actor'],row['command'],link_id=row['link_id'],binding_id=row.get('binding_id'),portal_id=row.get('portal_id'),
            expected_life_generation=row['expected_life_generation'])
        self.world.log('combat_control_applied',control=deepcopy(row))

    def result(self):
        return {'combat_control_commands':deepcopy(list(self.commands.values()))} if self.world.aim_control.enabled or self.world.portals.enabled else {}
