"""Owned whole-body yaw on the shared action queue and saved translation prefix.

Native angular queries include ground/support, obstacles, curved projectiles,
fields, reference-space grapple/distance links and prescribed climbing. Shared
constraint preparation retires climb controls whose actual path is redirected.
"""
from copy import deepcopy
from dataclasses import replace
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F

from combat_sim.action_ownership import ActionRequirements
from combat_sim.angular_paths import RotatingBoxPath, YawArc
from combat_sim.angular_contacts import box_path_contact
from combat_sim.angular_contacts import _FlightWindow
from combat_sim.gravity_collisions import first_contact
from combat_sim.angular_kinematics import impact_normals, witness, point_velocity, margins, departing_footprint
from combat_sim.battle_models import BattleAction, decimal_value as dec
from combat_sim.facing import frame as facing_frame
from combat_sim.hitboxes import Cuboid
from combat_sim.models import UnsupportedMechanicError
from combat_sim.orientation import scalar, vector3
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.pose_kinematics import pose_acceleration
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M as DIST, CONTACT_SPEED_EPS_MPS as SPEED, CONTACT_ACCEL_EPS_MPS2 as ACCEL

ZERO=(F(0),)*3


class ClockedAngularCollider:
    """Map the existing binary64 flight clock into one saved world lease.

    Only endpoint conversion roundoff may be clipped; the body path itself is
    never extrapolated, fitted or independently integrated.
    """
    def __init__(self,path,release_ms):self.path=path;self.release=F(release_ms);self.part=path.part

    def time(self,time):
        value=F(str(time))+self.release/1000
        low,high=self.path.yaw.begin_s,self.path.yaw.end_s
        if value < low-F(1,10**12) or value > high+F(1,10**12):
            raise ValueError('Flight query exceeds angular path clock roundoff band')
        return max(low,min(high,value))

    def at_time(self,time):return self.path.at_time(self.time(time))
    def enclosing_interval(self,begin,end):return self.path.enclosing_interval(self.time(begin),self.time(end))


class TurnControl:
    def __init__(self,world):
        self.world=world;self.enabled='turn_script' in world.scenario
        self.commands=[];self.rows={};self.advancing_to=None;self.responding_turns=set()

    @staticmethod
    def requirements():return ActionRequirements(frozenset(('heading',)),frozenset(('lower_body',)))

    def attach(self):
        if not self.enabled:return
        w=self.world
        if not w.gravity_mode or not w.terrain_support.finite_ground or not w.body_paths.ready or w.ownership_definition is None:
            raise UnsupportedMechanicError('Native turns require the current gravity, saved-path and finite-face owned world')
        rows=w.scenario['turn_script']
        if not isinstance(rows,list):raise ValueError('Turn script must be a list')
        parsed=[]
        for index,row in enumerate(rows):
            if (not isinstance(row,dict) or set(row)-{'actor','at_ms','angle_degrees','expected_life_generation'} or
                    not {'actor','at_ms','angle_degrees'}<=set(row) or row['actor'] not in w.fighters):
                raise ValueError('Turn command requires a known actor, time and signed angle')
            at,angle=scalar(row['at_ms']),scalar(row['angle_degrees']);life=row.get('expected_life_generation',1)
            if at<0 or type(life) is not int or life<1:raise ValueError('Invalid turn time or actor life')
            parsed.append(dict(id='turn-command:'+str(index+1),actor=row['actor'],at_ms=dec(at),
                angle_degrees=dec(angle),expected_life_generation=life,status='scheduled',action_id=None))
        self.commands=parsed
        for row in parsed:w.push(row['at_ms'],'turn_command',{'command_id':row['id']},priority=5)

    def active(self,name,time=None):
        row=self.rows.get(name);w=self.world;time=w.time if time is None else time
        return (row is not None and row['status']=='active' and w.fighters[name].hp>0 and
                row['life_generation']==w.fighters[name].life_generation and time < row['end_ms'])

    def any_active(self):return any(self.active(n) for n in self.rows)

    def suspends_reference_plane(self,name):
        return self.active(name) or name in self.responding_turns

    def key(self,name):
        if self.active(name):
            r=self.rows[name];return ('owned_turn',r['action_id'],r['start_ms'],r['end_ms'],r['arc'].initial_frame)
        return self.world.fighters[name].facing

    def frame(self,name,time):
        row=self.rows.get(name)
        if row is None or row['status']!='active':return facing_frame(self.world.fighters[name].facing)
        return row['arc'].frame_at(max(row['arc'].begin_s,min(row['arc'].end_s,F(time)/1000)))

    def receive(self,payload):
        row=next(r for r in self.commands if r['id']==payload['command_id']);row['status']='queued'
        self.world.request_decision(row['actor'],self.world.time)

    def try_pending(self,actor):
        if not self.enabled:return
        w=self.world
        if self.active(actor.id) or actor.knocked_down:return
        for row in self.commands:
            if row['actor']!=actor.id or row['status']!='queued':continue
            if actor.hp<=0 or row['expected_life_generation']!=actor.life_generation:
                row.update(status='ignored',reason='actor_life_ended');continue
            if not row['angle_degrees']:
                row.update(status='completed',completed_at_ms=w.time);continue
            if any(actor.action_registry.unavailable(self.requirements())):return
            velocity=w.mobile_motion(actor.id)[0];speed=sum(v*v for v in velocity).sqrt()
            initial=facing_frame(actor.facing)
            arc=YawArc.fixed_speed_turn(w.time,initial,row['angle_degrees'],speed,precision=w.precision)
            duration=dec((arc.end_s-arc.begin_s)*1000)
            action=BattleAction(next(w.action_ids),actor.id,actor.id,'turn','heading_turn',w.time,w.time,
                duration,phase='ready',life_generation=actor.life_generation)
            actor.current=action;row.update(status='running',action_id=action.id)
            self.rows[actor.id]=dict(actor=actor.id,life_generation=actor.life_generation,action_id=action.id,
                command_id=row['id'],status='pending',start_ms=w.time,end_ms=w.time+duration,arc=arc,sampled_speed_mps=speed)
            w.log('turn_requested',actor=actor.id,action_id=action.id,angle_degrees=row['angle_degrees'],sampled_speed_mps=speed,
                duration_ms=duration,requires=['lower_body'],occupies=['heading'])
            w._schedule_phase(action,'active_started',w.time)
            return

    def start(self,actor,action):
        row=self.rows[actor.id];row['status']='active';action.phase='active';action.active_end_ms=row['end_ms']
        actor.facing=row['arc'].initial_frame
        self.world.set_body_reference(actor.id,self.world.spatial_transitions.reference(actor.id))
        self.world.body_paths.invalidate()
        self.world.log('turn_started',actor=actor.id,action_id=action.id,active_end_ms=action.active_end_ms,
            sampled_speed_mps=row['sampled_speed_mps'],angular_rate_degrees_per_second=dec(row['arc'].rate_degrees_per_second))
        self.world._schedule_phase(action,'active_completed',action.active_end_ms)

    def complete(self,actor,action):
        w=self.world;row=self.rows[actor.id];actor.facing=row['arc'].frame_at(row['arc'].end_s)
        row.update(status='completed',ended_at_ms=w.time)
        command=next(r for r in self.commands if r['id']==row['command_id']);command.update(status='completed',completed_at_ms=w.time)
        actor.current=None;w.set_body_reference(actor.id,w.spatial_transitions.reference(actor.id));w.body_paths.invalidate()
        w.log('turn_completed',actor=actor.id,action_id=action.id,facing=actor.facing)
        w.request_decision(actor.id,w.time)

    def cancelled(self,actor,action,reason):
        if action.kind!='heading_turn':return
        row=self.rows.get(actor.id)
        if row is None or row['action_id']!=action.id or row['status'] not in ('pending','active'):return
        actor.facing=self.frame(actor.id,self.world.time)
        row.update(status='cancelled',ended_at_ms=self.world.time,reason=reason)
        command=next(r for r in self.commands if r['id']==row['command_id']);command.update(status='cancelled',reason=reason)
        self.world.body_paths.invalidate()
        self.world.log('turn_cancelled',actor=actor.id,action_id=action.id,reason=reason,facing=actor.facing)

    def settle(self):
        if not self.enabled:return
        for name,row in list(self.rows.items()):
            a=self.world.fighters[name];action=a.action_by_id(row['action_id'])
            if row['status'] in ('active','pending') and action is not None and (a.hp<=0 or a.knocked_down):
                self.world.cancel_owned_action(a,action,'actor_life_or_upright_control_ended')

    def path(self,name,box,end):
        w=self.world
        layer=w.blocking.layers.get(box.part)
        if layer is not None and layer['frozen_box'] is not None:return box
        piece=dict(w.body_paths.ensure().pieces)[name].slice(w.time,end)
        return self.path_from_piece(name,box,piece)

    def path_from_piece(self,name,box,piece):
        """Pure composition against a candidate/saved piece, without ensure()."""
        w=self.world;now=w.time;layer=w.blocking.layers.get(box.part)
        if layer is not None and layer['frozen_box'] is not None:return box
        frame=facing_frame(w.fighters[name].facing)
        piece=piece.slice(now,piece.end_ms);end=piece.end_ms
        point=frame.to_local_point(box.centre_m,piece.reference_m)
        if layer is None:
            velocity,rate=w.pose_part_motion(name,box.part,now);accel,size_a=pose_acceleration(w,name,box.part,now)
        else:
            _,_,velocity,rate=w.blocking.kinematics(name,box.part,now)
            accel,size_a=w.pose_part_acceleration(name,'torso',now)
        size=box.size_m
        if not isinstance(box,OrientedCuboid):
            size=(size[1],size[0],size[2]);rate=(rate[1],rate[0],rate[2]);size_a=(size_a[1],size_a[0],size_a[2])
        arc=YawArc(F(now)/1000,F(end)/1000,frame,0,w.precision)
        if self.active(name):
            old=self.rows[name]['arc'];arc=replace(old,begin_s=F(now)/1000,end_s=F(end)/1000)
        return RotatingBoxPath(piece,arc,Cuboid(box.part,point,size),frame.to_local_vector(velocity),
            frame.to_local_vector(accel),rate,size_a)

    def owned_path(self,row,end):
        """A controlled volume follows its live local attachment, not a release."""
        w=self.world;geometry=row['geometry'];name=row['actor']
        anchor=next(box for box in w.world_bodies[name] if box.part==geometry['anchor_part'])
        path=self.path(name,anchor,end)
        fraction=vector3(geometry.get('anchor_fraction',(0,0,0)))
        centre=tuple(p+o+f*s for p,o,f,s in zip(path.local_box.centre_m,
            vector3(geometry['centre_offset_m']),fraction,path.local_box.size_m))
        velocity=tuple(v+f*r for v,f,r in zip(path.local_velocity_mps,fraction,path.size_rate_mps))
        acceleration=tuple(a+f*r for a,f,r in zip(path.local_acceleration_mps2,fraction,path.size_acceleration_mps2))
        return replace(path,local_box=Cuboid(row['id'],centre,geometry['size_xyz_m']),
            local_velocity_mps=velocity,local_acceleration_mps2=acceleration,size_rate_mps=ZERO,size_acceleration_mps2=ZERO)

    def pair_contacts(self,a,b,left,right,end):
        w=self.world;found=[];begin=F(w.time)/1000;finish=F(end)/1000
        for first in left:
            pa=self.path(a,first,end)
            for second in right:
                pb=self.path(b,second,end) if b in w.fighters else second
                depth=F(DIST)/100
                initial_rows=margins(pa,pb,begin);initial=min(g for _,g,_,_ in initial_rows)
                if 0<=initial<F(DIST) and not impact_normals(pa,pb,begin,
                        distance_epsilon=F(DIST),speed_epsilon=F(SPEED),acceleration_epsilon=F(ACCEL)):
                    # The last accepted entry can leave sub-resolution overlap.
                    # A separating turn must first deepen it before a new entry
                    # can be nominated; otherwise a rejected zero-time candidate
                    # would repeatedly prevent the common clock from advancing.
                    departing=departing_footprint(initial_rows,distance_epsilon=F(DIST),
                        speed_epsilon=F(SPEED),acceleration_epsilon=F(ACCEL))
                    depth=min(F(DIST),max((r[1] for r in departing),default=initial)+depth)
                hit=box_path_contact(pa,pb,begin,finish,time_tolerance_s=F(1,10**28),minimum_overlap_m=depth)
                if hit is None:continue
                when=dec(hit.time_upper_s*1000)
                payload=dict(first=a,second=b,normals=[],angular_collision=True,first_part=first.part,second_part=second.part)
                if b not in w.fighters:payload.update(w.collider_system.registry.contact_fields(b))
                found.append((when,payload))
        return found

    def curve_contact(self,name,box,trajectory,flight,begin_s,end_s,world_end):
        w=self.world;end=min(world_end,dec(w.body_paths.ensure().end_ms))
        path=self.path(name,box,end)
        proxy=ClockedAngularCollider(path,flight['trajectory_started_at_ms']) if isinstance(path,RotatingBoxPath) else path
        hit=first_contact(_FlightWindow(trajectory,begin_s,end_s),(proxy,),flight['radius_m'],
            time_tolerance_s=float(w.physics['contact_time_tolerance_s']),
            clearance_tolerance_m=float(w.physics['contact_clearance_tolerance_m']),confirm_near_entry=w.confirm_curved_entry)
        return hit,path

    def revalidate(self,contact):
        w=self.world;a,b=contact['first'],contact['second'];boxes=w.world_bodies[a]
        right=w.world_bodies[b] if b in w.fighters else w.body_terrain_colliders().get(b,())
        first=next((x for x in boxes if x.part==contact['first_part']),None)
        second=next((x for x in right if x.part==contact['second_part']),None)
        if first is None or second is None:return None
        pa=self.path(a,first,w.time);pb=self.path(b,second,w.time) if b in w.fighters else second
        time=F(w.time)/1000
        normals=impact_normals(pa,pb,time,distance_epsilon=F(DIST),speed_epsilon=F(SPEED),acceleration_epsilon=F(ACCEL))
        if not normals:return None
        point=witness(first,second)
        result=dict(contact,normals=[tuple(map(dec,n)) for n in normals],
            first_contact_velocity_mps=tuple(map(dec,point_velocity(pa,time,point))),
            second_contact_velocity_mps=tuple(map(dec,point_velocity(pb,time,point))),contact_point_m=tuple(map(dec,point)))
        if b not in w.fighters and any(n[2]>0 for n in normals):
            ref=w.spatial_transitions.reference(a)
            result.update(support_part=second.part,support_body_part=first.part,
                support_reference_z_m=dec(second.bounds[1][2])-dec(first.bounds[0][2])+dec(ref[2]))
        return result

    def result(self):
        if not self.enabled:return {}
        return {'turn_commands':deepcopy(self.commands),'body_turns':{
            n:{**{k:deepcopy(v) for k,v in r.items() if k!='arc'},'arc':r['arc'].record()}
            for n,r in self.rows.items()},'turn_scope':'free bodies, finite-floor interior, body/material contact and curved projectiles'}


class TurningRules:
    def set_body_reference(self,name,reference_m):
        turns=getattr(self,'turns',None)
        if turns is not None and turns.enabled and name in turns.rows:
            time=self.time if turns.advancing_to is None else turns.advancing_to
            self.fighters[name].facing=turns.frame(name,time)
        return super().set_body_reference(name,reference_m)

    def advance_mobile_geometry(self,begin,end):
        if not self.turns.enabled:return super().advance_mobile_geometry(begin,end)
        self.turns.advancing_to=end
        try:return super().advance_mobile_geometry(begin,end)
        finally:self.turns.advancing_to=None

    def advance_mobile(self,end):
        self.turns.settle()
        return super().advance_mobile(end)

    def resolve_mobile_contacts(self,contacts):
        previous=set(self.turns.responding_turns)
        coupled=bool(self.distance_constraints.active() or self.grapple_links.groups() or self.body_support.active())
        involved={n for c in contacts if c.get('angular_collision') for n in (c['first'],c['second'])
                  if n in self.fighters and self.turns.active(n)}
        if coupled:self.turns.responding_turns.update(involved)
        try:
            for contact in contacts:
                if not contact.get('angular_collision'):continue
                for name in (contact['first'],contact['second']):
                    if name not in self.fighters or not self.turns.active(name):continue
                    row=self.turns.rows[name];actor=self.fighters[name];action=actor.action_by_id(row['action_id'])
                    if action is not None:self.cancel_owned_action(actor,action,'body_contact')
            return super().resolve_mobile_contacts(contacts)
        finally:
            self.turns.responding_turns=previous
            if coupled and involved:self.body_paths.invalidate()
