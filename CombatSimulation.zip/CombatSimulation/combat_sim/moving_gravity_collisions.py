"""Curved sphere contact with translating/resizing/rotating boxes or ground.

The supplied collider is located at ``begin_s``. Its velocity and acceleration
remain constant until ``end_s``. Querying a relative view of an immutable flight
reuses the curved contact enclosure without reintegrating or extrapolating the
flight. Ownership, death, contact priorities and event rounding belong to callers.

As in ``gravity_collisions``, bounds describe numerical trajectories, not a
certified enclosure of the exact differential equation. Unresolved tangencies
raise ``UnsupportedMechanicError``; they are never silently declared misses.
"""
from math import hypot, isfinite

from combat_sim.gravity_collisions import TrajectoryContact, first_contact
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.gravity import MotionState
from combat_sim.mechanics.kinematic_bounds import quadratic_range
from combat_sim.oriented_geometry import OrientedCuboid


def _vector(values, name):
    try:
        values = tuple(values)
        if len(values) != 3 or any(isinstance(value, bool) for value in values):
            raise ValueError
        result = tuple(float(value) for value in values)
        if not all(isfinite(value) for value in result):
            raise ValueError
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f'{name} requires three finite components') from error
    return result


class _RelativeTrajectory:
    def __init__(self, trajectory, begin, end, velocity, acceleration):
        self.trajectory = trajectory
        self.begin = begin
        self.end = end
        self.velocity = velocity
        self.acceleration = acceleration
        # first_contact needs a conservative bound on relative acceleration.
        self.gravity = trajectory.gravity
        self.deceleration = trajectory.deceleration + hypot(*acceleration)
        knots = (begin, *(state.time_s for state in trajectory.states
                          if begin < state.time_s < end), end)
        self.states = tuple(self.at(time) for time in dict.fromkeys(knots))

    def displacement(self, time):
        dt = time-self.begin
        return tuple(v*dt+a*dt*dt/2 for v, a in zip(self.velocity, self.acceleration))

    def at(self, time):
        if not self.begin <= time <= self.end:
            raise ValueError('Relative contact query is outside its interval')
        state = self.trajectory.at(time)
        dt = time-self.begin
        shift = self.displacement(time)
        return MotionState(time, tuple(p-s for p, s in zip(state.position_m, shift)),
                           tuple(v-b-a*dt for v, b, a in
                                 zip(state.velocity_mps, self.velocity, self.acceleration)),
                           state.distance_m)


class _LocalTrajectory:
    """A rigid view of the stored world flight, preserving its arc distance."""
    def __init__(self,trajectory,collider,begin,end):
        self.trajectory=trajectory;self.collider=collider
        self.duration=trajectory.duration;self.gravity=trajectory.gravity;self.deceleration=trajectory.deceleration
        knots=(begin,*(s.time_s for s in trajectory.states if begin<s.time_s<end),end)
        self.states=tuple(self.at(t) for t in dict.fromkeys(knots))

    def at(self,time):
        state=self.trajectory.at(time);frame=self.collider.frame
        return MotionState(time,tuple(map(float,frame.to_local_point(state.position_m,self.collider.centre_m))),
            tuple(map(float,frame.to_local_vector(state.velocity_mps))),state.distance_m)


class _BoundsCollider:
    """Closed bounds, including zero extents, with the existing rounded sweep."""
    def __init__(self, part, bounds):
        self.part = part
        self.bounds = bounds

    def swept_sphere_contact(self, start, end, radius_m, *, precision=50):
        return Cuboid.swept_sphere_contact(self,start,end,radius_m,precision=precision)


class _ResizingCollider:
    def __init__(self, collider, begin, size_rate,size_acceleration=(0,0,0)):
        self.part = collider.part
        self.bounds = tuple(tuple(float(v) for v in bound) for bound in collider.bounds)
        self.begin = begin
        self.half_rate = tuple(rate/2 for rate in size_rate)
        self.half_acceleration=tuple(a/2 for a in size_acceleration)

    def at_time(self, time):
        dt = time-self.begin
        low,high = self.bounds
        if any(self.half_acceleration):
            delta=tuple(r*dt+a*dt*dt/2 for r,a in zip(self.half_rate,self.half_acceleration))
            return _BoundsCollider(self.part,(tuple(a-d for a,d in zip(low,delta)),tuple(b+d for b,d in zip(high,delta))))
        return _BoundsCollider(self.part,
            (tuple(a-r*dt for a,r in zip(low,self.half_rate)),
             tuple(b+r*dt for b,r in zip(high,self.half_rate))))

    def enclosing_interval(self, begin, end):
        if any(self.half_acceleration):
            # A quadratic extent can be largest between both endpoints.
            high_delta=[float(quadratic_range(0,r,a,begin-self.begin,end-self.begin)[1])
                for r,a in zip(self.half_rate,self.half_acceleration)]
            low,high=self.bounds
            return _BoundsCollider(self.part,(tuple(p-d for p,d in zip(low,high_delta)),
                tuple(p+d for p,d in zip(high,high_delta))))
        # Each face is linear. The union of the two endpoint bounds therefore
        # contains the box at every intervening time, including shrinking axes.
        first,last = self.at_time(begin).bounds,self.at_time(end).bounds
        return _BoundsCollider(self.part,
            (tuple(min(a,b) for a,b in zip(first[0],last[0])),
             tuple(max(a,b) for a,b in zip(first[1],last[1]))))


def moving_curve_contact(trajectory, collider, radius_m, begin_s, end_s,
                         box_velocity=(0, 0, 0), box_acceleration=(0, 0, 0),
                         time_tolerance_s=1e-12, clearance_tolerance_m=1e-14, *,
                         box_size_rate_mps=(0, 0, 0),box_size_acceleration_mps2=(0,0,0),confirm_near_entry=False):
    """Return first numerical contact bracket within an absolute flight interval.

    Times in the result are relative to release, not to ``begin_s``. Centre and
    surface coordinates are world coordinates. Distance bounds retain the
    projectile's traveled path length, not the relative sphere/box distance.
    ``box_size_rate_mps`` is each initial full-side length rate; optional
    ``box_size_acceleration_mps2`` is its constant acceleration. All
    extents must remain nonnegative for the query. Interval enclosures may
    include unused space, but only actual sphere/box overlap confirms a hit.
    Exactly zero-duration intervals can report an existing overlap. A supplied
    interval outside the flight horizon fails explicitly.
    A ``RotatingBoxPath`` alternatively owns its complete reference/local-pose
    and yaw interval; separate box drivers must then remain zero. This extends
    the geometry API, not the shared-world turn-control admission boundary.
    """
    try:
        if isinstance(begin_s, bool) or isinstance(end_s, bool):
            raise ValueError
        begin, end = float(begin_s), float(end_s)
        if (not all(isfinite(t) for t in (begin, end)) or
                not 0 <= begin <= end <= trajectory.duration):
            raise ValueError
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError('Contact interval must lie within the explicit trajectory horizon') from error
    velocity = _vector(box_velocity, 'Box velocity')
    acceleration = _vector(box_acceleration, 'Box acceleration')
    size_rate = _vector(box_size_rate_mps, 'Box size rate')
    size_acceleration=_vector(box_size_acceleration_mps2,'Box size acceleration')
    from combat_sim.angular_paths import RotatingBoxPath
    if isinstance(collider,RotatingBoxPath):
        if any((*velocity,*acceleration,*size_rate,*size_acceleration)):
            raise ValueError('A saved rotating box path already owns its translation and pose drivers')
        from combat_sim.angular_contacts import rotating_curve_contact
        return rotating_curve_contact(trajectory,collider,radius_m,begin,end,
            time_tolerance_s=time_tolerance_s,clearance_tolerance_m=clearance_tolerance_m,
            confirm_near_entry=confirm_near_entry)
    if isinstance(collider,OrientedCuboid):
        local=_LocalTrajectory(trajectory,collider,begin,end)
        contact=moving_curve_contact(local,collider.local_box,radius_m,begin,end,
            collider.frame.to_local_vector(velocity),collider.frame.to_local_vector(acceleration),
            time_tolerance_s,clearance_tolerance_m,box_size_rate_mps=size_rate,
            box_size_acceleration_mps2=size_acceleration,confirm_near_entry=confirm_near_entry)
        if contact is None:return None
        original=trajectory.at(contact.time_upper_s)
        surface=tuple(map(float,collider.frame.to_world_point(contact.surface_point_m,collider.centre_m)))
        return TrajectoryContact(collider.part,contact.time_lower_s,contact.time_upper_s,
            original.position_m,surface,contact.distance_lower_m,contact.distance_upper_m)
    low,high = tuple(_vector(bound,'Box bounds') for bound in collider.bounds)
    invalid=(any(b<a or quadratic_range(b-a,r,q,0,end-begin)[0]<0
            for a,b,r,q in zip(low,high,size_rate,size_acceleration)) if any(size_acceleration) else
        any(b<a or b-a+r*(end-begin)<0 for a,b,r in zip(low,high,size_rate)))
    if invalid:
        raise ValueError('Collider dimensions must remain nonnegative throughout the interval')
    relative = _RelativeTrajectory(trajectory, begin, end, velocity, acceleration)
    resizing=any(size_rate) or any(size_acceleration)
    shape = _ResizingCollider(collider,begin,size_rate,size_acceleration) if resizing else collider
    contact = first_contact(relative, (shape,), radius_m,
                            time_tolerance_s=time_tolerance_s,
                            clearance_tolerance_m=clearance_tolerance_m,confirm_near_entry=confirm_near_entry)
    if contact is None:
        return None
    lower = trajectory.at(contact.time_lower_s)
    upper = trajectory.at(contact.time_upper_s)
    shift = relative.displacement(contact.time_upper_s)
    low, high = shape.at_time(contact.time_upper_s).bounds if resizing else collider.bounds
    surface = tuple(min(float(b)+s, max(float(a)+s, p))
                    for a, b, p, s in zip(low, high, upper.position_m, shift))
    return TrajectoryContact(collider.part, contact.time_lower_s, contact.time_upper_s,
                             upper.position_m, surface, lower.distance_m, upper.distance_m)
