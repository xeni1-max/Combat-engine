"""Event log container, separate from state execution and analysis."""

from typing import Any


class EventLog:
    def __init__(self) -> None:
        self._events: list[dict[str, Any]] = []

    def record(self, event: dict[str, Any]) -> None:
        self._events.append(event)

    def records(self) -> list[dict[str, Any]]:
        return list(self._events)
