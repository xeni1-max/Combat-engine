"""Experimental curved-path sphere contacts for isolated trajectory tests.

Returns contact-time/distance brackets, not rounded combat events. Recursive
chord enclosures avoid simply replacing the entire arc by one straight shot.
Binary64 trajectory error is not a formally certified enclosure. Ambiguous
near-tangent contacts are rejected, never silently declared misses or hits.
"""
from dataclasses import dataclass
from math import hypot, isfinite, nextafter

from combat_sim.models import UnsupportedMechanicError
from combat_sim.oriented_geometry import OrientedCuboid


@dataclass(frozen=True)
class TrajectoryContact:
    object_id: str
    time_lower_s: float
    time_upper_s: float
    centre_m: tuple
    surface_point_m: tuple
    distance_lower_m: float
    distance_upper_m: float


def first_contact(trajectory,colliders,radius_m,*,time_tolerance_s=1e-8,clearance_tolerance_m=1e-10,confirm_near_entry=False):
    """Find first contact within the explicit horizon with supplied static shapes.

    Collider objects need part, bounds and swept_sphere_contact (cuboids or
    finite ground). A changing collider additionally supplies ``at_time(t)``
    for its actual shape and ``enclosing_interval(a,b)`` for a static shape
    containing every position/extent within that interval. The enclosure is
    only used for conservative rejection; confirmed contact uses the actual
    shape at the queried time. The caller explicitly supplies eligibility; this helper
    does not infer owner exclusion, death times or collision priorities.
    """
    radius = float(radius_m)
    time_tolerance = float(time_tolerance_s)
    clearance = float(clearance_tolerance_m)
    if not all(isfinite(x) for x in (radius,time_tolerance,clearance)) or radius < 0 or min(time_tolerance,clearance) <= 0:
        raise ValueError('Invalid collision radius or numerical tolerance')
    if not isinstance(confirm_near_entry,bool):raise ValueError('Entry confirmation must be boolean')
    shapes = tuple(colliders)
    if len({c.part for c in shapes}) != len(shapes):
        raise ValueError('Isolated scene collider identities must be unique')
    acceleration_bound = trajectory.gravity+trajectory.deceleration

    def closest(shape,position,time):
        if hasattr(shape,'at_time'):
            shape = shape.at_time(time)
        if isinstance(shape,OrientedCuboid):return tuple(map(float,shape.closest_point(position)))
        low,high = shape.bounds
        return tuple(min(float(b),max(float(a),p)) for a,b,p in zip(low,high,position))

    def inside(shape,state):
        return hypot(*(p-q for p,q in zip(state.position_m,closest(shape,state.position_m,state.time_s)))) <= radius

    def search(shape,left,right):
        if inside(shape,left):
            return left,left
        dt = right.time_s-left.time_s
        # Bounded acceleration places the curve within A*dt²/8 of its chord.
        expansion = acceleration_bound*dt*dt/8+clearance
        enclosure = (shape.enclosing_interval(left.time_s,right.time_s)
                     if hasattr(shape,'enclosing_interval') else shape)
        possible = enclosure.swept_sphere_contact(left.position_m,right.position_m,radius+expansion)
        if possible is None:
            return None
        if dt <= time_tolerance:
            if inside(shape,right):
                return left,right
            mid = trajectory.at((left.time_s+right.time_s)/2)
            if inside(shape,mid):
                return left,mid
            if confirm_near_entry:
                # An expanded chord can nominate the last outside leaf just
                # before an ordinary entry. Confirm a real inside point within
                # this same allowed time bracket and physical integration
                # interval, rather than treating the candidate as a hit/miss.
                confirm_time=min(interval_end,left.time_s+time_tolerance)
                while confirm_time-left.time_s>time_tolerance:
                    confirm_time=nextafter(confirm_time,left.time_s)
                if confirm_time>right.time_s:
                    confirmed=trajectory.at(confirm_time)
                    if inside(shape,confirmed):return left,confirmed
            raise UnsupportedMechanicError('Near-tangent or unresolved curved contact: tighten numerical controls')
        mid = trajectory.at((left.time_s+right.time_s)/2)
        return search(shape,left,mid) or search(shape,mid,right)

    # Process intervals chronologically. Later uncertain geometry must not
    # invalidate a projectile which has already struck an earlier object.
    intervals = tuple(zip(trajectory.states,trajectory.states[1:]))
    if len(trajectory.states) == 1:
        intervals = ((trajectory.states[0],trajectory.states[0]),)
    for left,right in intervals:
        interval_end=right.time_s
        contacts = []
        for shape in shapes:
            bracket = search(shape,left,right)
            if bracket is not None:
                a,b = bracket
                contacts.append(TrajectoryContact(shape.part,a.time_s,b.time_s,b.position_m,
                    closest(shape,b.position_m,b.time_s),a.distance_m,b.distance_m))
        if contacts:
            contacts.sort(key=lambda c:c.time_lower_s)
            if len(contacts)>1 and contacts[1].time_lower_s <= contacts[0].time_upper_s:
                raise UnsupportedMechanicError('Overlapping contact brackets need refinement or a scene-contact priority rule')
            return contacts[0]
    return None
