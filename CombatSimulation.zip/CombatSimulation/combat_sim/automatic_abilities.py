"""Dispatch authored automatic definitions to independently enabled controllers."""
from combat_sim.models import UnsupportedMechanicError


def ability_definition(actor,identity):
    resolver=getattr(actor,'ability_resolver',None)
    if resolver is not None:
        selected=resolver(identity)
        if selected is not None:return selected
    active=actor.profile.get('abilities',{})
    automatic=actor.profile.get('automatic_abilities',{})
    if identity in active:return active[identity]
    if identity in automatic:return automatic[identity]
    raise UnsupportedMechanicError('Ability is not integrated: '+actor.profile_id+'/'+str(identity))


class AutomaticAbilities:
    def __init__(self,world):self.world=world

    def attach(self):
        handlers={'death_revival':self.world.revival,'block_counter':self.world.reactions}
        enabled=any(h.enabled for h in handlers.values())
        if enabled:
            for actor in self.world.fighters.values():
                definitions=actor.profile.get('automatic_abilities',{})
                if not isinstance(definitions,dict):raise ValueError('Automatic definitions must be keyed by ability')
                for ability,cfg in definitions.items():
                    if not isinstance(ability,str) or not ability or not isinstance(cfg,dict):
                        raise ValueError('Automatic ability needs an identity and definition')
                    if cfg.get('execution_model') not in handlers:
                        raise UnsupportedMechanicError('Unsupported automatic ability controller')
                    if ability in actor.profile.get('abilities',{}):
                        raise ValueError('Automatic and selectable definitions must not alias an ability')
        for handler in handlers.values():handler.attach()
