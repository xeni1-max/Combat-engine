"""Attached toxin effects using shared geometry, HP boundaries and loss history."""
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import AttachedVenom, EffectSource
from combat_sim.mechanics.attached_venom import coefficient, delivery_ratio, exposure_segment
from combat_sim.mechanics.damage_ledger import AffineHeatDose, PiecewiseDose, QuarticDose
from combat_sim.mechanics.dense_rk import integrate
from combat_sim.mechanics.venom import FORMULA
from combat_sim.toxin_defenses import shield_view


class VenomEffects:
    def __init__(self,world):
        self.world=world;self.caches={}

    def position(self,effect):
        actor=self.world.fighters[effect.target]
        if effect.ended or not effect.attached or actor.life_generation!=effect.target_life_generation:
            return effect.terminal_position_m
        box=next(b for b in self.world.world_bodies[effect.target] if b.part==effect.target_part)
        return tuple(dec(p)+f*dec(size) for p,f,size in zip(box.centre_m,effect.local_fraction,box.size_m))

    def freeze_anchor(self,effect):effect.terminal_position_m=self.position(effect)

    def record(self,effect,time):return {**effect.record(time),'attachment_position_m':self.position(effect)}

    def add(self,packet,calculation,armor_before):
        world=self.world;manager=world.effect_system
        actor=world.fighters[packet['actor']];ability=actor.profile['abilities'][packet['ability']]
        piercing=world.attack_modifiers.piercing(packet,ability)
        if 'block_layer_id' in packet:
            if not calculation.damage_left_after_shield:return None
            packet=dict(packet,hit_parts=['torso'])
        box=next(b for b in world.world_bodies[packet['target']] if b.part==packet['hit_parts'][0])
        local=tuple(min(D('.5'),max(D('-.5'),(dec(p)-dec(c))/dec(s))) for p,c,s in
            zip(packet['location_m'],box.centre_m,box.size_m))
        d=dec(calculation.damage_left_after_shield)
        effect=AttachedVenom('effect:'+str(next(manager.effect_ids)),
            EffectSource(actor.id,packet['ability'],packet['action_id'],life_generation=packet['source_life_generation']),
            packet['target'],packet['target_life_generation'],packet['blade_id'],box.part,local,
            world.time,dec(ability['poison_exposure_ms']),d,dec(armor_before),piercing,
            dec(ability['toxicity']),delivery_ratio(d,armor_before,piercing),
            terminal_position_m=tuple(map(dec,packet['location_m'])))
        manager.effects[effect.id]=effect
        world.push(effect.detach_ms,'venom_detached',{'effect_id':effect.id,'revision':effect.revision})
        world.log('blade_attached',effect=self.record(effect,world.time),autonomous=True,
            armor_snapshot='before_simultaneous_armor_loss',delivery_damage='post_shield_pre_armor')
        return effect

    def detach(self,effect):
        self.freeze_anchor(effect);effect.attached=False;effect.revision+=1
        self.world.log('venom_blade_detached',effect_id=effect.id,target=effect.target,
            attachment_position_m=effect.terminal_position_m,expires_at_ms=effect.expiry)
        self.world.push(effect.expiry,'typed_effect_expired',{'effect_id':effect.id,'revision':effect.revision})

    def _ensure(self,effect,begin,end):
        actor=self.world.fighters[effect.target]
        resistance=dec(actor.profile['resistances']['toxin'])
        bonus=dec(actor.profile.get('shield_toxin_resistance_per_hp',0))
        cached=self.caches.get(effect.id)
        key=(begin,effect.revision,resistance,bonus,actor.shield,
            self.world.shield_recovery[effect.target]._plan_generation)
        if cached is not None and cached['key']==key and cached['end']>=end:return cached
        q,reference,slope=exposure_segment(effect.start,effect.detach_ms,begin)
        if not bonus:
            c=coefficient(effect.delivery,effect.toxicity,effect.piercing,resistance)
            curve=AffineHeatDose(c,q,reference,slope)
            inputs={'curve_kind':'affine_root_v1','coefficient':c,'q_reference':q,
                'reference_ms':reference,'slope_per_second':slope,'toxin_resistance':resistance}
        else:
            shield=shield_view(self.world,effect.target,begin,end)
            def rate(time,state):
                r=resistance+bonus*shield(time)
                c=coefficient(effect.delivery,effect.toxicity,effect.piercing,r)
                return (c*max(D(0),q+slope*(time-reference)/1000).sqrt(),)
            dense=integrate(rate,begin,end,(D(0),),absolute=D('1e-12'),relative=D('1e-12'),max_step_ms=D(20))
            curve=PiecewiseDose(tuple((s.begin,s.end,QuarticDose(s.begin,s.end,s.initial[0],s.final[0],s.coefficients[0]))
                for s in dense.steps))
            inputs={'curve_kind':'venom_live_resistance_v1','base_toxin_resistance':resistance,
                'shield_toxin_resistance_per_hp':bonus,'epoch_begin_ms':begin,'epoch_end_ms':end,
                'absolute_tolerance_hp':D('1e-12'),'relative_tolerance':D('1e-12'),
                'rate_evaluations':dense.evaluations}
        cached={'key':key,'begin':begin,'end':end,'curve':curve,'inputs':inputs}
        self.caches[effect.id]=cached
        return cached

    def prepare(self,end):
        effects=[e for e in self.world.effect_system.effects.values() if isinstance(e,AttachedVenom)
            and not e.ended and self.world.fighters[e.target].hp>0]
        finish=end
        for effect in effects:
            finish=min(finish,effect.detach_ms if self.world.time<effect.detach_ms else effect.expiry)
        if finish>self.world.time:
            for effect in effects:self._ensure(effect,self.world.time,finish)
        return finish

    def component(self,effect,begin,end):
        if end<=begin:return None
        cached=self._ensure(effect,begin,end)
        amount=cached['curve'].integral(begin,end)
        if not amount:return None
        return {'effect_id':effect.id,'kind':'venom','actor':effect.source.actor,'ability':effect.source.ability,
            'action_id':effect.source.action_id,**effect.source.life_record(),'channel':'hp','amount':amount,
            'inputs':{**cached['inputs'],'delivery':effect.delivery,'damage_after_shield':effect.damage_after_shield,
                'armor_snapshot':effect.armor_snapshot,'piercing':effect.piercing,'toxicity':effect.toxicity,
                'formula':FORMULA,'shield_handling':'already delivered inside the body; HP only'}}

    def curve(self,effect_id,begin,end):
        cached=self.caches[effect_id]
        if not cached['begin']<=begin<=end<=cached['end']:raise ValueError('Venom history query exceeds its prepared dose')
        return cached['curve']
