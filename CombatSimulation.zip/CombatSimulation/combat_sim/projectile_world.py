"""Composition boundary between projectile entities and the shared world."""
from copy import deepcopy
from decimal import Decimal as D, ROUND_CEILING
from types import SimpleNamespace

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.projectile_clearance import first_owner_separation
from combat_sim.projectile_entities import ProjectileContactPolicy, ProjectileRegistry
from combat_sim.projectile_limits import AnchoredProjectileLimits
from combat_sim.pose_kinematics import pose_acceleration


class SharedProjectiles:
    def __init__(self,world,definition=None):
        self.world=world
        self.registry=ProjectileRegistry(definition)
        self.deferred_clearances={}
        self.limits=AnchoredProjectileLimits(world)

    def create(self,actor,action,ability,kinematics):
        if hasattr(action,'definition_snapshot'):
            kinematics={**kinematics,'definition_snapshot':deepcopy(action.definition_snapshot)}
        if getattr(action,'target_snapshot',None) is not None:
            kinematics={**kinematics,'target_snapshot':deepcopy(action.target_snapshot)}
        aim_part=getattr(action,'aim_part',None)
        if aim_part is not None:kinematics={**kinematics,'aim_part':aim_part}
        reach=getattr(self.world,'hand_reach',None)
        if reach is not None and reach.ready:
            kinematics={**kinematics,**reach.release_fields(actor,ability)}
        policy=ProjectileContactPolicy.from_definition(ability['projectile_geometry'].get('contact_policy'))
        if not self.world.mobile_mode and policy!=ProjectileContactPolicy():
            raise UnsupportedMechanicError('Non-default projectile contact policy requires moving combat')
        if ability.get('execution_model')=='binding_projectile':
            kinematics={**kinematics,'contact_payload':{'binding':deepcopy(ability['binding']),
                'target_effects':deepcopy(ability['target_effects'])}}
            if 'flight_limit' in ability:kinematics['contact_payload']['flight_limit']=deepcopy(ability['flight_limit'])
        if ability.get('execution_model')=='hook_projectile':
            kinematics={**kinematics,'contact_payload':{'hook':deepcopy(ability['hook']),
                'flight_limit':deepcopy(ability['flight_limit'])}}
        if ability.get('execution_model')=='impact_area_projectile':
            kinematics={**kinematics,'contact_payload':{'impact_area':deepcopy(ability['impact_area']),
                'target_effects':deepcopy(ability['target_effects']),'damage_type':ability['damage_type']}}
        if ability.get('execution_model')=='poison_projectile':
            kinematics={**kinematics,'contact_payload':{'poison':deepcopy(ability['poison']),
                'target_effects':deepcopy(ability['target_effects'])}}
        if ability.get('execution_model')=='impact_binding_area':
            kinematics={**kinematics,'contact_payload':{'impact_binding_area':deepcopy(ability['impact_binding_area']),
                'target_effects':deepcopy(ability['target_effects'])}}
        if ability.get('execution_model')=='construct_projectile':
            kinematics={**kinematics,'contact_payload':{'contact_construct':deepcopy(ability['contact_construct']),
                'target_effects':deepcopy(ability['target_effects'])}}
        flight=self.registry.create(action_id=action.id,owner=actor.id,ability=action.ability_id,
            created_at_ms=self.world.time,kinematics=kinematics,policy=policy,source_life_generation=action.life_generation)
        self.world.effort_system.capture_release(actor,action,ability,flight)
        return flight

    def groups(self,flight):
        world=self.world
        policy=self.registry.policies[flight['id']]
        groups=[]
        for name,boxes in world.world_bodies.items():
            boxes=(() if world.fighters[name].hp<=0 else tuple(boxes))+world.blocking.boxes(name)
            if not boxes:
                continue
            if name==flight['actor']:
                if policy.owner=='ignore' or flight['owner_cleared_at_ms'] is None:
                    continue
            elif policy.other_bodies=='ignore':
                continue
            groups.append((name,boxes,False))
        if world.terrain_mode and policy.terrain=='impact':
            groups.extend((name,boxes,True) for name,boxes in world.collider_system.registry.active('projectiles',world.time).items())
        return groups

    def _clearance(self,flight,end):
        world=self.world
        if (self.registry.policies[flight['id']].owner=='ignore' or
                flight['owner_cleared_at_ms'] is not None or world.fighters[flight['actor']].hp<=0):
            return None
        deferred=self.deferred_clearances.pop(flight['id'],None)
        if deferred is not None:
            confirmed,absolute,payload=deferred
            if world.time>=confirmed and self.registry.live(payload):
                if absolute>end:
                    self.deferred_clearances[flight['id']]=deferred
                return max(world.time,absolute),payload
        start=flight['trajectory_started_at_ms']
        begin_s=float((world.time-start)/1000)
        end_s=float((end-start)/1000)
        if world.gravity_mode:
            trajectory=world.gravity_trajectories[flight['id']]
            end_s=min(end_s,trajectory.duration)
            if trajectory.stopping_time_s is not None:
                end_s=min(end_s,trajectory.stopping_time_s)
            path=SimpleNamespace(at=trajectory.at,gravity=trajectory.gravity,
                deceleration=trajectory.deceleration,radius_m=flight['radius_m'])
            time_tolerance=float(world.physics['contact_time_tolerance_s'])
            clearance_tolerance=float(world.physics['contact_clearance_tolerance_m'])
            bound=None
        else:
            def at(seconds):
                point=world.mobile_flight_state(flight,start+dec(seconds)*1000)[0]
                return SimpleNamespace(position_m=tuple(map(float,point)))
            path=SimpleNamespace(at=at,radius_m=flight['radius_m'])
            time_tolerance,clearance_tolerance=1e-12,1e-14
            bound=abs(float(flight['acceleration_mps2']))
            if 'stops_at_ms' in flight:
                end_s=min(end_s,float((flight['stops_at_ms']-start)/1000))
        if begin_s>end_s:
            return None
        name=flight['actor']
        velocity,acceleration=world.mobile_motion(name)
        boxes=[]
        for box in world.world_bodies[name]:
            offset,size_rate=world.pose_part_motion(name,box.part,world.time)
            pose_accel,size_accel=pose_acceleration(world,name,box.part,world.time)
            combined_accel=tuple(a+b for a,b in zip(acceleration,pose_accel)) if any(pose_accel) else acceleration
            row=(box,tuple(v+o for v,o in zip(velocity,offset)),combined_accel,size_rate)
            boxes.append((*row,size_accel) if any(size_accel) else row)
        separation=first_owner_separation(path,boxes,begin_s,end_s,time_tolerance_s=time_tolerance,
            clearance_tolerance_m=clearance_tolerance,acceleration_bound_mps2=bound)
        if separation is None:
            return None
        # The binary64 endpoint can round above the exact Decimal boundary.
        # Reaching that supplied interval still confirms its numerical witness.
        confirmed=min(end,max(world.time,start+dec(separation.time_upper_s)*1000))
        absolute=confirmed
        quantum=world.physics['event_quantum_ms'] if world.gravity_mode else D('0.000001')
        absolute=(absolute/quantum).to_integral_value(rounding=ROUND_CEILING)*quantum
        payload={'projectile_id':flight['id'],'projectile_revision':flight['revision'],
            'projectile_event':'projectile_owner_cleared',
            'separation_bracket_s':[separation.time_lower_s,separation.time_upper_s]}
        if absolute>end:
            self.deferred_clearances[flight['id']]=(confirmed,absolute,payload)
        return absolute,payload

    def initialize_owner(self,flight):
        world=self.world
        owner=world.fighters[flight['actor']]
        if (world.life_cycles.enabled and self.registry.policies[flight['id']].owner!='ignore'
                and (owner.hp<=0 or flight.get('source_life_generation')!=owner.life_generation)):
            # The original birth body no longer exists. A new copy is born
            # armed, just like an ordinary copy already outside that body.
            flight['owner_cleared_at_ms']=world.time
            return
        separation=self._clearance(flight,self.world.time)
        if separation is not None:
            flight['owner_cleared_at_ms']=self.world.time
            self.deferred_clearances.pop(flight['id'],None)

    def clearance_boundary(self,flight,end):
        result=self._clearance(flight,end)
        return result if result is not None and result[0]<=end else None

    def schedule_stop(self,flight,*,priority=0):
        if 'stops_at_ms' in flight:
            self.world.push(flight['stops_at_ms'],'projectile_stopped',
                {'projectile_id':flight['id'],'projectile_revision':flight['revision']},priority=priority)

    def owner_cleared(self,payload):
        if not self.registry.live(payload):
            return
        flight=self.registry.flights[payload['projectile_id']]
        self._mark_owner_cleared(flight,separation_bracket_s=payload['separation_bracket_s'])

    def _mark_owner_cleared(self,flight,**evidence):
        if flight['owner_cleared_at_ms'] is not None:
            return
        flight['owner_cleared_at_ms']=self.world.time
        flight['revision']+=1
        self.deferred_clearances.pop(flight['id'],None)
        if self.world.gravity_mode:
            self.world.gravity_deferred_contacts.pop(flight['id'],None)
        self.schedule_stop(flight,priority=3 if self.world.gravity_mode else 0)
        self.world.log('projectile_owner_cleared',**self.registry.link(flight),**evidence)

    def retire_owner_life(self,actor,generation):
        for flight in self.registry.flights.values():
            if (flight['actor']==actor and flight.get('source_life_generation')==generation
                    and flight['status']=='in_flight' and flight['owner_cleared_at_ms'] is None
                    and self.registry.policies[flight['id']].owner!='ignore'):
                self._mark_owner_cleared(flight,reason='owner_life_ended')

    def collide(self,flight,payload):
        if not self.registry.live(payload):
            return None
        world=self.world
        if 'block_layer_id' in payload:
            if not world.blocking.contact_live(payload):return None
        elif not world.life_cycles.target_matches(payload):return None
        if 'collider_id' in payload and not world.collider_system.registry.contact_live(payload,'projectiles',world.time):
            return None
        static=payload['collision_kind']=='terrain'
        owner=payload['target']==flight['actor'] and not static
        consume=owner and self.registry.policies[flight['id']].owner=='consume_after_separation'
        self.registry.terminal(flight,'consumed' if consume else 'collided',collided_at_ms=world.time,
            collision_target=payload['target'],collision_location_m=payload['location_m'],
            collision_kind=payload['collision_kind'],traveled_distance_m=payload['distance_m'],
            **({'collision_target_life_generation':payload['target_life_generation']}
                if 'target_life_generation' in payload else {}))
        if static:
            world.fighters[flight['actor']].metrics['terrain_contacts']+=1
        world.log('projectile_owner_consumed' if consume else 'projectile_terrain_collision' if static else
            'projectile_body_collision',**payload)
        return None if consume else payload

    def copy(self,entity_id,*,source,offset_m):
        """Create one independent flight without spending ammo/cost or reaiming.

        Field entry/placement belongs to the authored duplication controller.
        Both parent and child remember the source to prevent recursive copying
        by that same field instance. Different fields may each copy a lineage.
        """
        world=self.world
        if not world.mobile_mode or self.registry.trace_schema!='entity_v1':
            raise UnsupportedMechanicError('Projectile copying requires current moving entity rules')
        if entity_id not in self.registry.flights:
            raise ValueError('Unknown projectile entity')
        if not isinstance(source,str) or not source:
            raise ValueError('Projectile copying needs a source instance identity')
        try:
            if len(offset_m)!=3 or any(isinstance(v,bool) for v in offset_m):
                raise ValueError
            offset=tuple(map(dec,offset_m))
            if not all(v.is_finite() for v in offset):
                raise ValueError
        except (TypeError,ValueError,ArithmeticError) as error:
            raise ValueError('Copy displacement needs three finite coordinates') from error
        parent=self.registry.flights[entity_id]
        if parent['status']!='in_flight' or source in parent['duplication_sources']:
            return None
        if world.gravity_mode:
            path=world.gravity_trajectories[entity_id]
            if path.stopping_time_s is not None and float((world.time-parent['trajectory_started_at_ms'])/1000)>=path.stopping_time_s:
                return None
        data,trajectory,distance=self._branch_state(parent,offset)
        # All failing numerical construction precedes lineage/entity mutation.
        self.registry.claim_duplication(entity_id,source)
        return self._commit_child(entity_id,source,offset,data,trajectory,distance)

    def _branch_state(self,parent,offset):
        world=self.world
        point,velocity,_,distance=world.mobile_flight_state(parent,world.time)
        origin=tuple(p+d for p,d in zip(point,offset))
        speed=sum(v*v for v in velocity).sqrt()
        data={'aim_target':parent['aim_target'],'released_at_ms':parent['released_at_ms'],
            'trajectory_started_at_ms':world.time,'distance_offset_m':distance,'origin_m':origin,
            'aim_point_m':parent['aim_point_m'],'radius_m':parent['radius_m'],
            'initial_speed_mps':speed,'acceleration_mps2':parent['acceleration_mps2'],'status':'in_flight'}
        if 'contact_payload' in parent:data['contact_payload']=deepcopy(parent['contact_payload'])
        if 'definition_snapshot' in parent:data['definition_snapshot']=deepcopy(parent['definition_snapshot'])
        if 'accuracy' in parent:data['accuracy']=deepcopy(parent['accuracy'])
        if world.gravity_mode:
            controls={key:float(world.physics[key]) for key in
                ('gravity_mps2','max_step_s','relative_tolerance','absolute_tolerance','speed_floor_mps','stop_time_tolerance_s')}
            trajectory=PersistentProjectileTrajectory(origin,velocity,float((world.horizon-world.time)/1000),
                deceleration_mps2=-parent['acceleration_mps2'],**controls)
            data['initial_velocity_mps']=tuple(map(float,velocity))
        else:
            if speed<=0:
                raise UnsupportedMechanicError('Cannot copy a straight shot with no travel direction')
            data['direction']=tuple(v/speed for v in velocity)
        return data,trajectory if world.gravity_mode else None,distance

    def _commit_child(self,entity_id,source,offset,data,trajectory,distance):
        world=self.world
        identity=self.registry.identities[entity_id]
        child=self.registry.create(action_id=identity.action_id,owner=identity.owner,ability=identity.ability,
            created_at_ms=world.time,kinematics=data,policy=self.registry.policies[entity_id],parent=entity_id,
            source_life_generation=identity.source_life_generation)
        if world.gravity_mode:
            world.gravity_trajectories[child['id']]=trajectory
            if trajectory.stopping_time_s is not None:
                child['stops_at_ms']=world._gravity_event_time(world.time+dec(trajectory.stopping_time_s)*1000)
                child['stopping_time_bracket_s']=trajectory.stopping_time_bracket_s
        elif child['acceleration_mps2']<0:
            child['stops_at_ms']=world.time-child['initial_speed_mps']/child['acceleration_mps2']*1000
        self.initialize_owner(child)
        self.schedule_stop(child,priority=3 if world.gravity_mode else 0)
        actor=world.fighters[identity.owner]
        actor.metrics['projectile_copies_created']=actor.metrics.get('projectile_copies_created',0)+1
        world.log('projectile_copied',**self.registry.link(child),parent_projectile_id=entity_id,
            source_instance=source,offset_m=offset,retained_traveled_distance_m=distance)
        return child['id']


    def split(self,entity_id,*,source,separation_m):
        """Atomic symmetric lateral split with retained source/power/path length.

        The displacement is an instantaneous authored shift, not traveled path.
        Both trajectories are constructed before claiming the field or changing
        the parent. Endpoint collisions are left to ordinary physical queries.
        """
        from combat_sim.world_colliders import finite
        separation=finite(separation_m,'Projectile separation',positive=True)
        if not self.world.mobile_mode or self.registry.trace_schema!='entity_v1':
            raise UnsupportedMechanicError('Projectile splitting requires current moving entity rules')
        if entity_id not in self.registry.flights or not isinstance(source,str) or not source:
            raise ValueError('Splitting needs a known projectile and source instance')
        parent=self.registry.flights[entity_id];world=self.world
        if parent['status']!='in_flight' or source in parent['duplication_sources']:return None
        if world.gravity_mode:
            path=world.gravity_trajectories[entity_id]
            if path.stopping_time_s is not None and float((world.time-parent['trajectory_started_at_ms'])/1000)>=path.stopping_time_s:return None
        centre,velocity,_,distance=world.mobile_flight_state(parent,world.time)
        horizontal=(velocity[0]**2+velocity[1]**2).sqrt()
        normal=((-velocity[1]/horizontal,velocity[0]/horizontal,D(0)) if horizontal else (D(1),D(0),D(0)))
        offset=tuple(v*separation/2 for v in normal)
        left,left_path,_=self._branch_state(parent,tuple(-v for v in offset))
        right,right_path,_=self._branch_state(parent,offset)
        parent.setdefault('birth_kinematics',{key:deepcopy(parent[key]) for key in
            ('origin_m','trajectory_started_at_ms','distance_offset_m','initial_velocity_mps',
             'initial_speed_mps','acceleration_mps2','direction') if key in parent})
        self.registry.claim_duplication(entity_id,source)
        parent.update(left,revision=parent['revision']+1)
        parent.pop('stops_at_ms',None);parent.pop('stopping_time_bracket_s',None)
        self.deferred_clearances.pop(entity_id,None)
        if world.gravity_mode:
            world.gravity_deferred_contacts.pop(entity_id,None)
            world.gravity_trajectories[entity_id]=left_path
            if left_path.stopping_time_s is not None:
                parent['stops_at_ms']=world._gravity_event_time(world.time+dec(left_path.stopping_time_s)*1000)
                parent['stopping_time_bracket_s']=left_path.stopping_time_bracket_s
        elif parent['acceleration_mps2']<0:
            parent['stops_at_ms']=world.time-parent['initial_speed_mps']/parent['acceleration_mps2']*1000
        if parent['owner_cleared_at_ms'] is None:self.initialize_owner(parent)
        self.schedule_stop(parent,priority=3 if world.gravity_mode else 0)
        child=self._commit_child(entity_id,source,offset,right,right_path,distance)
        row={'parent_projectile_id':entity_id,'child_projectile_id':child,'source_instance':source,
            'centre_before_m':centre,'parent_origin_m':left['origin_m'],'child_origin_m':right['origin_m'],
            'retained_velocity_mps':velocity,'retained_traveled_distance_m':distance,'separation_m':separation,
            'source_life_generation':parent.get('source_life_generation')}
        world.log('projectile_split',**row)
        return row
