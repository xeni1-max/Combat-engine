"""Stationary team rules attached to the existing shared event timeline.

Scheduling, formulas, input data and replaceable decisions stay separate. This
module supplies the integrated rules for the explicitly declared stationary
team scope; the earlier controlled duel remains reproducible under its scope.
"""
from collections import defaultdict
from decimal import Decimal as D

from combat_sim.battle_actions import AbilityOption, ActorOptions
from combat_sim.automatic_abilities import ability_definition
from combat_sim.body_collisions import BodyCollisionRules
from combat_sim.battle_models import BattleAction, ceil_ms, decimal_value as dec
from combat_sim.mechanics import projectile_damage, slash
from combat_sim.mechanics.dyspnea import (
    DyspneaContext, apply_action_dyspnea, apply_action_dyspnea_at_phase, dyspnea_loss_rate,
)
from combat_sim.pose_kinematics import physical_hand_recovery
from combat_sim.mechanics.simultaneous import DamagePacket, calculate_simultaneous_impacts
from combat_sim.mechanics.status import mitigate_status
from combat_sim.models import UnsupportedMechanicError
from combat_sim.stationary_geometry import distance_metres, within_radius
from combat_sim.target_policies import target_snapshot as immutable_target_snapshot, select_enemy, describe_selection


TEAM_SCOPE = {
    'movement': 'stationary', 'hit_eligibility': 'confirmed',
    'area_eligibility': 'position_centres_inclusive',
    'dyspnea_eligibility': 'enforced', 'recovery_eligibility': 'enforced',
    'zero_hp': 'death', 'coupled_simultaneous_events': 'shared_snapshot_phases_first',
    'shield_regeneration': 'per_loss_delay_shared_rate',
}
BODY_SCOPE = dict(TEAM_SCOPE,hit_eligibility='swept_sphere_bodies',
                  area_eligibility='body_sphere_and_vertical_cylinder',
                  projectile_motion='straight_no_gravity',ground_collision='not_implemented')
TERRAIN_SCOPE = dict(BODY_SCOPE,ground_collision='finite_static_terrain',
                    obstacles='fixed_solid_cubes',area_occlusion='ignored')


class StationaryTeamRules(BodyCollisionRules):
    def team_distance(self, actor, target):
        return distance_metres(self.fighters[actor].position_m, self.fighters[target].position_m,
                               precision=self.precision)

    def resource_ready_time(self, actor, rule):
        if rule['kind'] == 'none' or apply_action_dyspnea(actor.dyspnea, rule['base_value']).allowed:
            return self.time
        # Scenario policy forecasts affordability while free; the authoritative
        # check/payment still occurs at the authored phase. Recovery, Gathering
        # and Active block resource decay for this stationary action subset.
        base = dec(rule['base_value'])
        b, c = 100+2*base, 100-base**2
        if c < 0:
            return D('Infinity')
        maximum = 200*c/(b+(b*b+4*c).sqrt())
        delay = max(actor.disorientation, actor.instability)
        rate = D('0.018') if self.mobile_mode and self.mobile_is_running(actor.id) else D('0.03')
        return ceil_ms(self.time+delay+max(D(0), actor.dyspnea-maximum)/rate)

    def decide_team(self, name):
        actor, config = self.fighters[name], self.choices[name]
        actor.decision_due = None
        owned=actor.action_registry is not None
        if actor.died_at_ms is not None or (not owned and actor.current is not None):
            return
        if actor.knocked_down:
            return self.request_get_up(actor)
        if self.mobile_mode:
            if self.try_mobile_intent(actor) and not owned:
                return
            self.aim_control.try_pending(actor)
            self.turns.try_pending(actor)
            self.melee.try_prepare(actor)
            self.weapon_modes.try_return(actor)
            if self.mobile_weapon_blocked(actor):
                if not any(actor.profile['abilities'][key]['execution_model'] in ('block','dodge','ballistic_dash','ballistic_leap') for key in config['abilities']):
                    self.log('weapon_actions_blocked',actor=name,reason='sprinting')
                    return
            if self.time < dec(config.get('start_ms',0)):
                self.request_decision(name,dec(config['start_ms']))
                return
        snapshot = immutable_target_snapshot(self.states())
        target_policy = self.target_policies[name]
        target = select_enemy(target_policy, name, snapshot)
        options = []
        components={}
        for ability_id in config['abilities']:
            self_target=ability_definition(actor,ability_id).get('target_mode')=='self'
            if target is None and not self_target and self.scripted_targets.for_ability(actor,ability_id) is None:
                continue
            component=self.melee.next_component(actor,ability_id,target)
            components[ability_id]=component
            ability = self.melee.definition(actor,ability_id,component)
            reload = actor.ammo.get(ability_id) == 0 and config.get('reload_when_empty', False)
            if not self.weapon_requirements_available(actor,ability_id,reload,component=component):
                continue
            rule = ability['reload_dyspnea'] if reload else ability['dyspnea']
            options.append(AbilityOption(ability_id, self.cooldown_system.ready_at(actor,ability_id), actor.ammo.get(ability_id),
                                         max(self.resource_ready_time(actor, rule),
                                             self.effort_system.ready_at(actor,ability_id,reload),
                                             self.melee.ready_at(actor,ability_id))))
        if not options:
            return
        choice = self.policy.choose(ActorOptions(name, target if target is not None else actor.id, self.time, self.time, tuple(options),
                                                config.get('reload_when_empty', False)))
        if choice.kind == 'wait':
            if choice.at_ms.is_finite():
                self.log('policy_wait', actor=name, resume_at_ms=choice.at_ms, dyspnea=actor.dyspnea)
                self.request_decision(name, choice.at_ms)
            return
        ability_id, reload = choice.ability_id, choice.kind == 'reload'
        selection = (describe_selection(target_policy,name,snapshot,target)
                     if target_policy.name != 'nearest_living_enemy' else None)
        target_snapshot=self.scripted_targets.for_ability(actor,ability_id)
        if target_snapshot is not None:target=None
        component=components[ability_id]
        ability = self.melee.definition(actor,ability_id,component)
        return self.start_team_action(actor,target,ability_id,reload,component,target_snapshot,ability,
                                      target_selection=selection)

    def start_team_action(self,actor,target,ability_id,reload,component,target_snapshot,ability,*,target_selection=None):
        name=actor.id;config=self.choices[name];owned=actor.action_registry is not None
        if ability.get('target_mode')=='self':target=actor.id
        timing = actor.profile['timing_profiles'][ability['timing_profile']]
        poses = ability['reload_hand_positions_m'] if reload else ability['hand_positions_m']
        recovery_value = dec(actor.profile['recovery_value'])
        if self.mobile_mode and self.mobile_is_running(name):
            recovery_value *= D('1.2')
        previous_hands,target_hands=actor.hands,poses['start']
        recovery, calculation = ((0,{}) if ability['execution_model'] in ('attack_enhancement','ballistic_dash','ballistic_leap','dodge') or self.melee.continues_now(actor,ability_id,component) else
            physical_hand_recovery(self,actor,previous_hands,target_hands,recovery_value,equilibrium_legacy=True))
        action = BattleAction(next(self.action_ids), name, target, ability_id,
                              'reload' if reload else ability['execution_model'], self.time,
                              self.time+D(recovery), dec(ability['reload_active_ms'] if reload else timing['active_ms']),
                              phase='recovery', recovery_end_ms=self.time+D(recovery),
                              base_gathering_ms=dec(ability['reload_gathering_ms'] if reload else timing['gathering_ms']),component_id=component,
                              aim_part=config.get('aim_part') if target_snapshot is None else None,
                              aim_location_m=None if target_snapshot is None else target_snapshot['point_m'],
                              target_snapshot=target_snapshot)
        if action.kind=='block':action.active_ms=self.blocking.active_duration(actor,ability_id)
        if action.kind=='ballistic_dash':action.aim_location_m=tuple(map(dec,self.fighters[target].body_origin_m))
        self.weapon_modes.snapshot(actor,action,ability)
        actor.current = action
        self.weapon_modes.selected(actor,action)
        if action.kind=='contact_field':
            self.segment_fields.selected(actor,action);target_snapshot=action.target_snapshot
        if action.kind=='projectile_duplication_area':self.projectile_duplication.selected(actor,action)
        if action.kind=='portal_pair':self.portals.selected(actor,action)
        if action.kind=='conditional_melee':self.conditional_melee.selected(actor,action)
        self.effort_system.action_started(actor,action)
        actor.metrics['reloads_started' if reload else 'activations_started'] += 1
        if action.kind in ('heat_beam','cooldown_pause_area','contact_field','projectile_duplication_area','portal_pair','attack_enhancement'):
            if action.kind=='cooldown_pause_area':
                action.aim_location_m=tuple(map(dec,next(b.centre_m for b in self.world_bodies[target] if b.part=='torso')))
            self.cooldown_system.start(actor,ability_id,dec(ability['cooldown_ms']),action.id)
        if target_selection is not None:
            self.log('target_policy_selected',actor=name,ability=ability_id,action_id=action.id,
                     action_target=action.target,action_kind=action.kind,**target_selection)
        self.log('reload_requested' if reload else 'ability_started', actor=name, target=target,
                 **({'aim_part':action.aim_part} if action.aim_part is not None else {}),
                 **({'component_id':component} if component is not None else {}),
                 **({'target_snapshot':target_snapshot} if target_snapshot is not None else {}),
                 ability=ability_id, action_id=action.id, original_location_m=(
                     self.fighters[target].position_m if target is not None else action.aim_location_m),
                 recovery_ms=recovery, individual_hands=calculation, recovery_end_ms=action.recovery_end_ms,
                 base_gathering_ms=action.base_gathering_ms, active_ms=action.active_ms,
                 eligibility={'dyspnea': 'enforced', 'physical_recovery': 'enforced'})
        self._schedule_phase(action, 'recovery_completed', action.recovery_end_ms)
        if owned:
            # Acquisition owns new nonempty, disjoint resources. Revisit
            # eligibility after due phases so every independent action can
            # start now; a blocked/no-option decision schedules no retry.
            self.request_decision(actor.id,self.time)

    def recovery_completed(self, p):
        actor = self.fighters[p['actor']]
        action = actor.current
        if action.kind=='replacement_grab':return self.melee.grab_recovery_completed(actor,action)
        if self.mobile_mode and action.kind == 'locomotion':
            return self.complete_sprint_recovery(actor)
        ability = self.action_definition(actor,action)
        poses = ability['reload_hand_positions_m'] if action.kind == 'reload' else ability['hand_positions_m']
        actor.hands.update(poses['start'])
        action.phase = 'gathering'
        factor = D('1.2') if self.mobile_mode and self.mobile_is_running(actor.id) else D(1)
        action.active_due_ms = ceil_ms(self.time+action.base_gathering_ms*factor+actor.disorientation)
        self.timed_gathering.commit(actor,action)
        self.log('gathering_started', actor=actor.id, action_id=action.id,
                 disorientation_at_start=actor.disorientation, active_start_ms=action.active_due_ms)
        self._schedule_phase(action, 'active_started', action.active_due_ms)

    def pay_team_dyspnea(self, actor, phase, *, rule=None):
        action = actor.current
        if rule is not None:pass
        elif action.kind == 'get_up':
            rule = self.common_profiles[actor.id]['dyspnea']
        else:
            ability = self.action_definition(actor,action)
            rule = ability['reload_dyspnea'] if action.kind == 'reload' else ability['dyspnea']
        payment = (self.action_payment(actor,action,rule['base_value'],phase)
                   if actor.action_registry is not None and rule['kind']!='none' and rule['payment_timing']==phase
                   else apply_action_dyspnea_at_phase(actor.dyspnea, rule, phase))
        if payment is None:
            return True
        if not payment.allowed:
            if actor.action_registry is not None:
                # Continuous effort is not a reserved point debit. It can
                # consume capacity promised earlier, so the actual payment
                # remains authoritative. Do not emit work or a paid receipt.
                self.log('dyspnea_payment_rejected',actor=actor.id,ability=action.ability_id,
                    action_id=action.id,action_kind=action.kind,phase=phase,
                    before=dec(payment.before),required=dec(payment.action_value),
                    available_capacity=dec(payment.available_capacity),
                    reserved_for_other_actions=actor.action_registry.reserved(action.id),
                    base_value=rule['base_value'])
                self.cancel_owned_action(actor,action,'payment_capacity_exhausted')
                return False
            raise UnsupportedMechanicError('Payment-phase capacity failed; no firing/release ordering is inferred')
        actor.dyspnea = dec(payment.after)
        actor.metrics['dyspnea_paid'] += dec(payment.action_value)
        self.log('dyspnea_paid', actor=actor.id, ability=action.ability_id, action_id=action.id,
                 action_kind=action.kind, phase=phase, before=dec(payment.before),
                 base_value=rule['base_value'], amount=dec(payment.action_value), after=actor.dyspnea)
        if payment.reached_maximum:
            actor.disorientation += dec(payment.disorientation_trigger)
            self.extend_parallel_gatherings(actor,dec(payment.disorientation_trigger),action.id)
            self.log('maximum_dyspnea_trigger', actor=actor.id,
                     added_disorientation=dec(payment.disorientation_trigger))
        return True

    def deploy_team_heat(self, actor, action, ability):
        if self.effect_system.enabled:
            return self.effect_system.deploy_heat(actor,action,ability)
        if self.terrain_mode and self.collider_system.registry.active('areas',self.time):
            raise UnsupportedMechanicError('Beam exposure with area-blocking colliders requires volume/exposure integration')
        centre = self.fighters[action.target].position_m
        leave = self.time+dec(ability['beam_duration_ms'])
        if self.body_mode:
            centre = tuple(map(dec,self.fighters[action.target].body_origin_m))
            names = self.body_area_recipients(centre,ability['radius_m'],ability['area_shape'])
            recipients = [self.fighters[name] for name in names]
        else:
            recipients = [f for f in self.fighters.values() if f.hp > 0 and
                          within_radius(f.position_m, centre, ability['radius_m'])]
        self.log('beam_deployed', actor=actor.id, ability=action.ability_id,
                 location_m=centre, recipients=[f.id for f in recipients], leave_ms=leave)
        for target in recipients:
            effect = {'id': next(self.effect_ids), 'kind': 'heat', 'actor': actor.id, 'target': target.id,
                      'ability': action.ability_id, 'mode': 'shield' if target.shield else 'hp',
                      'start': self.time, 'leave': leave, 'expiry': leave+dec(ability['beam_duration_ms'])/2,
                      'heat_output': dec(ability['heat_output']), 'k': dec(ability['k'])}
            self.effects.append(effect)
            self.push(leave, 'beam_exposure_ended', {'effect_id': effect['id']})
            self.push(effect['expiry'], 'effect_expired', {'effect_id': effect['id']})
            self.log('heat_started', effect=effect, autonomous=True, source=ability['source'])

    def resolve_team_impacts(self, batch):
        targets = defaultdict(list)
        collider_targets=defaultdict(list)
        grabs=[]
        knock_defenses=self.knock_motion.snapshot()
        for _, _, _, kind, p in batch:
            if kind=='melee_impact':
                p=self.melee.resolve_frame(p)
                if p is None:continue
                kind='impact'
            elif kind=='owned_contact':
                p=self.owned_contacts.resolve(p)
                if p is None:continue
                if self.attack_definition(p['actor'],p['ability'])['execution_model']=='ballistic_leap':self.body_leaps.contact(p)
                kind='impact'
            ability = self.attack_definition(p['actor'],p['ability'],p.get('melee_component'),packet=p)
            if kind == 'area_impact':
                if self.body_mode:
                    recipients = self.body_area_recipients(p['location_m'],ability['delayed_area']['radius_m'],
                                                           ability['delayed_area']['shape'])
                else:
                    recipients = [f.id for f in self.fighters.values() if f.hp > 0 and
                                  within_radius(f.position_m, p['location_m'], ability['delayed_area']['radius_m'])]
                constructs=(self.collider_system.area_recipients(p['location_m'],ability['delayed_area']['radius_m'],
                    ability['delayed_area']['shape']) if self.terrain_mode else [])
                self.log('delayed_blast', **p, recipients=recipients,
                    **({'collider_recipients':constructs} if self.terrain_mode and self.collider_system.instant_areas else {}))
                for name in recipients:
                    targets[name].append(dict(p, target=name, **self.life_cycles.target_fields(name)))
                for name in constructs:
                    collider_targets[name].append(dict(p,target=name,collision_kind='terrain',
                        **self.collider_system.registry.contact_fields(name)))
            elif kind == 'impact':
                if ability['execution_model']=='charge_grab' and self.charge_grapples.contact(p):continue
                if self.body_mode and 'attack_id' not in p:
                    p = self.live_body_projectile_payload(p)
                    if p is None:
                        continue
                if ability['execution_model']=='poison_projectile':
                    for burst in self.weapon_modes.expand(p):targets[burst['target']].append(burst)
                    continue
                if ability['execution_model']=='hook_projectile':
                    self.grappling_gun.queue(p)
                    continue
                if ability['execution_model']=='impact_binding_area':
                    for burst in self.impact_bindings.expand(p):targets[burst['target']].append(burst)
                if ability['execution_model']=='impact_area_projectile':
                    bodies,materials=self.impact_areas.expand(p)
                    for burst in bodies:targets[burst['target']].append(burst)
                    for burst in materials:collider_targets[burst['target']].append(burst)
                    continue
                if ability['execution_model']=='binding_projectile' and (p.get('collision_kind')=='terrain' or 'block_layer_id' in p):
                    self.log('binding_projectile_blocked',**p)
                    continue
                if ability['execution_model']=='construct_projectile' and (p.get('collision_kind')=='terrain' or 'block_layer_id' in p):
                    self.log('construct_projectile_blocked',**p)
                    continue
                if ability['execution_model'] == 'projectile_delayed_area':
                    blast = dict(p, component='delayed_blast')
                    blast.pop('block_layer_id',None)
                    blast.pop('target_life_generation',None)
                    if self.terrain_mode:
                        blast['origin_collision_kind'] = blast.pop('collision_kind')
                    self.push(self.time+dec(ability['delayed_area']['delay_ms']), 'area_impact', blast)
                if p.get('collision_kind') == 'terrain':
                    if ability['execution_model'] in ('grapple_grab','charge_grab'):
                        grabs.append(p);continue
                    if 'collider_id' in p:collider_targets[p['collider_id']].append(p)
                    continue
                if self.fighters[p['target']].hp > 0 or self.blocking.contact_live(p):
                    targets[p['target']].append(p)
                else:
                    self.log('projectile_arrived_at_dead_target_location', **p)
            else:
                raise RuntimeError(f'Unexpected impact batch event {kind}')
        for name, packets in sorted(targets.items()):
            target = self.fighters[name]
            before = target.record()
            status_resistance=self.target_status_resistance(target)
            inputs = []
            for p in packets:
                ability = self.attack_definition(p['actor'],p['ability'],p.get('melee_component'),packet=p)
                raw = self.effort_system.raw_damage(p,ability)
                if 'range_falloff' in ability:
                    falloff = ability['range_falloff']
                    raw = dec(projectile_damage.damage_after_distance(
                        raw, p['distance_m'], falloff['damage_loss'], falloff['distance_m']))
                modifiers=self.attack_modifiers.values(p)
                if ability['execution_model'] in ('grapple_grab','charge_grab','binding_projectile','construct_projectile') or 'impact_binding_burst_id' in p:
                    inputs.append(DamagePacket('contact',0))
                    if ability['execution_model'] in ('grapple_grab','charge_grab'):grabs.append(p)
                else:
                    inputs.append(DamagePacket(self.impact_areas.damage_type(p,ability.get('direct_damage_type',ability['damage_type'])),raw,
                        self.attack_modifiers.piercing(p,ability),modifiers.shielding_ignored,modifiers.additional_armor_loss))
            if self.blocking.enabled:inputs=self.blocking.route(name,packets,inputs)
            calculations = calculate_simultaneous_impacts(inputs, target.armor, target.shield,
                                                         target.profile['resistances']['qard'])
            nominal = sum((dec(c.hp_damage) for c in calculations), D(0))
            absorbed = min(target.shield, sum((dec(c.shield_absorbed) for c in calculations), D(0)))
            armor_loss = min(target.armor, sum((dec(c.armor_loss) for c in calculations), D(0)))
            actual = min(target.hp, nominal)
            self.applied_damage.point(name,packets,calculations,actual)
            target.hp -= actual
            target.shield -= absorbed
            target.armor -= armor_loss
            target.metrics['direct_hp_damage_received'] += actual
            target.metrics['shield_damage_received'] += absorbed
            target.metrics['armor_lost'] += armor_loss
            self._record_shield_loss(name, absorbed)
            additions = {'disorientation': D(0), 'instability': D(0)}
            details = []
            for p, c in zip(packets, calculations):
                actor = self.fighters[p['actor']]
                ability = self.attack_definition(p['actor'],p['ability'],p.get('melee_component'),packet=p)
                self.knock_motion.queue(p,c,knock_defenses)
                self.bindings.queue_mark(p,c)
                self.bindings.queue_contact(p)
                self.impact_bindings.queue(p)
                self.impact_areas.queue(p)
                self.contact_constructs.queue(p)
                actor.metrics['hits_resolved'] += 1
                if ('block_layer_id' in p and (dec(before['hp'])<=0 or
                        self.blocking.layers[p['block_layer_id']]['source_life_generation']!=target.life_generation)):
                    details.append({**p,'incoming':dec(c.incoming_damage),'shield_absorbed':dec(c.shield_absorbed),
                        'overflow':dec(c.damage_left_after_shield),'nominal_hp_damage':dec(c.hp_damage),
                        'calculated_armor_loss':dec(c.armor_loss)})
                    continue
                statuses=(self.impact_areas.statuses(p) if 'impact_area_burst_id' in p else
                    self.impact_bindings.statuses(p) if ability['execution_model']=='impact_binding_area' else
                    self.projectile_flights[p['projectile_id']]['contact_payload']['target_effects']
                    if ability['execution_model'] in ('binding_projectile','construct_projectile') else ability['target_effects'])
                for status in additions:
                    additions[status] += mitigate_status(statuses[status], target.profile['max_hp'],
                                                         dec(before['armor']), status_resistance)
                details.append({**p, 'incoming': dec(c.incoming_damage), 'shield_absorbed': dec(c.shield_absorbed),
                                'overflow': dec(c.damage_left_after_shield), 'nominal_hp_damage': dec(c.hp_damage),
                                'calculated_armor_loss': dec(c.armor_loss)})
                if (ability['execution_model']=='slash_projectile' or ability.get('direct_damage_type')=='slash') and c.hp_damage:
                    effect=self.effect_system.add_bleed(p,dec(c.hp_damage)*dec(self.attack_modifiers.values(p).bleeding_multiplier))
                    self.log('bleeding_started', effect=effect, source=slash.BLEED_SOURCE)
                if ability['execution_model']=='venomous_thrust':
                    self.venom_effects.add(p,c,dec(before['armor']))
            for status, amount in additions.items():
                setattr(target, status, getattr(target, status)+amount)
            if self.mobile_mode:
                self.refresh_mobile_locomotion()
            self.log('impact_batch_resolved', target=name, pre_hit_armor=before['armor'],
                     **({'block_status_resistance':status_resistance-dec(target.profile['status_resistance'])}
                         if self.blocking.enabled and (status_resistance>dec(target.profile['status_resistance']) or
                             any('block_layer_id' in p for p in packets)) else {}),
                     hits=details, applied_hp_damage=actual, applied_shield_damage=absorbed,
                     applied_armor_loss=armor_loss, status_additions=additions,
                     state_before=before, state_after=target.record(),
                     individual_overkill_credit=('Proportional to nominal post-defense HP damage; see applied_hp_credited receipt'
                         if self.applied_damage.enabled else 'Not allocated; losses applied once to shared state'))
            if absorbed and not target.shield:
                self._shield_broken(name)
            for action in target.live_actions():
                if not additions['disorientation'] or action.phase!='gathering':
                    continue
                old = action.active_due_ms
                action.active_due_ms = ceil_ms(old+additions['disorientation'])
                action.revision += 1
                self._schedule_phase(action, 'active_started', action.active_due_ms)
                self.log('gathering_extended', actor=name, action_id=action.id,
                         old_active_start_ms=old, added_disorientation=additions['disorientation'],
                         new_active_start_ms=action.active_due_ms)
        self.knock_motion.flush_impacts()
        if self.terrain_mode:self.collider_system.damage_packets(collider_targets)
        self.charge_grapples.flush_hand_fractures()
        self.grapple_casts.attach_batch(grabs)

    def finish_team_deaths(self):
        for name, actor in self.fighters.items():
            if actor.hp > 0 or actor.died_at_ms is not None:
                continue
            actions=actor.live_actions()
            cancelled = actions[0].record() if len(actions)==1 else None
            cancelled_all=[action.record() for action in actions]
            actor.died_at_ms = self.time
            self.cooldown_system.stop_actor(actor)
            self.effort_system.stop_actor(actor)
            if actor.action_registry is not None:
                for action in actions:
                    self.note_action_cancelled(actor,action,'death')
                    actor.action_registry.release(action.id)
                    action.revision+=1
            else:
                actor.current = None
            actor.decision_due = None
            actor.decision_revision += 1
            self.equilibrium.retire_life(name)
            if self.mobile_mode:
                self.cancel_mobile_motion(actor)
            self.life_cycles.finish_death(actor)
            self.log('character_died', actor=name, cancelled_action=cancelled,
                     released_and_deployed_effects_continue=True, state=actor.record(),
                     **({'cancelled_actions':cancelled_all} if actor.action_registry is not None else {}))

    def advance_team(self, end, *, one_interval=False):
        while self.time < end:
            begin, finish = self.time, end
            for actor in self.fighters.values():
                if actor.hp > 0 and not actor.live_actions() and actor.dyspnea > 0:
                    expiry = begin+max(actor.disorientation, actor.instability)
                    if begin < expiry < finish:
                        finish = expiry
            parts = self.components(begin, finish)
            for name, target in self.fighters.items():
                if target.hp <= 0:
                    continue
                for channel, budget in [('hp', target.hp), ('shield', target.shield)]:
                    if channel=='hp' and self.healing.has_flow(name):
                        death=self.healing.death(name,begin,finish)
                        if death is not None:finish=min(finish,death)
                        continue
                    if channel=='shield' and self.thermal_recovery.is_active(name):continue
                    amount = sum((p['amount'] for p in parts[name] if p['channel'] == channel), D(0))
                    if budget > 0 and amount >= budget:
                        _, high = self._boundary(begin, finish, name, channel, budget)
                        finish = min(finish, high)
            if self.effect_system.enabled:
                for name,obj in self.collider_system.registry.objects.items():
                    if obj.hp is None or obj.hp<=0 or not obj.active(self.time):continue
                    amount=sum((p['amount'] for p in parts.get(name,[]) if p['channel']=='hp'),D(0))
                    if amount>=obj.hp:
                        _,high=self._boundary(begin,finish,name,'hp',obj.hp)
                        finish=min(finish,high)
            parts, before = self.components(begin, finish), self.states()
            healing_payment=self.healing.interval(begin,finish)
            if self.mobile_mode:
                self.advance_mobile_geometry(begin,finish)
            elapsed = finish-begin
            self.time = finish
            for name, target in self.fighters.items():
                if target.died_at_ms is not None:
                    continue
                context = DyspneaContext('stationary', disoriented=target.disorientation > 0,
                                         unstable=target.instability > 0,
                                         gathering=any(a.phase=='gathering' for a in target.live_actions()),
                                         recovering=any(a.phase=='recovery' for a in target.live_actions()),
                                         active=any(a.phase=='active' for a in target.live_actions()))
                if self.mobile_mode:
                    context = self.mobile_dyspnea_context(target)
                if self.mobile_mode and self.continuous_effort.handles(name):
                    self.bindings.advance(target,begin,finish)
                    self.continuous_effort.advance(target,begin,finish)
                    loss=D(0)
                elif self.mobile_mode and self.mobile_sprint_effort(name):
                    self.advance_sprint_dyspnea(target,begin,finish)
                    loss = D(0)
                else:
                    loss = min(target.dyspnea, dec(dyspnea_loss_rate(context))*elapsed/1000)
                    target.dyspnea -= loss
                if loss:
                    self.log('dyspnea_recovered', actor=name, interval_start_ms=begin,
                             interval_end_ms=finish, amount=loss, after=target.dyspnea)
                recovery_plan=None
                fluid=self.thermal_recovery.is_active(name)
                if fluid:
                    regenerated,fluid_shield,recovery_record=self.thermal_recovery.commit(name,begin,finish)
                elif target.hp>0 and self.shield_flow_enabled:
                    recovery_plan=self.shield_recovery[name].plan(begin,finish)
                    regenerated=self.shield_recovery[name].commit_plan(recovery_plan)
                else:
                    regenerated = self.shield_recovery[name].advance(begin, finish) if target.hp > 0 else D(0)
                if regenerated and not fluid and any(p['kind'] == 'heat' for p in parts[name]):
                    raise UnsupportedMechanicError(
                        'Shield regeneration overlapping ongoing heat is not integrated yet')
                target.shield += regenerated
                target.metrics['shield_regenerated'] += regenerated
                if regenerated:
                    self.log('shield_regenerated', target=name, interval_start_ms=begin,
                             interval_end_ms=finish, amount=regenerated, shield_after=target.shield,
                             **({'recovery_flow':recovery_record} if fluid else
                                {'recovery_flow':recovery_plan.record()} if recovery_plan is not None else {}))
                hp = sum((p['amount'] for p in parts[name] if p['channel'] == 'hp'), D(0))
                shield = sum((p['amount'] for p in parts[name] if p['channel'] == 'shield'), D(0))
                healed=healing_payment['heals'].get(name,D(0))
                if name in healing_payment['heals']:
                    healed=min(healed,max(D(0),dec(target.profile['max_hp'])-target.hp+hp))
                    healing_payment['heals'][name]=healed
                actual_hp, actual_shield = min(target.hp+healed, hp), min(target.shield, shield)
                self.applied_damage.continuous(name,begin,finish,parts[name],actual_hp)
                if fluid:actual_shield=max(D(0),dec(before[name]['shield'])+regenerated-fluid_shield)
                if self.healing.enabled:target.hp=target.hp+healed-actual_hp
                else:target.hp-=actual_hp
                target.shield -= actual_shield
                if fluid:target.shield=fluid_shield
                target.metrics['continuous_hp_damage_received'] += actual_hp
                target.metrics['shield_damage_received'] += actual_shield
                for status in ('disorientation', 'instability'):
                    remaining = max(D(0), getattr(target, status)-elapsed)
                    # Subtracting at a fractional expiry can leave a residual
                    # smaller than one representable clock increment. Treat
                    # that completed decay as zero instead of a zero-time knot.
                    if self.mobile_mode and remaining and finish+remaining == finish:
                        remaining = D(0)
                    setattr(target, status, remaining)
                if self.mobile_mode:
                    self.refresh_mobile_locomotion()
                if parts[name]:
                    self.log('continuous_damage_resolved', target=name, interval_start_ms=begin,
                             interval_end_ms=finish, components=parts[name], applied_hp_damage=actual_hp,
                             **({'applied_hp_healing':healed} if self.healing.enabled and name in self.healing.passives else {}),
                             applied_shield_damage=actual_shield, state_before=before[name], state_after=target.record(),
                             payment=('Continuous dense thermal integration with analytic recovery/stock; not a damage tick'
                                      if fluid else 'Continuous dense toxin integral; not a damage tick'
                                      if any(p['inputs'].get('curve_kind')=='venom_live_resistance_v1' for p in parts[name])
                                      else 'Analytic continuous integral; not a damage tick'))
                for part in parts[name]:
                    if part['channel'] == 'shield' and not fluid:
                        self._record_shield_loss(name, part['amount']*actual_shield/shield,
                                                 begin, part['effect_id'], part['inputs'])
                if fluid:self.thermal_recovery.record_losses(name,begin,finish,actual_shield)
                if dec(before[name]['shield']) > 0 and not target.shield:
                    self._shield_broken(name)
            if self.effect_system.enabled:
                for name,entries in parts.items():
                    if name in self.fighters:continue
                    amount=sum((p['amount'] for p in entries),D(0))
                    applied=self.collider_system.damage(name,amount,source='continuous_heat',interval_begin_ms=begin)
                    self.log('world_collider_continuous_damage',collider_id=name,interval_start_ms=begin,
                        interval_end_ms=finish,components=entries,applied_hp_damage=applied)
            self.healing.commit_interval(healing_payment)
            if finish < end:
                self.finish_team_deaths()
            if one_interval:
                return
