"""A shared event timeline for the confirmed stationary combat subset.

All actors share one state collection and event queue. Formulas live in mechanics,
choices in battle_actions, configuration in scenario JSON, and summaries in
battle_analysis. The stationary team scope integrates authored geometry,
Recovery, dyspnea, death and simultaneous impacts. The earlier controlled-duel
scope retains its original explicit restrictions and reproducible trace.
"""
from collections import Counter
from copy import deepcopy
from decimal import Context, Decimal as D, ROUND_HALF_EVEN, localcontext
import heapq
from itertools import count

from combat_sim.battle_actions import AbilityOption, ActorOptions, PriorityWhenReady
from combat_sim.battle_models import BattleAction, Combatant, ceil_ms, decimal_value as dec
from combat_sim.events import EventLog
from combat_sim.mechanics import heat, projectile_damage, qard, slash
from combat_sim.mechanics.simultaneous import DamagePacket,calculate_simultaneous_impacts
from combat_sim.mechanics.continuous_numeric import bleed_integral, root_curve_integral
from combat_sim.mechanics.status import mitigate_status
from combat_sim.mechanics.timing import impact_time_from_activation
from combat_sim.target_policies import make_target_policy
from combat_sim.models import UnsupportedMechanicError
from combat_sim.orientation import YawFrame
from combat_sim.attack_modifiers import AttackModifiers
from combat_sim.passive_abilities import PassiveAbilities
from combat_sim.spatial_transitions import SpatialTransitions
from combat_sim.grapple_links import GrappleLinks
from combat_sim.controlled_damage import ControlledDamage
from combat_sim.continuous_effort import ContinuousEffort
from combat_sim.grapple_casts import GrappleCasts
from combat_sim.grapple_break import GrappleBreak
from combat_sim.saved_body_paths import SavedBodyPaths,SavedBodyPathRules
from combat_sim.persistent_distances import PersistentDistances
from combat_sim.terrain_anchors import TerrainAnchors
from combat_sim.binding_effects import BindingEffects, EVENTS as BINDING_EVENTS
from combat_sim.body_dashes import BodyDashes
from combat_sim.body_leaps import BodyLeaps,EVENT as LEAP_EVENT
from combat_sim.knock_motion import KnockMotion
from combat_sim.conditional_melee import ConditionalMelee
from combat_sim.body_support import BodySupport,BodySupportRules
from combat_sim.terrain_support import TerrainSupport
from combat_sim.contact_signals import BodyContactSignals,EVENT as BODY_CONTACT_EVENT
from combat_sim.owned_contacts import OwnedContacts,EVENT as OWNED_CONTACT_EVENT
from combat_sim.ground_speed import GroundSpeedBonuses,EVENT as GROUND_SPEED_EVENT
from combat_sim.charge_grapples import ChargeGrapples
from combat_sim.aim_control import AimControl
from combat_sim.projectile_accuracy import ProjectileAccuracy
from combat_sim.combat_controls import CombatControls
from combat_sim.linked_motion import LinkedMotionRules
from combat_sim.mechanics.delayed_shield import DelayedShieldRecovery
from combat_sim.stationary_geometry import squared_distance
from combat_sim.team_rules import StationaryTeamRules, TEAM_SCOPE, BODY_SCOPE, TERRAIN_SCOPE
from combat_sim.movement_rules import ScriptedMovementRules, MOVEMENT_SCOPE
from combat_sim.common_actions import CommonActionRules
from combat_sim.mobile_combat import MovingCombatRules, MOBILE_SCOPE, GRAVITY_MOBILE_SCOPE
from combat_sim.sprint_combat import SprintCombatRules
from combat_sim.airborne_combat import AirborneCombatRules
from combat_sim.posture_combat import PostureCombatRules
from combat_sim.equilibrium import Equilibrium
from combat_sim.impact_bindings import ImpactBindings,EVENT as IMPACT_BINDING_EVENT
from combat_sim.impact_areas import ImpactAreas, EVENT as IMPACT_AREA_EVENT
from combat_sim.timed_gathering import TimedGathering, EVENT as TIMED_GATHERING_EVENT
from combat_sim.projectile_duplication import ProjectileDuplication, EVENTS as DUPLICATION_EVENTS
from combat_sim.portals import PortalPairs, EXPIRY as PORTAL_EXPIRY
from combat_sim.hand_reach import HandReach
from combat_sim.contact_constructs import ContactConstructs,EVENT as CONTACT_CONSTRUCT_EVENT
from combat_sim.segment_fields import SegmentFields,EVENTS as SEGMENT_FIELD_EVENTS
from combat_sim.climb_combat import ClimbCombatRules
from combat_sim.command_dispatch import MovementCommandRules
from combat_sim.owned_action_rules import OwnedActionRules
from combat_sim.mobile_projectile_rules import MovingProjectileRules
from combat_sim.gravity_projectile_rules import GravityProjectileRules
from combat_sim.projectile_world import SharedProjectiles
from combat_sim.projectile_entities import ProjectileContactPolicy
from combat_sim.spatial_effects import SpatialEffects
from combat_sim.thermal_recovery import ThermalRecovery
from combat_sim.cooldown_fields import CooldownFields
from combat_sim.revival import DeathRevival
from combat_sim.hp_recovery import HPRecovery
from combat_sim.applied_damage import AppliedDamage
from combat_sim.effort_rules import EffortRules
from combat_sim.life_cycles import LifeCycles
from combat_sim.melee_combat import SharedMelee
from combat_sim.venom_effects import VenomEffects
from combat_sim.poison_volumes import PoisonVolumes,EVENTS as POISON_EVENTS
from combat_sim.weapon_modes import WeaponModes
from combat_sim.blocking import Blocking
from combat_sim.dodging import Dodging
from combat_sim.combat_reactions import CombatReactions
from combat_sim.automatic_abilities import AutomaticAbilities, ability_definition
from combat_sim.scripted_targets import ScriptedTargets
from combat_sim.grappling_gun import GrapplingGun,EVENTS as HOOK_EVENTS
from combat_sim.turn_control import TurnControl,TurningRules

SUPPORTED = {'weapon_swap', 'poison_projectile', 'projectile_delayed_area', 'slash_projectile', 'direct_projectile', 'hook_projectile', 'marking_projectile', 'binding_projectile', 'impact_binding_area', 'impact_area_projectile', 'construct_projectile', 'projectile_duplication_area', 'portal_pair', 'contact_field', 'heat_beam','cooldown_pause_area','venomous_thrust','component_melee','grapple_grab','charge_grab','block','dodge','attack_enhancement','ballistic_dash','ballistic_leap','knock_melee','conditional_melee'}
BOUNDARY_TOLERANCE_MS = D('1e-25')
SCOPE = {
    'movement': 'stationary', 'hit_eligibility': 'confirmed',
    'area_eligibility': 'selected_target_only',
    'dyspnea_eligibility': 'excluded', 'recovery_eligibility': 'excluded',
    'zero_hp': 'stop_observation', 'coupled_simultaneous_events': 'reject',
}


def _fields(value, allowed, where):
    unknown = set(value) - set(allowed)
    if unknown:
        raise UnsupportedMechanicError(f'Unsupported {where} fields: {sorted(unknown)}')


def _text(value):
    if isinstance(value,YawFrame):return {'yaw_frame':value.record()}
    if isinstance(value, D):
        return str(value)
    if isinstance(value, dict):
        return {k: _text(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_text(v) for v in value]
    return value


class SharedEncounter(TurningRules,SavedBodyPathRules,BodySupportRules,LinkedMotionRules,OwnedActionRules,MovementCommandRules,ClimbCombatRules,PostureCombatRules,AirborneCombatRules,SprintCombatRules,MovingCombatRules,GravityProjectileRules,MovingProjectileRules,CommonActionRules,ScriptedMovementRules,StationaryTeamRules):
    def __init__(self, scenario, profiles, precision=50, sample_interval_ms=100, body_definition=None, terrain_definition=None, movement_definition=None, jump_definition=None, climb_definition=None, get_up_definition=None, combat_locomotion_definition=None, projectile_physics_definition=None):
        if not isinstance(precision, int) or precision < 40:
            raise ValueError('Shared numerical precision must be at least 40 digits')
        # Direct callers and subclass hooks need the same numerical contract as
        # execution. No initial Fraction conversion or geometry may use the
        # caller's rounding, traps or precision before run() establishes it.
        with localcontext(Context(prec=precision, rounding=ROUND_HALF_EVEN)):
            self._initialize_encounter(scenario, profiles, precision, sample_interval_ms,
                body_definition, terrain_definition, movement_definition, jump_definition,
                climb_definition, get_up_definition, combat_locomotion_definition, projectile_physics_definition)

    def _initialize_encounter(self, scenario, profiles, precision, sample_interval_ms,
            body_definition, terrain_definition, movement_definition, jump_definition,
            climb_definition, get_up_definition, combat_locomotion_definition, projectile_physics_definition):
        self.scenario, self.profiles = deepcopy(scenario), deepcopy(profiles)
        self.precision = precision
        self.time = D(0)
        self.serial = count()
        self.action_ids = count(1)
        self.intent_ids = count(1)
        self.effect_ids = count(1)
        self.queue, self.curve = [], []
        self.event_log = EventLog()
        self.effects, self.loss_history = [], []
        self.stop_reason = None
        self.airborne_enabled = False
        self.jump_actions_enabled = False
        self.climb_enabled = False
        self.movement_mode = scenario.get('scope') == MOVEMENT_SCOPE
        self.gravity_mode = scenario.get('scope') == GRAVITY_MOBILE_SCOPE
        self.mobile_mode = scenario.get('scope') in (MOBILE_SCOPE, GRAVITY_MOBILE_SCOPE)
        self.setup_projectile_physics(projectile_physics_definition)
        self.movement_input = deepcopy(movement_definition)
        self.jump_input = deepcopy(jump_definition)
        self.climb_input = deepcopy(climb_definition)
        self.get_up_input = deepcopy(get_up_definition)
        self.combat_locomotion_input = deepcopy(combat_locomotion_definition)
        self.effect_system=SpatialEffects(self,combat_locomotion_definition.get('persistent_effects') if combat_locomotion_definition else None)
        recovery_flow=(combat_locomotion_definition or {}).get('shield_recovery')
        if recovery_flow is not None and (recovery_flow!={'mode':'analytic_flow_v1'} or not self.effect_system.enabled):
            raise UnsupportedMechanicError('Analytic shield recovery flow requires current typed-effect world rules')
        self.shield_flow_enabled=recovery_flow is not None
        self.thermal_recovery=ThermalRecovery(self,(combat_locomotion_definition or {}).get('heat_shield_coupling'))
        self.cooldown_system=CooldownFields(self,(combat_locomotion_definition or {}).get('cooldown_clocks'))
        self.applied_damage=AppliedDamage(self,(combat_locomotion_definition or {}).get('damage_ledger'))
        self.effort_system=EffortRules(self,(combat_locomotion_definition or {}).get('effort_rules'))
        self.life_cycles=LifeCycles(self,(combat_locomotion_definition or {}).get('life_cycles'))
        self.revival=DeathRevival(self,(combat_locomotion_definition or {}).get('death_revival'))
        self.healing=HPRecovery(self,(combat_locomotion_definition or {}).get('hp_recovery'))
        self.conditional_melee=ConditionalMelee(self)
        self.melee=SharedMelee(self,(combat_locomotion_definition or {}).get('melee'))
        self.blocking=Blocking(self,(combat_locomotion_definition or {}).get('blocking'))
        self.reactions=CombatReactions(self,(combat_locomotion_definition or {}).get('combat_reactions'))
        self.attack_modifiers=AttackModifiers(self,(combat_locomotion_definition or {}).get('attack_modifiers'))
        self.passives=PassiveAbilities(self)
        self.spatial_transitions=SpatialTransitions(self,(combat_locomotion_definition or {}).get('spatial_transitions'))
        self.grapple_links=GrappleLinks(self,(combat_locomotion_definition or {}).get('grapple_links'))
        self.controlled_damage=ControlledDamage(self,(combat_locomotion_definition or {}).get('controlled_damage'),
            (combat_locomotion_definition or {}).get('released_rate_damage'))
        self.continuous_effort=ContinuousEffort(self,(combat_locomotion_definition or {}).get('continuous_effort'))
        self.grapple_casts=GrappleCasts(self,(combat_locomotion_definition or {}).get('grapple_casts'))
        self.bindings=BindingEffects(self,(combat_locomotion_definition or {}).get('binding_effects'))
        self.grapple_break=GrappleBreak(self,(combat_locomotion_definition or {}).get('grapple_break'))
        self.body_dashes=BodyDashes(self)
        self.grappling_gun=GrapplingGun(self)
        self.scripted_targets=ScriptedTargets(self)
        self.knock_motion=KnockMotion(self)
        self.automatic=AutomaticAbilities(self)
        self.venom_effects=VenomEffects(self)
        self.poison_volumes=PoisonVolumes(self,(combat_locomotion_definition or {}).get('poison_volumes'))
        self.weapon_modes=WeaponModes(self,(combat_locomotion_definition or {}).get('weapon_modes'))
        self.projectile_system=SharedProjectiles(self,
            combat_locomotion_definition.get('projectile_entities') if combat_locomotion_definition else None)
        self.projectiles=self.projectile_system.registry
        self.projectile_flights=self.projectiles.flights
        if combat_locomotion_definition is not None and not self.mobile_mode:
            raise UnsupportedMechanicError('Combat locomotion definitions require grounded combat scope')
        self.body_paths=SavedBodyPaths(self,(combat_locomotion_definition or {}).get('body_paths'))
        self.terrain_anchors=TerrainAnchors(self)
        self.distance_constraints=PersistentDistances(self,(combat_locomotion_definition or {}).get('distance_constraints'))
        self.equilibrium=Equilibrium(self,(combat_locomotion_definition or {}).get('equilibrium'))
        self.body_support=BodySupport(self,(combat_locomotion_definition or {}).get('body_support'))
        self.terrain_support=TerrainSupport(self,(combat_locomotion_definition or {}).get('terrain_support'))
        self.contact_signals=BodyContactSignals(self,(combat_locomotion_definition or {}).get('body_contact_signals'))
        self.owned_contacts=OwnedContacts(self)
        self.ground_speed=GroundSpeedBonuses(self)
        self.charge_grapples=ChargeGrapples(self,(combat_locomotion_definition or {}).get('charge_grapples'))
        self.accuracy=ProjectileAccuracy(self,(combat_locomotion_definition or {}).get('projectile_accuracy'))
        self.aim_control=AimControl(self,self.accuracy.enabled)
        self.turns=TurnControl(self)
        self.controls=CombatControls(self)
        self.hand_reach=HandReach(self,(combat_locomotion_definition or {}).get('hand_reach'))
        self.dodging=Dodging(self,(combat_locomotion_definition or {}).get('dodging'))
        self.timed_gathering=TimedGathering(self,(combat_locomotion_definition or {}).get('timed_gathering'))
        self.impact_areas=ImpactAreas(self,(combat_locomotion_definition or {}).get('impact_areas'))
        self.impact_bindings=ImpactBindings(self,(combat_locomotion_definition or {}).get('impact_bindings'))
        self.contact_constructs=ContactConstructs(self,(combat_locomotion_definition or {}).get('contact_constructs'))
        self.segment_fields=SegmentFields(self,(combat_locomotion_definition or {}).get('segment_fields'))
        self.projectile_duplication=ProjectileDuplication(self,(combat_locomotion_definition or {}).get('projectile_duplication'))
        self.portals=PortalPairs(self,(combat_locomotion_definition or {}).get('portals'))
        self.body_leaps=BodyLeaps(self,(combat_locomotion_definition or {}).get('body_leaps'))
        if self.mobile_mode and get_up_definition is not None and not self.equilibrium.enabled:
            raise UnsupportedMechanicError('Moving Get Up geometry is not integrated yet')
        if not (self.movement_mode or self.mobile_mode) and (movement_definition is not None or jump_definition is not None or climb_definition is not None):
            raise UnsupportedMechanicError('Locomotion definitions require the scripted movement test scope')
        self.terrain_mode = scenario.get('scope') in (TERRAIN_SCOPE,MOVEMENT_SCOPE,MOBILE_SCOPE,GRAVITY_MOBILE_SCOPE)
        self.body_mode = scenario.get('scope') in (BODY_SCOPE,TERRAIN_SCOPE,MOVEMENT_SCOPE,MOBILE_SCOPE,GRAVITY_MOBILE_SCOPE)
        self.team_mode = scenario.get('scope') in (TEAM_SCOPE,BODY_SCOPE,TERRAIN_SCOPE,MOVEMENT_SCOPE,MOBILE_SCOPE,GRAVITY_MOBILE_SCOPE)
        self.body_definition = deepcopy(body_definition)
        self.terrain_definition = deepcopy(terrain_definition)
        self.collider_system=None
        if body_definition is not None and not self.body_mode:
            raise UnsupportedMechanicError('Body definitions require the explicit body collision scope')
        if terrain_definition is not None and not self.terrain_mode:
            raise UnsupportedMechanicError('Terrain definitions require the explicit terrain collision scope')
        self.shield_recovery = {}
        self.policy = PriorityWhenReady()
        self.target_policies = {}
        self.sample_interval = dec(sample_interval_ms) if sample_interval_ms is not None else None
        if self.sample_interval is not None and self.sample_interval <= 0:
            raise ValueError('Sampling interval must be positive')
        self._load()
        self.cooldown_system.attach()
        self.blocking.attach()
        self.dodging.attach()
        self.life_cycles.attach()
        self.melee.attach()
        self.automatic.attach()
        self.passives.attach()
        self.spatial_transitions.load_interventions()
        self.accuracy.attach()
        self.aim_control.attach()
        self.controls.load_script()
        self.body_paths.attach()
        self.equilibrium.attach()
        self.body_support.attach()
        self.hand_reach.attach()
        self.turns.attach()
        self.initial = self.states()

    def _load(self):
        s = self.scenario
        _fields(s, {'id', 'description', 'execution_model', 'scope', 'encounter', 'action_selection', 'common_abilities'} |
                ({'terrain_profile'} if self.terrain_mode else set()) |
                ({'movement_script'} if self.movement_mode or self.mobile_mode else set()) |
                ({'spatial_interventions'} if self.spatial_transitions.enabled else set()) |
                ({'control_script'} if self.controls.enabled else set()) |
                ({'turn_script'} if self.turns.enabled else set()) |
                ({'random_seed'} if self.accuracy.enabled else set()) |
                ({'initial_restrictions','initial_colliders'} if self.mobile_mode else set()), 'scenario')
        if s.get('execution_model') != 'shared_encounter' or s.get('scope') not in (SCOPE, TEAM_SCOPE, BODY_SCOPE,TERRAIN_SCOPE,MOVEMENT_SCOPE,MOBILE_SCOPE,GRAVITY_MOBILE_SCOPE):
            raise UnsupportedMechanicError('Shared encounters require the explicit supported scope declaration')
        e = s['encounter']
        _fields(e, {'duration_ms', 'target_distance_m', 'participants'} |
                ({'ground_z_m'} if self.body_mode else set()), 'encounter')
        self.horizon = dec(e['duration_ms'])
        self.distance = dec(e.get('target_distance_m', 0))
        if self.team_mode and 'target_distance_m' in e:
            raise ValueError('Stationary team distances come from positions, not a global override')
        if not self.team_mode and 'target_distance_m' not in e:
            raise ValueError('Controlled duel requires target_distance_m')
        if self.horizon <= 0 or self.distance < 0:
            raise ValueError('Encounter duration must be positive and distance nonnegative')
        if self.horizon != ceil_ms(self.horizon):
            raise ValueError('Observation horizon must use integer milliseconds')
        self.fighters = {}
        for name, p in sorted(e['participants'].items()):
            _fields(p, {'character', 'team', 'initial_state'} | ({'position_m'} if self.team_mode else set()) |
                    ({'facing'} if self.body_mode else set()) |
                    ({'movement_direction'} if self.mobile_mode else set()), 'participant')
            profile = self.profiles[p['character']]
            raw = p.get('initial_state', {})
            _fields(raw, {'hp', 'armor', 'shield', 'disorientation', 'instability'} |
                    ({'knocked_down'} if s.get('common_abilities') == ['get_up'] or self.equilibrium.enabled else set()) |
                    ({'dyspnea'} if self.team_mode else set()), 'initial state')
            initial = {k: dec(raw.get(k, profile[key])) for k, key in
                       [('hp', 'max_hp'), ('armor', 'base_armor'), ('shield', 'shield_capacity')]}
            initial.update({k: dec(raw.get(k, 0)) for k in ('disorientation', 'instability')})
            if min(initial.values()) < 0 or initial['hp'] > dec(profile['max_hp']) or initial['shield'] > dec(profile['shield_capacity']):
                raise ValueError('Initial state must respect nonnegative values and HP/shield capacities')
            if not self.team_mode and self.horizon >= dec(profile['shield_regeneration']['delay_ms']):
                raise UnsupportedMechanicError('Shared regeneration execution is outside this stage; horizon must precede every loss delay')
            self.fighters[name] = Combatant(name, p['character'], p['team'], profile, **initial)
            self.weapon_modes.attach_actor(self.fighters[name])
            if self.team_mode:
                position = p.get('position_m', ())
                squared_distance(position, position)
                actor = self.fighters[name]
                actor.position_m = tuple(position)
                actor.dyspnea = dec(raw.get('dyspnea', 0))
                if not 0 <= actor.dyspnea <= 100:
                    raise ValueError('Initial dyspnea must be between zero and 100')
                if profile.get('hand_recovery_aggregation') != 'parallel_max':
                    raise UnsupportedMechanicError('Stationary teams require authored parallel hand Recovery')
                actor.hands = deepcopy(profile['initial_hand_positions_m'])
                actor.metrics.update(dyspnea_paid=D(0), shield_regenerated=D(0))
                regen = profile['shield_regeneration']
                self.shield_recovery[name] = DelayedShieldRecovery(regen['delay_ms'], regen['rate_per_second'])
        self.setup_common_actions(self.get_up_input)
        if len(self.fighters) < 2:
            raise ValueError('A shared encounter requires at least two participants')
        if self.body_mode:
            if 'ground_z_m' not in e:
                raise ValueError('Body collision scope needs an explicit placement ground datum')
            self.setup_body_geometry(self.body_definition,dec(e['ground_z_m']))
        if self.terrain_mode:
            self.setup_terrain_geometry(self.terrain_definition)
        if self.mobile_mode:
            self.setup_mobile_combat(self.movement_input,self.combat_locomotion_input)
        if self.movement_mode:
            self.setup_scripted_movement(self.movement_input,self.jump_input,self.climb_input)
            return
        self.choices = s['action_selection']
        if set(self.choices) != set(self.fighters):
            raise ValueError('Every participant needs an explicit action-selection configuration')
        for name, config in self.choices.items():
            _fields(config, {'kind', 'target', 'abilities', 'reload_when_empty', 'start_ms'} |
                    ({'aim_part','ability_targets'} if self.body_mode else set()) |
                    ({'held_blocks'} if self.blocking.enabled else set()), 'action selection')
            if config.get('kind') != 'priority_when_ready':
                raise UnsupportedMechanicError('Unsupported action-selection policy')
            if self.team_mode:
                self.target_policies[name] = make_target_policy(config.get('target'))
            if not self.team_mode and (config['target'] not in self.fighters or config['target'] == name):
                raise ValueError('A supplied distinct target is required')
            abilities = config['abilities']
            if not abilities or len(set(abilities)) != len(abilities):
                raise ValueError('Ability priorities must be a nonempty distinct list')
            actor = self.fighters[name]
            self.scripted_targets.validate(actor,config)
            if 'aim_part' in config and (not isinstance(config['aim_part'],str) or
                    config['aim_part'] not in {b.part for b in self.world_bodies[name]}):
                raise ValueError('Projectile aim_part must name an actual body cuboid')
            held=config.get('held_blocks',[])
            if (not isinstance(held,list) or len(set(held))!=len(held) or
                    any(key not in abilities or actor.profile['abilities'][key].get('execution_model')!='block' for key in held)):
                raise ValueError('Held Blocks must be distinct selected Block abilities')
            if not isinstance(config.get('reload_when_empty', False), bool):
                raise ValueError('Reload choice must be boolean')
            start = dec(config.get('start_ms', 0))
            if start < 0 or start != ceil_ms(start):
                raise ValueError('Policy start must use nonnegative integer milliseconds')
            for ability_id in abilities:
                if ability_id not in actor.profile.get('abilities',{}):
                    raise UnsupportedMechanicError('Ability is automatic or not selectable in shared combat: '+actor.profile_id+'/'+str(ability_id))
                ability = ability_definition(actor,ability_id)
                model = ability.get('execution_model')
                mobile_models = {'slash_projectile'}
                if self.effect_system.enabled:mobile_models.update(('heat_beam','cooldown_pause_area'))
                if self.effort_system.enabled:mobile_models.update(('projectile_delayed_area','direct_projectile','hook_projectile'))
                if self.bindings.enabled:mobile_models.update(('marking_projectile','binding_projectile'))
                if self.impact_bindings.enabled:mobile_models.add('impact_binding_area')
                if self.impact_areas.enabled:mobile_models.add('impact_area_projectile')
                if self.contact_constructs.enabled:mobile_models.add('construct_projectile')
                if self.segment_fields.enabled:mobile_models.add('contact_field')
                if self.projectile_duplication.enabled:mobile_models.add('projectile_duplication_area')
                if self.portals.enabled:mobile_models.add('portal_pair')
                if self.melee.enabled:mobile_models.update(('venomous_thrust','component_melee','knock_melee','conditional_melee'))
                if self.grapple_casts.enabled:mobile_models.add('grapple_grab')
                if self.charge_grapples.enabled:mobile_models.add('charge_grab')
                if self.blocking.enabled:mobile_models.add('block')
                if self.dodging.enabled:mobile_models.add('dodge')
                if self.attack_modifiers.enabled:mobile_models.add('attack_enhancement')
                if self.mobile_mode:mobile_models.add('ballistic_dash')
                if self.body_leaps.enabled:mobile_models.add('ballistic_leap')
                if self.weapon_modes.enabled:mobile_models.update(('weapon_swap','poison_projectile'))
                if self.mobile_mode and model not in mobile_models:
                    raise UnsupportedMechanicError('Selected attack is not integrated with current moving world rules')
                if model not in SUPPORTED:
                    raise UnsupportedMechanicError(f'Unsupported shared ability model: {model}')
                self.effort_system.validate_ability(actor,ability_id)
                timing = actor.profile['timing_profiles'][ability['timing_profile']]
                if model=='direct_projectile':
                    if not (self.mobile_mode and self.effort_system.enabled and actor.action_registry is not None):
                        raise UnsupportedMechanicError('Direct projectile output requires shared living owned moving combat')
                    if ability.get('damage_payment')!='direct_on_impact':
                        raise UnsupportedMechanicError('Direct projectile requires direct impact damage')
                    # Reuse the pure packet validator before any action starts.
                    calculate_simultaneous_impacts((DamagePacket(ability['damage_type'],
                        ability['pre_mitigation_damage'],ability['piercing']),),0,0,0)
                    falloff=ability.get('range_falloff',{})
                    if falloff.get('mode')!='continuous':
                        raise UnsupportedMechanicError('Direct projectile needs explicit continuous range falloff')
                    projectile_damage.damage_after_distance(ability['pre_mitigation_damage'],0,
                        falloff['damage_loss'],falloff['distance_m'])
                if self.team_mode:
                    for key in ('hand_positions_m', 'dyspnea'):
                        if key not in ability:
                            raise UnsupportedMechanicError(f'Missing team action definition: {key}')
                    if config.get('reload_when_empty') and model == 'slash_projectile':
                        for key in ('reload_hand_positions_m', 'reload_dyspnea'):
                            if key not in ability:
                                raise UnsupportedMechanicError(f'Missing reload definition: {key}')
                if dec(timing['gathering_ms']) < 0 or dec(timing['active_ms']) <= 0:
                    raise ValueError('Gathering must be nonnegative and Active positive')
                if dec(timing['active_ms']) != ceil_ms(dec(timing['active_ms'])):
                    raise UnsupportedMechanicError('Fractional base Active duration is not supported by this stage')
                if model in {'slash_projectile', 'direct_projectile', 'hook_projectile', 'projectile_delayed_area', 'marking_projectile', 'binding_projectile','impact_binding_area','impact_area_projectile','construct_projectile'}:
                    if model == 'hook_projectile':self.grappling_gun.validate(actor,ability_id)
                    if model == 'marking_projectile':self.bindings.validate(actor,ability_id)
                    if model == 'binding_projectile':self.bindings.validate_projectile(actor,ability_id)
                    if model == 'impact_binding_area':self.impact_bindings.validate(actor,ability_id)
                    if model == 'impact_area_projectile':self.impact_areas.validate(actor,ability_id)
                    if model == 'construct_projectile':self.contact_constructs.validate(actor,ability_id)
                    if self.body_mode and 'projectile_geometry' not in ability:
                        raise UnsupportedMechanicError('Body collision mode requires per-projectile geometry')
                    if self.body_mode:
                        policy=ProjectileContactPolicy.from_definition(ability['projectile_geometry'].get('contact_policy'))
                        if policy!=ProjectileContactPolicy() and not self.mobile_mode:
                            raise UnsupportedMechanicError('Non-default projectile contact policy requires moving combat')
                    anchor = (ability.get('weapon_cooldown_anchor', '').split(';')[0]
                              if model in ('direct_projectile','hook_projectile','projectile_delayed_area','marking_projectile','binding_projectile','impact_binding_area','impact_area_projectile','construct_projectile') else
                              ability.get('weapon_cooldown_behavior', {}).get('anchor'))
                    if anchor != 'active_firing_end':
                        raise UnsupportedMechanicError('Weapon cooldown must start at firing end')

                    if not self.effort_system.enabled and ability.get('damage_category') != 'extrinsic':
                        raise UnsupportedMechanicError('Shared projectiles currently require extrinsic damage')
                    if timing.get('projectile_release_timing') != 'after_active':
                        raise UnsupportedMechanicError('Shared projectiles require release after Active')
                    if self.team_mode:
                        for enemy in self.fighters.values():
                            if enemy.team != actor.team:
                                impact_time_from_activation(0, timing, self.team_distance(name, enemy.id))
                    else:
                        impact_time_from_activation(0, timing, self.distance)
                    if dec(ability['weapon_cooldown_ms']) <= 0:
                        raise ValueError('Weapon cooldown must be positive')
                    if ability['self_effects']['application_timing'] != 'middle_of_active':
                        raise UnsupportedMechanicError('Shared firing requires midpoint self effects')
                elif model=='weapon_swap':self.weapon_modes.validate(actor)
                elif model=='block':
                    self.blocking.validate(actor,ability_id)
                elif model=='dodge':
                    self.dodging.validate(actor,ability_id)
                elif model=='contact_field':self.segment_fields.validate(actor,ability_id)
                elif model=='projectile_duplication_area':self.projectile_duplication.validate(actor,ability_id)
                elif model=='portal_pair':self.portals.validate(actor,ability_id)
                elif model=='attack_enhancement':
                    self.attack_modifiers.validate(actor,ability_id)
                elif model=='ballistic_dash':
                    self.body_dashes.validate(actor,ability_id)
                elif model=='ballistic_leap':self.body_leaps.validate(actor,ability_id)
                elif model=='charge_grab':self.charge_grapples.validate(actor,ability_id)
                elif model in ('venomous_thrust','component_melee','grapple_grab','knock_melee','conditional_melee'):
                    self.melee.validate(actor,ability_id)
                elif model=='cooldown_pause_area':
                    if not self.cooldown_system.enabled:
                        raise UnsupportedMechanicError('Pause areas require cooldown work')
                    if (ability.get('area_shape')!='vertical_cylinder' or ability.get('deployment_timing')!='active_end' or
                            ability.get('cooldown_anchor')!='activation_start' or ability.get('dyspnea',{}).get('kind')!='none'):
                        raise UnsupportedMechanicError('Unsupported pause-area deployment, shape or effort rule')
                    if any(dec(ability[key])<=0 for key in ('radius_m','area_duration_ms','cooldown_ms')):
                        raise ValueError('Pause area radius, duration and cooldown must be positive')
                else:
                    if ability.get('armor_loss') != 'none' or ability.get('status_effects') != 'none':
                        raise UnsupportedMechanicError('Shared heat requires no armor loss or additional statuses')
                    if ability.get('deployment_behavior') != 'independent':
                        raise UnsupportedMechanicError('Shared heat requires the confirmed independent beam')
                    if timing.get('impact_timing') != 'start_of_active' or dec(ability['k']) != 2:
                        raise UnsupportedMechanicError('Shared heat requires Active-start k=2 beam')
                    if ability.get('cooldown_start_status', '').split(';')[0] != 'activation_start':
                        raise UnsupportedMechanicError('Heat cooldown must start at activation')
                    if dec(ability['beam_duration_ms']) <= 0 or dec(ability['cooldown_ms']) <= 0:
                        raise ValueError('Beam duration and cooldown must be positive')
                actor.ready[ability_id] = D(0)
                if model == 'slash_projectile':
                    capacity = ability['magazine_capacity']
                    if not isinstance(capacity, int) or isinstance(capacity, bool) or capacity <= 0:
                        raise ValueError('Magazine capacity must be a positive integer')
                    actor.ammo[ability_id] = capacity

    def states(self):
        return {name: f.record() for name, f in sorted(self.fighters.items())}

    def attack_definition(self,actor,ability,component=None,*,packet=None):
        if packet is not None:
            flight=self.projectile_flights.get(packet.get('projectile_id'))
            if flight is not None and 'definition_snapshot' in flight:return flight['definition_snapshot']
        if self.fighters[actor].profile.get('abilities',{}).get(ability,{}).get('execution_model')=='charge_grab':
            return self.charge_grapples.definition(self.fighters[actor],ability,component)
        if component is not None:return self.melee.definition(self.fighters[actor],ability,component)
        return ability_definition(self.fighters[actor],ability)

    def action_definition(self,actor,action):
        if hasattr(action,'definition_snapshot'):return action.definition_snapshot
        return self.melee.definition(actor,action.ability_id,action.component_id)

    def log(self, kind, **details):
        self.event_log.record(_text({'time_ms': self.time, 'type': kind, **details}))

    def push(self, time, kind, payload, priority=0):
        # A queued boundary and the saved body-path lease must use the same
        # declared precision, including direct API calls made by a caller with
        # a wider Decimal context. Unary plus normalizes an existing Decimal.
        with localcontext(Context(prec=self.precision,rounding=ROUND_HALF_EVEN)):
            time = +dec(time)
        if time < self.time:
            raise RuntimeError('An event cannot be scheduled in the past')
        if self.team_mode and kind in ('impact', 'area_impact'):
            priority = 1
        if kind=='projectile_range_ended':priority=3
        payload=self.life_cycles.stamp_event(kind,payload)
        heapq.heappush(self.queue, (time, priority, next(self.serial), kind, payload))

    def request_decision(self, name, time):
        if self.movement_mode:
            return
        f = self.fighters[name]
        if self.team_mode and f.died_at_ms is not None:
            return
        if f.decision_due is not None and f.decision_due <= time:
            return
        f.decision_due = time
        f.decision_revision += 1
        self.push(time, 'decision', {'actor': name, 'revision': f.decision_revision}, 10)

    def _live(self, event):
        _, _, _, kind, p = event
        if kind in POISON_EVENTS:return self.poison_volumes.event_live(kind,p)
        if kind in SEGMENT_FIELD_EVENTS:return self.segment_fields.event_live(kind,p)
        if kind in DUPLICATION_EVENTS:return self.projectile_duplication.event_live(kind,p)
        if kind==PORTAL_EXPIRY:return self.portals.event_live(p)
        if kind==LEAP_EVENT:return self.body_leaps.live(p)
        if kind=='released_rate_expired':return self.controlled_damage.event_live(p)
        if kind in HOOK_EVENTS:return self.grappling_gun.live(kind,p)
        if kind==BODY_CONTACT_EVENT:return self.contact_signals.live(p)
        if kind==OWNED_CONTACT_EVENT:return self.owned_contacts.live(p)
        if kind==GROUND_SPEED_EVENT:return self.ground_speed.live(p)
        if kind=='equilibrium_boundary':return self.equilibrium.event_live(p)
        if kind==IMPACT_BINDING_EVENT:return self.impact_bindings.event_live(p)
        if kind==IMPACT_AREA_EVENT:return self.impact_areas.event_live(p)
        if kind==TIMED_GATHERING_EVENT:return self.timed_gathering.event_live(p)
        if kind==CONTACT_CONSTRUCT_EVENT:return self.contact_constructs.event_live(p)
        if kind=='projectile_range_ended':return self.projectiles.live(p)
        if kind=='distance_expired':return self.distance_constraints.live(p)
        if kind in BINDING_EVENTS:return self.bindings.event_live(kind,p)
        if kind=='spatial_intervention':return self.spatial_transitions.intervention_live(p)
        if kind=='grapple_link_expired':return self.grapple_links.live(p)
        if kind=='turn_command':return self.turns.enabled
        if kind=='combat_control':return self.controls.live(p)
        if kind in ('grapple_break_deadline','grapple_break_boundary','grapple_break_penalty'):return self.grapple_break.event_live(kind,p)
        if kind in ('continuous_effort_expired','continuous_effort_cap'):return self.continuous_effort.event_live(kind,p)
        if kind=='combat_signal':return self.reactions.live(p)
        if kind=='attack_modifier_expired':return self.attack_modifiers.live(p)
        if kind=='revival_completed':return self.revival.live(p)
        if kind=='melee_impact':return self.melee.live(p)
        if kind=='replacement_blade_ready':return self.melee.items[p['blade_id']]['status']=='summoning'
        if not self.life_cycles.event_live(kind,p):return False
        if kind in ('block_layer_expired','block_second_layer'):return self.blocking.event_live(kind,p)
        if kind=='impact' and not (self.blocking.contact_live(p) if 'block_layer_id' in p
                else self.life_cycles.target_matches(p)):return False
        if kind=='cooldown_pause_expired':return self.cooldown_system.event_live(p)
        if kind=='incident_heat_expired':return self.thermal_recovery.incident_live(p)
        if kind in ('typed_effect_expired','volume_expired','venom_detached'):
            return self.effect_system.event_live(kind,p)
        if kind in ('projectile_stopped','projectile_owner_cleared') or (
                kind=='impact' and 'projectile_id' in p):
            return self.projectiles.live(p) and ('collider_id' not in p or
                self.collider_system.registry.contact_live(p,'projectiles',self.time))
        if kind=='world_collider_expired':
            return self.collider_system.expiry_live(p)
        if kind in ('knock_impact','knock_motion_ended'):return self.knock_motion.event_live(kind,p)
        if kind=='deferred_cooldown_started':return self.cooldown_system.deferred_live(p)
        # Body contact liveness depends on both participants' motion/pose and
        # individual collider versions. Revalidate after the due phase closure
        # instead of dropping a whole contact batch on an unrelated epoch change.
        if kind=='action_restriction_expired':
            clock=self.restriction_clocks.get((p['actor'],p['source']))
            return clock is not None and clock['revision']==p['revision']
        if self.mobile_mode and kind=='movement_climb_corner':
            action=self.fighters[p['actor']].action_by_id(p['action_id'])
            return action is not None and action.kind=='climb'
        if self.movement_mode and kind.startswith('movement_') and kind!='movement_command':
            return self.motion[p['actor']]['revision']==p['revision']
        if self.team_mode and kind in ('decision', 'recovery_completed', 'active_started', 'self_effect', 'active_completed'):
            if self.fighters[p['actor']].died_at_ms is not None:
                return False
        if kind == 'decision':
            return self.fighters[p['actor']].decision_revision == p['revision']
        if kind == 'effect_expired':
            effect = next(e for e in self.effects if e['id'] == p['effect_id'])
            return (event[0] == effect['expiry'] and not effect.get('expired', False)
                    and effect.get('mode') != 'ended')
        if kind in {'recovery_completed', 'active_started', 'self_effect', 'active_completed'}:
            action = self.fighters[p['actor']].action_by_id(p['action_id'])
            return action is not None and action.id == p['action_id'] and action.revision == p['revision']
        return True

    def decide(self, name):
        if self.team_mode:
            return self.decide_team(name)
        actor, config = self.fighters[name], self.choices[name]
        actor.decision_due = None
        if actor.current is not None:
            return
        options = ActorOptions(name, config['target'], self.time, self.time,
                               tuple(AbilityOption(a, actor.ready[a], actor.ammo.get(a)) for a in config['abilities']),
                               config.get('reload_when_empty', False))
        choice = self.policy.choose(options)
        if choice.kind == 'wait':
            if choice.at_ms.is_finite():
                self.request_decision(name, choice.at_ms)
            return
        ability_id = choice.ability_id
        ability = actor.profile['abilities'][ability_id]
        reload = choice.kind == 'reload'
        timing = actor.profile['timing_profiles'][ability['timing_profile']]
        gathering = dec(ability['reload_gathering_ms'] if reload else timing['gathering_ms'])
        active = dec(ability['reload_active_ms'] if reload else timing['active_ms'])
        if active != ceil_ms(active) or active <= 0 or gathering < 0:
            raise UnsupportedMechanicError('Unsupported reload/ability phase duration')
        due = ceil_ms(self.time+gathering+actor.disorientation)
        action = BattleAction(next(self.action_ids), name, config['target'], ability_id,
                              'reload' if reload else ability['execution_model'], self.time, due, active)
        actor.current = action
        actor.metrics['reloads_started' if reload else 'activations_started'] += 1
        if action.kind == 'heat_beam':
            self.cooldown_system.start(actor,ability_id,dec(ability['cooldown_ms']),action.id)
        self.log('reload_requested' if reload else 'ability_started', actor=name, target=action.target,
                 ability=ability_id, action_id=action.id, base_gathering_ms=gathering,
                 disorientation_at_start=actor.disorientation, active_start_ms=due,
                 active_ms=active, source=ability.get('source', actor.profile['source']),
                 eligibility={'dyspnea': 'excluded', 'physical_recovery': 'excluded'})
        self._schedule_phase(action, 'active_started', due)

    def _schedule_phase(self, action, kind, time):
        self.push(time, kind, {'actor': action.actor, 'action_id': action.id, 'revision': action.revision})

    def apply_target_status(self, target, effects, pre_hit_armor):
        f = self.fighters[target]
        additions = {name: mitigate_status(effects[name], f.profile['max_hp'], pre_hit_armor,
                                           self.target_status_resistance(f))
                     for name in ('disorientation', 'instability')}
        self.apply_target_status_additions(target,additions,pre_hit_armor)

    def target_status_resistance(self,actor):
        return dec(actor.profile['status_resistance'])+self.blocking.resistance(actor)

    def apply_target_status_additions(self, target, additions, pre_hit_armor):
        """Apply an already mitigated simultaneous status sum once."""
        f = self.fighters[target]
        for name, amount in additions.items():
            setattr(f, name, getattr(f, name)+amount)
        if self.mobile_mode:
            self.refresh_mobile_locomotion()
        self.log('target_status_applied', target=target, additions=additions,
                 pre_hit_armor=pre_hit_armor, state=f.record(), source='Collision details.odt; author pre-hit armor clarification')
        for action in f.live_actions():
            if not additions['disorientation'] or action.phase!='gathering':
                continue
            before = action.active_due_ms
            action.active_due_ms = ceil_ms(before+additions['disorientation'])
            action.revision += 1
            self._schedule_phase(action, 'active_started', action.active_due_ms)
            self.log('gathering_extended', actor=target, action_id=action.id,
                     old_active_start_ms=before, added_disorientation=additions['disorientation'],
                     new_active_start_ms=action.active_due_ms,
                     source='Author: incoming disorientation during Gathering increases that Gathering')

    def active_started(self, p):
        actor = self.fighters[p['actor']]
        action = actor.current
        if action.kind=='heading_turn':return self.turns.start(actor,action)
        if action.kind=='replacement_grab':return self.melee.grab_active_started(actor,action)
        if action.kind=='charge_grab':return self.charge_grapples.start(actor)
        if action.kind=='ballistic_dash':return self.body_dashes.start(actor)
        if action.kind=='ballistic_leap':return self.body_leaps.start(actor)
        if action.kind == 'climb':
            return self.start_combat_climb(actor)
        if action.kind == 'posture':
            return self.start_combat_posture(actor)
        if action.kind == 'basic_jump':
            return self.start_basic_jump(actor)
        if action.kind == 'get_up':
            return self.start_get_up(actor)
        if action.kind=='dodge' and not self.dodging.available(actor):
            self.cancel_owned_action(actor,action,'dodge_pose_unavailable_at_active_start')
            return
        if self.team_mode:
            if not self.pay_team_dyspnea(actor, 'active_start'):return
        action.phase, action.active_end_ms = 'active', self.time+action.active_ms
        self.log('active_started', actor=actor.id, action_id=action.id, ability=action.ability_id,
                 action_kind=action.kind, active_end_ms=action.active_end_ms)
        self._schedule_phase(action, 'active_completed', action.active_end_ms)
        if action.kind == 'reload':
            return
        ability = self.action_definition(actor,action)
        if action.kind=='weapon_swap':return self.weapon_modes.active(actor,action)
        if action.kind=='block':return self.blocking.active_started(actor,action)
        if action.kind=='dodge':return self.dodging.active_started(actor,action)
        if action.kind in ('venomous_thrust','component_melee','grapple_grab','knock_melee','conditional_melee'):self.melee.active_started(actor,action)
        if action.kind=='conditional_melee':self.conditional_melee.started(actor,action)
        if action.kind=='knock_melee':self.cooldown_system.start(actor,action.ability_id,dec(ability['cooldown_ms']),action.id)
        if action.kind=='grapple_grab':self.grapple_casts.active_started(actor,action)
        if action.kind in ('cooldown_pause_area','contact_field','projectile_duplication_area','portal_pair','attack_enhancement','aim_toggle'):return
        if action.kind == 'heat_beam':
            if self.team_mode:
                return self.deploy_team_heat(actor, action, ability)
            leave = self.time+dec(ability['beam_duration_ms'])
            target = self.fighters[action.target]
            effect = {'id': next(self.effect_ids), 'kind': 'heat', 'actor': actor.id, 'target': target.id,
                      'ability': action.ability_id, 'mode': 'shield' if target.shield else 'hp',
                      'start': self.time, 'leave': leave,
                      'expiry': leave+dec(ability['beam_duration_ms'])/2,
                      'heat_output': dec(ability['heat_output']), 'k': dec(ability['k'])}
            self.effects.append(effect)
            self.push(leave, 'beam_exposure_ended', {'effect_id': effect['id']})
            self.push(effect['expiry'], 'effect_expired', {'effect_id': effect['id']})
            self.log('heat_started', effect=effect, autonomous=True, source=ability['source'])
        else:
            self._schedule_phase(action, 'self_effect', ceil_ms(self.time+action.active_ms/2))

    def self_effect(self, p):
        actor = self.fighters[p['actor']]
        action = actor.current
        if action.kind=='dodge':return self.dodging.turn(actor,action)
        if action.kind in ('venomous_thrust','component_melee','grapple_grab','knock_melee','conditional_melee') and not p.get('melee_contact'):
            return self.melee.emit_frame(actor,action)
        values = self.action_definition(actor,action)['self_effects']
        factor = D('1.2') if self.mobile_mode and self.mobile_is_running(actor.id) else D(1)
        for name in ('disorientation', 'instability'):
            setattr(actor, name, getattr(actor, name)+dec(values[name])*factor)
        self.effort_system.own_recoil(actor,action,dec(values['instability'])*factor)
        self.extend_parallel_gatherings(actor,dec(values['disorientation'])*factor,action.id)
        if self.mobile_mode:
            self.refresh_mobile_locomotion()
        self.log('self_status_applied', actor=actor.id, ability=action.ability_id,
                 additions={k: dec(values[k])*factor if self.mobile_mode else values[k] for k in ('disorientation', 'instability')},
                 mitigation=False, state=actor.record(), source=values['source'])

    def extend_parallel_gatherings(self,actor,amount,cause_action_id):
        """Owned self O affects other unfinished preparations, never due starts.

        The causing action is already entering/executing Active. All starts
        due now have reached their phase boundary even if heap order has not
        visited their event yet. Historical exclusive scopes have no overlap.
        """
        if actor.action_registry is None or not amount:
            return
        for action in actor.live_actions():
            if action.id==cause_action_id or action.phase!='gathering' or action.active_due_ms<=self.time:
                continue
            before=action.active_due_ms
            action.active_due_ms=ceil_ms(before+amount)
            action.revision+=1
            self._schedule_phase(action,'active_started',action.active_due_ms)
            self.log('gathering_extended',actor=actor.id,action_id=action.id,old_active_start_ms=before,
                added_disorientation=amount,new_active_start_ms=action.active_due_ms,
                cause_action_id=cause_action_id,source='parallel_action_self_disorientation')

    def active_completed(self, p):
        actor = self.fighters[p['actor']]
        action = actor.current
        if action.kind=='heading_turn':return self.turns.complete(actor,action)
        if action.kind=='weapon_swap':return self.weapon_modes.complete(actor)
        if action.kind=='replacement_grab':return self.melee.grab_completed(actor,action)
        if action.kind=='ballistic_dash':return self.body_dashes.complete(actor)
        if action.kind=='ballistic_leap':return self.body_leaps.complete(actor)
        if action.kind=='dodge':return self.dodging.complete(actor,action)
        if action.kind == 'climb':
            return self.complete_combat_climb(actor)
        if action.kind == 'posture':
            return self.complete_combat_posture(actor)
        if action.kind == 'basic_jump':
            return self.complete_basic_jump(actor)
        if action.kind == 'locomotion':
            return self.complete_mobile_action(actor)
        if action.kind == 'get_up':
            return self.complete_get_up(actor)
        ability = self.action_definition(actor,action)
        if self.team_mode:
            if not self.pay_team_dyspnea(actor, 'active_firing_end'):return
            poses = ability['reload_hand_positions_m'] if action.kind == 'reload' else ability['hand_positions_m']
            actor.hands.update(poses['end'])
        if action.kind == 'reload':
            actor.ammo[action.ability_id] = ability['magazine_capacity']
            actor.metrics['reloads_completed'] += 1
            self.log('reload_completed', actor=actor.id, ability=action.ability_id,
                     ammo=actor.ammo[action.ability_id], action_id=action.id)
        elif action.kind=='cooldown_pause_area':
            self.cooldown_system.deploy(actor,action,ability)
        elif action.kind=='contact_field':self.segment_fields.deploy(actor,action,ability)
        elif action.kind=='projectile_duplication_area':self.projectile_duplication.deploy(actor,action,ability)
        elif action.kind=='portal_pair':self.portals.deploy(actor,action,ability)
        elif action.kind=='attack_enhancement':
            self.attack_modifiers.grant(actor,action,ability)
        elif action.kind=='aim_toggle':
            if not self.aim_control.complete(actor,action):return
        elif action.kind=='hook_projectile':
            return self.grappling_gun.release(actor,action,ability)
        elif action.kind=='venomous_thrust':
            self.log('thrust_active_completed',actor=actor.id,ability=action.ability_id,action_id=action.id)
        elif action.kind in ('component_melee','conditional_melee'):
            self.melee.completed(actor,action)
            self.log('melee_component_completed',actor=actor.id,ability=action.ability_id,action_id=action.id,
                component_id=action.component_id)
        elif action.kind=='grapple_grab':
            self.grapple_casts.grab_completed(actor,action)
        elif action.kind=='charge_grab':
            self.grapple_casts.grab_completed(actor,action)
            self.charge_grapples.completed(actor,action)
        elif action.kind=='knock_melee':
            self.log('knock_melee_active_completed',actor=actor.id,ability=action.ability_id,action_id=action.id)
        elif action.kind=='block':
            self.log('block_active_completed',actor=actor.id,ability=action.ability_id,action_id=action.id)
        elif action.kind != 'heat_beam':
            if action.kind=='poison_projectile':self.weapon_modes.consume(actor,action)
            elif action.ability_id in actor.ammo:
                if actor.ammo[action.ability_id] <= 0:
                    raise RuntimeError('Cannot release a projectile from an empty magazine')
                actor.ammo[action.ability_id] -= 1
            self.cooldown_system.start(actor,action.ability_id,dec(ability['weapon_cooldown_ms']),action.id)
            actor.metrics['projectiles_released'] += 1
            timing = dict(actor.profile['timing_profiles'][ability['timing_profile']])
            timing.update({'gathering_ms': 0, 'active_ms': 0})
            if self.body_mode:
                self.release_body_projectile(actor,action,ability,timing)
            else:
                distance = self.team_distance(actor.id, action.target) if self.team_mode else self.distance
                arrival, calculation = impact_time_from_activation(int(self.time), timing, distance)
                payload = {'actor': actor.id, 'target': action.target, 'ability': action.ability_id,
                           'action_id': action.id, 'component': 'projectile'}
                if self.team_mode:
                    payload.update(distance_m=distance, location_m=self.fighters[action.target].position_m)
                self.push(D(arrival), 'impact', payload)
                self.log('projectile_released', **payload, impact_time_ms=arrival,
                         weapon_ready_at_ms=actor.ready[action.ability_id], ammo=actor.ammo.get(action.ability_id),
                         travel_calculation=calculation)
        else:
            self.log('summoning_active_completed', actor=actor.id, ability=action.ability_id,
                     action_id=action.id, deployed_beam_continues=True)
        actor.current = None
        self.request_decision(actor.id, self.time)

    def _record_shield_loss(self, target, amount, begin=None, effect_id=None, curve=None,*,end=None):
        if not amount:
            return
        delay = dec(self.fighters[target].profile['shield_regeneration']['delay_ms'])
        loss_end=self.time if end is None else end
        if begin is not None and not begin<loss_end<=self.time:raise ValueError('Shield loss interval must end by current time')
        if begin is None:
            record = {'kind': 'impact', 'target': target, 'loss_at_ms': self.time,
                      'amount': amount, 'eligible_at_ms': self.time+delay}
        else:
            record = {'kind': 'continuous_heat_loss', 'target': target, 'effect_id': effect_id,
                      'interval_start_ms': begin, 'interval_end_ms': loss_end, 'amount': amount,
                      'eligible_interval_start_ms': begin+delay, 'eligible_interval_end_ms': loss_end+delay,
                      'curve': curve,
                      'history': 'Continuous loss distribution retains its exposure curve; eligibility shifts each loss by delay'}
        record.update(self.life_cycles.target_fields(target))
        self.loss_history.append(_text(record))
        if self.team_mode:
            if begin is None:
                self.shield_recovery[target].add_impact(self.time, amount)
            else:
                self.shield_recovery[target].add_curve(begin, loss_end, amount, curve)

    def impact(self, p):
        actor, target = self.fighters[p['actor']], self.fighters[p['target']]
        ability = actor.profile['abilities'][p['ability']]
        before = target.record()
        armor = target.armor
        raw = dec(ability['pre_mitigation_damage'])
        model = ability['execution_model']
        if model == 'slash_projectile':
            falloff = ability['range_falloff']
            raw = dec(projectile_damage.damage_after_distance(raw, self.distance, falloff['damage_loss'], falloff['distance_m']))
        absorbed = min(raw, target.shield)
        left = raw-absorbed
        target.shield -= absorbed
        self._record_shield_loss(target.id, absorbed)
        if model == 'slash_projectile':
            calculation = slash.calculate_impact(raw, armor, ability['piercing'], dec(before['shield']))
            damage, armor_loss = dec(calculation.hp_damage), min(armor, dec(calculation.armor_loss))
            raw_y, raw_ar = dec(calculation.raw_hp_damage), dec(calculation.raw_armor_loss)
            calculated_ar = dec(calculation.armor_loss)
        else:
            damage = dec(qard.post_mitigation_damage(left, armor, target.profile['resistances']['qard'])) if left else D(0)
            armor_loss = D(0)
            raw_y = dec(qard.raw_post_mitigation_damage(left, armor, target.profile['resistances']['qard'])) if left else D(0)
            raw_ar = calculated_ar = D(0)
        actual = min(target.hp, damage)
        target.hp -= actual
        target.armor -= armor_loss
        target.metrics['direct_hp_damage_received'] += actual
        target.metrics['shield_damage_received'] += absorbed
        target.metrics['armor_lost'] += armor_loss
        actor.metrics['hits_resolved'] += 1
        self.log('impact_resolved', **p, pre_hit_armor=armor,
                 damage_calculation={'incoming': raw, 'shield_absorbed': absorbed,
                    'damage_left_after_shield': left, 'nominal_hp_damage': damage,
                    'applied_hp_damage': actual, 'armor_loss': armor_loss,
                    'raw_hp_formula_output': raw_y, 'raw_armor_formula_output': raw_ar,
                    'calculated_armor_loss_before_state_floor': calculated_ar,
                    'piercing': ability.get('piercing'),
                    'qard_resistance': target.profile['resistances'].get('qard') if model == 'projectile_delayed_area' else None,
                    'formula': slash.FORMULA if model == 'slash_projectile' else qard.FORMULA},
                 state_before=before, state_after=target.record(), source=ability['source'])
        if absorbed and not target.shield:
            self._shield_broken(target.id)
        self.apply_target_status(target.id, ability['target_effects'], armor)
        if model == 'slash_projectile' and damage:
            effect=self.effect_system.add_bleed(p,damage)
            self.log('bleeding_started', effect=effect, source=slash.BLEED_SOURCE)
        if model == 'projectile_delayed_area' and p['component'] == 'projectile':
            blast = dict(p, component='delayed_blast')
            self.push(self.time+dec(ability['delayed_area']['delay_ms']), 'impact', blast)

    def components(self, begin, end):
        """Return analytic damage per target/effect under unchanged interval state."""
        parts = {name: [] for name in self.fighters}
        for effect in self.effects:
            if self.team_mode and self.fighters[effect['target']].hp <= 0:
                continue
            if effect['kind'] == 'bleeding':
                amount = bleed_integral(effect['basis_y'], effect['start'], begin, end)
                channel = 'hp'
                inputs = {'basis_y': effect['basis_y'], 'start_ms': effect['start'],
                          'expiry_ms': effect['expiry'], 'formula': slash.BLEED_FORMULA}
            elif effect['kind']=='heat':
                if effect['mode'] == 'ended':
                    continue
                target = self.fighters[effect['target']]
                channel = 'shield' if effect['mode'] == 'shield' else 'hp'
                coefficient = (effect['heat_output'] if channel == 'shield' else
                               dec(heat.heat_coefficient(effect['heat_output'], target.armor,
                                                        target.profile['resistances']['heat'], effect['k'])))
                inputs = {'heat_output': effect['heat_output'], 'k': effect['k'],
                          'armor': D(0) if channel == 'shield' else target.armor,
                          'heat_resistance': D(0) if channel == 'shield' else dec(target.profile['resistances']['heat']),
                          'start_ms': effect['start'], 'leave_ms': effect['leave'],
                          'expiry_ms': effect['expiry'], 'coefficient': coefficient, 'formula': heat.FORMULA}
                amount = root_curve_integral(coefficient, effect['start'], effect['leave'],
                                             effect['expiry'], begin, end, effect['k'])
            else:
                raise UnsupportedMechanicError('Unknown legacy persistent effect kind')
            if amount:
                parts[effect['target']].append({'effect_id': effect['id'], 'kind': effect['kind'],
                                               'actor': effect['actor'], 'channel': channel,
                                               'inputs': inputs, 'amount': amount,
                                               **({'coefficient': coefficient} if effect['kind'] == 'heat' else {})})
        for target,entries in self.effect_system.components(begin,end).items():
            parts.setdefault(target,[]).extend(entries)
        return parts

    def _boundary(self, begin, end, target, channel, budget):
        low, high = begin, end
        for _ in range(240):
            if high-low <= BOUNDARY_TOLERANCE_MS:
                break
            mid = (low+high)/2
            amount = sum((p['amount'] for p in self.components(begin, mid)[target]
                          if p['channel'] == channel), D(0))
            if amount >= budget:
                high = mid
            else:
                low = mid
        return low, high

    def _shield_broken(self, target):
        self.log('shield_broken', target=target)
        self.effect_system.shield_broken(target)
        for effect in self.effects:
            if effect['target'] != target or effect['kind'] != 'heat' or effect['mode'] != 'shield':
                continue
            if self.time < effect['leave']:
                effect['mode'], effect['start'] = 'hp', self.time
                effect['expiry'] = effect['leave']+(effect['leave']-self.time)/effect['k']
                self.push(effect['expiry'], 'effect_expired', {'effect_id': effect['id']})
                self.log('hp_heat_exposure_started', effect_id=effect['id'], target=target,
                         exposure_seconds=0, remaining_exposure_ms=effect['leave']-self.time)
            else:
                effect['mode'] = 'ended'
                self.log('shield_residual_terminated', effect_id=effect['id'], target=target,
                         transferred_hp_damage=0)

    def advance(self, end):
        if self.mobile_mode:
            return self.advance_mobile(end)
        if self.movement_mode:
            return self.advance_movement(end)
        if self.team_mode:
            return self.advance_team(end)
        while self.time < end:
            begin, finish = self.time, end
            parts = self.components(begin, end)
            boundaries = []
            for name, target in self.fighters.items():
                for channel, budget in [('hp', target.hp), ('shield', target.shield)]:
                    amount = sum((p['amount'] for p in parts[name] if p['channel'] == channel), D(0))
                    if budget > 0 and amount >= budget:
                        low, high = self._boundary(begin, end, name, channel, budget)
                        boundaries.append((high, low, name, channel))
                        finish = min(finish, high)
            parts = self.components(begin, finish)
            before = self.states()
            elapsed = finish-begin
            self.time = finish
            for name, target in self.fighters.items():
                hp = sum((p['amount'] for p in parts[name] if p['channel'] == 'hp'), D(0))
                shield = sum((p['amount'] for p in parts[name] if p['channel'] == 'shield'), D(0))
                actual_hp, actual_shield = min(target.hp, hp), min(target.shield, shield)
                target.hp -= actual_hp
                target.shield -= actual_shield
                target.metrics['continuous_hp_damage_received'] += actual_hp
                target.metrics['shield_damage_received'] += actual_shield
                for status in ('disorientation', 'instability'):
                    setattr(target, status, max(D(0), getattr(target, status)-elapsed))
                if parts[name]:
                    self.log('continuous_damage_resolved', target=name, interval_start_ms=begin,
                             interval_end_ms=finish, components=parts[name], applied_hp_damage=actual_hp,
                             applied_shield_damage=actual_shield, state_before=before[name],
                             state_after=target.record(), payment='Analytic continuous integral; not a damage tick')
                for part in parts[name]:
                    if part['channel'] == 'shield':
                        self._record_shield_loss(name, part['amount'], begin, part['effect_id'], part['inputs'])
                if dec(before[name]['shield']) > 0 and not target.shield:
                    self._shield_broken(name)
            if any(not f.hp for f in self.fighters.values()):
                self.stop_reason = {'kind': 'hp_zero_observation_stop', 'time_ms': self.time,
                                    'zero_hp': [name for name, f in self.fighters.items() if not f.hp],
                                    'boundary_brackets': [{'lower_ms': b[1], 'upper_ms': b[0], 'target': b[2]}
                                                          for b in boundaries if b[3] == 'hp' and b[0] == finish]}
                return

    def _check_batch(self, batch):
        hits = [e[4]['target'] for e in batch if e[3] == 'impact']
        duplicate = [target for target, n in Counter(hits).items() if n > 1]
        phases = {e[4]['actor'] for e in batch
                  if e[3] in {'active_started', 'active_completed', 'self_effect'}}
        coupled = set(hits) & phases
        if duplicate or coupled:
            raise UnsupportedMechanicError(
                f'Unspecified ordering of coupled simultaneous events at {self.time} ms: '
                f'multiple hits={duplicate}, incoming hit/phase tie={sorted(coupled)}')

    def _process(self, kind, p):
        if kind in POISON_EVENTS:return self.poison_volumes.process(kind,p)
        if kind in SEGMENT_FIELD_EVENTS:return self.segment_fields.process(kind,p)
        if kind in DUPLICATION_EVENTS:return self.projectile_duplication.process(kind,p)
        if kind==PORTAL_EXPIRY:return self.portals.expire(p)
        if kind==LEAP_EVENT:return self.body_leaps.process(p)
        if kind=='released_rate_expired':return self.controlled_damage.expire(p)
        if kind in HOOK_EVENTS:return self.grappling_gun.process(kind,p)
        if kind==BODY_CONTACT_EVENT:return self.contact_signals.process(p)
        if kind==GROUND_SPEED_EVENT:return self.ground_speed.process(p)
        if kind==IMPACT_BINDING_EVENT:return self.impact_bindings.process(p)
        if kind==IMPACT_AREA_EVENT:return self.impact_areas.process(p)
        if kind==TIMED_GATHERING_EVENT:return self.timed_gathering.expire(p)
        if kind==CONTACT_CONSTRUCT_EVENT:return self.contact_constructs.process(p)
        if kind=='equilibrium_boundary':return self.equilibrium.boundary(p)
        if kind=='projectile_range_ended':return self.projectile_system.limits.ended(p)
        if kind=='distance_expired':return self.distance_constraints.release(p['distance_id'],reason='expired')
        if kind in BINDING_EVENTS:return self.bindings.process(kind,p)
        if kind=='spatial_intervention':return self.spatial_transitions.process_intervention(p)
        if kind=='grapple_link_expired':return self.grapple_links.process(p)
        if kind=='turn_command':return self.turns.receive(p)
        if kind=='combat_control':return self.controls.process(p)
        if kind in ('grapple_break_deadline','grapple_break_boundary','grapple_break_penalty'):return self.grapple_break.process(kind,p)
        if kind in ('continuous_effort_expired','continuous_effort_cap'):return self.continuous_effort.process(kind,p)
        if kind=='combat_signal':return self.reactions.process(p)
        if kind=='attack_modifier_expired':return self.attack_modifiers.expire(p)
        if kind in ('block_layer_expired','block_second_layer'):return self.blocking.process(kind,p)
        if kind=='revival_completed':return self.revival.complete(p)
        if kind=='replacement_blade_ready':return self.melee.item_ready(p)
        if kind=='cooldown_pause_expired':return self.cooldown_system.expire(p)
        if kind=='incident_heat_expired':return self.thermal_recovery.expire_incident(p)
        if kind in ('typed_effect_expired','volume_expired','venom_detached'):
            return self.effect_system.process(kind,p)
        if kind=='world_collider_expired':
            return self.collider_system.expire(p)
        if kind in ('knock_impact','knock_motion_ended'):return self.knock_motion.process(kind,p)
        if kind=='deferred_cooldown_started':return self.cooldown_system.finish_deferred(p)
        if kind=='action_restriction_expired':
            self.expire_action_restrictions(self.fighters[p['actor']])
            return
        if self.mobile_mode and kind == 'world_horizon':
            return
        if self.mobile_mode and kind.startswith('movement_'):
            return self.process_mobile_event(kind,p)
        if self.mobile_mode and kind == 'projectile_stopped':
            return self.stop_mobile_projectile(p)
        if self.mobile_mode and kind == 'projectile_owner_cleared':
            return self.projectile_system.owner_cleared(p)
        if self.movement_mode and kind.startswith('movement_'):
            return self.process_movement_event(kind,p)
        if kind == 'impact':
            self.impact(p)
        elif kind in {'recovery_completed', 'active_started', 'active_completed', 'self_effect'}:
            actor=self.fighters[p['actor']]
            action=self.prepare_owned_phase(actor,p)
            if action is not None:
                with actor.using_action(action):
                    getattr(self, kind)(p)
        elif kind == 'beam_exposure_ended':
            effect = next(e for e in self.effects if e['id'] == p['effect_id'])
            self.log('beam_exposure_ended', effect_id=effect['id'], target=effect['target'])
        elif kind == 'effect_expired':
            effect = next(e for e in self.effects if e['id'] == p['effect_id'])
            if self.time >= effect['expiry'] and not effect.get('expired', False):
                effect['expired'] = True
                if effect['kind'] == 'heat':
                    effect['mode'] = 'ended'
                self.log('effect_expired', effect_id=effect['id'], target=effect['target'])
        elif kind == 'decision':
            self.decide(p['actor'])
        elif kind == 'sample':
            self.sample('scheduled_observation')
            if self.time+self.sample_interval <= self.horizon:
                self.push(self.time+self.sample_interval, 'sample', {}, 99)
        else:
            raise RuntimeError(f'Unknown shared event: {kind}')

    def sample(self, label):
        self.curve.append(_text({'time_ms': self.time, 'label': label, 'states': self.states()}))

    def run(self):
        # run_shared_scenario already supplies this context; direct/subclass
        # API users need the same numerical contract throughout phase closure.
        with localcontext(Context(prec=self.precision,rounding=ROUND_HALF_EVEN)):
            return self._run()

    def _run(self):
        self.sample('initial')
        if self.mobile_mode:
            self.push(self.horizon,'world_horizon',{},99)
        if self.team_mode:
            self.finish_team_deaths()
        elif any(not f.hp for f in self.fighters.values()):
            self.stop_reason = {'kind': 'hp_zero_observation_stop', 'time_ms': self.time,
                                'zero_hp': [n for n, f in self.fighters.items() if not f.hp]}
        for name, config in sorted(self.choices.items()):
            self.request_decision(name, dec(config.get('start_ms', 0)))
        if self.sample_interval is not None:
            self.push(D(0), 'sample', {}, 99)
        while self.queue and not self.stop_reason:
            if self.collider_system is not None:self.collider_system.flush()
            end = min(self.queue[0][0], self.horizon)
            self.advance(end)
            if self.stop_reason:
                break
            self.cooldown_system.settle()
            if self.queue[0][0] > self.horizon:
                break
            priority = self.queue[0][1]
            batch = []
            while self.queue and self.queue[0][0] == self.time and self.queue[0][1] == priority:
                event = heapq.heappop(self.queue)
                if self._live(event):
                    batch.append(event)
            if priority == 0 and not self.team_mode:
                self._check_batch(batch)
            if priority == 0:
                self.effort_system.begin_phases()
            if self.team_mode and priority == 1:
                self.resolve_team_impacts(batch)
            else:
                for event in batch:
                    if self._live(event):
                        self._process(event[3], event[4])
            more_phases_now = (self.queue and self.queue[0][0] == self.time and self.queue[0][1] == 0)
            if any(e[3] not in ('sample','world_horizon') for e in batch):
                self.body_paths.invalidate()
                self.thermal_recovery.invalidate();self.healing.invalidate();self.continuous_effort.invalidate()
                self.grapple_break.invalidate()
            if not more_phases_now:self.healing.settle_points()
            if self.team_mode and priority in (0, 1) and not more_phases_now:
                self.finish_team_deaths()
            if not more_phases_now:
                self.controlled_damage.settle()
                self.continuous_effort.settle()
                self.grapple_links.settle()
                self.grapple_casts.settle()
                self.grapple_break.settle()
                self.terrain_anchors.settle()
                self.bindings.settle()
                self.segment_fields.settle()
                self.projectile_duplication.settle()
                self.distance_constraints.settle()
                self.knock_motion.settle_ballistic()
                if self.mobile_mode and self.settle_climb_attachments():
                    self.refresh_mobile_locomotion()
                self.effort_system.settle()
                self.effort_system.finish_phases()
                self.equilibrium.settle()
                self.body_support.settle()
                self.contact_signals.settle()
                self.body_leaps.settle()
                self.owned_contacts.settle()
                self.ground_speed.settle()
                self.charge_grapples.settle()
                self.aim_control.settle()
                self.grappling_gun.settle()
                self.poison_volumes.settle()
            self.cooldown_system.settle()
            if priority == 0 or (self.team_mode and priority == 1):
                self.sample('after_events')
                if not self.team_mode and any(not f.hp for f in self.fighters.values()):
                    self.stop_reason = {'kind': 'hp_zero_observation_stop', 'time_ms': self.time,
                                        'zero_hp': [n for n, f in self.fighters.items() if not f.hp]}
        if not self.stop_reason:
            self.advance(self.horizon)
        if self.team_mode:
            self.finish_team_deaths()
        if not self.stop_reason:
            self.stop_reason = {'kind': 'observation_horizon_reached', 'time_ms': self.time}
        self.effect_system.settle()
        self.segment_fields.settle()
        self.projectile_duplication.settle()
        self.body_support.settle()
        self.contact_signals.settle()
        self.body_leaps.settle()
        self.owned_contacts.settle()
        self.ground_speed.settle()
        self.charge_grapples.settle()
        self.aim_control.settle()
        self.grappling_gun.settle()
        self.cooldown_system.settle()
        self.effort_system.settle()
        self.log('observation_ended', reason=self.stop_reason,
                 outcome='Deaths resolved; observation continues to the scenario horizon' if self.team_mode else 'No death or victory rule inferred')
        self.sample('final')
        result=self.projectiles.serialize(_text({
            'scenario_id': self.scenario['id'], 'execution_model': 'shared_encounter',
            'initial_states': self.initial, 'final_states': self.states(),
            'run_until_ms': self.time, 'requested_horizon_ms': self.horizon,
            'events': self.event_log.records(), 'curve': self.curve, 'stop_reason': self.stop_reason,
            'scope': self.collider_system.scope if self.collider_system is not None else self.scenario['scope'],
            'configuration': self.scenario,
            'numerics': {'kind': ('integrated_piecewise_kinematics_and_combat' if self.mobile_mode else 'analytic_kinematics_on_shared_timeline' if self.movement_mode else 'finite_precision_analytic_integrals'), 'precision': self.precision,
                         'status_mitigation_precision': 40, 'boundary_tolerance_ms': BOUNDARY_TOLERANCE_MS,
                         'event_times': ('Gathering/hand Recovery ceil once; movement/physical contacts retain fractional ms'
                                         if self.mobile_mode else
                                         'Phase/travel times ceil to integer ms; continuous boundaries retain fractional ms'),
                         **({'geometry':'Rational cuboids and quadratic sweep coefficients; fixed-precision contact roots',
                             'geometry_precision':self.precision} if self.body_mode else {}),
                         **(self.gravity_numerics() if self.gravity_mode else {})},
            'scheduling_rules': {'gathering_extension': ('Add separately mitigated O values from the simultaneous batch, then ceil ms'
                                                        if self.team_mode else
                                                        'Add each newly mitigated incoming O to the scheduled Active start, then ceil ms'),
                                 'active_disorientation': 'Does not insert Gathering',
                                 'beam_deployment': 'Independent after summoning',
                                 'selection_time': 'Policy selects after combat events at the same time'},
            **({'team_rules': {'same_timestamp': 'Complete due phases/releases, then resolve simultaneous incoming hits',
                               'simultaneous_damage': 'Shared pre-hit defenses; proportional raw shield absorption',
                               'target_death_during_action': 'Finish at original location; next action selects nearest living enemy',
                               'recovery': 'Parallel per-hand straight-line movements; longest time, ceiled to ms',
                               'beam_cooldown_anchor': 'Activation request, preserving the existing shared-action anchor',
                               'post_death': 'Cancel controlled actions; released projectiles and deployed effects persist'},
                'surviving_teams': sorted({f.team for f in self.fighters.values() if f.hp > 0})} if self.team_mode else {}),
            'metrics': {n: f.metrics for n, f in sorted(self.fighters.items())},
            'pending_events': [{'time_ms': e[0], 'type': e[3], 'details': e[4]}
                               for e in sorted(self.queue) if self._live(e) and e[3] != 'sample'],
            'pending_effects': [e for e in self.effects if e['expiry'] > self.time and e.get('mode') != 'ended']+self.effect_system.pending()+self.thermal_recovery.pending()+self.cooldown_system.pending()+self.poison_volumes.pending(),
            'shield_loss_history': self.loss_history,
            **({'common_action_rules': {
                'get_up': self.get_up_input if self.get_up_input is not None else {
                    'derived_from':'actor Recovery and supplied basic-jump values',
                    'profiles':{name:{'active_ms':dec(profile['active_ms']),
                        'dyspnea':profile['dyspnea']} for name,profile in self.common_profiles.items()}},
                'knockdown_geometry': ('Shared convex six-cuboid standing/crouch/prone geometry' if self.equilibrium.enabled else
                    'Existing collision proxy retained; this stage changes action eligibility only'),
                'knockdown_trigger': ('Integrated source equilibrium progress, explicit effect or initial state' if self.equilibrium.enabled else
                    'Explicit effect or scenario initial state; no inferred instability threshold'),
            }} if self.common_profiles else {}),
            **(self.movement_result() if self.movement_mode else {}),
            **(self.mobile_result() if self.mobile_mode else {}),
            **(self.body_result() if self.body_mode else {}),
            **self.effect_system.result(),
            **self.poison_volumes.result(),
            **self.weapon_modes.result(),
            **self.thermal_recovery.result(),
            **self.cooldown_system.result(),
            **self.applied_damage.result(),
            **self.effort_system.result(),
            **self.life_cycles.result(),
            **self.revival.result(),
            **self.healing.result(),
            **self.melee.result(),
            **self.blocking.result(),
            **self.dodging.result(),
            **self.reactions.result(),
            **self.attack_modifiers.result(),
            **self.spatial_transitions.result(),
            **self.grapple_links.result(),
            **self.controlled_damage.result(),
            **self.continuous_effort.result(),
            **self.grapple_casts.result(),
            **self.grapple_break.result(),
            **self.body_paths.result(),
            **self.distance_constraints.result(),
            **self.terrain_anchors.result(),
            **self.equilibrium.result(),
            **self.body_support.result(),
            **self.terrain_support.result(),
            **self.contact_signals.result(),
            **self.owned_contacts.result(),
            **self.body_leaps.result(),
            **self.ground_speed.result(),
            **self.charge_grapples.result(),
            **self.accuracy.result(),
            **self.aim_control.result(),
            **self.turns.result(),
            **self.controls.result(),
            **self.impact_bindings.result(),
            **self.impact_areas.result(),
            **self.timed_gathering.result(),
            **self.contact_constructs.result(),
            **self.segment_fields.result(),
            **self.projectile_duplication.result(),
            **self.portals.result(),
            **self.hand_reach.result(),
            **self.bindings.result(),
            **self.body_dashes.result(),
            **self.grappling_gun.result(),
            **self.knock_motion.result(),
            'shield_regenerated_total': sum((r.recovered for r in self.shield_recovery.values()), D(0)) if self.team_mode else 0,
            'sources': ['SHARED_ENCOUNTER_AUDIT.md', '1E1.odt', '1E2.odt', 'Damage types.odt',
                        'Collision details.odt', 'Author clarifications recorded in the audit'],
        }))
        return self.collider_system.serialize(result) if self.collider_system is not None else result


def run_shared_scenario(scenario, profiles, *, precision=50, sample_interval_ms=100, body_definition=None, terrain_definition=None, movement_definition=None, jump_definition=None, climb_definition=None, get_up_definition=None, combat_locomotion_definition=None, projectile_physics_definition=None):
    return SharedEncounter(scenario, profiles, precision, sample_interval_ms,body_definition,terrain_definition,movement_definition,jump_definition,climb_definition,get_up_definition,combat_locomotion_definition,projectile_physics_definition).run()
