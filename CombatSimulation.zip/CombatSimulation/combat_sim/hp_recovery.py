"""Shared passive healing, once-only point entitlements and continuous HP flow."""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.healing_allowance import HealingAllowance
from combat_sim.mechanics.healing_flow import DoseSum,ExpiringFunding,build_healing_flow
from combat_sim.mechanics.healing_flow import ABSOLUTE,RELATIVE,CONTACT_HP
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite


class HPRecovery:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'consumed_healing_v1'} or not world.life_cycles.enabled):
            raise UnsupportedMechanicError('HP healing requires current actor lives and applied damage')
        self.allowance=HealingAllowance(world.applied_damage.history)
        self.passives={};self.points=[];self.records=[];self.curves={};self.curve_ids={};self.cache=None

    def attach(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            for ability,cfg in actor.profile.get('passive_effects',{}).items():
                if cfg.get('execution_model')!='damage_fraction_heal':continue
                if not isinstance(ability,str) or not ability:raise ValueError('Passive healing needs an ability identity')
                if (cfg.get('execution_model')!='damage_fraction_heal'
                        or cfg.get('dyspnea',{}).get('kind')!='none'):
                    raise UnsupportedMechanicError('Unsupported passive healing definition')
                ratio=finite(cfg['fraction'],'Healing fraction',positive=True)
                if actor.id in self.passives:raise UnsupportedMechanicError('Multiple healing passives need an explicit composition rule')
                self.passives[actor.id]={'ability':ability,'fraction':ratio}
                actor.metrics.update(hp_healed=D(0),healing_entitlement_discarded=D(0))

    def invalidate(self):self.cache=None

    def stage_points(self,entries):
        if self.enabled:self.points.extend(entries)

    def _record(self,name,begin,end,requested,amount,claim,entries,curve=None):
        actor=self.world.fighters[name];curve_id=None;basis=None
        if curve is not None and amount:
            curve_id=self.curve_ids.get(curve)
            if curve_id is None:
                curve_id='healing-curve:'+str(len(self.curves)+1)
                self.curves[curve_id]=curve;self.curve_ids[curve]=curve_id
            basis=curve.integral(begin,end)
        row={'id':'healing:'+str(len(self.records)+1),'actor':name,'ability':self.passives[name]['ability'],
            'recipient_life_generation':actor.life_generation,'begin_ms':begin,'end_ms':end,
            'requested_hp':requested,'applied_healing_hp':amount,'discarded_entitlement_hp':max(D(0),requested-amount),
            'trigger_loss_ids':[e.id for e in entries],'funding':claim.record(),
            'curve_id':curve_id,'curve_basis_hp':basis}
        self.records.append(row);actor.metrics['hp_healed']+=amount
        actor.metrics['healing_entitlement_discarded']+=row['discarded_entitlement_hp']
        self.world.log('hp_healing_applied',**deepcopy(row))

    def settle_points(self):
        if not self.points:return
        entries=tuple(self.points);self.points.clear();world=self.world
        world.applied_damage.history.observe_until(world.time)
        for name,cfg in sorted(self.passives.items()):
            outgoing=tuple(e for e in entries if e.contribution.eligible and e.contribution.source.actor==name)
            if not outgoing:continue
            actor=world.fighters[name];requested=cfg['fraction']*sum((e.amount for e in outgoing),D(0))
            receipt='healing:'+str(len(self.records)+1)
            quote=self.allowance.claim(receipt,name,world.time,requested,
                missing_hp=max(D(0),dec(actor.profile['max_hp'])-actor.hp),alive=actor.hp>0)
            if quote.amount:actor.hp+=quote.amount
            self._record(name,world.time,world.time,requested,quote.amount,quote,outgoing)
        self.invalidate()

    def _matches(self):
        if self.cache is None or not self.cache['begin']<=self.world.time<self.cache['end']:return False
        for name,plan in self.cache['plans'].items():
            actor=self.world.fighters[name];hp,_,cursor=plan.at(self.world.time)
            if (actor.hp<=0 or abs(actor.hp-hp)>D('1e-9') or
                    abs(self.allowance.cursors.get(name,D(0))-cursor)>D('1e-9')):return False
        return True

    def prepare(self,end):
        if not self.enabled or not self.passives:return end
        world=self.world;now=world.time
        if self._matches():return min(end,self.cache['end'])
        world.applied_damage.history.observe_until(now)
        # Build a conditional physical epoch, independently of sample times.
        epoch_end=world.effect_system.prepare_interval(now+250,physical_only=True)
        for name in self.passives:
            expiry=ExpiringFunding.snapshot(world.applied_damage.history,name,now,epoch_end)
            epoch_end=min(epoch_end,expiry.next_point())
        if epoch_end<=now:return now
        parts=world.components(now,epoch_end);incoming={};outgoing={}
        for target,values in parts.items():
            if target not in world.fighters:continue
            for part in values:
                if part['channel']!='hp':continue
                curve=world.applied_damage.curve(target,part,now,epoch_end)
                incoming.setdefault(target,[]).append((D(1),curve))
                source=part['actor']
                if source in self.passives and world.applied_damage.eligible(source,target):
                    outgoing.setdefault(source,[]).append((self.passives[source]['fraction'],curve))
        plans={}
        for name in outgoing:
            actor=world.fighters[name]
            if actor.hp<=0:continue
            total,expired=self.allowance.funding(name,now)
            cursor=max(self.allowance.cursors.get(name,D(0)),expired)
            expiry=ExpiringFunding.snapshot(world.applied_damage.history,name,now,epoch_end)
            plans[name]=build_healing_flow(now,epoch_end,hp=actor.hp,max_hp=dec(actor.profile['max_hp']),
                incoming=DoseSum(tuple(incoming.get(name,()))),entitlement=DoseSum(tuple(outgoing[name])),
                funding_total=total,cursor=cursor,expiring=expiry)
        self.cache={'begin':now,'end':epoch_end,'plans':plans}
        return min(end,epoch_end)

    def death(self,name,begin,end):
        plan=(self.cache or {}).get('plans',{}).get(name)
        return plan.death(begin,end,initial_hp=self.world.fighters[name].hp) if plan is not None else None

    def has_flow(self,name):return name in (self.cache or {}).get('plans',{})

    def interval(self,begin,end):
        plans=dict((self.cache or {}).get('plans',{}))
        return {'begin':begin,'end':end,'plans':plans,'entry_start':len(self.world.applied_damage.history.entries),
            'heals':{name:max(D(0),p.at(end)[1]-p.at(begin)[1]) for name,p in plans.items()}}

    def commit_interval(self,payment):
        if not self.enabled:return
        world=self.world;begin,end=payment['begin'],payment['end']
        entries=world.applied_damage.history.entries[payment['entry_start']:]
        for name,cfg in sorted(self.passives.items()):
            outgoing=tuple(e for e in entries if e.contribution.eligible and e.contribution.source.actor==name)
            if not outgoing:continue
            requested=cfg['fraction']*sum((e.amount for e in outgoing),D(0))
            amount=payment['heals'].get(name,D(0));plan=payment['plans'].get(name)
            receipt='healing:'+str(len(self.records)+1)
            if plan is not None:
                claim=self.allowance.commit_flow(receipt,name,begin,end,requested,amount,plan.at(end)[2])
            else:
                actor=world.fighters[name]
                claim=self.allowance.claim(receipt,name,end,requested,
                    missing_hp=max(D(0),dec(actor.profile['max_hp'])-actor.hp),alive=False)
            self._record(name,begin,end,requested,amount,claim,outgoing,plan.healing_curve() if amount else None)

    def result(self):
        if not self.enabled:return {}
        return {'healing_rules':self.world.combat_locomotion_input['hp_recovery'],
            'healing_allowance':self.allowance.record(),
            'healing_numerics':{'physical_epoch_ms':250,'maximum_adaptive_step_ms':20,
                'absolute_tolerance_hp':ABSOLUTE,'relative_tolerance':RELATIVE,'constraint_tolerance_hp':CONTACT_HP},
            'healing_history':{'precision':self.world.precision,'observed_until_ms':self.world.time,
                'entries':deepcopy(self.records),'curves':{key:curve.record() for key,curve in self.curves.items()}}}
