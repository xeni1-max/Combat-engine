"""Single-impact event runner with shield-first blunt damage."""

from fractions import Fraction
from typing import Any

from combat_sim.actions import ScriptedActionSequence
from combat_sim.encounters import initial_states
from combat_sim.events import EventLog
from combat_sim.mechanics.blunt import (
    ARMOR_REDUCTION_FORMULA,
    POST_MITIGATION_FORMULA,
    SOURCE as BLUNT_SOURCE,
    armor_reduction,
    post_mitigation_damage,
    raw_armor_reduction,
    raw_post_mitigation_damage,
)
from combat_sim.mechanics.shield import split_damage
from combat_sim.mechanics.timing import impact_time_from_activation
from combat_sim.models import UnsupportedMechanicError, as_fraction, fraction_record
from combat_sim.state_updates import _advance_regeneration, _state_snapshot, _time_value, _validate_shield_state


def _resolve_scripted_timing(
    inputs: list[dict[str, Any]], character_data: dict[str, Any]
) -> list[dict[str, Any]]:
    """Resolve action activations while preserving direct impact-time inputs."""
    resolved = []
    for item in inputs:
        kind = item.get("kind")
        common_fields = {"kind", "actor", "target", "ability", "hit_confirmed", "target_context"}
        time_fields = {
            "impact": {"time_ms"},
            "activation": {"action_start_ms", "target_distance_m"},
        }
        if kind not in time_fields:
            raise UnsupportedMechanicError("Current stage accepts kind='impact' or kind='activation' inputs")
        unsupported = set(item) - common_fields - time_fields[kind]
        if unsupported:
            raise UnsupportedMechanicError(
                "Action input fields are not implemented by this combat stage: "
                + ", ".join(sorted(unsupported))
            )
        if kind == "impact":
            impact_time = item.get("time_ms")
            if not isinstance(impact_time, int) or impact_time < 0:
                raise ValueError("Every impact time_ms must be a nonnegative integer")
            resolved.append({"impact_time_ms": Fraction(impact_time), "timing": None})
            continue

        if kind != "activation":
            raise UnsupportedMechanicError("Current stage accepts kind='impact' or kind='activation' inputs")
        start_time = item.get("action_start_ms")
        if not isinstance(start_time, int) or start_time < 0:
            raise ValueError("Every action_start_ms must be a nonnegative integer")
        actor_name = item.get("actor")
        ability_id = item.get("ability")
        if actor_name not in character_data:
            raise ValueError("Activation actor must exist in character data")
        actor_data = character_data[actor_name]
        timing_profile = actor_data.get("timing_profiles", {}).get(ability_id)
        if timing_profile is None:
            timing_profile = actor_data.get("abilities", {}).get(ability_id)
        if timing_profile is None:
            raise ValueError(f"Unknown ability or timing profile {actor_name}/{ability_id}")
        impact_time, timing = impact_time_from_activation(
            start_time, timing_profile, item.get("target_distance_m")
        )
        timing["source"] = timing_profile.get(
            "timing_source", timing_profile.get("source", "unspecified character timing profile")
        )
        resolved.append({"impact_time_ms": impact_time, "timing": timing})
    return resolved


def run_scenario(scenario: dict[str, Any], character_data: dict[str, Any], *, body_definition=None, terrain_definition=None, movement_definition=None, jump_definition=None, climb_definition=None, get_up_definition=None, combat_locomotion_definition=None, projectile_physics_definition=None) -> dict[str, Any]:
    """Dispatch the supported controlled ability model, or run legacy blunt hits."""
    if scenario.get("execution_model") == "shared_encounter":
        from combat_sim.shared_engine import run_shared_scenario
        return run_shared_scenario(scenario, character_data,body_definition=body_definition,terrain_definition=terrain_definition,movement_definition=movement_definition,jump_definition=jump_definition,climb_definition=climb_definition,get_up_definition=get_up_definition,combat_locomotion_definition=combat_locomotion_definition,projectile_physics_definition=projectile_physics_definition)
    if projectile_physics_definition is not None:
        raise UnsupportedMechanicError('Projectile physics requires shared gravity combat')
    if combat_locomotion_definition is not None:
        raise UnsupportedMechanicError('Combat locomotion definitions require shared moving combat')
    if get_up_definition is not None:
        raise UnsupportedMechanicError('Get Up requires shared team combat')
    if movement_definition is not None or jump_definition is not None or climb_definition is not None:
        raise UnsupportedMechanicError('Locomotion definitions require the shared movement test scope')
    if body_definition is not None:
        raise UnsupportedMechanicError('Body definitions apply only to the shared body collision scope')
    if terrain_definition is not None:
        raise UnsupportedMechanicError('Terrain definitions apply only to the shared terrain collision scope')
    selected = ScriptedActionSequence(scenario.get("action_sequence", [])).inputs()
    models = [
        character_data.get(item.get("actor"), {}).get("abilities", {})
        .get(item.get("ability"), {}).get("execution_model")
        for item in selected
    ]
    if any(model is not None for model in models):
        if len(selected) != 1:
            raise UnsupportedMechanicError(
                "Controlled ability models support exactly one activation, without other actions"
            )
        if models[0] == "projectile_delayed_area":
            from combat_sim.projectile_engine import run_projectile_scenario
            return run_projectile_scenario(scenario, character_data)
        if models[0] == "venomous_thrust":
            from combat_sim.venomous_engine import run_venomous_scenario
            return run_venomous_scenario(scenario, character_data)
        if models[0] == "slash_projectile":
            from combat_sim.slash_projectile_engine import run_slash_projectile_scenario
            return run_slash_projectile_scenario(scenario, character_data)
        if models[0] == "poison_grenade":
            from combat_sim.poison_grenade_engine import run_poison_grenade_scenario
            return run_poison_grenade_scenario(scenario, character_data)
        if models[0] == "heat_beam":
            from combat_sim.heat_engine import run_heat_scenario
            return run_heat_scenario(scenario, character_data)
        raise UnsupportedMechanicError(f"Unsupported execution model {models[0]!r}")
    states = initial_states(scenario.get("encounter", {}))
    initial_snapshot = _state_snapshot(states)
    event_log = EventLog()
    inputs = ScriptedActionSequence(scenario.get("action_sequence", [])).inputs()
    if not inputs:
        raise UnsupportedMechanicError("Scenario must include at least one explicit impact input")

    resolved_inputs = _resolve_scripted_timing(inputs, character_data)
    event_times = [item["impact_time_ms"] for item in resolved_inputs]
    if event_times != sorted(event_times):
        raise ValueError("Action sequence impacts must be ordered by nondecreasing impact time")
    signature = (inputs[0].get("actor"), inputs[0].get("target"), inputs[0].get("ability"))
    if any((item.get("actor"), item.get("target"), item.get("ability")) != signature for item in inputs):
        raise UnsupportedMechanicError("Repeated-impact stage requires one actor, target, and ability per run")

    pending: list[dict[str, Any]] = []
    current_time_ms = 0

    for impact_index, (impact, resolved_timing) in enumerate(zip(inputs, resolved_inputs)):
        impact_time_ms = resolved_timing["impact_time_ms"]
        if impact.get("hit_confirmed") is not True:
            raise UnsupportedMechanicError("Current stage requires each successful hit to be supplied by the scenario")
        _advance_regeneration(
            states, character_data, pending, current_time_ms, impact_time_ms, event_log
        )

        actor_name = impact.get("actor")
        target_name = impact.get("target")
        ability_id = impact.get("ability")
        if actor_name not in character_data or target_name not in character_data:
            raise ValueError("Impact actor and target must exist in character data")
        if actor_name not in states or target_name not in states:
            raise ValueError("Impact actor and target must have initial states")

        actor_data = character_data[actor_name]
        try:
            ability = actor_data["abilities"][ability_id]
        except KeyError as exc:
            if ability_id in actor_data.get("timing_profiles", {}):
                raise UnsupportedMechanicError(
                    f"Timing is available for {actor_name}/{ability_id}, but its damage/effect mechanics are not implemented"
                ) from exc
            raise ValueError(f"Unknown ability {actor_name}/{ability_id}") from exc

        context = impact.get("target_context", {})
        for key, expected in ability.get("context_requirements", {}).items():
            if context.get(key) is not expected:
                raise UnsupportedMechanicError(
                    f"Ability {actor_name}/{ability_id} requires target_context.{key}={expected}"
                )

        target_character = character_data[target_name]
        if "shield_capacity" not in target_character:
            raise UnsupportedMechanicError(
                f"Combat defender data for {target_name} is incomplete: shield_capacity is not loaded; "
                "timing or documented ability data alone does not make the profile executable"
            )
        target_state = states[target_name]
        shield_capacity = as_fraction(target_character["shield_capacity"])
        _validate_shield_state(target_state, shield_capacity, target_name)
        if ability.get("damage_type") != "blunt":
            raise UnsupportedMechanicError(
                f"Current stage does not implement damage_type={ability.get('damage_type')!r}"
            )

        incoming_damage = as_fraction(ability["pre_mitigation_damage"])
        shield_damage, overflow_damage = split_damage(incoming_damage, target_state.shield)
        shield_before = target_state.shield
        hp_before = target_state.hp
        armor_before = target_state.armor
        target_state.shield -= shield_damage

        if overflow_damage > 0:
            raw_y = raw_post_mitigation_damage(overflow_damage, armor_before)
            raw_armor_loss = raw_armor_reduction(overflow_damage, armor_before)
            y = post_mitigation_damage(overflow_damage, armor_before)
            armor_loss = armor_reduction(overflow_damage, armor_before)
            target_state.hp = max(Fraction(0), hp_before - y)
            target_state.armor = max(Fraction(0), armor_before - armor_loss)
            formula_status = "evaluated_on_damage_left_after_shield"
        else:
            raw_y = Fraction(0)
            raw_armor_loss = Fraction(0)
            y = Fraction(0)
            armor_loss = Fraction(0)
            formula_status = "skipped_fully_absorbed_by_shield"

        hp_lost = hp_before - target_state.hp
        armor_lost = armor_before - target_state.armor

        regeneration = target_character.get("shield_regeneration")
        if shield_damage > 0:
            if regeneration is None:
                raise UnsupportedMechanicError(f"{target_name} has no documented shield regeneration data")
            rate = as_fraction(regeneration["rate_per_second"])
            if rate <= 0:
                raise ValueError(f"{target_name} shield regeneration rate must be positive")
            cohort = {
                "loss_instance": impact_index,
                "target": target_name,
                "loss_at_ms": impact_time_ms,
                "eligible_at_ms": impact_time_ms + int(regeneration["delay_ms"]),
                "remaining": shield_damage,
                "rate_per_second": rate,
                "source": regeneration["source"],
            }
            pending.append(cohort)

        event = {
            "time_ms": _time_value(impact_time_ms),
            "type": "impact_resolved",
            "actor": actor_name,
            "target": target_name,
            "ability": ability_id,
            "hit_confirmation": "supplied_by_scenario",
            "timing_calculation": (
                {
                    **resolved_timing["timing"],
                    "source": resolved_timing["timing"].get(
                        "source", ability.get("timing_source", ability["source"])
                    ),
                }
                if resolved_timing["timing"] is not None
                else None
            ),
            "damage_calculation": {
                "damage_type": "blunt",
                "incoming_damage": fraction_record(incoming_damage),
                "shield_handling": {
                    "shield_damage_is_unmitigated": True,
                    "shield_before": fraction_record(shield_before),
                    "damage_to_shield": fraction_record(shield_damage),
                    "shield_after_impact": fraction_record(target_state.shield),
                    "damage_left_after_shield": fraction_record(overflow_damage),
                },
                "formulas": {
                    "post_mitigation_damage": POST_MITIGATION_FORMULA,
                    "armor_reduction": ARMOR_REDUCTION_FORMULA,
                },
                "formula_evaluation": formula_status,
                "formula_inputs": (
                    {"d_left_after_shield": str(overflow_damage), "a_pre_impact": str(armor_before)}
                    if overflow_damage > 0
                    else None
                ),
                "outputs": {
                    "y": {"formula_source": BLUNT_SOURCE, **fraction_record(y)},
                    "Ar": {"formula_source": BLUNT_SOURCE, **fraction_record(armor_loss)},
                },
                "applied_state_losses": {
                    "hp": fraction_record(hp_lost),
                    "armor": fraction_record(armor_lost),
                },
                "excess_formula_outputs": {
                    "hp": fraction_record(y - hp_lost),
                    "armor": fraction_record(armor_loss - armor_lost),
                },
                "raw_formula_outputs_before_zero_clamp": {
                    "y": fraction_record(raw_y),
                    "Ar": fraction_record(raw_armor_loss),
                },
                "negative_output_rule": "negative damage and armor-loss outputs are clamped to zero per user clarification",
                "state_mapping": "y reduces HP; Ar reduces armor; both use pre-impact armor; resulting HP and armor floor at zero",
                "state_floor_rule": "User clarification: current HP and armor have minimum zero; excess is logged without assigning damage credit",
                "state_mapping_status": "confirmed_by_user",
            },
            "state_changes": {
                "target": target_name,
                "hp_before": fraction_record(hp_before),
                "hp_after_impact": fraction_record(target_state.hp),
                "armor_before": fraction_record(armor_before),
                "armor_after_impact": fraction_record(target_state.armor),
                "shield_before": fraction_record(shield_before),
                "shield_after_impact": fraction_record(target_state.shield),
            },
            "sources": {
                "ability": ability["source"],
                "timing_rule": (
                    resolved_timing["timing"].get("source", "impact timestamp supplied by scenario")
                    if resolved_timing["timing"] is not None
                    else "impact timestamp supplied by scenario"
                ),
                "target_profile": target_character["source"],
                "damage_rule": BLUNT_SOURCE,
                "shield_priority_and_overflow": "user clarification in current conversation",
            },
        }
        event_log.record(event)
        current_time_ms = impact_time_ms

    last_impact_ms = event_times[-1]
    configured_run_until = scenario.get("run_until_ms")
    if configured_run_until is None:
        run_until_ms = last_impact_ms
    elif not isinstance(configured_run_until, int) or configured_run_until < 0:
        raise ValueError("run_until_ms must be a nonnegative integer")
    else:
        run_until_ms = Fraction(configured_run_until)
    if run_until_ms < last_impact_ms:
        raise ValueError("run_until_ms must be an integer at or after the last impact")
    _advance_regeneration(
        states, character_data, pending, current_time_ms, run_until_ms, event_log
    )

    events = event_log.records()
    final_snapshot = _state_snapshot(states)
    return {
        "scenario_id": scenario.get("id", "unnamed"),
        "initial_states": initial_snapshot,
        "inputs": inputs,
        "run_until_ms": _time_value(run_until_ms),
        "events": events,
        "final_states": final_snapshot,
        "assumptions_and_limits": [
            "Successful hits are supplied by the scenario. For abilities with a supported documented impact anchor, the engine derives impact time from action start, Gathering, and Active duration; other impact times are supplied directly.",
            "Each shield-loss impact receives its own 20-second regeneration timer.",
            "Each shield loss has its own delay; all eligible losses share the profile's single shield regeneration rate.",
            "When allocating shared recovery for the event log, eligible losses are attributed oldest first.",
            "Shield absorbs raw incoming damage first; only overflow reaches the blunt formulas.",
            "A fully shield-absorbed hit does not reduce armor, as clarified by the user.",
            "Exact rational values are retained because the sources specify no rounding rule.",
            "HP and armor floor at zero. Nominal formula outputs and actual state losses are separate; death, revival, and excess-damage credit are outside this stage.",
            "Disorientation, instability, knockback, recovery, cooldowns, and other effects are outside this stage.",
        ],
    }
