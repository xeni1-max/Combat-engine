"""Shared optional pose acceleration, separate from reference translation."""
from decimal import Decimal as D
from combat_sim.hitboxes import local_to_world_point
from combat_sim.postures import pose_local_hand_position

ZERO=(D(0),)*3


def pose_acceleration(world,name,part,time):
    """Keep legacy/minimal worlds valid when no accelerated pose is enabled."""
    method=getattr(world,'pose_part_acceleration',None)
    return method(name,part,time) if method is not None else (ZERO,ZERO)


def projectile_pose_acceleration(world,name,part,time):
    layer=getattr(world.blocking,'layers',{}).get(part)
    if layer is not None and layer['frozen_box'] is not None:return ZERO,ZERO
    return pose_acceleration(world,name,part,time)


def pose_moving(world,name):
    turns=getattr(world,'turns',None)
    if turns is not None and turns.active(name):return True
    if world.posture_at(name,world.time)[1]:return True
    equilibrium=getattr(world,'equilibrium',None)
    return bool(equilibrium is not None and equilibrium.enabled and equilibrium.moving(name,world.time))


def base_world_hand_point(world,actor,point):
    equilibrium=getattr(world,'equilibrium',None)
    if equilibrium is not None and equilibrium.carries(actor.id):return equilibrium.world_hand(actor.id,point)
    drop=getattr(actor,'pose_drop_m',None)
    if drop is not None:point=pose_local_hand_position(point,drop)
    return local_to_world_point(point,actor.body_origin_m,actor.facing)


def world_hand_point(world,actor,point):
    reach=getattr(world,'hand_reach',None)
    if reach is not None and reach.ready:return reach.point(actor,point)
    return base_world_hand_point(world,actor,point)


def physical_hand_recovery(world,actor,current,required,value,*,equilibrium_legacy=False):
    """Use the same actual reach for Recovery and released attack origins."""
    from combat_sim.battle_models import decimal_value as dec
    from combat_sim.mechanics.recovery import hand_recovery
    reach=getattr(world,'hand_reach',None)
    if reach is not None and reach.ready:
        current={h:reach.local_point(actor,p) for h,p in current.items()}
        required={h:reach.local_point(actor,p) for h,p in required.items()}
        duration,records=hand_recovery(current,required,value)
        for row in records.values():
            for key in ('start_m','required_m'):row[key]=list(map(dec,row[key]))
        return duration,records
    equilibrium=getattr(world,'equilibrium',None)
    if equilibrium_legacy and equilibrium is not None and equilibrium.carries(actor.id):
        current={h:tuple(map(dec,equilibrium.local_hand(actor.id,p))) for h,p in current.items()}
        required={h:tuple(map(dec,equilibrium.local_hand(actor.id,p))) for h,p in required.items()}
    return hand_recovery(current,required,value)
