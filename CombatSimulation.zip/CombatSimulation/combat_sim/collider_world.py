"""World collider lifecycles composed with the existing combat coordinator."""
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.automatic_abilities import ability_definition
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics import projectile_damage
from combat_sim.models import UnsupportedMechanicError, as_fraction
from combat_sim.mechanics.life import life_generation
from combat_sim.world_colliders import ColliderPolicy, ColliderRegistry, OBJECT_DAMAGE_TYPES, finite, segment_crosses_interior
from combat_sim.orientation import YawFrame,scalar
from combat_sim.oriented_geometry import OrientedCuboid,boxes_overlap
from combat_sim.box_motion import closest_point


class SharedColliders:
    def __init__(self,world,definition=None):
        self.world=world
        if definition is not None and definition not in ({'mode':'fixed_compound_v1'},{'mode':'fixed_compound_v2'}):
            raise UnsupportedMechanicError('Unsupported world collider rules')
        self.enabled=definition is not None
        self.instant_areas=definition=={'mode':'fixed_compound_v2'}
        if self.enabled and (not world.mobile_mode or world.combat_locomotion_input.get('world',{}).get('ruleset')!='integrated_v2'):
            raise UnsupportedMechanicError('Mutable world colliders require integrated persistent-flight/body combat')
        self.registry=ColliderRegistry(world.fighters)
        self.scope=dict(world.scenario['scope'])
        if self.enabled:self.scope.update(obstacles='fixed_compound_colliders',area_occlusion='per_collider_witness_policy')
        self.dirty=False
        self.initializing=True

    def import_terrain(self,definition,geometry):
        objects={p['id']:p for p in definition['obstacles']}
        floor=definition['ground']['id']
        if any(item.get('hp') is not None for item in objects.values()):self.require_mutable()
        for name,parts in geometry.items():
            item=objects.get(name,{})
            self.registry.add(parts,time=0,source='terrain:'+definition['id'],kind='terrain',entity_id=name,
                permanent=name==floor,climbable=item.get('climbable',False),hp=item.get('hp'),tags=item.get('tags',()))
        self.sync()

    def sync(self):
        self.world.terrain_colliders=self.registry.active()

    def require_mutable(self):
        if not self.enabled:raise UnsupportedMechanicError('Mutable colliders require explicit current world collider rules')

    def _check_heat(self,affects_areas):
        if affects_areas and any(e['kind']=='heat' and e['start']<=self.world.time<e['leave'] for e in self.world.effects):
            raise UnsupportedMechanicError('Changing area cover during a deployed beam requires volume/exposure integration')

    def _check_geometry(self,parts,policy):
        if not policy.bodies:return
        for actor in self.world.fighters.values():
            if actor.hp<=0:continue
            for body in self.world.world_bodies[actor.id]:
                low,high=body.bounds
                if any((boxes_overlap(body,part,closed=False) if isinstance(body,OrientedCuboid) or isinstance(part,OrientedCuboid) else
                        all(max(a,c)<min(b,d) for a,b,c,d in zip(low,high,part.bounds[0],part.bounds[1]))) for part in parts):
                    raise ValueError('Collider creation/reshaping cannot penetrate a living body')

    def spawn(self,parts,*,source,hp=None,expires_at_ms=None,climbable=False,policy=ColliderPolicy(),
            entity_id=None,owner=None,ability=None,action_id=None,tags=(),source_life_generation=None,immune_damage_types=()):
        self.require_mutable()
        parts=ColliderRegistry.validate_parts(parts,climbable)
        self._check_frames(parts)
        if not isinstance(policy,ColliderPolicy):raise ValueError('Invalid collider policy')
        self._check_geometry(parts,policy)
        self._check_heat(policy.areas)
        if owner is not None and (owner not in self.world.fighters or ability not in self.world.fighters[owner].profile['abilities']):
            raise ValueError('Unknown collider source actor/ability')
        if source_life_generation is not None:
            life_generation(source_life_generation)
            if owner is None or not self.world.life_cycles.enabled or not any(
                    row['generation']==source_life_generation for row in self.world.life_cycles.lives.get(owner,())):
                raise ValueError('Collider source life must be a known life of its owner')
        else:source_life_generation=self.world.life_cycles.generation(owner) if owner is not None else None
        obj=self.registry.add(parts,time=self.world.time,source=source,entity_id=entity_id,hp=hp,
            expires_at_ms=expires_at_ms,climbable=climbable,policy=policy,owner=owner,ability=ability,action_id=action_id,
            source_life_generation=source_life_generation,tags=tags,immune_damage_types=immune_damage_types)
        self.sync();self.dirty=not self.initializing
        self.schedule_expiry(obj)
        self.world.log('world_collider_created',collider=obj.record())
        return obj.identity.id

    def load_initial(self,items):
        if not isinstance(items,list):raise ValueError('Initial colliders must be a list')
        for item in items:
            self.spawn_definition(item)
        self.initializing=False
        self.initial=self.registry.record()

    def spawn_definition(self,item):
        required={'id','parts','hp','duration_ms','climbable','blocking','source'}
        if not isinstance(item,dict) or not required<=set(item) or set(item)-required-{'tags','damage_immunities'}:
            raise ValueError('Collider definition requires id, parts, hp, duration_ms, climbable, blocking and source')
        if not isinstance(item['parts'],list):raise ValueError('Collider parts must be a list')
        parts=[]
        for part in item['parts']:
            if (not isinstance(part,dict) or not {'part','centre_m','size_m'}<=set(part)
                    or set(part)-{'part','centre_m','size_m','yaw_degrees'}):raise ValueError('Collider part requires name, centre and size')
            if 'yaw_degrees' in part:
                # A material yaw rotates its old world-x/world-y dimensions;
                # body frames describe forward heading, hence the +90 offset.
                frame=YawFrame.from_degrees(scalar(part['yaw_degrees'])+90,precision=self.world.precision)
                parts.append(OrientedCuboid(part['part'],part['centre_m'],part['size_m'],frame))
            else:parts.append(Cuboid(part['part'],part['centre_m'],part['size_m']))
        duration=finite(item['duration_ms'],'Collider duration',positive=True) if item['duration_ms'] is not None else None
        return self.spawn(parts,source=item['source'],entity_id=item['id'],hp=item['hp'],climbable=item['climbable'],
            expires_at_ms=self.world.time+duration if duration is not None else None,
            policy=ColliderPolicy.from_definition(item['blocking']),tags=item.get('tags',()),
            immune_damage_types=item.get('damage_immunities',()))

    def schedule_expiry(self,obj):
        if obj.expires_at_ms is not None:
            self.world.push(obj.expires_at_ms,'world_collider_expired',
                {'collider_id':obj.identity.id,'expiry_revision':obj.expiry_revision})

    def _check_frames(self,parts):
        if any(isinstance(p,OrientedCuboid) for p in parts) and not self.world.terrain_support.finite_ground:
            raise UnsupportedMechanicError('Oriented materials require current finite-face support and contact rules')

    def expiry_live(self,payload):
        obj=self.registry.objects.get(payload['collider_id'])
        return obj is not None and obj.status=='active' and obj.expiry_revision==payload['expiry_revision']

    def expire(self,payload):
        if self.expiry_live(payload):
            self.remove(payload['collider_id'],reason='lifetime_expired',status='expired')

    def set_expiry(self,entity_id,expires_at_ms):
        self.require_mutable()
        obj=self.registry.objects[entity_id]
        if self.registry.set_expiry(entity_id,time=self.world.time,expires_at_ms=expires_at_ms):
            self.schedule_expiry(obj)
            self.world.log('world_collider_expiry_changed',collider=obj.record())
            return True
        return False

    def reshape(self,entity_id,*,parts=None,policy=None):
        self.require_mutable()
        obj=self.registry.objects[entity_id]
        if not obj.active(self.world.time):return False
        chosen=policy if policy is not None else obj.policy
        if not isinstance(chosen,ColliderPolicy):raise ValueError('Invalid collider policy')
        geometry=ColliderRegistry.validate_parts(parts if parts is not None else obj.parts,obj.climbable)
        self._check_frames(geometry)
        self._check_heat(obj.policy.areas or chosen.areas)
        self._check_geometry(geometry,chosen)
        body_changed=geometry!=obj.parts or chosen.bodies!=obj.policy.bodies
        if self.registry.reshape(entity_id,parts=geometry,policy=chosen,time=self.world.time):
            self._changed(entity_id,'geometry_or_policy_changed',body_changed=body_changed)
            self.world.log('world_collider_changed',collider=obj.record())
            return True
        return False

    def remove(self,entity_id,*,reason,status='removed'):
        self.require_mutable()
        obj=self.registry.objects[entity_id]
        if obj.status!='active':return False
        self._check_heat(obj.policy.areas and obj.active(self.world.time))
        if self.registry.remove(entity_id,time=self.world.time,reason=reason,status=status):
            self._changed(entity_id,reason)
            self.world.log('world_collider_removed',collider=obj.record())
            return True
        return False

    def damage(self,entity_id,amount,*,source,interval_begin_ms=None,damage_type=None):
        self.require_mutable()
        if not isinstance(source,str) or not source:raise ValueError('Collider damage requires its source')
        obj=self.registry.objects[entity_id]
        if damage_type is not None and (not isinstance(damage_type,str) or
                damage_type not in OBJECT_DAMAGE_TYPES and damage_type not in obj.damage_immunities):
            raise ValueError('Unsupported object damage type')
        amount=finite(amount,'Collider damage')
        begin=finite(interval_begin_ms,'Continuous damage start') if interval_begin_ms is not None else None
        if begin is not None and begin>=self.world.time:raise ValueError('Continuous collider damage needs a positive interval')
        accepts=obj.active(self.world.time) or (begin is not None and obj.active(begin)
            and obj.status=='active' and obj.expires_at_ms==self.world.time)
        if not accepts or obj.hp is None:return D(0)
        if damage_type in obj.damage_immunities:
            self.world.log('world_collider_damage_ignored',collider_id=entity_id,source=source,
                damage_type=damage_type,incoming=amount,reason='material_immunity')
            return D(0)
        if amount>=obj.hp:self._check_heat(obj.policy.areas)
        before=obj.hp
        applied=self.registry.damage(entity_id,amount,time=self.world.time,interval_begin_ms=begin)
        self.world.log('world_collider_damaged',collider_id=entity_id,source=source,hp_before=before,
            incoming=amount,applied=applied,overkill=max(D(0),amount-before),hp_after=obj.hp,
            character_recovery_credit=False,**({'damage_type':damage_type} if damage_type is not None else {}))
        if obj.status=='destroyed':
            self._changed(entity_id,'hp_zero')
            self.world.log('world_collider_removed',collider=obj.record())
        return applied

    def damage_packets(self,groups):
        for entity_id,packets in sorted(groups.items()):
            obj=self.registry.objects[entity_id]
            if obj.hp is None:continue
            inputs=[]
            for packet in packets:
                ability=self.world.attack_definition(packet['actor'],packet['ability'],packet.get('melee_component'),packet=packet)
                raw=self.world.effort_system.raw_damage(packet,ability)
                if 'range_falloff' in ability:
                    falloff=ability['range_falloff']
                    raw=dec(projectile_damage.damage_after_distance(raw,packet['distance_m'],falloff['damage_loss'],falloff['distance_m']))
                family=self.world.impact_areas.damage_type(packet,ability.get('direct_damage_type',ability['damage_type']))
                inputs.append({**packet,'incoming':D(0) if family in obj.damage_immunities else raw,'damage_type':family,
                    **({'incoming_before_immunity':raw,'material_immune':True} if family in obj.damage_immunities else {})})
            total=sum((p['incoming'] for p in inputs),D(0))
            before=obj.hp
            applied=self.damage(entity_id,total,source='simultaneous_direct_hits')
            self.world.log('world_collider_impact_batch',collider_id=entity_id,hp_before=before,
                hits=inputs,applied_hp_damage=applied,hp_after=obj.hp,
                same_batch_rule=('Directed lines stop at the pre-batch solid; its break does not expose excluded receivers'
                    if any(p.get('delivery_kind')=='piercing_line' for p in inputs) else
                    'Area damage applies once across parts; direct hits stop at the pre-batch solid without overkill transmission'
                    if any(p.get('component') in ('delayed_blast','impact_area') for p in inputs) else
                    'All nonpiercing projectiles are consumed by the pre-batch collider; no overkill transmission'))

    def area_recipients(self,centre,radius,shape):
        """One receiver per live HP pool, regardless of overlapping parts."""
        if not self.instant_areas:return []
        recipients=[]
        for identity,obj in sorted(self.registry.objects.items()):
            if obj.hp is None or not obj.active(self.world.time):continue
            if shape=='sphere':parts=[p for p in obj.parts if p.intersects_sphere(centre,radius)]
            elif shape=='vertical_cylinder':parts=[p for p in obj.parts if p.intersects_vertical_column(centre[:2],radius)]
            else:raise UnsupportedMechanicError('Unsupported collider area shape')
            if parts and self.area_visible(centre,shape,parts,exclude=identity):recipients.append(identity)
        return recipients

    def _changed(self,entity_id,reason,*,body_changed=True):
        world=self.world
        self.sync();self.dirty=True
        if world.gravity_mode:
            for key,(_,_,payload) in list(world.gravity_deferred_contacts.items()):
                if payload.get('collider_id')==entity_id:del world.gravity_deferred_contacts[key]
        if body_changed and hasattr(world,'motion'):
            for actor in world.fighters.values():
                if actor.hp<=0:continue
                m=world.motion[actor.id]
                if world._climbing(actor.id) and m['climb']['target']==entity_id:
                    with actor.using_action(actor.body_action()):world.interrupt_combat_climb(actor,reason)
                else:
                    action=actor.body_action()
                    if action is not None and action.kind=='climb' and action.target==entity_id:
                        world.cancel_owned_action(actor,action,reason)
                if m.get('support_id')==entity_id and not world._airborne(actor.id) and not world._climbing(actor.id):
                    self._support_changed(actor,reason)
            world.refresh_mobile_locomotion()

    def _support_changed(self,actor,reason):
        if self.world.spatial_transitions.release_support(actor,reason):
            self.world.request_decision(actor.id,self.world.time)

    def find_support(self,actor):
        static=self.static_support(actor)
        if static is not None:return static
        support=getattr(self.world,'body_support',None)
        return support.find_support(actor) if support is not None and support.ready else None

    def static_support(self,actor):
        if self.world.terrain_support.enabled:
            return self.world.terrain_support.find_support(actor.id,self.world.world_bodies[actor.id])
        bottom=min(box.bounds[0][2] for box in self.world.world_bodies[actor.id])
        feet=[box for box in self.world.world_bodies[actor.id] if box.bounds[0][2]==bottom]
        for key,parts in sorted(self.registry.active('bodies',self.world.time).items()):
            for part in sorted(parts,key=lambda p:p.part):
                low,high=part.bounds
                if abs(dec(high[2])-dec(bottom))>D('1e-20'):continue
                if any(all(max(a,c)<min(b,d) for a,b,c,d in zip(box.bounds[0][:2],box.bounds[1][:2],low[:2],high[:2])) for box in feet):
                    return key,part.part
        return None

    def climb_target(self,entity_id):
        obj=self.registry.objects.get(entity_id)
        return obj if obj is not None and obj.active(self.world.time) and obj.climbable and obj.policy.bodies else None

    def flush(self):
        if not self.dirty or not self.world.mobile_mode:return
        self.dirty=False
        world=self.world
        shots=world.next_mobile_projectile_contacts(world.time)
        if shots is not None:
            for payload in shots[1]:world.push(shots[0],payload.get('projectile_event','impact'),payload)
        bodies=world.next_mobile_contacts(world.time)
        if bodies is not None:
            world.push(bodies[0],'movement_contact',world.mobile_contact_payload(bodies[1]),priority=2)

    def area_visible(self,centre,shape,parts,*,exclude=None):
        blockers=self.registry.active('areas',self.world.time)
        if not blockers:return True
        highest=max((as_fraction(p.bounds[1][2]) for boxes in (*self.registry.active().values(),*self.world.world_bodies.values()) for p in boxes),default=as_fraction(0))+1
        for part in parts:
            low,high=part.bounds
            witness=(closest_point(part,centre) if isinstance(part,OrientedCuboid) else
                tuple(min(b,max(a,as_fraction(c))) for a,b,c in zip(low,high,centre)))
            if shape=='vertical_cylinder':witness=(*witness[:2],high[2])
            origin=(witness[0],witness[1],highest) if shape=='vertical_cylinder' else centre
            if not any(segment_crosses_interior(origin,witness,wall) for key,walls in blockers.items()
                    if key!=exclude for wall in walls):return True
        return False

    def serialize(self,value):
        if isinstance(value,list):return [self.serialize(v) for v in value]
        if not isinstance(value,dict):return value
        if self.enabled:
            return {key:self.serialize(item) for key,item in value.items() if key!='motion_dependencies'}
        hidden={'collider_id','collider_revision'} if 'collider_revision' in value else set()
        hidden.add('motion_dependencies')
        if 'contacts' in value:hidden.add('collider_epoch')
        if 'first' in value and 'second' in value:hidden|={'support_part','support_body_part','support_reference_z_m'}
        return {key:self.serialize(item) for key,item in value.items() if key not in hidden}
