"""Basic jump actions and independently evolving airborne body motion."""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.airborne_geometry import first_downward_plane_contact,first_accelerated_plane_contact
from combat_sim.battle_models import BattleAction, ceil_ms, decimal_value as dec
from combat_sim.hitboxes import world_standing_cuboids
from combat_sim.character_geometry import actor_body
from combat_sim.mechanics.dyspnea import DyspneaContext, apply_action_dyspnea
from combat_sim.mechanics.jumping import jump_initial_speed_mps
from combat_sim.models import UnsupportedMechanicError
from combat_sim.command_dispatch import IntentOutcome
from combat_sim.spatial_motion import CONTACT_TIME_EPS_MS, contact_boundary_time

EPS = D('1e-24')


class AirborneCombatRules:
    def setup_mobile_combat(self, definition, effects):
        self.jump_actions_enabled = self.jump_input is not None
        world = effects.get('world') if effects else None
        self.world_ruleset = 'historical_optional_flight_v1' if world is None else world.get('ruleset')
        if world is not None and (self.world_ruleset!='integrated_v2' or set(world)!={'ruleset','gravity_mps2'}):
            raise UnsupportedMechanicError('Unsupported immutable combat world ruleset')
        self.airborne_enabled = world is not None or self.jump_actions_enabled
        if self.airborne_enabled:
            self.jump_gravity = dec(world['gravity_mps2'] if world is not None else self.jump_input['gravity_mps2'])
            if self.jump_gravity <= 0:
                raise ValueError('Body gravity must be positive')
            if self.gravity_mode and self.jump_gravity != self.physics['gravity_mps2']:
                raise ValueError('Body and projectile gravity must agree')
        if self.jump_actions_enabled:
            rules = self.jump_input
            expected = {'mode':'integrated_basic_jump', 'takeoff_timing':'start_of_active',
                'upward_speed_rule':'base_running_speed / 2', 'horizontal_velocity_rule':'retain_at_takeoff',
                'payment_timing':'active_start', 'hands':'retain_current_pose',
                'landing_effects':'self_and_physical_contact', 'air_control':'queued_until_landing',
                'airborne_recovery':'blocked'}
            if any(rules.get(k) != v for k,v in expected.items()):
                raise UnsupportedMechanicError('Unsupported combat jump definition')
            if dec(rules['gravity_mps2']) != self.jump_gravity:
                raise ValueError('Jump and body gravity must agree')
            for actor in self.fighters.values():
                p = rules['characters'].get(actor.profile_id)
                if p is None:
                    raise UnsupportedMechanicError('Missing basic jump profile')
                if (dec(p['gathering_ms']) < 0 or dec(p['active_ms']) <= 0 or
                        dec(p['active_ms']) != ceil_ms(dec(p['active_ms']))):
                    raise ValueError('Jump needs nonnegative Gathering and positive integer Active')
                if any(dec(p[k]) < 0 for k in ('self_disorientation_on_jump','self_instability_on_jump',
                        'self_disorientation_on_landing','self_instability_on_landing','listed_dyspnea_value')):
                    raise ValueError('Jump costs and statuses cannot be negative')
        super().setup_mobile_combat(definition,effects)
        if self.airborne_enabled:
            for m in self.motion.values():
                m['support_id'] = self.terrain_definition['ground']['id']

    def _airborne(self, name):
        return self.airborne_enabled and self.motion[name]['jump'] is not None and self.fighters[name].hp > 0

    def mobile_kinematics(self, name):
        if self._airborne(name):
            velocity = self.motion[name]['jump']['velocity']
            return sum(v*v for v in velocity[:2]).sqrt(), D(0)
        return super().mobile_kinematics(name)

    def mobile_motion(self, name):
        if self._airborne(name):
            return self.motion[name]['jump']['velocity'], (D(0),D(0),-self.jump_gravity)
        return super().mobile_motion(name)

    def mobile_dyspnea_context(self, actor):
        context=super().mobile_dyspnea_context(actor)
        if self._airborne(actor.id):
            return DyspneaContext('airborne',context.disoriented,context.unstable,
                context.on_grapple_ability,context.active,context.gathering,context.recovering)
        return context

    def resource_ready_time(self, actor, rule):
        if (self.mobile_mode and self._airborne(actor.id) and rule['kind']!='none' and
                not apply_action_dyspnea(actor.dyspnea,rule['base_value']).allowed):
            return D('Infinity')
        return super().resource_ready_time(actor,rule)

    def advance_mobile_geometry(self, begin, end):
        # Ground actors keep the existing path; temporarily restore airborne
        # z after it advances their xy with the overridden physical velocity.
        airborne = {name:(f.body_origin_m,self.motion[name]['jump']['velocity'])
                    for name,f in self.fighters.items() if self._airborne(name)}
        super().advance_mobile_geometry(begin,end)
        seconds = (end-begin)/1000
        for name,(origin,velocity) in airborne.items():
            actor = self.fighters[name]
            z = dec(origin[2])+velocity[2]*seconds-self.jump_gravity*seconds*seconds/2
            actor.body_origin_m = (*actor.position_m,z)
            self.motion[name]['jump']['velocity'] = (*velocity[:2],velocity[2]-self.jump_gravity*seconds)
            self.world_bodies[name] = world_standing_cuboids(actor_body(self,name),actor.body_origin_m,actor.facing)

    def refresh_mobile_locomotion(self):
        super().refresh_mobile_locomotion()
        if not self.airborne_enabled:
            return
        for name,actor in self.fighters.items():
            m = self.motion[name]
            airborne=self._airborne(name) or m.get('death_airborne',False)
            actor.locomotion.update(grounded=not airborne,
                height_above_ground_m=str(dec(actor.body_origin_m[2])+dec(actor_body(self,name)['standing_placement']['ground_z_m'])-
                    dec(self.scenario['encounter']['ground_z_m'])), support_id=None if airborne else m.get('support_id'))

    def try_jump_step(self,actor):
        m = self.motion[actor.id]
        profile = self.jump_input['characters'][actor.profile_id]
        ready = self.resource_ready_time(actor,{'kind':'action','base_value':profile['listed_dyspnea_value']})
        if ready > self.time:
            if ready.is_finite():
                self.request_decision(actor.id,ready)
            self.log('movement_waiting_for_capacity',actor=actor.id,action='jump',resume_at_ms=ready)
            return IntentOutcome.WAITING
        factor = D('1.2') if self.mobile_is_running(actor.id) else D(1)
        due = ceil_ms(self.time+dec(profile['gathering_ms'])*factor+actor.disorientation)
        action = BattleAction(next(self.action_ids),actor.id,actor.id,'jump','basic_jump',self.time,due,
            dec(profile['active_ms']),phase='gathering',base_gathering_ms=dec(profile['gathering_ms']))
        actor.current = action
        due = self.timed_gathering.commit(actor,action)
        self.log('jump_requested',actor=actor.id,action_id=action.id,active_start_ms=due,
            hands='retained; no authored jump hand movement')
        self._schedule_phase(action,'active_started',due)
        return IntentOutcome.STARTED

    def launch_body(self,actor,velocity,*,ground_drive_velocity=None,basic_jump=False,landing_effects=None,
                    motion_cause=None,contact_effects=None,allow_nonupward=False):
        """Launch one free body drive; linked motion projects it once afterward.

        This is voluntary takeoff, not an external spatial transaction: it must
        not cancel its own body action or acquire another action/effort owner.
        """
        if not self.airborne_enabled or actor.hp<=0:
            raise ValueError('Takeoff needs a living body in the gravity world')
        velocity=tuple(map(dec,velocity))
        if len(velocity)!=3 or not allow_nonupward and velocity[2]<=0:
            raise ValueError('Takeoff needs a three-component upward velocity')
        flight={'velocity':velocity,'basic_jump':basic_jump}
        previous=self.motion[actor.id].get('jump')
        if allow_nonupward and previous is not None:
            # A later voluntary launch cannot erase a jump/dash's already
            # incurred landing obligation. Native flight remains one writer.
            flight['basic_jump']=basic_jump or previous.get('basic_jump',False)
            if previous.get('landing_effects') is not None:flight['landing_effects']=previous['landing_effects']
            if previous.get('contact_obligations'):flight['contact_obligations']=previous['contact_obligations']
        if ground_drive_velocity is not None:flight['ground_drive_velocity']=tuple(ground_drive_velocity)
        if landing_effects is not None:flight['landing_effects']=landing_effects
        if motion_cause is not None:flight['motion_cause']=motion_cause
        if contact_effects is not None:
            flight['contact_obligations']=(*flight.get('contact_obligations',()),tuple(contact_effects))
        if any(self.motion[actor.id].get('distance_inertial_velocity',(0,0,0))):
            # Preserve the independent ground input across voluntary flight;
            # the airborne velocity itself is supplied by this launch.
            prior=self.free_mobile_motion(actor.id)[0]
            self.motion[actor.id]['imposed_velocity']=(*prior[:2],D(0))
        self.motion[actor.id].pop('distance_inertial_velocity',None)
        self.motion[actor.id].update(jump=flight,acceleration=D(0))

    def start_basic_jump(self, actor):
        action = actor.current
        profile = self.jump_input['characters'][actor.profile_id]
        payment = self.action_payment(actor,action,profile['listed_dyspnea_value'])
        if not payment.allowed:
            self.note_action_cancelled(actor,action,'active_start_capacity')
            actor.current=None
            self.queue_mobile_intent(actor,'jump',front=True)
            self.log('jump_deferred',actor=actor.id,reason='active_start_capacity')
            self.request_decision(actor.id,self.time)
            return
        horizontal = self.mobile_motion(actor.id)[0][:2]
        up = dec(jump_initial_speed_mps(self.movement_definition['characters'][actor.profile_id]['running_speed_mps']))
        actor.dyspnea = dec(payment.after)
        actor.metrics['dyspnea_paid'] += dec(payment.action_value)
        factor = dec(self.combat_locomotion_definition['running_self_effect_multiplier']) if self.mobile_is_running(actor.id) else D(1)
        additions = {k:dec(profile['self_'+k+'_on_jump'])*factor for k in ('disorientation','instability')}
        for key,value in additions.items():
            setattr(actor,key,getattr(actor,key)+value)
        cap_disorientation=D(0)
        if payment.reached_maximum:
            extra = dec(payment.disorientation_trigger)*factor
            cap_disorientation=extra
            actor.disorientation += extra
            self.log('maximum_dyspnea_trigger',actor=actor.id,added_disorientation=extra,source='jump')
        m = self.motion[actor.id]
        # Ground drive and ballistic velocity are different state. Airborne
        # instability changes neither; it is applied when ground drive resumes.
        drive = tuple(v*m['speed'] for v in m['direction'])+(D(0),)
        self.launch_body(actor,(*horizontal,up),ground_drive_velocity=drive,basic_jump=True)
        action.phase='active'
        action.active_end_ms=self.time+action.active_ms
        self.extend_parallel_gatherings(actor,additions['disorientation']+cap_disorientation,action.id)
        actor.metrics['jumps_started'] += 1
        self.refresh_mobile_locomotion()
        self.log('dyspnea_paid',actor=actor.id,ability='jump',action_id=action.id,action_kind='basic_jump',
            phase='active_start',before=dec(payment.before),amount=dec(payment.action_value),after=actor.dyspnea)
        self.log('jump_takeoff',actor=actor.id,action_id=action.id,velocity_mps=(*horizontal,up),
            self_effects=additions,active_end_ms=action.active_end_ms)
        self._schedule_phase(action,'active_completed',action.active_end_ms)

    def complete_basic_jump(self, actor):
        action_id = actor.current.id
        actor.current=None
        self.log('jump_active_completed',actor=actor.id,action_id=action_id,airborne=self._airborne(actor.id))
        self.request_decision(actor.id,self.time)

    def process_mobile_event(self, kind, payload):
        if kind=='movement_sprint_exhausted' and self._airborne(payload['actor']):
            # An incidental collision can lift a sprinter. End the sprint effort
            # at its cap, but ground braking waits until actual landing.
            m=self.motion[payload['actor']]
            m['mode']='running'
            self.queue_mobile_intent(self.fighters[payload['actor']],'stop',front=True)
        return super().process_mobile_event(kind,payload)

    def next_mobile_contacts(self, end):
        original = super().next_mobile_contacts(end)
        if not self.airborne_enabled or self.terrain_support.finite_ground:
            return original
        contacts = [] if original is None else [(original[0],c) for c in original[1]]
        floor = self.terrain_definition['ground']['id']
        plane = dec(self.terrain_colliders[floor][0].bounds[1][2])
        for name,actor in self.fighters.items():
            local_bottom=dec(actor_body(self,name)['standing_placement']['ground_z_m'])
            frame=self.body_paths.frame if hasattr(self,'body_paths') else None
            constrained=frame is not None and frame.constraints is not None and name in frame.constraints.names
            if not self._airborne(name) and not constrained:
                continue
            height = dec(actor.body_origin_m[2])+(actor.pose_drop_m or D(0))/2+local_bottom-plane
            velocity,acceleration = self.mobile_motion(name)
            contact = (first_accelerated_plane_contact(height,velocity[2],acceleration[2],
                (end-self.time+CONTACT_TIME_EPS_MS)/1000) if constrained else
                first_downward_plane_contact(height,velocity[2],self.jump_gravity,
                (end-self.time+CONTACT_TIME_EPS_MS)/1000))
            if contact is not None:
                contacts.append((contact_boundary_time(self.time+contact*1000,end),
                    {'first':name,'second':floor,'normals':[(D(0),D(0),D(1))]}))
        if not contacts:
            return None
        first = min(t for t,_ in contacts)
        return first,[c for t,c in contacts if abs(t-first)<=EPS]

    def constrain_mobile_support(self, actor, velocity, basis):
        imposed=self.motion[actor.id].get('imposed_velocity')
        if imposed is not None:
            for normal in basis:
                dot=sum(v*n for v,n in zip(imposed,normal))
                imposed=tuple(v-dot*n for v,n in zip(imposed,normal))
            self.motion[actor.id]['imposed_velocity']=(*imposed[:2],D(0))
        if self._airborne(actor.id):
            flight = self.motion[actor.id]['jump']
            if 'ground_drive_velocity' in flight:
                drive = flight['ground_drive_velocity']
                for normal in basis:
                    dot = sum(v*n for v,n in zip(drive,normal))
                    drive = tuple(v-dot*n for v,n in zip(drive,normal))
                flight['ground_drive_velocity'] = tuple(D(0) if abs(v)<EPS else v for v in drive)
        if not self.airborne_enabled or self._airborne(actor.id) or velocity[2] >= 0:
            return velocity
        # A grounded actor cannot acquire downward travel through its support.
        # Add the plane to the existing orthogonal constraints, preserving the
        # centre-line and solid-face response instead of merely truncating vz.
        direction=(D(0),D(0),D(1))
        for normal in basis:
            dot=sum(v*n for v,n in zip(direction,normal))
            direction=tuple(v-dot*n for v,n in zip(direction,normal))
        length=sum(v*v for v in direction).sqrt()
        if length > EPS:
            direction=tuple(v/length for v in direction)
            dot=sum(v*n for v,n in zip(velocity,direction))
            velocity=tuple(v-dot*n for v,n in zip(velocity,direction))
        return (*velocity[:2],D(0))

    def apply_air_contact_velocity(self, actor, velocity, contacts):
        """Consume a full 3D collision response; return extra landing self effects."""
        if not self.airborne_enabled:
            return None
        velocity=tuple(D(0) if abs(v)<EPS else v for v in velocity)
        m = self.motion[actor.id]
        airborne = self._airborne(actor.id)
        if not airborne and velocity[2] <= EPS:
            return None
        extra = {'disorientation':D(0),'instability':D(0)}
        obligations=m['jump'].get('contact_obligations',()) if airborne else ()
        group=self.grapple_links.group(actor.id)
        if obligations and any(not c.get('pose_only',False) and
                (c['first'] in group or c['second'] in group) for c in contacts):
            m['jump'].pop('contact_obligations')
            for owed in obligations:
                if owed[0]!=actor.life_generation:continue
                factor=dec(self.combat_locomotion_definition['running_self_effect_multiplier']) if self.mobile_is_running(actor.id) else D(1)
                additions=dict(zip(extra,(v*factor for v in owed[3:])))
                extra={k:extra[k]+additions[k] for k in extra}
                self.log('body_launch_contact',actor=actor.id,ability=owed[1],action_id=owed[2],
                    life_generation=owed[0],self_effects=additions)
        support = None
        support_contact=None
        for c in contacts:
            if c['first']==actor.id and any(n[2]>0 for n in c['normals']):
                support = c['second']
                support_contact=c
            elif c['second']==actor.id and any(n[2]<0 for n in c['normals']):
                support = c['first']
        if support is not None and abs(velocity[2])<=EPS:
            dynamic=support in self.fighters
            if dynamic and not self.body_support.ready:
                raise UnsupportedMechanicError('Standing on another moving body requires dynamic support tracking')
            witness=self.body_support.witness(actor.id,support) if dynamic else None
            if dynamic and (witness is None or not self.body_support.rooted(support)):
                flight=dict(m['jump']) if airborne else {'basic_jump':False}
                flight['velocity']=tuple(velocity);m.update(jump=flight,acceleration=D(0),phase=None)
                return extra
            was_jump = m['jump']['basic_jump'] if airborne else False
            landing_effects=m['jump'].get('landing_effects') if airborne else None
            factor = dec(self.combat_locomotion_definition['running_self_effect_multiplier']) if self.mobile_is_running(actor.id) else D(1)
            # A real descending top-face contact establishes exact support,
            # including cube tops. Do not retain a root-rounding penetration.
            parts=self.world_bodies[support] if dynamic else self.terrain_colliders[support]
            if dynamic:
                upper=next(p for p in self.world_bodies[actor.id] if p.part==witness.upper_part)
                lower=next(p for p in parts if p.part==witness.lower_part)
                z=dec(self.motion[actor.id]['body_reference_z'])+dec(lower.bounds[1][2]-upper.bounds[0][2])
                part=witness.lower_part
            else:
                z=(support_contact['support_reference_z_m'] if (len(parts)>1 or self.terrain_support.enabled) and support_contact is not None
                and 'support_reference_z_m' in support_contact else
                dec(parts[0].bounds[1][2])-dec(actor_body(self,actor.id)['standing_placement']['ground_z_m']))
                part=support_contact.get('support_part',parts[0].part) if support_contact else parts[0].part
            actor.body_origin_m=(*actor.position_m,z)
            self.world_bodies[actor.id]=world_standing_cuboids(actor_body(self,actor.id),actor.body_origin_m,actor.facing)
            # Ballistic velocity has not had U subtracted. Adding U here would
            # turn an airborne debuff into permanent ground propulsion.
            retained_nominal=airborne and 'ground_drive_velocity' in m['jump']
            drive = m['jump'].get('ground_drive_velocity',velocity) if airborne else velocity
            speed = sum(v*v for v in drive[:2]).sqrt()
            if speed:
                m['direction']=tuple(v/speed for v in drive[:2])
            m.update(jump=None,ground_origin_z=dec(actor.body_origin_m[2]),support_id=support,
                support_part=part,
                speed=speed if retained_nominal else speed/self.ground_speed_multiplier(actor.id),acceleration=D(0))
            if not speed:
                m['mode']='standing'
            if was_jump:
                profile=self.jump_input['characters'][actor.profile_id]
                extra={k:extra[k]+dec(profile['self_'+k+'_on_landing'])*factor for k in extra}
            elif landing_effects is not None and landing_effects[0]==actor.life_generation:
                extra={k:extra[k]+v*factor for k,v in zip(('disorientation','instability'),landing_effects[3:])}
                self.log('body_launch_landed',actor=actor.id,ability=landing_effects[1],action_id=landing_effects[2],
                    life_generation=landing_effects[0],support_id=support,body_origin_m=actor.body_origin_m,self_effects=extra)
            actor.metrics['landings'] += 1
            self.log('jump_landed',actor=actor.id,support_id=support,velocity_after_contact_mps=velocity,
                self_effects=extra,physical_contact_statuses='applied separately from the shared pre-contact snapshot')
            self.request_decision(actor.id,self.time)
        else:
            if not airborne and actor.current is not None and actor.current.kind=='locomotion':
                self.log('movement_active_cancelled',actor=actor.id,action_id=actor.current.id,reason='airborne_collision')
                self.note_action_cancelled(actor,actor.current,'airborne_collision')
                actor.current=None
                self.request_decision(actor.id,self.time)
            flight = dict(m['jump']) if airborne else {'basic_jump':False}
            flight['velocity'] = tuple(velocity)
            m.update(jump=flight,
                acceleration=D(0),phase=None)
        return extra

    def cancel_mobile_motion(self, actor):
        if self.airborne_enabled and actor.id in self.motion:
            m=self.motion[actor.id]
            m.update(death_airborne=m['jump'] is not None,jump=None,ground_origin_z=dec(actor.body_origin_m[2]))
        super().cancel_mobile_motion(actor)

    def validate_movement_scene(self):
        super().validate_movement_scene()
        if not self.airborne_enabled or self.terrain_support.enabled:
            return
        floor=self.terrain_definition['ground']['id']
        for name,actor in self.fighters.items():
            m=self.motion[name]
            support=m.get('support_id',floor)
            if actor.hp <= 0 or self._airborne(name) or m.get('climb') is not None or support==floor:
                continue
            if support in self.fighters and self.body_support.ready:continue
            parts=self.terrain_colliders[support]
            part=next((p for p in parts if p.part==m.get('support_part')),parts[0])
            low,high=part.bounds
            if any(any(a[i]<low[i] or b[i]>high[i] for i in (0,1))
                   for a,b in (box.bounds for box in self.world_bodies[name])):
                raise UnsupportedMechanicError('Raised-support departure requires ledge/fall integration')

    def validate_climb_support(self):
        # The geometry-only guard has no flight/removable-support lifecycle.
        # Integrated combat validates grounded support above, after this call.
        if not self.mobile_mode:return super().validate_climb_support()

    def mobile_result(self):
        result=super().mobile_result()
        if self.world_ruleset!='historical_optional_flight_v1':
            result['world_ruleset']={'id':self.world_ruleset,'gravity_mps2':str(self.jump_gravity)}
        if self.jump_actions_enabled:
            result['jump_definition']=deepcopy(self.jump_input)
            result['movement_combat_scope']['actions'].append('jump')
        if self.airborne_enabled:
            result['movement_combat_scope']['kind']='upright_ground_and_airborne_combat'
        return result
