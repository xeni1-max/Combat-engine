"""Fixed-body collision rules for the shared stationary encounter.

Bodies can disappear on death but do not move or rotate. Released trajectories
therefore retain ordered candidate contacts and skip recipients that die in
flight. Explicit terrain profiles add static colliders. Gravity and arbitrary
projectile lifetimes are not inferred.
"""
from decimal import Decimal as D
from fractions import Fraction

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import local_to_world_point, standing_cuboids, world_standing_cuboids
from combat_sim.mechanics.timing import impact_time_from_activation
from combat_sim.models import UnsupportedMechanicError, as_fraction
from combat_sim.terrain import terrain_colliders
from combat_sim.postures import pose_local_hand_position
from combat_sim.pose_kinematics import world_hand_point
from combat_sim.projectile_entities import ProjectileContactPolicy
from combat_sim.collider_world import SharedColliders
from combat_sim.character_geometry import profile_scale,scaled_definition
from combat_sim.facing import parse as parse_facing,record as facing_record
from combat_sim.oriented_geometry import OrientedCuboid


class BodyCollisionRules:
    def projectile_aim_point(self,action):
        # Scripted part choice pins an intent; native contact still determines
        # the receiver and damage. Default torso behavior remains unchanged.
        if getattr(action,'target_snapshot',None) is not None:
            return tuple(action.aim_location_m)
        part=getattr(action,'aim_part',None) or 'torso'
        return next(box.centre_m for box in self.world_bodies[action.target] if box.part==part)

    def setup_terrain_geometry(self, definition):
        if definition is None:
            raise UnsupportedMechanicError('Terrain collision scope requires an explicit terrain definition')
        if definition['id'] != self.scenario.get('terrain_profile'):
            raise ValueError('Scenario terrain profile must match the supplied definition')
        self.terrain_colliders = terrain_colliders(definition)
        if set(self.terrain_colliders) & set(self.fighters):
            raise ValueError('Terrain and character identities must be distinct')
        ground = self.terrain_colliders[definition['ground']['id']][0]
        if dec(ground.bounds[0][2]) != dec(self.scenario['encounter']['ground_z_m']):
            raise ValueError('Character placement datum must match the collidable ground')
        for actor in self.fighters.values():
            actor.metrics['terrain_contacts'] = 0
        rules=self.combat_locomotion_input.get('world_colliders') if self.combat_locomotion_input else None
        self.collider_system=SharedColliders(self,rules)
        if self.effect_system.enabled:
            self.collider_system.scope.update(attacks='slash_projectile_and_heat_beam',ongoing_effects='typed_spatial_heat_and_bleeding')
        if self.effort_system.enabled:
            self.collider_system.scope.update(attacks='gun_qard_heat_and_cooldown_pause',effort_response='phase_effort_v1')
        self.collider_system.import_terrain(definition,self.terrain_colliders)
        self.collider_system.load_initial(self.scenario.get('initial_colliders',[]))

    def body_terrain_colliders(self):
        return self.collider_system.registry.active('bodies',self.time) if self.terrain_mode else {}

    def setup_body_geometry(self, definition, ground_z):
        if definition is None:
            raise UnsupportedMechanicError('Body collision scope requires an explicit body definition')
        if (definition['units'] != 'metres' or definition['pose_behavior'] != 'fixed_standing' or
            definition['local_axes'] != {'x':'right','y':'forward','z':'up'}):
            raise UnsupportedMechanicError('Only the confirmed fixed standing body is supported')
        standing_cuboids(definition)
        self.world_bodies = {}
        self.actor_body_definitions={};self.actor_body_scales={}
        for name,actor in self.fighters.items():
            scale=profile_scale(definition,actor.profile)
            body=scaled_definition(definition,scale)
            self.actor_body_scales[name]=scale;self.actor_body_definitions[name]=body
            height=ground_z-dec(body['standing_placement']['ground_z_m'])
            facing = self.scenario['encounter']['participants'][name].get('facing')
            if facing not in ('+x','-x'):
                if not self.mobile_mode or not self.terrain_support.finite_ground:
                    raise UnsupportedMechanicError('General fixed actor facing requires current finite-face mobile combat')
                facing=parse_facing(facing,precision=self.precision)
            actor.facing = facing
            actor.body_origin_m = (*actor.position_m,height)
            self.world_bodies[name] = world_standing_cuboids(body,actor.body_origin_m,facing)
            if self.equilibrium.enabled:
                self.world_bodies[name]=self.equilibrium.initial_body(name,actor.body_origin_m,facing)

    def body_area_recipients(self, centre, radius, shape, *, occlusion='world'):
        if occlusion not in ('world','none'):
            raise UnsupportedMechanicError('Unknown body-area occlusion policy')
        recipients = []
        for name,actor in self.fighters.items():
            if actor.hp <= 0:
                continue
            if shape == 'sphere':
                parts=[box for box in self.world_bodies[name] if box.intersects_sphere(centre,radius)]
            elif shape == 'vertical_cylinder':
                parts=[box for box in self.world_bodies[name] if box.intersects_vertical_column(centre[:2],radius)]
            else:
                raise UnsupportedMechanicError(f'Unsupported body-area shape: {shape}')
            if parts and (occlusion=='none' or not self.terrain_mode or self.collider_system.area_visible(centre,shape,parts)):
                recipients.append(name)
        return recipients

    def release_body_projectile(self, actor, action, ability, timing):
        policy=ProjectileContactPolicy.from_definition(ability['projectile_geometry'].get('contact_policy'))
        if policy!=ProjectileContactPolicy():
            raise UnsupportedMechanicError('Non-default projectile contact policy requires moving combat')
        geometry = ability['projectile_geometry']
        if (geometry['shape'] != 'sphere' or geometry['aim'] != 'torso_centre' or
            geometry['origin'] != 'ability_start_hand'):
            raise UnsupportedMechanicError('Only authored sphere projectiles aimed at torso centre are supported')
        radius = as_fraction(geometry['radius_m'])
        if radius < 0:
            raise ValueError('Projectile radius must be nonnegative')
        hand = geometry['origin_hand']
        if hand not in ability['hand_positions_m']['start']:
            raise UnsupportedMechanicError('Projectile origin hand lacks an authored starting pose')
        hand_origin = ability['hand_positions_m']['start'][hand]
        origin=world_hand_point(self,actor,hand_origin)
        aim = self.projectile_aim_point(action)
        direction = tuple(b-a for a,b in zip(origin,aim))
        if not any(direction):
            raise UnsupportedMechanicError('Coincident projectile origin/aim needs an authored direction rule')
        # Search past every supplied body without inventing a weapon range.
        # This is a geometric bound on a fixed layout, not projectile lifetime.
        scale = Fraction(1)
        groups = list(self.world_bodies.items())
        if self.terrain_mode:
            groups.extend(self.terrain_colliders.items())
        for _,boxes in groups:
            for box in boxes:
                for bounds in box.bounds:
                    for bound,a,d in zip(bounds,origin,direction):
                        if d:
                            scale = max(scale,1+(abs(bound-a)+radius)/abs(d))
        end = tuple(a+scale*d for a,d in zip(origin,direction))
        length_squared = sum(((b-a)**2 for a,b in zip(origin,end)),Fraction(0))
        length = dec(length_squared).sqrt()
        candidates = []
        tolerance = D(10)**(-(self.precision-10))
        for name,boxes in groups:
            static = self.terrain_mode and name in self.terrain_colliders
            if not static and (name == actor.id or self.fighters[name].hp <= 0):
                continue
            contacts = [contact for box in boxes
                        if (contact := box.swept_sphere_contact(origin,end,radius,precision=self.precision)) is not None]
            if not contacts:
                continue
            first = min(contacts,key=lambda c:c.parameter)
            distance = first.parameter*length
            arrival,calculation = impact_time_from_activation(int(self.time),timing,distance)
            parts = sorted(c.part for c in contacts if abs((c.parameter-first.parameter)*length) <= tolerance)
            candidate = {'target':name,'distance_m':distance,'impact_time_ms':D(arrival),
                         'location_m':first.closest_box_point_m,'projectile_centre_m':first.centre_m,
                         'hit_parts':parts,'travel_calculation':calculation}
            if self.terrain_mode:
                candidate['collision_kind'] = 'terrain' if static else 'body'
            candidates.append(candidate)
        candidates.sort(key=lambda c:c['distance_m'])
        for a,b in zip(candidates,candidates[1:]):
            if abs(a['distance_m']-b['distance_m']) <= tolerance:
                if self.terrain_mode:
                    raise UnsupportedMechanicError('Simultaneous contact with different scene objects needs a collision-priority rule')
                raise UnsupportedMechanicError('Simultaneous contact with different bodies needs a collision-priority rule')
        flight = self.projectile_system.create(actor,action,ability,{'aim_target':action.target,
                  'released_at_ms':self.time,'origin_m':tuple(map(dec,origin)),
                  'aim_point_m':tuple(map(dec,aim)),'radius_m':dec(radius),'candidates':candidates,
                  'next_candidate':0,'status':'in_flight'})
        if candidates:
            p = self.body_projectile_payload(flight,0)
            self.push(p['impact_time_ms'],'impact',p)
        else:
            self.body_projectile_unhit(flight)
        self.log('projectile_released',actor=actor.id,target=action.target,aim_target=action.target,
                 ability=action.ability_id,action_id=action.id,projectile_id=flight['id'],
                 origin_m=flight['origin_m'],aim_point_m=flight['aim_point_m'],radius_m=flight['radius_m'],
                 scheduled_collision_target=candidates[0]['target'] if candidates else None,
                 impact_time_ms=candidates[0]['impact_time_ms'] if candidates else None,
                 weapon_ready_at_ms=actor.ready[action.ability_id],ammo=actor.ammo.get(action.ability_id),
                 travel_calculation=candidates[0]['travel_calculation'] if candidates else None)

    def body_projectile_payload(self, flight, index):
        return {**flight['candidates'][index],**self.projectiles.link(flight),'aim_target':flight['aim_target'],
                'candidate_index':index,'radius_m':flight['radius_m'],'component':'projectile'}

    def body_projectile_unhit(self, flight):
        flight['status'] = 'no_scene_contact_pending' if self.terrain_mode else 'no_live_body_contact_pending'
        self.log('projectile_without_scene_contact' if self.terrain_mode else 'projectile_without_body_contact',
                 actor=flight['actor'],ability=flight['ability'],
                 projectile_id=flight['id'],aim_target=flight['aim_target'],
                 creates_mark=False,
                 trajectory=('Original straight path; finite ground/cubes, open boundaries, no gravity'
                             if self.terrain_mode else 'Original straight path; no gravity or terrain collision modeled'))

    def live_body_projectile_payload(self, p):
        if not self.projectiles.live(p):
            return None
        flight = self.projectile_flights[p['projectile_id']]
        index = p['candidate_index']
        while (flight['candidates'][index].get('collision_kind','body') == 'body' and
               self.fighters[flight['candidates'][index]['target']].hp <= 0):
            self.log('projectile_skipped_dead_body',actor=flight['actor'],projectile_id=flight['id'],
                     target=flight['candidates'][index]['target'])
            index += 1
            if index >= len(flight['candidates']):
                self.body_projectile_unhit(flight)
                return None
        flight['next_candidate'] = index
        payload = self.body_projectile_payload(flight,index)
        if payload['impact_time_ms'] > self.time:
            self.push(payload['impact_time_ms'],'impact',payload)
            return None
        self.projectiles.terminal(flight,'collided',collided_at_ms=self.time,collision_target=payload['target'],
                      collision_location_m=payload['location_m'])
        static = payload.get('collision_kind') == 'terrain'
        if self.terrain_mode:
            flight['collision_kind'] = payload['collision_kind']
        if static:
            self.fighters[flight['actor']].metrics['terrain_contacts'] += 1
        self.log('projectile_terrain_collision' if static else 'projectile_body_collision',**payload)
        return payload

    def body_result(self):
        return {'body_definition':self.body_definition,
                **({'character_geometry':{'mode':'profile_scale_v1','actors':{
                    name:{'profile':actor.profile_id,'scale_xyz':tuple(map(dec,self.actor_body_scales[name])),
                        'standing_size_xyz_m':tuple(map(dec,self.actor_body_definitions[name]['standing_placement']['combined_size_xyz_m'])),
                        'standing_ground_offset_m':dec(self.actor_body_definitions[name]['standing_placement']['ground_z_m']),
                        'placement_status':self.actor_body_definitions[name]['standing_placement']['status'],
                        'source':actor.profile.get('body_scale_source','Reference size; no authored relative scale supplied')}
                    for name,actor in self.fighters.items()}}} if self.body_definition.get('character_geometry') else {}),
                'body_geometry':{name:{'origin_m':tuple(map(dec,actor.body_origin_m)),
                                       'facing':facing_record(actor.facing),
                                       'parts':[{'part':box.part,'centre_m':tuple(map(dec,box.centre_m)),
                                                 'size_m':tuple(map(dec,box.size_m)),
                                                 **({'shape':'oriented_cuboid','yaw_frame':box.frame.record()} if isinstance(box,OrientedCuboid) else {})}
                                                for box in self.world_bodies[name]]}
                                 for name,actor in self.fighters.items()},
                'projectile_flights':list(self.projectile_flights.values()),
                'pending_projectiles':[flight for flight in self.projectile_flights.values()
                                       if flight['status'] != 'collided'],
                **({'terrain_definition':self.terrain_definition,
                    'terrain_geometry':{name:{'minimum_m':tuple(map(dec,boxes[0].bounds[0])),
                                              'maximum_m':tuple(map(dec,boxes[0].bounds[1]))}
                                        for name,boxes in self.terrain_colliders.items()
                                        if self.collider_system.registry.objects[name].identity.kind=='terrain'},
                    **({'world_collider_rules':self.combat_locomotion_input['world_colliders'],
                        'initial_world_collider_states':self.collider_system.initial,
                        'world_collider_states':self.collider_system.registry.record()}
                       if self.collider_system.enabled else {})}
                   if self.terrain_mode else {})}
