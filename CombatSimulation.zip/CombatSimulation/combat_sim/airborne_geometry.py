"""Pure vertical flight geometry; support footprints and collision effects are callers' rules."""
from decimal import Decimal, InvalidOperation
from fractions import Fraction


HEIGHT_ROUNDOFF_TOLERANCE_M = Decimal('1e-25')


def _finite_decimal(value, name):
    try:
        result = (Decimal(value.numerator) / Decimal(value.denominator)
                  if isinstance(value, Fraction) else Decimal(str(value)))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError(f'{name} must be a finite number') from exc
    if not result.is_finite():
        raise ValueError(f'{name} must be finite')
    return result


def first_downward_plane_contact(height_m, vertical_velocity_mps, gravity_mps2,
                                 duration_s) -> Decimal | None:
    """Return the first descending plane contact within a closed time horizon.

    Height is the body's lowest face above the plane, velocity is positive up,
    and gravity is a positive downward magnitude. Flight follows
    ``height + velocity * t - gravity * t**2 / 2``. A body on the plane and
    resting or descending contacts at zero; upward takeoff ignores that root.
    Small negative heights down to -1e-25 m are clamped to zero solely for
    arithmetic roundoff. Larger penetration is an invalid starting state.

    The rationalized root for downward initial velocity avoids cancellation
    when the downward speed is large compared with the remaining fall height.
    All calculations use Decimal arithmetic in the caller's current context.
    The caller must separately check the finite support's horizontal footprint.
    """
    height = _finite_decimal(height_m, 'Height')
    velocity = _finite_decimal(vertical_velocity_mps, 'Vertical velocity')
    gravity = _finite_decimal(gravity_mps2, 'Gravity')
    duration = _finite_decimal(duration_s, 'Duration')
    if gravity <= 0:
        raise ValueError('Gravity must be positive')
    if duration < 0:
        raise ValueError('Duration must be nonnegative')
    if height < -HEIGHT_ROUNDOFF_TOLERANCE_M:
        raise ValueError('Height must not start below the contact plane')
    height = max(Decimal(0), height)
    if height == 0 and velocity <= 0:
        return Decimal(0)
    if duration == 0:
        return None
    speed_at_contact = (velocity * velocity + 2 * gravity * height).sqrt()
    if velocity < 0:
        contact = 2 * height / (speed_at_contact - velocity)
    else:
        contact = (velocity + speed_at_contact) / gravity
    return contact if contact <= duration else None


def first_accelerated_plane_contact(height_m,vertical_velocity_mps,acceleration_mps2,duration_s):
    """First closing contact of an arbitrary quadratic vertical path."""
    height=_finite_decimal(height_m,'Height');velocity=_finite_decimal(vertical_velocity_mps,'Vertical velocity')
    acceleration=_finite_decimal(acceleration_mps2,'Vertical acceleration');duration=_finite_decimal(duration_s,'Duration')
    if duration<0 or height < -HEIGHT_ROUNDOFF_TOLERANCE_M:raise ValueError('Invalid plane-contact interval or initial height')
    height=max(Decimal(0),height)
    if height==0 and (velocity<0 or velocity==0 and acceleration<0):return Decimal(0)
    if not acceleration:
        contact=-height/velocity if velocity<0 else None
        return contact if contact is not None and 0<=contact<=duration else None
    discriminant=velocity*velocity-2*acceleration*height
    if discriminant<0:return None
    root=discriminant.sqrt();q=-(velocity+(root if velocity>=0 else -root))/2
    candidates=(2*q/acceleration,height/q) if q else (Decimal(0),)
    closing=[t for t in candidates if 0<=t<=duration and velocity+acceleration*t<0]
    return min(closing) if closing else None
