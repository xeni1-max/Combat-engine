"""Shared status application and continuous decay log entries."""

from decimal import Decimal

from combat_sim.mechanics.status import add_status, apply_self_status, decay_status, mitigate_status
from combat_sim.models import as_fraction, fraction_record
from combat_sim.state_updates import _time_value


def _advance_statuses(states, start, end, log):
    if start == end:
        return
    for name, state in sorted(states.items()):
        before = state.statuses.to_record()
        state.statuses.disorientation = decay_status(state.statuses.disorientation, end - start)
        state.statuses.instability = decay_status(state.statuses.instability, end - start)
        after = state.statuses.to_record()
        if any(Decimal(before[key]["decimal"]) != Decimal(after[key]["decimal"]) for key in before):
            log.record({
                "time_ms": _time_value(end), "type": "status_decay_interval", "target": name,
                "interval_start_ms": _time_value(start), "interval_end_ms": _time_value(end),
                "rate_points_per_ms": 1, "before": before, "after": after,
                "source": "Collision details.odt, O(t)=Ok-t and U(t)=Uk-t; zero floor confirmed by user",
            })


def _apply_effects(name, state, profile, effects, time, origin, log, *, armor_snapshot=None):
    mitigation_armor = state.armor if armor_snapshot is None else as_fraction(armor_snapshot)
    for kind in ("disorientation", "instability"):
        incoming = as_fraction(effects[kind])
        current = getattr(state.statuses, kind)
        resistance = as_fraction(profile["status_resistance"])
        is_self = origin == "self"
        increment = (apply_self_status(0, incoming) if is_self else
                     mitigate_status(incoming, profile["max_hp"], mitigation_armor, resistance))
        after = add_status(current, increment)
        setattr(state.statuses, kind, after)
        log.record({
            "time_ms": time, "type": "status_applied", "target": name,
            "status": kind, "origin": origin,
            "formula": ("N * running_multiplier, then add to existing status; self effects bypass mitigation" if is_self else
                        "max(0, N - (H/500 + a/10)^1.1 - R), then add to existing status"),
            "inputs": {
                "N": fraction_record(incoming),
                **({} if is_self else {"H": str(profile["max_hp"]), "a": str(mitigation_armor), "R": str(resistance)}),
            },
            "listed_incoming": fraction_record(incoming),
            "running_modifier": 1,
            "mitigation_applied": not is_self,
            "applied_increment": {"decimal": str(increment)},
            **({} if is_self else {"after_mitigation": {"decimal": str(increment)}}),
            "before": {"decimal": str(current)}, "after": {"decimal": str(after)},
            "precision_digits": 40,
            "sources": {
                "effect": effects["source"],
                "formula": ("Author override: self disorientation/instability bypass all mitigation; running +20% remains" if is_self else
                            "Collision details.odt, resistance formula"),
            },
        })


