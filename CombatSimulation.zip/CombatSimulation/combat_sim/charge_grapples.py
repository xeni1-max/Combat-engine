"""3E5's existing charge through shared owned contact, holds and wall material."""
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import UnsupportedMechanicError


class ChargeGrapples:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.casts={};self.intents={};self.slams=[];self.hand_fractures=[]
        if self.enabled and (definition!={'mode':'owned_charge_grapple_v1'} or not all((world.mobile_mode,
                world.body_paths.enabled,world.grapple_casts.enabled,world.contact_signals.enabled))):
            raise UnsupportedMechanicError('Charge grapple requires current contacts, paths and owned holds')

    def validate(self,actor,ability_id):
        if not self.enabled:raise UnsupportedMechanicError('Charge grapple is disabled')
        a=actor.profile['abilities'][ability_id];g=a.get('grab_geometry',{})
        cfg=(self.world.ownership_definition or {}).get('actions',{}).get('charge_grab')
        if cfg!={'occupies':['locomotion','hands','weapon'],'requires':['lower_body','upper_body','attack']}:
            raise ValueError('Charge needs its actual motor, hand and weapon requirements')
        if (a.get('effort_phase')!='grab' or a.get('holding_effort_phase')!='holding' or
                a.get('holding_damage_type')!='constriction_tear' or a.get('damage_type')!='contact' or
                dec(a.get('pre_mitigation_damage',-1))!=0 or a.get('cooldown_anchor')!='active_start' or
                a.get('dyspnea',{}).get('payment_timing')!='active_start' or
                a.get('self_effects',{}).get('application_timing')!='impact' or
                g.get('mode')!='body_part_box' or g.get('anchor_part')!='torso' or
                a.get('melee_geometry',{}).get('origin_hand')!='left' or
                actor.profile['timing_profiles'][a['timing_profile']].get('impact_timing')!='contact_event'):
            raise ValueError('Unsupported charge profile or contact geometry')
        for key in ('charge_duration_ms','charge_movement_speed_multiplier','hold_duration_ms',
                'holding_damage_per_second','cooldown_ms'):
            if not dec(a[key]).is_finite() or dec(a[key])<=0:raise ValueError('Charge values must be positive and finite')
        if dec(a['holding_base_dyspnea'])<0 or any(dec(x)<=0 for x in g['size_xyz_m']):raise ValueError('Invalid charge effort/volume')
        if set(a['hand_positions_m']['start'])!={'left'} or set(a['hand_positions_m']['end'])!={'left'}:
            raise ValueError('Charge uses the declared left hand')
        self.world.owned_contacts.validate_geometry(actor,g)

    def available(self,actor):
        w=self.world
        return not (w._airborne(actor.id) or w._climbing(actor.id) or actor.knocked_down) and w.collider_system.find_support(actor) is not None

    def start(self,actor):
        w=self.world;action=actor.current;a=w.action_definition(actor,action)
        if not self.available(actor):return w.cancel_owned_action(actor,action,'charge_requires_support')
        if not w.pay_team_dyspnea(actor,'active_start'):return
        grab_active=action.active_ms
        action.phase='active';action.active_ms=dec(a['charge_duration_ms']);action.active_end_ms=w.time+action.active_ms
        action.authored_grab_active_ms=grab_active;action.active_subphase='search';action.subphase_started_ms=w.time
        from combat_sim.facing import forward
        m=w.motion[actor.id];direction=tuple(map(dec,forward(actor.facing)[:2]))
        m.update(mode='running',phase=None,speed=dec(w.movement_definition['characters'][actor.profile_id]['running_speed_mps']),
            acceleration=D(0),direction=direction,revision=m['revision']+1)
        bonus='charge-speed:'+str(action.id)
        w.ground_speed.grant(bonus,actor.id,actor.life_generation,a['charge_movement_speed_multiplier'],action.active_end_ms)
        row=dict(id='charge:'+str(action.id),actor=actor.id,ability=action.ability_id,action_id=action.id,
            source_life_generation=actor.life_generation,started_at_ms=w.time,search_until_ms=action.active_end_ms,
            grab_active_ms=grab_active,status='searching',bonus_id=bonus,bonus_count=0,holding_id=None,observer_id=None)
        self.casts[action.id]=row
        self.arm(row,action);self.watch(row,action)
        w.cooldown_system.start(actor,action.ability_id,dec(a['cooldown_ms']),action.id)
        w.refresh_mobile_locomotion();w._schedule_phase(action,'active_completed',action.active_end_ms)
        w.log('charge_started',actor=actor.id,ability=action.ability_id,action_id=action.id,
            charge=deepcopy(row),action=action.record())

    def arm(self,row,action):
        w=self.world;actor=w.fighters[row['actor']];a=actor.profile['abilities'][row['ability']]
        row['volume_id']=w.owned_contacts.start(actor,action,a['grab_geometry'],row['search_until_ms'])['id']

    def watch(self,row,action):
        w=self.world
        if row['observer_id'] is not None:w.contact_signals.unwatch(row['observer_id'],reason='phase_handoff')
        identity='charge-contact:'+str(action.id);row['observer_id']=identity
        w.contact_signals.watch(identity,row['actor'],row['source_life_generation'],self.deliver,
            action_id=action.id,phases=('active','holding_pending','holding'))

    def definition(self,actor,ability_id,component=None):
        a=actor.profile['abilities'][ability_id]
        if component!='wall_slam':return a
        return a|dict(execution_model='charge_wall_slam',damage_type='blunt',direct_damage_type='blunt',
            pre_mitigation_damage=a['wall_slam']['base_damage'],target_effects=dict(disorientation=0,instability=0))

    def bonus_present(self,row):
        bonus=self.world.ground_speed.rows[row['bonus_id']]
        return bonus['status']=='active' and bonus['life_generation']==row['source_life_generation'] and self.world.time<bonus['until_ms']

    def fracture(self,row,identity,*,wave_id=None,qualifying=None):
        w=self.world;obj=w.collider_system.registry.objects.get(identity)
        qualifying=self.bonus_present(row) if qualifying is None else qualifying
        if (obj is None or not obj.active(w.time) or obj.permanent or 'wall' not in obj.identity.tags or
                not qualifying):return False
        before=obj.hp;source='charge_wall_fracture:'+row['id']
        if obj.hp is None:w.collider_system.remove(identity,reason=source,status='destroyed')
        else:w.collider_system.damage(identity,obj.hp,source=source,damage_type='blunt')
        w.log('charge_wall_fractured',actor=row['actor'],ability=row['ability'],action_id=row['action_id'],
            wall_id=identity,hp_before=before,contact_wave_id=wave_id,conditional_destruction=True)
        return True

    def contact(self,p):
        """Return true when terrain has been consumed; living grabs stage normally."""
        row=self.casts.get(p['action_id'])
        if row is None or row['status']!='searching':return True
        w=self.world;actor=w.fighters[row['actor']];action=actor.action_by_id(row['action_id'])
        if action is None:return True
        if p['collision_kind']=='terrain':
            obj=w.collider_system.registry.objects[p['target']]
            if obj.active(w.time) and not obj.permanent and 'wall' in obj.identity.tags and self.bonus_present(row):
                self.hand_fractures.append(dict(cast_id=row['action_id'],wall_id=p['target'],attack_id=p['attack_id'],hp_at_contact=obj.hp))
                return True
        row['status']='grabbing';row['contact_at_ms']=w.time
        action.active_end_ms=w.time+row['grab_active_ms'];action.revision+=1
        action.active_ms=action.active_end_ms-action.active_due_ms
        action.active_subphase='grab';action.subphase_started_ms=w.time
        w._schedule_phase(action,'active_completed',action.active_end_ms)
        w.log('charge_grab_started',charge=deepcopy(row),active_end_ms=action.active_end_ms)
        return False

    def flush_hand_fractures(self):
        pending,self.hand_fractures=self.hand_fractures,[]
        for contact in pending:
            row=self.casts[contact['cast_id']];w=self.world
            # The touch/bonus were committed before this shared HP batch.
            fractured=self.fracture(row,contact['wall_id'],qualifying=True)
            actor=w.fighters[row['actor']];action=actor.action_by_id(row['action_id'])
            if (row['status']=='searching' and actor.hp>0 and actor.life_generation==row['source_life_generation'] and
                    action is not None and action.phase=='active' and w.time<row['search_until_ms']):self.arm(row,action)
            w.log('charge_hand_wall_resolved',**deepcopy(contact),fractured=fractured)

    def attached(self,parent,hold):
        row=self.casts.get(parent.id)
        if row is not None:
            row['holding_id']=hold['id'];self.world.log('charge_target_held',charge=deepcopy(row),hold=deepcopy(hold))

    def completed(self,actor,parent):
        row=self.casts.get(parent.id)
        if row is None or row['status']=='ended':return
        hold=self.world.grapple_casts.holds.get(row['holding_id'])
        if hold is not None and hold['status']=='active':
            row['status']='holding';self.watch(row,actor.action_by_id(hold['holding_action_id']))
        else:self.end(row,'search_or_grab_completed')

    def hold_ended(self,hold,reason):
        row=self.casts.get(hold['grab_action_id'])
        if row is not None:self.end(row,'hold_'+reason)

    def end(self,row,reason):
        if row['status']=='ended':return
        row.update(status='ended',ended_at_ms=self.world.time,end_reason=reason)
        w=self.world
        if row.get('volume_id') in w.owned_contacts.rows:w.owned_contacts.end(w.owned_contacts.rows[row['volume_id']],reason)
        if row['observer_id'] is not None:w.contact_signals.unwatch(row['observer_id'],reason=reason)
        if row['bonus_id'] in w.ground_speed.rows:w.ground_speed.end(row['bonus_id'],reason)
        w.log('charge_ended',charge=deepcopy(row))

    def action_cancelled(self,actor,action,reason):
        for row in self.casts.values():
            if row['actor']!=actor.id or row['status']=='ended':continue
            hold=self.world.grapple_casts.holds.get(row['holding_id'])
            if action.id==row['action_id'] or hold is not None and action.id==hold['holding_action_id']:self.end(row,reason)

    def before_native(self,prepared):
        if prepared is None or not self.enabled or not self.casts:return
        w=self.world;states={a.actor:a for a in prepared.before};matched={o.identity:o for o,_ in prepared.matches}
        for row in tuple(self.casts.values()):
            if row['status']=='ended' or row['observer_id'] not in matched:continue
            actor=row['actor'];hold=w.grapple_casts.holds.get(row['holding_id'])
            target=hold['target'] if hold is not None and hold['status']=='active' else None
            walls={c.second for c in prepared.contacts if not c.pose_only and c.surface is not None and
                'wall' in c.surface.tags and c.first in (actor,target)}
            intents=[];qualifying=self.bonus_present(row)
            for wall in sorted(walls):
                victim_contact=target is not None and any(c.first==target and c.second==wall and not c.pose_only for c in prepared.contacts)
                item=dict(wall_id=wall)
                if victim_contact:
                    identity='charge-slam:'+prepared.identity+':'+str(row['action_id'])+':'+wall
                    owner=matched[row['observer_id']];source=w.fighters[actor]
                    action=source.action_by_id(owner.action_id)
                    w.effort_system.capture_direct(source,row['ability'],owner.action_id,
                        self.definition(source,row['ability'],'wall_slam'),identity,'wall_slam',
                        instability_snapshot=states[actor].instability)
                    w.attack_modifiers.capture(source,action,identity)
                    item.update(target=target,target_life_generation=states[target].life_generation,
                        instability=states[actor].instability,attack_id=identity,source_action_id=owner.action_id)
                item['fractured']=self.fracture(row,wall,wave_id=prepared.identity,qualifying=qualifying)
                intents.append(item)
            if intents:self.intents[(prepared.identity,row['observer_id'])]=(row['action_id'],tuple(intents))

    def refresh(self,row):
        w=self.world;old=w.ground_speed.rows[row['bonus_id']]
        if row['status']=='ended':return
        a=w.fighters[row['actor']].profile['abilities'][row['ability']]
        until=w.time+dec(a['charge_duration_ms'])
        if old['status']=='active':w.ground_speed.refresh(old['id'],until)
        else:
            row['bonus_count']+=1;row['bonus_id']='charge-speed:'+str(row['action_id'])+':'+str(row['bonus_count'])
            w.ground_speed.grant(row['bonus_id'],row['actor'],row['source_life_generation'],a['charge_movement_speed_multiplier'],until)

    def deliver(self,delivery):
        entry=self.intents.pop((delivery.wave.identity,delivery.observer.identity),None)
        if entry is None:return
        action_id,intents=entry;row=self.casts[action_id];w=self.world;actor=w.fighters[row['actor']]
        for item in intents:
            if 'target' not in item:continue
            identity=item['attack_id']
            packet=dict(attack_id=identity,actor=actor.id,ability=row['ability'],action_id=item['source_action_id'],
                source_life_generation=row['source_life_generation'],target=item['target'],
                target_life_generation=item['target_life_generation'],component='wall_slam',melee_component='wall_slam',
                collision_kind='body',delivery_kind='committed_wall_slam',contact_wave_id=delivery.wave.identity,
                wall_id=item['wall_id'],distance_m=D(0),location_m=w.fighters[item['target']].body_origin_m,hit_parts=[])
            w.push(w.time,'impact',packet)
            self.slams.append(dict(**packet,wall_fractured=item['fractured'],instability_at_contact=item['instability']))
            w.log('charge_wall_slam',**deepcopy(self.slams[-1]));self.refresh(row)

    def settle(self):
        if not self.enabled:return
        w=self.world
        for row in self.casts.values():
            if row['status']=='ended':continue
            a=w.fighters[row['actor']]
            if a.hp<=0 or a.life_generation!=row['source_life_generation']:self.end(row,'source_life_ended')

    def result(self):
        return dict(charge_grapple_rules=self.world.combat_locomotion_input['charge_grapples'],
            charge_grapples=deepcopy(list(self.casts.values())),charge_wall_slams=deepcopy(self.slams)) if self.enabled else {}
