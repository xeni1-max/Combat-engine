"""Life-bound persistent velocity constraints, separate from grapple casts/Break.

Free character drives remain independent. Each connected component projects
them together on the shared clock, with actual contact/support constraints.
"""
from copy import deepcopy
from dataclasses import dataclass
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F

from combat_sim.battle_models import decimal_value as dec
from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.grapple import GrappleState
from combat_sim.mechanics.dyspnea import DyspneaContext,advance_continuous_action_dyspnea
from combat_sim.mechanics.knockback import KnockbackBody,resist_knockback
from combat_sim.mechanics.life import life_generation
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality,BlockedDirection,project_velocities,number
from combat_sim.models import UnsupportedMechanicError
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M as DIST,CONTACT_SPEED_EPS_MPS as SPEED
from combat_sim.spatial_transitions import SpatialChange,StaleSpatialPlan


@dataclass(frozen=True)
class LinkCommand:
    operation: str
    identity: str
    controller: str | None = None
    target: str | None = None
    controller_life: int | None = None
    target_life: int | None = None
    duration_ms: F | None = None

    def __post_init__(self):
        if self.operation not in ('attach','release') or not isinstance(self.identity,str) or not self.identity:
            raise ValueError('Link command needs an operation and identity')
        if self.operation=='release':
            if any(value is not None for value in (self.controller,self.target,self.controller_life,self.target_life,self.duration_ms)):
                raise ValueError('Release identifies only its link')
            return
        if any(not isinstance(n,str) or not n for n in (self.controller,self.target)) or self.controller==self.target:
            raise ValueError('Attach needs two distinct actor identities')
        for field in ('controller_life','target_life'):
            value=life_generation(getattr(self,field))
            if value is None:raise ValueError('Attach needs both expected actor lives')
            object.__setattr__(self,field,value)
        object.__setattr__(self,'duration_ms',number(self.duration_ms,positive=True))

    @property
    def actors(self):return {self.controller:self.controller_life,self.target:self.target_life} if self.operation=='attach' else {}


@dataclass(frozen=True)
class LinkPlan:
    owner: object
    dependency: tuple
    command: LinkCommand
    source: str
    action_source: EffectSource | None = None


class GrappleLinks:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.epoch=0;self.owner=object()
        if self.enabled and (definition!={'mode':'grapple_velocity_v1'} or not world.spatial_transitions.enabled):
            raise UnsupportedMechanicError('Grapple motion requires current atomic spatial rules')
        self.links={}

    def parse_command(self,value):
        if not self.enabled:raise UnsupportedMechanicError('Persistent grapple motion is not enabled')
        if not isinstance(value,dict) or value.get('operation') not in ('attach','release'):
            raise ValueError('Grapple control needs attach or release')
        if not isinstance(value.get('id'),str) or not value['id']:raise ValueError('Grapple control needs its link identity')
        if value['operation']=='release':
            if set(value)!={'operation','id'}:raise ValueError('Release identifies one existing link')
            return LinkCommand('release',value['id'])
        expected={'operation','id','controller','target','controller_life_generation','target_life_generation','duration_ms'}
        if set(value)!=expected:raise ValueError('Attach needs explicit participants, lives and duration')
        for field in ('controller','target'):
            if not isinstance(value[field],str) or value[field] not in self.world.fighters:raise ValueError('Unknown grapple participant')
        if value['controller']==value['target']:raise ValueError('A grapple needs two different actors')
        first=life_generation(value['controller_life_generation']);second=life_generation(value['target_life_generation'])
        if first is None or second is None:raise ValueError('A grapple needs both expected lives')
        if isinstance(value['duration_ms'],bool):raise ValueError('Link duration must be positive')
        duration=number(value['duration_ms'],positive=True)
        return LinkCommand('attach',value['id'],value['controller'],value['target'],first,second,duration)

    def prepare(self,command,*,source,action_source=None):
        with localcontext(Context(prec=self.world.precision)):
            return self._prepare(command,source=source,action_source=action_source)

    def _prepare(self,command,*,source,action_source=None):
        if not self.enabled or not isinstance(command,LinkCommand):raise ValueError('Link update needs an enabled typed command')
        if not isinstance(source,str) or not source:raise ValueError('Link update needs source attribution')
        if action_source is not None and (not isinstance(action_source,EffectSource) or
                command.operation!='attach' or action_source.actor!=command.controller or
                action_source.life_generation!=command.controller_life):
            raise ValueError('A cast link must retain its controller action and life')
        w=self.world
        if not w.airborne_enabled:raise UnsupportedMechanicError('Grapple motion needs body gravity and support')
        if command.operation=='attach':
            if command.identity in self.links:raise ValueError('Grapple link identities cannot be reused')
            for name,generation in command.actors.items():
                if name not in w.fighters:raise ValueError('Unknown grapple participant')
                actor=w.fighters[name]
                if actor.hp<=0 or actor.life_generation!=generation:raise StaleSpatialPlan('Grapple needs current living participants')
            actor=w.fighters[command.controller]
            if GrappleState(actor.dyspnea,actor.disorientation,actor.instability).exhausted:
                raise ValueError('Controller is already exhausted for this grapple')
        elif command.operation!='release':raise ValueError('Unknown link operation')
        return LinkPlan(self.owner,w.spatial_transitions._dependency(),command,source,action_source)

    def commit(self,plan,*,notify=True):
        with localcontext(Context(prec=self.world.precision)):
            return self._commit(plan,notify=notify)

    def _commit(self,plan,*,notify=True):
        if not isinstance(plan,LinkPlan) or plan.owner is not self.owner:raise ValueError('Link plan belongs to another world')
        if plan.dependency!=self.world.spatial_transitions._dependency():raise StaleSpatialPlan('World changed after link preparation')
        c=plan.command;w=self.world
        if c.operation=='release':
            return self.release(c.identity,reason='explicit_release',source=plan.source)
        record={'id':c.identity,'source':plan.source,'controller':c.controller,'target':c.target,
            'controller_life_generation':c.controller_life,'target_life_generation':c.target_life,
            'created_at_ms':w.time,'expiry_ms':w.time+dec(c.duration_ms),'status':'active',
            'reference_offset_m':tuple(y-x for x,y in zip(w.spatial_transitions.reference(c.controller),w.spatial_transitions.reference(c.target)))}
        if plan.action_source is not None:
            record.update(ability=plan.action_source.ability,holding_action_id=plan.action_source.action_id)
        self.links[c.identity]=record;self.epoch+=1
        w.push(record['expiry_ms'],'grapple_link_expired',{'link_id':c.identity},priority=0)
        w.log('grapple_link_created',link=deepcopy(record),engineering_controller=plan.action_source is None)
        if notify:self.notify()
        return deepcopy(record)

    def release(self,identity,*,reason,source=None):
        record=self.links.get(identity)
        if record is None or record['status']!='active':return None
        record.update(status='ended',ended_at_ms=self.world.time,end_reason=reason)
        self.epoch+=1
        self.world.log('grapple_link_ended',link=deepcopy(record),release_source=source)
        if hasattr(self.world,'grapple_casts'):self.world.grapple_casts.link_ended(record)
        self.notify()
        return deepcopy(record)

    def live(self,payload):return self.links[payload['link_id']]['status']=='active'

    def process(self,payload):return self.release(payload['link_id'],reason='duration_expired')

    def retire_life(self,actor):
        for identity,row in list(self.links.items()):
            if row['status']=='active' and (row['controller']==actor.id or row['target']==actor.id):
                self.release(identity,reason='participant_died',source=actor.id)

    def groups(self):
        graph={}
        for row in self.links.values():
            if row['status']!='active':continue
            names=(row['controller'],row['target'])
            if any(self.world.fighters[n].hp<=0 or self.world.fighters[n].life_generation!=row[k]
                    for n,k in zip(names,('controller_life_generation','target_life_generation'))):continue
            a,b=names;graph.setdefault(a,set()).add(b);graph.setdefault(b,set()).add(a)
        groups=[];pending=set(graph)
        while pending:
            todo=[min(pending)];group=set()
            while todo:
                name=todo.pop()
                if name in group:continue
                group.add(name);todo.extend(graph[name]-group)
            pending-=group;groups.append(tuple(sorted(group)))
        return tuple(groups)

    def group(self,name):return next((g for g in self.groups() if name in g),(name,))

    def joined(self,name):return len(self.group(name))>1

    def knockback_distance(self,name,nominal_m):
        group=self.group(name);w=self.world
        if any(w.fighters[n].hp<=0 for n in group):raise StaleSpatialPlan('Knockback needs living recipients')
        return resist_knockback(nominal_m,tuple(KnockbackBody(n,w.fighters[n].profile['max_hp'],w.fighters[n].armor)
            for n in group),precision=w.precision)

    def expand_changes(self,changes):
        """External physical changes move the complete current grapple group."""
        if not self.enabled:return changes
        w=self.world;expanded={c.actor:c for c in changes}
        if len(expanded)!=len(changes):raise ValueError('A body may appear only once in a spatial transaction')
        for group in self.groups():
            requested=[c for c in changes if c.actor in group];delta=None;velocity=None
            for c in requested:
                if c.reference_m is not None:
                    before=w.spatial_transitions.reference(c.actor)
                    candidate=tuple(dec(x)-y for x,y in zip(c.reference_m,before))
                    if not any(abs(x)>DIST for x in candidate):candidate=(D(0),)*3
                    if delta is not None and any(abs(x-y)>DIST for x,y in zip(delta,candidate)):
                        raise ValueError('Linked destinations require the same translation')
                    delta=candidate
                if c.velocity_mps is not None:
                    candidate=tuple(map(dec,c.velocity_mps))
                    if velocity is not None and any(abs(x-y)>SPEED for x,y in zip(velocity,candidate)):
                        raise ValueError('Linked bodies require one imposed velocity')
                    velocity=candidate
            if delta is not None and not any(delta):delta=None
            if velocity is not None and not any(abs(x-y)>SPEED for x,y in zip(velocity,w.mobile_motion(group[0])[0])):velocity=None
            if delta is None and velocity is None:continue
            for name in group:
                old=expanded.get(name);generation=old.expected_life_generation if old else w.fighters[name].life_generation
                reference=tuple(x+y for x,y in zip(w.spatial_transitions.reference(name),delta)) if delta is not None else None
                expanded[name]=SpatialChange(name,generation,reference,velocity)
        return tuple(expanded[n] for n in sorted(expanded))

    def capture_contacts(self,contacts):
        """Capture free inputs before the ordinary physical collision snapshot."""
        w=self.world;constraints={}
        for contact in contacts:
            if contact.get('pose_only'):continue
            a,b=contact['first'],contact['second']
            if w.fighters[a].hp<=0 or b in w.fighters and w.fighters[b].hp<=0:continue
            directions=list(contact['normals'])
            if b in w.fighters:
                delta=tuple(dec(y)-dec(x) for x,y in zip(w.fighters[a].body_origin_m,w.fighters[b].body_origin_m))
                length=sum(x*x for x in delta).sqrt()
                if length:directions.append(tuple(x/length for x in delta))
            for name in (a,b):
                if name not in w.fighters:continue
                group=self.group(name)
                if len(group)>1:constraints.setdefault(group,set()).update(directions)
        return tuple((group,tuple(sorted(normals)),tuple((n,self.world.free_mobile_motion(n)[0],w.fighters[n].instability,
            w.motion[n]['mode'],w.motion[n].get('imposed_velocity') is not None,
            w.motion[n]['jump'].get('ground_drive_velocity') if w.motion[n]['jump'] is not None and
                (w.motion[n]['jump'].get('landing_effects') is not None or
                 w.motion[n]['jump'].get('contact_obligations')) else None) for n in group))
            for group,normals in sorted(constraints.items()))

    def finish_contacts(self,plan):
        """Transmit lost movement to every free drive in the connected group.

        Collision penalties remain with actual contacting bodies. Removing each
        free input's component avoids reintroducing blocked movement by averaging
        an untouched partner, or inventing observation-dependent resting locks.
        """
        w=self.world;divisor=dec(w.combat_locomotion_definition['instability']['speed_penalty_divisor'])
        for group,normals,snapshots in plan:
            for name,before,instability,mode,imposed,landing_drive in snapshots:
                if w.fighters[name].hp<=0:continue
                actor=w.fighters[name];m=w.motion[name]
                if landing_drive is not None and m['jump'] is None:before=landing_drive
                projected=dict(project_velocities((VelocityNode(name,before,1,0),),
                    blocked=tuple(BlockedDirection(name,n) for n in normals),precision=w.precision).velocities)[name]
                basis=[]
                for normal in normals:
                    direction=normal
                    for previous in basis:
                        dot=sum(v*n for v,n in zip(direction,previous))
                        direction=tuple(v-dot*n for v,n in zip(direction,previous))
                    length=sum(v*v for v in direction).sqrt()
                    if length>SPEED:basis.append(tuple(v/length for v in direction))
                projected=w.knock_motion.elastic_response(name,before,projected,basis=basis)
                w.knock_motion.transport_components(name,basis)
                projected=w.constrain_mobile_support(actor,projected,basis)
                affected=any(abs(x-y)>SPEED for x,y in zip(before,projected)) or any(
                    abs(sum(x*n for x,n in zip(w.free_mobile_motion(name)[1],normal)))>SPEED for normal in normals)
                action=actor.body_action();stopping=m['phase']=='stopping_active' and action is not None
                if affected and action is not None and action.kind=='locomotion' and not stopping:
                    w.cancel_owned_action(actor,action,'linked_body_contact')
                    m.update(mode=mode,phase=None,acceleration=D(0))
                if imposed:m['imposed_velocity']=(*projected[:2],D(0))
                if m['jump'] is not None:m['jump']['velocity']=projected
                elif projected[2]>SPEED:m['jump']={'velocity':projected,'basic_jump':False}
                speed=sum(v*v for v in projected[:2]).sqrt()
                if speed>SPEED:m['direction']=tuple(v/speed for v in projected[:2])
                if stopping:
                    remaining=(action.active_end_ms-w.time)/1000
                    m.update(speed=speed,acceleration=-speed/remaining if remaining else D(0))
                else:
                    m['speed']=(speed+instability/divisor)/w.ground_speed_multiplier(name) if speed>SPEED else D(0)
                    if affected:m['acceleration']=D(0)
                    if speed<=SPEED and m['jump'] is None:m['mode']='standing'
            self.epoch+=1
            w.log('grapple_contact_transmitted',actors=group,constraints=normals,
                status_recipients='Only the bodies in actual contacts; existing individual mitigation')

    def motion(self,name,*,static_support_only=False):
        with localcontext(Context(prec=self.world.precision)):
            return self._motion(name,static_support_only=static_support_only)

    def _motion(self,name,*,static_support_only=False):
        group=self.group(name)
        if len(group)==1:return self.world.free_mobile_motion(name)
        w=self.world;raw={n:w.free_mobile_motion(n) for n in group}
        nodes=tuple(VelocityNode(n,raw[n][0],w.fighters[n].profile['max_hp'],w.fighters[n].armor) for n in group)
        edges=tuple(VelocityEquality(group[0],n) for n in group[1:])
        velocity=dict(project_velocities(nodes,edges,precision=w.precision).velocities)[name]
        acceleration=dict(project_velocities(tuple(VelocityNode(n,raw[n][1],w.fighters[n].profile['max_hp'],
            w.fighters[n].armor) for n in group),edges,precision=w.precision).velocities)[name]
        # Compatible prescribed controls support their complete component.
        # Incompatible controls are retired before positive-time consumption.
        if all(w._climbing(n) for n in group):return velocity,acceleration
        # A rigid velocity group has one vertical acceleration, irrespective of
        # how many members happen to supply a supporting static contact.
        support=w.collider_system.static_support if static_support_only else w.collider_system.find_support
        supported=any(w.motion[n]['jump'] is None and support(w.fighters[n]) is not None for n in group)
        acceleration=(*acceleration[:2],D(0) if supported and velocity[2]<=SPEED else -w.jump_gravity)
        if supported and velocity[2]<=SPEED:
            velocity=(*velocity[:2],D(0))
        return velocity,acceleration

    def settle(self):
        if not self.enabled:return
        w=self.world
        for identity,row in list(self.links.items()):
            if row['status']!='active':continue
            names=(row['controller'],row['target'])
            if any(w.fighters[n].hp<=0 or w.fighters[n].life_generation!=row[k]
                    for n,k in zip(names,('controller_life_generation','target_life_generation'))):
                self.release(identity,reason='participant_life_ended');continue
            actor=w.fighters[row['controller']]
            if GrappleState(actor.dyspnea,actor.disorientation,actor.instability).exhausted:
                self.release(identity,reason='controller_exhausted')

    def next_boundary(self,end):
        w=self.world;finish=end
        for row in self.links.values():
            if row['status']!='active':continue
            a=w.fighters[row['controller']]
            limit=dec(GrappleState(a.dyspnea,a.disorientation,a.instability).exhaustion_limit)
            if a.dyspnea>=limit:return w.time
            # Compound effort has one authoritative writer/forecast. A legacy
            # solo-sprint forecast would otherwise release a hold too early.
            # Split status knots before forecasting a changing fatigue limit.
            for status in (a.disorientation,a.instability):
                if status>0:finish=min(finish,w.time+status)
            if w.continuous_effort.handles(a.id) or not w.mobile_sprint_effort(a.id):continue
            anchor,initial=w.motion[a.id]['sprint_anchor']
            base=dec(w._sprint_values(a)['base_continuous_dyspnea_per_second'])
            def margin(time):
                amount=(D(100) if time>=w._sprint_cap_time(a) else dec(advance_continuous_action_dyspnea(
                    initial,base,time-anchor,context=DyspneaContext('sprinting')).after))
                elapsed=time-w.time
                threshold=max(D(0),100-(max(D(0),a.disorientation-elapsed)+max(D(0),a.instability-elapsed))/10)
                return amount-threshold
            if margin(finish)<0:continue
            low,high=w.time,finish
            for _ in range(w.precision*4):
                if high-low<=D('1e-25'):break
                middle=(low+high)/2
                if margin(middle)>=0:high=middle
                else:low=middle
            finish=high
        return finish

    def notify(self):
        w=self.world
        w.healing.invalidate();w.thermal_recovery.invalidate()
        w.refresh_mobile_locomotion();w.cooldown_system.settle();w.effect_system.settle();w.collider_system.dirty=True
        contact=w.next_mobile_contacts(w.time)
        if contact is not None:w.push(w.time,'movement_contact',w.mobile_contact_payload(contact[1]),priority=2)
        for a in w.fighters.values():
            if a.hp>0:w.request_decision(a.id,w.time)

    def result(self):
        if not self.enabled:return {}
        return {'grapple_motion_rules':self.world.combat_locomotion_input['grapple_links'],
            'grapple_links':deepcopy(list(self.links.values()))}
