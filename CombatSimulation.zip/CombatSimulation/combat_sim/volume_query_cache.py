"""Bounded memo of pure volume cells, separate from membership/effect ownership.

Keys retain complete fixed geometry, derivatives, controls and Decimal context.
Unsupported inputs (including iterators/angular paths) go directly to the query.
No actor life, damage, world reference or pending effect is retained here.
"""
from collections import OrderedDict
from dataclasses import fields
from decimal import Decimal as D,getcontext,localcontext
from fractions import Fraction as F

from combat_sim.hitboxes import Cuboid
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.terrain import RectangularGround

_SHAPES={cls:tuple(f.name for f in fields(cls)) for cls in (Cuboid,OrientedCuboid,YawFrame,RectangularGround)}
_SIGNALS=tuple(sorted(getcontext().traps,key=lambda s:s.__name__))
_MISSING=object()

class _Uncacheable(Exception):pass

def _freeze(value):
    kind=type(value)
    # Fraction.__hash__ computes modular inverses. Its exact integer pair is
    # an equally faithful, substantially cheaper immutable key.
    if kind is F:return F,value.numerator,value.denominator
    if kind is D:return D,value.as_tuple()
    if kind in (str,int,bool,type(None)):return kind,value
    if kind is float:return float,value.hex()
    if kind in (list,tuple):return kind,tuple(map(_freeze,value))
    if kind is dict:return dict,tuple(sorted((_freeze(k),_freeze(v)) for k,v in value.items()))
    if kind in _SHAPES:return kind,tuple(_freeze(getattr(value,n)) for n in _SHAPES[kind])
    raise _Uncacheable()

def _context_key(context):
    return (context.prec,context.rounding,context.Emin,context.Emax,context.capitals,context.clamp,
        tuple(context.traps[s] for s in _SIGNALS))

class VolumeQueryCache:
    """Per-world exact-input LRU; returned cell lists are detached on every call."""
    def __init__(self,maximum_entries=256):
        if type(maximum_entries) is not int or maximum_entries<=0:
            raise ValueError('Volume query cache capacity must be a positive integer')
        self.maximum_entries=maximum_entries;self.entries=OrderedDict()
        self.hits=0;self.misses=0;self.bypasses=0

    def clear(self):self.entries.clear()

    def query(self,function,*args,**kwargs):
        context=getcontext()
        try:
            key=function,_freeze(args),_freeze(kwargs),_context_key(context)
            cached=self.entries.get(key,_MISSING)
        except (_Uncacheable,TypeError,RecursionError):
            self.bypasses+=1
            return function(*args,**kwargs)
        if cached is not _MISSING:
            self.hits+=1;self.entries.move_to_end(key)
            cells,signals=cached
            for signal in signals:context.flags[signal]=True
            return list(cells)
        self.misses+=1;signals=()
        # Existing flags do not affect arithmetic. Measuring this query in a
        # copy with clear flags lets later hits reproduce every raised signal,
        # even when an earlier caller already had those flags set. Traps and
        # all arithmetic settings stay identical; failures never enter the LRU.
        try:
            with localcontext(context) as inner:
                inner.clear_flags()
                try:cells=function(*args,**kwargs)
                finally:signals=tuple(s for s in _SIGNALS if inner.flags[s])
        finally:
            for signal in signals:context.flags[signal]=True
        frozen=tuple(cells)
        self.entries[key]=frozen,signals
        if len(self.entries)>self.maximum_entries:self.entries.popitem(last=False)
        return list(frozen)
