"""One equip/grenade/cloud with explicit recipient exposure windows and exact toxin."""
from fractions import Fraction
from typing import Any

from combat_sim.actions import ScriptedActionSequence
from combat_sim.encounters import initial_states
from combat_sim.events import EventLog
from combat_sim.exact import ExactAmount,number_record
from combat_sim.mechanics import poison
from combat_sim.mechanics.timing import impact_time_from_activation,self_effect_time_from_activation
from combat_sim.models import UnsupportedMechanicError,as_fraction,fraction_record
from combat_sim.state_updates import _state_snapshot,_validate_shield_state
from combat_sim.status_events import _advance_statuses,_apply_effects


def _ms(value,label):
    if isinstance(value,bool) or not isinstance(value,int) or value<0:
        raise ValueError(f'{label} must be a nonnegative integer millisecond')
    return value


def _nonlethal(hp,total):
    rational=total.as_fraction()
    if rational is not None: return hp>rational
    if total.rational or len(total.roots)!=1 or total.roots[0].coefficient<0:
        raise UnsupportedMechanicError('Nonlethal poison precheck requires one complete exposure/residual expression')
    root=total.roots[0]
    return hp>0 and hp**2>root.coefficient**2*root.radicand


def _advance_poison(states,applications,start,end,impact,ability,log):
    if end<=start or start<impact: return
    for name,application in sorted(applications.items()):
        leave,expiry=application['leave'],application['expiry']
        if start>=expiry: continue
        if end<=leave:
            phase='exposure'; q0,q1=Fraction(start-impact,1000),Fraction(end-impact,1000)
            tt0,tt1,to0,to1=q0,q1,Fraction(0),Fraction(0)
        elif start>=leave and end<=expiry:
            phase='residual_poison'; tt0=tt1=application['duration_seconds']
            to0,to1=Fraction(start-leave,1000),Fraction(end-leave,1000)
            q0,q1=tt0-to0,tt1-to1
        else: raise ValueError('Poison interval must split at every exposure/end boundary')
        rt=application['resistance']; state=states[name]
        damage=poison.poison_damage_between(ability['toxicity'],rt,q0,q1,Fraction(end-start,1000))
        before=state.hp
        state.hp=ExactAmount.of(state.hp)-damage
        log.record({'time_ms':end,'type':'continuous_damage_resolved','target':name,'interval_start_ms':start,'interval_end_ms':end,
            'damage_payment':'Exact continuous analytic integral; interval accounting is not a damage tick',
            'nominal_hp_damage':number_record(damage),'applied_hp_damage':number_record(damage),
            'components':{'poison':{'amount':number_record(damage),'phase':phase,'formula':poison.FORMULA,
                'inputs':{'Tp':str(ability['toxicity']),'RT':str(rt),'tT_start_seconds':str(tt0),'tT_end_seconds':str(tt1),
                    'to_start_seconds':str(to0),'to_end_seconds':str(to1)},
                'coefficient':fraction_record(poison.poison_coefficient(ability['toxicity'],rt)),
                'root_input_start':str(q0),'root_input_end':str(q1),
                'resistance_scope':'Constant profile resistance in this scenario; changing resistance is not modeled',
                'shield_interaction':'bypasses_shield','integral':'C * integral(sqrt(q(t))) dt, exact for linear q','source':poison.SOURCE}},
            'state_changes':{'target':name,'hp_before':number_record(before),'hp_after_impact':number_record(state.hp),
                'armor_before':fraction_record(state.armor),'armor_after_impact':fraction_record(state.armor),
                'shield_before':fraction_record(state.shield),'shield_after_impact':fraction_record(state.shield)}})


def run_poison_grenade_scenario(scenario:dict[str,Any],profiles:dict[str,Any])->dict[str,Any]:
    if set(scenario)-{'id','description','encounter','action_sequence','run_until_ms'}:
        raise UnsupportedMechanicError('Unsupported poison-grenade scenario fields')
    encounter=scenario.get('encounter',{})
    if set(encounter)-{'initial_states','geometry'} or encounter.get('geometry')!='explicit_exposure_windows':
        raise UnsupportedMechanicError('Poison encounter requires geometry=explicit_exposure_windows; no automatic hit testing')
    inputs=ScriptedActionSequence(scenario.get('action_sequence',[])).inputs()
    if len(inputs)!=1: raise UnsupportedMechanicError('This stage requires one equip and one grenade')
    action=inputs[0]
    if set(action)-{'kind','action_start_ms','actor','ability','target_distance_m','hit_confirmed','area_targets','exposure_durations_ms'}:
        raise UnsupportedMechanicError('Unsupported poison-grenade action fields')
    if action.get('kind')!='activation' or action.get('hit_confirmed') is not True:
        raise UnsupportedMechanicError('Scenario-confirmed grenade detonation is required')
    actor,ability_id=action.get('actor'),action.get('ability'); recipients=action.get('area_targets'); durations=action.get('exposure_durations_ms')
    if not isinstance(recipients,list) or any(not isinstance(n,str) for n in recipients) or len(set(recipients))!=len(recipients):
        raise ValueError('area_targets must explicitly list unique explosion recipients, or []')
    if not isinstance(durations,dict) or set(durations)!=set(recipients):
        raise ValueError('exposure_durations_ms must specify exactly each area recipient')
    states=initial_states(encounter,track_statuses=True)
    if set(states)!={actor,*recipients}: raise UnsupportedMechanicError('States must contain actor and exactly the supplied recipients')
    for name,state in states.items():
        profile=profiles.get(name,{})
        if any(k not in profile for k in ('max_hp','shield_capacity','status_resistance')) or 'toxin' not in profile.get('resistances',{}):
            raise UnsupportedMechanicError(f'{name} requires complete defender data including toxin resistance')
        if min(as_fraction(profile['max_hp']),as_fraction(profile['status_resistance']),as_fraction(profile['resistances']['toxin']))<0:
            raise ValueError('HP and resistances must be nonnegative')
        _validate_shield_state(state,as_fraction(profile['shield_capacity']),name)
    if states[actor].statuses.disorientation!=0 or states[actor].statuses.instability!=0:
        raise UnsupportedMechanicError('First equip/grenade scope requires zero initial caster statuses; multi-activation Gathering transitions are excluded')
    ability=profiles[actor]['abilities'][ability_id]
    required={'damage_type':'poisonous','damage_category':'extrinsic','armor_loss':'none','shield_interaction':'bypasses_shield',
              'damage_payment':'continuous','exposure_clock':'elapsed_exposure_then_frozen_exposure_minus_elapsed_non_exposure',
              'weapon_cooldown_anchor':'active_firing_end'}
    if any(ability.get(k)!=v for k,v in required.items()): raise UnsupportedMechanicError('Unsupported poison-grenade rule modes')
    timing_profile=profiles[actor]['timing_profiles'][ability['timing_profile']]
    if timing_profile.get('impact_timing')!='projectile' or timing_profile.get('projectile_release_timing')!='after_active' or ability['self_effects'].get('application_timing')!='middle_of_active':
        raise UnsupportedMechanicError('Grenade requires release after Active and midpoint firing self effects')
    start=_ms(action.get('action_start_ms'),'action_start_ms')
    impact,timing=impact_time_from_activation(start,timing_profile,action.get('target_distance_m'))
    self_time,self_timing=self_effect_time_from_activation(start,timing_profile,'middle_of_active')
    swap_end=start+_ms(timing_profile['preparation_ms'],'Swap Active')
    release=timing['projectile_release_time_ms']; cooldown_end=release+_ms(ability['weapon_cooldown_ms'],'Weapon cooldown')
    cloud_duration=_ms(ability['cloud_duration_ms'],'Cloud duration')
    if not cloud_duration: raise ValueError('Cloud duration must be positive')
    cloud_end=impact+cloud_duration
    capacity=ability['magazine_capacity']
    if isinstance(capacity,bool) or not isinstance(capacity,int) or capacity<1: raise ValueError('Magazine capacity must be a positive integer')
    poison.poison_coefficient(ability['toxicity'],0)
    applications={}
    for name in recipients:
        duration_ms=_ms(durations[name],'Exposure duration')
        if duration_ms>cloud_duration: raise UnsupportedMechanicError('Single initial exposure cannot outlast the cloud')
        duration=Fraction(duration_ms,1000); resistance=as_fraction(profiles[name]['resistances']['toxin'])
        total=poison.full_exposure_and_recovery_damage(ability['toxicity'],resistance,duration)
        if not _nonlethal(states[name].hp,total):
            raise UnsupportedMechanicError('This controlled poison scope requires nonlethal exposure windows; death timing is not specified')
        applications[name]={'duration_seconds':duration,'leave':impact+duration_ms,'expiry':impact+2*duration_ms,'resistance':resistance}
    boundary=max([cloud_end,cooldown_end,*[a['expiry'] for a in applications.values()]])
    until=_ms(scenario.get('run_until_ms',boundary),'run_until_ms')
    if until<boundary: raise ValueError('run_until_ms must include cloud expiry, all residual poison and weapon cooldown')
    initial=_state_snapshot(states)
    queue=[(start,0,'ultimate_started',None),(swap_end,1,'weapon_swap_completed',None),
           (swap_end,2,'grenade_gathering_started',None),(timing['active_end_ms']-_ms(timing_profile['active_ms'],'Firing Active'),3,'grenade_active_started',None),
           (self_time,4,'self_effect',None),(release,5,'projectile_released',None),(impact,6,'grenade_detonated',None),
           (cooldown_end,7,'weapon_cooldown_completed',None),(cloud_end,10,'cloud_expired',None)]
    for name,a in applications.items():
        queue.extend([(a['leave'],8,'poison_exposure_ended',name),(a['expiry'],9,'poison_expired',name)])
    queue.sort(key=lambda e:(e[0],e[1],e[3] or ''))
    current=0; log=EventLog(); ammo=capacity
    for time,_,event,name in queue:
        _advance_poison(states,applications,current,time,impact,ability,log)
        _advance_statuses(states,current,time,log); current=time
        entry={'time_ms':time,'type':event,'actor':actor,'ability':ability_id}
        if event=='ultimate_started': entry.update(timing_calculation=timing,availability='One Ultimate equip and shot authorized by scenario; 65 s availability anchor and costs not executed')
        elif event=='weapon_swap_completed': entry.update(weapon='poison_grenade_launcher',ammo=ammo)
        elif event=='self_effect':
            entry['type']='self_effect_triggered'; entry['timing_calculation']=self_timing
            log.record(entry); _apply_effects(actor,states[actor],profiles[actor],ability['self_effects'],time,'self',log); continue
        elif event=='projectile_released':
            ammo-=1; entry.update(ammo_after=ammo,ammo_consumed=1,actor_state=states[actor].to_record(),weapon_cooldown_ends_at_ms=cooldown_end)
        elif event=='grenade_detonated':
            entry.update(area_targets=sorted(recipients),radius_m=ability['radius_m'],cloud_ends_at_ms=cloud_end,
                         eligibility='Supplied explosion recipients and exposure durations; no automatic movement/radius detection',
                         damage_scope='Listed continuous poisonous gas and area statuses; no separate instantaneous HP-damage value is supplied',source=ability['source'])
            log.record(entry)
            for target in sorted(recipients):
                _apply_effects(target,states[target],profiles[target],ability['target_effects'],time,'grenade_area',log)
            continue
        elif name is not None:
            entry['target']=name
            if event=='poison_exposure_ended': entry.update(exposure_seconds=str(applications[name]['duration_seconds']),residual_ends_at_ms=applications[name]['expiry'])
        elif event=='weapon_cooldown_completed': entry.update(ammo=ammo,actor_state=states[actor].to_record())
        log.record(entry)
    _advance_statuses(states,current,until,log)
    return {'scenario_id':scenario.get('id','unnamed'),'execution_model':'poison_grenade','initial_states':initial,
        'encounter_configuration':{'geometry':'explicit_exposure_windows'},'inputs':inputs,'events':log.records(),
        'continuous_targets':sorted(recipients),'run_until_ms':until,'final_states':_state_snapshot(states),
        'initial_weapon_state':{'weapon':'main_weapon','ultimate_grenades':capacity},
        'final_weapon_state':{'weapon':'poison_grenade_launcher','ammo':ammo,'weapon_cooldown_ready_at_ms':cooldown_end},
        'active_continuous_effects_final':[],'pending_shield_regeneration':[],
        'outcome':'One grenade, cloud and all supplied nonlethal exposure/residual effects completed',
        'assumptions_and_limits':[
            'One scenario-authorized equip and grenade, zero initial caster statuses, supplied distance and explosion recipients. No automatic hit detection or movement is simulated.',
            'Recipients start exposed at detonation and leave at supplied times no later than cloud expiry. Each has one exposure and residual window; no later entry/re-entry or overlapping clouds.',
            'Poison bypasses shields, leaves armor unchanged and uses the documented gas equation, without venom slash delivery. Toxin resistance stays constant; changing resistance behavior is outside this stage.',
            'Explosion applies target statuses once to all supplied recipients. Self effects occur at midpoint firing without mitigation. Including the caster explicitly executes friendly fire with normal incoming mitigation for area effects.',
            'Damage integrates continuously and exactly, retaining square-root HP and display-only decimal approximations. Nonlethal windows are required; lethal full exposures raise an explicit unsupported error.',
            'Swap Active, Gathering, firing, projectile travel, one ammo consumption, 1150 ms firing cooldown, cloud expiry and per-target residual expiry are logged. No separate instantaneous explosion HP damage is specified or executed.',
            'Ten ammo and the 65 s Ultimate cooldown are source values; repeated grenades, Ultimate availability/end transition, empty-ammo behavior, costs, hand Recovery, interrupts and death/revival are outside scope.',
            'Shield values are unchanged by poison; initial missing shield has no invented loss/regen history. Already Active phases do not gain additional Gathering.']}
