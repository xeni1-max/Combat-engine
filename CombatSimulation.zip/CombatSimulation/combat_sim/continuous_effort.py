"""One resource writer for overlapping sustained effort and grapple filling."""
from dataclasses import dataclass
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.effort_flow import EffortInput,build_effort_plan
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite


@dataclass
class EffortChannel:
    id: str
    actor: str
    life_generation: int
    action_id: int
    tag: str
    kind: str
    base: D
    started_at_ms: D
    expiry_ms: D
    gained: D = D(0)
    ended_at_ms: D | None = None
    end_reason: str | None = None

    def record(self):return dict(self.__dict__)


class ContinuousEffort:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None;self.ids=count(1);self.channels={};self.caches={}
        self.cap_ids=count(1);self.caps={}
        if self.enabled and (definition!={'mode':'shared_budget_v1'} or not world.life_cycles.enabled or not world.effort_system.enabled):
            raise UnsupportedMechanicError('Shared continuous effort requires owned living actors')

    def invalidate(self):self.caches.clear()

    def live(self,channel):
        actor=self.world.fighters[channel.actor]
        return channel.ended_at_ms is None and actor.hp>0 and actor.life_generation==channel.life_generation and actor.action_by_id(channel.action_id) is not None

    def active(self,name):return tuple(c for c in self.channels.values() if c.actor==name and self.live(c))
    def handles(self,name):return self.enabled and bool(self.active(name))

    def start(self,actor,action,*,tag,kind,base,until_ms):
        if not self.enabled:raise UnsupportedMechanicError('Shared continuous effort is not enabled')
        value=EffortInput('validation',kind,base);until=finite(until_ms,'Effort expiry')
        if (actor.hp<=0 or actor.action_by_id(action.id) is not action or action.life_generation!=actor.life_generation
                or until<=self.world.time or not isinstance(tag,str) or not tag):
            raise ValueError('Effort channel needs an owned living action, tag and future expiry')
        channel=EffortChannel('effort:'+str(next(self.ids)),actor.id,actor.life_generation,action.id,tag,kind,
            value.base,self.world.time,until)
        self.channels[channel.id]=channel;self.caches.pop(actor.id,None)
        self.world.push(until,'continuous_effort_expired',{'actor':actor.id,'channel_id':channel.id},priority=0)
        self.world.log('continuous_effort_started',channel=channel.record())
        return channel

    def end(self,channel,reason):
        if channel.ended_at_ms is not None:return
        channel.ended_at_ms=self.world.time;channel.end_reason=reason;self.caches.pop(channel.actor,None)
        actor=self.world.fighters[channel.actor]
        if not self.handles(actor.id) and self.world.mobile_sprint_effort(actor.id):
            self.world.motion[actor.id]['sprint_anchor']=(self.world.time,actor.dyspnea)
        self.world.log('continuous_effort_ended',channel=channel.record())

    def action_cancelled(self,actor,action,reason):
        for channel in self.channels.values():
            if channel.actor==actor.id and channel.action_id==action.id:self.end(channel,reason)

    def settle(self):
        for channel in self.channels.values():
            if channel.ended_at_ms is None and (not self.live(channel) or self.world.time>=channel.expiry_ms):
                self.end(channel,'duration_expired' if self.world.time>=channel.expiry_ms else 'owned_action_or_life_ended')

    def event_live(self,kind,p):
        if kind=='continuous_effort_expired':return self.live(self.channels[p['channel_id']])
        item=self.caps[p['cap_id']];actor=self.world.fighters[p['actor']]
        return item['status']=='queued' and actor.hp>0 and actor.life_generation==item['life_generation']

    def process(self,kind,p):
        if not self.event_live(kind,p):return
        if kind=='continuous_effort_expired':return self.end(self.channels[p['channel_id']],'duration_expired')
        item=self.caps[p['cap_id']];item['status']='applied';actor=self.world.fighters[p['actor']]
        actor.disorientation+=200
        self.world.extend_parallel_gatherings(actor,D(200),-1)
        self.world.log('maximum_dyspnea_trigger',actor=actor.id,added_disorientation=D(200),source='continuous_effort')
        self.world.request_decision(actor.id,self.world.time)

    def _inputs(self,name):
        values=[EffortInput(c.id,c.kind,c.base) for c in self.active(name) if self.world.bindings.channel_enabled(c)]
        if self.world.mobile_sprint_effort(name):
            actor=self.world.fighters[name]
            values.append(EffortInput('sprint:'+name+':'+str(actor.life_generation),'squared',
                dec(self.world._sprint_values(actor)['base_continuous_dyspnea_per_second'])))
        return tuple(sorted(values,key=lambda i:i.id))

    def _cache(self,name):
        w=self.world;actor=w.fighters[name];inputs=self._inputs(name);old=self.caches.get(name);now=w.time
        key=(actor.life_generation,inputs,tuple((c.id,c.expiry_ms) for c in self.active(name)))
        if (old is not None and old['key']==key and old['plan'].begin<=now<old['plan'].end
                and old['consumed_until_ms']==now and abs(old['plan'].at(now)[0]-actor.dyspnea)<=D('1e-18')):return old
        end=min((c.expiry_ms for c in self.active(name)),default=now+250);end=min(end,now+250)
        if end<=now:raise ValueError('An expired effort channel must settle before preparing another interval')
        plan=build_effort_plan(now,end,actor.dyspnea,inputs,precision=w.precision)
        old={'key':key,'plan':plan,'consumed_until_ms':now,'channel_initial':{c.id:c.gained for c in self.active(name)},
            'sprint_initial':actor.metrics.get('sprint_dyspnea_gained',D(0))}
        self.caches[name]=old;return old

    def _fatigue_boundary(self,name,plan,end):
        actor=self.world.fighters[name];now=self.world.time
        def margin(time):
            elapsed=time-now
            limit=max(D(0),100-(max(D(0),actor.disorientation-elapsed)+max(D(0),actor.instability-elapsed))/10)
            return plan.at(time)[0]-limit
        if margin(now)>=0:return now
        if margin(end)<0:return end
        low,high=now,end
        for _ in range(self.world.precision*4):
            if high-low<=D('1e-25'):break
            middle=(low+high)/2
            if margin(middle)>=0:high=middle
            else:low=middle
        return high

    def prepare(self,end):
        if not self.enabled:return end
        self.settle();finish=end;w=self.world
        controllers={r['controller'] for r in w.grapple_links.links.values() if r['status']=='active'}
        for name,actor in w.fighters.items():
            if not self.handles(name):continue
            cache=self._cache(name);plan=cache['plan'];stop=min(finish,plan.end)
            if plan.cap_ms is not None and plan.cap_ms>=w.time:stop=min(stop,plan.cap_ms)
            if name in controllers:stop=self._fatigue_boundary(name,plan,stop)
            finish=min(finish,stop)
        return finish

    def forecast(self,name,end):
        """Return the authoritative prefix plan, or a free/sprint-only forecast.

        A live grapple blocks ordinary recovery on both sides, so an actor
        without active effort has constant D during an escape comparison.
        """
        if self.handles(name):return self._cache(name)['plan']
        return build_effort_plan(self.world.time,end,self.world.fighters[name].dyspnea,
            self._inputs(name),precision=self.world.precision)

    def advance(self,actor,begin,end):
        cache=self.caches[actor.id];plan=cache['plan']
        if cache['consumed_until_ms']!=begin or end<begin or end>plan.end:
            raise ValueError('Effort must consume one increasing plan prefix')
        if end==begin:return
        before=actor.dyspnea;after,gains=plan.at(end);_,prior=plan.at(begin)
        details=[]
        for item,gain,old_gain in zip(plan.inputs,gains,prior):
            amount=max(D(0),gain-old_gain)
            if item.id.startswith('sprint:'):
                actor.metrics['sprint_dyspnea_gained']=cache['sprint_initial']+gain
                if amount:self.world.log('sprint_dyspnea_gained',actor=actor.id,interval_start_ms=begin,interval_end_ms=end,
                    amount=amount,base_rate_per_second=item.base,after=after,shared_effort=True)
            else:
                channel=self.channels[item.id];channel.gained=cache['channel_initial'][item.id]+gain
            details.append({'channel_id':item.id,'kind':item.kind,'base':item.base,'amount':amount})
        actor.dyspnea=after;cache['consumed_until_ms']=end
        self.world.log('continuous_effort_paid',actor=actor.id,life_generation=actor.life_generation,
            interval_start_ms=begin,interval_end_ms=end,before=before,after=after,channels=details)
        if before<100 and after==100:
            if self.world.mobile_sprint_effort(actor.id):self.world._schedule_sprint_exhaustion(actor)
            else:
                identity='effort-cap:'+str(next(self.cap_ids))
                self.caps[identity]={'actor':actor.id,'life_generation':actor.life_generation,'time_ms':end,'status':'queued'}
                self.world.push(end,'continuous_effort_cap',{'actor':actor.id,'cap_id':identity},priority=4)

    def result(self):
        return {'continuous_effort_rules':self.world.combat_locomotion_input['continuous_effort'],
            'continuous_effort_channels':[c.record() for c in self.channels.values()]} if self.enabled else {}
