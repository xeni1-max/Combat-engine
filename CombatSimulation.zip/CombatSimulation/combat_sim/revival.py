"""Death-triggered, generation-bound abilities using the shared life transition.

This controller is deliberately separate from living owned actions. It owns
an authored attempt and finite charge stock, not body/hand locks or projectiles.
"""
from copy import deepcopy
from decimal import Decimal as D
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite


class DeathRevival:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        if self.enabled and (definition!={'mode':'death_revival_v1'} or not world.life_cycles.enabled):
            raise UnsupportedMechanicError('Death revival requires current actor-life rules')
        self.ids=count(1);self.abilities={};self.attempts={};self.pending={};self.deaths=set()

    def attach(self):
        if not self.enabled:return
        for actor in self.world.fighters.values():
            configs=actor.profile.get('automatic_abilities',{})
            for ability,cfg in configs.items():
                if not isinstance(ability,str) or not ability:raise ValueError('Automatic ability needs an identity')
                if cfg.get('execution_model')!='death_revival':
                    continue
                if (cfg.get('trigger')!='death' or cfg.get('hp_snapshot')!='eligible_damage_at_death'
                        or cfg.get('blocked_completion')!='fail_without_retry'
                        or cfg.get('charge_policy')!='finite_encounter_stock'
                        or cfg.get('shield_damage_eligible') is not False
                        or cfg.get('dyspnea',{}).get('kind')!='none'):
                    raise UnsupportedMechanicError('Unsupported revival trigger/snapshot/charge/effort rules')
                for key in ('active_ms','cooldown_ms','damage_history_window_ms','hp_per_eligible_damage'):
                    finite(cfg[key],key,positive=True)
                if type(cfg['charges']) is not int or cfg['charges']<=0:
                    raise ValueError('Revival charges must be a positive integer')
                if actor.id in self.abilities:
                    raise UnsupportedMechanicError('Multiple death revival abilities need an explicit trigger policy')
                self.world.cooldown_system.register_background(actor,ability,continue_while_dead=True)
                self.abilities[actor.id]={'ability':ability,'definition':deepcopy(cfg),'charges':cfg['charges']}
                actor.metrics.update(revival_attempts=0,revivals_completed=0,revivals_blocked=0,
                    revivals_superseded=0,hp_restored_by_revival=D(0))

    def on_death(self,actor):
        state=self.abilities.get(actor.id)
        key=(actor.id,actor.life_generation)
        if state is None or key in self.deaths:return
        self.deaths.add(key)
        world=self.world;cfg=state['definition'];ability=state['ability']
        history=world.applied_damage.history
        history.observe_until(world.time)
        basis=history.amount(actor=actor.id,end=world.time,
            window_ms=cfg['damage_history_window_ms'],eligible_only=True)
        hp=min(dec(actor.profile['max_hp']),basis*dec(cfg['hp_per_eligible_damage']))
        clock=actor.cooldowns.clocks[ability]
        reason=('no_charges' if not state['charges'] else 'cooldown' if clock.remaining(world.time)
            else 'no_eligible_damage' if not hp else None)
        if reason is not None:
            world.log('revival_not_started',actor=actor.id,ability=ability,
                life_generation=actor.life_generation,reason=reason,charges=state['charges'],
                eligible_damage=basis,clock=clock.record(world.time))
            return
        identity='revival:'+str(next(self.ids))
        attempt={'id':identity,'actor':actor.id,'ability':ability,'life_generation':actor.life_generation,
            'started_at_ms':world.time,'due_at_ms':world.time+dec(cfg['active_ms']),
            'eligible_damage_at_death':basis,'restoration_hp':hp,'status':'active',
            'finished_at_ms':None,'end_reason':None}
        self.attempts[identity]=attempt;self.pending[actor.id]=identity
        state['charges']-=1;actor.metrics['revival_attempts']+=1
        clock.start(world.time,cfg['cooldown_ms'])
        world.push(attempt['due_at_ms'],'revival_completed',{'attempt_id':identity})
        world.log('revival_started',actor=actor.id,attempt=deepcopy(attempt),charges_remaining=state['charges'],
            cooldown=clock.record(world.time),dyspnea_cost=D(0))

    def live(self,payload):
        attempt=self.attempts.get(payload.get('attempt_id'))
        if attempt is None or attempt['status']!='active':return False
        actor=self.world.fighters[attempt['actor']]
        return actor.hp<=0 and actor.died_at_ms is not None and actor.life_generation==attempt['life_generation']

    def complete(self,payload):
        if not self.live(payload):return
        attempt=self.attempts[payload['attempt_id']];world=self.world
        actor=world.fighters[attempt['actor']]
        # Restoration notifies all controllers. Mark this attempt as resolving
        # so an independent restoration supersedes only genuinely pending work.
        attempt['status']='resolving'
        success=world.life_cycles.revive(actor.id,expected_generation=attempt['life_generation'],
            hp=attempt['restoration_hp'],source=attempt['id'])
        attempt.update(status='completed' if success else 'failed',finished_at_ms=world.time,
            end_reason='restored' if success else 'occupied_body_pose')
        self.pending.pop(actor.id,None)
        actor.metrics['revivals_completed' if success else 'revivals_blocked']+=1
        if success:actor.metrics['hp_restored_by_revival']+=attempt['restoration_hp']
        world.log('revival_completed' if success else 'revival_failed',actor=actor.id,
            attempt=deepcopy(attempt),life_generation=actor.life_generation,
            charges_remaining=self.abilities[actor.id]['charges'])

    def on_restored(self,actor):
        identity=self.pending.get(actor.id)
        if identity is None:return
        attempt=self.attempts[identity]
        if attempt['status']!='active':return
        attempt.update(status='superseded',finished_at_ms=self.world.time,end_reason='another_restoration')
        self.pending.pop(actor.id,None);actor.metrics['revivals_superseded']+=1
        self.world.log('revival_superseded',actor=actor.id,attempt=deepcopy(attempt),
            life_generation=actor.life_generation)

    def result(self):
        if not self.enabled:return {}
        return {'revival_rules':self.world.combat_locomotion_input['death_revival'],
            'revival_states':{name:{'ability':s['ability'],'charges_remaining':s['charges'],
                'pending_attempt_id':self.pending.get(name),
                'cooldown':self.world.fighters[name].cooldowns.clocks[s['ability']].record(self.world.time)}
                for name,s in sorted(self.abilities.items())},
            'revival_attempts':deepcopy(list(self.attempts.values()))}
