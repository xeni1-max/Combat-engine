"""Exact rational/square-root amounts, with Decimal used only for display."""

from dataclasses import dataclass
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from fractions import Fraction
from math import isqrt
from typing import Any

DISPLAY_CONTEXT = Context(prec=50, rounding=ROUND_HALF_EVEN)
RATIONAL_DISPLAY_CONTEXT = Context(prec=28, rounding=ROUND_HALF_EVEN)


def _fraction(value):
    return Fraction(str(value)) if isinstance(value, float) else Fraction(value)


@dataclass(frozen=True)
class ExactRootProduct:
    """An exact coefficient times sqrt(radicand)."""

    coefficient: Fraction
    radicand: Fraction

    def __post_init__(self):
        object.__setattr__(self, "coefficient", _fraction(self.coefficient))
        object.__setattr__(self, "radicand", _fraction(self.radicand))
        if self.radicand < 0:
            raise ValueError("Square-root radicand must be nonnegative")

    def as_fraction(self) -> Fraction | None:
        numerator = isqrt(self.radicand.numerator)
        denominator = isqrt(self.radicand.denominator)
        if numerator**2 == self.radicand.numerator and denominator**2 == self.radicand.denominator:
            return self.coefficient * Fraction(numerator, denominator)
        return None


@dataclass(frozen=True)
class ExactAmount:
    """A rational amount plus exact square-root terms; no gameplay rounding.

    Equal radicands combine and rational square roots reduce to fractions.
    This is arithmetic storage, not a general symbolic-algebra solver.
    """

    rational: Fraction = Fraction(0)
    roots: tuple[ExactRootProduct, ...] = ()

    def __post_init__(self):
        rational = _fraction(self.rational)
        terms = {}
        for root in self.roots:
            if root.coefficient == 0 or root.radicand == 0:
                continue
            value = root.as_fraction()
            if value is not None:
                rational += value
            else:
                terms[root.radicand] = terms.get(root.radicand, Fraction(0)) + root.coefficient
        object.__setattr__(self, "rational", rational)
        object.__setattr__(self, "roots", tuple(
            ExactRootProduct(coefficient, radicand)
            for radicand, coefficient in sorted(terms.items()) if coefficient
        ))

    @classmethod
    def of(cls, value):
        if isinstance(value, cls):
            return value
        if isinstance(value, ExactRootProduct):
            return cls(roots=(value,))
        return cls(_fraction(value))

    def __add__(self, other):
        other = ExactAmount.of(other)
        return ExactAmount(self.rational + other.rational, self.roots + other.roots)

    __radd__ = __add__

    def __neg__(self):
        return ExactAmount(-self.rational, tuple(ExactRootProduct(-root.coefficient, root.radicand) for root in self.roots))

    def __sub__(self, other):
        return self + -ExactAmount.of(other)

    def __rsub__(self, other):
        return ExactAmount.of(other) + -self

    def as_fraction(self):
        return self.rational if not self.roots else None

    def decimal_approximation(self):
        with localcontext(DISPLAY_CONTEXT):
            total = Decimal(self.rational.numerator) / Decimal(self.rational.denominator)
            for root in self.roots:
                coefficient = Decimal(root.coefficient.numerator) / Decimal(root.coefficient.denominator)
                radicand = Decimal(root.radicand.numerator) / Decimal(root.radicand.denominator)
                total += coefficient * radicand.sqrt()
            return total

    def expression(self):
        pieces = [str(self.rational)] if self.rational else []
        for root in self.roots:
            sign = "-" if root.coefficient < 0 else "+"
            term = f"({abs(root.coefficient)})*sqrt({root.radicand})"
            pieces.append((sign + " " + term) if pieces else (("-" if sign == "-" else "") + term))
        return " ".join(pieces) or "0"

    def to_record(self):
        if self.as_fraction() is not None:
            return number_record(self.rational)
        return {
            "exact_expression": self.expression(), "rational": str(self.rational),
            "root_terms": [{"coefficient": str(root.coefficient), "radicand": str(root.radicand)} for root in self.roots],
            "decimal_approx": str(self.decimal_approximation()), "decimal_precision_digits": 50,
        }


def number_record(value: Any) -> dict[str, Any]:
    if isinstance(value, (ExactAmount, ExactRootProduct)):
        return ExactAmount.of(value).to_record()
    value = _fraction(value)
    with localcontext(RATIONAL_DISPLAY_CONTEXT):
        approximate = Decimal(value.numerator) / Decimal(value.denominator)
    return {"exact": str(value), "decimal_approx": str(approximate)}


def amount_from_record(record) -> ExactAmount:
    if "exact" in record:
        return ExactAmount.of(record["exact"])
    if "rational" not in record or "root_terms" not in record:
        raise ValueError("Missing exact rational/root representation")
    return ExactAmount(Fraction(record["rational"]), tuple(
        ExactRootProduct(Fraction(term["coefficient"]), Fraction(term["radicand"]))
        for term in record["root_terms"]
    ))
