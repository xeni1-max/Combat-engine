"""Fixed surface attachments with collider identity and geometry lifetime."""
from dataclasses import dataclass
from itertools import count
from fractions import Fraction as F

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.distance_projection import FixedPoint
from combat_sim.mechanics.exact_ratio import ratio_text
from combat_sim.mechanics.velocity_projection import vector,number
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.box_motion import on_surface,footprint_contains,closest_surface_point


@dataclass(frozen=True)
class TerrainAnchorCandidate:
    collider_id: str
    collider_revision: int
    part: str
    position_m: tuple

    def __post_init__(self):
        if (any(not isinstance(x,str) or not x for x in (self.collider_id,self.part)) or
                type(self.collider_revision) is not int or self.collider_revision<0):raise ValueError('Invalid terrain anchor identity')
        object.__setattr__(self,'position_m',vector(self.position_m))


class TerrainAnchors:
    def __init__(self,world):
        self.world=world;self.rows={};self.points={};self.ids=count(1)

    def valid_candidate(self,candidate):
        if not isinstance(candidate,TerrainAnchorCandidate):return False
        w=self.world;registry=w.collider_system.registry
        if not registry.contact_live({'collider_id':candidate.collider_id,'collider_revision':candidate.collider_revision},'bodies',w.time):return False
        obj=registry.objects[candidate.collider_id]
        part=next((p for p in obj.parts if p.part==candidate.part),None)
        if part is None:return False
        if isinstance(part,OrientedCuboid):return on_surface(part,candidate.position_m)
        low,high=part.bounds;p=candidate.position_m
        return all(a<=x<=b for a,x,b in zip(low,p,high)) and any(x==a or x==b for a,x,b in zip(low,p,high))

    def below(self,actor,maximum_m):
        """Highest registered horizontal solid face below the actor's feet."""
        w=self.world;reference=vector(w.distance_constraints.reference(actor))
        maximum_m=number(maximum_m,positive=True)
        feet=min(b.bounds[0][2] for b in w.world_bodies[actor]);x,y,_=reference;found=[]
        for identity,obj in sorted(w.collider_system.registry.objects.items()):
            if not obj.active(w.time) or not obj.policy.bodies:continue
            for part in obj.parts:
                low,high=part.bounds
                inside=(footprint_contains(part,(x,y,high[2])) if isinstance(part,OrientedCuboid) else
                    low[0]<=x<=high[0] and low[1]<=y<=high[1])
                if inside and high[2]<=feet+F(CONTACT_DISTANCE_EPS_M):
                    p=(x,y,high[2])
                    if sum((a-b)**2 for a,b in zip(reference,p))<=maximum_m**2:
                        found.append((high[2],identity,part.part,p,obj.collision_revision))
        if not found:return None
        z,identity,part,p,revision=min(found,key=lambda v:(-v[0],v[1],v[2]))
        return TerrainAnchorCandidate(identity,revision,part,p)

    def from_projectile_contact(self,packet):
        """Project a witnessed sphere contact onto that actual registered face."""
        if packet.get('collision_kind')!='terrain' or 'collider_id' not in packet:return None
        registry=self.world.collider_system.registry
        if not registry.contact_live(packet,'projectiles',self.world.time):return None
        obj=registry.objects[packet['collider_id']]
        if not obj.policy.bodies:return None
        parts=set(packet.get('hit_parts',()))
        part=next((p for p in sorted(obj.parts,key=lambda p:p.part) if p.part in parts),None)
        if part is None:raise ValueError('Surface anchoring needs an actual contacted collider part')
        low,high=part.bounds;centre=vector(packet['location_m'])
        if isinstance(part,OrientedCuboid):
            candidate=TerrainAnchorCandidate(obj.identity.id,obj.collision_revision,part.part,closest_surface_point(part,centre))
            return candidate if self.valid_candidate(candidate) else None
        point=tuple(min(b,max(a,x)) for a,x,b in zip(low,centre,high))
        if not any(x in (a,b) for a,x,b in zip(low,point,high)):
            # A new solid can materialize around an existing shot. Choose its
            # nearest physical face; axis/side ordering resolves exact ties.
            _,axis,_,coordinate=min((abs(centre[i]-face),i,side,face)
                for i in range(3) for side,face in enumerate((low[i],high[i])))
            point=tuple(coordinate if i==axis else x for i,x in enumerate(point))
        candidate=TerrainAnchorCandidate(obj.identity.id,obj.collision_revision,part.part,point)
        return candidate if self.valid_candidate(candidate) else None

    def attach(self,candidate,*,source):
        if not self.valid_candidate(candidate):raise ValueError('Terrain anchor candidate is stale or not on a solid face')
        if not isinstance(source,str) or not source:raise ValueError('Terrain anchor needs a source identity')
        w=self.world
        identity='terrain-anchor:'+str(next(self.ids))
        while identity in w.fighters or identity in w.collider_system.registry.objects:
            identity='terrain-anchor:'+str(next(self.ids))
        point=FixedPoint(identity,candidate.position_m);self.points[identity]=point
        row={'id':identity,'collider_id':candidate.collider_id,'collider_revision':candidate.collider_revision,
            'part':candidate.part,'position_m':tuple(map(dec,point.position_m)),
            'exact_position_m':tuple(map(ratio_text,point.position_m)),'source':source,
            'created_at_ms':w.time,'status':'active'}
        self.rows[identity]=row;w.log('terrain_anchor_attached',**row)
        return identity

    def invalid_reason(self,identity):
        row=self.rows[identity];obj=self.world.collider_system.registry.objects.get(row['collider_id'])
        if obj is None:return 'anchor_missing'
        if not obj.active(self.world.time):
            return 'anchor_'+('expired' if obj.status=='active' else obj.status)
        if obj.collision_revision!=row['collider_revision']:return 'anchor_geometry_changed'
        if not obj.policy.bodies:return 'anchor_not_solid'
        return None

    def live(self,identity):
        return identity in self.rows and self.rows[identity]['status']=='active' and self.invalid_reason(identity) is None

    def end(self,identity,reason):
        row=self.rows.get(identity)
        if row is None or row['status']!='active':return False
        row.update(status='ended',ended_at_ms=self.world.time,end_reason=reason)
        if row.get('distance_id'):self.world.distance_constraints.release(row['distance_id'],reason=reason)
        self.world.log('terrain_anchor_ended',anchor_id=identity,reason=reason)
        return True

    def settle(self):
        for identity,row in self.rows.items():
            if row['status']=='active':
                reason=self.invalid_reason(identity)
                if reason:self.end(identity,reason)

    def result(self):return {'terrain_anchors':list(self.rows.values())} if self.rows else {}
