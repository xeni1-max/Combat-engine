"""Numerical passive-target damage benchmark, separate from exact encounter runners.

Analytic interval integrals use fixed Decimal precision. No gameplay rounding
or AI is introduced. Observation ends at HP=0; this is not a death/victory rule.
"""
from copy import deepcopy
from decimal import Context,Decimal,ROUND_CEILING,ROUND_HALF_EVEN,localcontext
from fractions import Fraction
import heapq

from combat_sim.benchmark_policies import RepeatWhenReady
from combat_sim.mechanics import blunt,heat,poison,qard,slash,venom,projectile_damage
from combat_sim.mechanics.status import mitigate_status
from combat_sim.mechanics.timing import impact_time_from_activation,self_effect_time_from_activation
from combat_sim.models import UnsupportedMechanicError,as_fraction

ABILITIES={'3E5_1bc':('3E5','1b'),'1E1_1':('1E1','1'),'2E4_1':('2E4','1'),
           '1E1_4':('1E1','4'),'1E2_1':('1E2','1'),'1E1_Ultimate':('1E1','Ultimate')}
LABELS={'3E5_1bc':'3E5 ability 1 b/c','1E1_1':'1E1 ability 1','2E4_1':'2E4 ability 1',
        '1E1_4':'1E1 ability 4','1E2_1':'1E2 ability 1','1E1_Ultimate':'1E1 Ultimate'}
D=Decimal
ROOT_TIME_TOLERANCE_MS=D('1e-25')


def dec(value):
    if isinstance(value,Decimal): return value
    f=as_fraction(value)
    return D(f.numerator)/D(f.denominator)


def root_integral(coefficient,q0,q1,seconds):
    q0=max(D(0),q0);q1=max(D(0),q1)
    if seconds<=0 or coefficient==0:return D(0)
    if q0==q1:return coefficient*q0.sqrt()*seconds
    return 2*coefficient*seconds*(q1*q1.sqrt()-q0*q0.sqrt())/(3*(q1-q0))


def root_curve_integral(coefficient,start,leave,expiry,begin,end,decay):
    begin=max(begin,start);end=min(end,expiry)
    if end<=begin:return D(0)
    total=D(0)
    if begin<leave:
        stop=min(end,leave)
        total+=root_integral(coefficient,(begin-start)/1000,(stop-start)/1000,(stop-begin)/1000)
    if end>leave:
        first=max(begin,leave); exposure=(leave-start)/1000
        total+=root_integral(coefficient,exposure-decay*(first-leave)/1000,
                             exposure-decay*(end-leave)/1000,(end-first)/1000)
    return total


class _Run:
    def __init__(self,profiles,ability_key,target_key,shielded,duration_ms,distance_m,precision,sample_interval_ms=100):
        self.profiles=profiles;self.key=ability_key;self.target_key=target_key
        actor,ability_id=ABILITIES[ability_key];self.actor=actor;self.ability_id=ability_id
        self.ability=profiles[actor]['abilities'][ability_id]
        self.target=profiles[target_key];self.hp=dec(self.target['max_hp']);self.initial_hp=self.hp
        self.armor=dec(self.target['base_armor']);self.initial_armor=self.armor
        self.shield=dec(self.target['shield_capacity']) if shielded else D(0);self.initial_shield=self.shield
        self.regen_delay=dec(self.target['shield_regeneration']['delay_ms'])
        self.horizon=D(duration_ms);self.distance=dec(distance_m);self.precision=precision;self.sample_interval_ms=sample_interval_ms
        self.time=D(0);self.actor_o=D(0);self.actor_u=D(0);self.target_o=D(0);self.target_u=D(0)
        self.hp_loss=D(0);self.shield_loss=D(0);self.nominal_components={};self.nominal_direct=D(0)
        self.effects=[];self.beams=[];self.queue=[];self.serial=0;self.events=[];self.curve=[];self.regen_losses=[]
        self.starts=0;self.releases=0;self.hits=0;self.reloads=0;self.hp_zero=None;self.stop=False
        self.ammo=int(self.ability['magazine_capacity']) if self.key in ('1E2_1','1E1_Ultimate') else None
        self.ready=D(0);self.reloading=False;self.reload_phase='none';self.policy=RepeatWhenReady(self.key)
        if self.key=='3E5_1bc':self.profile=self.ability
        else:self.profile=deepcopy(profiles[actor]['timing_profiles'][self.ability['timing_profile']])
        if self.key=='1E1_Ultimate':self.profile['preparation_ms']=0

    def push(self,time,priority,kind,payload=None):
        self.serial+=1;heapq.heappush(self.queue,(dec(time),priority,self.serial,kind,payload))

    def state(self):
        return {'hp':str(self.hp),'armor':str(self.armor),'shield':str(self.shield),
                'disorientation':str(self.target_o),'instability':str(self.target_u)}

    def log(self,kind,**details):
        self.events.append({'time_ms':str(self.time),'type':kind,**details})

    def sample(self,label):
        self.curve.append({'time_ms':str(self.time),'hp_damage':str(self.hp_loss),'shield_damage':str(self.shield_loss),
                           'hp_remaining':str(self.hp),'shield_remaining':str(self.shield),'label':label})

    def self_effect(self,n):
        self.actor_o+=dec(n['disorientation']);self.actor_u+=dec(n['instability'])
        self.log('self_status_applied',listed=n,actor_disorientation=str(self.actor_o),actor_instability=str(self.actor_u),mitigation=False)

    def target_effect(self,n,armor):
        for field in ('disorientation','instability'):
            increment=mitigate_status(n[field],self.target['max_hp'],armor,self.target['status_resistance'])
            if field=='disorientation':self.target_o+=increment
            else:self.target_u+=increment
        self.log('target_status_applied',listed=n,pre_hit_armor=str(armor),state=self.state())

    def add_root_effect(self,kind,coefficient,duration_ms,source):
        duration=dec(duration_ms);effect={'id':f'{kind}-{self.hits}-{len(self.effects)}','kind':kind,'coefficient':coefficient,
                                         'start':self.time,'leave':self.time+duration,'expiry':self.time+2*duration,'source':source}
        self.effects.append(effect);self.push(effect['leave'],1,'effect_exposure_ended',effect['id']);self.push(effect['expiry'],1,'effect_expired',effect['id'])
        self.log('continuous_effect_started',effect={k:str(v) if isinstance(v,Decimal) else v for k,v in effect.items()})

    def add_bleed(self,y):
        if y<=0:return
        effect={'id':f'bleed-{self.hits}','kind':'bleeding','y':y,'start':self.time,'expiry':self.time+8000}
        self.effects.append(effect);self.push(effect['expiry'],1,'effect_expired',effect['id'])
        self.log('bleeding_started',bleed_id=effect['id'],basis_y=str(y),expires_at_ms=str(effect['expiry']))

    def components(self,begin,end):
        values={}
        for effect in self.effects:
            if effect['kind']=='bleeding':
                a=max(begin,effect['start']);b=min(end,effect['expiry'])
                if b<=a:continue
                t0=(a-effect['start'])/1000;t1=(b-effect['start'])/1000
                amount=effect['y']*(8*(t1-t0)-(t1*t1-t0*t0)/2)/320
            else:amount=root_curve_integral(effect['coefficient'],effect['start'],effect['leave'],effect['expiry'],begin,end,D(1))
            values[effect['kind']]=values.get(effect['kind'],D(0))+amount
        shield=D(0)
        for beam in self.beams:
            if beam['mode']=='ended':continue
            if beam['mode']=='shield':
                shield+=root_curve_integral(dec(self.ability['heat_output']),beam['start'],beam['end'],beam['expiry'],begin,end,dec(self.ability['k']))
            else:
                coefficient=dec(heat.heat_coefficient(self.ability['heat_output'],self.armor,self.target['resistances']['heat'],self.ability['k']))
                amount=root_curve_integral(coefficient,beam['hp_start'],beam['end'],beam['expiry'],begin,end,dec(self.ability['k']))
                values['heat']=values.get('heat',D(0))+amount
        return values,shield

    def bisect(self,begin,end,budget,shield=False):
        low=begin;high=end
        for _ in range(220):
            if high-low<=ROOT_TIME_TOLERANCE_MS:break
            middle=(low+high)/2;parts,raw=self.components(begin,middle)
            amount=raw if shield else sum(parts.values(),D(0))
            if amount>=budget:high=middle
            else:low=middle
        return low,high

    def decay(self,elapsed):
        self.actor_o=max(D(0),self.actor_o-elapsed);self.actor_u=max(D(0),self.actor_u-elapsed)
        self.target_o=max(D(0),self.target_o-elapsed);self.target_u=max(D(0),self.target_u-elapsed)

    def advance(self,end):
        while self.time<end and not self.stop:
            begin=self.time;parts,raw_shield=self.components(begin,end);finish=end;hp_boundary=None;shield_boundary=None
            if self.shield>0 and raw_shield>=self.shield:
                shield_boundary=self.bisect(begin,end,self.shield,True);finish=shield_boundary[1]
                parts,raw_shield=self.components(begin,finish)
            hp_amount=sum(parts.values(),D(0))
            if hp_amount>=self.hp and hp_amount>0:
                hp_boundary=self.bisect(begin,finish,self.hp);finish=hp_boundary[1]
                parts,raw_shield=self.components(begin,finish);hp_amount=sum(parts.values(),D(0))
            before=self.state();applied=min(self.hp,hp_amount);shield_applied=min(self.shield,raw_shield)
            self.hp-=applied;self.hp_loss=self.initial_hp-self.hp;self.shield-=shield_applied;self.shield_loss=self.initial_shield-self.shield
            for key,value in parts.items():self.nominal_components[key]=self.nominal_components.get(key,D(0))+value
            self.decay(finish-begin);self.time=finish
            if hp_amount or shield_applied:
                self.log('continuous_interval',interval_start_ms=str(begin),interval_end_ms=str(finish),
                         nominal_hp_by_effect={k:str(v) for k,v in parts.items()},applied_hp=str(applied),applied_shield=str(shield_applied),
                         state_before=before,state_after=self.state(),payment='Analytic continuous integral; not a damage tick')
            if shield_applied:
                self.regen_losses.append({'kind':'continuous_heat_loss','interval_start_ms':str(begin),'interval_end_ms':str(finish),
                    'amount':str(shield_applied),'eligible_interval_start_ms':str(begin+self.regen_delay),'eligible_interval_end_ms':str(finish+self.regen_delay),
                    'history':'Loss distributed continuously over interval; eligibility shifts each infinitesimal loss by the documented profile delay'})
            if hp_boundary:
                self.hp_zero={'lower_ms':str(hp_boundary[0]),'upper_ms':str(hp_boundary[1]),'reason':'Starting HP exhausted; benchmark observation ends'}
                self.stop=True;self.log('benchmark_hp_budget_exhausted',bracket=self.hp_zero,state=self.state());self.sample('observation_stop');return
            if shield_boundary and self.shield==0:
                self.log('shield_broken_during_heat',time_bracket={'lower_ms':str(shield_boundary[0]),'upper_ms':str(shield_boundary[1])})
                for beam in self.beams:
                    if beam['mode']!='shield':continue
                    if self.time<beam['end']:
                        beam['mode']='hp';beam['hp_start']=self.time
                        beam['expiry']=beam['end']+(beam['end']-self.time)/dec(self.ability['k'])
                        self.push(beam['expiry'],1,'heat_expired',beam['id'])
                        self.log('hp_heat_exposure_started',beam_id=beam['id'],exposure_seconds='0')
                    else:
                        beam['mode']='ended';self.log('shield_residual_terminated',beam_id=beam['id'],transferred_hp_damage='0')
            if finish==end:break
        self.time=end

    def shield_hit(self,amount,shot):
        if amount<=0:return
        self.regen_losses.append({'kind':'impact','shot':shot,'loss_at_ms':str(self.time),'amount':str(amount),
                                  'eligible_at_ms':str(self.time+self.regen_delay)})

    def impact(self,kind,payload):
        self.hits+=1;armor=self.armor;before=self.state();raw=dec(payload['incoming'])
        if kind in ('blunt','venom'):raw=max(D(0),raw-self.actor_u/10)
        absorbed=min(raw,self.shield);left=raw-absorbed;self.shield-=absorbed;self.shield_loss=self.initial_shield-self.shield
        self.shield_hit(absorbed,payload['index'])
        if kind=='qard':
            y=dec(qard.raw_post_mitigation_damage(left,armor,self.target['resistances']['qard'])) if left else D(0)
            y=max(D(0),y);loss=D(0)
        elif kind=='blunt':
            y=dec(blunt.post_mitigation_damage(left,armor)) if left else D(0)
            loss=dec(blunt.armor_reduction(left,armor)) if left else D(0)
        else:
            calculation=slash.calculate_impact(raw,armor,self.ability['piercing'],dec(before['shield']))
            y=dec(calculation.hp_damage);loss=dec(calculation.armor_loss)
        applied=min(self.hp,y);self.hp-=applied;self.hp_loss=self.initial_hp-self.hp;self.nominal_direct+=y
        self.armor=max(D(0),armor-loss)
        self.log('impact_resolved',damage_kind=kind,source_index=payload['index'],incoming=str(raw),shield_absorbed=str(absorbed),
                 damage_left_after_shield=str(left),pre_hit_armor=str(armor),nominal_hp=str(y),applied_hp=str(applied),
                 nominal_armor_loss=str(loss),state_before=before,state_after=self.state(),source=self.ability['source'])
        if kind=='blunt':self.target_effect(self.profiles['3E5']['benchmark_attack']['target_effects'],armor)
        else:self.target_effect(self.ability['target_effects'],armor)
        if kind in ('slash','venom'):self.add_bleed(y)
        if kind=='venom':
            coefficient=dec(venom.venomous_damage_rate(left,armor,self.ability['piercing'],self.ability['toxicity'],self.target['resistances']['toxin'],1,0).coefficient)
            if coefficient:self.add_root_effect('venom',coefficient,self.ability['poison_exposure_ms'],{'pre_hit_armor':str(armor),'post_shield_d':str(left),'source':venom.SOURCE})
            self.self_effect(self.ability['self_effects'])
            blade=self.ability['replacement_blade'];self.push(self.time+blade['grab_delay_ms'],2,'blade_grab_started')
        elif kind=='blunt':self.self_effect(self.profiles['3E5']['benchmark_attack']['self_effects'])
        if self.hp==0:
            self.hp_zero={'lower_ms':str(self.time),'upper_ms':str(self.time),'reason':'Starting HP exhausted on impact; benchmark observation ends'}
            self.stop=True;self.log('benchmark_hp_budget_exhausted',bracket=self.hp_zero,state=self.state())

    def decide(self):
        decision=self.policy.choose(self.ammo);self.log('action_selected',decision=decision,ammo=self.ammo,actor_o=str(self.actor_o),actor_u=str(self.actor_u))
        if decision=='stop_empty':return
        if decision=='reload':
            self.reloading=True;self.reload_phase='gathering';self.reloads+=1
            g=int(self.actor_o.to_integral_value(rounding=ROUND_CEILING))+int(self.ability['reload_gathering_ms'])
            self.log('reload_requested',gathering_ms=g,active_ms=self.ability['reload_active_ms'])
            self.push(self.time+g,2,'reload_active_started');self.push(self.time+g+self.ability['reload_active_ms'],0,'reload_completed');return
        index=self.starts;self.starts+=1
        if self.key=='1E1_4':
            g=int((dec(self.profile['gathering_ms'])+self.actor_o).to_integral_value(rounding=ROUND_CEILING))
            self.push(self.time+g,3,'heat_started',index);self.push(self.time+self.ability['cooldown_ms'],4,'decision')
            self.log('ability_started',source_index=index,beam_start_ms=str(self.time+g),cooldown_anchor='activation_start');return
        if self.key=='3E5_1bc':profile=self.ability
        else:profile=self.profile
        distance=self.distance if profile['impact_timing']=='projectile' else None
        impact,timing=impact_time_from_activation(int(self.time),profile,distance,disorientation_at_gathering_start=self.actor_o)
        self.log('ability_started',source_index=index,component=self.policy.component(index),timing=timing)
        incoming=self.ability.get('pre_mitigation_damage',0)
        if self.key=='1E2_1':
            f=self.ability['range_falloff'];incoming=projectile_damage.damage_after_distance(incoming,self.distance,f['damage_loss'],f['distance_m'])
        payload={'index':index,'incoming':dec(incoming),'timing':timing}
        if self.key in ('3E5_1bc','2E4_1'):
            self.push(impact,5,'impact',payload)
            if self.key=='3E5_1bc':self.push(timing['active_end_ms'],4,'decision')
        else:
            self_time,_=self_effect_time_from_activation(int(self.time),profile,'middle_of_active',disorientation_at_gathering_start=self.actor_o)
            self.push(self_time,2,'self_firing_effect');self.push(timing['projectile_release_time_ms'],3,'release',payload)
            self.push(impact,5,'gas_detonated' if self.key=='1E1_Ultimate' else 'impact',payload)
            if self.key=='1E1_1':self.push(impact+self.ability['delayed_area']['delay_ms'],5,'impact',payload)

    def process(self,event,payload):
        if event=='decision':self.decide()
        elif event=='self_firing_effect':self.self_effect(self.ability['self_effects'])
        elif event=='release':
            self.releases+=1
            if self.ammo is not None:self.ammo-=1
            self.ready=self.time+self.ability['weapon_cooldown_ms']
            self.log('projectile_released',source_index=payload['index'],ammo=self.ammo,weapon_ready_at_ms=str(self.ready))
            self.push(self.ready,0,'weapon_cooldown_completed')
            self.push(self.time if self.key=='1E2_1' and self.ammo==0 else self.ready,4,'decision')
        elif event=='weapon_cooldown_completed':self.log(event,ammo=self.ammo,reloading=self.reloading)
        elif event=='reload_active_started':self.reload_phase='active';self.log(event)
        elif event=='reload_completed':
            self.reloading=False;self.reload_phase='none';self.ammo=int(self.ability['magazine_capacity']);self.log(event,ammo=self.ammo)
            self.push(max(self.time,self.ready),4,'decision')
        elif event=='blade_grab_started':
            self.log(event);self.push(self.time+self.ability['replacement_blade']['active_grab_ms'],0,'blade_grab_completed')
        elif event=='blade_grab_completed':self.log(event);self.push(self.time,4,'decision')
        elif event=='impact':
            kind={'3E5_1bc':'blunt','1E1_1':'qard','2E4_1':'venom','1E2_1':'slash'}[self.key]
            self.impact(kind,payload)
        elif event=='gas_detonated':
            self.hits+=1;self.log(event,source_index=payload['index'],cloud_duration_ms=self.ability['cloud_duration_ms'])
            self.target_effect(self.ability['target_effects'],self.armor)
            coefficient=dec(poison.poison_coefficient(self.ability['toxicity'],self.target['resistances']['toxin']))
            self.add_root_effect('poison',coefficient,self.ability['cloud_duration_ms'],poison.SOURCE)
        elif event=='heat_started':
            beam={'id':payload,'start':self.time,'end':self.time+self.ability['beam_duration_ms'],
                  'expiry':self.time+dec(self.ability['beam_duration_ms'])*(1+1/dec(self.ability['k'])),
                  'mode':'shield' if self.shield>0 else 'hp','hp_start':self.time}
            self.beams.append(beam);self.log(event,beam_id=payload,mode=beam['mode'])
            self.push(beam['end'],1,'heat_active_ended',payload);self.push(beam['expiry'],1,'heat_expired',payload)
        elif event in ('heat_active_ended','heat_expired'):
            for beam in self.beams:
                if beam['id']==payload and beam['mode']!='ended' and (event!='heat_expired' or self.time>=beam['expiry']):
                    if event=='heat_expired':beam['mode']='ended'
                    self.log(event,beam_id=payload)
        elif event in ('effect_exposure_ended','effect_expired'):
            self.log(event,effect_id=payload)
            if event=='effect_expired':self.effects[:]=[e for e in self.effects if e['id']!=payload]
        elif event=='weapon_swap_completed':self.log(event);self.push(self.time,4,'decision')

    def run(self):
        if self.key=='1E1_Ultimate':
            self.log('weapon_swap_started');self.push(self.profiles['1E1']['timing_profiles']['Ultimate']['preparation_ms'],0,'weapon_swap_completed')
        else:self.push(0,4,'decision')
        for point in range(0,int(self.horizon)+1,self.sample_interval_ms):self.push(point,20,'sample')
        self.sample('initial')
        while self.queue and self.queue[0][0]<=self.horizon:
            time,_,_,event,payload=heapq.heappop(self.queue)
            self.advance(time)
            if self.stop:break
            self.sample('before_'+event)
            if event!='sample':self.process(event,payload)
            self.sample('after_'+event)
            if self.stop:break
        if not self.stop:self.advance(self.horizon)
        observed=self.time;self.sample('observed_end')
        if observed<self.horizon:
            for point in range(int(observed//self.sample_interval_ms)*self.sample_interval_ms+self.sample_interval_ms,int(self.horizon)+1,self.sample_interval_ms):
                self.curve.append({'time_ms':str(point),'hp_damage':str(self.hp_loss),'shield_damage':str(self.shield_loss),
                    'hp_remaining':str(self.hp),'shield_remaining':str(self.shield),'label':'HP_budget_already_exhausted_no_further_simulation'})
        return {'ability':self.key,'ability_label':LABELS[self.key],'target':self.target_key,'shielded':self.initial_shield>0,
            'duration_ms':str(self.horizon),'projectile_path_m':str(self.distance),'precision_digits':self.precision,'numeric_values':'Decimal approximations, not exact fractions','sample_interval_ms':self.sample_interval_ms,
            'attacker_instance':'attacker:'+self.actor,'defender_instance':'defender:'+self.target_key,
            'initial_state':{'hp':str(self.initial_hp),'armor':str(self.initial_armor),'shield':str(self.initial_shield),'resistances':deepcopy(self.target['resistances'])},
            'metrics':{'hp_damage':str(self.hp_loss),'shield_damage':str(self.shield_loss),'total_damage':str(self.hp_loss+self.shield_loss),
                'final_hp':str(self.hp),'final_armor':str(self.armor),'final_shield':str(self.shield),'armor_lost':str(self.initial_armor-self.armor),
                'nominal_direct_hp':str(self.nominal_direct),'nominal_continuous_hp':{k:str(v) for k,v in self.nominal_components.items()},
                'activations_started':self.starts,'projectiles_released':self.releases,'hits_resolved':self.hits,'reloads_requested':self.reloads,
                'ammo_remaining':self.ammo,'reloading':self.reloading,'reload_phase':self.reload_phase,'shield_regenerated':'0','hp_zero_time':self.hp_zero,'observed_until_ms':str(observed)},
            'events':self.events,'curve':self.curve,'shield_loss_history':self.regen_losses,
            'pending_events_at_observation_end':len(self.queue),'active_effects_at_observation_end':len(self.effects)+sum(b['mode']!='ended' for b in self.beams),
            'limits':['Passive target, confirmed hits, no movement/accuracy/defensive choices, no dyspnea or unsupported Recovery costs.',
                'Melee at contact; all projectile paths fixed at supplied distance. Independent gas/venom/bleed histories.',
                'Observation stops at starting-HP exhaustion; no death, revival, victory or future-action behavior is inferred.',
                'No regeneration is eligible during this short window; initial shield is full or disabled, without older damage history.',
                'Numerical analytic integration at stated precision; root times have explicit bounded brackets; display curves sample every 100 ms plus events.']}


def run_benchmark_case(profiles,ability,target,shielded,*,duration_ms=10000,distance_m=10,precision=50,sample_interval_ms=100):
    if ability not in ABILITIES:raise ValueError('Unknown benchmark ability')
    if target not in profiles or not all(k in profiles[target] for k in ('max_hp','base_armor','resistances')):
        raise UnsupportedMechanicError('Benchmark defender requires complete documented stats')
    if isinstance(duration_ms,bool) or not isinstance(duration_ms,int) or not 0<duration_ms<int(profiles[target]['shield_regeneration']['delay_ms']):
        raise UnsupportedMechanicError('This benchmark requires a positive window below the 20000 ms shield regeneration delay')
    if not isinstance(shielded,bool) or precision<35:raise ValueError('Require a shield boolean and precision >=35')
    if dec(distance_m)<0:raise ValueError('Distance must be nonnegative')
    if isinstance(sample_interval_ms,bool) or not isinstance(sample_interval_ms,int) or sample_interval_ms<=0:
        raise ValueError('Sampling interval must be a positive integer millisecond')
    if ability=='1E1_4' and as_fraction(profiles['1E1']['abilities']['4']['k'])!=2:
        raise UnsupportedMechanicError('This benchmark currently supports the documented k=2 beam')
    with localcontext(Context(prec=precision,rounding=ROUND_HALF_EVEN)):
        return _Run(profiles,ability,target,shielded,duration_ms,distance_m,precision,sample_interval_ms).run()
