"""Existing Get Up/knockdown effects using owned actions and actual pose clearance."""
from dataclasses import replace
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F

from combat_sim.battle_models import BattleAction,decimal_value as dec
from combat_sim.mechanics.equilibrium import fall_duration_ms
from combat_sim.movement_contacts import first_box_contact
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M,CONTACT_SPEED_EPS_MPS,CONTACT_ACCEL_EPS_MPS2


def clearance(component,actor,duration_ms,*,recover_balance=True):
    w=component.world;q=component.at(actor.id,w.time)[0];c,_=w.posture_at(actor.id,w.time)
    c=F(c);duration=F(duration_ms)/1000
    if duration<=0:raise ValueError('Get Up clearance needs a positive duration')
    # Ordinary stand-up checks its nominal crouch change at the current
    # balance pose. Only paid Get Up controls balance recovery itself.
    qv,cv=(-q/duration if recover_balance else F(0)),-c/duration;time=F(0)
    reference=(*actor.position_m,w.motion[actor.id]['body_reference_z'])
    obstacles=[(key,p) for key,parts in w.body_terrain_colliders().items() if key!=w.terrain_definition['ground']['id'] for p in parts]
    obstacles.extend((key,p) for key,parts in w.world_bodies.items() if key!=actor.id and w.fighters[key].hp>0 for p in parts)
    while time<duration:
        now_q,now_c=max(F(0),q+qv*time),max(F(0),c+cv*time)
        morph=replace(component.basis(actor.id),crouch_fraction=now_c)
        boundary=morph.geometry_boundary((now_q,qv,F(0)),(now_c,cv,F(0)),duration-time,precision=w.precision)
        step=min(duration-time,boundary[1]) if boundary is not None else duration-time
        if step<=0:raise RuntimeError('Get Up clearance did not advance its geometry interval')
        for part in morph.world_parts(reference,actor.facing,now_q):
            velocity,acceleration,rate,change=morph.part_derivatives(part.part,now_q,qv,0,actor.facing,crouch_rate_per_s=cv)
            for identity,other in obstacles:
                contact=first_box_contact(part,other,velocity,acceleration,dec(step),left_size_rate_mps=rate,
                    left_size_acceleration_mps2=change,
                    contact_resolution=(CONTACT_DISTANCE_EPS_M,CONTACT_SPEED_EPS_MPS,CONTACT_ACCEL_EPS_MPS2))
                if contact is not None and contact<dec(step)-D('1e-25'):
                    component.state(actor.id).clearance_blockers=(identity,);return False
        time+=step
    component.state(actor.id).clearance_blockers=()
    return True


def wait_for_clearance(component,actor):
    w=component.world;row=component.state(actor.id)
    if not row.waiting_get_up:
        w.log('get_up_waiting_for_clearance',actor=actor.id,balance_fraction=dec(component.at(actor.id,w.time)[0]))
    row.waiting_get_up=True;row.blocked=True;component.rebuild(actor.id)
    row.driver_signature=component.drivers(actor.id)


def request_get_up(component,actor):
    w=component.world;row=component.state(actor.id)
    if actor.hp<=0 or not actor.knocked_down or actor.body_action() is not None or w._airborne(actor.id):return False
    if row.forced_rate is not None and component.at(actor.id,w.time)[0]<1 and not row.blocked:return False
    profile=w.common_profiles[actor.id]
    w.expire_action_restrictions(actor)
    requirements=w.action_requirements(actor,'get_up','get_up','ready')
    occupied,blocked=actor.action_registry.unavailable(requirements)
    if occupied or blocked:
        w.log('get_up_waiting_for_requirements',actor=actor.id,occupied=sorted(occupied),blocked=sorted(blocked))
        return False
    with localcontext(Context(prec=w.precision)):
        if not clearance(component,actor,profile['active_ms']):
            wait_for_clearance(component,actor);return False
    ready=w.resource_ready_time(actor,profile['dyspnea'])
    if ready>w.time:
        w.log('get_up_waiting_for_capacity',actor=actor.id,resume_at_ms=ready,dyspnea=actor.dyspnea)
        if ready.is_finite():w.request_decision(actor.id,ready)
        return False
    row.blocked=False;row.waiting_get_up=False;row.forced_rate=None
    action=BattleAction(next(w.action_ids),actor.id,actor.id,'get_up','get_up',w.time,w.time,
        dec(profile['active_ms']),phase='ready')
    actor.current=action;row.get_up_action_id=action.id
    component.rebuild(actor.id)
    w.log('get_up_requested',actor=actor.id,action_id=action.id,active_start_ms=w.time,active_ms=action.active_ms)
    w._schedule_phase(action,'active_started',w.time)
    return True


def start_get_up(component,actor):
    w=component.world;action=actor.current;row=component.state(actor.id)
    if w._airborne(actor.id) or not actor.knocked_down:
        w.cancel_owned_action(actor,action,'get_up_state_changed');return
    with localcontext(Context(prec=w.precision)):
        if not clearance(component,actor,action.active_ms):
            w.cancel_owned_action(actor,action,'get_up_clearance_changed');wait_for_clearance(component,actor);return
    if not w.pay_team_dyspnea(actor,'active_start'):return
    c,_=w.posture_at(actor.id,w.time)
    action.phase='active';action.active_end_ms=w.time+action.active_ms
    w.motion[actor.id]['pose_transition']={'from':c,'to':D(0),'start_ms':w.time,'duration_ms':action.active_ms}
    actor.metrics['activations_started']+=1;actor.metrics['get_ups_started']+=1
    row.get_up_action_id=action.id;row.blocked=False;row.waiting_get_up=False
    component.rebuild(actor.id);w.refresh_mobile_locomotion()
    w.log('get_up_started',actor=actor.id,ability='get_up',action_id=action.id,
        active_end_ms=action.active_end_ms,active_ms=action.active_ms)
    w._schedule_phase(action,'active_completed',action.active_end_ms)


def complete_get_up(component,actor):
    w=component.world;action=actor.current;row=component.state(actor.id)
    actor.knocked_down=False;actor.current=None
    row.progress=F(0);row.piece=None;row.get_up_action_id=None;row.forced_rate=None
    row.blocked=False;row.waiting_get_up=False
    w.motion[actor.id].update(crouch_fraction=D(0),pose_transition=None)
    actor.metrics['get_ups_completed']+=1
    component.rebuild(actor.id);w.refresh_mobile_locomotion()
    w.log('get_up_completed',actor=actor.id,action_id=action.id,state=actor.record())
    w.request_decision(actor.id,w.time)


def apply_knockdown(component,name,*,source):
    w=component.world;actor=w.fighters[name]
    if actor.hp<=0 or actor.died_at_ms is not None:return False
    row=component.state(name);q=component.at(name,w.time)[0]
    cancelled=[a.record() for a in actor.live_actions() if a.kind not in ('binding_break','grapple_break')]
    actor.knocked_down=True
    for action in list(actor.live_actions()):
        if action.kind not in ('binding_break','grapple_break'):w.cancel_owned_action(actor,action,'knocked_down',source)
    row.progress=q;row.piece=None;row.get_up_action_id=None;row.blocked=False;row.waiting_get_up=False
    row.forced_rate=F(1000)/fall_duration_ms(actor.disorientation,actor.instability) if q<1 else None
    # Voluntary ground drive stops; native flight, finite forces and existing
    # transmitted inertia keep their own lifetimes rather than being erased.
    w.motion[name].update(mode='standing',phase=None,speed=D(0),acceleration=D(0))
    actor.decision_due=None;actor.decision_revision+=1;actor.metrics['knockdowns_received']+=1
    component.rebuild(name);w.refresh_mobile_locomotion()
    w.log('knockdown_applied',actor=name,source=source,cancelled_action=cancelled[0] if len(cancelled)==1 else None,
        cancelled_actions=cancelled,state=actor.record())
    w.request_decision(name,w.time)
    return True
