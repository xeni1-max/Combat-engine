"""Open membership cells for saved yaw paths and fixed spatial fields.

Rational interval values and first derivatives certify whole time intervals.
Midpoint values tighten those bounds by the mean-value theorem; they are not
samples used as a substitute for a sweep. Only unresolved boundary brackets
shorter than the existing 1e-27 second field resolution are coalesced. Released
fields remain fixed, and these queries own neither translation nor exposure.
"""
from fractions import Fraction as F
from combat_sim.angular_paths import RotatingBoxPath, YawArc
from combat_sim.angular_intervals import Jet, _poly, _state, _truth, _all, _any, _local, _world, minimum, maximum, bounded_cells
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.orientation import YawFrame, scalar
from combat_sim.oriented_geometry import OrientedCuboid, axes, boxes_overlap


def _radial(path, centre, radius, begin, end, dimensions, blockers):
    def expressions(a, b):
        ref, low, high, _, _, _, c, s, vertical = _state(path, a, b)
        point = _local(tuple(p-r for p, r in zip(centre, ref)), c, s)
        gaps = tuple(maximum(0, lo-p, p-hi) for lo, hi, p in zip(low, high, point))
        overlap = radius*radius-sum((g.square() for g in gaps[:dimensions]), Jet.lift(0))
        cover = []
        if blockers:
            nearest = tuple(minimum(hi, maximum(lo, p)) for lo, hi, p in zip(low, high, point))
            witness = tuple(x+y for x, y in zip(ref, _world(nearest, c, s)))
            for blocker in blockers:
                if isinstance(blocker, OrientedCuboid):
                    delta = tuple(p-v for p, v in zip(witness, blocker.centre_m))
                    local = tuple(sum((basis[i]*delta[i] for i in range(3)), Jet.lift(0)) for basis in blocker.frame.basis)
                    lower = tuple(-v/2 for v in blocker.size_m)
                    upper = tuple(v/2 for v in blocker.size_m)
                else:local, (lower, upper) = witness, blocker.bounds
                cover.append(tuple(value for i in (0, 1) for value in (local[i]-lower[i], upper[i]-local[i]))+
                             (blocker.bounds[1][2]-vertical[1],))
        return overlap, cover
    values, covers = expressions(begin, end)
    middle, midcovers = expressions((begin+end)/2, (begin+end)/2)
    half = (end-begin)/2
    overlap = _truth(values, middle, half)
    if overlap is False:return False
    blocked = _any(_all(_truth(v, m, half, strict=True) for v, m in zip(row, mid)) for row, mid in zip(covers, midcovers))
    return _all((overlap, None if blocked is None else not blocked))


def _boxes(path, fixed, begin, end):
    def expressions(a, b):
        ref, _, _, size, local_centre, centre, c, s, vertical = _state(path, a, b)
        moving_axes = ((s, -c, Jet.lift(0)), (c, s, Jet.lift(0)))
        other_axes = axes(fixed)
        delta = tuple(p-v for p, v in zip(centre, fixed.centre_m))
        result = []
        local_fixed = _local(tuple(p-r for p, r in zip(fixed.centre_m, ref)), c, s)
        for i,axis in enumerate(moving_axes):
            projection = local_centre[i]-local_fixed[i]
            radius = size[i]*F(1, 2)+sum((h*abs(sum((x*y for x, y in zip(basis, axis)), Jet.lift(0)))
                for h, basis in zip(fixed.size_m[:2], other_axes[:2])), Jet.lift(0))*F(1, 2)
            result.extend((radius-projection, radius+projection))
        for i,axis in enumerate(other_axes[:2]):
            projection = sum((x*y for x, y in zip(delta, axis)), Jet.lift(0))
            radius = sum((h*abs(sum((x*y for x, y in zip(basis, axis)), Jet.lift(0)))
                for h, basis in zip(size[:2], moving_axes)), Jet.lift(0))*F(1, 2)
            radius += fixed.size_m[i]*F(1, 2)
            result.extend((radius-projection, radius+projection))
        return (*result, fixed.bounds[1][2]-vertical[0], vertical[1]-fixed.bounds[0][2])
    values = expressions(begin, end);mid = (begin+end)/2
    middle = expressions(mid, mid)
    return _all(_truth(v, m, (end-begin)/2) for v, m in zip(values, middle))


def _paths(parts, duration, precision):
    rotating = [p for p in parts if isinstance(p, RotatingBoxPath)]
    begin = rotating[0].yaw.begin_s
    end = begin+duration
    result = []
    for item in parts:
        if isinstance(item, RotatingBoxPath):
            if item.yaw.begin_s != begin:raise ValueError('Field paths must share a saved query start')
            item._validate_interval(begin, end);result.append(item);continue
        if len(item) not in (4, 5):raise ValueError('Invalid fixed-heading field motion')
        box, velocity, acceleration, rate = item[:4]
        frame = box.frame if isinstance(box, OrientedCuboid) else YawFrame(0, 1)
        reference = BodyPathPiece(begin*1000, end*1000, box.centre_m, velocity, acceleration)
        result.append(RotatingBoxPath(reference, YawArc(begin, end, frame, 0, precision), Cuboid(box.part, (0, 0, 0), box.size_m),
            size_rate_mps=rate, size_acceleration_mps2=item[4] if len(item)==5 else (0, 0, 0)))
    return result, begin, end


def angular_cells(kind, parts, duration_s, *, centre=None, radius=None, fixed=(), blockers=(), precision=50,
                  node_limit=100000, first_boundary_only=False):
    """Return the same open-cell contract as volume_geometry's polynomial path.

    Boundary times are the certified beginning of the following open cell,
    rounded upward. This retains closed overlap when a fence binds movement.
    Isolated unresolved tangencies below the field clock resolution add no cell.
    """
    duration = scalar(duration_s)
    if (duration < 0 or type(precision) is not int or precision < 40 or
            type(node_limit) is not int or node_limit <= 0):raise ValueError('Invalid angular field controls')
    if kind not in ('sphere', 'column', 'box'):raise ValueError('Unknown angular volume shape')
    centre = tuple(map(scalar, centre)) if centre is not None else None
    radius = scalar(radius) if radius is not None else None
    if kind != 'box' and (len(centre)!=3 or radius<=0):raise ValueError('Field needs xyz centre and positive radius')
    paths, begin, end = _paths(tuple(parts), duration, precision)
    fixed, blockers = tuple(fixed), tuple(blockers)
    if kind == 'column':blockers = tuple(b for b in blockers if b.intersects_vertical_column(centre[:2], radius))
    if kind == 'box':
        pairs = [(p, f) for p in paths for f in fixed if boxes_overlap(p.enclosing_interval(begin, end), f)]
    else:
        paths = [p for p in paths if (p.enclosing_interval(begin, end).intersects_sphere(centre, radius) if kind=='sphere'
            else p.enclosing_interval(begin, end).intersects_vertical_column(centre[:2], radius))]
    def classify(a, b):
        if kind == 'box':return _any(_boxes(p, f, a, b) for p, f in pairs)
        return _any(_radial(p, centre, radius, a, b, 3 if kind=='sphere' else 2, blockers) for p in paths)
    def actual(time):
        # The fixed-heading predicate is used only for zero-duration queries or
        # a complete query shorter than the boundary resolution.
        from combat_sim.volume_geometry import sphere_cells, column_cells, box_cells
        items = [(p.at_time(time), (0, 0, 0), (0, 0, 0), (0, 0, 0)) for p in paths]
        if kind=='box':return box_cells(fixed, items, 0, precision=precision)[0][1]
        if kind=='sphere':return sphere_cells(centre, radius, items, 0, precision=precision)[0][1]
        return column_cells(centre, radius, items, blockers, 0, precision=precision)[0][1]
    return bounded_cells(classify,actual,begin,end,precision=precision,node_limit=node_limit,
        first_boundary_only=first_boundary_only)
