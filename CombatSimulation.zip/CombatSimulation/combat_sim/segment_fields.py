"""Autonomous segmented materials, continuous body contact and common bindings.

This coordinator owns no clock, HP integrator or movement override. Each panel
is a shared collider; each contact episode uses existing binding and rate APIs.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,ROUND_CEILING,localcontext
from itertools import count

from combat_sim.battle_models import decimal_value as dec
from combat_sim.hitboxes import Cuboid
from combat_sim.models import UnsupportedMechanicError
from combat_sim.volume_geometry import box_cells, TIME_EPS_S
from combat_sim.world_colliders import ColliderPolicy, damage_immunities, finite
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid

EVENTS = frozenset(('segment_field_expired', 'segment_field_contact'))


class SegmentFields:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        self.ids=count(1);self.episode_ids=count(1);self.fields={};self.episodes={};self.current={}
        if self.enabled and (definition!={'mode':'fixed_contact_v1'} or not world.mobile_mode):
            raise UnsupportedMechanicError('Segment fields require the current mobile world')

    def validate(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id];cfg=a.get('contact_field',{})
        if (not self.enabled or not w.collider_system.enabled or actor.action_registry is None
                or not w.body_paths.enabled or not w.bindings.enabled or not w.controlled_damage.released_enabled):
            raise UnsupportedMechanicError('Selected contact fields require owned paths, bindings, released rates and materials')
        keys={'segments','length_per_segment_m','height_m','thickness_m','hp','duration_ms',
              'damage_per_second','damage_type','binding','damage_immunities'}
        if not isinstance(cfg,dict) or set(cfg)!=keys:
            raise ValueError('Contact field needs explicit segmented material and contact effects')
        if type(cfg['segments']) is not int or cfg['segments']<=0:raise ValueError('Field segment count must be positive')
        for key in ('length_per_segment_m','height_m','thickness_m','hp','duration_ms','damage_per_second'):
            finite(cfg[key],'Field '+key,positive=True)
        if (cfg['damage_type']!='electrocution' or not isinstance(cfg['binding'],dict)
                or cfg['binding'].get('kind')!='lower_body' or set(cfg['binding'])!={'kind','binding_value'}):
            raise UnsupportedMechanicError('Unsupported field rate or body binding')
        finite(cfg['binding']['binding_value'],'Field binding value')
        damage_immunities(cfg['damage_immunities'])
        if (a.get('deployment_timing')!='active_end' or a.get('cooldown_anchor')!='activation_start'
                or a.get('dyspnea',{}).get('kind')!='none'):
            raise UnsupportedMechanicError('Contact fields require explicit independent end-of-Active deployment')
        finite(a['cooldown_ms'],'Field cooldown',positive=True)

    def selected(self,actor,action):
        snapshot=deepcopy(action.target_snapshot)
        if snapshot is None:
            target=self.world.fighters[action.target]
            feet=min(box.bounds[0][2] for box in self.world.world_bodies[target.id])
            action.aim_location_m=(*tuple(map(dec,target.position_m)),dec(feet))
            snapshot={'kind':'target_feet','point_m':action.aim_location_m}
        if isinstance(actor.facing,YawFrame) and 'axis' not in snapshot:
            snapshot.update(axis='body_lateral',yaw_frame=actor.facing.record())
        else:snapshot.setdefault('axis','y' if actor.facing in ('+x','-x') else 'x')
        action.target_snapshot=snapshot

    def deploy(self,actor,action,ability):
        w=self.world;cfg=deepcopy(ability['contact_field']);identity='segment-field:'+str(next(self.ids))
        axis=action.target_snapshot['axis'];direction=0 if axis=='x' else 1
        point=tuple(map(dec,action.aim_location_m));length=dec(cfg['length_per_segment_m'])
        height=dec(cfg['height_m']);thickness=dec(cfg['thickness_m']);expiry=w.time+dec(cfg['duration_ms'])
        row={'id':identity,'actor':actor.id,'ability':action.ability_id,'action_id':action.id,
            'source_life_generation':action.life_generation,'deployed_at_ms':w.time,'expiry_ms':expiry,
            'location_m':point,'axis':axis,'definition':cfg,'panel_ids':[],'status':'active','autonomous':True}
        if axis=='body_lateral':row['yaw_frame']=deepcopy(action.target_snapshot['yaw_frame'])
        for index in range(cfg['segments']):
            if axis=='body_lateral':
                frame=YawFrame(**action.target_snapshot['yaw_frame'])
                offset=(D(index)+D('.5')-D(cfg['segments'])/2)*length
                centre=tuple(map(dec,frame.to_world_point((offset,0,height/2),point)))
                shape=OrientedCuboid('panel',centre,(length,thickness,height),frame)
            else:
                centre=list(point);centre[direction]+=(D(index)+D('.5')-D(cfg['segments'])/2)*length
                centre[2]+=height/2;size=[thickness,thickness,height];size[direction]=length
                shape=Cuboid('panel',centre,size)
            collider=w.collider_system.spawn((shape,),source=identity,hp=cfg['hp'],
                expires_at_ms=expiry,policy=ColliderPolicy(projectiles=True,bodies=False,areas=False),
                owner=actor.id,ability=action.ability_id,action_id=action.id,source_life_generation=action.life_generation,
                tags=('contact_field','fence'),immune_damage_types=cfg['damage_immunities'])
            row['panel_ids'].append(collider)
        self.fields[identity]=row
        w.push(expiry,'segment_field_expired',{'field_id':identity},priority=0)
        w.log('segment_field_deployed',field=deepcopy(row))
        self.settle()

    def parts(self,row):
        registry=self.world.collider_system.registry
        return [p for key in row['panel_ids'] if registry.objects[key].active(self.world.time)
                for p in registry.objects[key].parts]

    def cells(self,row,target,seconds):
        parts,seconds=self.world.effect_system.field_motion(target,'actor',seconds)
        return self.world.effect_system.query_cache.query(box_cells,self.parts(row),parts,seconds,
            precision=self.world.precision,first_boundary_only=True)

    def _enter(self,row,target):
        w=self.world;actor=w.fighters[target];identity='field-contact:'+str(next(self.episode_ids))
        episode={'id':identity,'field_id':row['id'],'target':target,'target_life_generation':actor.life_generation,
                 'started_at_ms':w.time,'status':'pending','binding_id':None,'stream_id':None}
        self.episodes[identity]=episode;self.current[(row['id'],target,actor.life_generation)]=identity
        w.push(w.time,'segment_field_contact',{'episode_id':identity},priority=3)

    def _leave(self,episode,reason):
        if episode['status']=='ended':return
        w=self.world
        if episode['stream_id'] is not None:
            w.controlled_damage.end(w.controlled_damage.streams[episode['stream_id']],reason)
        if episode['binding_id'] is not None:
            w.bindings.end(w.bindings.bindings[episode['binding_id']],reason)
        episode.update(status='ended',ended_at_ms=w.time,end_reason=reason)
        self.current.pop((episode['field_id'],episode['target'],episode['target_life_generation']),None)
        w.log('segment_field_contact_ended',episode=deepcopy(episode))

    def _finish(self,row,reason):
        if row['status']!='active':return
        row.update(status='ended',ended_at_ms=self.world.time,end_reason=reason)
        for episode in self.episodes.values():
            if episode['field_id']==row['id']:self._leave(episode,reason)
        self.world.log('segment_field_ended',field=deepcopy(row))

    def settle(self):
        if not self.enabled:return
        w=self.world
        for row in self.fields.values():
            if row['status']!='active':continue
            if row['expiry_ms']<=w.time:
                self._finish(row,'field_expired');continue
            if not self.parts(row):
                self._finish(row,'all_panels_removed');continue
            for name,actor in sorted(w.fighters.items()):
                key=(row['id'],name,actor.life_generation);current=self.episodes.get(self.current.get(key))
                eligible=actor.hp>0 and self.cells(row,name,2*TIME_EPS_S)[0][1]
                if eligible and current is None:self._enter(row,name)
                elif not eligible and current is not None:self._leave(current,'field_contact_left')

    def prepare(self,end,*,physical_only=False):
        if not self.enabled or not any(r['status']=='active' for r in self.fields.values()):return end
        w=self.world;self.settle();finish=w.effect_system.motion_limit(end,physical_only=physical_only)
        if finish<=w.time:return finish
        for row in self.fields.values():
            if row['status']!='active':continue
            finish=min(finish,row['expiry_ms'])
            for name,actor in sorted(w.fighters.items()):
                if actor.hp<=0:continue
                cells=self.cells(row,name,(finish-w.time)/1000)
                if len(cells)>1:
                    with localcontext(Context(prec=w.precision,rounding=ROUND_CEILING)):
                        boundary=w.time+cells[1][0]*1000
                    finish=min(finish,boundary)
        return finish

    def retire_life(self,actor):
        for episode in self.episodes.values():
            if episode['target']==actor.id and episode['target_life_generation']==actor.life_generation:
                self._leave(episode,'recipient_life_ended')

    def event_live(self,kind,p):
        if kind=='segment_field_expired':return self.fields[p['field_id']]['status']=='active'
        return self.episodes[p['episode_id']]['status']=='pending'

    def process(self,kind,p):
        if not self.event_live(kind,p):return
        if kind=='segment_field_expired':return self._finish(self.fields[p['field_id']],'field_expired')
        w=self.world;episode=self.episodes[p['episode_id']];row=self.fields[episode['field_id']]
        actor=w.fighters[episode['target']]
        if (row['status']!='active' or actor.hp<=0 or actor.life_generation!=episode['target_life_generation']
                or not self.cells(row,actor.id,2*TIME_EPS_S)[0][1]):
            return self._leave(episode,'contact_no_longer_eligible')
        packet={key:row[key] for key in ('actor','ability','action_id','source_life_generation')}
        packet.update(target=actor.id,target_life_generation=actor.life_generation)
        binding=row['definition']['binding']
        binding_id=w.bindings.create(packet,kind=binding['kind'],value=binding['binding_value'],duration_ms=row['expiry_ms']-w.time)
        stream=w.controlled_damage.start_released(packet,damage_type=row['definition']['damage_type'],
            base_dps=row['definition']['damage_per_second'],until_ms=row['expiry_ms'])
        episode.update(status='active',binding_id=binding_id,stream_id=stream.id,applied_at_ms=w.time)
        w.log('segment_field_contact_started',episode=deepcopy(episode))

    def result(self):
        return {'segment_field_rules':deepcopy(self.world.combat_locomotion_input['segment_fields']),
            'segment_fields':deepcopy(list(self.fields.values())),
            'segment_field_contacts':deepcopy(list(self.episodes.values()))} if self.enabled else {}
