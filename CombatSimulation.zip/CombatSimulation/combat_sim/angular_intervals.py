"""Shared rational bounds for prescribed yaw and quadratic local/reference poses.

Pure geometry only: no world lookup, reference integration, support or effect
writer. Field and support predicates compose these same interval derivatives.
"""
from dataclasses import dataclass
from decimal import Context, Decimal as D, ROUND_CEILING, localcontext
from fractions import Fraction as F
from functools import lru_cache
from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.kinematic_bounds import quadratic_range
from combat_sim.models import UnsupportedMechanicError
from combat_sim.orientation import scalar

RESOLUTION = F(1, 10**28)


def _mul(a, b):
    values = tuple(x*y for x in a for y in b)
    return min(values), max(values)


@dataclass(frozen=True)
class Jet:
    lo: F
    hi: F
    dlo: F = F(0)
    dhi: F = F(0)

    @staticmethod
    def lift(value):
        return value if isinstance(value, Jet) else Jet(scalar(value), scalar(value))

    def __add__(self, other):
        b = self.lift(other)
        return Jet(self.lo+b.lo, self.hi+b.hi, self.dlo+b.dlo, self.dhi+b.dhi)

    __radd__ = __add__

    def __neg__(self):
        return Jet(-self.hi, -self.lo, -self.dhi, -self.dlo)

    def __sub__(self, other):return self+-self.lift(other)
    def __rsub__(self, other):return self.lift(other)+-self

    def __mul__(self, other):
        b = self.lift(other)
        lo, hi = _mul((self.lo, self.hi), (b.lo, b.hi))
        a0, a1 = _mul((self.dlo, self.dhi), (b.lo, b.hi))
        b0, b1 = _mul((self.lo, self.hi), (b.dlo, b.dhi))
        return Jet(lo, hi, a0+b0, a1+b1)

    __rmul__ = __mul__

    def __abs__(self):
        if self.lo >= 0:return self
        if self.hi <= 0:return -self
        return Jet(0, max(-self.lo, self.hi), -max(abs(self.dlo), abs(self.dhi)), max(abs(self.dlo), abs(self.dhi)))

    def square(self):
        value = abs(self)
        lo, hi = _mul((2*self.lo, 2*self.hi), (self.dlo, self.dhi))
        return Jet(value.lo**2, value.hi**2, lo, hi)


def maximum(*values):
    values = tuple(map(Jet.lift, values));low = max(v.lo for v in values)
    possible = tuple(v for v in values if v.hi >= low)
    return Jet(low, max(v.hi for v in values), min(v.dlo for v in possible), max(v.dhi for v in possible))


def minimum(*values):return -maximum(*(-Jet.lift(v) for v in values))


def _poly(p, v, a, begin, end):
    low, high = quadratic_range(p, v, a, begin, end)
    return Jet(low, high, min(v+a*begin, v+a*end), max(v+a*begin, v+a*end))


@lru_cache(maxsize=4096)
def _trig(yaw, begin, end):
    if not yaw.rate_degrees_per_second:
        return Jet.lift(yaw.initial_frame.cosine), Jet.lift(yaw.initial_frame.sine)
    left, right = yaw.frame_at(begin), yaw.frame_at(end)
    error = max(map(abs, yaw.angular_speed_bounds))**2*(end-begin)**2/8+2*yaw.frame_error
    c = Jet(max(F(-1), min(left.cosine, right.cosine)-error), min(F(1), max(left.cosine, right.cosine)+error))
    s = Jet(max(F(-1), min(left.sine, right.sine)-error), min(F(1), max(left.sine, right.sine)+error))
    omega = Jet(*yaw.angular_speed_bounds)
    dc, ds = -omega*s, omega*c
    return Jet(c.lo, c.hi, dc.lo, dc.hi), Jet(s.lo, s.hi, ds.lo, ds.hi)


def _local(vector, c, s):
    x, y, z = vector
    return s*x-c*y, c*x+s*y, z


def _world(vector, c, s):
    x, y, z = vector
    return s*x+c*y, -c*x+s*y, z


def _state(path, begin, end):
    a, b = begin-path.yaw.begin_s, end-path.yaw.begin_s
    ref = tuple(_poly(p, v, q, a, b) for p, v, q in zip(
        path.reference.reference_m, path.reference.velocity_mps, path.reference.acceleration_mps2))
    low, high, size, centre = [], [], [], []
    for p, v, q, h, hv, hq in zip(path.local_box.centre_m, path.local_velocity_mps,
            path.local_acceleration_mps2, path.local_box.size_m, path.size_rate_mps, path.size_acceleration_mps2):
        low.append(_poly(p-h/2, v-hv/2, q-hq/2, a, b))
        high.append(_poly(p+h/2, v+hv/2, q+hq/2, a, b))
        size.append(_poly(h, hv, hq, a, b))
        centre.append(_poly(p, v, q, a, b))
    c, s = _trig(path.yaw, begin, end)
    world_centre = tuple(x+y for x, y in zip(ref, _world(centre, c, s)))
    # Combine signed coefficients before bounding the vertical faces. Anchored
    # feet/top witnesses must not acquire a fictitious interval drift.
    vertical = tuple(_poly(path.reference.reference_m[2]+path.local_box.centre_m[2]+sign*path.local_box.size_m[2]/2,
        path.reference.velocity_mps[2]+path.local_velocity_mps[2]+sign*path.size_rate_mps[2]/2,
        path.reference.acceleration_mps2[2]+path.local_acceleration_mps2[2]+sign*path.size_acceleration_mps2[2]/2, a, b)
        for sign in (-1, 1))
    return ref, low, high, size, centre, world_centre, c, s, vertical


def _truth(value, middle, half, *, strict=False):
    # Mean-value tightening also bounds smooth tangencies quadratically, unlike
    # a position-only enclosure whose uncertainty decreases only linearly.
    spread = max(abs(value.dlo), abs(value.dhi))*half+(middle.hi-middle.lo)
    lo, hi = max(value.lo, middle.lo-spread), min(value.hi, middle.hi+spread)
    if lo > 0 if strict else lo >= 0:return True
    if hi <= 0 if strict else hi < 0:return False
    return None


def _all(values):
    unknown = False
    for value in values:
        if value is False:return False
        unknown |= value is None
    return None if unknown else True


def _any(values):
    unknown = False
    for value in values:
        if value is True:return True
        unknown |= value is None
    return None if unknown else False


def bounded_cells(classify, actual, begin_s, end_s, *, precision=50, node_limit=100000,
                  first_boundary_only=False, preserve_initial=False, label='Angular field'):
    """Certify open cells, optionally retaining an actual closed start witness.

    Support loss needs a confirmed point beyond the initial witness, including
    when its remaining positive lifetime is shorter than temporal resolution.
    Field callers retain their original forward-open-cell contract.
    """
    begin,end=map(scalar,(begin_s,end_s));duration=end-begin
    if begin<0 or duration<0 or type(precision) is not int or precision<40 or type(node_limit) is not int or node_limit<=0:
        raise ValueError('Invalid angular interval controls')
    if not duration:return [(D(0),actual(begin))]
    initial=actual(begin) if preserve_initial else None
    pending,leaves,budget=[(begin,end)],[],node_limit
    certified=False
    while pending:
        left,right=pending.pop();budget-=1
        if budget<0:raise UnsupportedMechanicError(label+' interval budget exhausted')
        state=classify(left,right)
        if state is not None or right-left<=RESOLUTION:
            leaves.append((left,right,state))
            if state is not None:
                certified=True
                if first_boundary_only and initial is not None and state!=initial:break
                initial=state
            continue
        mid=(left+right)/2;pending.extend(((mid,right),(left,mid)))
    cells=[(D(0),actual(begin))] if preserve_initial else [];unresolved=None
    for left,right,state in leaves:
        if state is None:
            unresolved=left if unresolved is None else unresolved
            if right-unresolved>10*RESOLUTION:
                raise UnsupportedMechanicError(label+' boundary exceeds temporal resolution')
            continue
        unresolved=None
        if not cells or cells[-1][1]!=state:
            with localcontext(Context(prec=precision,rounding=ROUND_CEILING)):
                time=dec(left-begin) if cells else D(0)
            cells.append((time,state))
    if not certified:
        if duration>2*RESOLUTION:
            raise UnsupportedMechanicError('Unresolved persistent '+label.lower()+' boundary')
        return [(D(0),actual((begin+end)/2))] if not preserve_initial else cells
    return cells
