"""Life-bound ground motor bonuses; inertia and launched bodies are separate."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.life import life_generation

EVENT='ground_speed_bonus_ended'


class GroundSpeedBonuses:
    def __init__(self,world):self.world=world;self.rows={}

    def grant(self,identity,actor,generation,factor,until):
        w=self.world;factor=dec(factor);until=dec(until);generation=life_generation(generation)
        if (not isinstance(identity,str) or not identity or identity in self.rows or actor not in w.fighters or not factor.is_finite() or factor<=0 or
                not until.is_finite() or until<=w.time or w.fighters[actor].hp<=0 or
                w.fighters[actor].life_generation!=generation):raise ValueError('Ground speed bonus needs a unique living source and finite factor/clock')
        row=dict(id=identity,actor=actor,life_generation=generation,factor=factor,until_ms=until,
            created_at_ms=w.time,status='active',revision=0)
        self.rows[identity]=row;w.push(until,EVENT,{'bonus_id':identity,'revision':0})
        w.body_paths.invalidate();w.log('ground_speed_bonus_started',bonus=deepcopy(row));return row

    def factor(self,name):
        if not self.rows:return D(1)
        with localcontext(Context(prec=self.world.precision)):return self._factor(name)

    def _factor(self,name):
        a=self.world.fighters[name];value=D(1)
        for r in self.rows.values():
            if r['actor']==name and r['status']=='active' and r['life_generation']==a.life_generation and a.hp>0 and self.world.time<r['until_ms']:
                value*=r['factor']
        return value

    def refresh(self,identity,until):
        r=self.rows[identity];until=dec(until)
        if r['status']!='active' or not until.is_finite() or until<=self.world.time:raise ValueError('Only a live bonus may refresh to a future clock')
        r.update(until_ms=until,revision=r['revision']+1)
        self.world.push(until,EVENT,{'bonus_id':identity,'revision':r['revision']})
        self.world.body_paths.invalidate();self.world.log('ground_speed_bonus_refreshed',bonus=deepcopy(r))

    def end(self,identity,reason):
        r=self.rows[identity]
        if r['status']!='active':return
        r.update(status='ended',ended_at_ms=self.world.time,end_reason=reason)
        self.world.body_paths.invalidate();self.world.log('ground_speed_bonus_ended',bonus=deepcopy(r))

    def live(self,p):
        r=self.rows.get(p.get('bonus_id'));return r is not None and r['status']=='active' and r['revision']==p.get('revision')

    def process(self,p):
        if self.live(p):self.end(p['bonus_id'],'expired');self.world.refresh_mobile_locomotion()

    def settle(self):
        for r in self.rows.values():
            a=self.world.fighters[r['actor']]
            if r['status']=='active' and (a.hp<=0 or a.life_generation!=r['life_generation']):self.end(r['id'],'source_life_ended')

    def result(self):return {'ground_speed_bonuses':deepcopy(list(self.rows.values()))} if self.rows else {}
