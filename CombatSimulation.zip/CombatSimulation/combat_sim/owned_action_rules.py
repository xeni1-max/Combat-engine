"""Shared-engine action requirements, phase contexts and selective cancellation."""
from contextlib import ExitStack
from copy import deepcopy
from decimal import Decimal as D

from combat_sim.action_ownership import ActionRegistry, ActionRequirements
from combat_sim.automatic_abilities import ability_definition
from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.dyspnea import apply_action_dyspnea, validate_action_dyspnea_rule
from combat_sim.models import UnsupportedMechanicError

BODY_KINDS={'locomotion','posture','dodge','basic_jump','climb','get_up','ballistic_dash','ballistic_leap','charge_grab'}


class OwnedActionRules:
    def setup_mobile_combat(self,definition,effects):
        self.ownership_definition=deepcopy(effects.get('action_ownership')) if effects else None
        if self.ownership_definition is not None:
            if (self.ownership_definition.get('mode')!='declared_requirements_v1' or
                    self.ownership_definition.get('capacity')!='bounded_deferred_cost'):
                raise UnsupportedMechanicError('Unsupported controlled-action ownership rules')
            required={'locomotion','basic_jump','posture','sprint_transition','climb','slash_projectile','reload'}
            if self.equilibrium.enabled:required.add('get_up')
            if self.effect_system.enabled:required.add('heat_beam')
            if self.cooldown_system.enabled:required.add('cooldown_pause_area')
            if self.effort_system.enabled:required.add('projectile_delayed_area')
            if self.melee.enabled:required.update(('venomous_thrust','replacement_grab'))
            if self.grapple_casts.enabled:required.update(('grapple_grab','grapple_hold'))
            if self.grapple_break.enabled:required.add('grapple_break')
            if self.bindings.enabled:required.update(('binding_break','marking_projectile'))
            if self.impact_bindings.enabled:required.add('impact_binding_area')
            if self.impact_areas.enabled:required.add('impact_area_projectile')
            if self.contact_constructs.enabled:required.add('construct_projectile')
            if self.segment_fields.enabled:required.add('contact_field')
            if self.projectile_duplication.enabled:required.add('projectile_duplication_area')
            if self.portals.enabled:required.add('portal_pair')
            if self.body_leaps.enabled:required.add('ballistic_leap')
            if self.weapon_modes.enabled:required.add('weapon_swap');required.add('poison_projectile')
            if self.blocking.enabled:required.add('block')
            if self.dodging.enabled:required.add('dodge')
            if self.attack_modifiers.enabled:required.add('attack_enhancement')
            if not isinstance(self.ownership_definition.get('actions'),dict) or not required<=set(self.ownership_definition['actions']):
                raise ValueError('Missing current action requirements')
            if self.grapple_break.enabled and self.ownership_definition['actions']['grapple_break']!={'occupies':['contest'],'requires':[]}:
                raise UnsupportedMechanicError('Break input needs a private contest owner without limb exclusivity')
            if self.bindings.enabled and self.ownership_definition['actions']['binding_break']!={'occupies':['binding_break'],'requires':[]}:
                raise UnsupportedMechanicError('Binding Break needs one focus without limb exclusivity')
            for value in self.ownership_definition['actions'].values():
                if (set(value)!={'occupies','requires'} or not isinstance(value['occupies'],list)
                        or not isinstance(value['requires'],list) or not value['occupies'] or any(
                        not isinstance(v,str) or not v for v in value['occupies']+value['requires'])):
                    raise ValueError('Owned actions need explicit resource/function names')
        self.restriction_clocks={}
        self.restriction_revisions={}
        self.controlled_cancellation_receipts=set()
        super().setup_mobile_combat(definition,effects)
        if self.ownership_definition is not None:
            for actor in self.fighters.values():
                actor.action_registry=ActionRegistry(
                    lambda action,actor=actor:self.action_requirements(actor,action.kind,action.ability_id,action.phase,action=action),
                    lambda actor=actor:actor.dyspnea)
                actor.metrics.update(controlled_actions_cancelled=0)
        restrictions=self.scenario.get('initial_restrictions',[])
        if not isinstance(restrictions,list):
            raise ValueError('Initial restrictions must be a list')
        if restrictions and self.ownership_definition is None:
            raise UnsupportedMechanicError('Initial function restrictions require owned action rules')
        for item in restrictions:
            if set(item)!={'target','source','functions','duration_ms'}:
                raise ValueError('Initial restriction requires target, source, functions and duration_ms')
            if dec(item['duration_ms'])<0:
                raise ValueError('Initial restriction remaining duration cannot be negative')
            self.apply_action_restriction(item['target'],source=item['source'],functions=item['functions'],
                until_ms=dec(item['duration_ms']),wake=False)

    def action_requirements(self,actor,kind,ability_id,phase,*,action=None,component=None):
        if kind=='heading_turn':return self.turns.requirements()
        if kind=='hook_projectile':return self.grappling_gun.requirements(actor,ability_id,phase,
            action_id=None if action is None else action.id)
        if kind=='binding_break':return self.bindings.requirements()
        if kind=='grapple_break':
            if not self.grapple_break.enabled or action is None:
                raise ValueError('Break requirements need an enabled owned contest')
            return self.grapple_break.requirements(action)
        if kind=='grapple_hold':
            if action is None:raise ValueError('Holding requirements need their owned phase identity')
            return self.grapple_casts.requirements(actor,action,pending=phase=='holding_pending')
        key='sprint_transition' if kind=='locomotion' and phase=='recovery' else kind
        if key not in self.ownership_definition['actions']:
            raise UnsupportedMechanicError('No declared requirements for controlled action '+key)
        cfg=self.ownership_definition['actions'][key]
        occupies=set(cfg['occupies'])
        if 'hands' in occupies:
            occupies.remove('hands')
            if kind in BODY_KINDS and kind!='charge_grab':
                hands=actor.hands
            else:
                ability=self.action_definition(actor,action) if action is not None else self.melee.definition(actor,ability_id,component)
                if kind=='replacement_grab':poses=ability['replacement_blade']['hand_positions_m']
                else:poses=ability['reload_hand_positions_m'] if kind=='reload' else ability['hand_positions_m']
                hands=poses['start']
            occupies.update('hand:'+name for name in hands)
        if 'weapon' in occupies:
            occupies.remove('weapon');occupies.add('weapon:'+self.weapon_modes.slot(actor,ability_id))
        rule=None
        if kind in ('weapon_swap','poison_projectile','slash_projectile','direct_projectile','projectile_delayed_area','marking_projectile','binding_projectile','impact_binding_area','impact_area_projectile','construct_projectile','contact_field','projectile_duplication_area','portal_pair','heat_beam','cooldown_pause_area','reload','venomous_thrust','component_melee','conditional_melee','grapple_grab','charge_grab','knock_melee','block','dodge','attack_enhancement','ballistic_dash','ballistic_leap','aim_toggle'):
            ability=self.action_definition(actor,action) if action is not None else self.melee.definition(actor,ability_id,component)
            rule=ability['reload_dyspnea'] if kind=='reload' else ability['dyspnea']
            validate_action_dyspnea_rule(rule)
        elif kind=='replacement_grab':
            rule={'kind':'none'}
        elif kind=='basic_jump':
            rule={'kind':'action','base_value':self.jump_input['characters'][actor.profile_id]['listed_dyspnea_value'],'payment_timing':'active_start'}
        elif kind=='get_up':
            rule=self.common_profiles[actor.id]['dyspnea']
        elif kind=='posture':
            rule={'kind':'action','base_value':self.crouch_definition['characters'][actor.profile_id]['listed_dyspnea_value'],'payment_timing':'active_start'}
        elif kind=='climb':
            rule={'kind':'action','base_value':self.climb_definition['characters'][actor.profile_id]['listed_dyspnea_value'],'payment_timing':'active_start'}
        elif key=='sprint_transition':
            rule={'kind':'action','base_value':self._sprint_values(actor)['listed_transition_dyspnea_value'],'payment_timing':'active_start'}
        elif kind=='locomotion' and ability_id in ('walk','run') and self.motion[actor.id]['mode']!='standing':
            rule={'kind':'action','base_value':self.combat_locomotion_definition['characters'][actor.profile_id]['walk_run']['dyspnea_base_value'],'payment_timing':'active_start'}
        elif kind=='locomotion':
            rule={'kind':'none'}
        else:
            raise UnsupportedMechanicError('Missing explicit owned-action cost definition')
        requires=set(cfg['requires'])
        if kind=='ballistic_leap' and (phase=='falling_kick' or action is not None and getattr(action,'leap_kick_active',False)):
            requires.add('attack')
        return ActionRequirements(frozenset(occupies),frozenset(requires),
            dec(rule['base_value']) if rule and rule['kind']!='none' else None,
            rule['payment_timing'] if rule and rule['kind']!='none' else None)

    def movement_step_available(self,actor,step):
        if self.equilibrium.enabled and actor.knocked_down:return False
        if self.bindings.control_blocked(actor,'locomotion'):return False
        registry=actor.action_registry
        if registry is None:
            return True
        self.expire_action_restrictions(actor)
        m=self.motion[actor.id]
        body=actor.body_action()
        stable_pace=body is None or body.kind in ('posture','dodge')
        if stable_pace and step=='stop' and m['speed']==0 and m.get('imposed_velocity') is None:
            return True
        if stable_pace and step=='sprint' and m['mode']=='sprinting':
            return True
        if stable_pace and step in ('walk','run'):
            mode='walking' if step=='walk' else 'running'
            speed_key='walking_speed_mps' if step=='walk' else 'running_speed_mps'
            if m['mode']==mode and m['speed']==dec(self.movement_definition['characters'][actor.profile_id][speed_key]):
                return True
        if step in ('crouch','stand') and m.get('pose_transition') is None and (body is None or body.kind!='posture'):
            target=D(1) if step=='crouch' else D(0)
            if self.posture_at(actor.id,self.time)[0]==target:
                return True
        kind=('basic_jump' if step=='jump' else 'posture' if step in ('crouch','stand') else
            'climb' if step=='climb' else 'locomotion')
        phase='recovery' if step=='sprint' or step=='run' and self.motion[actor.id]['mode']=='sprinting' else 'active'
        requirements=self.action_requirements(actor,kind,step,phase)
        occupied,blocked=registry.unavailable(requirements)
        if occupied or blocked:
            self.log('movement_waiting_for_requirements',actor=actor.id,action=step,
                occupied=sorted(occupied),blocked=sorted(blocked))
            return False
        return True

    def weapon_requirements_available(self,actor,ability_id,reload,*,component=None):
        if self.bindings.control_blocked(actor,'weapon'):return False
        if self.weapon_modes.empty(actor,ability_id):return False
        if actor.action_registry is None:
            return True
        self.expire_action_restrictions(actor)
        model=ability_definition(actor,ability_id)['execution_model']
        if model=='ballistic_leap' and not self.body_leaps.available(actor):return False
        if model=='ballistic_dash' and not self.body_dashes.available(actor):
            return False
        if model=='charge_grab' and not self.charge_grapples.available(actor):return False
        if model=='dodge' and not self.dodging.available(actor):return False
        if self.mobile_weapon_blocked(actor) and model not in ('block','dodge','ballistic_dash','ballistic_leap'):
            return False
        kind='reload' if reload else model
        occupied,blocked=actor.action_registry.unavailable(self.action_requirements(actor,kind,ability_id,'recovery',component=component))
        return not occupied and not blocked

    def action_payment(self,actor,action,base,phase='active_start'):
        if actor.action_registry is None:
            return apply_action_dyspnea(actor.dyspnea,base)
        return actor.action_registry.payment(action.id,dec(base),phase)

    def resource_ready_time(self,actor,rule):
        if actor.action_registry is None:
            return super().resource_ready_time(actor,rule)
        if rule['kind']=='none' or actor.action_registry.affordable(rule['base_value']):
            return self.time
        if actor.live_actions() or self.mobile_sprint_effort(actor.id) or self._airborne(actor.id):
            return D('Infinity')
        return super().resource_ready_time(actor,rule)

    def prepare_owned_phase(self,actor,payload):
        if actor.action_registry is not None:
            self.expire_action_restrictions(actor)
        action=actor.action_by_id(payload['action_id'])
        if action is not None and self.bindings.control_blocked(actor,action.kind):
            self.cancel_owned_action(actor,action,'whole_body_bound')
            return None
        if action is not None and action.kind=='aim_toggle' and self.aim_control.running(actor.id):
            self.aim_control.clear(actor.id,'running')
            return None
        if action is not None and actor.action_registry is not None:
            requirements=actor.action_registry.requirements[action.id]
            if (action.kind!='replacement_grab' and self.mobile_weapon_blocked(actor)
                    and any(r.startswith('weapon:') for r in requirements.occupies)):
                self.cancel_owned_action(actor,action,'sprinting_disallows_weapon')
                return None
            blocked=set().union(*actor.action_registry.blocks.values()) if actor.action_registry.blocks else set()
            if requirements.requires&blocked:
                self.cancel_owned_action(actor,action,'phase_requirement_blocked')
                return None
        return action

    def process_mobile_event(self,kind,payload):
        actor=self.fighters.get(payload.get('actor'))
        if actor is not None and actor.action_registry is not None and kind!='movement_command':
            with actor.using_action(actor.body_action()):
                return super().process_mobile_event(kind,payload)
        return super().process_mobile_event(kind,payload)

    def resolve_mobile_contacts(self,contacts):
        contacts=[c for c in contacts if 'collider_id' not in c or
            self.collider_system.registry.contact_live(c,'bodies',self.time)]
        with ExitStack() as scopes:
            for actor in self.fighters.values():
                if actor.action_registry is not None:
                    scopes.enter_context(actor.using_action(actor.body_action()))
            return super().resolve_mobile_contacts(contacts)

    def apply_action_restriction(self,target,*,source,functions,until_ms,wake=True):
        if target not in self.fighters:
            raise ValueError('Unknown restriction target')
        actor=self.fighters[target]
        if actor.action_registry is None:
            raise UnsupportedMechanicError('Function restrictions need owned action rules')
        known=set().union(*(set(v['requires']) for v in self.ownership_definition['actions'].values()))
        known.update('hand:'+hand for hand in actor.hands)
        if not isinstance(source,str) or not source:
            raise ValueError('A restriction needs a source identity')
        if (not isinstance(functions,(list,tuple,set,frozenset)) or not functions or
                any(not isinstance(v,str) or not v for v in functions) or not set(functions)<=known):
            raise ValueError('Unknown required body function')
        until=dec(until_ms)
        if until<=self.time or actor.hp<=0:
            return False
        key=(target,source)
        revision=self.restriction_revisions.get(key,0)+1
        self.restriction_revisions[key]=revision
        affected=actor.action_registry.add_block(source,functions)
        self.restriction_clocks[key]={'until_ms':until,'revision':revision}
        for action in affected:
            self.cancel_owned_action(actor,action,'function_restricted',source=source)
        if 'lower_body' in functions:
            m=self.motion[target]
            if m['jump'] is None and not self._climbing(target):
                m.update(mode='standing',phase=None,speed=D(0),acceleration=D(0))
            elif m['jump'] is not None and 'ground_drive_velocity' in m['jump']:
                m['jump']['ground_drive_velocity']=(D(0),)*3
        self.refresh_mobile_locomotion()
        self.log('action_restriction_applied',actor=target,source=source,functions=sorted(functions),until_ms=until)
        self.push(until,'action_restriction_expired',{'actor':target,'source':source,'revision':revision})
        if wake:self.request_decision(target,self.time)
        return True

    def expire_action_restrictions(self,actor):
        for (target,source),clock in list(self.restriction_clocks.items()):
            if target==actor.id and clock['until_ms']<=self.time:
                actor.action_registry.remove_block(source)
                del self.restriction_clocks[(target,source)]
                self.log('action_restriction_expired',actor=target,source=source)
                self.request_decision(target,self.time)

    def cancel_owned_action(self,actor,action,reason,source=None):
        if actor.action_by_id(action.id) is None:
            return
        self.note_action_cancelled(actor,action,reason,source)
        with actor.using_action(action):
            if action.kind in BODY_KINDS or 'locomotion' in actor.action_registry.requirements[action.id].occupies:
                self.block_mobile_intent(actor,reason)
            if action.kind=='climb' and self._climbing(actor.id):
                self.interrupt_combat_climb(actor,reason)
            elif action.kind=='posture' and action.phase=='active':
                self.freeze_combat_posture(actor,reason)
            elif action.kind=='dodge':
                self.dodging.cancelled(actor,action,reason)
                actor.current=None
            else:
                actor.current=None
                if action.kind=='locomotion':
                    self.motion[actor.id].update(mode='standing',phase=None,speed=D(0),acceleration=D(0))
        action.revision+=1
        self.request_decision(actor.id,self.time)

    def note_action_cancelled(self,actor,action,reason,source=None):
        if actor.action_registry is None or action is None:
            return
        key=(actor.id,action.id)
        if key in self.controlled_cancellation_receipts:
            return
        self.controlled_cancellation_receipts.add(key)
        self.equilibrium.action_cancelled(actor,action,reason)
        self.grapple_break.action_cancelled(actor,action,reason)
        self.bindings.action_cancelled(actor,action,reason)
        self.grapple_casts.action_cancelled(actor,action,reason)
        self.charge_grapples.action_cancelled(actor,action,reason)
        self.aim_control.action_cancelled(actor,action,reason)
        self.turns.cancelled(actor,action,reason)
        self.grappling_gun.action_cancelled(actor,action,reason)
        self.body_leaps.action_cancelled(actor,action,reason)
        self.weapon_modes.cancelled(actor,action,reason)
        self.melee.action_cancelled(actor,action)
        self.controlled_damage.action_cancelled(actor,action,reason)
        self.continuous_effort.action_cancelled(actor,action,reason)
        self.effort_system.action_cancelled(actor,action,reason)
        actor.metrics['controlled_actions_cancelled']+=1
        self.log('controlled_action_cancelled',actor=actor.id,action_id=action.id,action=action.record(),
            reason=reason,source=source,released_effects_continue=True)

    def mobile_result(self):
        result=super().mobile_result()
        if self.ownership_definition is not None:
            result['action_ownership']=deepcopy(self.ownership_definition)
        return result
