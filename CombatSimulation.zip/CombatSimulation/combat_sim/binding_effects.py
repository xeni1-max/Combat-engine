"""Released marking hits, independent life-bound freezes and focused common Break.

Binding work is separate from stored dyspnea: attempted filling still counts at
the bar's cap. ContinuousEffort remains the only writer of actual fill gains.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
from itertools import count

from combat_sim.action_ownership import ActionRequirements
from combat_sim.battle_models import BattleAction,decimal_value as dec
from combat_sim.mechanics.binding import escape_work
from combat_sim.mechanics.life import life_generation
from combat_sim.models import UnsupportedMechanicError
from combat_sim.world_colliders import finite


EVENTS = frozenset(('binding_mark_hit', 'binding_contact_hit', 'binding_mark_expired', 'binding_expired', 'binding_break_boundary'))
FUNCTIONS = {'upper_body': ('upper_body', 'attack'), 'lower_body': ('lower_body',),
             'whole_body': ('upper_body', 'lower_body', 'attack'), 'distance': (), 'fixed_distance': ()}
BREAK_KINDS = frozenset(('binding_break', 'grapple_break'))
WORK_TOLERANCE = D('1e-25')


class BindingEffects:
    def __init__(self, world, definition=None):
        self.world = world
        self.enabled = definition is not None
        self.ids, self.mark_ids, self.hit_ids, self.break_ids = (count(1) for _ in range(4))
        self.bindings, self.marks, self.pools, self.hits, self.attempts = {}, {}, {}, {}, {}
        if self.enabled and (definition != {'mode': 'life_bound_bindings_v1'} or
                not world.continuous_effort.enabled or not world.life_cycles.enabled):
            raise UnsupportedMechanicError('Binding effects require owned lives and shared continuous effort')

    def validate(self, actor, ability_id):
        a = actor.profile['abilities'][ability_id]
        mark = a.get('binding_marks', {})
        if not self.enabled or not self.world.mobile_mode or not self.world.projectiles.trace_schema == 'entity_v1':
            raise UnsupportedMechanicError('Marking projectiles require current binding and projectile entities')
        if (a.get('damage_category') != 'extrinsic' or a.get('damage_type') != 'qard' or
                a.get('dyspnea', {}).get('kind') != 'none' or
                mark.get('kind') not in FUNCTIONS or mark.get('kind') in ('distance','fixed_distance') or type(mark.get('stacks')) is not int or mark['stacks'] <= 0):
            raise UnsupportedMechanicError('Unsupported marking projectile effort or binding rule')
        for key in ('mark_duration_ms', 'binding_duration_ms', 'binding_value'):
            finite(mark[key], 'Marking '+key, positive=True)

    def live(self, row):
        a = self.world.fighters[row['target']]
        live=row['status'] == 'active' and a.hp > 0 and a.life_generation == row['target_life_generation']
        if live and row['kind']=='distance':
            source=self.world.fighters[row['actor']]
            live=source.hp>0 and source.life_generation==row['source_life_generation'] and self.world.distance_constraints.rows[row['distance_id']]['status']=='active'
        if live and row['kind']=='fixed_distance':
            live=self.world.terrain_anchors.live(row['anchor_id']) and self.world.distance_constraints.rows[row['distance_id']]['status']=='active'
        return live

    def validate_projectile(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id];cfg=a.get('binding',{})
        if not (self.enabled and w.gravity_mode and w.body_paths.enabled and w.distance_constraints.enabled):
            raise UnsupportedMechanicError('Binding projectiles require gravity, saved paths and persistent distances')
        timing=actor.profile['timing_profiles'][a['timing_profile']]
        if (cfg.get('kind') not in ('distance','fixed_distance') or a.get('damage_type')!='contact' or
                dec(a.get('pre_mitigation_damage',-1))!=0 or timing.get('projectile_acceleration_mps2',0)!=0):
            raise UnsupportedMechanicError('Binding projectile needs damage-free contact and ballistic distance attachment')
        for key in ('maximum_m','duration_ms','binding_value'):finite(cfg[key],'Binding '+key,positive=True)
        limit=a.get('flight_limit')
        if limit is not None:
            if not isinstance(limit,dict) or limit.get('kind') not in ('ballistic','live_source_distance'):
                raise UnsupportedMechanicError('Unsupported utility projectile flight limit')
            fields={'kind','maximum_m'} if limit['kind']=='live_source_distance' else {'kind'}
            if set(limit)!=fields:raise ValueError('Unexpected utility flight-limit fields')
            if 'maximum_m' in limit:finite(limit['maximum_m'],'Flight limit',positive=True)

    def control_blocked(self, actor, kind):
        return self.enabled and kind not in BREAK_KINDS and any(self.live(r) and
            r['target'] == actor.id and r['kind'] == 'whole_body' for r in self.bindings.values())

    def create(self, packet, *, kind, value, duration_ms, maximum_m=None):
        """Create an independent recipient-life effect; released source death is allowed."""
        with localcontext(Context(prec=self.world.precision)):
            return self._create(packet, kind, value, duration_ms, maximum_m)

    def _create(self, packet, kind, value, duration_ms, maximum_m=None):
        w = self.world
        if not self.enabled:
            raise UnsupportedMechanicError('Binding effects are not enabled')
        if kind not in FUNCTIONS:
            raise ValueError('Unknown body binding kind')
        duration = finite(duration_ms, 'Binding duration', positive=True)
        value = finite(value, 'Binding value')
        for key in ('actor', 'target'):
            if packet.get(key) not in w.fighters:
                raise ValueError('A binding needs known source and recipient actors')
        for key in ('source_life_generation', 'target_life_generation'):
            if life_generation(packet.get(key)) is None:
                raise ValueError('A binding needs source and recipient lives')
        if (not isinstance(packet.get('ability'), str) or not packet['ability'] or
                type(packet.get('action_id')) is not int or packet['action_id'] <= 0):
            raise ValueError('A binding needs an ability/action identity')
        a = w.fighters[packet['target']]
        threshold = escape_work(value, a.profile['max_hp'])
        if a.hp <= 0 or a.life_generation != packet['target_life_generation']:
            return None
        if kind=='distance':
            maximum=finite(maximum_m,'Maximum binding distance',positive=True)
            source=w.fighters[packet['actor']]
            if source.id==a.id:raise ValueError('Distance binding needs distinct endpoints')
            if source.hp<=0 or source.life_generation!=packet['source_life_generation']:return None
            if sum((x-y)**2 for x,y in zip(w.spatial_transitions.reference(source.id),w.spatial_transitions.reference(a.id)))>maximum**2:return None
        elif kind=='fixed_distance':
            maximum=finite(maximum_m,'Maximum ground binding distance',positive=True)
            anchor=w.terrain_anchors.below(a.id,maximum)
            if anchor is None:return None
        elif maximum_m is not None:raise ValueError('Only distance bindings have a maximum separation')
        identity = 'binding:'+str(next(self.ids))
        row = {key: packet[key] for key in ('actor', 'ability', 'action_id', 'source_life_generation',
                                          'target', 'target_life_generation')}
        if 'projectile_id' in packet:
            row['projectile_id'] = packet['projectile_id']
        row.update(id=identity, kind=kind, binding_value=value, maximum_hp=a.profile['max_hp'],
            escape_work_required=threshold, escape_work_done=D(0), started_at_ms=w.time,
            expiry_ms=w.time+duration, status='active')
        if kind=='distance':
            distance_id=w.distance_constraints.attach(packet['actor'],a.id,maximum_m=maximum,
                expires_at_ms=row['expiry_ms'],source=identity,
                expected_lives={packet['actor']:packet['source_life_generation'],a.id:packet['target_life_generation']})
            row.update(distance_id=distance_id,maximum_m=maximum)
            w.distance_constraints.rows[distance_id]['binding_id']=identity
        elif kind=='fixed_distance':
            distance_id=w.distance_constraints.attach_fixed(a.id,anchor,maximum_m=maximum,expires_at_ms=row['expiry_ms'],
                source=identity,expected_life=packet['target_life_generation'])
            anchor_id=w.distance_constraints.rows[distance_id]['anchor_id']
            row.update(distance_id=distance_id,anchor_id=anchor_id,maximum_m=maximum)
            w.distance_constraints.rows[distance_id]['binding_id']=identity
        self.bindings[identity] = row
        if FUNCTIONS[kind]:w.apply_action_restriction(a.id, source=identity, functions=FUNCTIONS[kind], until_ms=row['expiry_ms'])
        if kind == 'whole_body':
            for action in a.live_actions():
                if action.kind not in BREAK_KINDS:
                    w.cancel_owned_action(a, action, 'whole_body_bound', identity)
        w.push(row['expiry_ms'], 'binding_expired', {'binding_id':identity}, priority=0)
        w.log('binding_applied', binding=deepcopy(row))
        return identity

    def queue_contact(self,packet):
        if not self.enabled:return
        ability=self.world.attack_definition(packet['actor'],packet['ability'])
        if ability['execution_model']!='binding_projectile':return
        identity='binding-hit:'+str(next(self.hit_ids))
        payload=self.world.projectile_flights[packet['projectile_id']]['contact_payload']
        self.hits[identity]={'id':identity,'packet':deepcopy(packet),'binding':deepcopy(payload['binding']),'status':'queued'}
        self.world.push(self.world.time,'binding_contact_hit',{'hit_id':identity},priority=3)

    def contact_hit(self,hit):
        w=self.world;p=hit['packet'];target=w.fighters[p['target']];source=w.fighters[p['actor']]
        if target.hp<=0 or target.life_generation!=p['target_life_generation']:
            hit['status']='recipient_life_ended';return
        cfg=hit['binding']
        identity=self.create(p,kind=cfg['kind'],value=cfg['binding_value'],duration_ms=cfg['duration_ms'],maximum_m=cfg['maximum_m'])
        hit['status']='applied' if identity else ('no_reachable_ground_anchor' if cfg['kind']=='fixed_distance' else
            'anchor_life_ended' if source.hp<=0 or source.life_generation!=p['source_life_generation'] else 'outside_maximum_distance')
        hit['binding_id']=identity
        w.log('binding_contact_resolved',**p,binding_id=identity,result=hit['status'])

    def queue_mark(self, packet, calculation):
        if not self.enabled:
            return
        ability = self.world.attack_definition(packet['actor'], packet['ability'], packet.get('melee_component'))
        if ability.get('execution_model') != 'marking_projectile':
            return
        # Personal shields do not prevent a body mark. An independent Block
        # surface must have positive overflow before its caster can be marked.
        # Blocking.route already replaced incoming damage with post-Block power;
        # the later personal-shield allocation is irrelevant to body marking.
        power = calculation.incoming_damage
        if power <= 0:
            return
        identity = 'binding-hit:'+str(next(self.hit_ids))
        self.hits[identity] = {'id':identity, 'packet':deepcopy(packet), 'status':'queued'}
        self.world.push(self.world.time, 'binding_mark_hit', {'hit_id':identity}, priority=3)

    def mark_hit(self, hit):
        w = self.world
        hit['status'] = 'applied'
        p = hit['packet']
        target = w.fighters[p['target']]
        if target.hp <= 0 or target.life_generation != p['target_life_generation']:
            hit['status'] = 'recipient_life_ended'
            return
        cfg = w.attack_definition(p['actor'], p['ability'])['binding_marks']
        key = (p['actor'], p['source_life_generation'], p['ability'], p['target'], p['target_life_generation'])
        row = self.marks.get(self.pools.get(key))
        if row is None or row['status'] != 'active' or row['expiry_ms'] <= w.time:
            identity = 'binding-marks:'+str(next(self.mark_ids))
            row = {k:p[k] for k in ('actor', 'source_life_generation', 'ability', 'target', 'target_life_generation')}
            row.update(id=identity, started_at_ms=w.time, count=0, revision=0, status='active', pool_key=key)
            self.marks[identity] = row
            self.pools[key] = identity
        row.update(count=row['count']+1, revision=row['revision']+1, last_hit_at_ms=w.time,
                   expiry_ms=w.time+finite(cfg['mark_duration_ms'], 'Mark duration', positive=True))
        w.log('binding_mark_added', marks=self.mark_record(row), projectile_id=p['projectile_id'])
        if row['count'] >= cfg['stacks']:
            row.update(status='consumed', ended_at_ms=w.time)
            self.pools.pop(key, None)
            row['binding_id'] = self.create(p, kind=cfg['kind'], value=cfg['binding_value'], duration_ms=cfg['binding_duration_ms'])
            w.log('binding_marks_consumed', marks=self.mark_record(row))
        else:
            w.push(row['expiry_ms'], 'binding_mark_expired', {'marks_id':row['id'], 'revision':row['revision']}, priority=0)

    def mark_record(self, row):
        return deepcopy({k:v for k,v in row.items() if k != 'pool_key'})

    def requirements(self):
        return ActionRequirements(frozenset(('binding_break',)), frozenset())

    def select(self, actor, identity=None):
        return min((r for r in self.bindings.values() if self.live(r) and r['target'] == actor and
                    (identity is None or r['id'] == identity)),
                   key=lambda r:(r['started_at_ms'], r['id']), default=None)

    def focused(self, actor):
        return next((r for r in self.attempts.values() if r['actor'] == actor and r['status'] != 'ended'), None)

    def command(self, actor, command, identity=None):
        with localcontext(Context(prec=self.world.precision)):
            return self._command(actor, command, identity)

    def _command(self, actor, command, identity):
        w = self.world
        if not self.enabled:
            raise UnsupportedMechanicError('Binding Break is not enabled')
        if actor not in w.fighters or command not in ('break','break_binding','stop_binding_break'):
            raise ValueError('Unknown binding Break actor or command')
        if identity is not None and (not isinstance(identity,str) or not identity):
            raise ValueError('A binding identity must be nonempty')
        if w.fighters[actor].hp <= 0:
            return {'status':'ignored','reason':'actor_life_ended'}
        previous = self.focused(actor)
        if command == 'stop_binding_break':
            if previous is None or identity is not None and previous['binding_id'] != identity:
                return {'status':'ignored', 'reason':'no_focused_binding_break'}
            self.finish_attempt(previous, 'stopped')
            return {'status':'stopped', 'binding_id':previous['binding_id']}
        binding = self.select(actor, identity)
        if binding is None:
            return {'status':'ignored', 'reason':'no_eligible_binding'}
        if previous is not None:
            return {'status':'duplicate' if previous['binding_id'] == binding['id'] else 'ignored',
                    'reason':'binding_break_already_focused', 'binding_id':previous['binding_id']}
        if binding['escape_work_done'] >= binding['escape_work_required']:
            self.end(binding, 'break_escaped')
            return {'status':'escaped', 'binding_id':binding['id']}
        a = w.fighters[actor]
        identity = 'binding-break:'+str(next(self.break_ids))
        action = BattleAction(next(w.action_ids), actor, binding['actor'], 'break', 'binding_break',
            w.time, w.time, binding['expiry_ms']-w.time, phase='filling', active_end_ms=binding['expiry_ms'],
            life_generation=a.life_generation)
        a.current = action
        row = {'id':identity, 'binding_id':binding['id'], 'actor':actor, 'life_generation':a.life_generation,
               'action_id':action.id, 'started_at_ms':w.time, 'status':'filling',
               'boundary_revision':0, 'boundary_at_ms':None}
        self.attempts[identity] = row
        channel = w.continuous_effort.start(a, action, tag='binding_break:'+identity, kind='fill', base=20,
                                          until_ms=binding['expiry_ms'])
        row['effort_channel_id'] = channel.id
        self.settle()
        w.log('binding_break_started', attempt=deepcopy(row))
        return {'status':row['status'], 'binding_id':binding['id'], 'attempt_id':identity}

    def channel_enabled(self, channel):
        return not channel.tag.startswith('binding_break:') or self.world.fighters[channel.actor].disorientation <= 0

    def advance(self, actor, begin, end):
        row = self.focused(actor.id) if self.enabled else None
        if row is None:
            return
        binding = self.bindings[row['binding_id']]
        elapsed = max(D(0), end-begin-actor.disorientation)
        if elapsed:
            before = binding['escape_work_done']
            binding['escape_work_done'] = min(binding['escape_work_required'], before+20*elapsed/1000)
            self.world.log('binding_break_work', attempt_id=row['id'], binding_id=binding['id'],
                actor=actor.id, interval_start_ms=begin, interval_end_ms=end,
                amount=binding['escape_work_done']-before, work_done=binding['escape_work_done'])

    def finish_attempt(self, row, reason):
        if row['status'] == 'ended':
            return
        w = self.world
        row.update(status='ended', ended_at_ms=w.time, end_reason=reason)
        channel = w.continuous_effort.channels[row['effort_channel_id']]
        w.continuous_effort.end(channel, reason)
        row['actual_dyspnea_gained'] = channel.gained
        a = w.fighters[row['actor']]
        action = a.action_by_id(row['action_id'])
        if action is not None:
            action.phase = 'ended'
            action.revision += 1
            a.action_registry.release(action.id)
        w.log('binding_break_ended', attempt=deepcopy(row))
        w.request_decision(a.id, w.time)

    def end(self, row, reason):
        if row['status'] != 'active':
            return
        w = self.world
        row.update(status='ended', ended_at_ms=w.time, end_reason=reason)
        attempt = self.focused(row['target'])
        if attempt is not None and attempt['binding_id'] == row['id']:
            self.finish_attempt(attempt, reason)
        a = w.fighters[row['target']]
        a.action_registry.remove_block(row['id'])
        w.restriction_clocks.pop((a.id, row['id']), None)
        if row['kind'] in ('distance','fixed_distance'):w.distance_constraints.release(row['distance_id'],reason=reason)
        w.log('binding_ended', binding=deepcopy(row))
        w.request_decision(a.id, w.time)

    def action_cancelled(self, actor, action, reason):
        if action.kind == 'binding_break':
            row = self.focused(actor.id)
            if row is not None and row['action_id'] == action.id:
                self.finish_attempt(row, reason)

    def retire_life(self, actor):
        if not self.enabled:
            return
        for row in self.bindings.values():
            if row['target'] == actor.id and row['target_life_generation'] == actor.life_generation:
                self.end(row, 'recipient_life_ended')
            elif row['kind']=='distance' and row['actor']==actor.id and row['source_life_generation']==actor.life_generation:
                self.end(row,'anchor_life_ended')
        for row in self.marks.values():
            if row['status'] == 'active' and row['target'] == actor.id and row['target_life_generation'] == actor.life_generation:
                row.update(status='ended', ended_at_ms=self.world.time, end_reason='recipient_life_ended')
                self.pools.pop(row['pool_key'], None)

    def settle(self):
        if not self.enabled:
            return
        w = self.world
        for row in self.bindings.values():
            if row['status'] == 'active' and (not self.live(row) or w.time >= row['expiry_ms']):
                reason=('duration_expired' if w.time>=row['expiry_ms'] else 'recipient_life_ended'
                    if w.fighters[row['target']].hp<=0 or w.fighters[row['target']].life_generation!=row['target_life_generation'] else 'anchor_life_ended')
                if row['kind']=='fixed_distance' and reason=='anchor_life_ended':
                    anchor=w.terrain_anchors.rows[row['anchor_id']]
                    reason=w.terrain_anchors.invalid_reason(row['anchor_id']) or anchor.get('end_reason','distance_ended')
                self.end(row,reason)
        for row in self.attempts.values():
            if row['status'] == 'ended':
                continue
            a = w.fighters[row['actor']]
            if a.action_by_id(row['action_id']) is None:
                self.finish_attempt(row, 'owned_action_ended')
                continue
            status = 'paused_disorientation' if a.disorientation > 0 else 'filling'
            if row['status'] != status:
                row['status'] = status
                w.log('binding_break_state', attempt=deepcopy(row))

    def prepare(self, end):
        if not self.enabled or end <= self.world.time:
            return end
        self.settle()
        w = self.world
        finish = end
        for row in self.attempts.values():
            if row['status'] == 'ended':
                continue
            binding = self.bindings[row['binding_id']]
            o = w.fighters[row['actor']].disorientation
            remaining = max(D(0), binding['escape_work_required']-binding['escape_work_done'])
            boundary = w.time+o+remaining*50
            if o > 0:
                finish = min(finish, w.time+o)
            if boundary >= binding['expiry_ms']:
                continue
            if row['boundary_at_ms'] is None or abs(row['boundary_at_ms']-boundary) > WORK_TOLERANCE:
                row['boundary_revision'] += 1
                row['boundary_at_ms'] = boundary
                w.push(boundary, 'binding_break_boundary', {'attempt_id':row['id'], 'revision':row['boundary_revision']}, priority=4)
            finish = min(finish, boundary)
        return finish

    def event_live(self, kind, p):
        if kind in ('binding_mark_hit','binding_contact_hit'):
            return self.hits[p['hit_id']]['status'] == 'queued'
        if kind == 'binding_mark_expired':
            row = self.marks[p['marks_id']]
            return row['status'] == 'active' and row['revision'] == p['revision']
        if kind == 'binding_expired':
            return self.bindings[p['binding_id']]['status'] == 'active'
        row = self.attempts[p['attempt_id']]
        return row['status'] != 'ended' and row['boundary_revision'] == p['revision']

    def process(self, kind, p):
        if not self.event_live(kind, p):
            return
        w = self.world
        if kind == 'binding_mark_hit':
            return self.mark_hit(self.hits[p['hit_id']])
        if kind == 'binding_contact_hit':return self.contact_hit(self.hits[p['hit_id']])
        if kind == 'binding_mark_expired':
            row = self.marks[p['marks_id']]
            row.update(status='expired', ended_at_ms=w.time)
            self.pools.pop(row['pool_key'], None)
            w.log('binding_marks_expired', marks=self.mark_record(row))
            return
        if kind == 'binding_expired':
            return self.end(self.bindings[p['binding_id']], 'duration_expired')
        row = self.attempts[p['attempt_id']]
        binding = self.bindings[row['binding_id']]
        row['boundary_at_ms'] = None
        if binding['escape_work_required']-binding['escape_work_done'] <= WORK_TOLERANCE:
            binding['escape_work_done'] = binding['escape_work_required']
            self.end(binding, 'break_escaped')

    def result(self):
        return {'binding_rules':deepcopy(self.world.combat_locomotion_input['binding_effects']),
                'binding_marks':[self.mark_record(r) for r in self.marks.values()],
                'binding_instances':deepcopy(list(self.bindings.values())),
                'binding_break_attempts':deepcopy(list(self.attempts.values()))} if self.enabled else {}
