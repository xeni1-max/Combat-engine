"""Shared-body trajectory composition above the existing movement controllers."""
from decimal import Context,Decimal as D,localcontext

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.dyspnea import DyspneaContext,apply_action_dyspnea
from combat_sim.spatial_motion import CONTACT_SPEED_EPS_MPS as SPEED


class LinkedMotionRules:
    def free_mobile_motion(self,name):return super().mobile_motion(name)

    def mobile_motion(self,name):
        links=getattr(self,'grapple_links',None)
        if links is not None and links.enabled and links.joined(name):return links.motion(name)
        return super().mobile_motion(name)

    def mobile_contact_velocity(self,name,seconds):
        if self.grapple_links.joined(name):
            v,a=self.mobile_motion(name)
            return tuple(x+y*seconds for x,y in zip(v,a))
        return super().mobile_contact_velocity(name,seconds)

    def mobile_dyspnea_context(self,actor):
        context=super().mobile_dyspnea_context(actor)
        if not self.grapple_links.joined(actor.id):return context
        return DyspneaContext(context.movement,context.disoriented,context.unstable,True,
            context.active,context.gathering,context.recovering)

    def resource_ready_time(self,actor,rule):
        if self.grapple_links.joined(actor.id) and rule['kind']!='none' and not apply_action_dyspnea(actor.dyspnea,rule['base_value']).allowed:
            return D('Infinity')
        return super().resource_ready_time(actor,rule)

    def start_basic_jump(self,actor):
        # The existing takeoff keeps actual horizontal velocity. In a linked
        # group that value was already averaged; retain the independent input
        # behind it so the group projection does not average it a second time.
        horizontal=self.free_mobile_motion(actor.id)[0][:2] if self.grapple_links.joined(actor.id) else None
        action=actor.current
        result=super().start_basic_jump(actor)
        flight=self.motion[actor.id]['jump']
        if horizontal is not None and action.phase=='active' and flight is not None and flight.get('basic_jump'):
            flight['velocity']=(*horizontal,flight['velocity'][2])
            self.refresh_mobile_locomotion()
            self.log('grapple_jump_drive_preserved',actor=actor.id,action_id=action.id,
                free_horizontal_velocity_mps=horizontal,shared_velocity_mps=self.mobile_motion(actor.id)[0])
        return result

    def _sync_link_vertical(self,group,velocity):
        for name in group:
            if self._climbing(name):continue
            actor,m=self.fighters[name],self.motion[name]
            support=self.collider_system.find_support(actor)
            if self.terrain_support.enabled and m['jump'] is None and support is None and velocity[2]<=SPEED:
                # Saved-prefix consumption may query this intermediate driver.
                # Common settled support loss owns flight conversion and keeps
                # the independent motor, rather than creating an unpaid jump.
                continue
            if velocity[2]>SPEED or support is None or m['jump'] is not None:
                before=m['jump'];free=self.free_mobile_motion(name)[0]
                m['jump']={**(before or {}),'velocity':(*free[:2],velocity[2]),
                    'basic_jump':bool(before and before.get('basic_jump',False))}
                m.update(support_id=None,support_part=None)
            else:
                m.update(support_id=support[0],support_part=support[1])

    def refresh_mobile_locomotion(self):
        links=getattr(self,'grapple_links',None)
        groups=links.groups() if links is not None and links.enabled and hasattr(self,'world_bodies') else ()
        # Refreshes occur inside an Active-start batch. Defer this component's
        # physical synchronization until all same-clock controls can be seen.
        for group in groups:
            if not any(self._climbing(n) for n in group):self._sync_link_vertical(group,self.mobile_motion(group[0])[0])
        super().refresh_mobile_locomotion()
        for group in groups:
            velocity,_=self.mobile_motion(group[0])
            for name in group:
                self.fighters[name].locomotion.update(velocity_mps=[str(v) for v in velocity],
                    speed_mps=str(sum(v*v for v in velocity[:2]).sqrt()),grapple_group=list(group))

    def advance_mobile_geometry(self,begin,end):
        snapshots=[]
        for group in self.grapple_links.groups():
            v,a=self.mobile_motion(group[0]);refs={n:self.spatial_transitions.reference(n) for n in group}
            snapshots.append((group,v,a,refs))
        super().advance_mobile_geometry(begin,end)
        seconds=(end-begin)/1000
        for group,v,a,refs in snapshots:
            current=tuple(x+y*seconds for x,y in zip(v,a))
            for name in group:
                reference=tuple(p+x*seconds+y*seconds*seconds/2 for p,x,y in zip(refs[name],v,a))
                self.set_body_reference(name,reference)
                self.motion[name]['ground_origin_z']=reference[2]
            self._sync_link_vertical(group,current)

    def resolve_mobile_contacts(self,contacts):
        if self.closing_reference_contacts:
            contacts=[dict(c,pose_only=True) if not c.get('angular_collision') and not self.reference_contact_closing(c) else c for c in contacts]
        signals=getattr(self,'contact_signals',None)
        contact_wave=signals.capture(contacts) if signals is not None else None
        charges=getattr(self,'charge_grapples',None)
        if charges is not None and charges.enabled and charges.casts:
            charges.before_native(contact_wave)
            contacts=[c for c in contacts if 'collider_id' not in c or
                self.collider_system.registry.contact_live(c,'bodies',self.time)]
        previous=self.knock_motion.contact_frames
        previous_inelastic=self.knock_motion.contact_inelastic
        if self.closing_reference_contacts:
            self.knock_motion.contact_frames=self.knock_motion.rebound_frames(contacts)
            self.knock_motion.contact_inelastic=self.knock_motion.stabilize_repeats(contacts)
        try:
            plan=self.grapple_links.capture_contacts(contacts)
            result=super().resolve_mobile_contacts(contacts)
            self.grapple_links.finish_contacts(plan)
            self.body_support.contact_resolved(contacts)
            self.body_support.settle()
            if plan:self.refresh_mobile_locomotion()
            if signals is not None:signals.commit(contact_wave)
            return result
        finally:
            self.knock_motion.contact_frames=previous
            self.knock_motion.contact_inelastic=previous_inelastic

    def settle_climb_constraints(self):
        """Close incompatible prescribed controls before consuming a future path.

        Keep each cancelled control's own momentum behind the group projection;
        averaging the already shared velocity would divide it a second time.
        Decisions resume after this monotone control-retirement closure.
        """
        cancelled=set()
        with localcontext(Context(prec=self.precision)):
            while True:
                climbers=tuple(n for n in sorted(self.fighters) if self._climbing(n))
                if not climbers or not (self.grapple_links.groups() or self.distance_constraints.active() or self.body_support.active()):break
                frame=self.body_paths.ensure(future=True)
                if frame.end_ms<=self.time:break
                pieces=dict(frame.pieces)
                incompatible=[n for n in climbers if not self.distance_constraints.climb_compatible(n,pieces[n])]
                if not incompatible:break
                for name in incompatible:
                    group=self.grapple_links.group(name)
                    self.log('climb_constraint_redirected',actor=name,actors=group,reference_m=self.spatial_transitions.reference(name),
                        projected_velocity_mps=tuple(map(dec,pieces[name].velocity(self.time))))
                    reason='grapple_motion_redirected' if len(group)>1 else 'constraint_motion_redirected'
                    self.interrupt_combat_climb(self.fighters[name],reason,resume_decision=False)
                    cancelled.add(name)
                self.body_paths.invalidate();self.refresh_mobile_locomotion()
            for name in sorted(cancelled):self.request_decision(name,self.time)
        return bool(cancelled)

    def next_mobile_knot(self,end):
        return self.grapple_links.next_boundary(super().next_mobile_knot(end))
