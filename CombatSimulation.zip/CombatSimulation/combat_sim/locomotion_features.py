"""Crouch poses and sprint transitions in the shared geometry/timing scope."""
from decimal import Decimal as D

from combat_sim.character_geometry import actor_body,crouch_target
from combat_sim.battle_models import decimal_value as dec, ceil_ms
from combat_sim.hitboxes import combined_bounds, local_to_world_point
from combat_sim.models import UnsupportedMechanicError, as_fraction
from combat_sim.movement_contacts import first_box_contact
from combat_sim.postures import LEGS, body_origin_from_bounds, crouch_drop_m, world_posture_cuboids


class LocomotionFeatureRules:
    def setup_locomotion_features(self):
        self.crouch_definition=self.movement_definition.get('crouch')
        self.sprint_definition=self.movement_definition.get('sprint')
        c,s=self.crouch_definition,self.sprint_definition
        if c is not None:
            if (c.get('status')!='confirmed_by_author' or c.get('geometry')!='shorten_legs_lower_upper_body' or
                c.get('pose_curve')!='linear_during_active' or c.get('standing_clearance')!='required'):
                raise UnsupportedMechanicError('Unsupported crouch definition')
        if s is not None and (s.get('status')!='confirmed_by_author' or
            s.get('speed_curve')!='linear_during_active' or s.get('attacks_allowed') is not False):
            raise UnsupportedMechanicError('Unsupported sprint definition')
        for name,actor in self.fighters.items():
            m=self.motion[name]
            if c is not None:
                crouch_drop_m(actor_body(self,name),1,crouch_target(self,name,c['target_leg_height_m']))
                p=c['characters'][actor.profile_id]
                if any(dec(p[k])<=0 or dec(p[k])!=ceil_ms(dec(p[k])) for k in ('crouch_active_ms','stand_active_ms')):
                    raise ValueError('Posture durations must be positive')
                m.update(crouch_fraction=D(0),pose_transition=None,
                    posture_hand_reference={hand:tuple(as_fraction(v) for v in point) for hand,point in actor.hands.items()})
                actor.metrics.update(crouches_started=0,crouches_completed=0,
                    stands_completed=0,stand_requests_rejected=0)
            if s is not None:
                p=s['characters'][actor.profile_id]
                if (dec(p['speed_bonus_mps'])<=0 or dec(p['run_sprint_active_ms'])<=0 or
                    dec(p['run_sprint_active_ms'])!=ceil_ms(dec(p['run_sprint_active_ms']))):
                    raise ValueError('Sprint speed bonus and duration must be positive')
                actor.metrics['sprint_transitions']=0

    def posture_at(self,name,time):
        if self.crouch_definition is None:return D(0),D(0)
        m=self.motion[name];p=m['pose_transition']
        if p is None:return m['crouch_fraction'],D(0)
        q=min(D(1),max(D(0),(time-p['start_ms'])/p['duration_ms']))
        fraction=p['from']+(p['to']-p['from'])*q
        rate=(p['to']-p['from'])/(p['duration_ms']/1000) if q<1 else D(0)
        return fraction,rate

    def pose_part_motion(self,name,part,time):
        if self.crouch_definition is None:return (D(0),)*3,(D(0),)*3
        _,rate=self.posture_at(name,time)
        drop_rate=dec(crouch_drop_m(actor_body(self,name),1,
            crouch_target(self,name,self.crouch_definition['target_leg_height_m'])))*rate
        if part in LEGS:return (D(0),D(0),-drop_rate/2),(D(0),D(0),-drop_rate)
        return (D(0),D(0),-drop_rate),(D(0),)*3

    def pose_part_acceleration(self,name,part,time):
        return (D(0),)*3,(D(0),)*3

    def update_posture_geometry(self,time):
        if self.crouch_definition is None:return
        c=self.crouch_definition
        floor=dec(self.scenario['encounter']['ground_z_m'])
        for name,actor in self.fighters.items():
            full_drop=dec(crouch_drop_m(actor_body(self,name),1,crouch_target(self,name,c['target_leg_height_m'])))
            m=self.motion[name];fraction,rate=self.posture_at(name,time)
            drop=full_drop*fraction
            xy,height,velocity,_,_=self.motion_at(name,time)
            if fraction:
                reference=(*xy,m['ground_origin_z']+max(D(0),height))
                self.world_bodies[name]=world_posture_cuboids(actor_body(self,name),reference,actor.facing,
                    fraction,crouch_target(self,name,c['target_leg_height_m']))
                actor.body_origin_m=tuple(map(dec,body_origin_from_bounds(self.world_bodies[name])))
            low,high=combined_bounds(self.world_bodies[name])
            feet=dec(low[2]);body_height=dec(high[2]-low[2])
            # This geometry scope has no weapon actions. Evaluate hand pose
            # from its reference each time, avoiding observation-dependent drift.
            actor.hands={hand:[dec(point[0]),dec(point[1]),dec(point[2])-drop/2]
                         for hand,point in m['posture_hand_reference'].items()}
            actor.pose_drop_m=drop
            posture=('crouching' if rate>0 else 'standing_up' if rate<0 else
                     'crouched' if fraction==1 else 'standing')
            world_hands={hand:[str(dec(v)) for v in local_to_world_point(point,actor.body_origin_m,actor.facing)]
                         for hand,point in actor.hands.items()}
            actor.locomotion.update(posture=posture,crouch_fraction=str(fraction),crouch_drop_m=str(drop),
                body_height_m=str(body_height),feet_z_m=str(feet),height_above_ground_m=str(feet-floor),
                height_above_support_m=str(feet-(m['ground_origin_z']+dec(actor_body(self,name)['standing_placement']['ground_z_m']))),
                feet_velocity_mps=[str(v) for v in velocity],
                velocity_mps=[str(velocity[0]),str(velocity[1]),str(velocity[2]-full_drop*rate/2)],
                hand_world_positions_m=world_hands)

    def standing_clearance(self,name,duration):
        """Check the planned expansion against current solid occupancy."""
        actor=self.fighters[name];m=self.motion[name]
        xy,height,_,_,_=self.motion_at(name,self.time+duration)
        reference=(*xy,m['ground_origin_z']+height)
        target=world_posture_cuboids(actor_body(self,name),reference,actor.facing,0,
                                   crouch_target(self,name,self.crouch_definition['target_leg_height_m']))
        target={b.part:b for b in target}
        obstacles=[box for key,boxes in self.terrain_colliders.items()
                   if key!=self.terrain_definition['ground']['id'] for box in boxes]
        obstacles.extend(box for other,boxes in self.world_bodies.items() if other!=name for box in boxes)
        seconds=duration/1000
        for box in self.world_bodies[name]:
            end=target[box.part]
            v=tuple((dec(b)-dec(a))/seconds for a,b in zip(box.centre_m,end.centre_m))
            sizes=tuple((dec(b)-dec(a))/seconds for a,b in zip(box.size_m,end.size_m))
            for obstacle in obstacles:
                contact=first_box_contact(box,obstacle,v,(0,0,0),seconds,left_size_rate_mps=sizes)
                if contact is not None and contact<seconds-D('1e-25'):return False
        return True

    def handle_locomotion_feature_command(self,name,action):
        actor=self.fighters[name];m=self.motion[name]
        fraction,_=self.posture_at(name,self.time)
        if fraction and action=='climb':
            raise UnsupportedMechanicError('Stand up before climbing; crouched climb completion pose is unspecified')
        if m['mode']=='sprinting' and action in ('walk','jump','climb'):
            raise UnsupportedMechanicError('Return from sprinting to running before that action; its direct transition is unspecified')
        if action in ('crouch','stand'):
            if self.crouch_definition is None:raise UnsupportedMechanicError('Posture commands require an explicit crouch definition')
            if m['mode'] not in ('standing','walking','running','sprinting'):
                raise UnsupportedMechanicError('Posture changes require a supported ground movement mode')
            target=D(1) if action=='crouch' else D(0)
            if target==fraction:
                self.log('posture_command_no_change',actor=name,action=action)
                return True
            p=self.crouch_definition['characters'][actor.profile_id]
            duration=dec(p['crouch_active_ms' if action=='crouch' else 'stand_active_ms'])
            if action=='stand' and not self.standing_clearance(name,duration):
                actor.metrics['stand_requests_rejected']+=1
                self.log('stand_rejected',actor=name,reason='insufficient_clearance')
                return True
            m.update(phase='posture_active',pose_transition={'from':fraction,'to':target,
                'start_ms':self.time,'duration_ms':duration})
            if action=='crouch':actor.metrics['crouches_started']+=1
            self.log('posture_transition_started',actor=name,action=action,from_fraction=fraction,to_fraction=target,
                     active_ms=duration,active_end_ms=self.time+duration)
            self.push(self.time+duration,'movement_pose_completed',{'actor':name,'revision':m['revision']})
            return True
        if action=='sprint' or (action=='run' and m['mode']=='sprinting'):
            if self.sprint_definition is None:raise UnsupportedMechanicError('Sprint command requires an explicit sprint definition')
            if action=='sprint' and m['mode']=='sprinting':
                self.log('movement_command_no_change',actor=name,action=action)
                return True
            if action=='sprint' and m['mode']!='running':
                raise UnsupportedMechanicError('Enter running before sprinting; direct stand/walk-to-sprint timing is unspecified')
            p=self.sprint_definition['characters'][actor.profile_id]
            base=dec(self.movement_definition['characters'][actor.profile_id]['running_speed_mps'])
            target=base+dec(p['speed_bonus_mps']) if action=='sprint' else base
            speed=self.motion_at(name,self.time)[4];duration=dec(p['run_sprint_active_ms'])
            m.update(phase='transition_active',target_speed=target,target_mode='sprinting' if action=='sprint' else 'running')
            self.reanchor_motion(name,speed,(target-speed)/(duration/1000))
            actor.metrics['sprint_transitions']+=1
            self.log('sprint_transition_started',actor=name,from_speed_mps=speed,to_speed_mps=target,
                     active_ms=duration,active_end_ms=self.time+duration,action=action)
            self.push(self.time+duration,'movement_transition_ended',{'actor':name,'revision':m['revision']})
            return True
        return False

    def process_posture_event(self,p):
        name=p['actor'];m=self.motion[name];actor=self.fighters[name]
        target=m['pose_transition']['to']
        m.update(crouch_fraction=target,pose_transition=None,phase=None)
        actor.metrics['crouches_completed' if target else 'stands_completed']+=1
        self.update_movement_geometry(self.time)
        self.log('crouch_completed' if target else 'stand_completed',actor=name,body_origin_m=actor.body_origin_m,
                 body_height_m=actor.locomotion['body_height_m'],feet_z_m=actor.locomotion['feet_z_m'])
