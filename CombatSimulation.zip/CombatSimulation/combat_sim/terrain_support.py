"""Static face witnesses and departure boundaries for the shared saved paths.

No translation or gravity writer lives here. BodySupport closes support changes
through SpatialTransitions after the saved prefix has been consumed atomically.
"""
from fractions import Fraction as F

from combat_sim.mechanics.support_geometry import static_witnesses,static_face_gaps,first_overlap_departure
from combat_sim.models import UnsupportedMechanicError
from combat_sim.pose_kinematics import pose_acceleration
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M
from combat_sim.angular_support import support_departure


class TerrainSupport:
    def __init__(self,world,definition=None):
        self.world=world;self.enabled=definition is not None
        self.finite_ground=definition=={'mode':'finite_faces_v2'}
        if self.enabled and (definition not in ({'mode':'static_faces_v1'},{'mode':'finite_faces_v2'}) or not world.mobile_mode or
                not world.body_paths.enabled or not world.body_support.enabled or not world.spatial_transitions.enabled):
            raise UnsupportedMechanicError('Static face support requires saved paths, living-body support and atomic gravity transitions')

    def witnesses(self,name,boxes):
        return static_witnesses(name,boxes,self.world.collider_system.registry.active('bodies',self.world.time),
            distance_epsilon=CONTACT_DISTANCE_EPS_M)

    def find_support(self,name,boxes):
        rows=self.witnesses(name,boxes)
        return (rows[0].lower,rows[0].lower_part) if rows else None

    def departure(self,pieces,end):
        if not self.enabled:return end
        w=self.world;now=F(w.time);limit=F(end)
        for name,piece in pieces:
            actor=w.fighters[name]
            if actor.hp<=0 or w._airborne(name) or w._climbing(name):continue
            boxes=w.world_bodies[name]
            for witness in self.witnesses(name,boxes):
                upper=next(p for p in boxes if p.part==witness.upper_part)
                lower=next(p for p in w.terrain_colliders[witness.lower] if p.part==witness.lower_part)
                if w.turns.active(name):
                    path=w.turns.path_from_piece(name,upper,piece.slice(now,limit))
                    loss=support_departure(path,lower,now/1000,limit/1000,
                        distance_epsilon=CONTACT_DISTANCE_EPS_M,precision=w.precision)
                    if loss is not None:limit=min(limit,loss*1000)
                    continue
                velocity,size_rate=w.pose_part_motion(name,upper.part,w.time)
                acceleration,size_acceleration=pose_acceleration(w,name,upper.part,w.time)
                gaps=static_face_gaps(upper,lower,
                    tuple(x+F(y) for x,y in zip(piece.velocity_mps,velocity)),
                    tuple(x+F(y) for x,y in zip(piece.acceleration_mps2,acceleration)),
                    size_rate=size_rate,size_acceleration=size_acceleration,distance_epsilon=CONTACT_DISTANCE_EPS_M)
                loss=first_overlap_departure(gaps,(limit-now)/1000,distance_epsilon=CONTACT_DISTANCE_EPS_M)
                if loss is not None:limit=min(limit,now+loss*1000)
        return limit

    def result(self):
        return {'terrain_support_rules':self.world.combat_locomotion_input['terrain_support']} if self.enabled else {}
