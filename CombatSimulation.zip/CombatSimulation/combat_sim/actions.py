"""Replaceable source of explicit, reproducible action inputs."""

from copy import deepcopy
from typing import Any, Iterable


class ScriptedActionSequence:
    """Supplies scenario-selected activations or confirmed impacts in order."""

    def __init__(self, inputs: Iterable[dict[str, Any]]):
        self._inputs = deepcopy(list(inputs))

    def inputs(self) -> list[dict[str, Any]]:
        return deepcopy(self._inputs)


class RepeatFirePolicy:
    """Finite reproducible decisions, separate from weapon/combat mechanics."""

    def __init__(self, shot_count: int, *, reload_when_empty: bool):
        if isinstance(shot_count, bool) or not isinstance(shot_count, int) or shot_count <= 0:
            raise ValueError('shot_count must be a positive integer')
        if not isinstance(reload_when_empty, bool):
            raise ValueError('reload_when_empty must be boolean')
        self.shot_count = shot_count
        self.reload_when_empty = reload_when_empty

    def choose(self, shots_released: int, ammo: int) -> str | None:
        if shots_released >= self.shot_count:
            return None
        if ammo > 0:
            return 'fire'
        return 'reload' if self.reload_when_empty else None
