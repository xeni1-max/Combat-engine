"""Dispatch existing passive definitions without conflating their controllers."""
from combat_sim.models import UnsupportedMechanicError


class PassiveAbilities:
    def __init__(self,world):self.world=world

    def attach(self):
        handlers={'damage_fraction_heal':(self.world.healing,self.world.healing.attach),
            'attack_modifier_passive':(self.world.attack_modifiers,self.world.attack_modifiers.attach_passives)}
        if any(controller.enabled for controller,_ in handlers.values()):
            for actor in self.world.fighters.values():
                definitions=actor.profile.get('passive_effects',{})
                if not isinstance(definitions,dict):raise ValueError('Passive definitions must be keyed by ability')
                for ability,cfg in definitions.items():
                    if not isinstance(ability,str) or not ability or not isinstance(cfg,dict):
                        raise ValueError('Passive ability needs an identity and definition')
                    if cfg.get('execution_model') not in handlers:
                        raise UnsupportedMechanicError('Unsupported passive ability controller')
                    if ability in actor.profile.get('abilities',{}) or ability in actor.profile.get('automatic_abilities',{}):
                        raise ValueError('Passive and active/automatic definitions must not alias')
        for _,attach in handlers.values():attach()
