"""Contact feature velocities and SAT margin derivatives for upright yaw paths."""
from fractions import Fraction as F

from combat_sim.angular_paths import RotatingBoxPath
from combat_sim.orientation import dot, vector3
from combat_sim.oriented_geometry import axes, projected_size

ZERO = (F(0),)*3


def up_cross(v):return -v[1], v[0], F(0)


def state(path,time):
    if not isinstance(path,RotatingBoxPath):return path,ZERO,ZERO,ZERO,ZERO,F(0)
    box=path.at_time(time);s=path.centre_state(time);t=path.yaw.elapsed(time)
    rate=tuple(v+a*t for v,a in zip(path.size_rate_mps,path.size_acceleration_mps2))
    return box,s.velocity_mps,s.acceleration_mps2,rate,path.size_acceleration_mps2,path.yaw.angular_speed


def margins(first,second,time):
    a,av,aa,ar,aq,aw=state(first,time);b,bv,ba,br,bq,bw=state(second,time)
    delta=tuple(x-y for x,y in zip(a.centre_m,b.centre_m))
    v=tuple(x-y for x,y in zip(av,bv));acc=tuple(x-y for x,y in zip(aa,ba))
    candidates=[(n,aw) for n in axes(a)[:2]]+[(n,bw) for n in axes(b)[:2]]+[((F(0),F(0),F(1)),F(0))]
    rows=[]
    for normal,omega in candidates:
        nv=tuple(omega*x for x in up_cross(normal));na=tuple(-omega*omega*x if i<2 else F(0) for i,x in enumerate(normal))
        d=dot(delta,normal);dv=dot(v,normal)+dot(delta,nv)
        da=dot(acc,normal)+2*dot(v,nv)+dot(delta,na)
        half=hv=ha=F(0)
        for box,rate,change,spin in ((a,ar,aq,aw),(b,br,bq,bw)):
            for size,sv,sa,basis in zip(box.size_m,rate,change,axes(box)):
                q=dot(basis,normal);qv=(spin-omega)*dot(up_cross(basis),normal)
                qa=-(spin-omega)**2*q if basis[2]==0 else F(0)
                sign=1 if q>0 else -1 if q<0 else 0
                abs_v=sign*qv if q else abs(qv)
                abs_a=sign*qa if q else F(0)
                half+=F(size)*abs(q)/2
                hv+=(sv*abs(q)+F(size)*abs_v)/2
                ha+=(sa*abs(q)+2*sv*abs_v+F(size)*abs_a)/2
        sign=1 if d>=0 else -1
        rows.append((tuple(sign*x for x in normal),half-abs(d),hv-sign*dv,ha-sign*da))
    return rows


def impact_normals(first,second,time,*,distance_epsilon,speed_epsilon,acceleration_epsilon):
    rows=margins(first,second,time)
    if any(g < -distance_epsilon for _,g,_,_ in rows):return ()
    normals=tuple(sorted({n for n,g,v,a in rows if abs(g)<=distance_epsilon and
        (v>speed_epsilon or abs(v)<=speed_epsilon and a>acceleration_epsilon)}))
    if any(n[2] for n in normals) and departing_footprint(rows,distance_epsilon=distance_epsilon,
            speed_epsilon=speed_epsilon,acceleration_epsilon=acceleration_epsilon):return ()
    return normals


def departing_footprint(rows,*,distance_epsilon,speed_epsilon,acceleration_epsilon):
    """Same outgoing edge rule as fixed-frame support/contact revalidation."""
    return tuple(row for row in rows if not row[0][2] and row[1]<=distance_epsilon and
        (row[2]<-speed_epsilon or abs(row[2])<=speed_epsilon and row[3]<-acceleration_epsilon))


def footprint(box):
    x,y,z=box.centre_m;r,f,_=axes(box);w,d=F(box.size_m[0])/2,F(box.size_m[1])/2
    return [(F(x)+sx*w*r[0]+sy*d*f[0],F(y)+sx*w*r[1]+sy*d*f[1])
            for sx,sy in ((-1,-1),(1,-1),(1,1),(-1,1))]


def witness(first,second):
    """Centroid of the actual projected contact polygon and vertical overlap."""
    polygon=footprint(first);clip=footprint(second)
    cross=lambda x,y:x[0]*y[1]-x[1]*y[0]
    sub=lambda x,y:(x[0]-y[0],x[1]-y[1])
    for start,end in zip(clip,clip[1:]+clip[:1]):
        if not polygon:break
        edge=sub(end,start);output=[]
        for a,b in zip(polygon,polygon[1:]+polygon[:1]):
            da,db=cross(edge,sub(a,start)),cross(edge,sub(b,start))
            if da>=0:output.append(a)
            if (da<0)!=(db<0):
                t=da/(da-db);output.append(tuple(x+t*(y-x) for x,y in zip(a,b)))
        polygon=output
    if polygon:xy=tuple(sum(p[i] for p in polygon)/len(polygon) for i in range(2))
    else:
        # A rounded event may be just outside the contact band. This fallback
        # is only a witness after the SAT/closing classifier accepts that band.
        xy=tuple((F(x)+F(y))/2 for x,y in zip(first.centre_m[:2],second.centre_m[:2]))
    z=(max(F(first.bounds[0][2]),F(second.bounds[0][2]))+min(F(first.bounds[1][2]),F(second.bounds[1][2])))/2
    return (*xy,z)


def point_velocity(path,time,point):
    if not isinstance(path,RotatingBoxPath):return ZERO
    box,v,_,rate,_,omega=state(path,time)
    offset=tuple(x-y for x,y in zip(vector3(point),box.centre_m))
    local=box.frame.to_local_vector(offset)
    deform=box.frame.to_world_vector(tuple(p*r/s for p,r,s in zip(local,rate,box.size_m)))
    return tuple(x+omega*j+d for x,j,d in zip(v,up_cross(offset),deform))
