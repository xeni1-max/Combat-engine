"""Small, source-traceable combat simulation slices."""

__version__ = "0.1.0"
