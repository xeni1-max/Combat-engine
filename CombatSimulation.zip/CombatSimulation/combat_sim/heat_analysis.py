"""Isolated heat-curve analysis; this does not extend encounter execution.

General k>=2 uses exact symbolic factors and fixed-context Decimal display.
Shield residual is an undecided design option, not an implemented shield rule.
"""
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from fractions import Fraction

from combat_sim.models import as_fraction, fraction_record

DISPLAY_CONTEXT = Context(prec=50, rounding=ROUND_HALF_EVEN)
SOURCE = 'Damage types.odt, Heat p49-p53; author confirms elapsed exposure, frozen exposure during residual, continuous accumulation'


def _decimal(value):
    return Decimal(value.numerator) / Decimal(value.denominator)


def _root_record(coefficient, duration, k):
    with localcontext(DISPLAY_CONTEXT):
        value = _decimal(coefficient) * (_decimal(duration) ** (Decimal(1) / _decimal(k))) if coefficient and duration else Decimal(0)
    return {'exact_expression': f'({coefficient})*({duration})^(1/({k}))',
            'coefficient': str(coefficient), 'radicand': str(duration), 'root_order': str(k),
            'decimal_approx': str(value), 'decimal_precision_digits': 50}


def analyze_heat_curve(heat_output, armor, heat_resistance, exposure_seconds, k=2):
    """Compare a complete uninterrupted exposure and its full candidate tail.

    Defenses/output stay constant; no shield depletion, clock reset, overlapping
    exposure histories, regeneration or HP caps are simulated. Setting a=Rh=0
    gives potential damage against a shield that remains available throughout.
    The residual-on-shield option remains unconfirmed by the author.
    """
    output, armor, resistance, duration, order = map(as_fraction, (heat_output, armor, heat_resistance, exposure_seconds, k))
    if output <= 0 or min(armor, resistance, duration) < 0 or order < 2:
        raise ValueError('Require output>0, defenses/exposure>=0, k>=2')
    coefficient = max(Fraction(0), (output**2 - (armor**2 + resistance**2) / 2) / output)
    growing_factor = coefficient * duration * order / (order + 1)
    residual_factor = coefficient * duration / (order + 1)
    ratios = None
    if coefficient and duration:
        ratios = {'residual_over_exposure': fraction_record(1 / order),
                  'residual_over_total': fraction_record(1 / (order + 1)),
                  'exposure_over_total': fraction_record(order / (order + 1))}
    return {
        'inputs': {'heat_output': str(output), 'armor': str(armor), 'heat_resistance': str(resistance),
                   'exposure_seconds': str(duration), 'k': str(order)},
        'source': SOURCE, 'coefficient': fraction_record(coefficient),
        'exposure_damage': _root_record(growing_factor, duration, order),
        'residual_damage': _root_record(residual_factor, duration, order),
        'total_with_residual': _root_record(coefficient * duration, duration, order),
        'peak_dps': _root_record(coefficient, duration, order),
        'residual_duration_seconds': fraction_record(duration / order),
        'damage_ratios': ratios,
        'scope': 'Isolated full curve with constant defenses; residual-on-shield is a candidate only; no encounter or depletion execution',
    }
