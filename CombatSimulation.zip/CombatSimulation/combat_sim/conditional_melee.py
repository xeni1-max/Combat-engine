"""Pinned source branches, normal cycles and independent counter cooldowns."""
from decimal import Decimal as D

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.recovery import hand_recovery
from combat_sim.mechanics.dyspnea import validate_action_dyspnea_rule
from combat_sim.models import UnsupportedMechanicError
from combat_sim.spatial_motion import CONTACT_SPEED_EPS_MPS as SPEED


class ConditionalMelee:
    def __init__(self,world):self.world=world

    @staticmethod
    def clock_key(ability,component):return 'component:'+ability+':'+component

    def validate(self,actor,ability):
        w=self.world;a=actor.profile['abilities'][ability];parts=a.get('melee_components',{})
        cfg=w.ownership_definition['actions'].get('conditional_melee') if w.ownership_definition else None
        if not (w.cooldown_system.enabled and w.spatial_transitions.enabled and w.airborne_enabled and
                w.attack_modifiers.enabled and cfg=={'occupies':['hands','weapon'],'requires':['upper_body','attack']}):
            raise UnsupportedMechanicError('Conditional melee needs the shared owned contact, force, cooldown and gravity world')
        cycle=a.get('normal_cycle');counter=a.get('counter_component')
        if (cycle!=['b','c'] or counter!='a' or set(parts)!={'a','b','c'} or a.get('initial_component')!='b' or
                a.get('condition')!='incoming_dash_or_knock' or a.get('cooldown_fallback')!='normal_cycle'):
            raise UnsupportedMechanicError('Unsupported conditional melee cycle/condition')
        for identity,part in parts.items():
            value=w.melee.definition(actor,ability,identity);g=value['melee_geometry']
            if (value.get('direct_damage_type')!='blunt' or value['self_effects'].get('application_timing')!='impact' or
                    g.get('mode')!='hand_capsule_at_impact' or g.get('aim')!='torso_location_at_active_start' or
                    g.get('blocking')!='body_solids' or g.get('origin_hand') not in ('left','right') or
                    any(set(value['hand_positions_m'][phase])!={g['origin_hand']} for phase in ('start','end'))):
                raise UnsupportedMechanicError('Conditional branches need pinned blunt hand contacts')
            validate_action_dyspnea_rule(value['dyspnea'])
            timing=actor.profile['timing_profiles'][value['timing_profile']]
            if (value['dyspnea'].get('payment_timing')!='active_start' or timing.get('impact_timing')!='middle_of_active' or
                    dec(timing['gathering_ms'])<0 or dec(timing['active_ms'])<=0 or dec(value['pre_mitigation_damage'])<=0):
                raise ValueError('Conditional branch timing, payment and damage must be positive')
            for phase in ('start','end'):hand_recovery(actor.hands,value['hand_positions_m'][phase],actor.profile['recovery_value'])
            for effects in ('self_effects','target_effects'):
                if any(dec(value[effects][k])<0 for k in ('disorientation','instability')):raise ValueError('Negative branch status')
            if identity==counter:
                if part.get('cooldown_anchor')!='active_end' or dec(part.get('cooldown_ms',0))<=0:
                    raise ValueError('Counter needs its own after-Active cooldown')
                w.knock_motion.validate_knock(value['knock'])
            elif part.get('next')!=cycle[(cycle.index(identity)+1)%len(cycle)]:
                raise ValueError('Normal branches must retain their alternating cycle')

    def attach(self,actor,ability):
        component=actor.profile['abilities'][ability]['counter_component']
        self.world.cooldown_system.register_background(actor,self.clock_key(ability,component))

    def assessment(self,actor,target):
        w=self.world;other=w.fighters[target];group=w.grapple_links.group(target)
        causes=[]
        for n in group:
            flight=w.motion[n]['jump']
            if flight is not None and (flight.get('motion_cause') or ())[:1]==('dash',):causes.append('dash')
            if any(a.kind=='charge_grab' and a.phase=='active' for a in w.fighters[n].live_actions()):causes.append('charge')
            if w.knock_motion.members(n):causes.append('knock')
        v=w.mobile_motion(target)[0];own=w.mobile_motion(actor.id)[0]
        delta=tuple(dec(x)-dec(y) for x,y in zip(actor.body_origin_m,other.body_origin_m))
        length=sum(x*x for x in delta).sqrt()
        closing=sum((x-y)*d for x,y,d in zip(v,own,delta))/length if length else D(0)
        return {'target':target,'target_life_generation':other.life_generation,'causes':sorted(set(causes)),
            'closing_speed_mps':closing,'eligible':bool(causes) and closing>SPEED}

    def select(self,actor,ability,target):
        w=self.world;a=actor.profile['abilities'][ability];state=w.melee.components.get((actor.id,ability))
        normal=state['next_component'] if state is not None else a['initial_component']
        if target is None:return normal
        counter=a['counter_component'];key=self.clock_key(ability,counter)
        value=w.melee.definition(actor,ability,counter)
        return counter if (self.assessment(actor,target)['eligible'] and
            w.cooldown_system.background_ready_at(actor,key)<=w.time and
            w.weapon_requirements_available(actor,ability,False,component=counter) and
            w.resource_ready_time(actor,value['dyspnea'])<=w.time) else normal

    def started(self,actor,action):
        a=self.world.action_definition(actor,action)
        if a.get('cooldown_anchor')=='active_end':
            self.world.cooldown_system.defer_start(actor,self.clock_key(action.ability_id,action.component_id),
                a['cooldown_ms'],action.id,action.active_end_ms,action.life_generation)

    def selected(self,actor,action):
        a=self.world.action_definition(actor,action)
        self.world.log('conditional_component_selected',actor=actor.id,ability=action.ability_id,
            action_id=action.id,component_id=action.component_id,assessment=self.assessment(actor,action.target),
            base_dyspnea=a['dyspnea']['base_value'],dyspnea_at_request=actor.dyspnea,
            counter_ready_at_ms=self.world.cooldown_system.background_ready_at(actor,
                self.clock_key(action.ability_id,actor.profile['abilities'][action.ability_id]['counter_component'])))
