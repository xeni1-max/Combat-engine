"""Physical hook contact followed by owned, paid self-launch and a finite rope.

One action owns its continuation; a released carrier remains a separate entity.
Native body physics owns all travel and the already incurred arrival effects.
"""
from copy import deepcopy

from combat_sim.action_ownership import ActionConflict,ActionRequirements
from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.body_launch import directed_launch
from combat_sim.mechanics.dyspnea import validate_action_dyspnea_rule
from combat_sim.models import UnsupportedMechanicError
from combat_sim.projectile_entities import ProjectileContactPolicy
from combat_sim.world_colliders import finite

EVENTS=frozenset(('hook_contact','hook_control_deadline'))


class GrapplingGun:
    def __init__(self,world):
        self.world=world;self.rows={};self.pending={}

    def validate(self,actor,ability_id):
        w=self.world;a=actor.profile['abilities'][ability_id];cfg=a.get('hook',{})
        if not (w.gravity_mode and w.airborne_enabled and w.life_cycles.enabled and
                w.effort_system.enabled and w.distance_constraints.enabled and
                w.contact_signals.enabled and w.hand_reach.enabled and actor.action_registry is not None):
            raise UnsupportedMechanicError('Grappling gun requires living owned gravity, terrain anchors and body contacts')
        if (not isinstance(cfg,dict) or set(cfg)!={'maximum_m','launch_speed_multiplier','launch_dyspnea','launch_self_effects','arrival_self_effects'} or
                finite(a['pre_mitigation_damage'],'Hook damage')!=0 or a['damage_type']!='contact'):
            raise ValueError('Hook requires damage-free contact and explicit launch/rope parameters')
        for key in ('maximum_m','launch_speed_multiplier'):finite(cfg[key],key,positive=True)
        validate_action_dyspnea_rule(a['dyspnea'])
        validate_action_dyspnea_rule(cfg['launch_dyspnea'])
        if cfg['launch_dyspnea']['payment_timing']!='active_start':raise ValueError('Hook launch pays at its Active start')
        for key in ('launch_self_effects','arrival_self_effects'):
            if set(cfg[key])!={'disorientation','instability'}:raise ValueError('Hook phase needs explicit self statuses')
            for value in cfg[key].values():finite(value,'Hook self status')
        if a.get('flight_limit')!={'kind':'live_source_distance','maximum_m':cfg['maximum_m']}:
            raise UnsupportedMechanicError('Hook range must follow its actual living source')
        if ProjectileContactPolicy.from_definition(a['projectile_geometry'].get('contact_policy'))!=ProjectileContactPolicy():
            raise UnsupportedMechanicError('Hook must stop at first physical contact')
        if dec(actor.profile['timing_profiles'][a['timing_profile']].get('projectile_acceleration_mps2',0))!=0:
            raise UnsupportedMechanicError('Hook range currently requires an undecelerated gravity carrier')
        for phase in ('recovery','hook_flight','hook_launch'):self.requirements(actor,ability_id,phase)

    def requirements(self,actor,ability_id,phase,*,action_id=None):
        a=actor.profile['abilities'][ability_id]
        frozen=self.rows.get(action_id)
        key='hook_wait' if phase=='hook_flight' else 'hook_launch' if phase=='hook_launch' else 'hook_projectile'
        cfg=self.world.ownership_definition['actions'].get(key)
        expected={'occupies':['hands','weapon']+(['locomotion'] if key=='hook_launch' else []),
            'requires':['upper_body']+(['attack'] if key=='hook_projectile' else [])}
        if cfg!=expected:raise UnsupportedMechanicError('Hook phases need explicit hand, weapon and launch ownership')
        hands=a['hand_positions_m']['start'] if frozen is None else frozen['hand_names']
        occupies={'hand:'+hand for hand in hands}|{'weapon:'+ability_id}
        if key=='hook_launch':occupies.add('locomotion')
        hook=a['hook'] if frozen is None else frozen['definition']
        rule=hook['launch_dyspnea'] if key=='hook_launch' else a['dyspnea'] if key=='hook_projectile' else None
        return ActionRequirements(frozenset(occupies),frozenset(cfg['requires']),
            None if rule is None else dec(rule['base_value']),None if rule is None else rule['payment_timing'])

    def release(self,actor,action,ability):
        w=self.world
        actor.action_registry.transfer({action.id:self.requirements(actor,action.ability_id,'hook_flight')})
        action.phase='hook_flight';action.active_end_ms=None;action.revision+=1
        w.cooldown_system.start(actor,action.ability_id,dec(ability['weapon_cooldown_ms']),action.id)
        actor.metrics['projectiles_released']+=1
        timing=dict(actor.profile['timing_profiles'][ability['timing_profile']],gathering_ms=0,active_ms=0)
        w.release_body_projectile(actor,action,ability,timing)
        flight=next(f for f in w.projectile_flights.values() if f['action_id']==action.id)
        self.rows[action.id]={'id':action.id,'actor':actor.id,'ability':action.ability_id,
            'life_generation':actor.life_generation,'projectile_id':flight['id'],'released_at_ms':w.time,
            'definition':deepcopy(ability['hook']),'hand_names':tuple(ability['hand_positions_m']['start']),
            'status':'hook_flight'}
        w.log('grappling_hook_waiting',hook_id=action.id,actor=actor.id,projectile_id=flight['id'])
        w.request_decision(actor.id,w.time)

    def queue(self,packet):
        row=self.rows.get(packet['action_id'])
        if row is None or row['status']!='hook_flight':return
        identity=packet['projectile_id']
        if identity in self.pending:return
        self.pending[identity]={'hook_id':row['id'],'packet':deepcopy(packet),'status':'queued'}
        self.world.push(self.world.time,'hook_contact',{'projectile_id':identity},priority=3)

    def live(self,kind,payload):
        if kind=='hook_contact':return self.pending.get(payload['projectile_id'],{}).get('status')=='queued'
        return self.rows.get(payload['hook_id'],{}).get('status')=='hook_launch'

    def process(self,kind,payload):
        if not self.live(kind,payload):return
        if kind=='hook_control_deadline':
            return self.end(self.rows[payload['hook_id']],'nominal_arrival_deadline')
        pending=self.pending[payload['projectile_id']];pending['status']='resolved'
        row=self.rows[pending['hook_id']];w=self.world;a=w.fighters[row['actor']]
        action=a.action_by_id(row['id']);packet=pending['packet']
        if row['status']!='hook_flight' or action is None or a.hp<=0 or a.life_generation!=row['life_generation']:return
        anchor=w.terrain_anchors.from_projectile_contact(packet)
        if anchor is None:return self.end(row,'hook_requires_solid_surface')
        cfg=row['definition'];reference=w.distance_constraints.reference(a.id)
        if sum((x-y)**2 for x,y in zip(reference,anchor.position_m))>dec(cfg['maximum_m'])**2:
            return self.end(row,'anchor_out_of_rope_range')
        speed=dec(w.movement_definition['characters'][a.profile_id]['running_speed_mps'])*dec(cfg['launch_speed_multiplier'])
        try:launch=directed_launch(reference,anchor.position_m,speed,w.jump_gravity,precision=w.precision)
        except UnsupportedMechanicError:return self.end(row,'launch_point_unreachable')
        try:a.action_registry.transfer({action.id:self.requirements(a,action.ability_id,'hook_launch',action_id=action.id)})
        except ActionConflict:return self.end(row,'launch_requirements_unavailable')
        action.phase='hook_launch'
        with a.using_action(action):
            if not w.pay_team_dyspnea(a,'active_start',rule=cfg['launch_dyspnea']):return
        deadline=w.time+launch.flight_time_ms
        distance=w.distance_constraints.attach_fixed(a.id,anchor,maximum_m=cfg['maximum_m'],
            expires_at_ms=deadline,source='grappling-hook:'+str(action.id),expected_life=a.life_generation)
        m=w.motion[a.id]
        if w.mobile_sprint_effort(a.id):
            m.update(mode='running',speed=dec(w.movement_definition['characters'][a.profile_id]['running_speed_mps']),sprint_anchor=None)
        drive=tuple(v*m['speed'] for v in m['direction'])+(dec(0),)
        if m.get('jump') is not None:drive=m['jump'].get('ground_drive_velocity',drive)
        m.pop('imposed_velocity',None)
        factor=dec(w.combat_locomotion_definition['running_self_effect_multiplier']) if w.mobile_is_running(a.id) else dec(1)
        effects={k:dec(v)*factor for k,v in cfg['launch_self_effects'].items()}
        for key,value in effects.items():setattr(a,key,getattr(a,key)+value)
        owed=(a.life_generation,action.ability_id,action.id,
            dec(cfg['arrival_self_effects']['disorientation']),dec(cfg['arrival_self_effects']['instability']))
        w.launch_body(a,launch.velocity_mps,ground_drive_velocity=drive,contact_effects=owed,
            allow_nonupward=True,motion_cause=('grappling_hook',a.life_generation,action.id))
        w.extend_parallel_gatherings(a,effects['disorientation'],action.id)
        action.active_end_ms=deadline
        observer='grappling-hook:'+str(action.id)
        row.update(status='hook_launch',launched_at_ms=w.time,anchor_id=w.distance_constraints.rows[distance]['anchor_id'],
            distance_id=distance,launch_velocity_mps=launch.velocity_mps,nominal_arrival_ms=deadline,
            launch_self_effects=effects,observer_id=observer)
        w.contact_signals.watch(observer,a.id,a.life_generation,self.arrival,action_id=action.id,phases=('hook_launch',))
        w.distance_constraints.watch_end(distance,self.distance_ended)
        w.push(deadline,'hook_control_deadline',{'hook_id':row['id']},priority=3)
        w.refresh_mobile_locomotion()
        w.log('grappling_hook_launched',**deepcopy(row))

    def arrival(self,delivery):
        row=self.rows.get(delivery.observer.action_id)
        if row is None or 'arrival_contact_wave' in row:return
        row['arrival_contact_wave']=delivery.wave.identity
        self.world.log('grappling_hook_arrival_contact',hook_id=row['id'],actor=row['actor'],wave_id=delivery.wave.identity)
        if row['status']=='hook_launch':self.end(row,'body_contact')

    def end(self,row,reason,*,release_owner=True):
        if row['status']=='ended':return
        w=self.world;a=w.fighters[row['actor']]
        row.update(status='ended',ended_at_ms=w.time,end_reason=reason)
        if row.get('distance_id'):w.distance_constraints.release(row['distance_id'],reason=reason)
        if row.get('observer_id'):w.contact_signals.unwatch(row['observer_id'],reason=reason)
        action=a.action_by_id(row['id'])
        if release_owner and action is not None:
            with a.using_action(action):a.current=None
            action.revision+=1
            w.request_decision(a.id,w.time)
        w.log('grappling_hook_ended',hook_id=row['id'],actor=row['actor'],reason=reason)

    def action_cancelled(self,actor,action,reason):
        row=self.rows.get(action.id)
        if row is not None:self.end(row,reason,release_owner=False)

    def distance_ended(self,identity,reason):
        for row in self.rows.values():
            if row.get('distance_id')!=identity or row['status']!='hook_launch':continue
            w=self.world;actor=w.fighters[row['actor']];action=actor.action_by_id(row['id'])
            if w.time>=row['nominal_arrival_ms']:self.end(row,'nominal_arrival_deadline')
            elif action is not None:w.cancel_owned_action(actor,action,'hook_'+reason)
            else:self.end(row,'hook_'+reason,release_owner=False)

    def settle(self):
        w=self.world
        for row in self.rows.values():
            if row['status']=='ended':continue
            actor=w.fighters[row['actor']];action=actor.action_by_id(row['id'])
            if actor.hp<=0 or actor.life_generation!=row['life_generation'] or action is None:
                self.end(row,'owner_life_or_control_ended',release_owner=False);continue
            if row['status']=='hook_launch':
                distance=w.distance_constraints.rows[row['distance_id']]
                if distance['status']!='active':
                    if w.time>=row['nominal_arrival_ms']:
                        self.end(row,'nominal_arrival_deadline')
                    else:w.cancel_owned_action(actor,action,'hook_'+distance['end_reason'])
            elif not any(p['hook_id']==row['id'] and p['status']=='queued' for p in self.pending.values()):
                flights=[f for f in w.projectile_flights.values() if f['action_id']==row['id']]
                if flights and all(f['status']!='in_flight' for f in flights):
                    self.end(row,'hook_flight_ended')

    def result(self):
        return {'grappling_hooks':deepcopy(list(self.rows.values()))} if self.rows else {}
