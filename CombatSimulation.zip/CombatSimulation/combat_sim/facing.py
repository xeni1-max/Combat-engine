"""Fixed actor facing adapters; ownership and angular motion live elsewhere."""
from combat_sim.orientation import YawFrame


def frame(value):
    if isinstance(value,YawFrame):return value
    if value=='+x':return YawFrame()
    if value=='-x':return YawFrame(-1,0)
    raise ValueError('Actor facing requires +x, -x or an immutable yaw frame')


def parse(value,*,precision):
    if value in ('+x','-x'):return value
    if not isinstance(value,dict) or set(value)!={'yaw_degrees'}:
        raise ValueError('Actor facing needs +x, -x or exactly yaw_degrees')
    return YawFrame.from_degrees(value['yaw_degrees'],precision=precision)


def record(value):
    return {'yaw_frame':value.record()} if isinstance(value,YawFrame) else value


def forward(value):return frame(value).forward
