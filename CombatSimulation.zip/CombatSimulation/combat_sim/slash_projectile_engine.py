"""Controlled single/repeated gunfire, independent bleeds, shields and empty reloads."""
from fractions import Fraction
import heapq
from typing import Any

from combat_sim.actions import ScriptedActionSequence, RepeatFirePolicy
from combat_sim.encounters import initial_states
from combat_sim.events import EventLog
from combat_sim.mechanics import projectile_damage, slash
from combat_sim.mechanics.timing import impact_time_from_activation, self_effect_time_from_activation
from combat_sim.models import UnsupportedMechanicError, WeaponState, as_fraction, fraction_record
from combat_sim.state_updates import _advance_regeneration, _state_snapshot, _validate_shield_state
from combat_sim.status_events import _advance_statuses, _apply_effects

# Engineering budget, not a game rule: stay below Python's integer-to-text limit.
MAX_EXACT_RESULT_BITS = 12000


def _ms(value, label):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f'{label} must be a nonnegative integer millisecond')
    return value


def _changes(target, before, state):
    return {'target': target, **{key: fraction_record(value) for key, value in {
        'hp_before': before[0], 'hp_after_impact': state.hp, 'armor_before': before[1],
        'armor_after_impact': state.armor, 'shield_before': before[2], 'shield_after_impact': state.shield}.items()}}


def _remaining_bleed(bleeds, time):
    return sum((slash.bleeding_damage_between(b['y'], Fraction(time-b['start'],1000), slash.BLEED_DURATION_SECONDS)
                for b in bleeds), Fraction(0))


def _advance_bleeds(state, target, bleeds, start, end, log):
    if end <= start or not bleeds:
        return
    instances=[]
    for bleed in bleeds:
        begin=max(start,bleed['start']); finish=min(end,bleed['end'])
        if finish <= begin:
            continue
        amount=slash.bleeding_damage_between(bleed['y'], Fraction(begin-bleed['start'],1000), Fraction(finish-bleed['start'],1000))
        instances.append({'bleed_id':bleed['id'], 'source_shot':bleed['id'], 'amount':fraction_record(amount),
                          'y':str(bleed['y']), 'tb_start_seconds':str(Fraction(begin-bleed['start'],1000)),
                          'tb_end_seconds':str(Fraction(finish-bleed['start'],1000))})
    if not instances:
        return
    damage=sum((Fraction(b['amount']['exact']) for b in instances),Fraction(0))
    if state.hp <= damage:
        raise UnsupportedMechanicError('This scope requires a nonlethal target; death inside bleeding is not specified')
    before=state.hp,state.armor,state.shield
    state.hp-=damage
    log.record({'time_ms':end,'type':'continuous_damage_resolved','target':target,
                'interval_start_ms':start,'interval_end_ms':end,
                'damage_payment':'Exact continuous analytic integral; interval accounting is not a damage tick',
                'nominal_hp_damage':fraction_record(damage),'applied_hp_damage':fraction_record(damage),
                'components':{'bleeding':{'amount':fraction_record(damage),'instances':instances,
                    'delivery':'Existing independent bleeds damage HP directly, even while shielded',
                    'integral':'Sum of y*(8*(end-start)-(end^2-start^2)/2)/320 per bleed, clipped at eight seconds',
                    'source':slash.BLEED_SOURCE}},'state_changes':_changes(target,before,state)})


def _resolve_hit(actor,target,ability_id,ability,shot,states,profiles,pending,bleeds,time,log):
    state=states[target]; before=state.hp,state.armor,state.shield
    calculation=slash.calculate_impact(shot['incoming'],state.armor,ability['piercing'],state.shield)
    values=(calculation.pre_hit_armor,calculation.hp_damage,calculation.armor_loss)
    if any(max(v.numerator.bit_length(),v.denominator.bit_length())>MAX_EXACT_RESULT_BITS for v in values):
        raise UnsupportedMechanicError('Exact rational armor growth exceeds this stage arithmetic budget; no armor or damage rounding is substituted')
    full_bleed=slash.bleeding_damage_between(calculation.hp_damage,0,slash.BLEED_DURATION_SECONDS)
    if state.hp <= calculation.hp_damage+full_bleed+_remaining_bleed(bleeds,time):
        raise UnsupportedMechanicError('This scope requires a nonlethal target including all committed bleeding')
    state.shield=calculation.shield_after
    state.hp-=calculation.hp_damage
    state.armor=max(Fraction(0),state.armor-calculation.armor_loss)
    armor_lost=before[1]-state.armor
    log.record({'time_ms':time,'type':'impact_resolved','actor':actor,'target':target,'ability':ability_id,
        'shot_index':shot['id'],'origin':'slash_projectile','hit_confirmation':'supplied_by_scenario','timing_calculation':shot['timing'],
        'range_calculation':{'base_damage':fraction_record(as_fraction(ability['pre_mitigation_damage'])),
            'distance_m':str(shot['distance']),'damage_loss':fraction_record(as_fraction(ability['pre_mitigation_damage'])-shot['incoming']),
            'formula':projectile_damage.FORMULA,'inputs':dict(ability['range_falloff']),'source':projectile_damage.SOURCE},
        'damage_calculation':{'damage_type':'slash','damage_category':'extrinsic','incoming_damage':fraction_record(shot['incoming']),
            'shield_handling':{'shield_damage_is_unmitigated':True,'shield_before':fraction_record(before[2]),
                'damage_to_shield':fraction_record(calculation.shield_damage),'shield_after_impact':fraction_record(state.shield),
                'damage_left_after_shield':fraction_record(calculation.damage_left_after_shield)},
            'formula_evaluation':'evaluated_on_damage_left_after_shield' if calculation.damage_left_after_shield else 'skipped_fully_absorbed_by_shield',
            'formulas':{'post_mitigation_damage':slash.FORMULA,'armor_reduction':slash.ARMOR_REDUCTION_FORMULA},
            'formula_inputs':{'d_left_after_shield':str(calculation.damage_left_after_shield),'a_pre_impact':str(calculation.pre_hit_armor),'p':str(ability['piercing'])},
            'outputs':{'y':fraction_record(calculation.hp_damage),'Ar':fraction_record(calculation.armor_loss)},
            'raw_formula_outputs_before_zero_clamp':{'y':fraction_record(calculation.raw_hp_damage),'Ar':fraction_record(calculation.raw_armor_loss)},
            'applied_state_losses':{'hp':fraction_record(calculation.hp_damage),'armor':fraction_record(armor_lost)},
            'excess_formula_outputs':{'hp':fraction_record(Fraction(0)),'armor':fraction_record(calculation.armor_loss-armor_lost)},
            'state_mapping':'Range falloff, raw shield absorption, overflow slash HP, then armor loss; pre-hit target status armor',
            'state_mapping_status':'confirmed_by_user'},'state_changes':_changes(target,before,state),
        'sources':{'ability':ability['source'],'damage_rule':slash.SOURCE,'armor_rule':slash.ARMOR_SOURCE}})
    _apply_effects(target,state,profiles[target],ability['target_effects'],time,'projectile_target',log,armor_snapshot=calculation.pre_hit_armor)
    if calculation.shield_damage:
        regen=profiles[target].get('shield_regeneration')
        if not regen or as_fraction(regen['rate_per_second'])<=0:
            raise UnsupportedMechanicError('Shield losses require documented positive regeneration data')
        pending.append({'loss_instance':shot['id'],'target':target,'loss_at_ms':time,
                        'eligible_at_ms':time+_ms(regen['delay_ms'],'Regeneration delay'),
                        'remaining':calculation.shield_damage,'rate_per_second':as_fraction(regen['rate_per_second']),'source':regen['source']})
        log.record({'time_ms':time,'type':'shield_regeneration_scheduled','target':target,'loss_instance':shot['id'],
                    'amount_lost':fraction_record(calculation.shield_damage),'eligible_at_ms':pending[-1]['eligible_at_ms'],
                    'shared_rate_per_second':str(regen['rate_per_second']),'source':regen['source']})
    if calculation.hp_damage:
        bleed={'id':shot['id'],'y':calculation.hp_damage,'start':time,'end':time+8000}
        bleeds.append(bleed)
        log.record({'time_ms':time,'type':'bleeding_started','actor':actor,'ability':ability_id,'target':target,
                    'bleed_id':bleed['id'],'bleed_basis_y':fraction_record(bleed['y']),'ends_at_ms':bleed['end'],'source':slash.BLEED_SOURCE})
        return bleed
    log.record({'time_ms':time,'type':'bleeding_not_created','target':target,'shot_index':shot['id'],
                'reason':'No post-shield/post-armor HP damage; shields cannot bleed'})
    return None


def run_slash_projectile_scenario(scenario:dict[str,Any],profiles:dict[str,Any])->dict[str,Any]:
    if set(scenario)-{'id','description','encounter','action_sequence','run_until_ms'}:
        raise UnsupportedMechanicError('Unsupported slash-projectile scenario fields')
    encounter=scenario.get('encounter',{})
    if set(encounter)-{'initial_states','movement','weapon_initial_state'} or encounter.get('movement')!='stationary':
        raise UnsupportedMechanicError('Controlled gunfire requires stationary movement and supported initial states')
    inputs=ScriptedActionSequence(scenario.get('action_sequence',[])).inputs()
    if len(inputs)!=1:
        raise UnsupportedMechanicError('Use one activation or one finite repeat_fire policy input')
    action=inputs[0]; repeated=action.get('kind')=='repeat_fire'
    fields={'kind','action_start_ms','actor','target','ability','hit_confirmed','target_distance_m'}
    if repeated: fields|={'shot_count','reload_when_empty'}
    if set(action)-fields or action.get('kind') not in ('activation','repeat_fire') or action.get('hit_confirmed') is not True:
        raise UnsupportedMechanicError('Gunfire requires supported action fields and scenario-confirmed hits')
    actor,target,ability_id=(action.get(k) for k in ('actor','target','ability'))
    states=initial_states(encounter,track_statuses=True)
    if actor==target or set(states)!={actor,target}:
        raise UnsupportedMechanicError('One distinct shooter and target are required')
    for name,state in states.items():
        profile=profiles.get(name,{})
        if any(key not in profile for key in ('max_hp','shield_capacity','status_resistance')):
            raise UnsupportedMechanicError(f'{name} requires complete defender data')
        if min(as_fraction(profile['max_hp']),as_fraction(profile['status_resistance']))<0:
            raise ValueError('Maximum HP and status resistance must be nonnegative')
        _validate_shield_state(state,as_fraction(profile['shield_capacity']),name)
    ability=profiles[actor]['abilities'][ability_id]
    if ability.get('damage_type')!='slash' or ability.get('damage_category')!='extrinsic' or ability.get('damage_payment')!='continuous_bleeding':
        raise UnsupportedMechanicError('This model requires extrinsic slash with continuous bleeding')
    if ability.get('target_status_armor_snapshot')!='before_hit_armor_loss' or ability['self_effects'].get('application_timing')!='middle_of_active':
        raise UnsupportedMechanicError('This model requires pre-hit target armor and midpoint self effects')
    cooldown=ability.get('weapon_cooldown_behavior',{})
    if cooldown.get('automatic') is not True or cooldown.get('blocks_other_actions') is not False or cooldown.get('anchor')!='active_firing_end':
        raise UnsupportedMechanicError('Automatic weapon cooldown must not block other actions')
    if (ability.get('bleed_delivery'),ability.get('bleed_overlap'),ability.get('existing_bleed_shield_interaction'))!=('post_shield_post_armor_hp_damage','independent_additive','continues_on_hp'):
        raise UnsupportedMechanicError('This model requires independent HP-delivered bleeds that continue on HP while shielded')
    falloff=ability['range_falloff']
    if falloff.get('mode')!='continuous': raise UnsupportedMechanicError('Continuous falloff is required')
    timing_profile=profiles[actor]['timing_profiles'][ability['timing_profile']]
    if timing_profile.get('impact_timing')!='projectile' or timing_profile.get('projectile_release_timing')!='after_active':
        raise UnsupportedMechanicError('Projectile release after Active is required')
    start=_ms(action.get('action_start_ms'),'action_start_ms')
    # Validate travel even for a policy that elects not to reload an empty gun.
    impact_time_from_activation(start,timing_profile,action.get('target_distance_m'))
    distance=as_fraction(action['target_distance_m'])
    incoming=projectile_damage.damage_after_distance(ability['pre_mitigation_damage'],distance,falloff['damage_loss'],falloff['distance_m'])
    weapon_input=encounter.get('weapon_initial_state',{})
    if set(weapon_input)-{'ammo'}: raise UnsupportedMechanicError('Initial weapon state supports ammo only; starts outside cooldown/reload')
    weapon=WeaponState(weapon_input.get('ammo',ability['magazine_capacity']),ability['magazine_capacity'])
    policy=RepeatFirePolicy(action.get('shot_count',1) if repeated else 1,reload_when_empty=action.get('reload_when_empty',True) if repeated else False)
    if not repeated and weapon.ammo==0: raise UnsupportedMechanicError('Empty weapon requires reload; use a repeat_fire policy')
    until=_ms(scenario['run_until_ms'],'run_until_ms') if 'run_until_ms' in scenario else None
    initial=_state_snapshot(states); initial_weapon=weapon.to_record(0)
    queue=[]; serial=0
    def schedule(time,priority,kind,payload=None):
        nonlocal serial
        serial+=1; heapq.heappush(queue,(time,priority,serial,kind,payload))
    schedule(start,10,'decision')
    log=EventLog(); pending=[]; bleeds=[]; current=0; released=0; reload_count=0; last_release=None
    def advance(end):
        nonlocal current
        _advance_regeneration(states,profiles,pending,current,end,log)
        _advance_bleeds(states[target],target,bleeds,current,end,log)
        _advance_statuses(states,current,end,log)
        current=end
    while queue:
        time,_,_,event,payload=heapq.heappop(queue)
        if until is not None and time>until:
            raise ValueError('run_until_ms must include weapon cooldown, reload and all eight seconds of bleeding')
        advance(time)
        common={'time_ms':time,'actor':actor,'ability':ability_id}
        if event=='decision':
            decision=policy.choose(released,weapon.ammo)
            log.record({**common,'type':'action_selected','decision':decision or 'stop','shots_released':released,'weapon_state':weapon.to_record(time),
                        'policy':'Finite repeat: fire when ready; reload when empty if requested' if repeated else 'Single explicit shot'})
            if decision=='fire':
                if time<weapon.cooldown_ready_at_ms or weapon.reload_phase!='none': raise ValueError('Policy attempted fire before weapon ready')
                impact,timing=impact_time_from_activation(time,timing_profile,distance,disorientation_at_gathering_start=states[actor].statuses.disorientation)
                self_time,self_timing=self_effect_time_from_activation(time,timing_profile,'middle_of_active',disorientation_at_gathering_start=states[actor].statuses.disorientation)
                shot={'id':released+1,'distance':distance,'incoming':incoming,'timing':timing,'self_timing':self_timing}
                log.record({**common,'type':'ability_started','shot_index':shot['id'],'timing_calculation':timing,'actor_state':states[actor].to_record(),
                            'weapon_state':weapon.to_record(time),'availability':'Weapon ammo/cooldown enforced; scenario confirms hit; costs and other-action eligibility excluded'})
                schedule(self_time,20,'self_effect',shot); schedule(timing['projectile_release_time_ms'],30,'release',shot); schedule(impact,40,'impact',shot)
            elif decision=='reload':
                rule=ability.get('reload_gathering_rule')
                if rule!='current_disorientation':
                    raise UnsupportedMechanicError('Reload Gathering must add current disorientation; no exception is confirmed')
                weapon.reload_phase='gathering'
                gathering=states[actor].statuses.disorientation
                reload_timing={'gathering_ms':_ms(ability['reload_gathering_ms'],'Reload base Gathering'),'active_ms':_ms(ability['reload_active_ms'],'Reload Active'),'impact_timing':'start_of_active'}
                active_at,timing=impact_time_from_activation(time,reload_timing,disorientation_at_gathering_start=gathering)
                reload_count+=1
                log.record({**common,'type':'reload_requested','reload_index':reload_count,'weapon_state':weapon.to_record(time),
                            'active_starts_at_ms':active_at,'active_ends_at_ms':timing['active_end_ms'],'gathering_rule':rule, 'timing_calculation':timing,
                            'source':'1E2.odt p235/p236; author permits overlap with weapon cooldown'})
                schedule(active_at,15,'reload_active_started',reload_count); schedule(timing['active_end_ms'],1,'reload_completed',reload_count)
        elif event=='self_effect':
            log.record({**common,'type':'self_effect_triggered','shot_index':payload['id'],'timing_calculation':payload['self_timing']})
            _apply_effects(actor,states[actor],profiles[actor],ability['self_effects'],time,'self',log)
        elif event=='release':
            weapon.ammo-=1; released+=1; last_release=time
            weapon.cooldown_ready_at_ms=time+_ms(ability['weapon_cooldown_ms'],'Weapon cooldown duration')
            log.record({**common,'type':'projectile_released','target':target,'shot_index':payload['id'],'actor_state':states[actor].to_record(),
                        'ammo_consumed':1,'weapon_state':weapon.to_record(time)})
            log.record({**common,'type':'weapon_cooldown_started','shot_index':payload['id'],'actor_state':states[actor].to_record(),
                        'duration_ms':ability['weapon_cooldown_ms'],'automatic':True,'blocks_other_actions':False,'weapon_ready':False,
                        'next_shot_ready_at_ms':weapon.cooldown_ready_at_ms,'weapon_state':weapon.to_record(time)})
            schedule(weapon.cooldown_ready_at_ms,0,'weapon_cooldown_completed',payload['id'])
            if released<policy.shot_count:
                # Empty reload may overlap cooldown; the next shot must satisfy both.
                next_decision=time if weapon.ammo==0 else weapon.cooldown_ready_at_ms
                schedule(next_decision,10,'decision')
        elif event=='weapon_cooldown_completed':
            log.record({**common,'type':event,'shot_index':payload,'actor_state':states[actor].to_record(),
                        'duration_ms':ability['weapon_cooldown_ms'],'automatic':True,'blocks_other_actions':False,
                        'weapon_ready':weapon.to_record(time)['can_fire_weapon'],'next_shot_ready_at_ms':weapon.cooldown_ready_at_ms,'weapon_state':weapon.to_record(time)})
        elif event=='reload_active_started':
            weapon.reload_phase='active'
            log.record({**common,'type':event,'reload_index':payload,'weapon_state':weapon.to_record(time),'active_ms':ability['reload_active_ms']})
        elif event=='reload_completed':
            before=weapon.ammo; weapon.ammo=weapon.capacity; weapon.reload_phase='none'
            log.record({**common,'type':event,'reload_index':payload,'ammo_before':before,'ammo_after':weapon.ammo,'weapon_state':weapon.to_record(time)})
            schedule(max(time,weapon.cooldown_ready_at_ms),10,'decision')
        elif event=='impact':
            bleed=_resolve_hit(actor,target,ability_id,ability,payload,states,profiles,pending,bleeds,time,log)
            if bleed: schedule(bleed['end'],2,'bleeding_expired',bleed['id'])
        elif event=='bleeding_expired':
            bleeds[:]=[b for b in bleeds if b['id']!=payload]
            log.record({**common,'type':event,'target':target,'bleed_id':payload})
    if until is not None: advance(until)
    events=sorted(log.records(),key=lambda e:Fraction(e['time_ms']) if isinstance(e['time_ms'],int) else Fraction(e['time_ms']['exact']))
    return {'scenario_id':scenario.get('id','unnamed'),'execution_model':'slash_projectile','initial_states':initial,
        'initial_weapon_state':initial_weapon,'final_weapon_state':weapon.to_record(current),
        'encounter_configuration':{'movement':'stationary'},'inputs':inputs,'events':events,'run_until_ms':current,'final_states':_state_snapshot(states),
        'weapon_cycle':{'actor':actor,'ability':ability_id,'initially_ready':initial_weapon['can_fire_weapon'],'cooldown_start_ms':last_release,
                        'ready_at_ms':weapon.cooldown_ready_at_ms,'final_phase':'ready' if weapon.to_record(current)['can_fire_weapon'] else 'empty',
                        'automatic':True,'blocks_other_actions':False},
        'shots_requested':policy.shot_count,'shots_released':released,'reload_count':reload_count,'active_continuous_effects_final':[],
        'pending_shield_regeneration':[{'target':p['target'],'loss_instance':p['loss_instance'],'loss_at_ms':p['loss_at_ms'],
            'eligible_at_ms':p['eligible_at_ms'],'remaining':fraction_record(p['remaining'])} for p in pending],
        'outcome':'Requested shots completed' if released==policy.shot_count else 'Policy stopped with an empty magazine',
        'assumptions_and_limits':[
            'One stationary shooter/target; single shot or finite repeat-fire policy. Supplied distance and hit confirmations replace aiming/dispersion; no other combatants, movement or autonomous decisions.',
            'Weapon starts outside cooldown/reload. Initial ammo is explicit or defaults to the documented full magazine. Ammo is consumed at projectile release; empty reload restores magazine capacity on Active completion.',
            'Automatic weapon cooldown starts at firing end, blocks no other actions and is independent of character statuses. Empty reload can overlap it; firing waits for both reload and cooldown. Reload Gathering follows the confirmed rule in ability data.',
            'Base shot Gathering is zero; current disorientation still adds Gathering. Self statuses apply at midpoint Active without mitigation. Firing is extrinsic, so intrinsic instability damage penalties do not apply.',
            'Range falloff uses supplied distance. Travel assumes constant along-path acceleration and rounds upward to integer milliseconds; unreachable paths are rejected.',
            'Shields absorb raw damage first; only overflow enters slash HP and armor equations. HP damage and target statuses use pre-hit armor; armor is reduced afterward. Fully shielded hits do not create bleeding or armor loss; incoming statuses still apply.',
            'Each HP-delivered bullet creates its own eight-second bleed. Independent rates add and existing bleeds continue on HP even after a shield regenerates. Exact analytic interval accounting is not a damage tick.',
            'Each shield loss retains its own delay and all eligible losses share the documented regeneration rate. Initial missing shield has no invented history; default completion does not wait for pending regeneration.',
            'Repeated cubic armor loss can grow exact fractions rapidly; results above the explicit 12000-bit arithmetic budget are rejected without substituting rounded rules.',
            'Only nonlethal returned runs are supported. General action switching, tactical reload, reload interruptions, incoming attacks, dyspnea/recoil-control costs, Recovery, death/revival and other ability scheduling remain outside scope.']}
