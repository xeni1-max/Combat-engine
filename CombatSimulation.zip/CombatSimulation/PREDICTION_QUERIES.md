# Shared prediction query work

2026-11-14. Delegated engineering optimization; no new combat rule, ability,
precision, contact tolerance or time quantum. Verification is recorded in
[the current verification](results/fence-roster/README.md).

The measured ordinary 30-second, ten-actor encounter combines the six existing
profiles, their current priorities, independent fields, physical projectiles
and scripted movement. Its first second initially required 162.102 seconds of
wall time. Profiling found repeated support/pose queries and construction of
field-root candidates for parts that cannot reach those fields. An interrupted
stack in pose refinement did not prove runaway rational growth: a later observer
measured pose calls below 0.1 seconds and coefficient sizes at most 559 bits in
its observed prefix. The late profile identifies field membership as the largest
remaining query cost. These are bounded workload observations, not universal
runtime or convergence guarantees.

Prediction retains the same immutable polynomial pieces and narrow geometry:

- Body-contact queries reuse each actor's motion and each part's derivatives
  within that one call. Gravity projectile queries reuse part kinematics across
  flights within that one call. The next call observes intervening actions,
  displacements, life changes and pose changes, even at the same clock.
- Balance retains at most one dynamic evaluation per actor, keyed by the exact
  requested clock and the identity of its immutable BalancePiece. Replacing a
  piece misses directly. Constant pieces return their validated constant value.
  No rounded progress, speculative pose or historical cache is introduced.
- Fixed-heading column and panel membership reject only proven unreachable
  parts/pairs before constructing candidate roots. This extends the existing
  spherical-volume rejection; timed turns retain the angular backend.

For lower/upper coordinate polynomials, exact endpoint and interior-extremum
bounds enclose every face over the whole requested interval. A column can
exclude a part only when the squared horizontal distance to that enclosure is
strictly greater than the squared radius. A fixed box pair can be excluded only
by strict interval separation; oriented pairs use their actual separating-axis
polynomials. An AABB never confirms a hit. Persistent closed tangency, interior
accelerating flybys and size bulges remain candidates. Shape-trajectory validation
still runs before rejection, including for distant invalid parts. Cover, open
exposure-cell classification, attribution, clocks and phase/life ownership keep
the existing contracts.

The full30s original mixed battle completes with independent HP/life/resource
checks. Its original inputs, whole result and interrupted earlier attempts are
preserved. Diagnostic prefixes remain incomplete evidence. The broad numerical,
CLI, position, policy and roster controls are running; a finished first case
alone does not establish the broader reproducibility criterion.

A bounded512-query sample from that actual battle has241 unique exact inputs.
Three cold-cache trials preserve every result and reduce pure-query calculation
time about39%. This is a sample measurement, not whole-engine throughput.
After92 prototype methods and112 exact complete-output comparisons, the memo
is promoted; query-cache-promotion.json binds its source. Columns, electrical
screens and gas share the per-world bounded
256-entry LRU. Complete immutable arguments and Decimal settings/traps form
keys; raised flags are preserved, returned lists detached and unsupported or
iterator inputs use the original query. Life/membership/pressure remain outside
that memo. All3389 methods pass1403.140s with497 matching tested-source hashes,
including the inherited optimizations, all-roster source repair and10 new memo
methods. Both unchanged review sets pass after promotion. All38 earlier complete
kit/policy controls and18 repair controls pass on the fixed current inputs.
No whole-engine speed improvement is claimed.
