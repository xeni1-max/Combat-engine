# Combat signals and 2E4's Block counterattack

Primary source: `2E4.odt` p5 gives one charge, gained every 9 seconds, consumed
by successful blocking to release a 500-damage attack 5 m forward hitting everyone
in line. Detailed p79/p80 gives target disorientation/instability 800/800. The
author explicitly exempts ability 2 from additional dyspnea because it works
with Block; Block keeps its cost. The source does not specify damage family,
line thickness/origin, cover or a separate preparation/release duration.

Verified in the shared engine, 2026-11-01. The following are delegated
technical choices, not additional author statements:

- Positive raw HP actually absorbed by released Block layers commits a typed,
  immutable signal. A miss, zero damage, passive regenerative shielding, area
  heat and armor resistance are not a successful Block trigger. Multiple
  packets/layers in one incoming target batch produce one signal per source life.
  Friendly fire can trigger the same physical defense; the counter itself hits
  friends and enemies in its line, excluding its emitter.
- Resolve the original complete incoming batch, point healing, deaths and body
  contacts before dispatching reactions. The holder must still be living in
  that shield source life. A lethal Block break does not spend the counter's
  charge or resurrect its owner. Old-life frozen surfaces cannot activate a
  restored actor's counter. Already released packets retain source/action/life
  identity and survive the emitter's later death.
- All signals at one reaction stage release their attacks before those attacks'
  next damage batch. A causal depth/source chain distinguishes these subsequent
  same-timestamp hits from the original simultaneous batch. Each new wave uses
  the defenses then present. This extends the author's simultaneous-hit rule to
  causally created attacks: independent arrivals in one wave share snapshots;
  a new attack caused by those arrivals belongs to the next wave. Including it
  retroactively would make shield allocation and its own trigger circular.
  Charges are consumed before emission, so the
  existing one-charge counters cannot loop indefinitely at one timestamp.
- The automatic reaction takes no new hands, weapon/body lock, Gathering,
  Recovery, Active timer, self-status or dyspnea payment. It is a delegated
  extrinsic momentary emission. A living deployed shield can trigger it after
  its Block control completes or is selectively cancelled. Body restrictions
  do not invent a new requirement for this automatic emission.
- Start with one charge, recharge 9000 ms of ordinary cooldown work after use,
  preserving pause sources and dead/resumed work through the shared charge pool.
  Full stock banks no work. Ready stock can fire within a pause field. A signal
  while empty is discarded rather than queued for a future refill. This is
  separate from Block's four-charge family and revival's finite three-stock gate.
- Use blunt damage with no piercing and the existing pre-hit armor/HP formulas.
  The source names no blade, slash, toxin, Qard or other family for this attack;
  blunt preserves a direct non-bleeding hit without inventing those properties.
- Delivery is an instantaneous sphere-swept line, 5 m centreline length and 2 cm
  radius, from the current torso centre along fixed body facing. This numerical
  proxy keeps 3D hitboxes and closed endpoint/corner geometry. Each receiver is
  hit once at full strength; one body's interception does not stop later bodies.
  Every recipient independently routes through its forward Block layers and
  regenerative shield. Source and creative values are kept in character data.
- The nearest projectile-blocking world solid stops the line, takes its normal
  direct construct damage and protects receivers behind it. A solid wins an
  exact boundary tie. Indestructible terrain also stops it. This does not change
  the author's separate Qard/beam area-through-cover rule. Frozen shields from
  an old life are independent receivers; a body-piercing line can also reach a
  restored body behind such a surface without transferring its overflow to it.

`AutomaticAbilities` routes existing definitions to independently enabled
controllers rather than treating every automatic entry as revival. The existing
revival policy and frozen no-reaction inputs retain their scope. Active selection
does not cast an automatic-only ability. `line_delivery.sweep_line` supplies
reusable receiver/solid geometry; `BlockSignal` supplies validated causal/source
identity; shared direct power/impact/HP history supplies actual damage and credit.

The subsequent [attack modifier increment](ATTACK_MODIFIERS.md) now routes
2E4's shielding bypass through these layers. Only actual Block absorption emits
a signal; ignored stock cannot fund a counter. The full six-character engine
remains unfinished. Next is 1E5's actual alternating melee delivery, followed
by linked movement and per-phase resource transfers for the remaining kits.

**Evidence:** 1544 tests pass in 219.117 s, including 42 new checks. Eleven ordinary
complete API/CLI captures verify actual counter hits, friendly fire, solid and
destroyed cover, simultaneous shared-target snapshots, mutual death and clipped
revival credit, causal healing, empty/paused/refilled stock and source lives.
Three complete hash controls and two higher-precision/observation/order controls
pass. Both review suites/matrix and prior frozen Block/healing/revival/melee/life/
effort packages replay unchanged. [Inputs, logs and commands](results/combat-reactions/README.md).
