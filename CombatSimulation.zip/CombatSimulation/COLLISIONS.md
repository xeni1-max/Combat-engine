# Body collision direction and response

Current implementation status: shared moving combat executes these responses,
including full 3D support/flight, changing posture and climb interruption. The
isolated checkpoint below is historical. See [ENGINE_STATUS.md](ENGINE_STATUS.md)
and [moving combat](MOVING_COMBAT.md) for current coverage and remaining guards.

**2026-11-13 finite-floor extension:** [actual sheet contacts](FINITE_GROUND.md)
replace the infinite body landing plane under `finite_faces_v2`. Partial
support, open-edge departure, underside and perimeter-edge contacts use the
shared body solver. Face impacts retain the vertical ground normal; a finite
edge's horizontal constraint applies only when a body straddles the sheet.
No walls, ground thickness, abyss death or collision HP damage are added.
Historical inputs retain their explicit guards.

**2026-11-01 linked extension:** [grapple groups](LINKED_MOTION.md) transmit
collision movement loss to every connected free input. Status penalties still
apply only to actual contacting bodies with their individual defenses. The
author's summed-stat rule concerns [knock distance resistance](KNOCKBACK.md);
it does not sum defenses for collision disorientation/instability.

Author clarification, 2026-10-25. The root `Collision details.odt` now states
the earlier combined centre-line wording. The subsequent explicit author
clarification below supersedes that wording for obstacles; original ODT files
were not edited by the simulator work.

## Confirmed rules

- **Character/character:** collision direction is the 3D line between their
  body centres (the approved body origins).
- **Character/obstacle:** collision direction passes through the character
  centre and is perpendicular to the **contacted surface**. Obstacle centre
  is not used. For a cube face this is that face's normal axis.
- Relative speed uses the difference between the two velocities projected onto
  that line. Static obstacles have zero velocity.
- Both characters receive **the full relative-speed status amount**, each
  before its own resistance. It is not divided between them.
- Each character independently loses its **own** velocity component along the
  collision line. Perpendicular components are retained by this operation.
- Ground collision direction is perpendicular to the ground through the body
  centre. For the current horizontal ground, it is the vertical line.
- Raw disorientation and instability are **300 per 5 m/s**, or 60 times the
  relative projected speed. Existing incoming-collision resistance applies to
  each character separately, with the existing zero floor. These are incoming
  collision effects, not an invented running-scaled self effect.

For unit direction n, character velocities vA and vB:

```
relative directional speed = |(vA − vB) · n|
raw disorientation = raw instability = 60 × relative directional speed
vA_after = vA − (vA · n)n
vB_after = vB − (vB · n)n
```

For a static cube, vB=0 and only the character receives a response. For flat
ground n=(0,0,1); vertical velocity is removed and horizontal velocity remains.
The line's sign does not change these results.

## Verified isolated examples

| Collision | Relative directional speed | Raw status per character |
|---|---:|---:|
| Two characters head-on, +6.4 and −6.4 m/s | 12.8 m/s | 768 of each |
| Same direction, 6.4 and 2 m/s | 4.4 m/s | 264 of each |
| Character 5 m/s perpendicular to a static obstacle surface | 5 m/s | 300 of each |
| Flat-ground landing at vertical velocity −3.2 m/s | 3.2 m/s | 192 of each |

[mechanics/body_collision.py](combat_sim/mechanics/body_collision.py) implements
these calculations separately from contact detection and world response.
Seventeen tests cover relative speeds, independent defenses, perpendicular
velocity preservation, plane collisions, static objects, exchange symmetry,
zero velocity, explicit undefined-centre rejection and precision independence.
The complete suite passes **634 tests**.

Response vectors use an explicit 50-digit context by default. Incoming status
mitigation retains the established 40-digit context. Centres and input
velocities are retained as rational values before evaluation. No impulses,
momentum transfer, mass rule or collision HP damage is introduced.

## Surface-normal distinction verified

The author resolved the flat-face ambiguity by distinguishing obstacles from
characters. At a cube's x-facing surface, velocity (6.4,2,0) becomes (0,2,0),
with 384 raw disorientation/instability. The tangential 2 m/s is retained.
Moving the character off-centre on that same flat face does not change the
direction or generate artificial sideways/downward velocity.

The obstacle helper requires an explicit keyword surface normal. It normalizes
that vector; its sign and scale do not change the response. The ground helper
uses the same surface-normal calculation with n=(0,0,1). Character/character
calculations retain the centre-to-centre rule unchanged.

## Historical integration boundaries at the isolated checkpoint

These are isolated response calculations. The shared geometry test retains
its earlier temporary stop-only contact response and excludes collision
statuses. Actual contact normals still need wiring into that timeline, along
with response/state updates. Edge/corner and simultaneous multi-surface cases
need defined handling; no face priority or averaged normal is inferred.
Ground-impact ability/self-effect stacking and ongoing movement-input response
also remain to be defined/validated when integrated. The moving-to-climb
handoff is now defined and tested in the geometry scope; see CLIMBING.md.
All earlier frozen traces remain unchanged.

## Shared integration and review corrections, 2026-10-28

Live contacts provide actual normals and common pre-contact velocity/defense
snapshots. Each contact is mitigated separately, then additions are aggregated
before one Gathering extension. A normalized corner-face sum supplies the one
obstacle status impulse; orthogonal component constraints enforce all solid
faces without reintroducing removed velocity. Character centre-line responses
retain the author's rule. Body/terrain contacts are deduplicated across cuboids.

Current world support/gravity is explicit immutable configuration; scheduling a
future jump cannot change an earlier grounded collision. Physical blocking of
a compound prerequisite finishes that intent once. A new command may retry
after occupancy changes, without an invented time delay. Persistent rest and
tangency do not repeatedly charge collision statuses.

Posture-only geometry contact freezes deformation; physical translation supplies
collision speed. Climb uses its prescribed path velocity and interrupts on
physical obstruction, followed by the usual projection/gravity. At a path corner
the outgoing velocity determines whether exact contact is actually closing.
Static top-face landings snap feet to the contacted support plane, including
cube tops. Basic-jump landing self effects remain distinct from physical contact.

At this October checkpoint, ground edges, raised-support departure and standing
on another moving body were unsupported. Current [living-body support](BODY_SUPPORT.md),
[static ledges](SUPPORT_DEPARTURE.md) and [finite floor](FINITE_GROUND.md) now
share native contact/support/flight. General turning and prescribed linked
climbing remain unfinished. The engine adds no mass impulse or collision HP
damage. [Review corrections](PRINCIPAL_ENGINEERING_REVIEW_RESPONSE.md) and
[climb evidence](results/climb-combat/REPORT.md) retain historical verification.
