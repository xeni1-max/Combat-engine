# 1E2 ability 4 source and implementation audit

Implemented and verified, 2026-11-03. Root `1E2.odt` is pinned unchanged in
results/1e2-ability4/sources. Paragraph indices below are zero-based.

| Author source | Rule |
|---|---|
| p9 | Projectile 600 damage, headshot 1500 instead; cooldown 9 s |
| p126/p128 | Slash damage, Active firing 60 ms |
| p130/p131 | Target disorientation/instability 140/140 |
| p133/p134 | Firing self disorientation/instability 165/165 |
| p136 | Db 2.5 |
| p141 | Piercing60, speed1400 m/s, acceleration−300 m/s², range damage loss, base accuracy1.7 cm/100 m |
| p143 | Impact follows distance/velocity; execute the actual curved arrival |
| p145/p147 | Release immediately after firing; intrinsic momentary |
| p267 | Add unaimed radius10 cm/100 m |

Existing author rules retain midpoint firing self effects, firing-end capacity/
payment, no debit if cancelled before payment, gravity9.81 and compensated
faster arc, actual travelled-distance falloff, actual cuboid contacts and death.
Intrinsic output uses the existing U/10 flat reduction at release.

The following are **delegated implementation decisions**, not additional author
statements:

- Current source removed the previously imported 180 ms Gathering. Use zero
  base Gathering, retaining ordinary physical hand Recovery and current O.
- Reuse the existing two-hand gun grip, left-hand origin and 2 cm sphere proxy.
  No separate pose/radius is authored for this shot. Default aim remains torso;
  scripted aim_part may select another actual cuboid centre.
- Reuse the current continuous 0.25 damage/m range loss because the source
  requires loss but supplies no coefficient. Apply it to the selected frozen
  body/head output, without an extra head multiplier. This value is reversible.
- Start the 9 s cooldown after successful paid release, matching other physical
  projectile anchors. No unlisted automatic Readying phase is added.
- No ammunition/reload rule is authored for ability4. It is governed by its own
  cooldown and effort, and does not consume ability1's separately authored
  eleven-round magazine. No extra stock or shared-magazine rule is invented.
- Use shared direct projectile delivery and the body-part mechanism described
  in BODY_PART_DAMAGE.md. Direct slash impact supplies its normal armor/status
  calculations, not the ordinary gun's separate bleed behavior.

Verification covers actual head/body/Block/terrain/friendly contact,
simultaneous shields/armor, intrinsic output snapshots, recoil/cost/cooldown,
movement/Aim, interruption, released copies and source/recipient lives. Source
metadata alone is not a completed kit delivery; keep final status in PROGRESS.md.
