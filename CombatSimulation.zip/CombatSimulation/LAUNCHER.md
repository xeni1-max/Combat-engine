# Existing 1E1 Ultimate launcher

Verified 2026-11-10 through the shared poison foundation and projectile world.
No new character ability is added; historical controlled inputs stay supported.
[Verification/reproduction](results/1e1-launcher/README.md) · [Ordinary scenario](scenarios/1e1_launcher.json).

## Author facts

1E1.odt p11/p13 equips a poisonous grenade launcher, replacing ability 1 with
impact grenades, ten rounds, radius 5 m poison for 8 s and 65 s Ultimate cooldown.
Current p137/139/141 gives swap Active400/Db2.5/intrinsic sustained. Firing
p148–172 gives G140/A180, target O/U110/110, midpoint self140/140, toxicity1200,
1150 ms cooldown from firing end, Db3.5, speed60, end-of-Active release and
two firing hands: left(0,.30,.15), right(.05,.25,.1). It is intrinsic momentary.
No instantaneous grenade HP-damage amount is supplied. Poison uses the author
formula and confirmations in POISON_VOLUMES.md: shield bypass, unchanged armor,
independent clouds and continuous exposure/residual damage.

## Delegated completion choices

- Keep immutable author profiles separate from per-actor weapon inventory.
  Ability 1 resolves its current variant when selected; each owned action and
  released projectile keeps that selected definition. Mode changes, source
  death/restoration and copying cannot reinterpret a released Qard or grenade.
  Firing uses Ultimate's reviewed effort namespace while retaining public ability 1
  identity. Applied-HP receipts follow resolved release/component type; existing
  wall slams now correctly record Blunt instead of contact, with unchanged damage.
- Swap has no unlisted base Gathering or self statuses. Common hand Recovery,
  current disorientation/timed Gathering and required functions still apply.
  Both hands use the known firing poses; reserve the same main-weapon slot as
  ability 1. Other genuinely independent actions remain legal.
- Db2.5 pays at swap Active start. Completing equip loads ten rounds and starts
  65 s cooldown; cancellation before completion grants no weapon/ammunition.
  Intrinsic sustained non-damaging work invents neither DPS nor an extrinsic
  instability-interrupt rule. Native knockdown/function/death cancellation applies.
- Each grenade pays Db3.5, consumes one round and starts its 1150 ms weapon
  cooldown at firing end. Cancellation before that point incurs no firing cost,
  ammunition or cooldown. Fire from the authored left hand with the existing
  2 cm sphere, gravity and current-torso faster-arc/no-lead aiming controls.
  Algebraically unreachable targets use the existing conservative ballistic
  aim proxy, producing a physical miss instead of a solver exception. This
  shared rule also covers the existing 1E2 impact device; feasible arcs retain
  their original faster branch. Advanced range-aware NPC selection is deferred.
- Firing's authored intrinsic category applies to its zero instantaneous carrier
  damage. Chemical toxicity is an immutable payload parameter, not an invented
  muscle-dependent chemical formula; retain Tp1200 through source instability.
  Released zero direct power and positive chemical parameters are separately
  inspectable. Source class and physical firing cost are retained.
- The first real projectile collision creates one unoccluded spherical cloud
  and once-only area O/U to living overlapping bodies, including friends/source.
  There is no extra direct HP hit or material toxin receiver. Copies retain
  their own physical first contacts and produce independent clouds without
  another firing payment or ammunition debit.
- On empty stock, return using the same known 400 ms/Db2.5 swap without another
  Ultimate cooldown. This mandatory existing weapon transition can wait for
  resources/functions; it does not refill ammunition or skip the previous
  weapon cooldown. Returning invents no separate character ability or reload.
  If the configured Ultimate is already ready, its normal equip may directly
  replace the empty launcher without a forced intermediate return swap.
  Death/restoration retains physical inventory/ammunition while cancelling old
  controlled actions, consistent with existing life restoration rules.

Actual implementation and verification belong in PROGRESS.md and the new
results/1e1-launcher package. Advanced NPC decisions and balance automation remain
deferred; this integration must keep the full six-kit/5v5 Goal in scope.

## Explicit cover contract — 2026-11-10

Delegated, behavior-preserving clarification of the review's ambiguous contract:
the instantaneous O/U pulse uses explicit world area occlusion. A collider whose
area-blocking policy is enabled can stop that pulse; ordinary cubes with area
blocking disabled do not. The separately released gas remains unoccluded and
can expose an in-range body behind that cover. Pulse recipients and gas exposure
are deliberately inspected separately. Covered/uncovered actual grenade tests
verify one pulse and unchanged chemical damage; no extra direct HP hit is added.
