# Projectile gravity and compensated aiming

**Current release/contact integration, 2026-11-03:** the ideal compensated
launch is followed by the [shared source accuracy cone](AIMING.md), and current
physics schema 2 uses [confirmed curved entry](CURVED_CONTACTS.md). Actual gun,
Qard and prison/ice casts are verified together. The current public CLI and
frozen-input/numerical boundaries are recorded in
[the evidence](results/aim-toggle-confirmed-entry/README.md).

The subsequent scripted aim_part input can choose another actual body-part
centre for a physical cast, including 1E2 ability4. The legacy physics `aim`
tag names the default torso strategy; the optional action/flight aim_part and
actual aim_point_m record an override. The same short-arc solver uses that
release-time point without target leading. Existing scenarios retain torso
aim. [Body-part rules](BODY_PART_DAMAGE.md) · [Ability4](1E2_ABILITY4_AUDIT.md).

Explicit `action_selection.<actor>.ability_targets` also permits physical
projectiles to aim at a fixed world point or registered surface. The action
pins that point/provenance; the flight records target_snapshot and aim_point_m.
It still follows compensated gravity/spread and actual Body/Block/terrain
interception. An intended surface disappearing does not fabricate contact;
the released trajectory may hit another real surface. No-enemy targeting and
the actual [grappling gun](GRAPPLING_GUN.md) use this shared path.

## Author-specified rules

Author clarifications, 2026-10-25:

- Gravity is **9.81 m/s²**, vector (0,0,−9.81) in world z-up coordinates.
- Aim compensates for fall and chooses the faster arc. The selected aim point
  is the torso centre; projectiles start at their specified ability start hand.
- Existing acceleration components and gravity add. The gun's −300 m/s²
  contribution opposes **instantaneous velocity**, not the initial launch axis.
- Damage falloff uses actual traveled path length, including curvature.

For a gun round at nonzero velocity v:

`acceleration = (0, 0, −9.81) − 300 v / |v|`

The common combat timeline executes this model for supported physical projectile
casts, including moving body/terrain contacts, damage, death and resource effects.
Qard's delayed blasts and deployed beams also use shared spatial effects.
Earlier stationary/straight-flight scopes and saved results remain historical
checkpoints; current accuracy and numerical refinement require their explicit
selected input modes. No new character ability was added.

## Trajectory and aiming implementation

[gravity.py](combat_sim/mechanics/gravity.py) provides analytic ballistic motion
and arc length without deceleration, and adaptive binary64 RK4 step doubling
when deceleration follows instantaneous velocity. Path length integrates speed
as a seventh state. [persistent_gravity.py](combat_sim/mechanics/persistent_gravity.py)
extends this to immutable flights through the battle observation horizon, using
safe nonzero-speed integration steps and the explicit terminal rule below.
Queries do not change stored trajectory states or integration knots.

[aiming.py](combat_sim/mechanics/aiming.py) gives the analytic minimum positive
flight-time solution for undecelerated projectiles. The gun instead uses
[decelerating_aim.py](combat_sim/mechanics/decelerating_aim.py): a damped shooting
solve in elevation and flight time, with four deceleration continuation stages
starting from the fastest ballistic solution. The endpoint is checked again
using tighter integration controls. The solver records its branch, residual,
refinement difference and trajectory evaluation count.

The supported gun solution must lie within the conservative positive-speed
horizon `flight_time < launch_speed / (deceleration + gravity)`, about 2.905 s
for the gun. The continuation chooses the short branch within this domain;
it is **not a global optimality proof** across unsupported near-stop/high arcs.
Failure to resolve the branch raises an explicit error instead of substituting
straight aim, another trajectory or an unproven claim that the target is
unreachable. This covers the tested standing torso ranges in the current arena.

Delegated aiming decision, 2026-10-26: solve toward the target's current torso
at release and freeze the launch velocity. Do not lead moving targets or search
for a slower arc around cover. This isolates fall compensation from future NPC
prediction and gives reproducible moving hits and misses. Fixed body facing is
still independent of aim; turning constraints remain a later integration task.

## Contacts and numerical event ordering

[gravity_collisions.py](combat_sim/gravity_collisions.py) recursively encloses a
curve about its chord by `A Δt² / 8`, tests sphere overlap, and returns a time
and path-length bracket. [moving_gravity_collisions.py](combat_sim/moving_gravity_collisions.py)
subtracts the collider's interval displacement from that same immutable flight.
It includes collider acceleration in the relative acceleration bound. Returned
locations are world coordinates and distances are projectile path lengths.
This avoids using a chord as the flight or relative travel as damage falloff.

[gravity_projectile_rules.py](combat_sim/gravity_projectile_rules.py) checks every
eligible living body and terrain collider over the current kinematic interval.
It excludes the shooter, retains friendly fire, and removes dead bodies from
eligibility. Released flights survive their owner's death. A changed motion or
earlier event causes contact recomputation through the shared coordinator.

Delegated numerical choices:

- Curved contact brackets use at most 1e-12 s width and 1e-14 m clearance controls.
- Confirmed contacts are ceiled to a common **1e-6 ms (1 ns)** event grid. This is
  numerical event resolution, not exact physical simultaneity. Objects/parts
  tied on this grid use stable identity order; one shot is consumed once.
- Separate shots at the same tick share pre-hit defenses and proportional
  shield absorption. Existing phase/release ordering remains first, then
  projectile impacts, then body contacts. Inert terminal events follow impacts.
- If rounding crosses an intervening boundary, retain contact evidence only
  when advancement actually reached the confirmation time. An earlier
  interruption invalidates it. Retaining reached evidence prevents brief
  contacts from disappearing merely because they ended before the next tick.
- Combat states use Decimal arithmetic independently of binary64 trajectory
  arithmetic. Increasing combat precision does not increase projectile precision.

Trajectory refinement and contact brackets are numerical diagnostics, **not
certified bounds on the exact differential equation**. Unresolved near tangencies
raise an error; they are never silently changed into hits or misses. The static
isolated helper retains its historical looser defaults; the combat controls are
explicit in [projectile_gravity.json](data/physics/projectile_gravity.json).

## Terminal rule and controls

At zero velocity, direction-following deceleration has no direction. Under the
author's delegation, a decelerating round becomes inert when speed first reaches
**1e-6 m/s**, without a collision, damage or impact mark. This avoids undefined
acceleration or artificial reversal; its remaining displacement is negligible
at the declared spatial controls. The floor crossing is refined within 1e-9 s,
then the stored position and traveled distance remain fixed. A confirmed impact
wins over an inert stop in the same numerical tick.

This extension supports zero deceleration (ordinary gravity, including an apex)
or positive deceleration **greater than gravity**, which guarantees monotone
speed decrease. Positive deceleration at or below gravity is explicitly
unsupported by the terminal model. The current gun's 300 m/s² is supported.

Default integration controls: maximum step 0.01 s, relative tolerance 1e-11,
absolute tolerance 1e-12; aim residual tolerance 1e-7 m, with refinement difference
at most one quarter of that tolerance. These are numerical controls, not damage
or movement ticks. API calls require an explicit physics definition; the CLI
loads it when the gravity scope is selected. Every result records its definition.

## Verification and remaining scope

The focused helpers check analytic limits, work–energy balance, convergence,
long-flight stopping, immutable queries, compensated endpoints, moving and
accelerated colliders, finite ground, rounded corners and split intervals.
Integrated checks cover moving hits/misses, motion changes after release,
actual-path falloff, shooter death, cube/floor contact, inert stops, actor order,
observation schedules, combat precision and sub-nanosecond scheduling boundaries.

[Moving gravity results and replay](results/moving-gravity-combat/REPORT.md) use
the original arena. The saved five-second duel, diagonal ground miss, cube
interception and inert miss reproduce complete traces and summaries. The earlier
[isolated gravity package](results/gravity-isolated/REPORT.md) remains historical,
with its explicit launch inputs and conservative short-duration integrator.

Grounded walking/running/sprinting/stopping are integrated. Jump, climb, posture,
turning, knockdown/Get Up geometry, moving area exposure and the other kits
remain unfinished in shared combat. No animation work is planned.
