# Upright orientation and fixed-frame contact geometry

2026-11-13. This is the geometry foundation for the author's whole-body turn.
The shared world does not advance turns. [Fixed oriented materials](ORIENTED_WORLD.md)
use native world consumers, and [fixed initial actor yaw](ACTOR_FACING.md) now
migrates pose/hand/delivery and dynamic-body consumers. Their verification is
recorded separately. Continuous angular prediction and owned control remain.
[Turning rule](TURNING.md) · [Evidence](results/oriented-geometry/README.md).

The following representation and API choices are delegated engineering
decisions. They add no ability or effort cost and retain all six characters,
standing dimensions, timings and original source documents.

`YawFrame` stores rational c/s with **c²+s² exactly one**. Heading zero faces
world +x; positive heading proceeds toward world +y. The source local axes
remain right/forward/up. The world basis is right=(s,−c,0), forward=(c,s,0),
up=(0,0,1). Existing +x/−x placements are exact cardinal cases. Point transforms
include an explicit origin; vector transforms include no translation. Inverses,
dot products and distances preserve the selected metric exactly.

Degree input is reduced modulo 360 before computation. Quarter turns remain
exact cardinal frames. Other angles use owned Decimal precision, 16 guard
digits, Machin's pi formula and reduced-angle sine/cosine series. The computed
half-angle tangent selects the rational unit pair
`c=(1−t²)/(1+t²), s=2t/(1+t²)`. This quantizes the requested heading while
preserving orthonormal geometry afterward. Actual stored coefficients are
inspectable. Independent rational atan bounds, caller-context checks and
precision refinement verify representative conversions. No universal angular
trajectory or performance certificate is claimed.

`OrientedCuboid` retains local dimensions and fixed yaw. Its `bounds` property
is an enclosing world AABB for broad-phase use. Containment, closest point,
sphere/column membership, segment intervals and straight sphere sweeps use the
actual local box and return world contact points. Box overlap uses the complete
separating-axis set: both horizontal local-axis pairs plus up. Placement rotates
the six source cuboids without changing dimensions or inferring a new pose.

Two existing contact APIs now accept this shape:

- `earliest_moving_sphere_contact` transforms world trajectory and box motion
  into the exact local frame, reuses existing rational root isolation and
  returns world points with the original outward time enclosure. Quadratic
  centre motion and quadratic local resizing retain their physical units.
- `first_box_contact` projects onto the complete separating-axis set and uses
  the existing quadratic entry solver. Motion vectors remain world coordinates;
  full-dimension rates/accelerations follow local shape axes. The caller owns
  Decimal precision as before. Finite zero-thickness ground remains valid.

Both retain their original axis-aligned branches. Each supplied frame is fixed
throughout the complete query interval. Neither chooses collision response or
samples a turn into stationary poses. Fixed initial actor yaw and oriented
material admission require current finite-face mobile rules; older scopes
retain their original restrictions.

Fixed materials and actors now use these contracts for support, native normals,
occupancy, cover/fields, pose/hand and heading-dependent delivery, including
retained dynamic-body planes. Next extend saved prediction to continuous
angular motion and wire owned turning with the confirmed speed-dependent
timing. Translation retains its single shared writer. The author delegation
covers speed sampling and steering; no routine clarification is held for the
author.

This foundation does not establish complete shared-engine turning. Prescribed
linked climbing, cross-kit/5v5 verification and other recorded boundaries remain.
Advanced NPC behavior, mass experiments and balancing automation are deferred.
