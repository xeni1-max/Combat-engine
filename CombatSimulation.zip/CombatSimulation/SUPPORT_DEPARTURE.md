# Static support and raised-terrain departure

Current extension, 2026-11-13: [finite-ground rules](FINITE_GROUND.md) select
`finite_faces_v2`, reusing every static witness/departure rule below while
removing the outer-floor guard through actual finite-sheet collision/flight.
Explicit `static_faces_v1` and older inputs retain the historical scope below.
The subsequent [angular extension](ANGULAR_SUPPORT.md) composes support witnesses
against candidate yaw/pose/reference paths, preserving this contact policy.

2026-11-10. Implementation and verification status are recorded in
[PROGRESS.md](PROGRESS.md). This addresses R1 from the November 10 principal
review through existing saved paths, support transactions and gravity.

The author specifies gravity, colliding bodies, finite ground/open boundaries,
noncolliding dead bodies and independent released effects. The following
contact and departure policy is a delegated engineering decision, consistent
with [living-body support](BODY_SUPPORT.md); no character ability is added.

`terrain_support: {"mode":"static_faces_v1"}` admits a character part's
underside on a static top face when its vertical gap is within the existing
1e-20 m contact band and its XY overlap has positive area beyond that band.
Full containment of the character is unnecessary. Every real underside may
support; a lower part beside a narrow solid does not invalidate another part's
actual contact. A zero-area edge supplies no support. Alternate parts, adjacent
surfaces and living supports are considered before declaring loss. No new
horizontal friction, edge balance force or automatic step-up is introduced.

The shared geometry helpers form opposing face gaps from the saved reference
polynomial plus part-centre/size velocity and acceleration. The saved prefix
ends at the first witness departure, including pose withdrawal. Remaining
witnesses are then reconsidered; losing one foot does not imply losing all
support. Certified constrained paths may be shortened to a valid prefix, so
grapples, fixed/paired tethers and imposed forces keep the same translation
writer. Root upper bounds are normalized to the same declared Decimal clock
used by scheduling and advancement. Observations consume that prefix; they do
not choose a new physical departure time.

After atomic prefix consumption and clock installation, common support closure
chooses an alternate support or calls `SpatialTransitions.release_support`.
It retains instantaneous position/velocity and independent motor/force inputs,
then uses native flight and landing. Leaving a ledge adds no jump payment or
basic-jump landing obligation. Existing paid launch obligations retain their
own lifetime and apply once at actual contact. Loss cancels a conflicting body
action through ordinary ownership; unrelated hands/holding/released entities
continue. A rigid group's interim support query does not prematurely replace
its independent motor with an invented jump state.

Native collisions use the actual touching part's reference depth on a single
or compound top. Separating edge tangencies cannot immediately recreate a
landing, and cached vertical contact planes require positive supporting area.
Actual inward contacts still use their existing status and velocity response.
Support expiry/destruction at departure is handled by the same transaction;
it cannot create a second takeoff or payment.

At this November 10 checkpoint, historical inputs without this rule retained
their raised-support guard and outer-floor departure had a separate footprint
guard. The November 13 extension above now defines finite-floor and below-floor
behavior explicitly. Angular static/body support is extended above; active
linked response and prescribed linked climbing remain unfinished.

[Ordinary climb/walk scenario](scenarios/raised_support_departure.json) ·
[Shared path contract](BODY_PATHS.md) · [Atomic transitions](SPATIAL_TRANSITIONS.md)
