# Knockback directions and grapple-group resistance

## Author rules

Clarifications, 2026-11-01 and reaffirmed 2026-11-02: characters still in a grapple when a knock-away
ability hits are knocked away together. The resistance formula uses sums of
their stats: maximum HP is `H1 + H2`, and current armor is `a1 + a2`.
Knockback and knock away mean the same thing. Knock up is this displacement
directed upward; knock down is directed downward.

Primary formula: `Collision details.odt` p38–42 and Object 3/content.xml:

`P2 = max(0, P - (H/500 + armor/10)^1.1 / 150)`.

`P` is nominal knock distance in metres; `P2` is resisted distance. HP means
maximum HP, not remaining HP. Armor is current armor at application. The zero
floor is a delegated consistency choice, matching other resisted quantities.
For the author's grapple pair:

`P2 = max(0, P - ((H1+H2)/500 + (a1+a2)/10)^1.1 / 150)`.

Sum stats first, then evaluate the nonlinear term. Do not add already-computed
individual resistances or divide the resulting knock a second time by the
grapple's velocity weights. Shield HP does not occur in this formula.

## Delegated composition and boundaries

For simultaneous connected grapple links, extend the pair rule to the connected
component, counting each actor once even in cycles. Apply one resisted knock to
the group. Preserve its active grapple links unless a separate documented
release cause has already resolved. Current cast delivery snapshots living
membership at impact and applies force before that hit's fatigue teardown.
Death/escape/expiry resolved before the impact can change membership; a later
life never inherits the committed force. This component extension is delegated;
the impact timing corrects a former ordering that violated the author's rule.
[Current delivery and historical mode](KNOCK_DELIVERY.md).

This rule concerns spatial displacement resistance. Individual damage, armor
loss, disorientation, instability, shield interception and actual terrain/body
contact penalties retain their existing recipients and mitigation rules. An
unrelated binding chain is not automatically a grapple group.

Downward displacement is separate from the existing prone/Get Up eligibility
flag. An ability must explicitly apply that state if required; the word “down”
alone does not replace vertical physics with a boolean flag.

## Current implementation

[knockback.py](combat_sim/mechanics/knockback.py) implements the summed-stat
distance assessment and the directional aliases. [Persistent linked motion](LINKED_MOTION.md)
now moves a configured grapple component together through shared gravity,
contacts, later movement, force changes, expiry and life transitions.
`world.grapple_links.knockback_distance(actor, nominal_m)` snapshots actual
living membership and defenses; atomic imposed motion propagates to the group
without a second weight division. [Evidence](results/grapple-motion/README.md).

Actual [1E5 grab/holding](GRAPPLE_DELIVERY.md) now registers the grapple links
through authored contact. Its group resistance and imposed upward-force tests
use those live holds. The force intervention remains an engineering operation,
not an authored knockback cast. [3E5's actual heavy punch](KNOCK_DELIVERY.md) now
uses real contact, post-hit/life ordering, summed-stat group resistance, finite
additive impulses and temporary 100% elasticity. Its 500 ms force window is a
documented engineering choice. The [conditional upward counter](CONDITIONAL_MELEE.md)
now delivers a resisted ballistic height through the same group/life snapshot.
Current [saved body paths](BODY_PATHS.md) preserve both deliveries: the
[held-pair encounter](results/body-paths/held_counter_scenario.json) receives a
real heavy-punch knock and then a real upward counter. Its trace checks summed
stats before the nonlinear term, equal group velocity increments without a
second weight division, individual force clocks and real landing.
The later [live distance encounter](results/persistent-distances/held_heavy_scenario.json)
also joins a tether-only fourth actor: the held pair contributes 29080 maximum
HP and 515 armor to resistance, while the fourth actor shares constrained
motion without joining that grapple assessment. [Controller rules](PERSISTENT_DISTANCES.md).
The [actual chain encounter](results/chain-cast/held_knock_scenario.json) now
verifies the same separation using authored casts for the chain, hold and heavy
punch. No engineering attachment supplies that encounter's constraint.
The [existing falling kick](LEAPS.md) now supplies actual descending contact
and a delegated 15 m/500 ms downward increment through this same assessment.
It does not substitute a forced-prone flag. Real held recipients contribute
summed stats before the hit's fatigue teardown. Charge/slam also has its own
[shared delivery](CHARGE_GRAPPLE.md). A resistance calculation alone does not
complete an ability; current verification remains in PROGRESS.md. Current
status is indexed in [ENGINE_STATUS.md](ENGINE_STATUS.md) and
[PROGRESS.md](PROGRESS.md). Primary ODTs remain unchanged.
