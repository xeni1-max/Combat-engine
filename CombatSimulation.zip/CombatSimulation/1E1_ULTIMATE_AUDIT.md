# 1E1 Ultimate: poisonous grenade audit and initial scope

Current root ODTs and author clarifications are authoritative. Paragraph numbers below are zero-based ODT paragraph indexes. The embedded Poisonous equation was read from its actual `Object 5/content.xml` reference. No source document is edited.

| Rule | Source | Status |
|---|---|---|
| Equips a poisonous grenade launcher; ability 1 becomes grenades | `1E1.odt` p11/p13 | Confirmed; initial equip and one grenade in scope |
| Cloud radius 5 m, lifetime 8 s, 10 ammo, Ultimate cooldown 65 s | `1E1.odt` p13 | Confirmed values; cloud and one ammo consumption executed; Ultimate availability/65 s anchor excluded |
| Weapon-swap Active 300 ms | `1E1.odt` p122 | Confirmed |
| Grenade Gathering 140 ms, Active firing 180 ms | `1E1.odt` p124/p125 | Confirmed |
| Self O/U 140/140 on firing | `1E1.odt` p130/p131; earlier author midpoint and self-mitigation overrides | Confirmed: midpoint Active, bypass mitigation |
| Target O/U 110/110 on impact | `1E1.odt` p127/p128; author reply | Confirmed: once to everyone in the five-metre explosion area |
| Toxicity 1200 | `1E1.odt` p133 | Confirmed |
| 1150 ms cooldown after Active firing | `1E1.odt` p135 | Confirmed; automatic cooldown timing logged for this one shot |
| Speed 60 m/s, release at end of firing, impact depends on distance | `1E1.odt` p139/p141/p143 | Confirmed; supplied path length, constant listed speed |
| `Td=((Tp²-10*RT²)/Tp)*sqrt(tT-to)` | `Damage types.odt`, Poisonous p42/p44/p46 | Confirmed; negative coefficient floors to zero under existing damage-floor rule |
| Elapsed exposure grows, freezes after exit; non-exposure then grows until root reaches zero | Author reply | Confirmed; residual lasts as long as exposure |
| Gas bypasses shields and damages HP | Author reply | Confirmed; shield and its regeneration history untouched by gas |
| Poison leaves armor unchanged | Author reply | Confirmed |
| Poisonous exposure/payment timing | Author replies plus earlier continuous toxin clarification | Continuous analytic integration; no invented ticks |
| Separate instantaneous grenade HP damage | No formula/value listed | Not specified; initial model executes listed poison damage and explosion statuses only |
| Changing toxin resistance during an application | Not clarified | Excluded: this scope has constant profile resistance and no resistance-changing action |
| Overlapping clouds/re-entry/death/action switching | Not sufficiently specified for this scope | Excluded |

## Established initial scope before implementation

One authorized Ultimate equip plus one grenade, zero initial caster disorientation/instability, explicit impact distance, and explicit explosion recipients. Each recipient is inside from detonation until one supplied exposure-end time, no later than cloud expiry. These exposure windows are encounter inputs, not automatic movement/radius detection. A target can leave before the cloud expires; its residual toxin continues independently. Existing statuses on targets are supported. An explicitly included caster receives area effects and poison under friendly fire.

The first sample uses 60 m flight distance and two seconds of target exposure. The cloud persists for eight seconds, while target exposure ends after two seconds and residual ends after four seconds. Resolve the cloud, all target effects and the first weapon cooldown completely. Only nonlethal returned runs are supported; full eight-second exposures can exceed normal HP, so these are rejected rather than inventing death timing. Initial caster statuses are excluded pending a separate review of additional Gathering across equip versus subsequent ability-1 activation; this does not exempt either future activation from the confirmed J=O rule.

Keep character/ability data, pure poison formulas, controlled event execution, supplied encounter decisions and result summaries separate. Damage remains exact rational/square-root arithmetic. Source definitions for 10 ammo/65 s cooldown do not establish repeated Ultimate fire or activation availability. This stage will consume one grenade and record its cooldown; no reload, post-ammo behavior, Ultimate-end transition, dyspnea cost or repeated-fire scheduler is inferred.

## Analytic calculation

For constant `C=max(0,(Tp²-10*RT²)/Tp)` and exposure T seconds, DPS is `C*sqrt(t)` during exposure and `C*sqrt(T-u)` afterward. Each full phase integrates to `(2/3)*C*T*sqrt(T)`. Total is `(4/3)*C*T*sqrt(T)`. Armor is absent from the equation; the venomous slash-delivery factor does not apply to poisonous gas. Shield bypass is explicit, not a zero-defense shield calculation.

At 60 m from activation at 0, equip ends at 300 ms, firing begins at 440 ms, self effects occur at 530 ms, grenade releases at 620 ms, and detonation is 1620 ms. Weapon cooldown ends at 1770 ms. With T=2, exposure ends at 3620 ms, residual ends at 5620 ms, and cloud expires at 9620 ms. No extra Gathering is inserted after firing has begun.

## Implemented and verified

The established equip/grenade/cloud scope now executes. At 60 m into 2E4 with HP 9080, armor 165, shield 4000, toxin resistance 44 and a supplied two-second exposure: `C=(1200²-10*44²)/1200=17758/15`. Each phase deals `(71032/45)*sqrt(2)` ≈ **2232.320395**; total is `(142064/45)*sqrt(2)` ≈ **4464.640789**. Final HP is approximately **4615.359211**, while shield remains 4000 and armor 165. Ammo becomes 9. Cloud expiry remains 9620 ms despite target exposure ending at 3620 ms.

**311 automated tests pass**, including poison-specific formulas, exact partitioned integrals, equal exposure/residual totals, shield bypass, unchanged armor, one-time area effects, friendly fire, multi-target windows, zero exposure/empty areas, full lifecycle boundaries, input validation, deterministic replay and existing model regressions. The eight-second lifecycle test with synthetic full mitigation verifies clocks without inventing death behavior; canonical saved encounters use nonlethal exposure windows.

Saved traces, formula-only full-exposure potential, source/code/test snapshots and reproduction commands are in [results/1e1-ultimate-stage](results/1e1-ultimate-stage/README.md). Earlier snapshots remain unchanged.
