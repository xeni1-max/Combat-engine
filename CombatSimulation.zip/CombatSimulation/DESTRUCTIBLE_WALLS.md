# Destructible walls

2026-11-02. The author requests walls with **2000 HP**, damaged by blunt,
slash, Qard, heat, constriction and tear, in preparation for 3E5's Ultimate.
This increment supplies terrain, durability and shared collision/damage paths;
the subsequent charge implementation is tracked in [CHARGE_GRAPPLE.md](CHARGE_GRAPPLE.md)
and [PROGRESS.md](PROGRESS.md).

## Arena and delegated choices

[The wall arena](data/terrain/destructible_arena.json) retains the original
500 × 500 m floor, open sides/top and three 1.8 m cubes. It adds:

| Object | Centre (x, y, z), metres | Size (x, y, z), metres | HP |
| --- | --- | --- | --- |
| wall_1 | (12, −8, 1.5) | (0.4, 8, 3) | 2000 |
| wall_2 | (20, 12, 1.5) | (8, 0.4, 3) | 2000 |
| wall_3 | (−12, 8, 1.5) | (0.4, 8, 3) | 2000 |

Placement, dimensions, unclimbable panels, zero armor/resistance, and
area-transparent material are delegated design choices. Each wall has one HP
pool and an immutable `wall` tag, independent of its name or orientation.
Bodies and projectiles collide with intact panels. Blast and beam area effects
pass through them, extending the author's original cube policy. Walls can
still receive area damage themselves. Destruction removes the whole collider;
there is no rubble, animation, biological bleeding or invented character status.

The wall arena is a separate selectable preset so older three-cube scenarios
retain their explicit layout and reproduce unchanged. The original cubes keep
indestructible HP; the floor remains permanent. Terrain cuboids use `size_m`;
cubes retain `side_length_m`. Optional positive `hp` requires the current mutable
world, so historical static engines cannot silently turn a destructible object
into a permanent obstacle.

## Damage and charge integration

All six requested damage types consume the same pool. Existing direct attacks
use their ordinary effort-adjusted power and actual-path falloff; objects have
no armor or personal shield. Continuous heat keeps its existing exposure curve
and solves the zero-HP time on the shared timeline. Loss is capped at remaining
HP and never grants actor healing/revival credit. Same-batch nonpiercing shots
all stop at the pre-batch solid; only later shots can use the opening.

Current `fixed_compound_v2` adds damageable objects to delayed-blast recipients.
An impact and its later Qard blast both consume wall HP; a nearby wall also
receives the blast when the projectile originally hit a character. Each area
attack applies once per object across overlapping parts. Several same-time
blasts share HP clipping, while destroyed objects are no longer recipients.
Frozen version 1 retains its former character-only blast behavior. Pre-change
captures from this increment are preserved under `before-blast-integration/`;
the top-level final captures use version 2.

The shared object API `collider_system.damage(id, amount, source=...,
damage_type=...)` accepts `blunt`, `slash`, `qard`, `heat`, `constriction`, `tear`
and the source's combined name `constriction_tear`. Its amount is resolved HP
pressure, not an unintegrated DPS value. Unknown types/invalid amounts reject
before mutation. The optional field records typed future deliveries without
changing historical untyped engineering receipts. Actual gun, punch, Qard and
beam casts exercise the existing delivery paths; constriction/tear are verified
through explicitly labelled object-API probes. Current creature grabs are not
silently allowed to hold buildings.

`3E5.odt` specifies wall destruction while the charge's +50% speed state is
active, plus 700 blunt damage from slamming its victim. That qualifying destroy
operation is separate from ordinary wall HP damage. The actual
[charge](CHARGE_GRAPPLE.md) consumes a qualifying wall's remaining HP separately
from its 700-base victim damage; it preserves the authored destruction rather
than turning it into a 700-damage wall chip. Destruction uses the same contact
invalidation, climb/support loss and rescan paths as other mutable colliders.
[Shared collider contract](WORLD_COLLIDERS.md).

The later [committed contact receipts](CONTACT_EVENTS.md) pin wall identity,
revision and the actual held group before native collision or fatigue can end
the hold. This prepares causal wall-slam handlers without adding charge, grab,
victim damage or automatic wall destruction to ordinary collisions.
The subsequent actual charge uses those receipts for conditional fracture and
700-base victim damage; hand interception stages fracture after the complete
ordinary damage batch so nonpiercing shots still stop at the same-time wall.

Run the ordinary demonstration:

```sh
python3 -B -m combat_sim run scenarios/destructible_wall_gun.json \
  --terrain data/terrain/destructible_arena.json --summary-only
```

Verification and complete captures are in
[results/destructible-walls](results/destructible-walls/README.md).
