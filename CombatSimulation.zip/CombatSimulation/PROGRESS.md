# Combat Simulation Engine — Progress

## Verified source repair — complete electrical resistance imports

2026-11-14. **Goal active/incomplete; previous turn made progress before its
explicit pause.** All617 source hashes matched the paused handoff on resume;
no old jobs were live. Both ordinary1E1/3E5 fence failures were reproduced.
Their primary ODTs explicitly give resistance150/250; only those two omitted
data entries are restored. No fallback, formula, ability or lifetime change.

**All3379 methods pass in1318.186s**, four isolated processes with complete,
exact once-only/disjoint coverage, no errors/failures/skips and495 matching
pre/post tested-source hashes. This is the first complete gate for the31
inherited target-policy/query methods as well as the4 new all-roster methods;
all3344 methods from the last sealed full backend remain. Seventy-six affected
checks pass34.276s. Eighteen complete all-six fence/HP/shield/beam encounters
pass wholeCLI/hash4547 and precision80/17ms/reversed/ambient28 controls; maximum
checked difference is3.83524402532726855371058009098e-46. All32 old current-kit
and6 target-policy complete traces remain exact under the current fixed inputs,
including their high controls and fresh wholeCLI/hash4561 runs.

The original full-priority30s mixed battle completed: A4/B1 alive, HP accounting
error1.100e-44, no pending projectiles/revival attempts. Numerical controls and
the required position/policy/roster variations are still running. Advanced NPCs, mass simulation
and balancing remain deferred. The repair package is unsealed while that run
writes evidence. [Current handoff](results/fence-roster/WORKING.md) ·
[Source/verification](results/fence-roster/README.md).

A bounded512-query corpus from the actual run contains241 unique exact inputs.
A field-query memo prototype reproduces the sample and reduces its calculation
time about39%; this is not a whole-engine speed claim. After92 prototype methods
and112 exact full-output comparisons, the memo is promoted. All3389 methods now
pass in1403.140s, with exact once-only/disjoint coverage, no failures/errors/skips
and497 matching pre/post/current tested-file hashes. The unchanged review sets
pass4/4 in3.543s and7/7 in7.091s after promotion. The full broad controls are
running; completion remains unproven. All prior10399 result files and14 primaryODTs are
being preserved; the older paused/unsealed package is historical evidence.

The [completion audit](results/fence-roster/COMPLETION_AUDIT.md) keeps all five
original criteria explicit. It found a result-description/provenance issue:
lowest-HP selection works, but the serialized rule still promises nearest;
a custom API policy reusing that name can suppress its selection record.
An [isolated correction](results/fence-roster/policy-description/README.md) passes
24 affected methods and six complete API/high/CLI controls, with only the stated
description/provenance differences. It is not promoted while the broad controls
consume frozen root code. Goal completion remains unproven even if that batch
succeeds; inspect/promote this small follow-up and reconcile final evidence.

Independent saved-state audit now checks18,890 actor states and15,430 per-life
HP samples in the completed30s original trace; maximum discrepancy about1.52e-44.
All32 earlier complete kit traces also pass, including funded healing/revival.
These strengthen accounting/ownership evidence without rerunning simulations;
the full broad controls still need their own completed receipts.

The post-memo nearest baseline and productionCLI/hash4591 controls now both
finish the full30s and reproduce the entire pre-memo result exactly as parsed
JSON, including38648 events. The complete nearest high control also passes;
largest checked difference is2.5668788345545272e-10 versus1e-8. Independent
high timeline audit checks33,530 raw states/29,830 HP samples. Four of12 broad
receipts are complete, including the staggered baseline. Further controls
remain in progress. Wall times do not establish an overall memo speed gain.

A [bounded actual-contact profile](results/fence-roster/focus-profile/FINDINGS.md)
identifies repeated balance-resume/support planning, with modest167-bit current
coefficients and no active distance links. A labelled controlled reproducer
proves that an invalidated pose prediction still cuts a saved lease and advances
the global clock before rejection. This needs a shared clock correction and
real continuation checks; it is not fixed yet. The batch manager also leaves
ready controls waiting behind an unfinished prerequisite. Preserve live jobs,
full scopes and all receipts while resolving these issues. Goal incomplete.

## Paused work — target policies and shared prediction queries

2026-11-14. **Goal paused at the author's request.** This increment is unsealed
and the full regression gate is incomplete. No further engine work runs.
[Durable handoff](results/target-policies/README.md) ·
[Detailed state and live-job history](results/target-policies/WORKING.md).

Implemented independent nearest/lowest-current-HP enemy policies through the
existing legal action path, immutable inputs, explicit legal-target admission
and action-linked provenance. Existing nearest traces are unchanged. Exact
constant/balance reuse, per-query body/projectile derivative caches and
conservative whole-interval field rejection reduce repeated prediction work.
No combat formula, tolerance, ability or mechanical character value changed.
Rules/architecture: [TARGET_POLICIES.md](TARGET_POLICIES.md),
[PREDICTION_QUERIES.md](PREDICTION_QUERIES.md).

Completed verification:141 affected checks pass157.718s;112 later geometry/
policy checks pass27.719s. All32 previous current-kit traces reproduce exactly
with their complete CLI/hash4511 and precision80/17ms/reversed/ambient28
controls. All6 new policy captures and their complete CLI/hash4523/numerical
controls reproduce on the final current backend. Unchanged review checks pass
4/4 in4.075s and7/7 in10.706s. The full3375-method suite was interrupted on pause:
three shards complete successfully(2531 methods);797 methods completed in the
remaining shard, whose last47 methods lack a complete receipt. **No full-suite
pass is claimed.** Frozen tested-source inventory contains494 files.

The original30s full-priority5v5 exposed a real `KeyError: electrocution` in
ControlledDamage.sources/key. Current1E1 and3E5 resistance maps lack that entry;
the other four profiles contain it. Failure is preserved under
results/target-policies/battle-probes/nearest_lines.error.txt. **Unfixed at pause.**
Next inspect those two primary character sources, import their actual resistance
values or explicitly resolve any source gap, then test actual fence pressure
against all six profiles through shield/HP and coupled heat. Do not silently
invent a zero-resistance fallback. Preserve all old captures/inputs and run a
fresh final full suite after that correction.

Mixed5v5 first1000ms improved from162.102s to100.616s with the same543 saved
frames; it reached2000ms before its later crash. Separate main-attack5v5 reached
22000ms before the user pause(30s requested); it has no completed result. Neither
is a completed5v5 control. Keep full horizons and scopes explicit. Broader
performance remains unresolved. Old diagnostic false leads, intentional stops
and one observer cleanup field error are preserved and distinguished from the
actual engine failure. All jobs were stopped; no new abilities or primary ODT
edits. The preceding sealed checkpoint remains current-kit-audit; resume from
this unsealed handoff rather than rerunning old live-job commands blindly.


## Verified checkpoint — current six-kit delivery audit

2026-11-14. **Goal active/incomplete; previous turn made progress.** All32
creative source abilities and6 additional basic slots have positive current-rule
witnesses across32 complete shared encounters. They require actual contacts,
triggers, payloads or transport, not merely configured abilities. Canonical root
rules replace historical wrappers for these new runs. No engine code or
mechanical/numeric character value changes; only3 stale descriptive status
strings and current documentation are corrected.

All32 pass whole productionCLI/hash4511 equality and combined precision80/
17ms/reversed/ambient28 controls. Largest checked difference is about2.0316e-43,
below1e-8. HP/healing/life/resource accounting passes. Actual probes cover
reload after11 rounds, portals for two allies, clone HP/marks on both targets,
three-mark freeze, fences/ice/prison, both arm components/double wound basis/
piercing, both2E4 enhancements/venom/funded healing, automatic counter/revival,
both dashes, descending kick, real incoming-dash upward counter and two wall
fractures. All38 source/basic slots map to explicit activation channels. Six
wrong-path selections reject instead of inventing active/passive aliases.

The implementation/tests retain the exact3344-method verified backend; those
historical/current methods were not needlessly rerun for unused descriptions.
This increment adds32 current-rule delivery controls, not a universal interaction
proof. One initial charge recipe used a different arena profile; its rejection
is preserved. A knock-in counter selecteda but missed current pose geometry;
a real incoming dash supplies the positive hit. Two checker field names and an
open-ended ballistic clock reader were corrected without changing simulation
outputs or turning null expiry into a finite deadline. Failed drafts remain.

All10069 older result files and14 primaryODTs are preserved. [Inventory and
interaction scope](KIT_INTERACTIONS.md) · [Evidence and audit](results/current-kit-audit/README.md).

**Next:** simple replaceable target policies and measured reproducible5v5
variations, closing real shared-engine interaction failures they reveal.
Advanced NPC/mass/balancing work remains deferred; overall Goal incomplete.

## Verified checkpoint — prescribed angular and linked climbing

2026-11-14. **Goal active/incomplete. Previous goal turn made progress.** Native
turns, compatible prescribed climb routes and actual grapple attachment now
compose on the shared reference writer. A genuinely redirected route retires
before future motion is consumed, preserving paid effects, reached position and
each own input behind the weighted projection. Tangent angular impacts can stop
heading without fabricating flight. Real obstructions still interrupt. Supported
1E5 ground-drag preparation is legal; unsupported entry remains invalid, while
actual3E5 charge can grab a climber. No character/ability data changed.

All **3344 methods pass in 1280.173 s**, four isolated workers, exact once-only
disjoint coverage, no failures/errors/skips and490 matching tested-file hashes.
Twenty-four methods are added; one old expectation is strengthened to require
pre-displacement interruption without rewind. All other old methods remain.
The37 focused checks pass in417.523s; later death/range/heavy/preemption checks
pass separately. Unchanged reviews pass4/4 in3.992s and7/7 in7.994s.

Seventeen complete frozen-input captures pass whole-output hash4447 controls
(15 productionCLI,2 labelled distance-callbackAPI) and combined precision80/
17ms/reversed/ambient28 controls. Seven are ordinary actions and ten label
engineering attachments. Largest checked difference is about2.7993e-26 against
1e-8. The59 older captures pass their current contracts and numerical/hash
controls:38 whole outputs exact,16 only cache counters changed,4 only reaction
objectives/contact rows/duals changed, and1 actual chain has corrected floor
reaction/landing timing. Restoring old gravity reproduces that entire historical
chain output exactly. Old snapshots are preserved, including9748 prior result
files and14 primaryODTs. Nineteen original preimages plus3 added files reconcile
607 baseline to610 current sources; unchanged references are archived separately.

The real taut case exposed missing raw gravity in a grounded joint solve and
an invented midpoint arch between stationary normals. Both are corrected while
retaining real lift and whole-interval distance certification. Before/after
observations, explicit interrupts, the large-ratio reader assertion and the
wrong-team heavy fixture remain labelled evidence. The author's pause preserved
the interrupted suite; the resumed full run uses unchanged inputs and reuses
12 already completed prior-link controls. The400ms taut case completes but
needs845 planned steps/859 frames and minutes of compute: performance and
rational growth remain explicit concerns. No universal temporal/energy or
convergence claim is made. [Evidence and audit](results/linked-climb/README.md).

**Next:** current cross-kit interaction matrix, stale descriptive roster metadata,
then reproducible5v5 varied starts and simple deterministic policies. Advanced
NPCs, mass experiments and balancing automation remain deferred. Overall Goal
is incomplete; this checkpoint does not claim universal interaction coverage.

## Verified checkpoint — active grapple and distance turns

2026-11-13. **Goal active/incomplete. Previous goal turn: progress.** Native
turns now compose with active reference-space grapples and moving/fixed distance
limits. World-space rigid offsets, frozen charge motors, independent holding
work, summed-stat knocks and the single saved reference writer remain. Resting
planes retire at actual angular contact departure, even on slack leases; real
impacts preserve their shared pre-response motion. No character data or creative
ability changes. Delegated rules: [ANGULAR_LINKS.md](ANGULAR_LINKS.md).

All **3320 methods pass in 1073.145 s**, four isolated workers with exact
once-only disjoint coverage, no failures/errors/skips and 487 matching pre/post
tested-file hashes. Twenty added methods and four existing obstruction checks
pass together in 217.109 s. Unchanged review checks pass 4/4 in 4.002 s and
7/7 in 7.984 s. The full suite includes historical fixtures; its size does not
claim universal current-rule interaction coverage.

Twelve complete captures reproduce from frozen inputs, with whole-output hash
controls (eight CLI, four labelled callback API probes) and precision 80/17 ms/
reversed/ambient 28 comparisons. Seven are ordinary character casts and five
label engineering attachments/velocities. Largest checked difference is about
2.9474E-26, below 1e-8. All 47 previous captures remain exact with controls.
All 9534 older result files/fourteen primary ODTs retain hashes. Sixteen changed
originals, one unchanged recovered example and four additions reconcile 603
baseline to 607 current sources. Old data, tests and scenarios remain unchanged.

The isolated contact-cache comparison reproduces a suppressed second real wall
impact without departure clipping; the corrected integration records both.
The actual hook control also exposed precision-dependent Get Up beside a wall:
clearance omitted the existing native stationary-face resolution, blocking
recovery at precision 50 while precision 80 paid about9.26864 more dyspnea and
recovered. The caller now supplies that existing policy; matching recovery and
completion pass while real obstruction still blocks. Draft fixtures, interrupted
verification records and exact before-fix outputs remain separate from final
evidence. An accidentally reused demonstration filename was restored byte-for-
byte; the new example is scenarios/turning_held_victim_wall.json.
[Evidence, read-only audit and handoff](results/angular-links/README.md).

**Next:** prescribed angular/linked climbing, then the current cross-kit matrix
and reproducible 5v5 experiments. Existing pure path composition and climb
compatibility checks already supply the reference backend; inspect actual
consumers rather than inventing another integrator. Advanced NPC, mass
simulations and balancing automation remain deferred. Overall Goal incomplete.

## Verified checkpoint — angular static and living support

2026-11-13. **Goal active/incomplete. Previous goal turn: progress.**
Native turns now use finite, raised and living support through pure composition
against candidate BodyPathPieces. Positive-area/vertical-band witnesses,
alternate parents, one translation writer, gravity and landing/life obligations
remain. Shared interval primitives are extracted from fields without changing
their forward-cell behavior. Support retains its actual initial witness and
normalizes confirmed departure at the absolute owned clock. Delegated decisions
are in [ANGULAR_SUPPORT.md](ANGULAR_SUPPORT.md). No character/ability data changed.

All **3300 methods pass in 1042.127 s**, four isolated processes with exact
once-only disjoint coverage, no failures/errors/skips and 484 matching pre/post
tested file hashes. Thirty-eight added methods and one promoted obsolete guard
exercise all six scales, rotation-only static/head-support loss, both turning
bodies, co-falling gravity, alternate tops, climb/walk/turn, expiry, crouch and
actual sheet return/underside/edge contacts. The 39 focused checks pass in
301.822 s. Review checks pass 4/4 in 4.394 s and 7/7 in 9.591 s.

Twelve complete API/CLI/hash seed4421 and combined precision80/17ms/reversed/
ambient28 captures reproduce from frozen inputs: two ordinary movement/climb
encounters and ten explicitly labelled initial-placement/velocity probes,
including a turning fall onto a raised solid. Largest checked difference is
about 2.262E-26, below 1e-8. All 35 prior field/owned/native/fixed-heading captures
remain exact with controls. All 9386 older result files/fourteen primary ODTs
retain hashes. Nineteen changed originals and one unchanged reference are
archived; six added domain files reconcile 597 baseline to 603 current sources.
Old data/scenarios and every other old test method remain unchanged.

The expanded co-falling world stalled in independent swept collision bounds;
its exact process was interrupted and exited130, with trace/source retained.
Relative reference bounds and signed vertical face differences now cancel common
motion/pose. A labelled old/new geometry query exhausts256 nodes before and
rejects correctly in about0.0032 s after; the actual co-falling world passes.
An outgoing floor graze also reproduced two false impacts/landings. Applying the
existing separating-edge rule with actual angular derivatives corrects it;
the same input now produces none, while real inward corners still collide.
The first approximate grazing angle had tiny inward motion; both fixtures are
retained distinctly. A diagnostic draft used the default time tolerance; its
final comparison uses the native1e-28 s setting. These retained draft issues do
not replace the final current tests. [Evidence and handoff](results/angular-support/README.md).

**Next:** active grapple/tether response and prescribed angular/linked climbing,
then final cross-kit and reproducible5v5 evidence. Distance endpoints currently
use actor references/static anchors, and rigid-group reference offsets stay in
world space; do not invent a missing hand-curve or reference-integration blocker.
Advanced NPC, mass experiments and balancing remain deferred. Overall Goal is
incomplete.

## Verified checkpoint — angular field membership and cover

2026-11-13. **Goal active/incomplete. Previous goal turn: progress.**
Heat/beam cover, cooldown columns, spherical gas and electrical fences now
consume actual saved yaw/translation/pose paths through shared interval and
derivative bounds. Fixed-heading polynomial branches and existing exposure,
work, binding, damage and source/recipient-life writers remain. Only field and
contact-field turn guards are removed. No character/ability data changed.
Delegated engineering decisions are in [TURNING_FIELDS.md](TURNING_FIELDS.md).

All **3262 methods pass in 972.101 s**, four isolated processes with exact
once-only coverage, no failures/errors/skips and 479 matching pre/post tested
file hashes. Twenty-five added methods and one promoted obsolete guard cover
geometry, actual field edge/cover changes, one fence binding/turn interruption,
real grenade gas, source death, overlapping pause fields, walking and crouching.
The 26 focused checks pass in 183.187 s; review checks pass 4/4 in 4.556 s and
7/7 in 9.003 s. Seven ordinary complete API/CLI/hash seed4409 and combined
precision80/17ms/reversed/ambient28 captures reproduce from frozen inputs.
Largest checked difference is about 1.491E-25, below 1e-8. Comparisons include
field transitions, heat/toxin memory and cooldown work, lives and HP accounting.
All 28 preceding owned/native/fixed-heading captures remain exact with controls.
All 9276 old result files/fourteen ODTs retain hashes. Fourteen archived changed
originals and five added domain files reconcile 592 baseline to 597 current
source files. Old character data/scenarios and all other test methods remain.

Two initial failures were fixture placements: the actual pause radius is 8 m,
and grenade gas centres on the real collision. A subsequent real overlap error
occurred when cooldown reconciliation queued an immediate decision, shortening
the saved lease before the next volume query. Clipping to the current prefix
and handing back to the queued phase corrects it. A labelled isolated reader
comparison reproduces the archived failure and completes the same ordinary
overlap cast after correction. Draft sources/logs remain. Independent static
predicates also agree at 1547 rational points across 91 certified intervals;
these supplement the continuous bounds, not replace them. Evidence and a
concrete support handoff are in [results/turning-fields](results/turning-fields/README.md).

**Next:** angular finite/raised/body support and active grapple/tether response,
prescribed linked climbing, final cross-kit and reproducible 5v5. Support
prediction runs during saved-prefix construction; compose against the candidate
piece rather than recursively calling body_paths.ensure(). Advanced NPC, mass
simulation and balancing work remain deferred. Overall Goal remains incomplete.

## Verified checkpoint — angular owned body-part contacts

2026-11-13. **Goal active/incomplete. Previous goal turn: progress.**
Current owned-volume users are 3E5's charge-grab and descending foot kick;
component melee frame attacks use their existing separate delivery. Controlled
body-part volumes now follow live owner heading, including after a turn ends,
without rewriting their creation snapshot. Source and target sweeps reuse the
same saved reference prefix and angular bounds; fractional anchors include
centre and size derivatives. The blanket owned-volume turn guard is removed.
Other angular field/support/link guards remain. No ability data changed.

Seventeen new tests and twelve existing attachment/plane checks pass in
94.233 s. Real charge-wall fracture, rotated contact timing, source/target/both
turning kicks, one-time downward knock/payment, actual missed-kick landing,
live post-turn rearm and turn-before-grab/holding continuation pass. All
**3237 methods pass in 879.184 s**, four isolated processes with exact once-only
coverage, no failures/errors/skips and 475 matching pre/post tested file hashes.
Review checks pass 4/4 in 4.211 s and 7/7 in 8.345 s. Four ordinary complete
API/CLI/hash seed4399 and precision80/17ms/reversed/ambient28 captures reproduce
from frozen inputs; largest difference is about 1.797E-26, below 1e-8. The six
preceding native turn and eighteen fixed-heading captures remain exact with
controls. All 9196 older result files/fourteen ODTs retain hashes. Nine archived
changed originals and three added domain files reconcile 589 baseline files to
592 current source files. Old character data, tests and scenarios are unchanged.

The first test draft had fixture errors: missing precision on a minimal world,
using a historical rules fixture for a current-world inspection, an incorrect
10 ms expectation for a measured 2.828 ms contact shift, and expecting a body
contact cancellation where the actual kick applies a function restriction.
Original draft source/log remain. No production correction was needed for those
fixture changes. Current work is preserved in results/turn-owned-contacts/.

**Next after verification:** angular field/cover membership and support, then
active linked response and prescribed linked climbing, followed by final
cross-kit/5v5 evidence. Advanced NPC/mass/balancing work remains deferred.

## Verified checkpoint — initial native whole-body turns

2026-11-13. **Goal active and incomplete. Previous goal turn: progress.**
The author pause/resumption preserved the 3194-method checkpoint. Native timed
turns now execute in the shared engine for all six characters within the
[initial free-body scope](NATIVE_TURNING.md). Heading has separate ownership;
actual walk/turn, gunfire, Block, wall/body impact and fatal interruption work.
Source speed is sampled once at Active start; movement stays on its world
direction. These are delegated decisions. No character/ability data changed.

All 26 new native tests pass in 32.392 s. Six ordinary complete captures pass
CLI/hash seed4393 and combined precision80/17ms/reversed/ambient28 controls.
All **3220 methods pass in 854.181 s**, four isolated processes with exact
once-only coverage and no failures/errors/skips. All 473 tested file hashes
match before/after. Review checks pass 4/4 and 7/7. All six native encounters
reproduce from frozen inputs, including final heading, collision status/normals,
source/life and HP accounting. Largest checked difference is about 6.106E-26,
below 1e-8. All 18 preceding complete combat captures and eight angular examples
remain exact with their controls. All 9092 older result files/fourteen primary
ODTs retain hashes; 16 archived changed originals and five added domain files
reconcile 584 baseline to 589 current source files. Old tests/data/scenarios are
unchanged. A missing earlier replay process was confirmed terminal; its partial
log is retained, and the complete read-only replay then passed.

Two diagnosed geometric/timeline defects were corrected: separate vertical
acceleration bounds invented foot/floor crossings; a separating turn repeatedly
nominated a rejected zero-time overlap. Exact signed vertical coefficients and
an inner entry band preserve the actual foot and allow the clock to progress.
Angular impact uses actual contact-point velocity for statuses and original
root velocity for projection, avoiding invented translation. Source preimages,
draft failures and current checks are in [the new package](results/native-turning/README.md).

Correction to the earlier handoff: the actual persistent-distance planner is
already certified quadratic and returns BodyPathPiece. A dense-reference adapter
was not a current blocker. Angular constrained response remains unfinished for
its own unmigrated planes/contacts, rather than reference representation.

**Next:** migrate angular field/cover membership, finite/raised/body support,
owned melee paths and grapple/tether response; remove their explicit temporary
guards with real interactions. Native turning is not complete across all kits.
Prescribed linked climbing, final cross-kit coverage and reproducible 5v5 remain.
Advanced NPCs, mass experiments and balancing automation are deferred.

## Verified checkpoint — continuous angular query paths

2026-11-13. **Goal active and incomplete. Previous goal turn: progress.**
Read AGENTS.md, this progress ledger, the current review response and relevant
orientation/path/contact sources. The November 10 corrections remain verified.
The next [angular query backend](ANGULAR_PATHS.md) now composes anchored yaw,
quadratic local pose/size and the existing saved reference piece. It provides
point derivatives/error bounds, conservative continuous enclosures and actual
box/curved-projectile queries. It introduces no second body writer or native
turn command. Fixed-heading actors and character data retain their contracts.

The 52 new methods plus 13 existing curved-contact checks pass in 3.890 s;
116 affected existing checks pass in 0.813 s. The unchanged review specifications
pass 4/4 and 7/7. Eight explicitly labelled geometry examples pass complete
hash seed4391, precision80, reversed query order/box participants and ambient
precision6 controls, largest difference about 4.965E-49 below 1e-9.
All **3194 methods pass in 957.233 s**, four isolated processes with exact
once-only coverage and no failures/errors/skips. All 469 tested file hashes
match before/after. All 18 preceding native combat captures reproduce exactly
with their complete API/CLI/hash/numerical controls. An additional 721 rational
angles agree with the independent precision100 frame selector within the
claimed coefficient errors. All 9037 older result files and fourteen primary
ODTs are unchanged. Five archived changed originals and six added domain files
reconcile the 578-file baseline to 584 current source files. All character
data, old tests/scenarios and old fixed-shape query branches remain unchanged.

The draft exposed a public-cache validation bug: unhashable inputs raised before
normalization, and cache hits could bypass numeric type checks. Validation now
precedes private caching, with regression coverage. The draft also had three
fixture errors (JSON tuple/list equality, a finite-width enclosure treated as
its zero-width limit, and two paths that did not actually meet); corrected
fixtures retain the intended tests. Draft sources/logs remain in the new
[evidence package](results/angular-paths/README.md).

**Next:** connect turn ownership and angular prediction to the common saved
translation prefix, including dense constrained references, actual contact
features/response, support changes and live/released geometry. Native timed
turning, prescribed linked climbing and final cross-kit/5v5 verification remain
unfinished. No advanced NPC, mass experiments or balance automation was added.
This session ends at a verified geometry checkpoint with the concrete native
integration handoff preserved; it does not complete the overall Goal.

## Verified checkpoint — fixed initial actor headings

2026-11-13. **Goal active and incomplete. Previous goal turn: progress.**
[Fixed initial headings](ACTOR_FACING.md) now work through the actual shared
pose/hand/Recovery, Block, owned attacks, heading-dependent movement/delivery,
dynamic body planes and implicit fence consumers. All six source scales retain
local dimensions. Explicit world movement/fence axes and legacy cardinal
inputs retain their contracts. Timed turning is still unfinished.
[Evidence](results/actor-facing/README.md).

All **3142 methods pass in 952.210 s**, four isolated processes with exact
once-only coverage, no failures/errors/skips and 464 matching pre/post tested
file hashes. The 76 focused checks pass in 76.281 s, including 37 added methods;
46 existing geometry/context checks pass. Four November 10 review checks pass
in 4.078 s and seven November 3 checks in 8.095 s.

Eighteen complete current captures pass: fifteen ordinary movement/casts, one
labelled support placement and two labelled external-loss/restoration APIs.
Sixteen CLI/hash and two API-subprocess hash seed 4373 comparisons pass, with
precision80/17 ms/reversed/ambient28 controls and frozen-input reproduction.
Largest checked difference is about 3.280E-43, tolerance1e-8. Character HP/
healing/lives, source identity, material HP and labelled external losses are
accounted for. All eighteen preceding material/owned captures remain exact
with their controls. All 8845 older result files and fourteen ODTs retain
hashes. Twenty-nine archived changed originals, one unchanged reference and
five added domain files reconcile the 573-file baseline to 578 current files.
All character data/old scenarios remain exact; only two obsolete admission-
guard methods are promoted, with all other old methods/imports unchanged.

The lifecycle audit reproduced and corrected a false AABB corner rejection.
It then reproduced a second defect: the solid SAT pass repeated the finite
sheet check, rejecting valid 1e-30 m floor-contact roundoff only for rotated
bodies. Spatial preflight now owns that sheet band once, while real crossing
still rejects atomically. Before/after evidence, failed logs/methods and final
passing source pins remain. Separate fixture-only mistakes are documented.

**Next:** continuous angular prediction and owned timed turning with the
author's rate. Include rotating part/hand velocities, actual contact response,
support changes and live versus frozen/released geometry; preserve one
translation writer. Fixed frames are not an angular sweep.
[Implementation handoff](results/actor-facing/NEXT.md). Prescribed linked
climbing and final current cross-kit/reproducible 5v5 remain. Advanced NPC,
mass experiments and balancing automation are deferred. The old optional
periodic stack-dump exit139 remains unresolved. The overall Goal is unfinished.

## Verified checkpoint — native fixed oriented materials

2026-11-13. **Goal active and incomplete.** Previous goal turn preserved a
paused handoff; resumption made **progress**. [Fixed oriented materials](ORIENTED_WORLD.md)
now use native support/departure, actual collision normals/retained static
planes, occupancy, curved projectiles, cover/fields, terrain anchors and ordinary
climbing. Actual owned charge-hand, falling-kick and slash deliveries also
compose. Enclosing AABBs remain broad bounds. Actor facing stays +x/−x;
continuous angular motion and timed body turning are unfinished.
[Evidence](results/oriented-world/README.md).

All **3105 methods pass in 931.219 s**, four isolated processes with exact
once-only coverage and no failures/errors/skips. All 460 tested files retain
pre/post hashes. The corrected 36-method focused run passes in 22.452 s;
89 affected existing geometry checks pass. Four current-review specifications
pass in 4.058 s and seven earlier review regressions in 8.053 s.

Eighteen complete captures comprise thirteen ordinary movement/casts, four
labelled initial-condition cases and one labelled geometry/anchor API case.
Seventeen complete CLI/hash and one API-subprocess hash seed 4357 comparisons
pass. Precision 80/17 ms/reversed/ambient 28 controls retain event outcomes,
boundaries, character/material accounting and lifetimes; largest checked
difference is about 2.585E-26, tolerance 1e-8. All reproduce from frozen inputs.
Twelve previous complete current captures reproduce exactly with their controls.
All 8648 older result files and fourteen ODTs are unchanged. Nineteen archived
changed originals, two unchanged reference copies and five new domain files
reconcile the 568-file baseline to 573 current files. Character data, old
scenarios and old tests remain exact except one promoted registry-guard method.

The first 3103-method full run passed, then an additional real charge capture
exposed a rational/Decimal contact-tolerance TypeError. The tolerance now
converts exactly to the rational comparison domain. Two regression methods
prove the metric band and native hand fracture. The complete first run,
faulty module and failures remain; the final corrected full run has frozen
sources. Earlier fixture-only cover/event assertions are separately preserved.

**Next:** carry the common actor yaw frame through pose/hand/heading consumers,
owned source volumes and dynamic body planes, then add continuous angular
prediction and owned timed turns with one translation writer. The material
reshape API is discrete, not angular motion. [Concrete migration sites](results/oriented-world/NEXT.md).
Prescribed linked climbing and final current cross-kit/reproducible 5v5 remain.
Advanced NPC, mass experiments and balancing automation are deferred. The old
optional periodic stack-dump exit139 remains unresolved. This checkpoint does
not complete the overall Goal.

## Verified prerequisite — upright orientation and true box queries

2026-11-13. **Goal active and incomplete.** Previous goal turn: **progress**.
[Oriented geometry](ORIENTED_GEOMETRY.md) now supplies exact rational unit yaw
frames, point/vector transforms, real oriented-box membership/overlap and the
existing projectile/body contact APIs for fixed orientation. The enclosing AABB
is used only as a broad bound. Original axis-aligned branches remain intact.
[Evidence](results/oriented-geometry/README.md).

All **3069 methods pass in 936.224 s**, four isolated processes with exact
once-only coverage and no failures/errors/skips. All 456 tested files retain
pre/post hashes. The 93-method focused run passes in 0.417 s, including 58
new contracts: fourteen frame, twenty shape and twenty-four contact checks.
Independent rational atan bounds and polygon clipping, all six source body
scales, quadratic/resizing contacts, true corner misses and finite-sheet
contacts pass. Four current-review checks pass in 4.038 s; seven earlier
review regressions pass in 7.972 s.

Six labelled geometry API examples pass precision 80 and complete hash seed 4337
controls; largest checked difference is about 9.855E-43, tolerance 1e-38.
These are fixed-frame queries, not executed shared-world turns. All twelve
complete frozen current combat captures reproduce exactly, including their
API/CLI/hash and numerical controls. All 8591 older result files and fourteen
primary ODTs are unchanged. Existing tests/scenarios and all six character
definitions remain exact; only turn.json's obsolete author-waiting metadata
changes. Numeric timing is unchanged. Six archived originals and six new
domain files reconcile the 562-file baseline with the 568-file current manifest.

The query example's first draft assumed uniform 1E5 scaling when calculating
head contact. Its actual horizontal/vertical scales differ. The expected
analytic entry now uses the declared local head width; the failed log and
initial script remain. Runtime/test/data/scenario files stayed fixed throughout
the complete passing regression.

**Next concrete engine work:** migrate pose/hand and heading consumers,
support footprints, actual contact normals, occupancy/cover/field queries and
constraint planes to the new shapes. Keep actor/world admission guarded until
those paths are coherent. Then add continuous angular prediction and owned
turn control using the author's timing, retaining one translation writer.
No instantaneous end flip or time-sampled stationary-body approximation
establishes a turn. Speed sampling and steering belong to implementation under
the author delegation; no routine clarification is held for the author.
Prescribed linked climbing, the compact cross-kit matrix and reproducible 5v5
remain. Advanced NPC, mass simulation and balancing automation are deferred.
The older optional periodic stack-dump exit139 is unresolved. This prerequisite
does not complete the overall Goal or establish shared-world turning.

## Verified checkpoint — finite ground and open-edge flight

2026-11-13. **Goal active and incomplete.** Previous goal turn: **progress**.
The November 10 review corrections remain verified. The next shared geometry
gap is now closed: current `finite_faces_v2` uses actual finite-sheet body
contacts and existing saved support-loss/flight, replacing the infinite floor
shortcut. Ordinary walking/running and real midair gunfire reach the horizon;
heavy knock, owned grab/drag and rigid/tether links compose with departure.
[Rules](FINITE_GROUND.md) · [Evidence](results/finite-ground/README.md).

The author's floor remains 500 × 500 m with open sides/top. Delegated edge/
underside contacts require actual sheet intersection; no walls, floor thickness,
abyss death or fall HP damage are added. New occupancy crossing the sheet is
rejected atomically; outside and wholly below-floor motion remain valid.
Any actual underside can support, including a torso with the legs past an edge.
Historical `static_faces_v1` and older inputs retain their original floor guard.

All **3011 methods pass in 783.208 s**, four isolated processes
(753/753/753/752 methods),
exact once-only coverage and no failures/errors/skips. All 451 tested files
retain pre/post hashes. The 94-method focused subset, including all 35 new
methods, passes in 125.194 s; four November 10
review specifications pass in 4.118 s and seven November 3 regressions in
8.150 s. Existing tests and all six character definitions are unchanged.

Twelve complete captures comprise three ordinary casts, eight labelled
engineering setups with real motion/casts, and one labelled tether API probe.
API/CLI or API-subprocess hash seed 4309 and combined precision 80/17 ms/reversed/
ambient precision 28 controls pass. Largest checked final/boundary difference is
1.492E-30, below 1e-8. Eight complete frozen previous-mode traces remain exact.
All 8294 older result files and fourteen primary ODTs remain unchanged. The
558-file starting manifest, thirteen archived originals and four new domain
files reconcile to the 562-file current manifest.

Early unit failures were assertion/fixture mistakes: a rejected intervention is a
recorded result, impact instability legitimately changes body-reference height,
and a later torso landing after feet lose support is a real contact. The failed
logs and initial test source remain. The first full regression then exposed a
real contact-cache defect at pose support-envelope switches, also reproduced
on raised solids. Current-mode contacts now revalidate actual one-sided pose
geometry before effects. Four isolated archived-method before/after cases
restore native fall/Get Up, with precision 80 controls. The failed/interrupted
regression and hashes of all 451 tested files remain. No tested runtime/data/test/
scenario changed during the complete passing run.

**Next concrete step:** introduce reusable orientation/rotated-body geometry
with exact narrow-phase queries before wiring the author's timed whole-body
turn. Preserve independent world motion, hand transforms, support and action
ownership; do not substitute enlarged axis-aligned hitboxes for rotation. Then
resolve prescribed linked climbing as needed and run the compact current
cross-kit matrix and reproducible 5v5 with varied starts/simple policies.
Advanced NPC and balancing automation remain deferred. The older optional
periodic stack-dump exit139 is unresolved; this increment makes no fix claim.
This is a bounded verified checkpoint, not completion of the overall Goal.

## Verified review corrections — 2026-11-10

The author requested implementation after the pause. Previous implementation
turn made progress; the overall Goal remains unfinished. R1/R2/R3 and the
grenade cover-contract note are now resolved within the selected scope.
[Response](PRINCIPAL_ENGINEERING_REVIEW_2026-11-10_RESPONSE.md) ·
[Evidence](results/principal-fixes-2026-11-10/README.md).

Static top faces use the same positive-area contact band as living bodies.
Actual partial support, alternate tops and pose withdrawal feed the existing
saved prefix and common support-loss/flight transaction. Position/velocity,
independent motors/forces, grapples/tethers and earned landing effects remain.
Ordinary climb/walk/run, real midair gunfire, all six scales, actual heavy knock
and owned grab/drag pass. An actual torso landing on a narrow post verifies
the touching-part depth while the legs hang beside it. Outer-floor departure
retains its separate explicit guard. [Rules](SUPPORT_DEPARTURE.md).

The common constructor owns declared precision/rounding during all loading and
subclass hooks, restoring caller precision, traps and flags on success/failure.
Seven new contracts and 18 complete caller-context/entry-point comparisons pass;
the supplied release is consistently 121 ms, with exact CLI/hash parity. The
capability table now lists delivered portals/leaps/kick/launcher accurately.
The grenade O/U pulse explicitly uses world cover; its gas stays unoccluded.

All **2976 methods pass in 886.083 s**, four isolated processes with exact
once-only coverage and no failures/errors/skips. All 448 tested files match
pre/post hashes. The 33 new methods pass in 76.193 s, 75 affected existing checks
in 8.845 s, all four new-review specifications in 4.177 s, and all seven
November 3 regressions in 8.494 s. No existing test or character data changed.

Fifteen complete interaction captures pass API/CLI or API-subprocess hash 4297
and precision80/17 ms/reversed/ambient28 controls: five ordinary casts, nine
labelled engineering-setup cases with real casts/movement, and one tether API
probe. The torso/post case adds two precision controls. Largest checked final/
boundary difference is 2.9582283945787942997783248974514272444658047334E-30, tolerance1e-8. Eight selected complete frozen
older traces remain exact. All 8113 older result files and fourteen primary
ODTs remain unchanged; 550 starting files, 23 archived originals and eight new
runtime/test/scenario/doc files are accounted for by the 558-file manifest.

The first terrain draft's lease-clock mismatch is fixed by one canonical
representable boundary; its source and failed logs remain. Root-enclosure,
striker-facing, hold-expiry, metric-attribution and post-placement fixture
diagnoses are preserved without treating them as production failures. No
runtime/data/test/scenario changed during or after the complete passing run.

**Next:** general facing/turning, outer-floor departure and prescribed linked
climbing as needed, followed by a compact current cross-kit matrix and
reproducible 5v5 with varied starts/simple deterministic policies. Advanced NPC,
mass simulation and balancing automation remain deferred. The older optional
stack-dump exit139 remains unresolved. This verified correction checkpoint
does not complete the overall Goal.

## Independent principal-engineer review — completed

2026-11-10. [Final actionable review](PRINCIPAL_ENGINEERING_REVIEW_2026-11-10.md)
and [evidence/reproduction](results/principal-review-2026-11-10/README.md) are complete.
Resumption confirmed the 549-file reviewed inventory and implementation were
unchanged; only the review's earlier continuity entry differed. No implementation,
character data, permanent tests, primary sources or older results were modified.
This completes the independent review, not the overall implementation Goal.

Prioritized results: **R1/P1**, reproduced known raised-support departure gap
(ordinary climb-then-walk aborts the public API and CLI); **R2/P2**, new verified
direct-constructor Decimal-context defect (same declared precision/input changes
shot release/contact by 1 ms and final HP; public runner/CLI unaffected);
**R3/P3**, stale current capability rows still list delivered leaps/kick/portals
as unfinished. Grenade O/U versus gas cover policy is separately identified as
an ambiguous design contract, not a proven gameplay bug. Coordinator complexity
is a qualified architectural risk. The report gives correction sites and
acceptance criteria without changing mechanics or creative features.

Verified evidence remains **2943 existing methods passing in 748.094 s** across
four isolated processes with exact disjoint coverage, seven previous-review
regressions passing, and twelve bounded current-rule cross-kit runs passing the
specified outcome/HP-conservation comparisons. Four new review specifications
retain two passing controls, one R2 failure and one R1 error. The unchanged
implementation made another full-suite run unnecessary on resumption.

**Implementation handoff:** retain raised-support departure as the next major
engine task; fix constructor context ownership independently, reconcile the
current status table and make grenade status-cover policy explicit. Then finish
shared facing/turning and affected interaction coverage before reproducible 5v5.
Advanced NPC systems and balance optimization remain deferred.

## Independent principal-engineer review — paused checkpoint

2026-11-10. Paused at the author's request; the final review is not yet written.
No implementation, character data, permanent tests, primary documents or older
results were changed. [Durable review handoff](results/principal-review-2026-11-10/REVIEW_HANDOFF.md)
records the findings, evidence and next steps. The implementation Goal's status
was not changed by this review.

The current **2943-method suite passes in 748.094 s**, with exact disjoint
coverage across four isolated processes. All seven November 3 review regressions
pass. Twelve bounded current-rule cross-kit runs pass their numerical/discrete
outcome and HP-conservation comparisons. All 549 reviewed source/doc/primary
files matched their starting hashes immediately before this continuity entry.

Verified findings to carry forward: ordinary climb-then-walk aborts at the known
raised-support departure guard; direct `SharedEncounter` construction can round
initial state under the caller's Decimal context despite declared precision 50,
changing a shot from 121 ms to 120 ms and changing final HP. The public runner and
CLI protect initialization and are unaffected by the latter defect. Separate
notes cover ambiguous grenade O/U cover policy and stale capability-table rows;
these must not be presented as newly proven gameplay defects. No fixes were made.

**Resume:** compare the saved source manifest with any intervening development,
revalidate affected findings, then finish the prioritized actionable review and
evidence README. The handoff preserves reproduction commands and correction
criteria; no full-suite rerun is needed unless the reviewed implementation changes.

## Verified checkpoint — actual 1E1 Ultimate launcher

2026-11-10. **Goal active and incomplete.** Previous goal turn: **progress**.
The preceding 544-file checkpoint, 7742 older result files and fourteen primary
ODTs were revalidated. Twenty-three changed originals are archived; five
runtime/test/scenario/doc files are new. All original 1E1 abilities, numerical
timings, stats and hands remain; all five other characters are exact. One old
test's projectile-profile count changes 11 → 12; its distance checks are retained.

The complete **2943-method suite passes in 753.112s** across four isolated
processes, exact disjoint once-only coverage and no failures/errors/skips.
All 442 tested files retain their pre-run hashes. Thirty-nine new methods cover
nine inventory/effort checks and thirty actual shared launcher interactions.
The final 103-method affected subset passes in 66.020 s; 51 focused checks also
pass in 64.939 s, and 82 earlier compatibility checks pass in 101.254 s.

[The actual launcher](LAUNCHER.md) now uses owned 400 ms/Db2.5 equip, per-actor
ten-round inventory, ability 1 variant selection, G140/A180/Db3.5/60 m/s firing,
1150 ms firing cooldown and first-collision poison (5 m, 8 s, Tp1200) poison. Each action and
released projectile retains its definition through swaps, copying and source
death/restoration. Empty stock returns through the same paid swap; ready
Ultimate can replace it directly. The old 300 ms controlled runner remains exact.
Chemical payload and zero instantaneous carrier power are separate; source
intrinsic firing classification does not invent instability-dependent chemistry.

Twenty-four complete ordinary API/CLI/hash-seed 4271 casts and five separately
labelled API probes pass combined precision 80/17 ms/reversed/ambient precision 28 controls
and fresh immutable reproduction. Block, materials, friendly/self damage,
independent leap/beam, pause fields, copying, old Qard/last grenade through swap,
control cancellation, source lives and actual earned 2E4 revival compose.
Largest checked final difference is 2.394203714141514792343998788088389195929145189761813489975666488117E-10, tolerance 1e-8.
All 227 selected historical traces were checked: **226 are complete exact**;
**1 differ only in corrected 3E5 wall-slam receipt kind**, contact → blunt.
Their HP, timing and every other field are exact; original evidence is intact.

Initial full regression completed 2943 methods with one standalone-journal API
error and one obsolete profile-count failure. Its source pins, receipts and
original test remain archived. Profile-only journal support is restored while
shared receipts use actual released variants/components. Draft payment/fixture
diagnoses and ready-stock before/after proof remain. Exact swept-box sphere
rejection preserves a complete 66.6 s workload (observed 28.045 → 6.276 s; fresh
29.488 → 6.614 s); these are observations, not universal speed guarantees.
Current manifests pin 549 source/doc/primary files and all new evidence.
The older optional periodic stack-dump exit 139 remains unresolved; this
increment makes no fix claim for it. [Evidence/reproduction](results/1e1-launcher/README.md).

**Next concrete implementation:** raised-support edge departure through existing
saved paths/support-loss/flight, retaining real contact, linked groups, landing
debt and life rules. Then general facing/turning and a compact cross-kit/current
boundary matrix before reproducible 5v5. All roster creative abilities now have
shared delivery within documented boundaries; this does not verify arbitrary
encounters or complete the Goal. Advanced NPC, mass simulation and balancing
automation remain deferred. This is a bounded verified checkpoint.

## Verified checkpoint — shared poisonous volumes

2026-11-10. **Goal active and incomplete.** Previous goal turn: **progress**.
All 542 paused source/doc files, 7540 older result files and fourteen primary
ODTs were revalidated before resuming. Paused drafts/handoff remain archived.
The preceding verified baseline has 539 files; eleven changed originals are
archived and five runtime/test/doc files are new. No existing test changed.
All six character definitions, stats, abilities, timings and hands are unchanged.

The complete **2904-method suite passes in 899.088 s** across four isolated
processes, exact disjoint once-only coverage, no failures/errors/skips and 438
unchanged tested files. Forty-two new methods comprise twelve sphere-geometry
and thirty shared gas/API checks; their focused run passes in 19.630 s.
Seventy-six existing venom/healing/heat interactions pass in 66.608 s.

Released spherical gas now shares actual body motion/pose, event boundaries,
live toxin defenses, immutable applied-HP history, continuous healing, death
and recipient lives. Shield absorption and armor do not receive gas damage;
2E4's explicit shield-stock toxin resistance remains live. Exposure/residual
uses analytic affine-root doses or existing dense integration for changing
defenses. Independent scalar quadrature and closed-form checks agree under
beam-drained shields, delayed shield regeneration and constant defenses.

POISON_VOLUMES.md separates author facts from delegated 3D unoccluded organic
membership, net-load re-entry, zero output and independent recipient-life
episodes. Source death/restoration leaves released clouds attributed to their
old source life; recipient death retires old toxin and revival starts at zero.
Actual 2E4 thrust/healing delays gas death and funds its real two-second revival.
These are labelled released-volume API probes, **not actual launcher casts**.
The historical controlled grenade runner retains its old 300 ms equip timing;
the current source's 400 ms swap remains to be delivered with the real launcher.

Two draft defects have archived/current causal proof: validation consumed an
iterable centre before geometry used it, and re-entry exactly at zero load
reused the expired episode if a due phase reconciled before timer dispatch.
The iterator is retained once, and physical expiry decides a fresh episode.
Initial fixture mistakes (rational data conversion, jump metric name and the
disabled-healing control's absent history) remain archived with their fixes.

Twenty-four complete labelled API/hash-seed4241 cases pass combined precision80,
17 ms sampling, reversed participants and ambient28 controls, with fresh
immutable reproduction. Largest final difference is 2.006782894506314423333890567103573868177658267938363463687453908258E-10, tolerance1e-8.
Eight ordinary API/CLI/hash/current-default parity cases also reproduce: seven
existing shared scenarios and one historical controlled grenade run. All 195
selected prior complete traces are exact. Current manifests pin 544 source/doc/
primary files and this evidence. The older optional stack-dump diagnostic from
the leap checkpoint remains unresolved; this work makes no fix claim for it.
[Evidence and reproduction](results/poison-volumes/README.md).

**Next concrete implementation:** actual existing 1E1 Ultimate weapon swap,
ability-1 mode selection, ten-round ammunition and released impact grenades
using this poison foundation. Then finish shared interactions/boundaries and
verify reproducible 5v5. Advanced NPC, mass simulation and balance automation
remain deferred. This bounded checkpoint does not complete the overall Goal.

## Verified checkpoint — existing leaps and controlled falling kick

2026-11-09. **Goal active and incomplete.** Previous goal turn: **progress**.
The 533-file portal checkpoint was revalidated before editing. All 7330 older
result files and fourteen primary ODTs remain unchanged. Fifteen changed
originals are archived; six runtime/test/scenario/doc files are new. No existing
test changed. Only existing 1E1/3 and 3E5/3 were imported; all other abilities,
stats, numeric timings and hands retain their preceding values.

The complete **2862-method suite passes in 706.069 s**, with exact once-only
coverage across four isolated processes, no failures/errors/skips and 434
unchanged tested files. The 36 new methods comprise seven fractional-contact
geometry checks and 29 actual leap/API interactions. Their final focused run
passes in 216.386 s; 61 existing compatibility checks pass in 14.471 s.

Actual 1E1/3 and 3E5/3 retain authored total launch speeds 15/20 m/s, G140/A250,
Db3.5/3, cooldowns 9/2.85 s and takeoff/landing statuses. LEAPS.md separates
delegated forward-45-degree controls or fastest explicit feet-point arcs,
Active-start payment, independent lower-body ownership and physical flight.
3E5 retains control until actual descent and makes one first-contact foot kick
through shared intrinsic power, defenses, material HP, statuses and downward
knock. Knock down remains downward displacement; balance/Get Up are separate.
The source's omitted knock amount is delegated 15 m/500 ms, with actual
summed-stat grapple resistance. A fractional part anchor follows the feet under
pose deformation; no horizon-based contact expiry is introduced.

Twenty complete ordinary API/CLI/hash-seed4001 cases and six separately labelled
API probes pass precision80/17ms/reversed-order controls; probes also run under
ambient28. Fresh immutable reproduction passes. Both public scenarios exactly
match current-default CLI. Shields, Block, destructible tops, friendly fire,
native grapples, tethers, descent reversal, transport, independent Qard, control
loss, death and earned revival compose. All 169 selected prior complete traces
are exact. Largest final numerical difference is 9.829730095480750278892724911979755629382986963935E-31, tolerance1e-8.

Initial geometry/interface and fixture failures remain archived, including the
transport assertion that ignored a legal second leap. The first restoration
attempt was correctly blocked by positive body overlap during Get Up; ordinary
walking supplies clearance in the corrected recipe. An optional periodic stack
dump diagnostic exited 139; its cause remains unresolved. Uninstrumented native
grapple tests/captures, the full suite and a read-only reference observer all
pass. Do not present the diagnostic failure as fixed. Final manifests pin 539
current source/doc/primary files and this new evidence.
[Evidence and reproduction](results/leaps/README.md).

**Next concrete implementation:** existing 1E1 Ultimate launcher through shared
projectile delivery, ammunition/replacement ownership and persistent poison.
Then complete remaining shared interactions/boundaries and verify reproducible
5v5. Fixed facing, finite-floor and partial-raised-support boundaries remain;
advanced NPC behavior, mass simulation and balance automation remain deferred.
This is a verified bounded checkpoint; the overall Goal remains unfinished.

## Verified checkpoint — actual1E3 portals and atomic voluntary transport

2026-11-09. **Goal active and incomplete.** Previous goal turn: **progress**.
The528-file preceding checkpoint and paused drafts were revalidated before
resuming. All7093 older result files and fourteen author ODTs remain unchanged.
Seventeen changed originals are archived; five runtime/test/scenario/doc files
are new. No existing test was rewritten. Only existing1E3/3 was imported;
all other character abilities/stats/timings/hands remain unchanged.

All **2826 methods pass in 749.094s**, with exact once-only coverage across
four isolated processes, no failures/errors/skips and429 unchanged tested
files. The52 new methods comprise20 shared transport and32 actual portal/API
checks; the final87-method focused run passes in22.083s.

Actual1E3/3 now releases its authored10m/8s pair after300ms extrinsic-momentary
Active, with12s cast cooldown and no dyspnea. PORTALS.md distinguishes delegated
neutral left hand, zero unlistedGathering/selfO/U, selection cooldown, frozen
target/current-feet release, explicit0.5m allied use and per-user/pair/life2s
shared reuse work. Independent hand actions and ordinary movement compose.

Shared `prepare_transport` validates the complete destination/actual grapple
group and live distance limits before mutation. It preserves entry offset,
facing, independent motor/force inputs, pose, phase clocks, flight and owed
landing/contact effects. Actual active climb is interrupted with physical
velocity; support uses prospective group placements. Linked stacks, unlinked
rider fall, native grabs/dash/knock, heat/electrical exit, pause fields, blocked
partners, source/user death/restoration and independent pairs are exercised.
Existing finite-floor/partial-raised-support guards remain documented.

Code review found a same-clock stale-plan defect after the initial2824-method
full run passed in710.091s: attaching a tether after transport preparation did
not invalidate the plan, allowing an erroneous move and `external_separation`.
Distance topology now joins spatial dependencies. The archived/current modules
run the same operation sequence and respectively reproduce the escape/reject it
before moving or releasing the tether. New fixed/moving regressions pass; the
first complete run and its unchanged-source hashes are retained separately.
Initial fixture failures (Decimal exactness, field placement, body-arm overlap
and demonstration parser fields) remain archived with their corrections.

Twenty-four complete ordinary API/CLI/hash-seed3187 cases and six separately
labelled API probes pass combined precision80/17ms/reversed-order controls;
probes also run under ambient28. Fresh immutable reproduction after the final
correction passes. Largest final difference is8.53246783442264242319429202429E-47, tolerance1e-8.
The public portal scenario exactly matches current-default CLI. All139 selected
previous complete API traces are exact. Current manifests pin533 source/doc/
primary files and the new evidence. [Reproduction](results/portals/README.md).

**Next concrete implementation:** existing1E1 leap and3E5 leap/falling kick
through reusable shared launch/contact phases, then remaining1E1 launcher and
interaction completion. Continue toward reproducible5v5. Advanced NPC behavior,
mass simulation and balance automation remain deferred. This is a verified
bounded checkpoint; the overall Goal remains active and incomplete.

## Verified checkpoint — actual 1E3 projectile-duplication field

2026-11-09. **Goal active and incomplete.** Previous goal turn: **progress**.
The preceding 522-file checkpoint was verified before edits. All 6916 older
result files and fourteen primary ODTs remain unchanged. Sixteen changed
originals are archived; six source/doc/test/scenario files are new. No existing
test was rewritten. Only the authored 1E3 Ultimate was imported; other abilities,
stats, numeric timings and hand definitions retain their preceding values.

The complete **2774-method suite passes in 780.062 s** across four isolated
unittest processes, with exact once-only discovery and no failures, errors or
skips. All 425 tested runtime/data/test/scenario files retain pre-run hashes.
Thirty-eight new methods comprise nine continuous geometry checks and 29 actual
field/API interactions; their final focused run passes in 47.910 s. The earlier
35 existing projectile/entity methods also pass in 3.122 s.

Actual 1E3 Ultimate now executes its source Active300/extrinsic-momentary,
radius12m/25s/4m separation/65s cooldown, retaining author no-dyspnea activation.
PROJECTILE_DUPLICATION.md separates author facts from delegated cylinder shape,
neutral left hand, unlisted G0/self O/U0, selection cooldown/Active-end release,
frozen targeting, born/already-inside eligibility, symmetric lateral placement,
independent field lineage and collision/expiry ordering. The left-hand summon
can overlap the existing right-hand marking attack and ordinary walking.

Reusable continuous radial entry uses bounded chord enclosures and real inside
witnesses; fixed field/immutable flight pairs are solved once over their common
lifetime, excluding observation-dependent root subdivision. Shared atomic split
prepares both paths before mutation and shifts original/child 2m to either side.
Velocity, accumulated actual travel, original life/action/power, accuracy sample
and utility payload are retained, with no extra ammunition, payment or cooldown.
Birth kinematics remain inspectable after segment rebasing. Inherited field IDs
prevent recursive copies; separate fields each remain effective. Four-way
overlap, native marking/freezes, shields, impact-device explosions, hooks,
source death/restoration and recipient restoration compose. Current physical
contacts precede splitting, including a solid created by a due phase; displaced
endpoints inside material or bodies collide at the same clock. Vertical apex,
actually inert flight and injected second-path failure are separately tested.

Initial fixture failures are preserved: a straight-world projectile target used
the gravity-only explicit-target interface; a last shot was still in flight at
the horizon; and the existing marking attack has no dyspnea payment. Corrections
use supported targeting and the actual current rules. The initial demonstration
used 1E5 targets whose armor absorbed the Qard hits; the public demonstration now
uses 1E2 to expose HP damage as well as marks. Primary stats remain unchanged.

Twenty complete ordinary API/CLI/hash-seed2579 cases and combined precision80 /
17ms / reversed-participant controls pass, as does fresh immutable reproduction.
Six separately labelled API probes reproduce with subprocess/hash and precision/
order/ambient28 controls: collision tie, expiry tie, source restoration, recipient
restoration, control loss and atomic construction failure. Largest final numerical
difference across both sets is 1.74354251800953005089150472141858141697019880301486944430257874371E-11, tolerance1e-8. The public
scenarios/1e3_duplication.json exactly matches its current-default CLI capture.
All 113 selected prior complete API traces remain exact: 24 preceding Ultimate,
26 fence, 18 electrical, 22 Dodge, 20 body, two hook and one historical Block.
Final manifests pin 528 current source/doc/primary files and this new evidence.
[Evidence and reproduction](results/projectile-duplication/README.md).

**Next concrete implementation:** audit and deliver 1E3's existing portal pair,
reusing atomic shared-body transitions, native contacts and linked constraints.
Keep the remaining creative abilities, complete interaction coverage and
reproducible 5v5 Goal in scope. Advanced NPC behavior, mass simulation and balance
automation remain deferred. This is a verified bounded checkpoint, not overall
Goal completion.

## Verified checkpoint — 1E2 Ultimate and timed Gathering

2026-11-09. **Goal active and incomplete.** Previous goal turn: **progress**.
The preceding 515-file fence checkpoint was verified before edits. All 6728
older result files and fourteen primary ODTs remain unchanged. Twenty changed
originals are archived; seven source/doc/test/scenario files are new. No
existing test was rewritten. Only 1E2's existing Ultimate was imported; all
other character abilities, stats, numeric timings and hand definitions remain.

The complete **2736-method suite passes in 745.068 s** across four isolated
unittest processes, with exact once-only discovery and no failures, errors or
skips. All 420 tested runtime/data/test/scenario files retain their pre-run
hashes. Thirty-five new methods cover actual device delivery and labelled
shared API preparation contracts; the final focused run passes in 30.462 s.

The actual device uses G170/A200, 60 m/s gravity flight, radius 8 m, 900 base
Qard, target O/U500, author midpoint self O/U150/190, Db1.5 and 65 s cooldown.
Released intrinsic power and source life survive caster death. One physical
contact produces one area hit per body/material HP pool, without extra direct
damage. Friendly/self hits, actual shields, Block-surface detonation, cover,
material destruction, jumping and earned 2E4 revival compose. Effects queue
after the complete HP/healing/death wave, excluding dead recipients.

Reusable timed Gathering instances compose by maximum, belong to recipient
lives and expire independently. Existing Gathering, including zero-base
reload/posture/Aim and jump/climb/replacement preparation, commits its largest
encountered addition. Expiry does not refund committed work; repeated hits
cannot charge one preparation again. Active-only movement/Get Up/Break gains
no invented phase. IMPACT_AREAS.md and TIMED_GATHERING.md distinguish these
delegated rules from author facts. Actual target instability correctly cancels
sustained gun preparation while the independent modifier remains for retry.

A new fractional-refresh regression exposed repeated upward rounding: three
slightly stronger additions incorrectly delayed Active to 1053 rather than
1051 ms. Quantize the maximum once at shared millisecond phase resolution.
The archived module still reproduces 1053; current source gives 1051. Raw
before/after API traces and module hashes preserve that causal proof. No
geometry tolerance or gameplay time nudge changed. Initial fixture mistakes
(hand Recovery, later-action counts, sustained interruption, revival allowance,
minimum participants and the missing movement-script key) remain archived.
A capture fixture initially killed its source before release; the corrected
actual gun timing now verifies death during device flight, without an API kill.

Eighteen complete ordinary API/CLI/hash-seed 2341 captures and combined
precision 80 / 17 ms / reversed-participant controls pass, as does fresh
immutable reproduction. Six separately labelled API probes also reproduce
with subprocess/hash and precision/order/ambient-context controls. Largest
final difference across both sets is 2.116921776086630208524726432467E-46 against 1e-8. The public
scenarios/1e2_ultimate.json exactly matches its current-default CLI capture.
All 89 selected prior complete traces remain exact: 20 fence + 6 fence API,
18 electrical API, 18 Dodge + 4 Dodge API, 20 body, 2 hook and 1 legacy Block.
The final manifests pin 522 current source/doc/primary files and this evidence.
[Evidence and reproduction](results/1e2-ultimate/README.md).

**Next concrete implementation:** audit and deliver 1E3's existing Ultimate
projectile-duplication field, reusing released projectile-copy identity and
shared spatial volumes. Preserve its unusual allied-projectile duplication
and separation. Continue the remaining creative kits and reproducible 5v5
Goal; advanced NPC, mass simulations and balancing stay deferred. This is a
verified bounded checkpoint, not completion of the overall Goal.

## Verified checkpoint — actual segmented 1E2 fence

2026-11-09. **Goal active and incomplete.** Previous goal turn: **progress**.
The preceding 510-file electrical foundation was verified before editing.
All 6524 older result files and fourteen primary ODTs remain unchanged.
Twenty-one changed originals are archived; five source/doc/test/scenario files
were added. No existing test was rewritten. Only 1E2 ability5's definitions,
metadata and timing were imported; all other kits/stats/hands are unchanged.

The complete **2701-method suite passes in 782.064 s** across four isolated
processes with exact once-only discovery coverage and no failures, errors or
skips. All 415 tested runtime/data/test/scenario files retain their pre-run
hashes. Forty-three new methods comprise 11 pure geometry and 32 actual field/
shared API interactions. The final 45-method focused set, including the two
existing compatibility tests, passes in 19.119 s. Earlier subset logs remain.

Actual ability5 now executes owned G140/A160 summoning, 9 s cooldown, five
independent 4 m × 1.5 m/1500-HP panels, 800/s electrocution, 6 s lifetime and
lower-body B2/common Break. Author no-dyspnea activation is retained. The
primary detailed 20 m rule supersedes the old 15 m overview under delegation.
ELECTROCUTION_FENCE.md distinguishes author facts from Active-end deployment,
neutral left hand, axis-aligned frozen placement, 0.1 m thickness and the
body-permeable/area-transparent electrical screen. Projectiles hit its material;
movement prevention is a contact binding. No ability or arbitrary damage
immunity was invented for characters.

Root-partitioned box contact shares actual body motion/pose with heat. One
field/body/life episode gets one existing electrical stream and one binding;
body parts or panel seams do not multiply output. Break frees movement while
contact still damages; it does not immediately rebind. Exit/re-entry rearms.
One removed seam panel preserves the episode and Break work while another
still touches. Last contacted material, full destruction, expiry and recipient
death end it. Source death preserves released material/effects; a restored
recipient inside the field gets a fresh episode with original source identity.
Material toxin/electrocution immunity, actual gun-created gaps, Qard blasts,
beam destruction, falling, upper-body firing and independent marking compose.

The public walking/Break case exposed a real contact-side defect: midpoint
root rounding could stop just outside, ending the new binding at the same
clock. Box-field boundaries now use the certified upper isolating bracket and
upward absolute-clock rounding at declared precision. No position snap,
gameplay delay or geometry-tolerance relaxation was added; columns retain
their earlier policy. Initial raw traces and pre-fix modules remain saved.
Initial fixture errors (exact root assertion, registry key and away-facing
walker) are also preserved.

The first complete 2700-method run had zero failures and two dependency-gate
errors: unrelated straight Aim and the disabled released-rate API guard. Field
construction now validates mode, with dependencies checked on selection; box
contact does not require gravity. Original tests stay unchanged, and a new
actual straight-world field test passes. The failed run is preserved. Three
tested files edited immediately after it were reconstructed and proved exact
against original pre-run hashes; the other 412 remained unchanged. Its explicit
source-proof record accounts for all 415 original tested files.

Twenty complete current-input API/CLI/hash-seed 2113 cases and combined precision 80/
17 ms/reversed-participant controls pass, as does fresh immutable reproduction
on final source. Largest final difference is 4.7388e-26 against 1e-8. Six separate
labelled API/engineering probes also reproduce with numerical/order controls;
their final-state difference is zero and they make no ordinary CLI claim.
The public scenarios/1e2_fence.json exactly matches its current-default CLI
capture: walk into contact, Break, then walk away. All 63 selected prior complete
API traces remain exact (18 electrical, 22 Dodge, 20 body, 2 hook, 1 legacy Block).
Final manifests pin 515 current source/doc/primary files and the new evidence.
[Evidence and reproduction](results/electrocution-fence/README.md).

**Next concrete implementation:** audit 1E2's existing ultimate and its timed
250 ms Gathering addition, build reusable parameter-effect/lifetime support,
then deliver the actual impact device through shared projectile/area rules.
Keep every remaining creative kit and the full reproducible 5v5 objective in
scope. Advanced NPCs, mass experiments and balancing remain deferred. This is
a verified bounded checkpoint, not completion of the Goal.

## Verified checkpoint — shared electrocution and consistent declared clocks

2026-11-09. **Goal active and incomplete.** Previous goal turn: **progress**.
The preceding 506-file Dodge checkpoint was verified before editing. All 6400
older result files and fourteen primary ODTs remain unchanged. Eleven changed
originals are archived; four source/doc/test files were added. No existing test
was rewritten and no character ability, stat, timing or hand definition changed.

The complete **2658-method suite passes in 860.075 s** across four isolated
processes, with exact once-only discovery coverage and no failures, errors or
skips. All 411 tested runtime/data/test/scenario files retain pre-run hashes.
Forty new methods cover primary electrical rates, mixed continuous layers,
material support, live defenses, source/recipient lives, real attacks/healing/
revival, and direct API precision contracts. The earlier 79-method rate/life
subset and three targeted clock/revive methods also passed.

The fence audit found missing reusable electrocution support. The primary
formula is (de²-Re²)/de; armor does not enter. ELECTROCUTION.md separates the
author formula from delegated zero-rate/output floors and common layer rules.
Released streams now share controlled rates' joint shield/HP solver, raw
pressure/recovery allocation, immutable damage/healing credit and exact death
boundaries. They spend no caster effort, keep released source identity through
caster death/restoration, retire at recipient death, and can depend on material
support. Actual support destruction/expiry and explicit contact exit end them.
Recipient restoration needs a new delivery. No residual electrical memory or
implicit armor loss is added. Only a released-rate rules opt-in was added to
current data. Existing owned constriction and frozen legacy schemas remain.

A natural 2E4 death/revive test exposed a real direct-API clock bug: caller
precision 80 created a fractional revival beyond the body path's precision-50
rounded lease, repeatedly selecting the current time. The live test was
explicitly interrupted; its stack, raw repeated-step snapshot and pre-fix
module are preserved. The archived module reproduces four zero steps; current
code completes actual revival without a time nudge. run() now owns its declared
Decimal context, restores the caller context, and queue insertion normalizes
to that precision. Complete results match across caller precisions 28/50/80;
an overprecise external clock has a separate regression. No numerical tolerance
or physical collision guard was relaxed.

Eighteen **labelled shared API** cases pass complete subprocess/hash1901 and
combined precision80/17 ms/reversed-participant/ambient28 controls, as does fresh
immutable reproduction. Maximum final difference is 1.24703131897634241550445419177104736027920585663325E-26 against 1e-8.
These are damage foundations, not ordinary CLI fence casts. Forty-five complete
previous API traces remain exact: 18 ordinary Dodge cases, four Dodge API
probes, 20 body cases, two no-enemy hook cases and the explicit legacy Block.
Initial missing-slope/unsupported-test-ammo errors, the exact-root assertion,
and an evidence-audit event-shape error are preserved with corrected results.
Final manifests pin 510 current source/doc/primary files and the new evidence.
[Evidence and reproduction](results/electrocution-rate/README.md).

**Next concrete implementation:** deliver actual 1E2 ability5 placement/contact
and binding/Break using this shared foundation: G140/A160, six-second 800/s
fence, B2, nine-second cooldown, five independent 4 m × 1.5 m parts with 1500
non-toxin/non-electrocution HP each. Use detailed 20 m rather than the older
15 m overview under documented delegated precedence. Summoning has no dyspnea
cost, as author-confirmed. Preserve all remaining creative kits and the full
reproducible 5v5 Goal; advanced NPCs, mass experiments and balancing stay deferred.
This is a verified bounded checkpoint, not completion of the Goal.

## Verified checkpoint — actual 2E4 basic9 Dodge

2026-11-09. **Goal active and incomplete.** Previous goal work: **progress**.
The first Dodge audit was read-only before the author paused; work resumed only
after the author reactivated the Goal. The 502-file preceding checkpoint was
verified before edits. All 6219 older result files and fourteen primary ODTs were
fingerprinted; all 23 changed originals are archived in results/2e4-dodge.
Four source/doc/scenario files were added. No prior manifest or capture changed.

The complete **2618-method suite passes in 828.112 s** across four isolated
unittest processes with exact once-only discovery coverage and no failures,
errors or skips. All 408 tested runtime/data/test/scenario files retain their
pre-run hashes. The 28 new methods cover actual Dodge, real evasion/hits, native
contact, ownership, charges, fields, fatigue, death/restoration and numerical
controls. Two obsolete duplicate-Block tests now assert current separate Dodge
stock and disjoint body/hand ownership; their originals remain archived.

Current basic9 imports source Dodge, four charges/4500 ms each, Active 150 ms and
Db 3.5. DODGING.md separates author facts from selecting the permitted downward
variant: 75 ms dip plus 75 ms return through existing proportional crouch, own
serial stock, intrinsic momentary body effort, zero unlisted self statuses,
self targeting and retained pose on interruption. Hands stay available for
independent Block/thrust; stable pace continues. This profile does not add the
general definition's lateral alternatives. No new ability or immunity is given.
Other abilities, stats and authored hands are unchanged. The old basic9 Block
remains reproducible only when explicitly supplied in frozen legacy data.

A real beam/Dodge test exposed a shared forecast extending leg shrink past the
75 ms reversal, producing negative size. Heat queries now clip to valid shared
path/phase bounds before constructing geometry cells, including HP recovery's
conditional 250 ms forecast. The strict geometry guard remains. Death retirement
also closes the Dodge runtime record at actual HP death. Initial failures,
corrected fixtures and raw before-correction Block traces are preserved.

Eighteen complete current-input API/CLI/hash-seed 1709 captures pass, as do combined
precision 80/17 ms/reversed-participant controls and fresh immutable reproduction.
Four separately labelled shared API probes cover new cover, restrictions,
restoration between old events and imposed flight; they also reproduce and make
no ordinary CLI claim. Largest ordinary final-state difference is 1.0410e-46
against 1e-8; largest probe difference is 4.5767e-48. The public current-default
scenarios/2e4_dodge.json exactly matches its pinned capture. Real Qard evasion is
paired with close tracking/lower shots and beam exposure that still hit.

All 20 preceding ordinary body traces, two no-enemy hook traces and the original
explicit legacy basic9 Block API trace reproduce exactly: 23 complete previous
comparisons. The initial legacy replay accidentally used 100 ms default samples
instead of its original explicit None; its diagnostics are saved and the exact
input replay now passes. Final source/evidence manifests pin 506 current
source/doc/primary files plus the new evidence; all 6219 prior results and 14 ODTs
remain intact. [Evidence, integrity and reproduction](results/2e4-dodge/README.md).

**Next concrete implementation:** audit the current 1E2 ability5 fence against its
five 4-m parts, 20 m × 1.5 m detail and 1500 non-toxin/non-electrocution HP per part.
Build any missing shared contact/damage/binding mechanics before delivering the
actual field. Resolve the older 15 m overview by the documented detailed-source
precedence. Keep all remaining creative kits and reproducible5v5 experiments in
the Goal. Advanced NPC behavior, mass experiments and balance automation remain
deferred. This is a verified bounded checkpoint, not completion of the Goal.

## Verified checkpoint — authored body geometry and shared constraint corrections

2026-11-09. **Goal active and incomplete.** Previous goal turn: **progress**.
The complete **2590-method suite passes in 826.089 s** across four isolated
unittest processes, with exact once-only discovery coverage and no skips,
failures or errors. All 405 tested runtime/data/test/scenario files retain their
pre-run hashes. Thirty new methods cover authored geometry and the newly exposed
planner/motor/force defects. Original versions of twelve edited existing test
files are preserved; geometry and contact assertions now use authored sizes.

Current data imports author-specified 1E5 local x/y/z scale 1.6/1.6/1.3 and
3E5 scale 1.15/1.15/1.05. Standing heights are 2.275 m and 1.8375 m, feet anchored
to ground. Per-actor definitions feed placement, crouch/prone/Get Up, hands/reach,
movement/landing, climbing, body support, clearance, projectile aiming/contact
and area eligibility. CHARACTER_GEOMETRY.md distinguishes those author rules
from delegated affine arrangement and proportional crouch. Existing ability
values, combat stats, costs, timings and metre-based hand offsets are unchanged.
Explicit old body inputs retain their proxy; current test helpers enable the
authored geometry. Trait geometry stays fixed across later lives.

The first complete 2587-method regression found seven failures and two errors;
its runtime, receipts and captures are preserved under pre-constraint-fix.
Uniform centres, equal partner centres, climb height, initial melee overlap and
lethal-shot timing were obsolete fixtures. Two reflected knocks retained
1e-48 m/s cancellation residue; expiry now uses the existing contact-speed band.
A real unequal-height chain/body-support interaction exposed a genuine motor
accounting defect: subtracting a projected share repeatedly reapplied running
speed, exceeding 500 m/s before leaving the floor. Residual motion now subtracts
the actor's own unprojected request. The corrected case then exposed a near-
tangent certification failure. A feasible shared-velocity anchor preserves
common translation while retaining strict objective/error and nonlinear
feasibility checks; released-force transport uses that same selected anchor.
PERSISTENT_DISTANCES.md, DISTANCE_PATHS.md and KNOCK_DELIVERY.md record the fixes.

Twenty ordinary current-input cases plus the original labelled stacking/chain
failure pass complete API/CLI/hash1307 and combined precision80/17 ms/reversed-
participant controls. All twenty-one pass fresh immutable reproduction. Largest
final-state difference is 2.5582e-45 against 1e-8. The public six-character
scenarios/authored_body_geometry.json exactly matches its current-default CLI
capture. Real head shots, Qard/beam edge eligibility, pose, jumps, climbs,
support, restoration, grapple motion and simultaneous knocks are verified.
Initial capture/fixture mistakes and the raw failed projection are preserved.
The 80-digit opposed-knock check uses a numerical bound because its attacker
positions were calibrated at50 digits; no engine tolerance was relaxed.

All sixteen immediate previous hook traces reproduce exactly. Five older
frozen-input traces also match the complete runtime reconstructed from this
increment's verified pre-change archive. Differences from those much older
saved results already exist in that baseline, including signed-zero formatting;
they are not attributed to this geometry work. Current source/evidence manifests
pin 502 source/doc/primary files. All 5661 preceding result files and fourteen
primary ODTs remain unchanged. All 44 changed existing files have archived
originals; five source/doc/scenario files were added. No older manifest or
capture was refreshed. [Evidence and reproduction](results/body-scales/README.md).

**Next concrete implementation:** audit the current 2E4 basic9 Dodge source and
shared Dodge rules, replace the obsolete second Block import, and verify its
four charges and 4.5 s/charge through actual owned actions and interactions.
The authored 1E2 fence and other remaining kits follow. Do not claim the full
six-character/5v5 Goal complete. Advanced NPCs, mass experiments and balancing
automation remain deferred. Stop this coherent session at its verified checkpoint
and preserve capacity for the next complete implementation/verification cycle.

## Verified checkpoint — explicit world targets and 1E2 grappling gun

2026-11-09. **Goal active and incomplete.** Previous goal turn: **progress**,
auditing source and implementing an unverified prototype. The author paused
on November3; a usage-limit automatic-approval failure then prevented the
handoff documents from being written. The author has now resumed the Goal.
Disk inspection confirms the prototype and the68-method subset result exist;
the attempted pause/handoff documents did not reach disk.

This increment has its own full regression and reproducibility evidence; the
old ability4 result remains historical. The earlier prototype subset completed
68 methods in25.837 s, OK, but none activates explicit world targets or the new
grappling gun. At resumption ability3 was explicitly labelled unverified; the
current executable definition now links its final verification here.

The source audit pins authored rope30 m, cooldown12 s, G160/A60, hook speed40,
firing self135/135 and Db1.5, separate launch self300/350 and Db1.5, arrival
self305/355 and intrinsic momentary firing. [GRAPPLING_GUN.md](GRAPPLING_GUN.md)
records delegated speed, target, geometry, phase, payment and lifetime choices.
Implementation adds world/surface targets without an enemy, actual face anchors,
owned hook/launch continuation and shared native first-contact obligations.
The actual interactions and complete regression now have the evidence below.

Implementation verification has now exercised actual wall/ground/overhead
launches, no-enemy world targeting, Body/Block interception, moving range,
separate payments/transfers, copies, prior jump obligations, incoming gun death,
restrictions and external displacement. The34-method new module includes pure
fastest-arc checks. Initial new fixture failures are preserved: external
velocity's actual reason/event names and a real later ground hit after removing
the aimed wall. That actual ground collision legitimately creates an anchor.

An actual1E1 beam exposed130.343 ms of delayed control release after destroying
the2000-HP anchor. The failing assertion is preserved. A generic distance-end
observer now cancels control at the actual removal clock; real-beam and explicit
removal checks pass. Spatial transactions and successive launches preserve all
owed contact effects. The complete2560-method suite passes in528.051 s across
four isolated unittest processes, with exact once-only discovery coverage and
no skips/errors/failures. All401 runtime/data/test/scenario files retain their
pre-run hashes; no existing test was changed. All34 new methods pass within
that full run.

Sixteen complete public API/CLI/hash911 and combined precision80/17 ms/reversed
captures pass. Largest final-state difference is2.361e-40 against1e-8. Sixteen
previous complete ability4 traces reproduce exactly on frozen inputs. The
continuous-wall audit's initial re-summed HP comparison failed by3.842e-47;
clipping now checks the event's actual pre-hit snapshot while retaining
independent cumulative conservation. No engine formula/tolerance changed.
Fresh immutable reproduction passes all16 cases, and the current-default public
CLI exactly equals its pinned wall capture. Final integrity pins497 current
source/data/test/scenario/doc/primary files plus the new evidence. The28 scoped
existing changes include the three author-edited primary documents; six source/
scenario/document files were added. Original25 runtime/data/doc files and all
5493 preceding result files remain preserved. No prior manifest was refreshed.
[Evidence, integrity and reproduction](results/grappling-gun/README.md).

All5493 earlier result files and fourteen ODTs were fingerprinted before edits;
original runtime/data/doc files are archived under results/grappling-gun.
Resume integrity confirms all5493 old result files unchanged. Three primary
ODTs have author edits since the pause: fence part geometry/HP,2E4 basic9 Dodge,
and1E5/3E5 body scales. Both source versions and exact diffs are pinned;
[SOURCE_UPDATES_2026-11-09.md](SOURCE_UPDATES_2026-11-09.md) records the changes
and remaining imports. Grappling-gun paragraphs are unchanged. Do not describe
the old second Block or common body proxy as implementing these new revisions.
This coherent increment is verified; the full Goal remains active/incomplete.
**Next concrete implementation:** import authored1E5/3E5 scales through shared
body geometry, including pose/hand/reach/contact support, then correct2E4 basic9's
obsolete Block import to its actual Dodge. Preserve historical inputs and verify
real interactions.
Keep the original six-kit/5v5 objective; advanced NPCs, mass simulations and
balancing automation remain deferred.

## Verified checkpoint — 1E2 ability 4 and shared body-part damage

2026-11-03. **Goal active and incomplete.** Previous turn: **progress**, sealing
current Aim/curved-entry evidence and resolving missing documentation. Start of
this increment verified the prior source hashes and preserved all 5348 previous
result files and fourteen ODTs in results/1e2-ability4. Original edited runtime/
data files are archived before mutation; no primary source is changed.

Source audit and delegated decisions: 1E2_ABILITY4_AUDIT.md. Shared rules:
BODY_PART_DAMAGE.md. Keep explicit intrinsic momentary effort, source 600/1500,
Active60, cooldown9s, recoil165/165, target140/140, Db2.5, speed1400 and piercing60.
Selected missing-value defaults: zero base Gathering, existing grip/left origin/
2cm sphere, existing continuous0.25 damage/m loss, paid release cooldown anchor,
no unlisted ammunition rule. Do not label these defaults author confirmations.

Implementation uses reusable direct projectile delivery, frozen default/head
power with one release-time U snapshot, actual-contact part selection and
scripted aim_part. Default torso behavior and unrelated existing profiles remain.
The 34 new pure/current-input methods cover head/body/guard/material/friendly
intercepts, source/target death, released copies, incoming instability, cooldown
fields, actual movement, simultaneous head hits and shared fixed-filling payment
failure. **185 affected methods pass in 70.193 s**; additional early-definition
validation also passes. The first canonical full run completed 2526 methods in
1650.737 s, with only two obsolete timing expectations failing: they still
included source-removed Gathering180. Their original file and the complete run
are archived. Updated release/arrival expectations use 60/132 ms, preserving
the 72 ms flight check; all 34 timing methods pass. Runtime/data are unchanged
after that first run.

Sixteen ordinary complete API/CLI/hash-seed607 and combined precision80/17ms/
reversed-participant captures pass, as does fresh immutable reproduction. The
largest final-state difference is about 4.993e-47 against 1e-8. Independent audits
check actual part selection, flat U loss, travelled distance, source/cone/HP,
once-paid release/cooldown and wall credit. Eleven complete previous Aim traces
reproduce exactly on frozen inputs. The public current-default CLI matches the
pinned aimed-head capture. Other five profiles and other existing ability data
remain unchanged; the initial new fixture/schema/rounding failures are preserved.

The complete **2526-method suite passes in 805.091 s**, exit 0, across four
isolated unittest processes partitioned by module. Discovery/worker receipts
verify every method ran exactly once, with no skips, errors or failures. All
397 runtime/data/test/scenario files match their pre-run hashes. The failed
canonical serial attempt remains separate; it is not relabelled as successful.

Final integrity preserves all 5348 earlier result files and fourteen ODTs,
permits only the documented 22 existing source/data/test/doc edits and six new
source/scenario/document files, and pins 491 current files plus the new evidence.
The evidence-tool import correction and initial fixture failures remain saved.
[Evidence, integrity and reproduction](results/1e2-ability4/README.md).
This coherent increment is complete; the full six-kit/5v5 Goal remains active
and incomplete. **Next concrete implementation:** reusable explicit world/
surface targets and committed hook-point anchors for 1E2's existing grappling
gun, then its authored rope/self-launch phases. The
[read-only preflight](results/1e2-ability4/next-step-preflight.md) pins source
phases and existing prerequisites; launch speed/phase/lifetime choices still
need delegated design and interaction verification. Advanced NPCs, mass
experiments and automated balancing remain deferred.

## Verified checkpoint — Aim and confirmed curved entry

2026-11-03. **Goal active and incomplete.** The preceding turn is **progress**:
it corrected N1/N2, added current-input regressions and completed the 2492-method
suite. All 393 runtime/data/scenario/test files still match that successful run.
No runtime or character change was needed to finish the interrupted Aim
checkpoint. The existing successful full run remains applicable; it was not
rerun or relabelled as a new full execution in this handoff.

New work is in results/aim-toggle-confirmed-entry. All 5251 preceding result
files and fourteen current root ODTs are fingerprinted. Preserve both older Aim
directories and the latest review-fix evidence. This new directory replaces the
older plan to add captures to results/aim-toggle, which is now historical.

Eleven ordinary public scenes include the earlier ten Aim interactions plus
the actual prison/ice cast that exposed the curved-entry error. Complete current
schema-2 API/CLI/hash-seed-401 and combined 80-digit/17 ms/reversed captures pass,
as does fresh immutable reproduction. The current-default public Aim CLI equals
its pinned API capture. Independent audits check source/life/ordinal identity,
cone angle/speed, actual toggle cost/phases, HP/healing and wall credit. The
largest final numerical-control difference is about 1.854e-45 against 1e-8.

**72 focused methods pass in 20.370 s.** The unchanged 393-file runtime/data/
test/scenario source is the one that passed **2492 methods in 1627.776 s**.
Independent analytic witnesses confirm static and moving/resizing entries
within the unchanged 1e-12 s bracket and supplied query; truncated/grazing and
overlapping-priority guards remain explicit. CURVED_CONTACTS.md now resolves
the data's missing reference and states the binary64/non-certified boundary.
The source audit independently checks the per-metre disorientation unit and
authored Aim/radius/running paragraphs against three pinned primary copies.

Exhaustive legacy diagnosis covers ten older Aim and thirteen charge traces.
All physical fields remain equal. One trace is completely identical; 22 differ
only in internal created-path counts and/or pending decision revisions. Restoring
only the archived pre-N1 scheduler in an isolated process restores all 23 complete
traces exactly. That diagnostic is not a public legacy mode. Failed initial raw
replays and the new evidence-script schema-selector error remain saved; no old
capture, interrupted log, source document or manifest is refreshed.

[Aim rules](AIMING.md) · [Curved contacts](CURVED_CONTACTS.md) ·
[Evidence, integrity and reproduction](results/aim-toggle-confirmed-entry/README.md).
Current capability/source/roster/roadmap records now distinguish this verified
integration from ability 4's still-unimplemented metadata.
**Next concrete implementation:** audit 1E2 ability 4's source phases, recoil,
cost, cooldown and range falloff; implement reusable body-part damage selection
on actual projectile contact, then deliver its authored 600-body/1500-head shot
through the existing owned release, flight, accuracy and simultaneous defenses.
Verify real head/body/shield/Block/terrain/life interactions. Preserve the full
six-character/5v5 objective; advanced NPCs, mass experiments and balance
automation remain deferred.

## Verified checkpoint — November 3 review fixes N1 and N2

The author explicitly requested continuing with these fixes. Work is scoped to
correcting and verifying N1/N2; the broader six-kit/5v5 objective and unfinished
Aim handoff remain incomplete. The reviewed source, fourteen primary hashes
and preceding result fingerprints are preserved in
results/principal-review-fixes-2026-11-03. Do not refresh review evidence.

Implemented separately: N1 makes every successful owned acquisition request
another same-clock eligibility decision through the existing queue, retaining
priority, resource/capacity gates and once-only payment. N2 makes intent/climb
handlers respect pose_only without withholding the contact from posture freezing.
No character ability, data, numerical tolerance or payment rule changes.

The unchanged seven review specifications now pass (four failed before fixes).
The 43 readiness/ownership/command checks and five older review invariants pass.
108 current-rule/enhancement tests pass; the 27 final dash/counter checks also
pass. Sixteen complete API/CLI comparisons, eighty observation/precision
captures, reversed insertion order and six full hash-seed comparisons pass.
The permanent module adds 24 current-input methods, including the unchanged
review cases, four concurrent actions, conflicts/capacity, modifier release
windows, guards/counters, held dashes and real climb obstruction/clearance.

Broader testing exposed former serial-preparation assumptions in five existing
test files. Preserve their original versions under source-before/tests. Fixtures
now explicitly gate the required hand/locomotion when testing a prepared
Ultimate, grab-before-dash or single-guard lethal counter. Ungated current-input
tests retain early unbuffed strikes, early-dash misses and extra legal guard
layers. Formula, clipped credit, defense sharing and lifecycle assertions remain.
The initial 290-method interaction log, failed fixture-schema runs and first
full attempt remain saved. That full attempt was deliberately interrupted after
known stale setup failures; it is not a successful full result.

The final canonical **2492-method suite passes in 1627.776 s**, exit code 0.
All 393 source/data/test/scenario files match their pre-run hashes. The final
audit preserves all 5186 prior result files and fourteen primary ODTs, permits
only the documented edits to fourteen reviewed files, and pins the new source
and evidence checkpoint. No review manifest is refreshed. The response,
mechanics documents, current index and evidence README record the completed
corrections and their numerical/physical limits.

[Response](PRINCIPAL_ENGINEERING_REVIEW_2026-11-03_RESPONSE.md) ·
[Evidence and reproduction](results/principal-review-fixes-2026-11-03/README.md).
This bounded review-fix increment is complete; the broader Goal is incomplete.
**Next concrete step:** reconcile the unfinished Aim/confirmed-curved-entry
evidence and documentation, including the missing CURVED_CONTACTS.md reference;
use this successful full regression as current evidence without rewriting prior
interrupted logs or manifests. Then select the next missing actual delivery
from ENGINE_STATUS.md. Retain the review's orchestration risk as a boundary
design constraint, not a reason for an unverified wholesale rewrite. Advanced
NPCs, mass experiments and automated balancing remain deferred.

## Independent principal review completed — 2026-11-03

The author requested another independent review after the recent implementation
work. [Review and actionable handoff](PRINCIPAL_ENGINEERING_REVIEW_2026-11-03.md)
and [reproduction evidence](results/principal-review-2026-11-03/README.md) are saved.
This was a review-only session; implementation, existing tests/data/scenarios
and primary ODTs were not edited. The implementation Goal's paused status below
is retained; the author's later `continue` resumed this review.

Two **verified P1 findings** remain: **N1**, independent actions are reconsidered
after acquisition only for selected action kinds, so a stationary no-op `stop`
wakes 2E4's otherwise idle free-hand Block and materially changes HP; **N2**, the
intent/climb contact handlers ignore `pose_only`, cancelling a tangential climb
before the pose handler freezes deformation and turning climb speed into an
unintended upward flight. The report supplies exact scenarios, code references,
practical corrections, positive controls and acceptance tests. Structural risks
and acknowledged unfinished kit capabilities are separately labelled.

Verification: the resumed complete suite passed **2468 tests in 1527.217 s**.
The new isolated review script runs seven methods: three controls pass and four
desired-behavior specifications fail, exposing N1/N2. Thirty current-input
captures, six complete API/CLI comparisons, reversed-participant controls and
two hash-seed comparisons preserve the findings. The original five review
invariants pass with current required world inputs; the previous registered-climb
prerequisite and heat-volume schema cases also pass. All 392 files in the
development checkpoint's source manifest match at resumption; the review pins
481 pre-existing files and verifies final integrity separately.

Next implementation handoff: fix N1 and N2 separately, preserve resource/phase
ordering and genuine obstruction responses, add current-rule invariant tests
alongside historical fixtures, and rerun affected interactions plus the full
suite. This audit does not complete the paused Aim increment or the six-kit/5v5
Goal and does not begin NPC or balance work.

## Paused by author — Aim and confirmed curved entry

2026-11-03. The author explicitly paused the Goal again. Stop development until
resumed. The Goal is incomplete. Previous work made concrete implementation,
regression diagnosis and numerical-correction progress; nothing here claims a
verified complete Aim increment or six-kit/5v5 engine.

The initial Aim phase is preserved under
results/aim-toggle-initial-contact-guard. It contains 217 passing focused methods,
ten complete API/CLI/hash/numerical captures and fresh reproduction, thirteen
unchanged previous charge traces, the matching current-default public CLI, and
the earlier actually interrupted run. The resumed full run then completed
2461 methods in 1643.429 s with two failures and one error. No old manifest or
primary source was changed. All fourteen primary sources matched on resume.

Two failures were fixture assumptions about perfect aim. The released gun round
at 100 m is unchanged by controller fall even when seed 0 misses; seed 114 hits
and bleeds after the fall. Complete first-flight records match with/without fall
for both seeds. That existing test now checks both cases. The precisely mirrored
same-wave prison/mark test explicitly disables dispersion for its calibrated
simultaneous-geometry contract, keeping its original strict assertions. Original
versions of both edited tests are archived under
results/aim-toggle/source-before-refinement; no other old test was changed.

The real error was an ordinary ice projectile entering a prison west wall.
A leaf ended 6.68e-15 m outside the surface; an actual inside point existed
within the same 1e-12 s time bracket. The solver previously raised first.
The new explicit physics schema 2 / confirmed_entry_v2 mode probes an actual
inside point within the existing time budget and current integration interval.
No tolerance, gravity, radius or event quantum was widened. Unconfirmed grazes,
interval-end ambiguity and overlapping scene priorities retain strict guards.
Frozen physics schema 1 keeps its former behavior.

**Implemented correction evidence:** all three originally failing interaction
methods now pass in 4.972 s. Seven new confirmed-entry kernel methods plus the
29 existing static/moving curved-contact methods pass (36 total, 1.175 s).
The new tests independently check the recorded wall entry, analytic crossing,
moving/resizing surfaces, no interval extrapolation, retained uncertain-graze
rejection and retained priority guards. Current source is pinned in
results/aim-toggle/regression-source-before.json; test-inventory.json lists
2468 methods. The fresh full run was interrupted on this explicit pause and
is not a successful full-suite result. Preserve its partial full-suite.txt log.

Current edited production: Aim/control/accuracy modules and lifecycle hooks,
plus gravity_collisions.py, moving_gravity_collisions.py and the versioned
setup/call in gravity_projectile_rules.py. Data edits: 1E2 Aim/weapon accuracy,
locomotion accuracy/ownership mode and physics schema 2. Other five character
profiles and primary ODTs are unchanged. New tests are test_accuracy.py,
test_aim_combat.py and test_confirmed_curved_entry.py. The source before the
numerical correction is archived; all 86 initial Aim evidence files are pinned
by initial-aim-evidence-before-refinement.json, in addition to the original
5057 historical files and fourteen primary hashes.

**Resume:** inspect live processes and logs first; compare current source hashes
with regression-source-before.json. Archive the interrupted full log, then
complete the 2468-method regression and the broader updated interactions.
Update the copied make_scenarios.py/reproduce.py in results/aim-toggle to add
the ordinary prison/ice interaction to the ten earlier Aim scenes; regenerate
current input/capture files in this new directory (they are not present yet).
The complete earlier ten scenes remain frozen in the sibling initial-contact-
guard directory and must not be overwritten or counted as schema-2 evidence.
Reproduce those historical ten and the previous thirteen charge traces, then
capture current complete API/CLI/hash/80-digit/17 ms/reversed controls with HP,
source, cone geometry and wall audits. The public scene already exists at
scenarios/1e2_aim_toggle.json; recheck its current-default CLI against the new
schema-2 capture. Finish CURVED_CONTACTS.md (currently absent despite the data
link), current capability documents and the new integrity gate. AIMING.md still
correctly says in progress. Do not refresh historical manifests.

Known scope: confirmation remains bounded to the supplied physical interval;
unconfirmed endpoint/grazing geometry still raises rather than inventing a hit
or miss. Advanced NPCs/mass/balancing stay deferred. Ability-4 headshots, other
remaining kits, portals/duplication, broader turning/ledges and complete 5v5 are
unfinished. Ask only creatively indispensable questions after resuming.

## Verified checkpoint — actual 3E5 charge, front holding and wall slams

2026-11-03. **Goal active and incomplete.** Existing 3E5 Ultimate now executes
through shared owned moving-box contacts, life-bound motor bonuses, actual
holding/Break and committed wall receipts. Real casts grab the first body,
preserve the full 180 ms grab tail, hold for eight seconds, break two 2000-HP
walls and apply separate 700-base blunt victim slams. The 65 s cooldown and Db3
start at charge Active. [Rules](CHARGE_GRAPPLE.md) ·
[Evidence/reproduction](results/charge-grapple/README.md).

**2425 full-suite tests pass in 1508.383 s; 77 focused methods pass in 95.419 s.**
Thirteen complete ordinary API/CLI traces, thirteen fresh hash-seed 401 controls
and thirteen saved 80-digit/17 ms/reversed-participant controls pass. Independent
HP/healing/life, source/phase/power and wall-HP audits pass; largest final physical/
resource difference is below 1.133e-40. The current-default public wall-arena CLI
matches its complete frozen trace. Six previous complete contact captures replay
unchanged with their original inputs. The final source/data/evidence integrity
checks are in the linked package; historical manifests are not refreshed.

Delegated choices fill source omissions: 600 DPS/Dd2 constriction/tear, an actual
left-hand forward contact proxy, and normal ground drive after search/grab ends.
The +50% bonus lasts two seconds, before U penalties and grapple averaging;
a surviving controlled victim slam refreshes it. Own bonus identity qualifies
wall fracture; unrelated speed does not. Glancing/airborne captures preserve
actual offsets without teleportation or another position writer. Right-hand
work and autonomous beam effects retain their independent ownership/lifetimes.

A live heavy hit exposed incorrect knock timing: its statuses could release a
hold before force read membership. The explicit current timing mode snapshots
the pre-hit group/defenses, finishes character damage, then applies additive
forces before fatigue/new attachments. Existing 1E5 and new 3E5 holds, opposed
punches and force expiry verify the author's summed-stat rule. Frozen earlier
inputs retain their old policy. Controlled charge is a documented dash-family
cause for the existing upward counter; ordinary bonus running is not.

Hand-wall fracture waits for complete ordinary object damage so same-batch
nonpiercing shots still meet the pre-batch solid. Held-victim fracture precedes
an absent wall's infinite-mass response. Pre-contact U power/modifiers/source/
lives survive collision cancellation and emit through the normal later impact
batch. Nonqualifying solids retain native response. No wall HP grants actor
healing/revival credit. Source, actual material and phase clocks remain inspectable.

Preserved diagnostics include the first full run's ten missing-optional-input
errors on minimal historical contact worlds. Defaulting that absence to the
historical policy fixes all twelve existing contact methods; the corrected
full suite passes. Earlier fixture/geometry/source-reporting failures and the
capture auditor's nonexistent max_hp field are retained. Fresh complete
reproduction now passes all thirteen cases without resuming saved physics.

4944 earlier result files/manifests and other earlier tests are preserved.
One contact fixture is adapted for the now-supported Ultimate/dependent mode;
its byte-identical original is archived. No primary ODT was edited by the
implementation. A concurrent 1E3 overview revision changes duplication radius
8→12 m and separation 3→4 m; matching old/new copies, hashes and diff are pinned,
and metadata is imported. Thirteen other primary sources match this increment's
start. Duplication and the preceding 1E2 Aim revision remain unimplemented.

**Next concrete work: 1E2 Aim toggle and deterministic projectile dispersion**
on shared aiming, preserving faster-arc physics, owned phases, no aiming while
running and complete replay controls. Other remaining kit deliveries, leap/kick,
portals/duplication, static ledges, linked climb, broader turning and complete
reproducible 5v5 remain unfinished. Advanced NPCs, mass simulations and balancing
automation stay deferred. End this coherent session at the verified checkpoint;
the overall Goal stays active, rather than being marked complete or paused.

## Verified checkpoint — committed native contact signals

2026-11-02. **Goal active and incomplete.** Shared native contact receipts now
pin participant lives, physical states, defenses, owned actions, actual grapple
groups/links and collider identity/tags/revisions before collision can cancel
control. Existing native responses run once; committed same-clock handlers
retain their original source. No subscribers schedule no extra physical knot.
[Decisions](CONTACT_EVENTS.md) · [Evidence](results/body-contact-signals/README.md).

**2384 full-suite tests pass in 1408.841 s; all 24 new shared-engine contact
methods pass in 10.894 s.** Actual posture cancellation, hold/fatigue release,
jump landing, death/restoration, simultaneous walls, pose obstruction, expiry
and causal observer changes are covered. The `after` state is explicitly after
native kinematics and before outer phase settlement; handlers use committed
`before` group membership to establish who was held at impact.

Six ordinary complete API/CLI captures, six complete hash-seed 401 controls,
six saved 80-digit/17 ms/reversed-participant runs and six disabled-mode
comparisons pass. The full crowded encounter has 75 contact waves; final
physical/resource differences under numerical controls are below 1.745e-44.
Without listeners, final states, metrics, HP history and all existing events
match exactly when recording is disabled. A separate labelled public-API
observer removes a wall after contact, retaining its pre-removal identity/HP.
This is an engineering probe, not an Ultimate cast. Six previous complete
body-support API traces replay unchanged with frozen inputs.

4876 preceding result files/manifests and all earlier tests are preserved.
Only the current locomotion data gains the explicit contact-signals mode;
character, terrain and other physics data are unchanged. A concurrent primary
1E2 Aim edit is preserved separately: toggle, 160 ms Active, no aiming while
running and additional non-aiming dispersion. It remains pending; the other
13 primary ODTs are unchanged. The fresh capture finished all comparisons
before its final preservation assertion caught that edit. A saved-trace audit
pins the revision without repeating unchanged physics. Earlier invalid fixture
and ground-tag audit failures remain in the evidence package; no physics/fatigue
rule or previous manifest was weakened/refreshed.

**Next concrete work: actual 3E5 Ultimate controlled swept grab, charge speed/
expiry, front holding and qualifying wall slams.** An ordinary 12 m/s body
crash already gives about 649.63 incoming O/U each and exhausts a fresh holding
controller. Implement its actual hand/grab geometry before full-body impact;
retain shared collision penalties. Existing linked paths preserve captured
relative offsets, but glancing/airborne front capture still needs verification.
Choose/document drag DPS/effort and wall-reset details under delegation.
Qualifying wall destruction remains separate from 700 blunt victim damage.
The three 2000-HP walls and committed contact API are ready; the Ultimate is
not implemented. Then integrate the pending Aim revision and remaining kits/
portals/duplication, broader turning/ledge geometry and reproducible 5v5.
Advanced NPCs and mass/balancing automation stay deferred. Stop at this bounded
verified checkpoint with verification and handoff complete.

## Verified checkpoint — living-body support and stable tangency

2026-11-02. **Goal active and incomplete.** Life/part witnesses now join the
existing shared contact/distance planner and saved reference-path writer.
The selected current mode supports rooted/floating stacks, pose withdrawal,
real impacts/landings, inherited support loss, actual holds/tethers, death and
occupied restoration. [Rules](BODY_SUPPORT.md) ·
[Evidence and boundaries](results/body-support/README.md).

**2360 full-suite tests pass in 1418.168 s.** This includes 44 new methods:
29 shared combat methods, eight support-geometry methods and seven tangency
methods. Earlier focused and failed/diagnostic runs are retained separately;
the complete final suite covers the current source. No animation or character
ability is invented, and existing character/body/other physics data is unchanged.
Only the current locomotion input gains the explicit support mode.

Six complete public API/CLI captures, six complete hash-seed replays and six
saved 80-digit/17 ms/reversed-participant controls pass. The full 2200 ms crowded
prison/hold/heavy-knock encounter uses ordinary casts without intervention.
Five other scenes label their initial stacking geometry, then exercise real
walking, climbing, expiry, grappling/drag, gun death and beam destruction of a
2000-HP deck. Independent audits check HP/healing/lives, witness lifetimes,
object damage/credit, and exact full-interval contact/distance polynomials.
Current-default public CLI matches the complete frozen-input crowded trace.

All fifteen previous prison captures and three previous velocity traces replay
unchanged. All 4711 preceding result files/manifests, fourteen primary ODTs and
previous tests are preserved. No historical manifest is refreshed. The final
integrity gate freezes the current source, data, documentation and evidence.

Important corrections: route support loss through the common spatial
transaction; distinguish prospective placement from present support; preserve
independent floor reactions; keep contact queries coherent during atomic path
consumption. The initial gravity-only diagnosis of witness churn was incomplete.
A separate numerical control exposed a spurious corner impulse from 1.12e-78 m
stationary-face overlap. Native prediction/revalidation now use the existing
1e-20 m / 1e-24 m/s / 1e-24 m/s² resolutions consistently for tangency, without
widening them. Complete crowded controls now agree in final physical/resources
within 1.745e-44. Preserve all intermediate failures and interrupted runs in the
new evidence package; none is counted as a successful full suite.

Pose obstruction and standing/Get Up clearance remain in force. Withdrawing
poses release support; there is no pose-driven lifting or horizontal friction/
carrying. Mere body contact never joins the author's summed-stat grapple knock
resistance group. Basic jumps retain one owed landing effect even when later
balance changes produce genuine additional physical contacts. This increment
does not claim a universal multi-body energy or convergence certificate.

**Next concrete subsystem: 3E5 Ultimate charge/grab/front holding and qualifying
wall slams**, using shared motion, real grapples and collider identity/removal.
Preserve its creative conditions: wall destruction during the speed bonus is
separate from ordinary 700 blunt victim damage. The 2000-HP wall arena is ready;
the Ultimate is not implemented. Static ledge/outer-floor departure, broader
turning, portals/duplication, other missing kit deliveries and complete 5v5 remain
unfinished. Advanced NPCs and mass/balancing work stay deferred. Stop at this
bounded verified checkpoint; reserve the next coherent session for the charge.

## Verified checkpoint — velocity-only force expiry at contacts

2026-11-02. **Goal active and incomplete.** Shared spatial validation now
separates an actual relocation/new occupancy from a velocity change at existing
geometry. Only new placements and restoration perform overlap rejection;
relocated bodies still check every final recipient. No position writer,
collision tolerance, character data, payment or force duration changes.
[Rules](SPATIAL_TRANSITIONS.md) · [Evidence](results/velocity-transitions/README.md).

**2316 full-suite tests pass in 782.867 s. Nine new methods pass in 91.088 s;
35 existing spatial methods pass in 1.752 s.** A deterministic rounded-contact
fixture and the actual early heavy-knock/prison failure reproduced beforehand.
The complete 1800 ms cast encounter now finishes; native force expiry at 890 ms
retains all recipient references. Relocation collisions, occupied revival,
finite/life checks and stale plans remain strict. The direct restoration preflight
has an additional passing check.

Complete ordinary force API/CLI traces match. Two labelled engineering scenes
exercise velocity changes after actual wall/body contacts and continue firing.
Three saved 80-digit/17 ms/reversed-participant runs independently agree on actual
reference/body position, velocity, resources and every spatial transaction.
All fifteen prior prison captures replay unchanged. Three complete hash-seed
and three combined precision/observation/order controls pass; the independent
physical-control audit saves all three complete traces. The final integrity gate
freezes this checkpoint; do not refresh earlier manifests.

**Next shared subsystem: moving-body support.** The other full 2200 ms crowded
knock/prison continuation still reaches its explicit support guard. Do not just
remove that guard or copy a carrier's position in a second motion loop. Extend
the shared unilateral/saved-path constraints with life-bound part/normal
contacts, pose velocity/acceleration offsets, real grapple/tether coupling,
departure/re-entry and landing obligations. Preserve the author's initial
centre-line collision/status calculation; resting support must not repeatedly
add penalties. Horizontal friction/carrying has no authored rule. Verify full
crowded continuation, moving/deforming stacks, jump/departure, death/revival and
force interactions with numerical/observation/order controls before claiming it.

All 4672 earlier result files and 14 primary ODTs are preserved; current JSON
data stays byte-identical. The prior prison integrity gate passed before this
source edit. Six kits/5v5, charge/wall slam, portals/duplication and broader
turning/ledge geometry remain unfinished; advanced NPCs and mass/balancing
simulation stay deferred. Stop at this bounded verified checkpoint with a
current handoff; do not start the larger support subsystem without capacity
to implement and verify it together.

## Verified checkpoint — physical prison and shared solid hand reach

2026-11-02. **Goal active and incomplete.** Existing 1E3 ability4 now forms a
hollow six-face 4000-HP / 12 s physical enclosure through an actual damage-free
projectile. Shared solid hand reach prevents close origins beyond thin walls;
explicit area policy corrects the existing cover-transparent ice burst.
[Rules and delegated choices](PRISON.md) · [Evidence/boundaries](results/prison-cast/README.md).

**2307 full-suite tests pass in 674.831 s; 69 focused methods pass in 60.172 s**: eight placement, twelve contact-response,
thirteen reach and thirty-six live prison methods. Fifteen complete ordinary
API/CLI captures and fresh reproduction pass, with five complete hash seed 401
and five combined 80-digit / 17 ms/reversed-participant controls. Both public prison
and 2000-HP wall demos match current-default CLI/frozen API traces. Independent
material/containment, shared object HP, zero utility power, actor HP/healing/life
and expiry/source-attribution audits pass. Previous twelve ice-bomb and four
wall captures replay unchanged. The integrity gate freezes this bounded
checkpoint; do not infer the complete Goal from it.

**Source:** G140/A180, 100 m/s, self O/U120, target O/U110, intrinsic momentary
firing, Db2, 4000 HP / 12 s / 9 s cooldown. **Delegated:** no invented HP damage or binding
value; pay/cooldown at release, neutral right hand / 2 cm/faster gravity aim;
minimum 2 m cavity with 0.1 m walls/clearance, fitted to current bodies and actual
grapple groups without actor translation. Terrain/Block consume utility without
fake damage/counters. Personal shielding preserves HP but does not stop body
contact. Formation follows shared HP/healing/death; source action/life stays
pinned through death/restoration. Formed objects outlive caster/occupant lives.

Actual walking/jumping/climbing, inward/outward gunfire, Qard, roof/heat cover
and destruction, a prison appearing during an existing beam, marking/ice,
legal remote summons and pause fields compose. Real recipient death/revival
keeps one enclosure. Copies have independent HP/clocks; later casts hit existing
material. Raised-floor expiry uses native falling/landing. No global action ban
or intangible freeze replaces material. Original2000-HP walls remain prepared
for 3E5's qualifying charge; that ability is not implemented.

**Shared corrections:** reach/reporting/Recovery/melee/release use one actual
point while canonical requests stay separate. Two-hand Recovery remains parallel.
Current reference contacts distinguish pose obstruction from approaching motion.
Moving elastic contacts use a common weighted frame; rapid repeats within 1 ms
absorb normal movement for that response/group. Log that numerical contact band;
no general multi-body energy/convergence certificate is claimed. Frozen earlier
selected inputs retain their original responses.

**Concrete next shared-engine work:** the longer crowded heavy-knock continuation
reaches the existing moving-body-support guard; an ordinary earlier knock reaches
an over-strict velocity-only spatial placement check at force expiry. Preserve
both failed scenarios/diagnostics. The short paired capture verifies the actual
summed-stat knock and first common wall impact; the impact legitimately exhausts
the holding controller and releases the grapple. It does not verify either longer
continuation. Correct velocity-only validation, then dynamic support before
charge/wall slam. Portals, duplication, other kits, turning/ledges and final 5v5
remain unfinished; advanced NPCs and mass/balancing automation stay deferred.

**Diagnosis and preservation:** initial fixture/representation assertions and
bounded contact diagnostics are retained. The first full run was interrupted
after identifying a stale hold assertion; its corrected 2307-test replacement passes.
Fifteen fresh captures pass after making the material audit compare exact ratio
certificates to decimal displays within 1e-35 m. All 4582 earlier result files and
fourteen primary ODTs are unchanged; no old manifest is refreshed. Existing
character stats/abilities are unchanged apart from importing authored 1E3 ability4
and metadata; current data adds explicit construct/reach/contact modes/ownership.
This is a bounded verified checkpoint with capacity reserved for final audit
and durable handoff; start the two concrete shared fixes in the next session.

## Verified checkpoint — actual 1E3 ice bomb and shared impact bindings

2026-11-02. **Goal active and incomplete.** Existing ability2 now throws an
actual physical carrier and detonates an independent lower-body binding area
on first contact. Shared damage, area geometry, actions, forces, lives and
common Break remain in use. [Decisions](IMPACT_BINDINGS.md) ·
[Evidence](results/ice-bomb/README.md).

**2237 full-suite tests pass in 603.380 s.30 new live methods pass in 31.480 s;
96 combined current-rule/balance/geometry checks pass in 101.225 s.** Twelve
ordinary complete API/CLI captures and fresh reproduction pass, including
five complete hash-seed 401 and five 80-digit/17 ms/reversed-participant controls.
Independent HP/healing/life, zero-damage utility, binding identity/work/expiry,
terrain-credit and paired-knock checks pass. Prior equilibrium and ground-chain
capture packages replay unchanged.

**Authored rules:** G140/A220,60 m/s release after throw, selfO160/U180 at
midpoint, target O/U110 on impact,Db2,8m lower-body freeze for 10 s/B3 and 9 s cooldown.
The throw is intrinsic momentary; released binding is independent. Under
delegation, use 200 blunt on physical contact because no amount is authored,
with no added area HP damage; the listed target status applies only at direct
contact. Native U/10 gives193 contact output in the
canonical case; the binding retains full strength. Pay 4 at D0 and start the
cooldown at throw end. Neutral right-hand/2cm geometry and faster compensated
arc reuse existing rules. Actual unreachable aims use a paid ballistic miss.

**Burst and interactions:** a physical body, Block, floor or wall collision
selects every living body overlapping the closed 8 m sphere once, including
allies/caster. Delegated cover-transparent binding follows the everyone-in-area
wording; physical damage still uses normal shields/armor/terrain. Each physical
copy gets one independent burst, with pinned radius/strength/duration/status
and root power. Damage resolves in its shared wave; binding attaches after
healing/death, rejecting a dead/new-life recipient. There is no fabricated
explosion at a dead target's old location.

Lower freeze cancels voluntary lower-body control and paid Get Up/climb while
preserving native inertia, flight/landing and legal upper-body fire/holding.
Actual holds still receive summed-stat heavy knocks together. Two real casts
and separate casters retain independent effects, expiry and Break work; upper
mark freezes can coexist. The source may die after release without erasing
flight or binding. Actual gun death/revival retires the old recipient freeze.

**Diagnosis/preservation:** initial failures came from fixture assumptions
about walking direction and a helper copying another character's Block/fire
policy. An audit used an unsupported history-query keyword; that diagnostic
is retained. Thirty corrected methods, captures and final full suite pass.
All 4523 prior result files and 14 primary ODTs are unchanged; no historical
manifest is refreshed. Only current 1E3 ability2/metadata and the impact mode/
ownership are added. Existing character stats and other abilities stay intact.

**Next concrete step:** actual 1E3 prison projectile and a hollow physical
4000-HP cube, shared HP across faces, 12 s expiry, attacks blocked from inside
and outside, ordinary destruction/support/life behavior. Do not replace the
enclosure with an intangible freeze or invent a binding value. Portals,
duplication, leap/kick, charge/wall slam, remaining kits, broader support/turning
and final 5v5 remain unfinished; advanced NPCs and mass/balancing automation
stay deferred. This is a bounded verified checkpoint with a durable handoff.

## Verified checkpoint — equilibrium, prone geometry and common Get Up

2026-11-02. **Goal active and incomplete.** The appended collision-source
formula now executes in the selected moving world. Source-rate balance loss,
six-part prone geometry, concurrent crouching and paid Get Up use shared
contacts, aiming, fields, actions, forces and lives. No new abilities or
animations. [Rules/decisions](EQUILIBRIUM.md) · [Evidence](results/equilibrium/README.md).

**2207 full-suite tests pass in 580.685 s. All 66 focused checks pass in
68.279 s: 26 pure and 40 live methods.** All six Get Up profiles execute on
actual geometry. Twelve ordinary complete API/CLI captures and fresh
reproduction pass, with five complete hash-seed 401 controls and five combined
80-digit/17 ms/reversed-participant controls. Independent committed-polynomial,
HP/healing/life, material/support and initial-state checks pass. The existing
30-second 2v2 also matches its complete default CLI/API trace, with the first
team's 1000-HP shields and independent HP/life/balance audits. The current
public wall demo also matches API/CLI output: three 2000-HP walls, five gun
contacts destroy wall 1, later shots pass through, no terrain recovery credit.

**Source and delegated choices:** while both O/U are positive, integrate live
1/tF with their existing decay; partial loss recovers at the zero-status base
rate. Full knockdown requires the existing paid Get Up. Convex standing/crouch/
prone weights keep concurrent pose geometry piecewise quadratic, with a shared
lowest support plane. These are collision proxies, not rigid rotation. Current
hands/Block follow that pose; centre/size acceleration reaches body sweeps,
straight/curved projectiles, owner clearance and fields. Saved reference paths
remain the only translation writer. Exact interval coefficients and committed
versus planned ends are inspectable in every current result.

**Real interactions:** an actual Block counter causes a full fall and paid
recovery. Existing gun/Qard/beam, mark/freeze/Break, thrust/venom/replacement/
healing/revival, alternating arms/passive/Ultimate, holds/Break, dashes, both
chains and actual held-pair heavy knocks compose. Grapple knock resistance
still sums only real members' stats. Released effects survive controller falls;
owned holding ends when its controller is interrupted. Native flight/finite
forces survive knockdown. New-life completion is generation-bound.

**Diagnosed corrections:** own pose changes no longer look like imposed climb
displacement; actual external motion still interrupts it. Mapped hand Recovery
now emits serializable numeric records. Failed pose probes save the held driver,
preventing a retry storm; unchanged static cover does not poll every 5 ms.
Moving blockers retain independent retries, tested against observation and
precision changes. Standing clearance uses the actual balance pose before
payment. A restored down actor prioritizes Get Up independently of a delayed
weapon policy, without accepting its old paid completion.

**Preservation/coverage boundary:** all 4407 earlier result files and fourteen
current primary ODTs are unchanged. No historical manifest is refreshed. The
previous four wall, ten ground-chain and ten chain-cast capture packages replay
unchanged. Only current locomotion data adds equilibrium/Get Up ownership;
character/standing-body/movement/terrain data remain unchanged. Ten older
numerical/phase test modules explicitly select their pre-equilibrium v2 rules;
the 40 new live methods and public captures exercise current defaults. Frozen
inputs without equilibrium retain prior upright behavior.

**Next concrete step:** 1E3's authored lower-body ice bomb, using shared
projectile/area/binding and common Break, then its physical 4000-HP prison cube.
Preserve separate source/recipient/collider lives and explicit physical geometry.
Remaining charge/grab/wall slam, portals/duplication, other kits, ledge/turning
geometry and final reproducible 5v5 remain unfinished. Advanced NPCs and mass/
balancing automation stay deferred. Stop this coherent increment after its
integrity audit; do not start another large subsystem without verification and
handoff capacity.

## Verified checkpoint — destructible walls and 1E1 ground chain

Last updated **2026-11-02. Goal active and incomplete.** Author-requested
**three 2000-HP walls** now work in a selectable variant of the existing arena.
Blunt, slash, Qard, heat, constriction and tear share each wall's HP pool.
Real gun/punch/Qard/beam deliveries use common damage and collision removal;
constriction/tear are explicit typed object-API probes, not invented wall grabs.
[Wall decisions](DESTRUCTIBLE_WALLS.md) · [Evidence](results/destructible-walls/README.md).

**2141 full-suite tests pass in 494.565 s; 96 combined interaction checks pass
in 29.574 s.** Twenty wall methods, seventeen live ground-chain methods and
eight pure fixed-point methods are new. Four wall and ten ground-chain ordinary
complete API/CLI captures and fresh reproduction pass, with five complete
hash-seed 401 and five combined 80-digit/17 ms/reversed-participant controls.
The previous ten-capture chain package replays unchanged. Independent actor
HP/healing, construct clipping, fixed separation and exact interval certificate
audits pass. [Integrity gate](results/destructible-walls/verify_integrity.py).

**Walls:** delegated placement gives three 8 × 0.4 × 3 m panels (one rotated),
zero armor, no expiry, body/projectile blocking and area-transparent material.
Immutable wall tags prepare the future charge's qualifying destruction without
replacing its creative condition with ordinary 700-damage wall HP loss. The
original three-cube preset and permanent floor remain unchanged. Terrain now
accepts positive cuboid HP in the current mutable world. Typed object damage
accepts all requested families, including the combined `constriction_tear`
name, clips at zero and grants no actor healing/revival credit.

**Diagnosed area gap:** initial direct wall hits worked, but delayed Qard
blasts selected only characters. Current `fixed_compound_v2` now selects each
live overlapping object once across its parts, respects cover, shares same-time
HP clipping and excludes already destroyed objects. Version 1 keeps its frozen
behavior. Tests cover nearby walls without direct contact, duplicate parts,
destruction before a mark detonates and three simultaneous blasts. Earlier
complete captures and the passing 2119-test pre-area run are preserved.

**Goal continuation:** [1E1's actual ground chain](GROUND_CHAIN.md) now uses
typed constant surface endpoints in the same distance planner, never fake
fighters or arbitrary anchor mass. Authored G180/A220, 30 m/s, 10 m/15 s/B6,
self O/U160, target O/U80 and Db3.5 are imported; delegated release-end payment/
cooldown and neutral-hand geometry match the existing throw architecture.
Flight is ballistic; its 10 m binding length is not a caster-relative range.
Caster death preserves released/attached ground binding; recipient life,
common Break, collider geometry/removal, expiry and external separation retire
binding/anchor/distance once together. Exact reference reconciliation is bounded
below contact resolution; fixed points receive no forces or knock stats.
[Ground-chain evidence](results/ground-chain/README.md).

Real running reaches the fixed sphere; real hold/heavy-punch still assesses
only held B/D's summed stats. Actual climbing selects the roof, a beam destroys
its 2000 HP, and anchor release/support loss/falling/landing share the native
world clock. Nonlethal anchor damage preserves geometry identity. Actual
source death, recipient revival and separate duplicate expiry pass. No temporal
accuracy, energy conservation or universal rational-size guarantee is claimed.

**Preservation and source revision:** 4270 pre-wall and 4265 pre-ground-chain
result files are unchanged; no historical manifest is refreshed. Existing
character stats/abilities remain unchanged apart from importing authored 1E1
ability 2 and making 3E5's existing flight policy explicit. The final source
audit found an appended equilibrium rule in `Collision details.odt`, separate
from these implementation edits: `tF = 1500/(1+(O+U)/400)` ms. All earlier
paragraphs/formulas and the other thirteen ODTs match the previous checkpoint.
Both versions are preserved. **This new equilibrium loss is not implemented.**
[Source comparison and pending work](SOURCE_UPDATES_2026-11-02.md).

**Next concrete step:** integrate that equilibrium-loss rule with shared prone
geometry, interruption, clearance and Get Up, including changing statuses and
independent actions. Then use the delivered projectile/area/binding machinery
for 1E3's lower-body ice bomb and physical 4000-HP prison. Charge/grab/wall slam,
other remaining kits, broader ledge/turning geometry and 5v5 completion remain
unfinished; advanced NPCs and mass/balancing automation stay deferred. This is
a bounded verified checkpoint with capacity reserved for review and handoff.

## Previous verified checkpoint — actual 3E5 chain

Last updated: **2026-11-02. Goal active and incomplete.** Current verified
increment: **actual 3E5 chain cast, released contact payloads and spatial binding
with common Break**. Full six-kit/5v5 completion remains unfinished.
[Rules/decisions](CHAIN_CAST.md) · [Evidence/reproduction](results/chain-cast/README.md).

**2096 full-suite tests pass in 472.829 s. All 35 focused methods pass in
20.208 s:** 30 live chain checks and five pure distance-event checks. The
initial 162 interaction checks, 42 payload/bridge checks and eleven final
terminal/timing checks also pass. Ten ordinary complete API/CLI captures and
fresh reproduction pass, with three complete hash-seed 401 controls and five
combined 80-digit/17 ms/reversed-participant controls. No engineering attachment
supplies those captures' chains. Independent HP/healing/life, live distance,
last-plan coefficient and actual grapple knock audits pass.

**Delivery and choices:** existing ability 2 uses G180/A220, 30 m/s gravity
flight, self O/U120 at midpoint, target O/U60 on physical body contact, Db3.5,
B6, 15 s binding and 20 m separation. Under delegation, pay 12.25 and start the
9 s cooldown at throw end; use the neutral right-hand pose and existing 2 cm
projectile. It is a damage-free contact, with no invented HP/armor/shield loss
or damage credit. Independent Block/terrain intercept it. The casting hand is
released after throwing; subsequent binding is autonomous, with common Break
and separate instance clocks. Two actual casts coexist.

**Shared architecture:** released range/binding/status payloads are pinned and
copied with projectile identities. A live original caster supplies a moving
20 m flight envelope; first outward crossing ends flight without impact. Actual
body reference separation and both living endpoint generations gate attachment.
Binding and distance-row release are linked once at one timestamp; Break,
expiry, death, restoration and external separation retain native life/force
behavior. Source death preserves released flight/contact but ends the physical
anchor's binding. This lifetime choice is delegated, not a global summon rule.
The actual hold/chain/heavy-punch encounter preserves the author's summed-stat
knock resistance for actual grapple members; tether-only actors share motion
without joining that assessment.

**Diagnosed corrections:** a same-tick maximum-extension event originally
removed a projectile before physical impact; impacts now win. The first full
2093-test run exposed seven errors in an intentionally minimal gravity bridge;
opt-in released payloads remove that new interface dependency. An intermediate
2095-test run passed before a real 150 m target exposed unsupported aim. An
explicit reachable proxy now yields a paid miss for algebraically unreachable
opponents, while reachable faster arcs remain unchanged. Contact prediction
also stops at the actual terminal boundary, avoiding errors on a future path
that the projectile never follows. Solver failures are not masked. Before-fix
logs and both earlier capture versions are retained, including routine import
corrections; final canonical records are the ten top-level run files.

**Preservation:** previous persistent-distance and saved-body-path capture
packages and the principal-review correction matrix replay unchanged. All 4179
prior result files are unchanged; no historical manifest refreshed. All 14
primary ODTs, the other five profiles and 3E5's existing stats/abilities stay
unchanged. Character data imports only authored ability 2/reviewed metadata;
locomotion data adds its ownership mapping. Eight frozen inputs match current
root rules. The [integrity gate](results/chain-cast/verify_integrity.py)
fingerprints final source, tests, inputs, docs and evidence.

**Next concrete work:** typed fixed-terrain endpoints and 1E1 ability 2, the
10 m/15 s ground chain. Primary details are G180/A220, speed30, Db3.5/B6,
self O/U160, target O/U80 and overview cooldown9 s. Reuse released contact,
binding/Break and saved paths, while separating physical anchor/collider
lifetime from caster attribution. Its binding length is not automatically a
caster-relative projectile range. Select/document the actual ground attachment
point and failure policy. Add fixed endpoints to the joint solver explicitly,
rather than simulating immovable anchors with arbitrary huge character stats.

Other kits, environmental grappling, freeze/construct/portal/duplication casts,
leap/kick, charge/slam, turning/support/prone geometry and reproducible 5v5 remain
unfinished. Advanced NPCs and mass/balancing automation remain deferred.
This is a bounded verified checkpoint; the full Goal remains active.

## Previous verified checkpoint — live persistent distances

Last updated: **2026-11-02. Goal active and incomplete.** Current verified
increment: **live persistent distance limits on shared saved body paths**.
Engineering attachments now run in the world; **3E5's actual chain cast and
binding/Break attachment remain unfinished**. Resumed after the author's pause.
[Rules and decisions](PERSISTENT_DISTANCES.md) ·
[Evidence/reproduction](results/persistent-distances/README.md).

**2061 full-suite tests pass in 451.293 s. All 40 focused checks pass in
152.675 s:** 34 live interaction methods and six pure force-response methods.
Ten complete engineering API captures and fresh reproduction pass, including
actual hold/heavy punch, gun/Block, beam, death and redirected dash landing.
Three complete hash-seed 401 and three combined 80-digit/17 ms/reversed-actor
controls pass. A 0.5 s free-orbit comparison at 5/2.5/1.25 ms halves position
error at each refinement; default error is 1.5765513e-5 m. Energy/velocity error
is measured for that case, without a universal temporal/conservation claim.
Independent last-plan coefficient audits cover full planned intervals and mark
the actually committed prefix; intermediate certificates are not all archived.

**Author rule reaffirmed:** actual grapple participants receive knockback
together, using summed maximum HP/current armor before nonlinear resistance.
Back/away are synonyms; up/down specify direction. The real held-pair case sums
to 29080 HP and 515 armor and applies equal increments without a second weight
division. Its tether-only fourth actor shares constrained motion without
joining that resistance group. [Rules](KNOCKBACK.md).

**Architecture:** certified quadratic prefixes now serve body, terrain,
projectile, Block and field queries plus one advancement writer. Actual slack
crossings use the constrained candidate; inward freedom remains legal. Taut
participants expand through real grapples/resolved body contacts. Independent
5 ms/0.001-relative-travel knots, bounded inward reconciliation and downward
clock rounding preserve geometry independently of observations. Desired ground
pace stays separate from transmitted inertia. Finite forces share the selected
linear response, base offset once, retaining individual life/expiry. Native
gravity, climb interruption, paid landing and independent action owners remain
coherent. Real pause/freezing ownership, special stop and ground/air checks pass.

**Diagnosis:** independent inputs fixed an early linked-drive regression.
Clock rounding, unrelated solver participants, quiescent imposed metadata and
launch restoration also required correction. An initial 2060-test run passed
before final review found a real slack-contact cache defect: the 175 ms impact
was forgotten at first tension, charging a second at 287.5 ms. Cache identity
now initializes before contact admission. Four contact checks and a complete
capture pass; restoring just the old method makes the new regression fail.
Earlier diagnostics and the first nine-capture check record remain preserved.

**Preservation:** saved-body-path complete API/CLI encounters, numerical-distance
captures and the principal-review correction matrix replay unchanged. All 4103
earlier result files stay unchanged; no old manifest refreshed. All six
characters and 14 primary ODTs are unchanged. Eight frozen inputs match root
rules; only current locomotion data gains the explicit distance mode and three
numerical settings. Frozen inputs without it retain prior behavior. The new
[integrity gate](results/persistent-distances/verify_integrity.py) fingerprints
final source/tests, inputs, documentation and evidence.

**Next concrete work:** deliver 3E5 ability 2 through shared action/projectile/
effort/cooldown/life systems: 30 m/s chain, G180/A220, Db3.5, self O/U120,
target O/U60, B6, 15 s binding, 20 m maximum separation and 9 s overview cooldown.
Add a spatial binding kind with common Break rather than a freeze restriction.
`binding_effects.queue_mark` requires positive damage and cannot stand in for
a damage-free chain contact. Extend shared contact/effect delivery and link
Break/end/endpoint lives to distance-row release atomically; document impact
range and source-life policies. Preserve independent action ownership.

Other kits, turning/support/prone geometry and reproducible 5v5 remain
unfinished. Advanced NPCs and mass/balancing automation remain deferred.
This is a bounded verified checkpoint; the overall Goal stays active.

## Previous checkpoint — certified finite distance planner

Last updated: **2026-11-01. Goal active.** Current verified increment:
**certified finite distance-path planner and large exact-ratio reporting**.
This is a numerical prerequisite. **The live world does not yet run a persistent
tether controller or 3E5's chain cast.** Full six-kit/5v5 coverage remains unfinished.

**2021 full-suite tests pass in 300.114 s. All 35 focused checks pass in
1.020 s:** 28 new methods and seven existing immutable-path methods. Forty
random affine problems match an independent exhaustive-face KKT oracle. Nine
complete numerical path captures pass independent coefficient/feasibility/JSON
audits, with four complete hash-seed 401 controls and four combined 80-digit/
reversed-input controls. Fresh reproduction passes. These are pure planner
calls, not new combat/CLI chain encounters. [Rules/decisions](DISTANCE_PATHS.md) ·
[Evidence/reproduction](results/distance-paths/README.md).

**Numerical delivery:** an origin-feasible affine QP handles nonzero bounds and
dependent active directions with exact dual pivots/certificates. Supporting-plane
finite-distance projection brackets the true weighted optimum; feasible radial
scaling and strong convexity certify its default 1e-10 m/s error budget without
spending that budget on overstretch. Retaining only active supporting planes
keeps degenerate refinement small while preserving its lower bound. Exact
whole-interval Bernstein coefficients certify quadratic reference paths, with
a maximal certified blend toward the initial tangent. Tests reproduce a naive
legal-endpoint curve overstretching while the certified curve remains inside.
Grapple/contact/distance cycles, unequal gravity and ten-body graphs are covered.

**Real reporting correction:** the ten-body case has a coefficient numerator of
43037 bits. Ordinary Fraction string conversion exceeds Python's integer-text
guard. Local Decimal-based exact ratio formatting/parsing now round-trips every
digit while leaving that guard enabled and unchanged. `BodyPathPiece.from_record`
reads the same decimal ratio format; ordinary historical records are identical.
Existing runtime changes are limited to body-path and unilateral-projection
records. The new planner is not selected by the live backend.

**Diagnosis:** the initial focused run corrected a Fraction-to-Decimal reference
fixture; no production formula changed. An initial 2020-test run passed before
the ten-body record exposed the reporting bug. The final 2021-test run includes
that regression and final correction. Diagnostics and existing captures are
retained; capture creates missing files only and refuses different replacements.

**Preservation:** complete earlier saved-body-path API/CLI encounters and the
projection numerical/API package replay unchanged, including real held-pair
knocks. The principal-review correction matrix passes. All 4073 pre-existing
result files remain unchanged; no old manifest refreshed. This turn replays
those selected packages, not all earlier packages again. Runtime data, all six
character definitions and primary ODTs are unchanged. The new
[integrity gate](results/distance-paths/verify_integrity.py) fingerprints final
source, tests, inputs, docs and evidence.

**Next concrete work:** integrate the finite planner into a persistent saved-path
controller. Select and test a temporal rule with physics/error knots independent
of observations; the geometric certificate alone does not prove temporal
accuracy or energy behavior. Split at actual slack-to-taut activation rather
than pulling early from a prospective endpoint. Reconcile bounded-precision
state without losing the bound, preserve inertial airborne versus desired ground
drivers, and verify tangential motion, gravity, support and joint contacts.

Transport each finite-force component through the same selected response, with
the affine curvature offset counted once in the base response; expiry must
remove only retained/transmitted shares. Do not repeatedly invoke external
velocity replacement, which cancels control and retires impulses. All body,
terrain, projectile and field consumers must use those same committed paths.
Then deliver 3E5's actual 30 m/s chain, G180/A220, Db3.5, B6, 15 s binding,
20 m maximum separation and common Break through the shared action/projectile/
life systems. Do not replace slack/tangential motion with rigid equality.

Ice bomb, prison cube, portals, duplication, leap/kick, charge/slam and full kits
remain unfinished. Keep ledge/dynamic-support/facing/prone/Get Up guards until
those paths work. Advanced NPCs and mass/balancing automation remain deferred.
This is a bounded verified checkpoint; the overall Goal stays active/incomplete.

## Previous checkpoint — saved polynomial body paths

Verified **2026-11-01**. Increment:
**saved polynomial body-path prefixes shared by prediction and advancement**.
Persistent curved tethers, the chain cast, complete six-kit interactions and
general 5v5 remain unfinished.

**1993 full-suite tests pass in 302.604 s. Eighteen focused checks pass in
3.921 s:** seventeen new methods and one strengthened existing projection
regression. The initial 148 interaction checks and 51 knock/counter/resistance
checks also pass. Ten complete API/CLI captures (nine ordinary encounters and
one labelled external-motion engineering probe), four complete hash-seed 401
controls and five combined 80-digit/137 ms/reversed-participant controls pass.
Fresh final-code reproduction passes. [Architecture](BODY_PATHS.md) ·
[Evidence/reproduction](results/body-paths/README.md).

**Author rule retained and verified:** actual grapple participants receive
knockback together, using summed maximum HP/current armor before the nonlinear
resistance term. Knock away/back are synonyms; up/down are directions. The real
held-pair capture receives a heavy punch and upward counter, checks equal
increments without a second weight division, and retains released motion after
hold expiry until landing. The pair sums to 29080 maximum HP. This does not
combine damage/status recipients, turn a binding chain into a grapple or
deliver the unfinished downward kick. [Rules](KNOCKBACK.md).

**Architecture:** immutable rational reference polynomials supply existing body,
terrain, projectile, Block and area/field queries and one position writer.
Pose deformation stays separate. Saved driver state preserves ground speed,
gravity, grapple sharing and landing obligations. Observations retain the
prefix; semantic events/motion knots bound its lease. Same-time status/driver
changes, armor, support, groups and life invalidate it coherently. Matching
tolerance 1e-35 reconciles upstream Decimal roundoff; no new curvature solver
or accuracy guarantee is implied. Canonical climb segments retain exact source
corners/endpoints. A test disables the old writer while actual walk/jump works.

**Diagnosis:** the first focused run corrected fixture assumptions about the
instability divisor and querying a zero-duration lease before pending phases.
The first full run exposed an old test comparing velocity strings: legacy
`"2.00"` and `"2"` were both numerically 2 m/s. It now commands genuinely
different running motion and compares numeric 6.4 versus 2 m/s. No production
formula was changed to satisfy that fixture. The capture harness also corrected
a nonexistent cooldown-field event name. Diagnostics and earlier captures are
retained; capture creates only missing files and refuses differing replacements.

**Preservation:** all 24 preceding capture packages and three unchanged review
regressions pass. All 3998 pre-existing result files remain unchanged; no old
manifest refreshed. Eight frozen inputs match current rules. Only the current
locomotion JSON gains `body_paths.mode=saved_polynomial_v1`; character data,
primary ODTs and other runtime inputs are unchanged. Frozen definitions without
the mode retain their original advancement and result shape. The new
[integrity gate](results/body-paths/verify_integrity.py) fingerprints the final
source, tests, docs, inputs and evidence.

**Next concrete work:** add a persistent constrained-path backend to the saved
prefix interface. Physics knots must be independent of observations. Verify
slack-to-taut crossing, inward release, rotating tangents, gravity and joint
terrain/grapple constraints. Transport each finite-force component through the
same response so expiry removes only its retained share; do not repeatedly use
external velocity replacement, which intentionally cancels body control and
retires replaced impulses. Then deliver 3E5's real 30 m/s chain, 15 s binding,
20 m maximum separation and common Break through the existing world.

Ice bomb, prison cube, portals, duplication, leap/kick, charge/slam and full kits
remain unfinished. Keep ledge/dynamic-support/facing/prone/Get Up guards until
those paths work. Advanced NPCs and mass/balancing automation remain deferred.
This is a bounded verified checkpoint; the overall Goal stays active/incomplete.

## Previous checkpoint — joint radial/contact projection

Verified **2026-11-01**. Increment:
**joint radial/contact velocity projection through atomic spatial APIs**.
This is an instantaneous foundation; **3E5's persistent chain is not delivered**.
Complete six-kit interaction coverage and general 5v5 remain unverified.

**1976 full-suite tests pass in 284.789 s. All 31 focused checks pass in 0.725 s:**
23 new methods and eight existing projection regressions. An independent
exhaustive face oracle covers 40 small graphs. A separate audit passes 48 exact
stationarity/feasibility/complementarity/energy/order checks for 2/3/6/10 bodies.
Five exact numerical captures and two complete labelled engineering API captures
pass with three complete hash-seed 401 controls and two combined 80-digit/17 ms/
reversed-participant controls. [Rules/boundaries](TETHERS.md) ·
[Evidence/reproduction](results/tether-projection/README.md).

**Mathematical foundation:** taut limits remove outward relative radial motion
while preserving allowed inward/tangential components. One-sided contacts,
existing grapple equalities and bilateral blocked directions are solved jointly.
The delegated sharing weights reuse current maximum-HP/armor body weights.
Exact rational arithmetic, canonical rows, a nonnegative dual active set and
checked certificates avoid order-dependent pair corrections and singular
redundant cycles. Decimal presentation owns its precision; trace ratios retain
exact strings. No character stats, abilities, costs or runtime rule data change.

**Shared API scope:** optional `taut=`/`contacts=` parameters extend the existing
atomic prepare/commit interface. Actual grapple groups expand once with live
participant snapshots. Invalid endpoints/lives and stale plans cannot partially
write the world. Probes verify actual body movement, compatible firing and a
real 1E5 hold retaining its control/damage stream. The legacy solver path remains
when no new constraint is supplied. These external velocity-replacement probes
are engineering operations, not a chain projectile or a persistent binding.

**Diagnosis:** the first shared probes referenced nonexistent stream `status`
and transition `history` fields; fixtures now inspect `ended_at_ms` and `records`.
Complete capture then exposed a real JSON reporting defect: exact Fractions
escaped the world formatter. The record now serializes exact ratios as strings;
a shared-world JSON assertion and complete captures pass. Before-fix diagnostics
and the earlier numerical full-suite run are retained. Existing captures were
compared without replacement; only missing capture files were created.

**Preservation:** all 3962 pre-existing result files are checked unchanged, with
no historical manifest refreshed. Two preceding frozen capture packages and the
review-correction regression pass against the final source. Eight captured
inputs match root rules; all runtime data and primary ODTs are unchanged.
The final integrity gate records this foundation's source/tests/docs/evidence.

**Next concrete implementation:** saved constrained body-path prefixes shared
by body, terrain, projectile and area/field queries. Physics knots must be
independent of observations; invalidate predictions coherently on action,
force, support, armor-weight and life changes. Keep gravity, landing obligations
and per-force expiry/transport consistent. Verify slack→taut crossing and
curved tangential motion before delivering 3E5's actual 30 m/s chain, 15 s binding
and 20 m maximum separation. Instantaneous radial projection alone permits
second-order distance growth and does not supply that path. The current air
controller separately writes ballistic z; a velocity-only override is insufficient.

Binding/Break and 1E3 marking remain verified below. Ice bomb, prison cube,
portals, duplication, leap/kick, charge/slam and full kits remain unfinished.
Keep ledge/dynamic-support/facing/prone/Get Up guards until those paths work.
Advanced NPCs and mass/balancing automation remain deferred. Goal active and
incomplete; no chain/5v5 completion claim.

## Previous checkpoint — shared binding and marking projectile

Verified 2026-11-01. Previous increment:
**shared binding/Break and actual 1E3 marking projectile**. Complete six-kit
interactions and 5v5 remain **unverified**.

**1953 full-suite tests pass in 289.430 s. All 35 new focused tests pass in
7.462 s:** five pure threshold and thirty shared-world interaction checks.
Ten complete ordinary API/CLI captures, three complete hash-seed 401 controls
and five combined 80-digit/137 ms/reversed-participant controls pass. Fresh
reproduction against the final code passes. [Rules/decisions](BINDINGS.md) ·
[Evidence/reproduction](results/binding-marks/README.md).

**Actual delivery:** 1E3 ability 1 uses its 350 Qard, G140/A180, 100 m/s,
after-Active release and 1200 ms firing-end cooldown. Self O/U120 occurs at
midpoint; target O/U110 retains pre-hit mitigation. No unlisted recoil cost is
added. Real contacts refresh an 8 s source/life-specific mark pool; three marks
consume it for an independent 8 s upper-body freeze with binding value4.
Personal shields permit marks; independent Block must have positive overflow.
A fully intercepted or terrain-only hit cannot mark a body behind it.

**Shared binding/Break:** life-bound independent instances reuse selective
function restrictions and controlled-action cancellation, leaving released
attacks and independent effects alive. Real freeze cancels an actual hold and
its damage/effort stream while legal walking/jumping remains possible. Source
MathML gives `(20*B-H/500)^0.9`; the delegated floor keeps the power real.
Break fills at 20/s and pauses on disorientation. One focus prevents duplicate rates;
stop/resume retains that instance's progress. Lower/whole freeze attachment is
an API foundation, not ice-bomb/prison delivery. Physical force/gravity persist.

**Delegated cap interpretation:** attempted filling counts as escape work while
actual stored gains use the one capped resource writer. This keeps Break usable
at D100. Crossing the cap still adds the existing once-only O200 pause. Other
sustained channels retain their own behavior. Grapple response contests keep
their separate comparison, response window and penalties. Recipient death
retires marks, bindings and Break; revival inherits none. Source death after
release does not retract marks/freeze. The canonical Break at 3600 escapes about
5768.761890512 ms after later hits pause it; B4/H8140 requires about 42.05795872 work.

**Source import:** primary 1E3 already supplies its stats, Recovery250 and
shield/toxin bonus. The prior inventory omission is corrected. Source jump,
crouch, walk/run effects, climb and sprint values now use the shared basic
geometry/physics for all six characters. Missing hand coordinates and common
transition values use documented delegated defaults. Only 1E3's character
profile changes; primary ODTs are unchanged.

**Diagnosis and continuity:** the initial 1952-test run exposed four failures
and four errors in stale legacy-mode, missing-profile and five-profile movement
fixtures. Corrected fixtures retain their original guard intent; targeted and
full reruns pass. Focused probes corrected callback/facing/event/range/horizon
expectations and accounted for both real 2E4 Block layers. Diagnostics remain.
The author paused verification, then resumed; a later automatic approval review
failure reported a usage limit and interrupted its processes. Missing handles
and process state were checked before restarting the unfinished gates. The
completed final-code API/CLI replay was retained. No production formula was
changed to fit a fixture expectation.

**Preservation:** twenty-two previous capture packages, both unchanged five-method
principal reviews and the correction matrix pass. All **1276 historical files**
are unchanged; no old capture or manifest was refreshed. Eight frozen current
inputs match root rules and fourteen primary ODTs are unchanged. Only 1E3's
character definition changed. The [final integrity gate](results/binding-marks/verify_integrity.py)
records source/test/data/docs and evidence fingerprints without rewriting history.

**Next concrete work:** deliver 3E5's real 30 m/s chain with 15 s binding and 20 m
maximum length. Reuse shared
binding/Break, effort, life and projectile systems. Preserve slack and tangential
motion with a curved distance constraint; rigid grapple equality would change
the ability. Ice bomb, prison cube, portals, duplication, leap/kick, charge/slam
and complete kits remain unfinished. Keep ledge/dynamic-support/facing/prone/
Get Up guards until their paths work. Advanced NPCs and mass/balancing automation
remain deferred. The overall Goal remains active and incomplete.

## Previous checkpoint — conditional melee

Verified 2026-11-01. The Goal was active at this checkpoint. Verified increment:
**actual 3E5 conditional punches/upward counter and deferred branch cooldowns**.
Complete six-kit interaction coverage and general 5v5 remain **unverified**.

**1918 full-suite tests pass in 282.614 s. All 27 new focused checks pass
in 14.149 s:** 23 shared-world methods and four pure launch checks. Sixteen
complete API/CLI captures (thirteen ordinary, three labelled engineering motion
controls), four complete hash-seed 401 and five combined 80-digit/137 ms/reversed-
participant controls pass. [Rules/source decisions](CONDITIONAL_MELEE.md) ·
[Evidence/reproduction](results/conditional-melee/README.md).

**Actual delivery:** 3E5 ability 1 is one selectable action with b/right and
c/left 300-blunt punches, G140/A180, Db1.8 and source O/U. Counter a uses
600 blunt, G180/A220, Db3, O800/U800 target and O200/U200 self, with its own
4 s after-Active cooldown. Branch hand/cost/timing/power/status/knock are pinned
before admission and retained through the complete action and packet consumers.
Normal emission advances b/c even on misses; a leaves that cursor untouched.
The source normal-chain Recovery exception remains. Legacy scalar 1b is preserved.

**Delegated contextual policy:** documented actual dash/knock cause plus relative
closing motion selects a when its cooldown, functions/hands and capacity allow;
otherwise use a legal normal branch. A dash cause is separate from its owed
landing effects and is cleared by velocity replacement, retained by reference-
only relocation, and ended at actual landing. Contextual abilities.odt supplies
examples but no universal re-evaluation policy; no hypothetical execution move
was added. Source choices versus these delegated rules are explicit in the doc.

**Shared cooldown work:** paid Active start commits a deferred private counter
clock at the original Active end. Before-payment cancellation incurs no debt;
after-payment cancellation cannot bypass it. Pauses affect work after that
boundary, never the Active tail. Due work can be committed while its clock is
stopped, without resuming it; restoration resumes ordinary retained debt with
current pause membership. This resource receipt cannot replay an old-life attack.

**Upward physics:** resisted height uses the author's summed group stats and
`sqrt(2*g*P2)` launch increment under shared gravity, rather than the horizontal
500 ms window. The delegated counter response removes approaching horizontal
motion while retaining lateral/vertical motion; older force components are
projected too, so expiry cannot undo the deflection. Ballistic records close
on real support, replacement or recipient death. A real held pair launches
together; hold expiry retains survivor momentum. Existing jump/dash landing
obligations survive and apply once. Near-apex, Block, ceiling and real marking
cases pass. The ordinary knocked-target counter hits at 640 ms, starts its
cooldown at 750 and lands the target about 4100.321489 ms; a is ready at 4750.

**Verification/diagnosis:** real dash/knock/away/run/held/Block/ceiling/pause
interactions, an a while normal cursor points left, and unavailable-cost normal
fallback pass. Engineering controls verify cancellation/debt/life and stale
cause boundaries. The initial apex fixture incorrectly supplied a fractional
observation horizon; it now checks the last legal integer against the analytic
path. The capture harness's incorrect result key was corrected to `run_until_ms`;
existing frozen traces were verified and only missing files created. Diagnostics
are retained. No production formula was changed to fit those expectations.

**Preservation:** twenty-one prior capture packages, both unchanged five-method
principal reviews and the correction matrix pass. All **1182 historical files**
remain unchanged; no old capture/manifest refreshed. Eight current frozen inputs
match root files and fourteen primary ODTs are unchanged. Only 3E5's character
definition changed in this increment.

**Next concrete work:** shared binding instances and Break from
`Binding abilities.odt`, including its embedded maximum-HP threshold and 20/s
filling paused by disorientation. Then deliver 3E5's actual chain projectile:
30 m/s, 15 s binding, 20 m maximum length, taut opposing-direction movement.
Keep binding independent from rigid grapple links/response contests. Reuse
effort, life, projectile and constraint systems before other freeze/binding
deliveries. Leap/kick, charge/wall slam, portals and complete kits remain
unfinished. Keep ledge/dynamic-support/facing/prone/Get Up guards until those
paths work; advanced NPCs and mass/balancing automation remain deferred.
This is a verified checkpoint; the overall Goal remains active.

## Previous checkpoint — heavy punch, finite knocks and elasticity

Verified increment at this checkpoint:
**actual 3E5 heavy punch, additive finite knocks and temporary elasticity**.
Complete six-kit interaction coverage and general 5v5 remain **unverified**.

**1891 full-suite tests pass in 268.248 s. All 21 new focused checks pass
in 3.361 s.** Eighteen complete API/CLI captures (sixteen ordinary and two
labelled engineering external-motion cases), four complete hash-seed 401
controls and five combined 80-digit/137 ms/reversed-participant controls pass.
A fresh replay and a separate exact expiry/contact probe at both precisions
pass. [Rules/source decisions](KNOCK_DELIVERY.md) ·
[Evidence/reproduction](results/knock-delivery/README.md).

**Actual delivery:** existing 3E5 ability 4 now uses shared hand-origin melee
contact, G180/A220 midpoint impact at 290 ms, 600 blunt damage, Db3,
O/U snapshots and independent 9 s cooldown. Full Active ends at 400 ms; a
whiff still costs/cools down. Positive power reaching a body releases a force;
an independent Block surface can intercept it. Personal shield stock does not
replace body resistance or cancel physical knock. All primary source values
and the existing legacy 1b scalar path remain unchanged.

**Delegated force model:** use a configurable 500 ms velocity component covering
the resisted nominal 15 m on a stationary unobstructed body. Add it to physical
velocity, retain vertical motion/gravity, and keep each impulse's own source/
action/life and expiry. Contact linearly transforms stored components alongside
the body; expiry removes only that transformed contribution. Simultaneous and
staggered overlaps compose without a global force lock. The latter see armor
lost to earlier punches. Temporary lower-body restrictions prevent walking/
stopping/dash from erasing force; upper-body actions remain independent.

**Author group rule delivered:** after the full hit/heal/death/hold-settle wave,
query the actual living grapple component, sum its pre-batch maximum HP/armor
snapshots, evaluate resistance once and impose one common velocity without a
second weight division. Real 1E5 holds now receive the actual heavy punch.
Release leaves imposed force on survivors; contacts transmit reflection to the
group but penalize only actual contacting bodies. Death/escape/fatigue which
already released a link changes application membership. This causal ordering
and the 500 ms window are delegated choices, distinct from the author rule.

**Elasticity/lives:** 100% reflects the contact-normal velocity, preserving
tangents, with the existing pre-contact penalties. Wall/body/ground interactions
use existing sweeps; a real descending jumper bounces without a fake landing or
new cost, then eventually pays its original landing effects once. Exact force
expiry precedes a tied wall contact. A released impulse survives its source's
same-batch death; recipient HP death retires its component. Explicit external
velocity replacement retires the old force without a later undo, while reference-
only relocation keeps the clock. Separate lives do not inherit old components.

**Diagnosis:** the first staggered fixture assumed equal opposite travel;
traces identified source blunt armor loss, and the expectation now checks the
two defense snapshots. An admission audit then reproduced an actual stopping
bug: nominal speed zero bypassed restrictions while imposed velocity remained,
causing `ActionConflict`. The shortcut now checks imposed velocity and waits.
Before-fix diagnostics and the passing intermediate 20-method run are retained.

**Preservation:** twenty prior capture packages, both unchanged five-method
principal reviews and their correction matrix pass. All **1082 historical
files** remain unchanged; no old capture/manifest refreshed. Eight frozen
current rule inputs match root files and all fourteen primary ODTs are unchanged.
Only 3E5's character definition changed in this increment.

**Next concrete work:** implement 3E5 ability 1 as its real conditional action,
with alternating b/c blunt punches and upward counter a when the target's actual
dash/knock motion approaches the actor. Keep motion cause distinct from a pending
landing obligation; keep the counter's source 4 s cooldown anchored after Active.
Use gravity to achieve resisted upward height instead of copying the horizontal
500 ms window. Reuse shared contacts, forces, phase effort and life/group rules.
Leap/kick, charge/wall slam, binding, portals and complete kits remain unfinished.
Keep ledge/dynamic-support/facing/prone/Get Up guards until those paths work.
Advanced NPCs, mass experiments and balancing automation remain deferred. This
is a verified checkpoint; the overall Goal remains active.

## Previous checkpoint — existing dashes and shared body launch/landing

Verified increment at this checkpoint:
**actual 1E5/2E4 dashes through reusable shared body launch/landing**.
Complete six-kit interaction coverage and general 5v5 remain **unverified**.

**1870 full-suite tests pass in 263.866 s. All 28 new focused checks pass
in 4.150 s:** 24 shared-world interaction methods and four pure launch checks.
Sixteen complete API/CLI captures (fourteen ordinary and two labelled external-
motion probes), four complete hash-seed 401 controls and five combined 80-digit/
137 ms/reversed-participant controls pass. A fresh capture replay also passes.
[Rules/source decisions](BODY_LAUNCHES.md) ·
[Evidence/reproduction](results/body-dashes/README.md).

**Actual delivery:** both existing ability-3 entries now use the common action
policy, lower-body owner, payment gate and cooldown clock. G140/A150, Db2.5,
takeoff O80/U80 and landing O120/U160 retain the primary definitions; ranges
and cooldowns remain 13.5 m/5200 ms for 1E5 and 14 m/2850 ms for 2E4. Hands
remain independent, so compatible attacks and actual holds/Break can continue.

**Delegated trajectory:** launch at Active start with half base running speed
upward; solve horizontal speed for the documented same-height range. Active
is launch control, not forced landing. A standing 1E5 launches at 140 ms,
ends Active at 290 ms and lands at about 853.557594292 ms after travelling
13.5 m. Actual terrain/contact/link constraints decide the outcome. The simple
policy uses the saved requested enemy position, moving 1E5 away and 2E4 toward
it. Sprint is replaced by running at launch; prior ground pace resumes on
landing rather than adding momentum to nominal range. These are engineering
choices, recorded separately from author rules.

**Shared physics/lives:** basic jump and dash use one voluntary takeoff writer;
existing gravity, continuous body sweeps and contact/status snapshots remain
authoritative. An immutable life/action-bound landing obligation survives the
end or cancellation of launch control and external displacement, including an
imposed supported destination. Actual contact consumes it once. Death retires
it and revival cannot inherit it. Linked voluntary input is projected once;
landing restores prior ground drive instead of retaining dash propulsion.
This does not turn voluntary dash into the author's imposed group knock.

**Real interactions:** walls, teammate bodies, ceilings, an actual climb then
falling dash from cube_1, queued walking, running/sprint, independent arm attack,
real grab/hold, gun death, beam/shield/HP and cooldown-pause entry/exit pass.
Actual holding plus answered Break can invalidate pending dash payment safely,
without launch or cooldown. Explicit engineering restriction/force/restoration
controls verify post-launch cancellation and life boundaries. HP/healing/source
credit remains conserved. Initial failures were fixture assumptions about
immediate Break, shield dose and exact Decimal equality; their logs and the
earlier passing 1868-test suite are preserved.

**Preservation:** nineteen prior capture packages, both unchanged five-method
principal reviews and their correction matrix pass. Before/after hashes verify
all **989 historical files** unchanged; no old capture/manifest refreshed. The
eight frozen current inputs match root files and fourteen primary ODTs remain
unchanged. Only 1E5/2E4 character definitions changed in this increment.

**Next concrete work:** actual 3E5 knock delivery, starting with its upward and
heavy punches: causal impact/life membership, summed-stat grapple resistance,
nominal trajectory, finite 100% elasticity and real wall/body contacts. Keep
motion cause distinct from a pending landing obligation when implementing its
dash/knock counter condition. Reuse the shared flight/contact/group systems;
then address its charge/wall slam, binding and portals without erasing defining
features. Keep ledge/dynamic-support/facing/prone/Get Up guards until those
paths work. Advanced NPCs, mass experiments and balancing automation remain
deferred. This is a verified checkpoint; the overall Goal remains active.

## Previous checkpoint — common grapple Break and continuous escape

Verified increment at this checkpoint:
**actual common grapple Break/controller response and continuous escape**.
Complete six kits and general 5v5 remain **unverified**.

**1842 full-suite tests pass in 256.605 s. All 43 new focused methods pass
in 10.484 s:** 33 shared-world interactions and ten pure boundary/effort checks.
Seventeen complete API/CLI captures (sixteen ordinary and one labelled force
probe), three complete hash-seed 401 controls and nine combined 80-digit/
137 ms/reversed-participant controls pass. [Rules/source decisions](GRAPPLE_BREAK.md) ·
[Evidence/reproduction](results/grapple-break/README.md).

**Actual delivery:** common Break acts on real 1E5 holds through life-bound
`control_script` or the shared command API. Immediate equality escapes. A failed
comparison permits the configured half-open response window (default 150 ms);
the same-hold response starts fixed 20/s filling on both bars alongside normal
holding/sprint. Missing/late responses release that hold; duplicates cannot
extend the window or add channels. Per-contest private ownership permits
compatible independent movement/weapon actions and multiple contests.

**Continuous math:** the earliest satisfied comparison reads the same saved
resource prefixes that commit D. Interval bounds on analytic/dense derivatives
isolate interior/tangent roots across status, input, cap and polynomial knots;
there is no endpoint-only monotonicity assumption or observation tick. An
independent RK4 bar comparison agrees with the real answered escape near
1312.26499382 ms. Higher-priority state changes invalidate forecast escapes.

**Delegated rules:** comparison remains live during the response window. Every
answered-contest ending retains `3*A`, with A equal to both participants' actual
fixed Break gains on that link after caps, excluding holding/sprint and point
costs. Apply incoming O/U once to the living matching pair with individual
current defenses, after due phases/hits/contacts. No group stat aggregation,
running self multiplier, upfront Db or binding disorientation pause is added.
These selected rules are recorded separately from primary/author definitions.

**Diagnosis/iteration:** a real expiry/thrust tie initially extended Gathering
from a due Active start at 3190 ms to 3497 ms. Staged penalties now preserve the
3190 ms start. A rational deadline constructed under caller precision28 was
incorrectly accepted early; script/window clocks now use owned precision and
classify ties at 1e-24 ms resolution as the deadline. Both before-fix cases and
the passing intermediate 1840/1841-test runs are retained. Final verification
includes both corrections and the added continuous-death interaction.

**Real interactions:** source gun and continuous beam death stop contest filling
at the actual death boundary; the independent beam persists. Actual recipient
healing/revival cannot inherit old contests/commands. Real sprint and exhaustion
share one capped bar, while Break continues; an independent real gun can fail
payment safely during answered filling. Multiple holds keep separate owners,
actual-gain penalties and graph membership. Movement/group flight remain live;
HP, healing and source/life credit stay conserved.

**Preservation:** both unchanged five-method principal reviews and their
correction matrix pass. Eighteen historical packages replay unchanged; before/
after hashes verify all **867 files** unchanged. No historical capture or
manifest is refreshed. Eight new frozen rule inputs match current files and
all fourteen primary ODTs remain unchanged.

**Next concrete work:** inspect existing forced-movement/dash/knock delivery,
starting with remaining 1E5 ability 3, then implement reusable owned displacement
with real contacts and phase/life ordering. Source knock distance/resistance
alone does not specify a trajectory; preserve the author's grouped summed-stat
rule and 3E5 charge/slam/elasticity identity. Binding, portals and complete kits
remain unfinished. Keep linked-climb/ledge/dynamic-support/facing/prone/Get Up
guards until those paths work. Advanced NPCs, mass experiments and balancing
automation remain deferred. This is a verified checkpoint; overall Goal is active.

## Previous checkpoint — safe unpaid-action payment boundaries

Verified increment at this checkpoint:
**safe unpaid-action cancellation at its authored payment boundary**.
Complete six kits and general 5v5 remain **unverified**.

**1799 full-suite tests pass in 248.885 s. All 13 new interaction methods pass
in 0.862 s.** Eight complete frozen API probes, eight hash-seed 401 controls
and eight combined 80-digit/137 ms/reversed-participant controls pass.
[Rules/rationale](ACTION_OWNERSHIP.md) ·
[Evidence/reproduction](results/payment-boundaries/README.md).

**Reproduced and corrected:** continuous fixed filling could invalidate a
pending real gun's capacity, causing an unsupported-mechanic exception at
111 ms. The owned payment gate now cancels only that unpaid action and releases
its reservation, without a debit/receipt, new projectile, ammo/item/charge loss
or release-anchored cooldown. It runs before Active mutation for paid starts
and before end-phase emission. Previously applied statuses, paid costs,
released effects and independent action owners survive; successful ordinary
traces remain unchanged. Gun/Qard still check/pay at firing end, reload/grab/
melee at Active start. Existing jump/defer and sprint/special-stop paths remain.

**Delegated policy:** apply primary `Dyspnea details.odt` p23's unaffordable-action
rule transactionally at the existing author-confirmed anchor. Do not pay early,
clamp a cost, refund earlier work or prevent continuous effort from filling to
capacity to protect an old promise. A later legitimate retry follows ordinary
recovery/admission. Effortless activation still works at D100. The source and
character values were not changed. This is the prerequisite for Break filling,
not a claim that the source Break command has been delivered.

**Interactions:** real firing, Qard, thrust/blade supply, component cursor,
grab/cooldown, empty-magazine reload, real death-before-payment and full-bar
marking pass. A previously paid projectile hits after a later attempt fails.
A real 1E5 hold and its damage/effort remain active when the recipient's
independent gun payment fails. The budget fixtures are explicitly engineering
API controls; no new selectable ability or CLI fixture support is invented.
The initial harness's recovery/cooldown/schema assumptions were corrected,
with diagnostics retained.

**Preservation:** both unchanged five-method principal reviews and their
correction matrix pass. Seventeen historical capture packages replay unchanged. Before/after hashes
verify all **801 files** unchanged; fresh logs stay in the new evidence folder.
All eight frozen rule inputs match current files; primary ODTs are unchanged.
No historical capture or manifest is refreshed.

**Next concrete work:** actual common grapple Break/controller response:
validated per-link controls, half-open 150 ms response deadline, earliest
continuous escape/fatigue boundary, per-link actual-gain penalties and multiple
contests. Root basic Break has no separate listed activation cost; do not
confuse Get Up's doubled jump cost with it. Establish pending-window comparison
and termination-penalty ordering explicitly. Reuse the actual hold/link, shared
effort, payment, life and HP coordinators. Authored knock timing/elasticity,
3E5 charge/wall slam, binding, portals and complete kits remain unfinished.
Keep the existing linked-climb/ledge/dynamic-support/facing/Get Up guards;
advanced NPCs, mass experiments and balancing automation remain deferred.

## Previous checkpoint — actual 1E5 grab and owned holding

Verified increment at this checkpoint:
**actual 1E5 grab, owned holding, sustained damage and effort**.
Complete six kits and general 5v5 remain **unverified**.

**1786 full-suite tests pass in 247.005 s**, including the reproduced affine
zero-crossing correction.
All **84 focused checks pass in 13.680 s**: 81 new methods plus three existing
legacy dependency controls. Ten complete API/CLI encounters, three complete
hash-seed 401 controls and six combined 80-digit/137 ms/reversed-participant
controls pass. [Delivery/source decisions](GRAPPLE_DELIVERY.md) ·
[Evidence/reproduction](results/authored-grapple/README.md).

**Actual delivery:** selected 1E5 ability 2 uses its existing G100/A180 midpoint
contact: normal contact 190 ms, grab end/hand transfer 280 ms, hold expiry
3190 ms. A real first body/Block/solid decides contact; a miss cannot become an
assumed selected-target grab. The full grab tail keeps its left hand; a separate
owned hold starts at impact, then receives the hand/weapon atomically. Paid
receipts remain paid. Independent right-arm, enhancement and body actions work
when their explicit requirements permit; no global lock or new ability is added.
Attachment is staged after the complete simultaneous hit batch, so a dead source
or recipient cannot acquire a hold. Same-time lethal cases are verified.

**Shared damage/resources:** live intrinsic sustained pressure is `max(0,900-U/4)`.
Constriction/tear uses the primary `max(0,dps-25*armor^2/(4*dps))`; no unlisted
armor loss, bleeding or piercing is added. Root/affine recovery rates and the
existing joint shield/HP solver now compose it with heat, current armor, raw
shield absorption, proportional zero-stock interception and delayed recovery.
The same immutable HP curves fund healing/revival and clipped source/life
credit. One resource writer sums squared sustained rates plus explicit fixed
filling, allocates actual capped gains, triggers a full bar once and reanchors
solo sprint. Fixed filling APIs do not claim actual Break delivery.

**Delegated choices:** left neutral hand/1 m/2 cm proxy; static supported entry;
Db2 at grab Active start plus Dd2 during holding; 9 s cooldown from Active start,
including misses/interception. Holding lasts 3 s from real contact. Fatigue,
function restriction, source/target life, expiry or owner release ends its link,
stream and effort together. Later external forces retain the author's grouped
motion/summed-stat rule; each participant keeps individual damage/status defense.
Author ODTs and confirmed preferences were not rewritten as delegated decisions.

**Interaction evidence:** actual gun death stops controlled damage at the death
boundary; actual 2E4 healing and revival consume clipped histories without
reattaching an old hold to life 2. Two real grabs share motion while one owner's
hand restriction ends only its hold. Real heat and personal shields share one
balance. Actual walking drags and an engineering upward force moves both held
participants under gravity. Numerical/observation/order controls agree.

**Review/diagnosis:** initial broad verification found three legacy fixtures
that removed prerequisites while retaining new dependent modes; their original
assertions now run unchanged with coherent legacy configurations. Code review
then reproduced a new increasing-ramp edge case: an affine value clock had been
treated as activation, and the delayed plan omitted its true zero knot. Integral,
translation and knots are corrected together, with before/after evidence. The
prior passing 1785-test run is retained; the final run includes that added test.

**Preserved evidence:** both unchanged five-method principal reviews and the
existing correction matrix pass. Sixteen frozen combat/spatial packages replay
unchanged, including the 30 s 2v2. Before/after hashes verify all **722 files**
unchanged; no historical manifest or capture refreshed. Primary ODTs are unchanged.

**Next concrete work:** source common Break/controller-response: validated
commands, half-open response window, exact continuous escape/fatigue arbitration,
per-link actual-gain penalties and multiple contests. Resolve the existing
payment-phase failure guard before allowing concurrent Break filling to invalidate
an independent unpaid reservation. Reuse the verified owned-action, rate/HP,
shared-budget, life and group coordinators. Actual knock timing/elasticity,
3E5 charge/wall slam, binding, portals and other kits remain unfinished.
Keep prescribed linked-climb, ledge/dynamic support, fixed-facing/turning and
broader prone/Get Up boundaries until those paths work. Advanced NPCs, mass
experiments and balancing automation remain deferred. This session ends at a verified
checkpoint; overall Goal remains active.

## Previous checkpoint — persistent grapple-group motion

Verified milestone at this checkpoint:
**persistent grapple-group motion and summed-stat knockback resistance**.
Complete six kits and general 5v5 remain **unverified**.

**1705 full-suite tests pass in 232.211 s. All 43 new focused checks pass in
4.168 s:** seven source/direction and 36 real shared-world interaction methods.
Ten complete API/CLI captures, three complete hash-seed 401 controls and six
80-digit/137 ms/reversed-participant controls pass. [Rules](LINKED_MOTION.md) ·
[Author knockback clarification](KNOCKBACK.md) ·
[Evidence/reproduction](results/grapple-motion/README.md).

**Author rule recorded:** knockback/knock away are synonyms, up/down change its
direction, and a knock while still grappling moves the participants together.
Use summed maximum HP and current armor before the resistance exponent:
`max(0, P - (sum(H)/500 + sum(armor)/10)^1.1 / 150)`.
The group query and direction helper implement this; shield/remaining HP do not
replace those stats. Connected graphs count an actor once under delegation.
For two 1E2 bodies, nominal 15 m becomes 14.3692821023… m, not the singleton's
14.7057596966… m. [Confirmed preferences](DESIGN_PREFERENCES.md) remain separate
from delegated runtime policies.

**Implemented:** `GrappleLinks` plus the `LinkedMotionRules` composition layer
keep configured participants moving together on the existing clock. Independent
horizontal inputs remain available for later walk/run/stop changes; the group
projects them centrally. Shared ballistic velocity evolves under one gravity.
Atomic external changes expand to current group members; incompatible explicit
requests or one occupied destination reject the whole batch. Explicit projection
also includes existing registered links. Link/source lives, unique IDs, expiry,
controller fatigue and ordinary-recovery blocking are integrated.

**Collision policy:** all simultaneous face/centre-line directions remove
movement from every free input in the component. Only actual contacting bodies
receive collision statuses; untouched partners get no fabricated penalties.
This avoids reintroducing blocked motion from an untouched partner or using
observation-dependent resting locks. Existing compatible weapons/released work
survive. Release resumes independent inputs without an added impulse; a force
already applied to all members therefore persists for a surviving member.

**Real interactions:** actual jump/landing obligations, special stopping,
perpendicular simultaneous contacts, two colliding grapple groups, oblique
character contacts, real gun armor/weight changes, source death, actual 2E4
revival, heat exit, nonlinear sprint exhaustion and phase/contact ties pass.
A new unequal-drive jump test exposed double averaging (1.5 became 0.75 m/s).
It now keeps the independent input and preserves 1.5 m/s through takeoff/landing.
The failing regression and earlier 1703-test run are retained; final verification
includes the new regression plus expiry/force ordering. Three initial assertion
contract mistakes were corrected without production schema changes.

**Preserved evidence:** both unchanged five-method principal reviews and the
correction matrix pass; all prior component/modifier/counter/Block/melee/effort/
healing/revival/life and spatial captures replay unchanged, including the
30-second 2v2. All 507 files in thirteen historical evidence folders remained
unchanged during replay; historical manifests were not refreshed. Eight new
frozen inputs match current rules and fourteen ODTs match the prior spatial
checkpoint. No known failing test remains.

**Boundaries and next concrete work:** current link controls are explicitly
engineering operations, not authored grapple/knockback casts. Integrate actual
1E5 grab/drag contact, per-phase limb/action ownership and holding effort,
900/s constriction/tear, then Break/controller response and shared resource
flows. Reuse this motion/life coordinator. Knock timing, elasticity and
fatal-hit effect ordering require actual delivery; a distance query alone does
not finish those abilities. Binding/chain, portal and environmental grapple-gun
rules remain separate. Keep prescribed linked-climb, raised-edge/ledge,
ordinary dynamic-support, turning and broader prone/Get Up guards until those
paths work. Advanced NPCs, mass experiments and balancing automation remain
deferred. This session ends at a verified checkpoint; the overall Goal is active.

## Previous checkpoint — atomic spatial transitions and imposed motion

**1662 full-suite tests pass in 227.577 s; all 43 new focused checks pass in
1.498 s.** Nine new complete API/CLI captures pass: two ordinary existing
support/revival encounters and seven explicitly labelled engineering controls.
Three complete hash-seed 401 controls and five combined 80-digit/137 ms/
reversed-participant controls pass. [Rules](SPATIAL_TRANSITIONS.md) ·
[Evidence and reproduction](results/spatial-transitions/README.md).

**Implemented:** `SpatialTransitions` preflights typed immutable actor/life,
upright-reference, physical-velocity and support changes together, then rejects
stale/foreign plans before cancellation or writes. Final-pose swaps are legal;
one invalid destination leaves all body/control/effort state unchanged.
External changes cancel body control while independent compatible weapons and
released work survive. Geometry/contact, continuous HP/heat forecasts, cooldown
and heat membership update at the transition. Actual support loss and revival
restoration now use this coordinator; old frozen inputs retain old trace fields.

**Delegated physical policy:** imposed horizontal motion is an explicit driver
independent of voluntary U penalties. It uses existing gravity/continuous
contacts, retains horizontal momentum through landing and hands control to
ordinary movement or special stopping. It adds no new effort/ability/friction.
Force launch has no fake jump cost; an actual jump retains its owed landing
effects after a force. Displaced climbing inherits current velocity without
rewind/completion. Partial posture persists; death/restoration clears imposed
control. Relocations validate final destinations, not a swept teleport path.

**Graph foundation:** one exact rational weighted projection per connected
component, using the unchanged 40-digit HP/armor body weight and owned output
precision. Cycles, duplicate edges and dependent blocked normals are composed
centrally. This is an instantaneous update, **not a persistent grapple link**.
Mandatory life-bound `scope: engineering` scenario interventions expose the API
through the public CLI without invented selectable character abilities. A stale
member skips the whole batch; invalid geometry rejects it; callbacks run once.

**Real verification:** a climbed platform expires at 600 ms and causes a real
fall; actual 2E4 revival commits spatial state before its new life. Labelled
probes verify force flight, tangential wall motion, a released shot missing a
relocated target, displaced climbing, atomic swaps/graph updates and rejected
batches during actual jump/melee control. Additional focused checks cover real
heat/pause exit, source death, horizon contact, stale lives/plans, independent
gun control, stopping and unchanged jump landing obligations.

**Preserved evidence:** both unchanged five-method principal-review suites and
the correction matrix pass; R1/R2/R3 remain corrected. All nine component,
eight modifier, eleven counter, nine Block, four melee, nine effort, five
healing, five revival and three life encounters plus restoration probe replay
unchanged, including the 30-second 2v2. All 441 files in those twelve historical
packages stayed unchanged during replay. No historical captures/manifests or
primary ODTs were refreshed. Eight new frozen rule inputs match current files;
all fourteen ODTs match the prior component checkpoint. The initial evidence
script used the wrong release-event name; its corrected public-contract check
passes, with the initial log retained. No known failing test remains.

**Boundaries and next work at that checkpoint:** persistent coupled trajectories and
voluntary-drive constraints, including gravity, terrain/body contacts, support,
source/recipient life and release. Then integrate the existing 1E5 grab/drag
with authored damage and grapple contest/Break. Instantaneous projection alone
does not integrate grapple/chain/portal delivery. Keep partial raised support,
ledge/floor-edge departure and dynamic-body support guards until those paths
work. Fixed facing, turning, broader knockdown/Get Up and per-phase resource
transfers remain gates for affected kits. Advanced NPCs, mass experiments and
balancing automation remain deferred. This session ends at a verified
checkpoint; the overall Goal stays active.

## Previous checkpoint — component melee and actual 1E5 attacks

**1619 full-suite tests pass in 225.661 s.** All 36 new checks pass:
35 actual interaction methods plus one provenance/units regression. Nine ordinary
encounters match complete API/CLI output; three complete hash-seed 401 controls
and four combined 80-digit/137 ms/reversed-participant controls pass.
[Rules/source decisions](COMPONENT_MELEE.md) ·
[Current evidence](results/component-melee/README.md).

**Actual delivery:** 1E5 swings a/left then b/right for authored 440 slash,
G140/A180/midpoint, target/self O/U150 on real impact and Db1.8 at Active start.
Each owned action pins its component/hand; it uses the same contact controller,
phase power, shield/armor/HP snapshots and wound delivery as existing melee.
Consecutive next Gathering starts at Active end without Recovery; actual contact
cadence is 230/610/990 ms after remaining self disorientation. Passive 4 captures
actor-specific double bleed. Ultimate supplies +80 piercing to each arm's release
for 15 s after A320, with its existing 65 s cooldown and no added effort.

**Delegated gaps:** first a/left, unspecified base piercing 0, existing neutral
hand poses and 1 m/2 cm physical proxy. Advance once at emission, including
whiffs/full shielding; cancellation before emission retries the same arm, after
emission keeps its successor/wounds. Repeated callbacks cannot emit twice.
Restore next-arm state like physical resources; do not resume old control or
retired timed grants. Independent compatible movement/jump/enhancement actions
can overlap. No extra arms, venom, healing, revival or Block counter is inferred
for 1E5. Hand restrictions now check named occupied resources as well as declared
functions; existing right-hand thrust/left-hand Block obey the same mechanism.

**Shared profile:** source HP 20000/armor 350/Recovery 200, run 7, sprint +5.2 (12.2
m/s), jump up 3.5 m/s under gravity 9.81 m/s², shield 4000/shared 400 per second after 20 s
and source basic costs/effects. Missing movement/pose defaults are explicitly
delegated. Metadata labels no longer authorize mechanics: the old geometry
runner validates units/equations/profiles instead of requiring an English
“author-confirmed” label. A public regression retains wrong-unit rejection.

**Real interactions:** one unenhanced 440 strike removes 378.125 HP against 165
armor and starts a 756.25-basis bleed. Enhanced first hit removes 423.579545… HP.
Shielding still absorbs enhanced piercing; ordinary simultaneous sources retain
their own bleed multiplier. A real gun kills the source at 344.011649 ms while
its previously applied bleed continues. Mutual 1-HP death clips each source to 1
HP without inventing healing/revival. Shared jumping melee, source/recipient
life transitions, expiry without wound rewriting, friendly credit, cover,
source isolation and actual Block/counter are checked.

**Preserved evidence:** both unchanged five-method review suites/matrix and all
eight modifier, eleven counter, nine Block, four melee, nine effort, five healing,
five revival and three life encounters plus restoration probe replay unchanged,
including the 30-second 2v2. No historical capture/manifest was refreshed. All 14
primary ODTs match the prior modifier checkpoint; the new eight frozen JSON
inputs match current files. The initial full run exposed the obsolete provenance
gate and old fixed-roster expectations; corrections and sourced 1E5 expectations
are checked, with its log retained. No known failing test remains.

**Inventory correction:** basic Break is the grapple escape ability explicitly
named in `Grapple abilities.odt` p10; physical special stopping is the separate
opposite-input/slide rule in `Details.odt` p38. Corrected the old roster’s
conflation. The Break controller is still unfinished; no new ability was added.

**Next concrete work at that checkpoint:** investigate current position/reference/velocity/support
writes and introduce shared authoritative spatial transitions and linked-body
constraints. Compose simultaneous links centrally, preserving phase/contact
arbitration, support/ground departure, collision response and source/life
identity. Integrate actual existing grapple/drag/chain/portal delivery only after
real coupled motion is verified. Per-phase resource transfers remain necessary
where those authored abilities change requirements. 1E5 grapple/drag/dash/Break,
2E4 dash and other character deliveries remain unfinished; fixed facing,
turning and broader support/Get Up geometry remain boundaries. Advanced NPCs,
mass experiments and balancing automation remain deferred.

[ENGINE_STATUS.md](ENGINE_STATUS.md) indexes current capability; dated entries
below retain historical scope. Prior foundations:
[modifiers](ATTACK_MODIFIERS.md), [reactions](COMBAT_REACTIONS.md),
[Block](BLOCKING.md), [healing](HEALING.md), [revival](REVIVAL.md),
[melee/venom](MELEE_VENOM.md), [lives](LIFE_CYCLES.md),
[ownership](ACTION_OWNERSHIP.md), [effort](ABILITY_EFFORT.md),
[HP history](DAMAGE_LEDGER.md), [projectiles](PROJECTILE_ENTITIES.md),
[colliders](WORLD_COLLIDERS.md), [heat/recovery](HEAT_SHIELD_COUPLING.md),
[cooldowns](COOLDOWN_PAUSES.md) and [grapple source/formulas](GRAPPLE.md).
Read [AGENTS.md](AGENTS.md) and [confirmed preferences](DESIGN_PREFERENCES.md)
before new work; ask only for indispensable creative direction.

## Goal and source of truth

Build an inspectable combat simulation engine for the author's documented combat system. **Author goal clarification, 2026-10-25:** the engine will have no animations. The longer-term exploratory goal remains battlefield 5v5 experiments comparing different characters, starting positions and NPC behaviors. **Author priority clarification, 2026-10-27:** the current priority is a complete, internally consistent shared engine in which all existing abilities and interactions can be tested. Useful bounded demonstrations remain valuable; advanced NPC intelligence, learning and large automated experiments are later possibilities. Confirmed preferences are in [DESIGN_PREFERENCES.md](DESIGN_PREFERENCES.md), separate from delegated implementation decisions.

The absence of animations does not change documented combat timing or geometry. In particular, hand-position-based Recovery still requires numerical pose/transition definitions for supported actions; it does not require rendered hand movement. No Recovery formula or other mechanic was changed by this goal clarification.

- Primary specifications are the **ODT files in the project root**, including character documents, `Damage types.odt`, `Details.odt`, `Details2.odt`, `Collision details.odt`, `Dyspnea details.odt`, `Binding abilities.odt`, and `Grapple abilities.odt`.
- **Author source clarification, 2026-10-25:** `reference_material_non_authoritative/` is optional background material, not the project being implemented or an authoritative mechanics source. The author renamed the former `Game project 1.4/` directory to make this status explicit. It may provide ideas for consideration; it must not supply missing rules or override the primary documents without author confirmation.
- Explicit author clarifications take precedence over superseded wording. **Strategic delegation, 2026-10-25:** the author now authorizes mechanics changes and implementation decisions for optimization and internal consistency, with minimal input requests. Decide, document and test gaps; ask only when indispensable. Preserve the six existing characters and do not invent new character abilities. Battlefield and hitbox changes are permitted. Original ODT files remain intact; documented delegated decisions identify intentional differences.
- [MECHANICS_AUDIT.md](MECHANICS_AUDIT.md) contains the inventory and rule registry; [CONSISTENCY_REVIEW.md](CONSISTENCY_REVIEW.md) records consistency issues and resolutions. Older stage descriptions retain historical scope: consult the latest stage audit before interpreting them as current limitations.

## What is implemented

### Shared encounter engine

[combat_sim/shared_engine.py](combat_sim/shared_engine.py) runs supported abilities for multiple independently identified character instances on **one event timeline**, updating their common combat state. The latest moving-gun demonstrations add gravity, compensated aim, walking/running/sprinting/stopping, basic jump, crouch/stand, statuses, resources and death; see [the posture report](results/posture-combat/REPORT.md), [jump report](results/jump-combat/REPORT.md) and [earlier gravity report](results/moving-gravity-combat/REPORT.md). The **30-second stationary 2v2 with six-cuboid hitboxes, finite ground and three fixed cubes** retains its original scope, alongside preserved earlier body-only and point-based encounters:

- **1E1 ability 1:** Qard projectile, fixed-location delayed blast, self/target statuses, and automatic weapon cooldown.
- **1E1 ability 4:** independent summoned heat beam, exposure/residual damage, shield-to-HP transitions, and cooldown from activation start.
- **1E2 ability 1:** accelerating/decelerating projectile travel as configured, continuous distance falloff, slash damage, armor loss, independent bleeding, ammo, automatic weapon cooldown, and empty-magazine reloads.
- **1E2 ability 2, current moving scope:** independent 8 m / 4 s cooldown-pause areas with overlapping sources and actual moving membership; phase/effect clocks remain independent.
- **2E4 ability 1, current moving scope:** timed physical thrust, slash/bleeding,
  attached/residual venom with live toxin defenses, independent replacement
  summoning and owned grabbing. Its existing movement basics use the same world.
- **2E4 ability 5, current moving scope:** automatic death trigger, damage-based
  HP snapshot, 2000 ms generation-bound revival, charge/cooldown control and
  occupied-pose handling through the shared life transition.
- **2E4 basic 10, current moving scope:** actual 20% passive recovery with
  consumed recent-HP capacity, once-only entitlements and joint continuous
  HP/healing/death. Saved healing histories preserve nonlinear windows and lives.
- **1E5 ability 1/4/Ultimate:** actual shared alternating arm attacks, actor-specific
  double bleed and timed piercing; pinned resources, physical contacts, phase
  costs, immutable release values and source/life handling. See
  [component melee](COMPONENT_MELEE.md).
- **2E4 ability 4/Ultimate:** actual next-thrust armor loss and timed finite
  shielding bypass; shared release snapshots, simultaneous allocation,
  consumption/expiry, cooldown pauses and source-life handling. See
  [attack modifiers](ATTACK_MODIFIERS.md).
- **2E4 ability 2:** actual automatic Block counter, causal source-life signals, direct line/blunt delivery, target statuses and refill/pause/death handling. See [reactions](COMBAT_REACTIONS.md).
- **2E4/3E5 Block:** actual attached forward shields, held release, simultaneous layered defense/status snapshots and rechargeable stock; independent control/source lifetimes. See [Block](BLOCKING.md).
- Incoming disorientation can extend an existing Gathering. Already Active abilities do not acquire Gathering. Status stacking/decay, pre-hit armor snapshots for target statuses, and unmitigated self effects are executed.
- Ongoing effects, attacks, and later actions interact with the same states. Continuous HP/shield exhaustion is located between scheduled events without converting damage into ticks.
- Initial/final states, calculations, event sequence, loss histories, pending actions/effects, and stop reason are inspectable and reproducible.
- Current moving combat also records attributed actual HP losses, proportional overkill and clipped analytic/dense history windows. Revival and passive healing use this basis with separate payout rules; actual healing remains distinct from gross damage received.

**Stationary 2v2 body-collision scope:** approved fixed six-cuboid standing bodies,
explicit team facings, hand-position launch points, perfect torso-centre aim,
per-projectile sphere radii (initially 2 cm), first-other-living-body collisions
with friendly fire, 4 m Qard blast spheres and 7 m beam columns. Each overlapping
character receives an area attack once. Dead bodies stop colliding; Qard marks
require actual collisions. Hand Recovery, dyspnea, death, simultaneous snapshots
and per-loss shield regeneration run on the same event timeline.

The historical stationary terrain scope adds finite ground and fixed cubes; see [TERRAIN.md](TERRAIN.md).
That scenario does not include gravity, movement, arbitrary facing changes,
accuracy dispersion, revival or general interrupts are claimed. Shots with no scene contact
remain pending without a fabricated impact. Nearest-target/contact ties
need rules; this frozen run does not exercise heat overlapping recovery. Its
historical definitions retain that guard. Current definitions support the
interaction through [continuous coupling](HEAT_SHIELD_COUPLING.md).
See [HITBOXES.md](HITBOXES.md).

The earlier point-based 2v2 retains its explicit controlled eligibility model
and complete trace as a historical comparison. Its location-impact assumptions
are not the new physical collision rules.

The earlier duel retains its explicit controlled scope (supplied distance,
selected-target-only areas, dyspnea/Recovery excluded, coupled ties rejected,
HP-zero observation stop and short horizon). Its entire saved trace is unchanged.
A general battlefield or scripted 5v5 has not been validated.

### Earlier scoped runners and separate analysis

These remain runnable. Their capabilities do not automatically extend to the shared engine.

| Ability/system | Working capability | Boundary |
|---|---|---|
| 3E5 ability 1b | Scripted Blunt damage, armor loss, shield overflow, repeated hits and shield recovery | Legacy runner; b/c alternation and statuses also appear in the separate numerical benchmark. Not integrated into shared combat. |
| 2E4 ability 1, earlier runner | Exact controlled slash, bleeding and snapshotted venom for one unshielded, nonlethal thrust; separate benchmark adds repeated/shielded hits | Historical runner limits remain. The current shared engine now integrates actual thrust/venom/replacement delivery; see [MELEE_VENOM.md](MELEE_VENOM.md). |
| 1E1 Ultimate | Launcher preparation, grenade flight, area statuses, gas exposure/residual toxin damage | Controlled runner uses explicit exposure windows and nonlethal targets; repeated additive clouds are in the separate benchmark. Not integrated into shared combat. |
| Earlier 1E1 projectile/heat and 1E2 firearm runners | Focused formula/lifecycle validation, including exact calculations under their supported limits | Each retains its own restrictions; the exact heat runner, for example, remains unshielded/nonlethal. |
| Shield regeneration | Each loss has its own delay; eligible losses share one recovery rate; current heat/recovery coupling preserves net stock and zero-stock absorption | Executed in current shared moving combat, including delayed recycled losses. Frozen runners/definitions retain their documented restrictions. See [coupling scope](HEAT_SHIELD_COUPLING.md). |
| Dyspnea and damage-based recovery credit | Dyspnea eligibility/payments/recovery execute for the selected shared team abilities; shield-excluded damage-credit helpers remain separate | This does not establish other ability costs, healing, or revival. |
| Timing and character definitions | Data-driven profiles; hand Recovery executes for selected 1E1/1E2 actions | Full kits, general limb scheduling, and complete 1E5 ability-1 combat are not implemented. |

The [36-case repeated-damage comparison](results/repeated-10s-comparison/REPORT.md) tests six ability families against canonical 1E1, 3E5, and 1E5, with and without 4000 starting shield. It is a **separate passive-target benchmark**, not a shared battle.

The [heat parameter study](results/heat-ratio-analysis/REPORT.md) explores general k and exposure. Under unchanged output/defenses, residual/exposure damage is `1/k`; residual/total is `1/(k+1)`. Encounter heat currently implements k=2.

## Current terrain 2v2 and validation

Author confirmed a 500 × 500 m ground centred at (0,0), z=0, with nominal
battlefield height 200 m and open sides/top. Three fixed 1.8 m cubes rest on
it at horizontal centres (6,0), (2,15), (15,15). Ground and cubes stop
projectiles and trigger Qard marks; blasts and beams ignore cover. Gravity
was absent in this saved run. Its magnitude and basic aiming/falloff rules are
now confirmed, with remaining trajectory choices in [GRAVITY.md](GRAVITY.md). See [TERRAIN.md](TERRAIN.md).

The unchanged 30-second teams and policy now leave **both A characters alive**:
A_1E1 has 1831.9808 HP and 1000 shield; A_1E2 has 8140 HP and 1000 shield.
B_1E2 dies at 10.104 s, B_1E1 at 15.264 s. Cube (6,0) blocks A_1E1's outgoing
Qards and incoming enemy gunfire/Qards. The policy continues choosing nearest
living targets without considering cover. This is a scenario result, not a
character ranking.

**479 tests pass**, including 9 terrain geometry and 9 terrain integration
checks. These cover finite edges/open boundaries, cube contacts, actual ground
impact after target death, Qard delay/location, blocked gunfire, area attacks
through cover, input validation and full older-body trace preservation.
80-digit evaluation and alternative observation schedules agree within 1e-20
and preserve action cadence. Earlier frozen traces remain unchanged.

[Scenario](scenarios/stationary_2v2_terrain.json) ·
[Report](results/stationary-2v2-terrain/REPORT.md) ·
[Map](design/terrain/arena.svg) ·
[Timeline](results/stationary-2v2-terrain/timeline.html).

## Earlier body-collision 2v2 and validation

Scenario: [scenarios/stationary_2v2_hitboxes.json](scenarios/stationary_2v2_hitboxes.json).
Positions, initial HP/armor/shields and action policy match the earlier 2v2.
Team A faces +world-x and team B -world-x. 1E1 fires from its right-hand start
pose; 1E2 from its left-hand start pose, with perfect torso-centre aim and
2 cm spherical projectiles. Body origin is 0.875 m above the placement datum.

| Instance | Status at 30 s | Death time (s) | HP remaining | Shield remaining | Armor remaining |
|---|---|---:|---:|---:|---:|
| A_1E1 | Dead | 3.825190 | 0 | 0 | 82.2751 |
| A_1E2 | Dead | 11.136842 | 0 | 0 | 76.2878 |
| B_1E1 | Alive | — | 6729.9502 | 3830.4626 | 133.2454 |
| B_1E2 | Dead | 9.432000 | 0 | 0 | 22.2707 |

Team B remains the only surviving team. Body contact distances change flight
timing/falloff slightly. Attacks keep their original trajectory after target
death, skip removed bodies and create no Qard mark without a collision.
The earlier point-based run is preserved below as a separate controlled result.

- **461 tests pass**, including 25 geometry and 15 body-collision integration
  checks. The frozen snapshot is separately tested.
- 80-digit evaluation, 137 ms observations and no periodic observations preserve
  action cadence and agree within 1e-20 in checked states and death times.
- Earlier 1v1 and point-based 2v2 complete traces reproduce unchanged.
- [Report](results/stationary-2v2-hitboxes/REPORT.md),
  [timeline](results/stationary-2v2-hitboxes/timeline.html), and frozen
  code/data/source/test evidence preserve the new run.

## Earlier point-based stationary 2v2 and validation

Scenario: [scenarios/stationary_2v2.json](scenarios/stationary_2v2.json).
Team A positions: 1E1 (0,0), 1E2 (0,10); team B: 1E1 (30,0), 1E2 (30,4) metres.
Both A actors start with 1000 current shield; B with 4000. All begin at 8140 HP,
150 armor, zero dyspnea/statuses and ready/loaded abilities. Policy selects the
nearest living enemy, beam before projectile for 1E1, and gunfire/reload for 1E2.

| Instance | Status at 30 s | Death time (s) | HP remaining | Shield remaining | Armor remaining |
|---|---|---:|---:|---:|---:|
| A_1E1 | Dead | 3.826679 | 0 | 0 | 82.2943 |
| A_1E2 | Dead | 11.138013 | 0 | 0 | 76.3118 |
| B_1E1 | Alive | — | 6730.2294 | 3830.4626 | 133.2502 |
| B_1E2 | Dead | 9.367000 | 0 | 0 | 22.3063 |

Team B has the sole survivor. Dead characters' resources retain their death
state. Both B actors initially focus A_1E1; A's beam and delayed blasts affect
both B actors. Released/deployed effects continue after their source dies.
B_1E1 regenerates 3830.4626 shield by 30 seconds from observed loss histories;
no history is invented for A's initially missing shield.

- **421 tests pass**, including individual Recovery and continuous shield-supply
  cases and 21 integrated team tests.
- An 80-digit evaluation, 137 ms observations and no periodic observations
  preserve action cadence and agree within 1e-20 in checked final states,
  death times and total regeneration. These are finite-precision evaluations.
- The previous duel's complete trace reproduces unchanged.
- [Report](results/stationary-2v2/REPORT.md), [interactive inspection](results/stationary-2v2/timeline.html),
  [complete run](results/stationary-2v2/run.json), and a frozen code/data/source/test
  package preserve this experiment. It is a controlled scenario, not a broad
  character-strength ranking.

## Earlier 1v1 encounter and validation

Scenario: [scenarios/1e1_vs_1e2_shared.json](scenarios/1e1_vs_1e2_shared.json).

- Duration **10 seconds**, supplied distance **10 metres**.
- Both start with **8140 HP, 150 armor, and 4000 shield**.
- Replaceable priority policy: 1E1 selects its beam when ready, otherwise projectile; 1E2 fires when ready and reloads when empty. Decisions occur after combat events at the same timestamp. These are scenario choices, not authored tactical behavior.

| Character | HP damage received | HP remaining | Armor remaining | Shield remaining |
|---|---:|---:|---:|---:|
| 1E1 | 5,126.86 | 3,013.14 | 48.69 | 0 |
| 1E2 | 4,179.60 | 3,960.40 | 150.00 | 0 |

Both remain above zero HP. No shield loss becomes eligible for regeneration within ten seconds. The first bullet arrives at 52 ms, adding approximately 65.864 disorientation and moving the beam's scheduled start from 180 to **246 ms**. The beam remains deployed while 1E1 fires subsequent projectiles.

- **365 automated tests passed**, also from the frozen code snapshot: [test evidence](results/1e1-vs-1e2-shared/test_results.txt).
- Frozen replay reproduces the complete saved trace, states, and pending effects.
- Shared execution uses **50-digit numerical arithmetic with analytic continuous integrals**; incoming status mitigation retains its established 40-digit evaluation. These results are not mathematically exact.
- An **80-digit reference** and alternate **137 ms observation spacing** preserve action cadence and agree within `1e-20` in checked final states. Observation spacing is not a damage tick.
- Earlier exact runners retain rational/symbolic-root calculations. Long repeated armor calculations can exceed their explicit **12000-bit exact-arithmetic budget**; unsupported cases are rejected rather than silently rounded.
- A separate three-actor test verifies heat responding to another attacker's armor loss. The actual duel does not change armor on the heated target: bullets damage 1E1 while the beam heats 1E2.

[Report](results/1e1-vs-1e2-shared/REPORT.md) · [Interactive timeline](results/1e1-vs-1e2-shared/timeline.html) · [Complete run](results/1e1-vs-1e2-shared/run.json) · [Precision checks](results/1e1-vs-1e2-shared/precision_check.json).

## Important confirmed decisions and clarifications

- **Shields:** absorb raw damage before HP mitigation. Armor/resistances do not reduce shield damage. Only overflow becomes pre-mitigation HP damage; a fully absorbed hit does not reduce armor. Existing shields do not automatically grant status resistance: only explicitly stated bonuses apply. Incoming status effects can still pass through shields.
- **Shield regeneration:** every lost amount waits its own **20 seconds**, then eligible losses share **400 HP/s**, rather than each receiving that rate. Added shield amounts stack. Do not invent regeneration history for initially missing shield.
- **Floors:** HP/armor, damage, and decaying statuses stop at zero. Adjusted armor/resistances floor at zero before squaring.
- **Disorientation/instability:** values stack additively and decay by one per millisecond. Incoming values are mitigated before addition. Self effects bypass mitigation; running's self-effect increase still applies. The earlier mitigated-self interpretation is historical.
- **Gathering:** current disorientation adds time even to zero-base-Gathering actions, including reload. New incoming disorientation extends Gathering already in progress. Once Active begins, disorientation does not insert Gathering into it. Running multiplies base Gathering by 1.2 before current disorientation is added.
- **Projectile timing:** release is after Active for the supported firing abilities; self effects described as on firing/throw occur at Active midpoint. Acceleration affects flight time. Phase/travel timestamps round upward to integer milliseconds; successive Gathering extensions add to the scheduled Active start and round upward. Continuous damage boundaries retain fractional milliseconds.
- **Gun/reload:** 1E2's base Gathering is zero. Its 40 ms firing is followed by an automatic 360 ms weapon cooldown, which blocks no other action. Eleven bullets exhaust the magazine; reload can overlap cooldown and uses additional Gathering followed by 1800 ms Active. Range falloff is continuous: 0.25 raw damage per metre.
- **Qard:** leaves armor unchanged. 1E1's delayed blast deals the same damage and target effects as its projectile hit.
- **Bleeding:** independent eight-second applications add together. Shields cannot bleed; only post-shield, post-armor slash damage supplies the bleed basis. Existing HP bleeding continues if shield later regenerates.
- **Venom:** always has slash delivery. Its multiplier is post-armor slash damage divided by post-shield/pre-armor slash damage; fully shielded delivery produces no toxin. Each application snapshots armor immediately before its own hit's armor loss, so later armor changes do not alter that application. Exposure grows while attached; residual decay begins on detachment. Damage accumulates continuously.
- **Heat:** uses current armor/heat resistance. The beam starts at Active start, operates independently after summoning, adds no statuses, and removes no armor. Each beam has its own curve. Shields use zero defenses; HP exposure starts at zero when an active beam breaks shield. Residual heat can damage shield but ends at shield break without transferring to HP. Beam cooldown starts at activation.
- **Poison gas:** bypasses shields, leaves armor unchanged, and uses elapsed exposure followed by residual toxin damage. Separate clouds add independently. The grenade's target statuses apply once to eligible explosion recipients.
- **Geometry/limbs:** straight-line distances and local 3D limb coordinates were chosen as a direction for Recovery; full anatomical simulation is not required. Actual poses and transition rules remain incomplete. Alternating-arm attacks use component definitions; metadata alone is not full execution. Older 1E5 after-Active self-effect examples were superseded by 150/150 on impact.

Detailed formulas and per-document references remain in the mechanics registry and focused ability audits; this file summarizes the current decisions.

## Confirmed tether specification — not implemented

[1E1 ability 2](1E1_ABILITY2_AUDIT.md) anchors at the **impact position**, lasts 15 seconds, and has a 10-metre chain. The target's **whole body/hitbox** must stay within the permitted boundary. Walking/running/dashes stop at it; outside teleport destinations are unavailable. Projectiles and summons can cross or be placed outside. This is a tether, not full immobilization.

Six-cuboid body dimensions and standing placement are confirmed (below).
Binding-specific facing/movement response, dimensional treatment, Break,
forced-movement details, and failed-teleport costs are still needed for complete
tether execution. Do not substitute a centre-point check that allows the body to
cross the boundary or clamp an invalid teleport into a valid destination.

## Confirmed six-cuboid body and collision rules

The author specifies head (0.25,0.25,0.25), torso (0.5,0.3,0.7), arms
(0.1,0.1,0.8) and legs (0.2,0.2,0.8) in local x/y/z metres (right/forward/up).
The standing placement and whole-bounds origin are approved: total dimensions
0.70 × 0.30 × 1.75 m, local ground z=-0.875. Bodies stay fixed while hand poses
continue controlling Recovery timing independently.

[HITBOXES.md](HITBOXES.md), [body data](data/body_hitboxes.json) and the
[diagram](design/hitboxes/standing_proposal.svg) record the current source rules.
[hitboxes.py](combat_sim/hitboxes.py) supplies exact geometry and fixed-precision
swept contacts; [body_collisions.py](combat_sim/body_collisions.py) integrates
launch/aim, live-body filtering, area eligibility and pending missed shots.

The author confirms fixed A→+x/B→-x facings, right-hand Qard and left-hand gun
launch positions, torso aim, initial sphere radius 2 cm per projectile, ignoring
owner and striking the first other living body including allies. Dead bodies
stop colliding. Qard marks require an actual collision, not arrival at an empty
former target location. Ground/gravity are the next planned physics stage;
no values or rules for them have been invented.

## Unresolved problems and current limitations

1. **Heat during shield regeneration:** specify how returning shield changes
   ongoing HP heat exposure/residual clocks. The shared team mode rejects that
   overlap; the current encounter does not exercise it.
2. **Broader event/action lifecycle:** current phase/release-before-hit and shared
   snapshots are defined for this subset. Gathering reselection, general
   interrupts, multi-component abilities, sustained channels, cooldown/charge
   anchors and additional kits still need rule-specific work.
3. **Broader Recovery:** selected 1E1/1E2 actions have poses and parallel hand
   timing. Other poses, alternating-arm/reset/unused-hand behavior and other
   anatomical constraints are not established by this implementation.
4. **Broader dyspnea/Break:** selected action values and payment anchors are
   confirmed. Other costs, continuous-action eligibility, broader refunds and
   Break's older filling rules still need applicable definitions.
5. **Further physics/geometry:** approved fixed bodies and actual sphere
   contacts are integrated. Ground/obstacles, gravity, ballistic aiming, moving
   hitboxes, arbitrary facings and aim dispersion still need source rules.
   Equally near targets or same-point contacts with different bodies need a
   selection rule. Shots without a scene contact have no inferred later impact.
6. **HP-zero systems beyond this subset:** controlled-action cancellation and
   persistent released/deployed effects now execute. Healing, revival, damage
   credit/overkill attribution and match rules beyond reporting survivors remain
   unimplemented.
7. **Integration coverage:** separate venom, gas and Blunt results do not establish
   mixed shared compatibility. Imported character profiles do not make their
   full kits executable. Arbitrary 5v5 encounters remain unvalidated.

## Latest confirmed boundary decisions

[STATIONARY_2V2_SPEC.md](STATIONARY_2V2_SPEC.md) records all author answers.
At an identical timestamp, Gathering has already completed/Active started, and
projectiles due to release are released before incoming hits. If an attack's
target dies during preparation, finish toward its original location; the next
new action chooses the nearest living enemy. Individual hand Recovery times
overlap, with their maximum controlling eligibility. Qard/gun check/pay at
firing end; reload at Active start; death before payment incurs no cost.

## Suggested next steps

1. Validate isolated gravity trajectories using explicit launch inputs; see
   [GRAVITY.md](GRAVITY.md). NPC aiming/arc selection can follow separately,
   before integrating compensated aiming into a gravity 2v2.
2. Inspect the saved 2v2 trace and compare small controlled changes to the same
   scenario (positions, initial shield, target/ability priorities).
3. Define returning-shield heat exposure before claiming that longer mixed
   encounters support every regeneration/heat interaction.
4. Extend the authored geometry with movement, retaining explicit scope, then
   exercise tether boundaries and moving projectile/area eligibility.
5. Expand tested scripted team encounters toward 5v5 using supported abilities;
   add kits and behavior policies incrementally with focused regression cases.

These are proposed priorities, not additional mechanics.

## Architecture and commands

| Responsibility | Main location |
|---|---|
| Character/ability definitions | [data/characters.json](data/characters.json) |
| Pure formulas and numeric integrals | [combat_sim/mechanics/](combat_sim/mechanics/) |
| Shared state and execution | [battle_models.py](combat_sim/battle_models.py), [shared_engine.py](combat_sim/shared_engine.py), [team_rules.py](combat_sim/team_rules.py) |
| Replaceable decisions | [battle_actions.py](combat_sim/battle_actions.py), [actions.py](combat_sim/actions.py), [benchmark_policies.py](combat_sim/benchmark_policies.py) |
| Encounter input | [scenarios/](scenarios/) |
| Events, summaries and analysis | [events.py](combat_sim/events.py), [battle_analysis.py](combat_sim/battle_analysis.py), [analysis.py](combat_sim/analysis.py), saved reports under [results/](results/) |
| Separate repeated-damage study | [benchmark.py](combat_sim/benchmark.py) |

The simulator uses Python's standard library. Run from the project root:

```sh
# Current 2v2 summary; omit --summary-only for the full trace.
python3 -B -m combat_sim run scenarios/stationary_2v2_terrain.json --summary-only

# Earlier controlled duel.
python3 -B -m combat_sim run scenarios/1e1_vs_1e2_shared.json --summary-only

# Complete automated suite.
python3 -B -m unittest discover -s tests -q

# Verify the saved run using its frozen code/data.
python3 -B results/stationary-2v2-terrain/reproduce_snapshot.py

# Rebuild current shared results after reviewing any source changes.
python3 -B results/stationary-2v2-terrain/build_results.py
```

Frozen result folders intentionally preserve their own earlier rules, scopes, inputs, code, and test counts. Do not rewrite historical evidence merely to match the current implementation.


## Gravity clarification received, 2026-10-25

Confirmed g=9.81 m/s² downward, fall-compensated aim, addition of motion
components and falloff by actual travelled distance. Recorded in
[GRAVITY.md](GRAVITY.md). Gravity was subsequently implemented in isolated helpers (see milestone below),
but is not integrated into battle execution. The author confirmed that firearm
deceleration follows current travel direction and proposed deferring aiming
to NPC intelligence work. Faster-arc selection was subsequently confirmed; isolated physics
can be tested with explicit launch inputs without selecting an NPC policy.
No combat values, executable mechanics or frozen results changed in this update.


## Isolated gravity verification, 2026-10-25

Implemented [gravity motion](combat_sim/mechanics/gravity.py) and
[curved static contacts](combat_sim/gravity_collisions.py), separate from
shared combat. Inputs explicitly specify launch position, velocity and duration;
no NPC aiming policy is selected. Gravity is 9.81 m/s² downward; gun deceleration
is 300 m/s² opposite instantaneous velocity. Arc length is calculated for
future falloff use, without changing existing damage application.

**509 tests pass**, including **30 isolated gravity tests**. Analytic ballistic,
vertical and zero-gravity limits, an independent speed integral, the work–energy
relation and tighter numerical controls verify motion. Curved-path collision
tests include arcs that hit/clear geometry contrary to the straight chord,
finite ground, cube interception, body removal from a fixed scene and radius
changes. The complete earlier terrain battle trace remains unchanged.

[Isolated report](results/gravity-isolated/REPORT.md) records horizontal test
shots and frozen evidence. Qard falls onto ground within the arena when
unobstructed; horizontal gunfire can pass beyond the finite ground before
falling to z=0. The wider firearm landing floor is explicitly a test fixture.
These are physics checks with uncompensated explicit launch inputs, not a
new battle result or a replacement for the future compensated-aim requirement.

Numerics: analytic undecelerated motion; binary64 adaptive RK4 for
velocity-dependent acceleration; recursively refined sphere contact brackets.
Tightened controls agree within 1e-8 in final checked motion components,
2e-8 s in contact upper time and 2e-5 m in contact upper path length for the
saved fixtures. No formally certified error bound is claimed. Unsupported
near-tangent/tied contacts and conservative zero-speed-boundary horizons are
rejected. See [GRAVITY.md](GRAVITY.md).

Next: review isolated results, define any needed zero-speed behavior, extend
curved contacts to dynamic combat eligibility/event scheduling and path-length
falloff, then add compensated aiming as a separate policy before another 2v2.


## Faster aiming arc and movement request, 2026-10-25

Author selects the faster projectile arc. Added an isolated stationary-target
[ballistic aiming helper](combat_sim/mechanics/aiming.py) for undecelerated
projectiles, with 12 tests. The full suite now passes **521 tests**. The firearm's
velocity-dependent deceleration needs its own aiming solver; neither helper
is integrated into combat. No moving-target leading rule is assumed.

Requested straight-line walking and running. Both 1E1/1E2 walk at **2 m/s**
(author clarification) and run at **6.4 m/s** (primary profiles). Recorded
source rules and unresolved movement responses in [MOVEMENT.md](MOVEMENT.md).
Author subsequently confirms a temporary stop-only movement response at cubes,
other bodies and the ground edge; detailed body collisions will be developed
by the author. Transition durations were subsequently supplied (see below);
remaining speed-curve and stopping/slide ambiguities await clarification. Existing
battles and frozen evidence remain unchanged.


## Movement transition timing received, 2026-10-25

Re-read the updated primary 1E1/1E2 ODTs: both now specify walk ↔ run Active
transition 150 ms. Author confirms acceleration occurs during Active.
Stand ↔ walk Active is one third of Recovery; stopping Active is 150 ms per
5 m/s of starting speed (192 ms from running 6.4 m/s, 60 ms from walking
2 m/s). Recorded in [MOVEMENT.md](MOVEMENT.md). Revised files also add
run ↔ sprint Active 200 ms; sprint is outside this requested milestone.

Clarification requested before affected implementation: linear versus other
speed curves; numeric interpretation of Recovery/3 and its overlap with the
walk → stand stopping duration; and whether the existing mitigated slide
is during braking, additional afterwards, or superseded. No movement formulas
or transition behavior were invented. No executable code changed in this
clarification update; the last verified full suite remains 521 tests.


## Linear walk/run transition verification, 2026-10-25

Author confirms speed changes linearly during movement transition Active.
Implemented exact rational baseline motion in
[mechanics/movement.py](combat_sim/mechanics/movement.py) and separate
[walk/run data](data/movement/walk_run.json). Both characters transition
2 ↔ 6.4 m/s over 150 ms, with acceleration ±88/3 m/s² and displacement
0.63 m. Twelve focused tests pass; the full suite passes **533 tests**.

This verifies the isolated Active segment, not locomotion in the battle
engine. Standing-transition interpretation, walk → stand duration conflict
and slide/braking relationship await author answers. Status effects, dyspnea,
collision stops, dynamic eligibility and combat action scheduling remain to
be integrated after applicable rules are settled. Frozen results are untouched.


## Standing/stopping duration correction, 2026-10-25

Author confirms stand → walk uses numeric Recovery/3 = 200/3 ms for both
characters. Author removes the separate walk → stand transition: walking
now uses the general stopping rule (60 ms from 2 m/s), as running does
(192 ms from 6.4 m/s). Updated movement data, implemented exact standing
acceleration and a separate stopping-duration helper, with seven additional
tests. The full suite passes **540 tests**. Baseline stand → walk covers
1/15 m during Active. Existing battle execution and frozen results are unchanged.

The remaining stopping clarification is how the documented mitigated slide
relates to the confirmed linear deceleration. No total stopping displacement
or collision/status/action integration is claimed by the duration helper.


## Further standing/walking correction pending, 2026-10-25

Author corrects the preceding statement to apply “both for walking to standing
and the other way around.” Asked whether both directions should use the
general 150 ms per 5 m/s rule applied to speed change (60 ms for 0 ↔ 2),
rather than initial speed. No formula change is inferred. The existing
Recovery/3 stand → walk helper is provisional pending this answer. No code
or test changes in this clarification update; last full suite: 540 passing.


## Standing/walking correction resolved, 2026-10-25

Author confirms **both directions follow the stopping mechanic**. Recovery/3
is now superseded for both stand → walk and walk → stand; removed from
movement data and executable timing. Both take 60 ms for a 0 ↔ 2 m/s speed
change. The isolated start segment covers 0.06 m with linear acceleration.
Walk ↔ run remains 150 ms; running → standing remains 192 ms at 6.4 m/s.
Updated 19 movement tests pass; the full suite passes **540 tests**.

This resolves the provisional correction above. Total stopping displacement
and its relationship to the documented mitigated slide remain pending.
Movement/combat integration and frozen results are unchanged.


## Isolated basic jumping, 2026-10-25

Author confirms upward initial speed = half base running speed, retained
horizontal velocity and gravity, with takeoff at Active start. Both current
characters take off at 3.2 m/s upward. Re-read root basic-jump definitions:
Gathering 100 ms, Active 150 ms, jump self statuses 80/80, landing self
statuses 100/120 and listed dyspnea value 1.5. Stored source data in
[data/movement/jump.json](data/movement/jump.json).

Implemented exact isolated jump flight and timing in
[mechanics/jumping.py](combat_sim/mechanics/jumping.py), documented in
[JUMPING.md](JUMPING.md). Apex rise is 512/981 m (about 0.521916 m); apex
time is 320/981 s and same-height return is 640/981 s after takeoff.
Horizontal velocity remains constant under gravity-only flight. Active end
is independent of later geometric return/landing. Existing Gathering rules
are reused without changing formulas.

Eleven new jump tests pass; the full suite passes **551 tests**. Tests include
exact gravity/energy relations, an independent ballistic reference, horizontal
velocity retention, base-speed scaling and Active-start scheduling. Shared
combat remains stationary: body/terrain landing collisions, jump/landing
statuses, dyspnea payment timing, mid-flight death and combat integration are
pending. Frozen battle and gravity evidence are unchanged.


## Shared-engine scripted movement geometry, 2026-10-25

User requested walking/running, transitions, stopping and jumping in the combat
engine and explicitly selected **geometry and timing first**. Added an explicit
scripted-movement scope to SharedEncounter, retaining its existing event loop,
combatant collection, body/terrain geometry, trace format and CLI dispatch.
Earlier combat scopes remain unchanged. Movement/jump effects and attacks are
excluded by author choice for this first integration test.

Implemented forward stand → walk, walk ↔ run, stationary/walking/running
jumps, takeoff/apex/Active-end/flat-ground-landing events, and continuous
translation of all six body cuboids. Quadratic rigid-box sweeps locate cube
and body contacts without observation-step tunnelling. Contacts apply the
author's temporary stop-only response and cancel an in-progress transition.
The floor remains finite. Edge footprint policy and airborne obstacle response
are explicitly unsupported rather than invented. Script commands cannot overlap
Active/Gathering/flight; direct stand → run timing is unspecified and rejected.

Main [scenario](scenarios/scripted_movement_geometry.json) exercises both
characters in separate unobstructed lanes. Both finish at x=21.62 m, walking
2 m/s, after a running jump. Takeoff is 2320 ms, Active ends at 2470 ms,
landing is about 2972.395515 ms. The separate
[cube-stop scenario](scenarios/scripted_movement_contact_stop.json) stops
A_1E1 at x=4.95 m, time 1521.875 ms, at the torso/cube first contact.
These are controls, not new NPC behaviors.

Special stopping clarifications: author deletes linear stopping, retains
the mitigated slide and penalties, sets slide duration to the **base**
instability stopping gives, and reaches zero velocity at slide end. The slide
speed curve and start anchor remain undefined. A `stop` command is rejected
until those rules are authored. See [STOPPING_REVIEW.md](STOPPING_REVIEW.md).
No discarded linear stopping distance or instant slide-speed reset is used.

Verification: **578 tests pass**, including 19 shared movement integration and
7 continuous rigid-contact tests, plus an explicit rejection of deleted linear
stopping. High precision and alternate/no observation schedules preserve event
sequence and agree within 1e-35 in checked positions and event times. Earlier
complete terrain/body/point traces remain unchanged.

[Saved geometry results](results/scripted-movement-shared/REPORT.md) include
inspection, CSV exports, frozen code/data/tests/source documents and replay.
Outstanding requested work: integrate and test the special stopping action
after its remaining displacement/time rules are supplied; then separately
address movement effects/resources and combat attacks on moving bodies.


## Special stopping resolved and integrated, 2026-10-25

Author confirms sliding begins at Active start, negative calculated distance
stops travel, and slide speed decays linearly to zero. Explicitly approved
initial slide speed 2 × mitigated distance / duration, rather than preserving
the prior running speed in the deleted linear-braking model. Duration uses
base stopping instability, excluding running's +20% modifier.

Implemented [mechanics/stopping.py](combat_sim/mechanics/stopping.py), including
zero-distance flooring, explicit precision and an inspectable curve; connected
special stops to the existing shared event loop, continuous body geometry and
contact interruption. See [STOPPING_REVIEW.md](STOPPING_REVIEW.md).
At original speed 6.4 m/s with current defenses, slide distance is
0.1434558179 m, duration 192 ms and initial slide speed 1.4943314368 m/s.
At walking speed 2 m/s, resistance cancels travel immediately; 60 ms stopping
Active still runs. No status/dyspnea payments are enabled by this geometry test.

[New scripted scenario](scenarios/scripted_movement_stopping.json) exercises
walking/running transitions, running and walking special stops, and jumps
from running, standing and walking. Both characters finish at x≈26.7734558179 m,
standing and grounded, after 3 jumps/landings and 2 special stops each.
It resolves the outstanding special-stop portion of the requested geometry test.

**591 tests pass**, including 9 pure slide tests and 23 shared movement
integration tests. The suite checks midpoint slide position/speed, zero travel
when resistance cancels distance, completion, interruption by a cube, all three
jump modes and complete previous shared-movement/cube-stop traces unchanged.
80-digit and alternative/no periodic observations preserve event sequence and
checked values within 1e-35. Frozen earlier battles and geometry results remain
untouched. [New results and replay](results/scripted-movement-stopping/REPORT.md).

Next work is movement/jump/stopping status and resource integration, then
attack interaction with moving bodies. Ground-edge footprint and airborne
obstacle/body response remain explicitly unsupported in this bounded scope.


## Climbable block and standing test, 2026-10-25

User requested one climbable block; chose cube_1 at (6,0), height 1.8 m.
Cube_2/cube_3 remain non-climbable. Added an optional boolean terrain flag
without changing collision geometry. Author confirms inclusive 0.5 m activation
range from **character body origin to block surface**, not nearest body cuboid.
Approved path: vertical until feet reach top, then horizontal to top centre,
constant path speed over documented 300 ms Active after 150 ms Gathering.
Primary 1E1/1E2 climb values are recorded in data/movement/climb.json.

Implemented isolated range/path geometry and standing climb phases on the
shared event loop, with six-cuboid translation, explicit rejection for
non-climbable/out-of-range targets, and persistent raised support. The
[climb scenario](scenarios/scripted_climb_geometry.json) starts A at (4.6,0),
exactly on the origin-distance boundary; Active starts at 150 ms, feet reach
top at 318.75 ms, and standing on top completes at 450 ms. Body origin is
(6,0,2.675), feet z=1.8. B's nearby non-climbable cube_2 request is rejected.
Subsequent stationary jump/landing on that same top is tested.

**617 tests pass**, including 9 pure climb tests and 17 shared climb tests.
Earlier complete special-stopping traces remain unchanged. Geometry/timing
scope still excludes statuses and dyspnea payments. No new frozen result
package was built for this partially completed interaction stage.

**Author requested waiting for forthcoming body-collision details**, since
those affect walking/running-to-climb handoff. That handoff and new collision
responses are paused pending the added documentation. Standing activation is
tested; moving activation, blocked-path responses and leaving raised supports
remain explicit unsupported cases. Do not invent automatic momentum cancellation
or a stopping slide for climb. See [CLIMBING.md](CLIMBING.md).


## Centre-line body collision clarification, 2026-10-25

Author supplied new collision rules and updated root Collision details.odt:
character/character and obstacle collision direction is the centre-to-centre
line; ground collision uses a perpendicular through the body centre. Status
uses full relative projected speed, 300 disorientation and instability per
5 m/s. Author explicitly confirms each character receives that full raw amount
before its own resistance and independently loses its own velocity component
along the line. Perpendicular velocity remains.

Implemented isolated response calculations in
[mechanics/body_collision.py](combat_sim/mechanics/body_collision.py), with
12 focused tests. The full suite passes **629 tests**. Verified head-on and
same-direction relative speeds, stationary recipients, oblique preserved
velocity, ground vertical removal, individual resistance and exchange symmetry.
Read [COLLISIONS.md](COLLISIONS.md) for equations, examples and current scope.

Pending author answer: centre-line removal at a flat cuboid face may leave
inward face velocity. Asked whether an additional solid-face constraint should
block it, or geometry/response should differ. No substitute normal or guessed
penetration solver was introduced. New body-collision rule work has resumed
from the supplied details; this unresolved response blocks safe world
integration and the moving-to-climb handoff. Existing shared geometry tests
retain their previous explicitly temporary contact stop and exclude effects.
No earlier frozen results were changed.


## Obstacle surface-normal distinction, 2026-10-25

Author resolves the earlier obstacle-face ambiguity: **character/character**
uses the centre-to-centre line; **character/obstacle** uses the line through
the character centre perpendicular to the contacted surface. Ground follows
the same surface-normal rule. This explicit clarification supersedes the
earlier combined wording in Collision details.odt for obstacles.

Updated the pure obstacle response to require an explicit surface normal; it
never uses an obstacle centre. Ground delegates to that normal-based response.
Character centre-line response, full relative-speed statuses for both actors,
individual resistance and component removal remain unchanged. Example: at an
x-facing surface, velocity (6.4,2,0) becomes (0,2,0), producing 384 raw of each
status before resistance. Off-centre location does not add spurious motion.

Seventeen isolated response tests pass; **634 tests pass** in the full suite.
New tests cover off-centre and glancing impacts, normal sign/scale, oblique
surfaces, invalid/zero normals and prevention of the old positional-centre API.
See [COLLISIONS.md](COLLISIONS.md). Earlier frozen traces remain unchanged.

This resolves the single-obstacle-face direction question. Response helpers
still await world-timeline integration, actual contact-normal extraction and
edge/corner/multi-contact handling. Existing geometry test scopes retain the
previous temporary contact stop and excluded statuses. Moving-to-climb
handoff is not inferred from this direction clarification.


## Active-start climb gate and moving handoff, 2026-10-25

Author confirms range is checked **once at Active start**, walking/running
continues through Gathering, and a successful check switches to the approved
climb path. Failed checks leave movement unchanged; a collision requires
actual body contact. Implemented the deferred gate and removed the prior
standing-only activation restriction. Requests outside range may approach
during Gathering. Requests initially in range may leave range and fail.
The running Gathering modifier is preserved (150 → 180 ms).

Contacts during climb Gathering remove movement under the existing geometry
response without erasing the pending range check; collisions do not implicitly
interrupt Gathering. A failed check does not retry when range changes later.
No spurious collision/status/slide is created by being outside range.

[Moving scenario](scenarios/scripted_moving_climb_geometry.json): A requests
at 200 ms from x=4.34 (out of range), reaches x=4.64 at Active start 350 ms
(in range), and completes at 650 ms. B requests at 100 ms initially in range,
walks away, fails at 250 ms from x=7.54, and reaches x=8.84 at 900 ms without
a collision. A finishes at block centre (6,0), feet z=1.8, body origin z=2.675.
The standing demonstration remains runnable and completes at 450 ms.

**638 tests pass**, including 9 pure climb and 21 shared climb cases. New
cases test motion into/out of range, running handoff, contact before Active
and later actual contact without automatically retrying a failed climb.
High precision and alternative/no observations preserve checked outcomes.
[Saved results and replay](results/climbing-active-start/REPORT.md).

Moving-to-climb eligibility/handoff is now resolved for this geometry/timing
scope. Status/resource integration, full directional collision response in
the timeline, blocked-climb response and raised-edge behavior remain pending.
Earlier frozen results are untouched. See [CLIMBING.md](CLIMBING.md).


## Crouch geometry discussion, 2026-10-25

Author asked how to model crouching. Re-read both basic crouch definitions:
Active 150 ms, self disorientation/instability 80/80, listed dyspnea value 1.
No crouched height or pose is specified in the primary files.

Proposed, not yet approved or implemented: keep feet fixed on support; shorten
leg cuboids from their tops to represent bending; lower torso/head/arms by the
same height reduction while retaining their dimensions; interpolate the pose
during crouch Active. Derive body origin from the resulting bounds and keep
ability hand/aim origins consistent with the lowered upper body. A clearance
check is needed for subsequent standing expansion. Example for author review:
legs 0.8 → 0.4 m implies total height 1.75 → 1.35 m. Final crouch depth and
standing-up transition remain undecided. No mechanic, geometry or code change
was applied by this discussion. Last verified full suite: 638 tests.


## Crouch and sprint implemented, 2026-10-25

User approved the proposed crouch and requested sprinting. Confirmed standing
back up also uses 150 ms Active. Crouch reduces legs 0.8 → 0.4 m, lowers
head/torso/arms by 0.4 m and preserves their sizes. Feet stay on support.
Total height changes 1.75 → 1.35 m; body origin above feet .875 → .675 m.
Hand positions and projectile-origin conversion follow the upper-body shift
while accounting for the recentered origin. Standing checks clearance and
reverses the pose in 150 ms. No animation is added.

Primary sprint definitions: +4.8 m/s over base running 6.4 = **11.2 m/s**,
run ↔ sprint Active **200 ms**, linear transitions. Source sprint attack
restriction, transition penalties and base dyspnea Dd=2 are recorded; effects
and attacks remain excluded from this author-approved geometry/timing scope.
Posture and ground pace are independent: no undocumented crouch speed modifier
or prohibition is introduced. Tested walking/running/sprint poses and crouched
jumping. Direct sprint handoffs with unspecified timing remain rejected.

Added modular posture geometry and feature rules. Continuous box contact
calculation now accounts for linear size changes as well as translation;
feet anchoring does not generate fake ground impacts. Exact standing-height
ceiling fits are handled with the established numerical boundary tolerance.
New scenario: [scripted_crouch_sprint_geometry.json](scenarios/scripted_crouch_sprint_geometry.json).
Both actors finish upright/grounded at x≈33.0934558179 m after 2 crouches,
2 stands, 2 sprint transitions, 1 jump and 2 special stops each.

**665 tests pass**, including 9 posture geometry, 15 shared crouch/sprint
cases and 3 added changing-size contact cases. Checked endpoints/midpoints,
hand/origin consistency, clearance, exact fit, sprint stopping, posture/pace
independence, high precision and observation schedules, with older complete
climb traces unchanged. Earlier frozen results are preserved.

[Specification](CROUCH_SPRINT.md), [static diagram](design/postures/standing_crouch.svg),
[results/replay](results/crouch-sprint-shared/REPORT.md). Status/resource/attack
integration and obstructed partial-pose collision response remain pending.


## Whole-body turning timing, 2026-10-25

Author specifies 90° per 150 ms, with +200 ms per 5 m/s current movement
speed. Confirmed timing: T90(v)=150+40v ms; walking 230 ms, running 406 ms,
sprinting 598 ms. Added exact rational timing helpers and explicit source data
in [TURNING.md](TURNING.md), mechanics/turning.py and data/movement/turn.json.
Eleven isolated timing tests pass; the full suite passes **676 tests**.

Asked two necessary movement-integration choices: whether angular rate follows
speed changes continuously or is fixed at turn start, and whether turning
changes facing alone or also steers movement. These answers remain pending.
Current axis-aligned +x/−x body geometry also needs oriented-body and rotational
contact support for continuous turns. No fake body flip, AABB substitute,
steering rule or speed-sampling behavior was invented. Whole-body turning is
not yet integrated into shared movement; existing frozen results are untouched.


## Aiming-direction statement pending interpretation, 2026-10-25

Author adds “Turn aiming direction is 180 degrees.” Clarification is needed
whether this means aiming angular speed, a range relative to body facing, or
a target world direction. No aiming rate/range, movement modifier or whole-body
turn value is changed from this ambiguous statement. Last verified suite: 676.


## Strategic delegation and Get Up checkpoint, 2026-10-25

The author changes the development procedure: proceed incrementally toward an
internally consistent engine, optimize for long-term efficiency, and ask for
input only when indispensable. Mechanics, battlefield and hitbox changes are
authorized. Retain **1E1, 1E2, 1E3, 1E5, 2E4, 3E5** and their existing abilities;
do not invent character abilities. AGENTS.md now reflects this overriding
instruction. Root ODTs and earlier frozen results remain untouched.

The author additionally asks that usage exhaustion must not undermine quality.
Use bounded work sessions with capacity reserved for testing/review/handoff.
This session ends at the verified checkpoint below, before starting the larger
movement/combat change. No account quota is assumed or reported. The overall
engine goal is still unfinished.

[ROADMAP.md](ROADMAP.md) defines staged integration and completion criteria.
[ROSTER.md](ROSTER.md) inventories the six authored kits and distinguishes shared
execution from controlled runners, passive benchmarks and metadata. The key
architectural gap is that movement and combat share a queue but still select
separate advancement paths. Integration precedes broader kit coverage.

### Completed increment

The author supplies common **Get Up**: Active = 2 × Recovery; dyspnea = 2 ×
jump dyspnea. Under the new delegation, choose numeric Recovery in ms and
double the basic jump's base value before `(Db + D/100)^2`. Choose immediate
Active, no added Gathering/hand Recovery, and capacity check/payment at Active
start. These are documented decisions, not retroactive author confirmations.

Six profiles derive Active values **400/400/500/400/300/300 ms** and Db
**3/3/3/2.4/2.4/2.4** in roster order. Values are in
`data/movement/get_up.json`; exact helpers are in `mechanics/get_up.py`.

Get Up now runs through `common_actions.py` on the existing shared combat
action lifecycle. Opt-in `common_abilities: ["get_up"]` and explicit definitions
preserve historical traces. Initial `knocked_down` is validated. A living down
actor recovers before selecting attacks, including when no enemies remain.
It stays down until completion; it neither heals nor clears status. Insufficient
capacity waits for normal recovery without payment. Death cancels the action;
paid costs are not refunded. The knockdown-effect entry point cancels controlled
actions and invalidates stale phase events. Reapplication requires a new paid
Get Up; released projectiles and deployed beams persist.

The example [scenario](scenarios/get_up_combat.json) gets up during 0–400 ms,
pays 9 dyspnea, releases an existing Qard at 798 ms and hits at 1098 ms for
400 HP. [Saved trace, report and replay](results/get-up-combat/REPORT.md) include
inputs and full results without another copied engine tree.

**707 tests pass** (676 baseline + 12 pure Get Up + 19 shared integration).
Verified resources, incoming status during Active, death, repeated knockdown,
stale event cancellation, same-time phase/impact ordering, retained projectiles
and beams, exact-cap triggering, input order, observation schedules and higher
precision. Independent review found no blocking issue. Complete saved Get Up
replay and existing frozen trace regressions pass.

### Scope and next session

Knockdown currently retains the existing collision proxy and changes action
eligibility only. Prone pose, Get Up clearance, movement interaction and actual
character-attack knockdown triggers remain pending. Six derived profiles do not
claim full six-character combat support. Get Up source/decisions are in
[GET_UP.md](GET_UP.md).

Earlier pending turn/aim questions are no longer requests blocking work: the
new delegation allows choosing rules when that integration is reached. They
remain unimplemented, with historical question entries retained above.

**Next concrete task:** build the shared advancement coordinator and derive
status/resource context from actual locomotion. Start with grounded upright
straight movement and the existing 1E2 gun; finish the milestone with a real
moving-body hit/miss. Relevant seams: `SharedEncounter._load()` currently
returns after movement setup; `advance()` selects movement or team advancement;
`advance_team()` uses a stationary dyspnea context; released projectiles currently
precompute contacts against fixed bodies. Reuse existing modules and preserve
legacy scopes. Maintain one action-eligibility model and invalidate controlled
motion on death. Moving heat entry/exit belongs to a later focused increment.


## Grounded moving gun combat checkpoint, 2026-10-26

The previous goal turn made concrete progress: Get Up was completed and
verified. This session implements the next integration milestone under the
same model and the author's bounded-session/quality instructions. The overall
six-character/5v5 goal remains active and unfinished.

### Working integrated behavior

New explicit `grounded_combat` scope reuses the shared engine rather than
creating another encounter runner. `mobile_combat.py` coordinates the earliest
queued event, instability expiry/speed-floor crossing, body contact, projectile
contact and continuous damage exhaustion. `advance_team` advances geometry and
resources to that same boundary. Historical stationary and geometry-only
scopes retain their complete saved trace regressions.

Walking/running/stopping intents share the controlled action slot with attacks.
FIFO intents wait for the current action and precede the next automatic shot.
Steady movement continues during weapon phases. Standing-to-running intent
executes the existing stand-to-walk then walk-to-run transitions. Explicit
world movement direction is separate from the fixed body facing.

Integrated source rules include continuously decaying **U/200 speed loss**,
30/s stationary/walking and 18/s running dyspnea recovery, phase/status recovery
blockers, and running's 20% modifiers for weapon Gathering, hand Recovery and
self statuses. Recovery scales its numeric attribute before the single final
ceiling. Walk/run transitions pay Db0.5 and add96/96 self statuses at Active
start. The source-or-destination running modifier, free starting walk/stop,
and Active-start anchors are explicit delegated decisions. Special stopping
retains the approved resisted distance/duration and avoids a second U penalty.

Body contacts now execute the existing directional responses on the combat
timeline. Pair/obstacle contacts are deduplicated across cuboids, with separate
mitigation for each incoming contact before summing. Character status uses
the centre line; obstacle status uses a surface normal. Simultaneous solid
face constraints use orthonormal projection; exact corners use one normalized
sum of face normals for status. These extra nonpenetration/tie choices are
documented delegated decisions. Tangential velocity is preserved before the
new collision instability slows movement. Incoming O extends Gathering;
death cancels controlled motion/intents, and dead bodies stop colliding.

`moving_projectiles.py` solves relative quadratic sphere/cuboid contacts using
exact rational polynomial root isolation, including rounded corners/tangency
and zero-thickness finite ground. `mobile_projectile_rules.py` retains released
flights and recomputes contact against current motion, so starting/stopping
after release can change a hit to a miss or a miss to a hit. Actual traveled
distance supplies falloff. Initial hand origin, torso aim and friendly fire
are preserved. Aim tracks the current torso at release, without predictive lead.
Physical contacts retain fractional milliseconds. A decelerated round reaching
zero speed becomes inert without inventing an impact; this stage's explicit
zero-speed decision is recorded in [MOVING_COMBAT.md](MOVING_COMBAT.md).

### Evidence and fixes

**748 tests pass**: previous 707, 20 moving-sphere geometry tests and 21 integrated
movement/combat tests. These include real moving hits/misses, motion changes
after release, resource eligibility, U-dependent distance/floor/expiry, contacts,
death, per-contact mitigation and higher-precision/observation invariance.

Review identified and corrected early termination when no sample/policy event
remained, double rounding of running Recovery, and double subtraction of old
instability during glancing contact. An additional full-duel 80-digit check
found a repeated resting-contact loop from microscopic rounded overlap. Rest
or tangency now requires renewed inward speed/acceleration to create another
contact. The full-duel regression verifies one contact and reaches the full
horizon without relying on observations.

[Five-second moving gun duel](scenarios/moving_gun_duel.json): both 1E2s run,
exchange fire, stop, walk and finally collide. Each releases 11 shots and lands
11 hits. Final HP: A≈3374.865322, B≈3365.631892; both survive. Positions:
A≈(14.398077,-20), B≈(14.698077,-20). Running intent expands into two phases,
so each completes four movement Actives from three intents. These are scenario
outcomes, not balance rankings. No-observation and 80-digit/137 ms runs agree
within 1e-20 on checked final state values and have one body contact.

[Lateral target scenario](scenarios/moving_gun_lateral_miss.json): one gunshot,
no hit or HP loss in 1500 ms; the non-leading shot remains in flight after the
target leaves its path. [Saved inputs, full traces, report and replay](results/moving-gun-combat/REPORT.md)
are compact artifacts without another copied source tree. Both complete
traces replay exactly, and the prior Get Up checkpoint still replays exactly.

### Remaining scope and next session

This mode currently uses upright, grounded straight movement and the existing
1E2 gun. It intentionally has **straight decelerating flights without gravity**;
the isolated gravity solver is not yet connected. Footprint departure remains
an explicit unsupported case. Jump/climb/crouch/sprint, turning, prone/Get Up
geometry, moving area exposure and the other kits still need integration.
The six-character inventory remains unchanged; no new abilities were invented.

**Next concrete task:** connect gravity and faster-arc compensated aiming to
the persistent-flight path. Reuse `mechanics/gravity.py`, `mechanics/aiming.py`
and `gravity_collisions.py`; gun deceleration follows instantaneous velocity,
so its gravity-enabled curve cannot be treated as a single quadratic. Preserve
moving-body contact recalculation and actual traveled-distance falloff. Validate
an isolated shot first, then a moving gun encounter with finite-ground/terrain
contact and observation-independent outcomes. After that, join other spatial
actions and area entry/exit before extending the remaining kits.

The helper reviewer reported a usage limit during this session; remaining
verification and the handoff were completed locally. No remaining account
allowance is inferred. This is a verified incremental checkpoint, not a claim
that the overall engine goal is finished.

## Gravity and compensated aim in moving combat, 2026-10-26

The previous increment made verified progress: 748 tests and exact moving-gun
replay established the shared movement/combat coordinator. This session connects
gravity through that same coordinator, rather than counting isolated helpers as
integrated combat. The overall six-kit/5v5 objective remains active and unfinished.

### Implemented behavior and decisions

`GRAVITY_MOBILE_SCOPE` extends grounded gun combat with author-specified 9.81 m/s²
gravity, 300 m/s² deceleration opposing instantaneous velocity, compensated aim,
and actual traveled-path falloff. Character abilities, existing movement rules
and the original battlefield are unchanged. Earlier straight/stationary scopes
retain their exact regression traces. API/CLI support an explicit physics
configuration in `data/physics/projectile_gravity.json`, recorded in every result.

`mechanics/decelerating_aim.py` continues the analytic fastest ballistic branch
through four deceleration stages and verifies endpoints with tighter integration.
The supported solution stays within a conservative positive-speed horizon. This
is a bounded short-arc method, not a global optimality proof for unsupported
near-stop/high arcs. Delegated choice: target the current torso at release,
without predictive lead or cover avoidance. Failed branch resolution is explicit.

`mechanics/persistent_gravity.py` computes immutable trajectories once per release.
Queries and observations do not mutate their integration knots. Direction-following
acceleration and path length use adaptive binary64 RK4. Delegated terminal rule:
when a decelerated round first reaches 1e-6 m/s, it becomes inert without collision,
damage or mark. Positive deceleration must exceed gravity; undecelerated ordinary
gravity remains supported. The current gun satisfies that restriction.

`moving_gravity_collisions.py` uses relative trajectory views for current moving
cuboids and finite terrain, preserving world coordinates and actual projectile
path distance. `gravity_projectile_rules.py` integrates those contacts into the
existing shared clock; changing motion/death can change contacts after release.
Owner exclusion, friendly fire, post-death projectiles, defense snapshots and
resource/action timing are preserved.

Delegated numerical choices and rationale are in [GRAVITY.md](GRAVITY.md) and
[MOVING_COMBAT.md](MOVING_COMBAT.md): 1e-12 s contact brackets, 1e-14 m clearance,
1 ns event grid, stable object/part tie order, separate binary64 projectile and
Decimal combat precision. Numerical brackets/refinement are not certified ODE
bounds; unresolved tangencies raise an error. A common event grid limits changes
from subdivision/observation boundaries without treating samples as physics ticks.

Review found and fixed three scheduling edge cases: a brief contact disappearing
before its rounded tick; a binary64 confirmation endpoint slightly beyond the
reached Decimal boundary; and an inert-stop event suppressing a same-tick hit.
Reached contact evidence now survives rounding, an earlier interruption invalidates
unreached evidence, endpoint confirmation is clamped to the searched boundary,
and projectile impacts precede terminal stopping. Four dedicated regressions
cover these cases, including a real thin obstacle traversed between event ticks.

### Verification and reproducible outcomes

**799 tests pass** in 16.742 s: the previous 748 plus 12 aim, 11 persistent-trajectory,
13 moving curved-contact,11 shared gravity-combat and 4 scheduling-boundary tests.
Focused physics checks include analytic references, work–energy balance, numerical
refinement, endpoints and long-flight stopping. Integrated checks cover moving
hits/misses, target motion after release, finite floor/open space, cube interception,
actual-path damage, shooter death, actor order, observation schedules and precision.

[Saved results and replay](results/moving-gravity-combat/REPORT.md) contain four
scenarios, exact fixture inputs, full traces/summaries and the complete test log:

- Five-second gun duel: 22 releases and 22 body hits; both survive. Final HP
  A≈3374.865325, B≈3365.631894. No/100/137 ms observations agree to Decimal
  roundoff in checked final HP; focused tests additionally check 80-digit states.
- Diagonal lateral miss in the original arena: first round hits ground at
  1077.274832 ms near (128.877504,145.099420,0), after 533.060529 m of travel.
- Cube interception: one round hits cube 1 at 116.315873 ms; no body damage.
- Open-side miss: first round becomes inert at 3114.027369 ms after 1350.639777 m,
  without any collision or invented impact. Eight later rounds remain in flight.

All four full traces and summaries replay exactly in the current environment.
The prior moving-gun hit/miss and Get Up packages also replay exactly. The public
CLI successfully runs the gravity ground-miss scenario. Historical result packages
are preserved; no copied source tree was added to the new result package.

### Remaining scope and next concrete task

This integrated scope still accepts upright grounded walking/running/stopping and
the existing gun. Sprint, jump, climb, crouch, turning, prone/Get Up geometry,
moving Qard/beam exposure and the remaining kits require shared integration.
Predictive NPC aiming and final 5v5 policy experiments remain unfinished. Ground
footprint departure still raises an explicit unsupported-case error.

Next: connect sprint and jump to the same movement/combat coordinator. Start with
the existing source profiles and geometry helpers, document costs/status anchors
under the delegation, then implement takeoff/airborne/landing boundaries and
moving-projectile interactions. Validate isolated action timing/resources before
an airborne combat encounter. Do not add a second runner or new abilities.

This is a verified bounded checkpoint with tests, review and handoff complete.
No new large change was started after verification, and no account quota is
inferred. The same model remains the working assumption for session planning.

The final read-only documentation check initially failed because automatic
approval review reported a usage limit. Access succeeded on the next continuation;
the saved test log and handoff were read, and current summary/roster descriptions
were corrected to distinguish gravity combat from the historical stationary scope.
No code changed after the 799-test verification and successful replay checks.

## Sprint integrated with combat, 2026-10-27

The previous verified checkpoint was gravity-enabled moving gun combat, 799 tests
and four exact replay traces. This increment adds the existing sprint to the same
coordinator. Jump/other spatial actions and the full six-kit/5v5 goal remain open.

### Source rules and implemented choices

Audited root ODT paragraphs 1E1 p206–216, 1E2 p222–232, Details p10–11 and Dyspnea
p15–25, including the embedded Da/Dc formulas. Both sprint profiles add 4.8 m/s
to 6.4 running, use 200 ms run↔sprint Active, list 100 O / 100 U and transition 0.5,
and gain 2 dyspnea per second while sprinting. Attacks are prohibited. Sprint
hand poses are authored; 1E1 explicitly gives identical start/end poses.

Under the delegation, `sprint_combat.py` applies transition Db0.5 and self statuses
at Active start, with running's self multiplier (120 O / 120 U). Hands recover to
neutral sprint poses first, using running's Recovery modifier and a single final
ceiling. Old pace continues during Recovery. Use the same end poses for 1E2;
its source only supplies the start. Compound intents stage existing transitions.

Continuous sprint 2 maps to Dd=2 in `(2+D/100)^2`, with zero recovery. Effort begins
at entry Active, persists through stable sprint and exit Recovery/Active, and ends
at exit completion, special-stop Active start, full collision or death. Analytic
entry/payment anchors and cap boundaries make resource evolution independent
of observation intervals. Continuous gain is exposed separately from discrete
`dyspnea_paid` in events, metrics and summaries.

Sprint blocks new weapon actions including reload; extending the authored attack
restriction to reload is a delegated choice. Already released shots persist.
At capacity 100, apply the cap trigger once after interval status decay, including
the sprint/running self factor (normally 240 O). If still sprinting, cancel its
controlled action and invoke the existing free special stop. An unaffordable
paid exit also replaces that intent with a free stop, instead of deadlocking
while sprint blocks recovery. Later explicit commands remain available.

These choices and their rationale are recorded in [CROUCH_SPRINT.md](CROUCH_SPRINT.md),
[MOVING_COMBAT.md](MOVING_COMBAT.md) and the optional `sprint` section of
`data/movement/combat_locomotion.json`. Historical replay definitions without the
section retain their old output and supported actions. No new ability was invented.

### Review findings and fixes

A full sprint collision now wakes an attack policy previously blocked by sprint.
That interaction exposed a residual instability/disorientation of 1e-47 after
fractional expiry: adding it could not advance the clock, creating a zero-time
loop. Decay now clears a remainder only when it is below the representable clock
increment. The ordinary full-collision regression reaches its horizon and fires.

Review also found that a glancing collision during special stopping cleared the
stop phase, resumed sprint mode and charged from a stale pre-stop resource anchor.
Near exhaustion this could produce another zero-time loop. The corrected response
retains the stop action/deadline and linearly decays projected tangential slide to
zero over the remaining duration. A full block retains the Active with zero travel.
It does not reapply stop penalties, subtract instability again or resume sprint
cost. A permanent regression covers both ordinary and nearly exhausted cases at
50/80 digits and with/no observations.

The initial helper test process was absent when work resumed after a usage-limit
interruption. Bounded local diagnostics reproduced the loop; it was not treated
as a still-running job. A new review and full verification then completed. No
account allowance is inferred and the model selection remains unchanged.

### Verified checkpoint

**815 tests pass** in 17.562 s: the previous 799 plus 16 shared sprint tests, including
independent resource/distance formulas, hand Recovery, attack/reload restrictions,
exit fallback, exact exhaustion timing, interrupted entry, death, collisions,
observation schedules, 80-digit state and historical scope rejection.

[Four demonstrations, inputs, complete traces, report and replay](results/sprint-combat/REPORT.md):

- Five-second mixed gun encounter: A sprints, exits to fire, sprints again and
  stops. A releases/hits 6 shots and B releases/hits 11. Both survive with
  HP A≈3464.415421 and B≈5677.010066. Second sprint has 85 ms hand Recovery;
  continuous sprint gain≈9.705949519 is reported separately.
- Exhaustion from initial D90: reaches 100 at 893.134101687 ms, applies one 240 O
  trigger and one special stop. No duplicate penalty or stale completion.
- Unaffordable exit at 700 ms: free special stop replaces the paid exit;
  there is no recovery wait while sprinting and no capacity overdraw.
- Glancing stop: begins 800 ms, contacts cube 1 near 931.489549433 ms and still
  completes 1136 ms. No sprint gain occurs after 800 ms.

All four complete traces and summaries replay exactly; the CLI summary matches
its saved combat result. Prior gravity, moving-gun and Get Up replay packages
remain exact. Historical artifact directories were not rewritten.

### Next concrete task

Integrate the existing jump into this same coordinator. Start with the approved
100 ms Gathering, 150 ms Active, takeoff at Active start, upward speed half base
running speed, retained horizontal velocity and gravity. Resolve/document source
jump/landing costs and status anchors under delegation; then implement airborne
body/contact/landing boundaries and projectile interaction. Verify geometry and
resource timing individually before an airborne combat scene. Do not create a
second runner or new abilities.

Crouch/climb/turning, prone/Get Up geometry, moving area effects, the other kits
and final 5v5 policy experiments remain unfinished. This bounded session ends
with implementation, review, tests and handoff complete; it does not mark the
full objective achieved.

## Basic jump in shared combat, 2026-10-27

The existing basic jump now runs on the same coordinator as ground movement,
sprint and the 1E2 gun. Optional `data/movement/combat_jump.json` selects the new
rules; `airborne_combat.py` integrates actions, resources and full 3D motion,
and `airborne_geometry.py` isolates descending plane-contact geometry. The CLI
loads the combat jump definition for jump commands. Historical geometry-only
jump inputs and result directories retain their original behavior.

### Rules and delegated decisions

The author-confirmed upward speed is half base running speed (3.2 m/s), with
actual horizontal velocity retained and gravity 9.81 m/s². Takeoff occurs at
Active start. Root 1E1/1E2 basic jumps list 100 ms Gathering, 150 ms Active,
self 80/80 on jumping, self 100/120 on landing, and dyspnea 1.5. The source
audit found no hand poses for either basic jump; launcher hand poses are not
borrowed. [JUMPING.md](JUMPING.md) records source references and full rationale.

Implemented under delegation:

- Retain current hands without invented Recovery movement. Treat 1.5 as Db,
  check capacity before selection and at Active start, then pay and apply jump
  self effects. Running's existing modifiers apply. Death before payment pays
  nothing; incoming disorientation can extend Gathering.
- Capture horizontal velocity before new self instability. Flight continues
  independently after Active; weapons can act in air. Ground movement intents
  wait for landing and the current controlled action. Sprint exits through its
  existing run transition before a requested jump.
- Airborne dyspnea recovery is zero, without adding continuous jump cost.
  Landing wakes waiting action policies. Landing self effects stack with
  separately resisted physical-contact statuses; aggregate additions before
  one Gathering extension. No extra fall damage or bounce is assigned.
- Retain full 3D collision velocity. Existing floor support constrains downward
  projection; a collision can lift a grounded actor without charging jump or
  assigning jump landing self effects. Incidental sprint flight retains its
  existing effort until exhaustion; at the cap effort ends and stopping waits
  for landing. Death freezes the last body location, removes its collisions
  and cancels flight while released projectiles persist.

### Review and verification

An oblique airborne-body contact exposed a vanishing residual velocity after
projection. It could survive landing as nominal motion and create a false
contact when instability expired. Components below the existing 1e-24 m/s
collision tolerance are now cleared. A regression verifies ground support,
landing and no repeated resting impact. Airborne support selection uses only
accepted living contacts, excluding stale contacts invalidated by earlier death
at the same event time. Independent review added reachable collision-lift and
airborne sprint-exhaustion cases rather than synthetic state-only assertions.

**849 tests pass in 19.505 s**: the previous 815 plus 12 plane-contact checks,
21 airborne combat tests and one explicit zero-airborne-recovery test. Coverage
includes timing, retained momentum, resource anchors, landing mitigation/self
contributions, airborne firing and limb hits/misses, walls, queued commands,
Gathering extension, death/released shots, sprint exit, incidental lift and
exhaustion, definition validation, actor order, 50/80-digit combat state and
alternative/no observation schedules. [Complete test log](results/jump-combat/test-results.txt).

[Four scenarios, full traces, frozen inputs and replay](results/jump-combat/REPORT.md):

- Running jump: takeoff 420 ms, Active end 570 ms, airborne shot 695 ms,
  landing 1072.395515 ms. Stop requested at 500 ms starts at 1095 ms after the
  current firing action finishes. A ends standing; B has about 7378.488462 HP.
- Wall: side contact at 410.475 ms removes horizontal travel while flight
  continues; floor contact at 1022.395515 ms. A ends at x=4.95 m.
- Airborne hit: the shot intersects the rising target's left leg at
  341.620333 ms. Active completion does not fabricate a landing.
- Death: A dies airborne at 561.561864 ms, but its released shot hits at
  591.559658 ms. Its later movement intent is rejected.

All four complete traces and summaries replay exactly. Both saved-input and
README default-input CLI summaries match the saved combat result. All eleven
prior sprint, moving-gravity, moving-gun and Get Up replay cases remain exact.
No historical artifact directory was rewritten.

### Remaining scope and next concrete task

Current bodies remain upright with fixed facings; moving weapons remain the
existing 1E2 gun. The jump definition covers 1E1/1E2 source values but does not
integrate 1E1's moving area attacks. Finite ground-footprint departure, walking
off raised support and standing on another moving body remain explicitly
unsupported. Other kits, crouch/climb/turning, knockdown/Get Up geometry, moving
area effects and general 5v5 policy experiments are unfinished.

Next integrate the existing crouch/stand poses into combat. Reuse their approved
150 ms transition and standing-clearance check. Audit source costs/statuses and
select documented timing anchors, then test changing body cuboids against live
projectiles and contacts while sharing normal action/resource eligibility.
Keep geometry separate from effect rules and preserve historical geometry tests.
Do not introduce another runner or new abilities.

This is a bounded verified checkpoint with implementation, independent review,
replay and handoff complete. The author's consistent model choice is retained;
session sizing remains based on a coherent tested change, not an assumed account
allowance. The full engine goal remains active and incomplete.

## Creative direction and shared crouch/stand, 2026-10-27

### Author clarification and continuity

Reviewed AGENTS.md, ROADMAP.md and the 849-test jump checkpoint before continuing
its recorded next task. Existing delegation, verification and handoff rules were
retained. The added guidance records the author's creative-director role,
implementation-agent ownership of detailed design/mathematics/architecture,
preservation of unusual defining features, reversible choices, the narrow
escalation boundary and reusable mechanics with permitted independent effects.
[DESIGN_PREFERENCES.md](DESIGN_PREFERENCES.md) now contains confirmed author
preferences separately from delegated choices.

The engine and complete existing ability interactions take priority over advanced
NPC intelligence, learning and large automated experimentation. The six-character
roster, no-animation goal, 5v5 longer-term goal and development sequence remain.
The original root ODTs and historical result packages were not changed.

### Implemented increment and decisions

The existing crouch/stand now executes on the same moving-combat coordinator.
The optional `posture` rule section enables the approved 150 ms changing cuboids,
anchored feet, hand/projectile-origin transforms, action eligibility, resources,
statuses, collisions, crouched jump and death. Geometry remains separate from
effect/action decisions; this adds no second runner or character ability.

Audited 1E1 p172–179 and 1E2 p188–195: Active 150 ms, self O/U 80/80, listed
dyspnea 1, no crouch hand poses. [CROUCH_SPRINT.md](CROUCH_SPRINT.md) distinguishes
these and the author's geometry/clearance approvals from delegated choices:
Db1 and 80/80 in both directions at Active start, zero-base Gathering with current
O, retained canonical hand poses, running/sprint modifiers, current-occupancy
clearance and live contact interruption. An interrupted pose retains its reached
fraction, paid cost and applied effects; another legal command can leave it.
Partial retries use the same pose rate and a new full action payment.

Moving-sphere and curved projectile contacts include each part's pose velocity
and size rate. Actual body origin remains recentered while a separate upright
reference protects foot height and flight/landing. Death freezes the last pose;
released shots persist. The existing controlled-action slot remains this
increment's scheduling boundary, not a universal rule forbidding concurrent
abilities in future kits; independent released effects continue to coexist.

Review found and corrected an exact-fit ceiling contact rounded slightly before
pose completion. Endpoint queries now use zero completed-pose velocity within
the existing contact tolerance. It also identified the exact sprint-cap payment
case: posture payment reanchors effort, and reaching 100 delegates cancellation,
the single cap trigger and free stop to the existing sprint event. Natural
exhaustion during posture is verified too. Standing clearance retains the
historical geometry-only dispatch and its earlier traces.

### Verification and reproducible results

**874 tests pass**: the previous 849 plus 25 posture integration checks. Coverage
includes midpose geometry/hands, normal/no-change costs, Gathering extension,
weapon eligibility and lowered launch origins, both projectile models, actual
cube contact, running/sprint effort, natural and exact-payment exhaustion,
clearance/exact fit, newly obstructed expansion, partial-pose retry, crouched
jump/landing, death before/after payment, actor order, 50/80-digit state and
alternate/no observations. [Captured test log](results/posture-combat/test-results.txt).

[Four saved scenarios, inputs, full traces, report and replay](results/posture-combat/REPORT.md):

- Crouch/fire/stand: five rounds hit; both actors end standing. B retains about
  6199.822745 HP. Crouched muzzle z=0.625 m versus standing z=1.025 m.
- Post-release crouch: release at 111 ms, crouch at 120 ms; actual lowered-head
  hit at 341.590158 ms replaces the baseline standing-torso hit.
- Crouched jump: three rounds hit, including airborne fire. Landing occurs at
  about 1128.395514781 ms, with feet at z=0 and crouched body origin z=0.675 m.
- Arena cube: contact at about 335.910233048 ms freezes crouch at fraction
  0.572734887 and stops translation at x=4.95 m, without stale completion.

All four complete new traces and summaries replay exactly. Default-input CLI
summaries match saved ordinary and jump cases. All **15 previous compact replay
cases** (jump, sprint, gravity, moving gun and Get Up) remain exact. No historical
artifact directory was rewritten. Current README, roadmap and roster scope
statements are updated without treating older historical entries as current.

### Remaining scope and next concrete task

Moving combat still uses fixed facings and the existing 1E2 gun. Posture data
covers both 1E1/1E2 source values, but moving 1E1 area attacks are not integrated.
Climb, turning, knockdown/Get Up geometry, moving area effects and the remaining
kits are unfinished. Finite ground-footprint departure, raised-support departure
and standing on another moving body retain their explicit unsupported cases.
Advanced NPC work and large automated experiment batches remain later work.

Next integrate the existing climb into this same coordinator. Start with approved
climb geometry and root source costs/hand poses; document payment, movement and
interruption anchors under delegation. Verify individual phase/resource/contact
behavior before a climb with live gunfire. Reuse the existing geometry helpers
and action queue, and preserve historical geometry-only climb results.

This is a bounded verified checkpoint. Implementation, review, tests, replay and
handoff are complete for this increment; the overall combat engine is incomplete.
The sandbox command path still fails during bwrap setup, but reviewed escalated
commands succeeded after the author's permission change. No further author
design input was necessary, and no account quota is inferred.

## Climb combat integration in progress, 2026-10-28

The last completed checkpoint remains 874 tests and the posture result package.
Current working changes add `climb_combat.py`, optional `combat_climb.json`,
shared phase dispatch and target-bearing movement intents. A direct standing
run reaches the approved Active start at 150 ms, corner at 318.75 ms and top
centre at 450 ms. Focused interaction tests have been added and are being run;
this is not a completed/fully verified climb milestone yet. A prior baseline
test process disappeared in a server restart with an empty output file; it is
not treated as live or passing and will be replaced by final verification.

Root source audit: 1E1 p194–201 and 1E2 p210–217 specify Gathering 150 ms,
Active 300 ms, self O80/U250 and listed dyspnea 3.5, with no climb hand poses.
Working delegated decisions: retain hands; pay Db3.5 and apply self effects only
after a successful Active-start range check; failed requests do not pay/retry;
stand and exit sprint through existing transitions; climb path ignores a second
U speed subtraction. Physical obstruction cancels the path, uses the shared
velocity projection and then gravity, with no basic-jump self effects. Death
freezes the reached body location and invalidates future phases. The CLI loads
combat flight rules for climbing because interruption can require falling.

Next: resolve focused test failures, verify actual gunfire/obstruction/support
interactions, run full regressions and earlier compact replays, then save a
climb result package and replace this provisional entry with verified evidence.

### Principal engineering review corrections in progress

The author requested evaluation of `PRINCIPAL_ENGINEERING_REVIEW.md` during
climb work. F1–F5 are justified reproduced defects. Working corrections now add
one iterative dispatcher with typed target-bearing intents, explicit handler
outcomes and prerequisite ownership. A blocked prerequisite finishes its parent
once; a later explicit command may retry. No tiny artificial time delay is used.
Current world gravity/support selects an immutable `integrated_v2` rule profile,
independent of future script contents and separate from jump action data.
Flight retains projected ground drive independently of ballistic velocity;
landing no longer adds airborne instability to commanded speed. State records
deep-copy nested hands and locomotion at capture time.

The review's unchanged five-test reproduction script passes, as do 30 focused
climb/cross-feature checks before the latest added cases. The first full run
completed 904 tests with three failures, all historical full-result assertions
whose saved initial hands exhibit F5. Frozen artifacts remain untouched. Those
expectations now reconstruct only initial hands from their own frozen profiles;
all other trace fields still compare in full. Compact historical comparisons
also identify Decimal formatting changes and one new blocked-intent event.
Full final verification, new result packages, and final review
response are still pending; do not claim the old artifacts all replay exactly.

A1–A3 are valid integration prerequisites, not evidence that their unimplemented
abilities already misexecute. Dispatch ownership begins A1; selective action
requirements, independent projectile/world-entity identity, typed effects/area
exposure, paused clocks and revival remain required engine work. These will be
introduced for actual existing abilities without removing their creative features.

## Independent principal engineering review, 2026-10-28

Historical state at inspection; the verified correction entry below supersedes
its pending work and failing-test statements.

At the author's request, reviewed foundational correctness and compatibility
with the six existing kits. No implementation code, character/rule data,
existing scenarios, existing tests, or historical result packages were changed.
Recommendations are reviewer proposals, not new author-specified rules or
implemented mechanics decisions.

The existing suite passes **896 tests in 31.297 seconds**. Five additional
review regression specifications reproduce four P1 defects and one P2 defect:

- F1: a second run request while blocked against a cube enters an endless
  same-timestamp prerequisite/contact/retry cycle; a diagnostic guard bounds
  the reproduction.
- F2: the CLI enables body physics by inspecting future jump/climb commands,
  so appending a future jump changes an earlier ordinary collision outcome.
- F3: landing adds current airborne instability into nominal running speed;
  firing during a jump raises actual ground speed above the documented pace.
- F4: a no-op stop followed by jump, crouch or sprint bypasses dispatch and
  raises KeyError.
- F5: initial_states hands alias mutable combat state and report later poses.

[The full review](PRINCIPAL_ENGINEERING_REVIEW.md) gives exact inputs, code
locations, root causes, practical corrections and acceptance checks. It also
separates verified architectural restrictions from speculative risks: action
ownership/selective restrictions, projectile/world-object identity, and effect,
cooldown and death/revival lifecycles needed by the existing abilities.

Reproduce with `python3 -B results/principal-review-2026-10-28/reproduce.py`.
This review-only script is outside tests/ and intentionally fails until the
five defects are corrected. Its current five test methods report six failed
assertions and three errors because some findings have parameterized cases.
The artifact directory contains baseline and reproduction logs plus hashes of
the inspected implementation/test/data/scenario files.

Next concrete step: fix F1/F4 together through centralized intent dispatch and
explicit blocked-intent outcomes, then fix F2/F3/F5, run the existing suite and
the review regressions, and check compact historical replays. Preserve historical
snapshots. Do not promote the provisional climb integration solely because the
baseline suite is green. The review is complete; the engine remains incomplete.

## Verified review corrections and shared climb, 2026-10-28

Evaluated the requested principal review against the actual worktree and its
unchanged reproduction script. F1–F5 are justified and corrected. A1–A3 are
accepted prerequisites for existing creative abilities, with implementation
status distinguished from proposals in the
[review response](PRINCIPAL_ENGINEERING_REVIEW_RESPONSE.md).
[ENGINE_STATUS.md](ENGINE_STATUS.md) is now the current capability/decision index;
older dated paragraphs and results retain their historical scope.

### Foundational corrections

- F1/F4: `command_dispatch.py` owns one iterative queue of typed movement intents.
  Each handler returns an explicit outcome. No-op consumption reselects the next
  family, including target-bearing climb. Parent prerequisite ownership lets a
  physical block finish that parent once. A later explicit command can retry
  after occupancy changes. No tiny timing delay or recursive retry is used.
- F2: root combat locomotion data declares immutable `integrated_v2` world
  gravity/support, independent of jump/climb commands. Jump-action data and body
  physics are separate. Current CLI definitions load before execution without
  scanning future actions. Frozen inputs retain an explicitly named historical
  compatibility adapter; historical CLI flight requires an explicit flag.
- F3: flight stores commanded ground drive independently of physical velocity.
  Contacts project drive; landing applies existing ground penalties instead of
  adding airborne U into nominal speed. The review reproduction now ends at
  actual 6.3556802276 m/s and nominal 6.4, rather than actual 6.8287026537.
  Prescribed/forced motion is not universally capped to running pace.
- F5: records deep-copy nested hands and locomotion at capture. Earlier records,
  including initial state, cannot be overwritten by subsequent hand changes.

These are technical corrections under delegation, not new author specifications.
Independent shots, bleeds and deployed effects retain their existing lifetimes.
The one controlled-action slot remains a known temporary scheduling boundary;
the dispatcher does not claim full selective action ownership yet.

### Climb integration and decisions

The existing climb now shares movement, posture, gunfire, resources, statuses,
contacts, raised support and death on the same coordinator. Source audit verified
1E1 p194–201 / 1E2 p210–217 (150 ms Gathering, 300 ms Active, self O80/U250,
Db3.5). Author-confirmed range is body-origin-to-surface ≤0.5 m, checked once at
Active start; movement continues during Gathering. The approved path rises to
top height then crosses to top centre at constant speed.

Delegated anchors: retain hands (no source climb poses); check/pay and apply
self effects only on successful Active start; failed range requests pay nothing
and do not retry. Stand/exit sprint through existing actions first. The prescribed
path receives no second U speed subtraction. Physical obstruction cancels the
path, projects velocity and resumes gravity without basic-jump self effects.
Death freezes the reached pose and invalidates completion. Exact contact at a
path corner uses outgoing velocity; exact overhead fit remains legal. Static
top-face landing snaps feet to the true surface, including cube tops, eliminating
a tiny contact-root remainder. [CLIMBING.md](CLIMBING.md) records rationale/limits.

### Verification and preserved evidence

**906 suite tests pass in 36.931 s**: the prior 874 plus 22 climb integration
tests and 10 cross-feature invariants. The independent review's original five
tests also pass unchanged. Coverage includes blocked run/sprint, explicit retry
after blocker departure, 1200 no-ops without stack recursion, mixed action
families, API/CLI prefix invariance, repeated walk/run jumps with self/incoming
U, nested snapshots, range changes, actual climbing gun/body/ceiling contacts,
Gathering extension, exact fit, sprint/crouch handoffs, death and raised jumps.
50/80-digit state and alternate/no observations are exercised.

The initial 904-test full run failed only three historical assertions exposing
F5; those expectations now reconstruct just initial hands from their own frozen
profiles. All other result fields remain checked. No historical artifact was
rewritten. [Nineteen compact comparisons](results/engineering-corrections-2026-10-28/historical-comparisons.txt)
find four exact traces, thirteen with only corrected initial hands, one with
those hands plus 42 numerically identical Decimal-format differences, and one
with a new blocked-intent diagnostic. Their numeric combat behavior is unchanged.
The older jump example did not expose F3; the separate saved review scenario
does. Old exact-output scripts can therefore differ; the comparison script
documents and checks the narrow migrations instead of hiding them.

[Four new climb scenes, frozen inputs, full traces and replay](results/climb-combat/REPORT.md)
match exactly, including the saved-input CLI summary:

- Gun combat: A climbs at 150–450 ms while B fires, then fires from the raised
  hand. At 1600 ms A/B HP≈6537.855727/6946.979816; 3/4 shots released.
- Moving gate: A enters range and climbs at 350–650 ms; B leaves range, fails
  at 250 ms, pays nothing and keeps walking to x=8.84.
- Blocked top: B arrives first. A contacts it at 921.875 ms, cancels crossing
  and stands on cube_1 at x=5.7. No stale completion or repeated impact.
- Raised jump: takeoff 600 ms, airborne fire, landing on cube_1 at
  1252.395514781 ms; feet remain exactly z=1.8 and origin z=2.675.

### Remaining work and next concrete step

Moving weapons still cover only the existing 1E2 gun; the climb/posture source
profiles cover 1E1/1E2 without claiming moving 1E1 areas. Fixed facings, ground
footprint/raised-support departure and support on another moving body remain
guarded. Turning, knockdown/Get Up geometry, moving areas, complete six kits
and general 5v5 remain unfinished. Advanced NPCs and mass experiments are deferred.

Next implement A1: action instances with declared hand/body requirements, atomic
conflict/eligibility checks, per-action payments and selective cancellation.
Begin with the current gun/reload and body actions and verify the upper/lower-body
restriction requirements of the existing 1E3 kit. Preserve independent released
effects outside those locks. Then introduce A2/A3 identities and typed effect/
volume/clock lifecycles for the authored interactions that require them, using
the current engine rather than another runner or ability-specific override layer.

This checkpoint includes implementation, debugging, full verification, replay
classification and durable handoff. The overall goal remains active/incomplete.

## Verified A1 current-action ownership, 2026-10-28

Replaced universal action occupancy in current moving combat with an action
registry: separate exclusive resources, required functions, action-bound
payment receipts/reservations and explicit phase contexts. Current root rules
opt into declared ownership; prior feature tests load a dedicated frozen
exclusive-scheduling fixture. Historical artifacts were not rewritten.

Source audit reconfirmed Details p10 (sprint forbids attacks), p17–27 (hand
Recovery/Gathering), Collision details p4/p10 (O extends unfinished Gathering),
and 1E3 p3/p5 (upper attack/lower movement restrictions). Delegated policy:
gun/reload occupy authored hands and weapon; walk/run/stop and jump occupy
locomotion; posture needs both body functions without owning hands. Climb and
sprint transitions retain hand/body requirements. Independent flight/effects
stay outside controlled locks. [ACTION_OWNERSHIP.md](ACTION_OWNERSHIP.md)
records the consequential decisions, implementation and remaining scope.

### Shared interactions and corrections

- Gun/reload overlap legal ground transitions, jump and posture. Mid-crouch
  launch uses the actual transformed hand position; parallel actions cannot
  overwrite hand ownership. Phase/contact paths bind the relevant action ID;
  ambiguous implicit access and foreign-actor ownership fail explicitly.
- Deferred costs reserve bounded capacity against other controlled debits,
  retaining existing calculation/payment anchors. Cancellation before payment
  releases only that reservation. Continuous sprint can invalidate an unpaid
  body payment and uses existing defer/cancel/exhaustion rules without a debit.
- Source-specific upper/lower restrictions compose and refresh by generation;
  exact expiry is half-open. They cancel only affected actions, stop voluntary
  lower drive while preserving existing physical flight, and wake waiting
  decisions. Death cancels every owned action; released shots persist.
- Incoming O applies once to state and extends every unfinished Gathering.
  Self O from one action also extends another future Gathering, excluding the
  causing action and already due Active boundaries. Active never gains Gathering.
- Tests exposed three false no-ops: stand during crouch Gathering, sprint during
  a sprint exit and stop during climb. They now wait for the changing property
  rather than disappearing or changing an owned path. Cancellation receipts are
  deduplicated across restriction, physical contact, exhaustion and death.

### Verification and results

**943 tests pass in 43.916 s**: the previous 906 plus ten registry and 27 shared
ownership tests. The principal review's original five tests pass unchanged in
1.264 s. Precision, observation schedules, actor input order and public CLI
prefix controls pass. Four new full traces and CLI replay match exactly; four
prior climb traces/CLI also match with frozen inputs. Nineteen historical cases
and the corrected F3 trace still match their documented classifications.
[Report and frozen inputs](results/action-ownership/REPORT.md),
[full tests](results/action-ownership/full-tests.txt),
[replay](results/action-ownership/replay-log.txt),
[historical comparisons](results/action-ownership/historical-comparisons.txt).

The run/jump/gun scene takes off at 497 ms and lands at 1149.395515 ms while
gunfire continues. Upper restriction permits running before expiry at 500 ms;
lower restriction permits gun releases at 111/511/911 ms and movement after
expiry. Empty-magazine reload runs 4111–6030 ms while a separate jump takes off
at 4326 and lands at 4978.395515 ms. Initial restrictions represent pre-applied
existing freeze conditions, not implemented 1E3 casts/projectiles/marks.

### Remaining boundary and next concrete task

A1 is verified for current moving gun/reload and body actions. Full six-kit
requirements, phase-specific transfers and extra-limb mappings remain kit work.
Moving weapons still cover only the existing 1E2 gun; the body profiles cover
1E1/1E2. Fixed facings, support/ground departure guards, moving areas, dynamic
entities and revival remain unchanged limitations.

Next implement A2 independent projectile/world-object identities and explicit
contact policy. Begin with flight identity separated from parent action,
owner/source attribution and safe owner-contact eligibility; reuse current
trajectory/contact mathematics and verify with existing flights before adding
authored duplication, owner consumption and damageable/expiring colliders.
A3 typed effect/volume/clock lifecycles follow for actual existing interactions.
The overall goal remains active and incomplete; advanced NPCs, mass experiments
and balance automation remain deferred.

## Verified A2 projectile foundation, 2026-10-28

Physical shared flights now use independently allocated entity IDs rather than
their releasing action ID. Immutable attribution stores owner, source ability,
parent action/projectile, root projectile and creation time. Straight, gravity
and stationary body paths share the registry. A composition component connects
it to the existing coordinator without another ability-specific override layer.
[PROJECTILE_ENTITIES.md](PROJECTILE_ENTITIES.md) records sources, delegated
choices, implementation and boundaries.

### Interactions and consequential decisions

- Explicit per-projectile policies choose owner, other-body and terrain contact.
  Default gun/Qard behavior is preserved. Owner-enabled projectiles born inside
  the body stay immune until their sphere clears the union of all body parts;
  owner consumption then ends only that projectile, without ordinary hit damage.
  Continuous interval enclosures handle translation, acceleration, posture
  resizing and exit/re-entry without observation-based arming. Numerical
  tolerances and rounding match the documented diagnostic scope.
- Copying through the shared API creates an independent flight with source
  attribution, current momentum and retained actual path-distance falloff. It
  does not refire/reaim/spend another round or cost. Parent and child inherit
  visited field-instance IDs, preventing repeated copying by one source while
  permitting independently active fields. Inert/terminal shots cannot copy;
  an undecelerated ballistic apex remains active.
- Contact/stop/clearance events carry entity revisions. Parent collision/removal
  cannot discard a child or its terminal event. Copies preserve attribution and
  hit after owner death. Reached numerical clearance confirmation survives
  subquantum events and Decimal/binary64 endpoint rounding; stale generations
  cannot resurrect contacts. Updated the old contact harness to use the registry
  while retaining its original thin/grazing-boundary checks.
- Source audit: 1E3 p11 requires entering-projectile duplication; 2E4 p9 and
  p97–117 require owner-contact consumption and a separate attack. Identity,
  immunity, copy ancestry and trace choices are delegated engineering decisions.
  The new probes are explicitly labelled fixtures, not new abilities or claims
  that these two full casts/field/secondary-attack lifecycles are integrated.

### Verification and reproducible evidence

**980 tests pass**, the previous 943 plus 17 entity/clearance tests, 18 real
shared interaction tests and two numerical-boundary regressions. Precision,
observation schedules, actor order, multiple impacts with shared defenses,
same-source recursion, retained falloff, owner contact, independent removal/
stopping and post-death attribution pass. The original five review checks
remain unchanged and passing. [Report](results/projectile-entities/REPORT.md),
[full tests](results/projectile-entities/full-tests.txt),
[new replay](results/projectile-entities/replay-log.txt).

The ordinary run/jump/gun scene reproduces the earlier numeric outcome with
eight independent projectile IDs. The copy fixture produces two hits linked
to one action without another round/payment. Owner geometry probes record
clearance/consumption at 264.000643/795.997345588 ms and ballistic return at
325.635610/881.732383 ms. All four complete traces replay exactly; ordinary
combat matches the public CLI in full. Four prior ownership and four prior
climb full traces/CLI replay exactly with frozen inputs.

Frozen inputs retain a legacy **presentation** adapter; internal IDs remain
independent. Old result files/scripts were not rewritten. The current
[historical comparison](results/projectile-entities/compare_historical.py)
checks nineteen compact cases and the corrected F3 trace. Apart from the
previous F1–F5 classifications, it removes 14 obsolete expected pending stop
events for already collided flights in the old moving-gun duel. This is a
reporting/liveness correction; no numeric state, calculation or actual event
is normalized away. Earlier strict scripts can fail on that new correction.

### Remaining scope and next concrete task

A2 is partial. The copy API is not actual 1E3 field entry, allied eligibility
or 3 m split placement; owner consumption is not the 2E4 follow-up attack.
Production moving weapons remain the existing 1E2 gun, with body profiles for
1E1/1E2. Historical confirmed-hit runners retain their event-only representations.
Full six-kit requirements, fixed-facing/support guards and A3 lifecycles remain.

Next implement world-collider identity/lifecycle: stable IDs/revisions, optional
HP and expiry, explicit projectile/body/area blocking, and invalidation of
predicted contacts when a collider changes or disappears. Reuse the current
contact mathematics and verify removal exposing a later trajectory before
porting authored prison/wall destruction. Then add typed effects/volumes and
actual duplication, moving exposure, pause and revival interactions. The goal
remains active/incomplete; NPC learning and mass experiments remain deferred.

## Verified fixed world collider lifecycle, 2026-10-28

Current moving combat now uses a composed world registry for fixed/compound
objects, optional shared HP/lifetime and independent projectile/body/area
blocking. Stable identities preserve source attribution, including after owner
death. State, collision and expiry revisions are separate: nonlethal HP damage
keeps valid contact evidence, while structural/removal changes invalidate it.
[WORLD_COLLIDERS.md](WORLD_COLLIDERS.md) records the complete delegated rules,
source references, implementation and boundaries.

### Shared mechanics and consequential decisions

- Parts form one object/HP pool, allowing a hollow six-part shell around a body.
  Source audit reconfirmed 1E3 p9 (4000 HP, 12 s, blocks both directions) and
  3E5 p17 (qualifying charge destroys walls). No ability cast or charge was added.
- Supported nonpiercing projectiles in one batch all hit the pre-batch object.
  Their actual-path falloff is retained; applied HP loss floors at zero, and
  overkill does not pass through a newly destroyed barrier. Later flights can
  pass. Construct HP has no invented armor, bleeding, statuses or regeneration,
  and grants no character healing/revival credit. These are delegated choices.
- Creation/reshaping rejects positive body penetration; exact touch is allowed.
  Creation over a flight and at a moving body's face triggers immediate rescans.
  Contacts carry collider revisions; body predictions carry a collision epoch.
  Expiry is half-open, refreshed clocks invalidate their older events, and
  expired geometry cannot become climb support at a tied completion phase.
- Removal/reshape interrupts affected climb with retained momentum. Lost support
  transfers to a valid remaining support or becomes a real gravity fall, without
  a paid basic jump or its landing self effects. Independent gun actions survive.
  Compound landing uses the hit part, not the first part's unrelated height.
- Tests found an inherited geometry-only support validator treating falling
  bodies as standing. Moving combat now uses its airborne support validator,
  permitting support-loss flight and jumping off a raised platform. Ordinary
  grounded ledge departure, finite-ground departure and moving-body support are
  still guarded. Registered geometry fixtures retain earlier ceiling tests.
- Area policy filters representative radial/downward witness rays in both
  directions; ordinary cubes remain area-transparent. Dynamic area damage to
  collider HP and live heat/poison membership remain A3 work. Unsupported live
  heat cover changes reject before mutation; terminal removal is a no-op.
- Result scope resolves compound objects/cover from current world rules while
  configuration preserves input scope for replay. Complete results and compact
  summaries expose deployed/changed object HP, status, expiry and policy.

### Verification and ordinary API/CLI scenes

**1022 tests pass in 50.159 s**: the previous 980 plus 14 pure registry/cover,
26 shared interaction and two numerical-boundary checks. Focused verification
passes 48 checks including six earlier rounded-contact regressions. The original
principal-review script passes all five unchanged tests. Precision, observations,
actor order, source death, simultaneous damage, exact-touch creation, expiry ties,
shape/policy changes, compound support and actual falling are covered.
[Report](results/world-colliders/REPORT.md),
[full suite](results/world-colliders/full-tests.txt),
[focused checks](results/world-colliders/focused-tests.txt).

All four new complete traces replay through the ordinary shared API **and full
public CLI**, without an encounter subclass or injected runtime operation:

- Gate: hits at 121.663415/521.663415 ms destroy 500 HP; subsequent shots reach B,
  leaving B at 7390.36477776 HP at 1500 ms.
- Expiry: the 4000-HP panel disappears at 200 ms during flight. The shot reaches
  B on its original trajectory; no phantom collision or collider HP loss.
- Shell: six parts share 4000 HP; opposing shots leave 3150.81502181 HP and both
  characters at 8140. This is initial geometry, not a prison cast.
- Support: climb finishes at 450 ms, platform expires at 600, and actual ground
  landing occurs at 1205.782532815 ms while gunfire continues.

Prior projectile, ownership and climb packages still replay exactly with frozen
inputs. Nineteen compact historical cases and corrected F3 retain their existing
classified reporting differences; old evidence was not rewritten.
[Current replay](results/world-colliders/replay-log.txt),
[historical comparisons](results/world-colliders/historical-comparisons.txt).

### Next concrete step and remaining goal

The A2 projectile/fixed-world foundations are verified for supported types;
actual prison, qualifying wall charge, duplication-field and owner-contact
ability delivery remain unfinished. Moving weapons still cover the existing
1E2 gun; body profiles cover 1E1/1E2. There is no continuous platform motion.

Next introduce A3 typed persistent effects and independently identified volumes
on this coordinator. Start with the existing heat beam's lifetime and per-target
exposure/residual state, preserving stationary evidence. Then verify moving
entry/exit/re-entry and cover changes, and resolve ongoing heat with shield
regeneration before claiming that interaction. Composable paused clocks,
source-attributed damage/revival and remaining kit delivery follow. The full
six-character/general 5v5 goal remains active and incomplete; advanced NPCs,
mass simulations and balancing automation remain deferred.

## In progress: A3 typed heat volumes, 2026-10-28

**Preparation note; superseded by the verified checkpoint below.**

The original principal-review reproductions still pass unchanged (5 tests,
1.720 s). A typed persistent-effect component and independent heat-column
membership are being integrated into the existing coordinator. The initial
88-test focused compatibility run passes. This work is **not yet a verified
checkpoint**; the preceding 1022-test checkpoint remains the reference.

Pending verification covers actual moving 1E1 beam casts, entry/exit/re-entry,
overlapping source attribution, shield depletion, continuous construct damage
and cover removal. Ongoing heat with shield regeneration remains guarded.
Delegated thermal-memory and cover semantics will be recorded with evidence
before claiming integration. Paused cooldowns, revival and remaining kits are
still incomplete.

## Verified typed heat volumes and moving exposure, 2026-10-28

The first A3 increment now runs in the same coordinator: source-attributed typed
bleeding/thermal instances, independent beam volumes and per-target membership,
layer and residual clocks. Existing 1E1 ability 4 casts in moving combat beside
the existing body actions and 1E2 gun. No runner or character ability was added.
[SPATIAL_EFFECTS.md](SPATIAL_EFFECTS.md) records current primary-source references,
delegated rules, architecture, compatibility and remaining boundaries.

### Decisions and corrected interactions

- Each beam snapshots its location at Active start and remains independent of
  the caster. Per-source heat uses current defenses, full-strength once-per-body
  membership and friendly fire. Caster death or cancellation of controlled
  summoning after deployment cannot erase its volume or residual effects.
- Delegated re-entry stores nonnegative q: +1/s while exposed, -k/s outside,
  floored at zero. Re-entry resumes remaining memory; fully cooled re-entry
  starts a new episode. Revision-bound cooling timers cannot expire resumed
  exposure. Different beams/targets/layers retain independent tracks.
- Confirmed shield behavior is preserved: zero shield defenses, no HP exposure
  accumulation under shielding, fresh HP tracks at depletion, and no shield
  residual transfer to HP. Source/action/projectile identities survive into
  typed bleeding; unknown effect/curve types explicitly reject.
- Rational polynomial cell boundaries handle moving/resizing cuboids and fixed
  cover witnesses without time samples or damage ticks. Final membership settles
  horizon-time cover changes without advancing time. Sorted membership events
  make multi-target expiry independent of Python hash seeds.
- HP constructs also receive heat once per object with zero inferred defenses,
  excluding their own parts from cover. Their HP exhaustion removes geometry and
  exposes bodies at that same continuous boundary, without retroactive exposure.
  Undamageable/default area-transparent terrain retains its confirmed behavior.
  Construct loss grants no character healing/revival credit.
- Verification exposed an expiry discrepancy: collider damage was rejected at
  expiry even when it represented the preceding continuous interval. The registry
  now accepts loss on that left interval before expiry while point hits at the
  same instant still see inactive geometry. Terminal objects remain terminal.
- Affine heat segments retain per-loss shield-recovery distributions. Ongoing
  heat with shield regeneration remains explicitly guarded and tested; this
  preparatory history support is not a claim that the interaction is complete.

### Verification and ordinary API/CLI encounters

**1066 tests pass in 54.499 s**, including 44 new tests: 17 primitive geometry,
memory/integral/history, 25 shared interaction and two registry boundary checks.
Focused verification passes 58 checks (4.860 s). All five original principal
review tests pass unchanged (1.356 s). Real gunfire changes current heat defenses;
jumping, selective cancellation, source death, precision (50/80 digits),
observations and actor order are exercised. [Report](results/spatial-heat/REPORT.md),
[full suite](results/spatial-heat/full-tests.txt).

Six new complete captures replay exactly through ordinary API and full public
CLI, with frozen production definitions and 98 source/input hashes. No encounter
subclass or injected operation is used in these captures:

- Running B exits at 1440.4375 ms and finishes at 7063.11556291 HP after cooling.
- C enters later at 621.72012643 ms and exits at 2714.85487357 ms, independently
  of the target present at deployment.
- A 1000-HP roof burns away at 1697.72110884 ms; B begins fresh exposure there,
  finishing at 6378.61417531 HP. The roof is initial geometry, not a prison cast.
- Two independently cast beams deplete B's 4000 shield at 2523.44316694 ms,
  then create separate HP tracks; final B HP is 6960.89622207.
- B's real gun kills A at 643.992849 ms, while A's volume persists to 3292 ms
  and its residual completes at 4792 ms. B finishes at 3593.36663013 HP.
- A/B/C all receive one friendly-fire beam; complete CLI output matches at hash
  seeds 1 and 123, including per-target expiry order.

All previous collider/projectile/ownership/climb captures still replay with
frozen inputs. The current nineteen-case historical comparison plus corrected
F3 retain existing classified reporting corrections; old evidence is unchanged.
[New replay](results/spatial-heat/replay-log.txt),
[prior replays/comparisons](results/spatial-heat/prior-replays.txt).

### Next concrete step and remaining goal

Resolve ongoing heat plus shield regeneration on this coordinator, including
HP/shield layer transitions, simultaneous sources, continuous recovery supply
and observation-independent boundaries. The affine loss history is ready for
that work; no author decision is required for its technical design.

Then extend typed clocks/volumes for composable pauses and existing effects,
establish applied source-damage credit/life generations, and deliver remaining
abilities. Moving Qard/poison and full kits remain unfinished, as do the existing
facing/support/Get Up geometry guards. The broad six-character/general 5v5 goal
remains active/incomplete. Advanced NPCs, mass simulations and balancing
automation remain deferred. This is a verified bounded checkpoint.

## In progress: analytic recovery-flow prerequisite, 2026-10-28

**Preparation note; superseded by the verified prerequisite below.**

The next heat/regeneration interaction requires recovery rates and exact queue
boundaries, not only per-interval totals. An immutable analytic recovery plan
now represents supply-limited root-rate pieces and capacity-limited constant
pieces, with read-only prefixes and generation/owner-bound single consumption.
The rate family stays closed when recovered work becomes a later shield loss.
22 primitive checks pass; current typed-world data is being connected to these
plans for ordinary regeneration. Full verification is still pending.

This is a prerequisite, **not completed simultaneous heat/regeneration**. The
remaining zero-shield case needs continuous allocation and incident thermal
memory so fresh recharge cannot repeatedly reset heat clocks or grant immunity.
The existing overlap guard remains active. Preserve individual delayed losses,
independent sources and continuous damage in that forthcoming coupling.

## Verified analytic recovery-flow prerequisite, 2026-10-28

Current typed moving-world inputs declare `shield_recovery.mode=analytic_flow_v1`.
Ordinary shield regeneration now previews and commits immutable analytic flow
plans on the shared coordinator. Positive recovery events expose rate pieces,
their clocks and numerical tolerance. This preserves actual per-loss delays and
one shared capacity; initially missing shield gains no invented recovery.
[RECOVERY_FLOW.md](RECOVERY_FLOW.md) records source rules, engineering decisions,
math, APIs, compatibility and exact remaining coupling requirements.

The planner separates supply-limited positive root rates from capacity-limited
constant rates. It finds both capacity crossings and backlog exhaustion, handles
point arrivals half-open at the right endpoint and solves constant-rate times
directly. Forecasting never mutates state. Committing is single-use and checks
owner, generation, work baseline and immutable history; even legacy direct-list
edits invalidate consumption. Nested curve inputs/records are detached.

The constant-plus-root rate family remains closed when recovered work becomes a
later shield loss. `sum_root_v1` retains that distribution without ticks. Cooling
zero now contributes an expression knot even if a recorded interval extends
farther; otherwise the service solver's concavity assumption can be invalid.
Frozen inputs without the new flag retain the earlier accumulator/presentation.

**1094 tests pass in 61.044 s**, including 28 new checks (22 primitive, six shared
combat). Focused verification passes 64 checks in 10.645 s; all five original
review checks pass unchanged in 1.381 s. Precision (50/80 digits), irregular
observations, prefix consumption, stale plans, delayed curve composition and
live-world read-only preview are exercised. [Evidence](results/recovery-flow/REPORT.md),
[full suite](results/recovery-flow/full-tests.txt).

Two ordinary 35-second captures match complete API/CLI output, using frozen
production definitions and 98 source/input hashes. A real beam's 4000 absorbed
shield loss recovers after its individual delays while the caster remains dead
and B stays at 8140 HP. A single existing gun magazine leaves B at
7447.25132108 HP and eventually restores 4000 shield. Three isolated analytic
forecasts also reproduce. These captures have no subclass/injected operation;
zero-delay/high-capacity diagnostic values are labelled math fixtures.
Earlier heat/collider/projectile/ownership/climb captures and the current nineteen
historical comparisons plus corrected F3 still replay; old evidence is unchanged.

### Next concrete step — required coupling, not solved here

**Simultaneous incoming heat and shield regeneration still raises the existing
scope error.** This increment supplies the required rate trajectory; it does
not substitute for that interaction. Next combine recovery work with incoming
heat before finding shield exhaustion, and handle a shield held at zero without
repeated fresh thermal clocks, arbitrary recharge thresholds or zero-time loops.
Incident thermal state, partial protection/layer exposure and warm HP memory
when shielding reforms need documented engineering rules and actual interaction
tests. Positive profile delay must prevent unrecorded losses entering supply
early. Use the new curve family when spent recovery becomes later eligible loss.

Do not merely remove the guard or add regenerated HP after a heat-only boundary
search. [The detailed requirements](RECOVERY_FLOW.md) identify the continuation.
No author input is needed for this technical work. Paused clocks, damage credit,
revival, remaining abilities and broader spatial support still follow. The full
six-character/general 5v5 Goal remains active/incomplete; advanced NPCs, mass
simulations and balancing automation remain deferred.

## Preparation note: coupled shield/thermal balance, 2026-10-28

Implementing the required heat/recovery interaction, including zero-stock
continuous absorption and body thermal memory. The selected engineering model
and verification requirements are in [HEAT_SHIELD_COUPLING.md](HEAT_SHIELD_COUPLING.md).
The 1094-test checkpoint remains the verified reference; the new interaction
is not yet claimed complete. Existing abilities and their identities are retained.

## Verified checkpoint: continuous heat/shield recovery, 2026-10-28

The previously rejected incoming-heat/recovery overlap now executes in the shared
engine. Current definitions select `heat_shield_coupling.mode=fluid_layers_v1`,
composing typed heat volumes and immutable analytic recovery plans. No new
ability, separate runner or rewritten historical capture is introduced.
[HEAT_SHIELD_COUPLING.md](HEAT_SHIELD_COUPLING.md) records the source rules,
delegated decisions, equations, numerical limits and implementation scope.

### Architecture and consequential decisions

- Shield depletion uses **net** balance `S=S0+U-L`, locating intermediate stock
  exhaustion even when the end balance is positive. Positive stock absorbs full
  incident heat. At zero stock, returning shield is immediately spent up to the
  incident pressure; independent sources share absorption proportionally.
- Geometric incident memory persists while shield stock is zero. Body memory
  evolves separately: exposed `dq/dt=1-3*theta`, outside `dq/dt=-2`, floored at
  zero, where theta is the protected-time fraction. Warm body heat cools rather
  than disappearing under reformed shielding and can still damage HP. These
  partial-protection/warm-memory choices are **delegated engineering decisions**.
  The author's initially cold HP start, shield residual non-transfer, current
  defenses and independent deployment survive unchanged.
- Analytic shield loss retains its actual time distribution. Recovery consumed
  under heat becomes another individually delayed loss; it grants no character
  healing/revival credit. HP components retain source identity; simultaneous
  applied-overkill credit remains separate unfinished work.
- Immutable conditional thermal plans compose with the existing coordinator.
  Body heat/dose uses adaptive Decimal Dormand–Prince 5(4) and dense prefixes;
  shield work remains analytic. Epochs are bounded by 250 ms and delay/2, stop
  at cooling zero, and invalidate at actual physical changes. Observations read
  prefixes without selecting adaptive steps. Future commands cannot change past
  state. Recovery cursors validate owner/history/baseline and consume work once.
- Tests exposed and corrected cancellation of an incident cooling timer on
  shield detachment, fractional-delay curve support roundoff, and tiny numerical
  recovery debts producing artificial micro-stock. The opt-in 1e-24 HP work
  budget retains residual debt and clips service to eligible supply. Signed root
  classification handles nearly equal clocks and short heating intervals.
  Solver controls are recorded; no certified global ODE error bound is claimed.
- Caster death preserves released heat. Recipient death freezes its resources
  and recovery. Once incident heat fully cools, ordinary recovery resumes;
  future beams can start another coupled episode. Frozen inputs lacking the
  coupling mode retain their named legacy behavior and historical overlap guard.

### Verification and ordinary encounters

**1129 tests pass in 89.995 s**, including **35 new checks**: 20 primitive/numerical
and 15 shared-combat tests. **88 focused checks pass in 36.175 s**. The principal
review's original **five unchanged checks pass in 1.450 s**.
[Full evidence and commands](results/heat-shield-coupling/REPORT.md).

Seven ordinary API captures match complete public CLI traces with frozen
production definitions, 100 ms observations and 104 source/input hashes:

- Zero-stock recovery under the third beam ends at **4905.839971 HP / 1928 shield**
  at 26 s; no break/reform chatter or repeated cold HP reset occurs.
- Sprint/stop changes exposure timing; net recovery preserves **8140 HP** and
  **80.114657 shield**, while the no-recovery control breaks shield.
- Matched delayed supply and a second caster's beam hold shield at exactly zero
  while protecting a cold body. Balanced and overlap CLI captures also match
  hash seeds 1 and 123.
- Gunfire kills the caster during coupling; its beam persists. Consumed recovery
  becomes eligible again after 20 s. At 45 s B has **4000 shield**, after
  **4328.862551 cumulative recovery**; no initial deficit is fabricated.
- Two overlapping casters retain attribution and share one recovery flow;
  moving exit and warm-body residual death also execute. A 3000-HP recipient
  dies at **21.513921715 s with 133.568686 shield** after reformation, then receives
  no further recovery.

Engineering API tests additionally cover temporary cover/re-entry, real gunfire
changing defenses and breaking reformed stock, jumping, stale history rejection
and tight numerical controls. They do not claim a construct ability. 50/80-digit
runs, 113/37 ms observations and reversed actor order agree within 1e-8 HP and
1e-18 shield in the checked overlap case. A future jump preserves the exact
earlier event prefix. Prior recovery, spatial heat, world collider, projectile,
ownership and climb captures replay; nineteen historical cases plus corrected
F3 keep their documented classifications. Existing evidence remains unchanged.

### Remaining Goal and next concrete step

The review's F1–F5 fixes and supported A1/A2/A3 foundations are verified; A3 and
the full six-character/general 5v5 Goal remain **active/incomplete**. This is a
bounded verified checkpoint, not full engine completion.

Next implement **cooldown remaining-work clocks with composable pause sources**,
then deliver the existing **1E2 ability 2 cooldown-pause area** through typed
volumes. Read its root source/timing/status rules first; preserve overlapping
sources, exact entry/exit/expiry boundaries and independent released effects.
Keep phase readiness and weapon cooldown ownership explicit. Test real casts
and moving entry/exit before claiming that ability integrated. No author input
is needed for these engineering choices.

Attributed applied-loss credit/life generations precede healing and revival.
Moving Qard, poison, restrictions/marks, construct/duplication/owner-contact
delivery, chains/grabs/portals and other kits remain. Fixed-facing, broader
support departure and moving Get Up/knockdown geometry guards are unchanged.
Advanced NPC behavior, mass simulation and balancing automation remain deferred.

## Author clarification: dyspnea follows effort, 2026-10-28

The author confirms no dyspnea value for **1E1/4, 1E2/5, 1E3/3, 1E3/Ultimate,
1E5/4, 2E4/2, 2E4/Ultimate and 2E4/5**. Summoning, marking, a passive effect or
activating an enhancement is effortless in these examples; revival is explicitly
preferred without cost. The block-triggered effect adds no cost to its block,
and passive/enhanced effects add no independent cost to the underlying attack.
The broader author preference is no cost for effortless extrinsic activation;
documented physical effort, such as 1E2's recoil control, retains its cost.

Recorded this in [DESIGN_PREFERENCES.md](DESIGN_PREFERENCES.md), the new
[DYSPNEA_POLICY.md](DYSPNEA_POLICY.md), source-only `documented_abilities` metadata
in `data/characters.json`, the roster and earlier audit's absent-cost question.
The confirmed exemption is `kind=none`, not Db=0: the latter still charges
`(D/100)^2` at nonzero D. No value, capacity reservation or debit is needed for
an exempt activation, including at a full bar. Do not invent a cost or ask for
a missing number on an effortless summon/mark/passive during later integration.
Resolve any actual effort/timing gaps under the existing delegation.

The existing shared beam already implements the exemption. Executable ability
maps for all six characters are unchanged from the 1129-test checkpoint;
Qard Db=2, gun recoil Db=2, reload Db=0.5 and listed block/attack effort remain.
The other seven clarified effects remain unimplemented in shared combat;
source metadata is not an integration claim. General Recovery/Gathering,
cooldowns, restrictions and dyspnea-recovery blockers are separate and unchanged.
Original ODTs and historical result packages remain intact.

Verification: **70 existing tests pass in 6.721 s** with
`python3 -B -m unittest tests.test_dyspnea tests.test_action_dyspnea_phases tests.test_source_revisions tests.test_owned_actions_combat -v`.
All eight metadata exemptions bypass payment at D=0/50/100 across Gathering,
Active start and firing end. An ordinary production shared-engine probe deploys
1E1's beam at **292 ms** at each initial D=0/50/100, with no dyspnea payment or
maximum trigger. Confirmed costed definitions and executable ability maps match
the prior frozen profiles. No simulation formula changed and no new test suite
or full-kit execution claim is introduced by this data/documentation correction.

The previous goal turn made verified engine progress; this turn records and
verifies additional author rules. The broad Goal stays active/incomplete.
Next remains cooldown work/pause composition and the existing 1E2 pause-area
delivery, applying the effort policy when reviewing its source. Attributed
damage credit, revival lifecycles and remaining abilities still follow.

## In progress: composable cooldown work and 1E2 marking, 2026-10-28

Implementing remaining-work clocks and the existing cooldown-pause area on the
common coordinator. Source rules, selected delegated interpretations and
verification requirements are in [COOLDOWN_PAUSES.md](COOLDOWN_PAUSES.md).
The detailed source's older 0.5 marking dyspnea is retained as history while
the new effortless-activation preference supplies an explicit exemption.
This does not yet claim integration; the 1129-test checkpoint remains verified.

## Paused handoff: cooldown work and 1E2 area verified, 2026-10-28

The author paused the Goal after implementation and verification, during final
documentation cleanup. Stop engineering work until resumed. The preceding
in-progress entry is superseded: **1159 tests pass in 107.187 s**, the focused
30 pass in 22.675 s, and the original five review checks pass in 1.408 s.
Eight ordinary captures match complete API/CLI traces, including hash-seed
controls; earlier coupled heat/recovery, recovery, heat, collider, projectile,
ownership, climb and classified historical replays all pass.

Implemented remaining-work cooldowns with independent pause sources, live
membership, obsolete-wait invalidation, exact field handoff and stopped dead
clocks. Existing 1E2 ability 2 now deploys its independent 8 m / 4 s area after
200 ms Active; its cooldown starts at activation request. Marking uses the new
effortless-activation preference; source-listed 0.5 remains recorded as history.
Physical phases/reload/effects/shield recovery continue while cooldowns pause.
Source rules, delegated geometry/pose/timing decisions and limitations are in
[COOLDOWN_PAUSES.md](COOLDOWN_PAUSES.md).
[Evidence](results/cooldown-pauses/REPORT.md) records measured gun/overlap/exit,
reload, heat and death interactions. No full-kit or revival claim is made.

On resume, finish bookkeeping before starting another subsystem:

- The new `results/cooldown-pauses/source_hashes.json` was captured before the
  final mechanics/policy documentation and final added heat/recovery test.
  Refresh the affected manifest entries and verify all 106 hashes; the runtime
  source/input definitions and complete replay results are already verified.
- Update 1E2's `documented_abilities_status` description: it still says other
  abilities are source-only, although ability 2 now executes. Preserve frozen
  inputs/results, or explicitly verify any metadata-only capture refresh.
- Check final local Markdown links and current status text. Documentation edits
  since the final passing tests changed no simulation code or numerical data.

Next substantial work remains attributed applied-HP-loss credit and explicit
life generations before healing/revival. Remaining abilities and broader
facing/support/Get Up geometry still need integration. Advanced NPCs, mass
simulation and balancing automation remain deferred. The Goal is paused,
not complete or blocked.

## Resumed: handoff complete; applied HP attribution in progress, 2026-10-28

The author resumed the Goal. The previous turn made verified progress and
stopped at the requested pause. Cleanup now verifies all 106 source/input hashes
and repeats eight complete API plus ten CLI confirmations. The original capture
manifest is preserved separately. The author revised `1E2.odt` while paused:
the mark's old 0.5 cost is now extrinsic-momentary activation, consistent with
the runtime exemption. A source snapshot and both hashes are retained. Current
coverage metadata is corrected; frozen inputs/results are unchanged. Links
were checked and executable ability maps match the verified captures.

Next implementation is attributed applied-HP-loss history. Source rules,
delegated overkill/eligibility/window decisions and required verification are
in [DAMAGE_LEDGER.md](DAMAGE_LEDGER.md). This is required shared infrastructure
for healing/revival and source-specific effects, not an isolated substitute
for those abilities. Integration remains unclaimed until actual shared-engine
interactions and continuous-window evidence pass.

## Verified checkpoint: applied HP attribution and windows, 2026-10-29

Current shared combat now records actual applied HP losses with immutable
source/time receipts and analytic or dense dose curves. This completes the
applied-loss history prerequisite identified in the principal review; it is
not a healing payout or revival implementation.
[Rules and decisions](DAMAGE_LEDGER.md) ·
[Evidence and commands](results/applied-hp-credit/REPORT.md).

### Architecture and consequential decisions

- Direct and continuous damage record at the authoritative HP commit. Source
  actor/ability/action, projectile/effect/volume and component identity remain.
  Simultaneous overkill is split by nominal post-defense HP weights, with a
  deterministic finite-precision residual correction. Shield, armor and
  construct losses do not become character recovery credit.
- Friendly/self HP loss remains real and auditable. Under delegation, only
  damage to another team's actor generates outgoing healing/revival credit;
  this prevents self/friendly damage farming. Incoming HP-loss windows include
  all real HP losses. Eligibility is snapshotted when loss applies; owner death
  does not erase credit from released effects.
- Point windows use `(end-window,end]`. Continuous windows integrate clipped
  intersections. Bleed/affine heat retain analytic curves; coupled body heat
  retains copied quartic cumulative-dose steps and affine segments from its
  actual conditional plan. No uniform spreading or endpoint-only thermal
  reconstruction is used. Observations can split rows without changing the
  tested integrated windows.
- The ledger owns its Decimal precision, exports re-readable curves/receipts,
  rejects duplicate receipts and validates writes before mutation. Attack
  identity excludes recalculated damage values, so a repeated attack cannot
  gain another receipt after defenses change. Dense coefficients must agree
  at their endpoints; positive credit cannot arise from a zero nominal loss.
  Numerical validation budgets are explicit in the mechanics document.
- Current world data opts into `damage_ledger.mode=applied_hp_v1`; frozen inputs
  retain their old presentation and physical outcomes. No damage, resistance,
  bleed-delivery or death formula changed. The resumed pause-area handoff was
  completed first, preserving original and revised 1E2 source provenance.

### Verification and ordinary encounter evidence

**1192 tests pass in 121.998 s**. The **33 focused tests pass in 14.698 s**:
18 ledger/API and 15 shared-combat checks. The original five review checks
pass unchanged. Nine ordinary production-runner scenarios reproduce complete
API/CLI traces and saved-history queries; simultaneous/fluid cases also match
two hash seeds. All prior pause, heat/recovery, recovery, spatial heat, collider,
projectile, ownership and climb captures replay with their frozen definitions.
The nineteen classified historical cases and corrected F3 remain verified.

Measured results include:

- Three shots/bleeds apply **1194.612532 HP** in one second, fully attributed.
- Two simultaneous guns or two continuous beams share one 100-HP victim budget:
  each source receives **50 HP**; nominal overkill gives no extra credit.
- A shield-only hit gives zero HP credit. An intervening ally takes
  **1207.521500 HP** from friendly fire but gives zero recovery entitlement.
- A deployed beam keeps **4546.633370 HP** attribution after its caster dies;
  the opponent's lethal shot against that caster's 1 HP earns **1 HP**.
- Eleven shots and real bleeds yield **4951.266825 HP** by 12 s; last-10-second
  outgoing credit is **2911.541864**, while last-8-second incoming HP is
  **702.588816**. Independent integration from actual bleed deliveries agrees.
- Coupled heat/recovery yields **3234.160029 actual HP**, ends at **1928 shield**,
  and gives **1509.326100 HP** in the last 10 s. The clipped 20037–21037 ms
  nonlinear window is **487.295673853 HP**, matching independent HP-prefix runs.
  Shield absorption/recycling does not add HP credit.

Source/target death, self/friendly damage, construct exclusion, paused cooldowns,
saved JSON roundtrips and duplicate-credit defense changes are covered. 50/80-
digit, 113/37 ms observation and reversed actor insertion controls agree within
1e-8 HP for checked nonlinear windows. A numeric-zero test expectation was
corrected without changing simulation formatting. No certified global ODE or
cross-platform bitwise accuracy claim is added.

The new evidence freezes eight runtime definitions, all 13 root ODT sources,
and 119 implementation/input/test/script hashes. New manifests are checked
against the final reviewed implementation; historical packages are untouched.

### Next concrete work and remaining Goal

The full six-character/general 5v5 Goal stays active/incomplete. This is a
bounded verified engine checkpoint. Next move toward **actual 2E4 recovery
delivery**: introduce explicit actor life states/event generations, review
2E4's root source/profile requirements, and bring the authored attack/effects
needed to exercise its healing/revival into this same coordinator. Preserve
attached blades/replacement timing and independent lingering effects; do not
replace them with injected HP or scripted damage credit.

Healing must consume each entitlement once and track the already-spent share
of its 90%-of-recent-damage allowance. Revival still needs explicit death versus
completion anchors, charge/cooldown behavior, HP/resource restoration and stale
event handling. Those technical choices remain delegated; source-cost exemptions
and character identity remain confirmed preferences. Remaining kits, moving
Qard/poison, chains/grabs/portals/duplication/construct delivery, broader facing/
support and moving Get Up still need integration. Advanced NPCs, mass simulation
and balancing automation remain deferred.

## Author clarification: effort categories and independent effects, 2026-10-29

The author clarifies that intrinsic/extrinsic expresses the character's effort
relative to an external mechanism, and momentary/sustained expresses whether
that effort continues. The categories guide instability response. A powered
chainsaw remains intrinsic sustained when the character holds/pushes it; full-
auto gun/flamethrower operation is extrinsic sustained. A shotgun's brief
trigger/discharge is extrinsic momentary and can still charge for recoil control.
These examples do not add abilities to the roster.

**1E1 ability 4 has extrinsic momentary activation.** Its three-second beam is
already summoned and independent; the caster cannot stop it, and caster
instability cannot interrupt that deployed effect. Controlled Active time,
effort category, dyspnea cost and autonomous effect lifetime are separate.
Composite actions can have different effort categories per phase.

Recorded confirmed definitions in [ABILITY_EFFORT.md](ABILITY_EFFORT.md),
[DESIGN_PREFERENCES.md](DESIGN_PREFERENCES.md), cost/effect docs and source
metadata. Four reviewed `effort_phases` entries are 1E1 Qard firing (intrinsic
momentary), 1E1 beam activation (extrinsic momentary), 1E2 firing control
(extrinsic sustained), and 1E2 marking activation (extrinsic momentary).
Executable ability definitions and simulation formulas are unchanged; metadata
is not a claim that generic effort-based interruption is integrated.

Verification: **64 existing tests pass in 11.961 s** with
`python3 -B -m unittest tests.test_spatial_heat_combat tests.test_owned_actions_combat tests.test_action_dyspnea_phases tests.test_source_revisions -v`.
These include actual controlled-summon cancellation, caster death, independent
volume lifetime and dyspnea exemptions. A production combat probe deploys the
beam at **358 ms**, receives real incoming instability at **543.992849 ms**
during the remaining summon Active, and expires at **3358 ms**. Complete target
beam damage matches a no-incoming-attack control within 1e-20 HP. All six
executable ability maps match the last frozen checkpoint.

Source/implementation gaps discovered during this review remain explicit:

- Legacy `damage_category=extrinsic` routing is not authoritative effort data.
  The current Qard source says intrinsic momentary, whose general instability
  damage response is not yet shared-engine support. Per-shot gun scheduling
  likewise does not implement a sustained-control interruption lifecycle.
- Integrate phase-specific damage sampling/control interruption, including
  self/incoming instability and committed/released output, before expanding
  intrinsic 2E4 attacks. Resolve these technical rules under delegation; no new
  author input is requested. Preserve deployed volumes and automatic readiness.
- The same source review found **1E1 Ultimate swap Active 400 ms** while the
  historical controlled timing profile retains **300 ms**. This current-source
  discrepancy is recorded in `documented_abilities.Ultimate.current_source_review`.
  Shared Ultimate delivery remains unfinished; import/review its current source
  before claiming integration. Historical inputs/results are preserved.

This turn makes verified source/metadata progress under the active Goal.
Life/event generations and actual 2E4 healing/revival remain the next character
target after the effort-response prerequisite. Full six-kit/general 5v5
completion remains unverified.


## Shared phase effort and moving Qard — 2026-10-29

The author's effort clarification now drives real shared combat. Current inputs
select `effort_rules.mode=phase_effort_v1`; executable abilities explicitly name
their reviewed `documented_abilities.effort_phases` entry. Old extrinsic routing
remains only a historical adapter and is not an effort classifier. No authored
ability or root ODT was replaced.

**Implemented and interaction-tested:**

- Pure source formulas for intrinsic momentary damage (`U/10`) and sustained
  DPS (`U/4`). Only momentary Qard delivery is integrated; the sustained formula
  does not claim an additional ability or a completed sustained attack.
- Immutable power per original projectile, inherited by copies and delayed
  blasts. Source power is sampled before target defenses; defenses remain live
  at each hit. Qard's ordinary release has U=50 and power 445 from base 450.
  Subsequent source instability/death cannot rewrite that release.
- Separate identified gun-control lifetimes linking owned emission actions.
  Incoming/parallel-action instability interrupts unfinished gunfire; own
  causative recoil does not self-cancel that shot. Starts/emissions require
  stability, with exact policy waits combined with cooldown/resource readiness.
  Cancelled unreleased shots spend no ammo, firing cost or weapon cooldown.
- Automatic Readying holds no hands or global channel lock. Reload, empty
  magazine, function restriction, resource reassignment or death ends the
  relevant control. No living enemy ends idle control while an already-started
  attack still finishes at its original location. Unrelated body actions,
  released projectiles, bleeds, independent beams and pause areas persist.
- Same-time phase closure snapshots source instability before concurrent phase
  status additions, completes due releases, then settles interruptions. Incoming
  hits follow before policy. Explicit insertion-order reversals verify committed
  gun output and intrinsic Qard power; numeric-zero tolerance is 1e-18 U.
- Moving Qard reuses existing straight/gravity flights, hand/torso geometry,
  moving bodies, actual terrain contact/marks, area eligibility, simultaneous
  defenses, collider damage and applied-HP receipts. No separate runner was added.

Sampling, stable-start gating, recoil causality, end conditions and phase-batch
ordering are **delegated technical decisions**, not new author confirmations.
[ABILITY_EFFORT.md](ABILITY_EFFORT.md) records rationale and numerical boundaries.
The author-confirmed definitions remain separate in DESIGN_PREFERENCES.md.

**Final verification: 1234 full-suite tests pass in 128.771 s; 42 focused checks pass in 5.908 s; the five unchanged review checks pass in 1.399 s.** New and prior replay packages match. All 125 source hashes and 14 ODT copies match; every saved encounter conserves actual HP through independently decoded damage histories.

Forty-two focused checks cover formula floors/precision, immutable snapshots,
real hit/Active interruption, exact payments, source/target death, no-enemy
completion, body overlap, actual lowered launch poses, copies, live defenses,
cover/friendly area damage, walking Qard, heat coexistence, independent beam
lifetime and phase order. Six old ownership/projectile fixtures were revised
for current effort timing while preserving their original interaction coverage;
new tests retain an actual mid-crouch release and a posthumous projectile hit.

Nine **ordinary production API** captures have frozen inputs and full CLI/API
replays. They contain no injected runtime operations. Duel and 30-second 2v2
hash-seed controls are included. In the new current-rule
[stationary 2v2](scenarios/effort_stationary_2v2.json), the approved positions,
first-team 1000-HP shields and three cubes are retained; 1E1 prioritizes beam then
Qard and 1E2 firing/reload then its pause mark. Team B dies by 16.818534 s; A 1E1 ends
at 6378.614175 HP and A 1E2 at 8140 HP. This is a single encounter, not balance evidence.
Earlier scenarios and historical saved results are unchanged.

[Evidence and verification](results/phase-effort/REPORT.md) includes the final
full-suite/focused/original-review logs, complete new replays and all nine prior
frozen replay packages (applied HP, cooldown, heat/recovery, recovery flow, spatial
heat, colliders, projectiles, action ownership and climb). The new 125-file
manifest includes all 14 current root ODTs; source copies and hashes are checked.
`Grapple abilities.odt` contains shared grapple/exhaustion/break/movement rules;
its embedded formulas and detailed delivery remain future integration work.

**Next coherent increment:** investigate explicit actor life/event generations
against the current sources and ledger, implement/test death-to-new-life
boundaries before actual 2E4 healing/revival, then integrate its required shared
attack/effect profiles and one-time credit consumption. Preserve released-effect
source identity while preventing old target-life effects from silently applying
to a revived life. Resolve technical choices under delegation. Intrinsic
sustained/composite delivery, other kits, grapple/break interactions, grounded
support departure, turning and moving knockdown/Get Up remain unfinished. Keep
the recorded current 1E1 Ultimate 400 ms versus historical 300 ms discrepancy visible
when integrating that ability. Advanced NPCs and mass experiments stay deferred.
The overall Goal remains active; full six-kit/general 5v5 completion is unverified.
This session stops at a verified effort checkpoint, reserving remaining context
for verification and this durable handoff rather than beginning a large life/
revival change without capacity to finish and check it.


## Author-added grapple source and shared calculation foundation — 2026-10-29

Previous Goal turn: **progress** (phase effort, moving Qard and verified shared
combat changed authoritative state). The new author message supplies additional
primary material; it does not replace or narrow the six-character Goal.

Read all of `Grapple abilities.odt`, including four embedded MathML formulas,
alongside binding/dyspnea rules and affected primary character profiles. Source
facts include reduced controller-fatigue capacity, the signed empty-capacity
Break comparison, a controller response opportunity, both bars filling, escape
penalty 3A and weighted vector motion. 1E5/2 and 3E5 Ultimate explicitly say
Grapple; 3E5/2 explicitly says the throw is intrinsic momentary and chaining is
binding. Preserve the 1E2 grappling gun's separate launch phases.

Implemented `combat_sim/mechanics/grapple.py` with exact rational fatigue/escape/
Break-effort helpers, immutable assessment records and owned-precision shared
velocity. Extracted the common `(H/500+armor/10)^1.1` into `body_status_weight`
in existing status mechanics; current combat uses this same unchanged 40-digit
term. Shared motion uses maximum HP/current armor, not current HP/shield or
additional status resistance. The authored 1E5/1E2 example gives about
+3.29508869406831549 m/s for +7/-6.4 m/s inputs.

**Delegated interpretations**, distinguished from source facts in GRAPPLE.md:
floor reduced holding capacity at 0; keep the signed escape correction; compare
defender minus controller empty bar space; use current already-adjusted statuses
without double mitigation; choose 20/s as the specific Break fill default while
leaving ordinary 30/18 recovery unchanged. Binding's explicit disorientation
pause is not automatically a grapple rule. Response-window timing, effort-A
aggregation, penalties, phase costs and runtime release ordering are work to
resolve during integration, not author-input blockers.

Updated the primary inventory/mechanics registry, confirmed preferences, roster
and documented ability facts. Added `data/mechanics/grapple_rules.json` with
source equations/locations and selected/pending interpretations. All six
**executable ability maps are unchanged**. In particular, do not infer that a
new cast exists from a metadata control label. 3E5 Ultimate's drag damage family
is stated, but drag DPS is absent; do not borrow 1E5's 900/s.

Verification: **1259 full-suite tests pass in 129.675 s**. **107 focused tests pass
in 6.010 s**, including 25 new source calculations/invariants; all five original
review tests pass in 1.407 s. The nine frozen phase-effort encounters match complete
API traces and eleven CLI/hash-seed comparisons. Source equations, six explicit
escape cases and an independent 90-digit motion reference reproduce. All 12 new
manifest hashes and five relevant primary-source copies match. Evidence is in
[results/grapple-rule-import/REPORT.md](results/grapple-rule-import/REPORT.md).
Historical result packages and author ODTs remain unchanged.

**Scope:** formula foundation and shared status-weight reuse are implemented.
Grapple links, a Break/controller response state machine, combined continuous
resource flows, drag damage and linked body constraints are not yet integrated.
Do not claim 1E5/3E5 grappling support from this source import or its green tests.

**Next:** retain explicit actor life/event generations as the next engine
increment, followed by actual 2E4 healing/revival and shared attack/effect
prerequisites. These identities also let controlled grapple links terminate on
participant death without transferring into a revived life; independently
released binding/projectile effects retain their own source/anchor policies.
Then integrate the reusable grapple contest/resource/constraint lifecycle and
the actual grab/drag/carry profiles using this same coordinator, preserving
multiple independent actions/links where source rules permit. Full six-kit and
5v5 completion remains unverified; advanced NPCs/mass experiments remain deferred.
The Goal remains active at this verified source/mechanics checkpoint.
