# Actual body-part projectile damage

Implemented and verified in the shared engine, 2026-11-03. This is the foundation for the
existing 1E2 ability 4; it does not add a character ability or anatomical bonus
to other attacks. All 2526 methods pass across four isolated unittest processes;
34 new methods and sixteen complete API/CLI/hash/numerical scenarios exercise
this increment. [Evidence](results/1e2-ability4/README.md).

The source `1E2.odt` p9 gives 600 damage, or 1500 on a headshot. Its p147
explicitly labels this shot intrinsic momentary; preserve that category. At
release, freeze the default and each authored part output independently using
the same instability snapshot. Thus U=135 gives 586.5 body and 1486.5 head,
rather than multiplying an already reduced body output. Released copies share
the same immutable source outputs.

At actual contact select the frozen output for the contacted body cuboid.
The native receiver's stable lexical part identity breaks exact closed-contact
ties. Intent, aim point and the selected enemy do not confer a bonus: an ally
intercept, a torso hit while aiming at the head, a Block or a wall uses its
actual receiver. Block and terrain have no anatomical part, so use default
power; personal shielding still absorbs the damage of the actual body-part hit.
Apply travelled-distance loss after part/instability selection, then the normal
simultaneous shield, armor, status, clipped HP and life/credit rules. The new
direct projectile model pays HP at impact and does not inherit gun bleeding.

Scripted `action_selection.<actor>.aim_part` can name an actual body cuboid.
It pins the action's intended part and chooses its centre at release; default
is torso. Dispersion, gravity, motion, friendly interception and cover still
determine the actual contact. This is a reusable scripted input, not target
leading or advanced NPC intelligence. Unknown parts reject before simulation.

The ability-specific missing-value decisions are in 1E2_ABILITY4_AUDIT.md.
