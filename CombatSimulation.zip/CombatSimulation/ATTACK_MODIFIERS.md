# Attack enhancements and release snapshots

Current source: `2E4.odt` p9/p99–103 gives ability 4's next-ability-1
additional 20 armor loss, 200 ms Active and 9 s cooldown. p11/p106–110 gives
the Ultimate's ability-1 shielding ignore of 4000 for 10 s, 400 ms Active and
60 s cooldown. Both activations are extrinsic momentary. The author's policy
exempts such enhancements from separate dyspnea; the thrust retains its own cost.
These author revisions replace the old owner-contact projectile and longer
blade attachment. See [source revisions](SOURCE_UPDATES_2026-10-31.md).

Verified in the shared engine, 2026-11-01. The following gap decisions
are delegated technical choices, not additional author statements.

- Both enhancements use the common controlled-action lifecycle. No hand pose,
  physical Recovery distance, base Gathering, self status or extra effort is
  authored, so these are absent. Existing incoming disorientation still delays
  Gathering. Each activation occupies its own ability resource and requires
  upper-body control; it adds no global attack/hand/locomotion lock. Successful
  acquisition immediately reconsiders other independent actions through the
  common scheduler; no movement input is needed. Sprint's existing
  weapon-action restriction remains. Death or a control restriction can cancel
  an unfinished activation.
- Cooldown starts at the activation request, matching the existing summoned
  effect convention. The grant begins only at Active completion. A cancelled
  activation keeps its elapsed cooldown and supplies no grant. Ordinary
  cooldown work pauses in fields and freezes at death; grant duration uses
  elapsed world time. Pausing a cooldown does not extend a buff.
- A grant belongs to the actor life that activated it. Unused grants end at
  death and do not return on restoration. Recasting the same source ability
  replaces its unused grant rather than accumulating bonuses. Different
  sources compose additively for piercing, extra armor loss and shielding
  budgets, and multiplicatively for bleeding. Current 2E4 activations and
  [1E5's actual component strikes/passive/Ultimate](COMPONENT_MELEE.md) use this
  shared capture path. Passive definitions retain actor-specific provenance.
- At the thrust's midpoint emission, freeze an immutable modifier snapshot
  alongside its existing power snapshot, before impact and self effects. This
  lets an enhancement completed during preparation affect the upcoming attack.
  A next-attack grant is consumed once at that emission, including a whiff,
  terrain contact or fully shielded hit. Cancellation before emission leaves
  it available. Blocks, automatic counters and other ability IDs cannot spend
  it. Timed eligibility is `[start, expiry)` independently of callback order.
  Captured modifiers survive later expiry, cancellation or source death.
- Additional armor loss is a flat 20 after the ordinary slash armor-loss
  calculation, applied only if positive damage reaches the body beyond shields.
  Combined actual armor loss floors at zero armor. It neither changes the
  attack's own pre-hit armor nor another simultaneous packet's HP/status/venom
  snapshot. It creates no direct HP credit and does not damage construct armor.

**Readiness correction, 2026-11-03:** [N1](PRINCIPAL_ENGINEERING_REVIEW_2026-11-03.md)
removed accidental serial preparation. A 2E4 thrust released at 230 ms can use
ability 4's grant completed at 200 ms, but not the Ultimate completed at 400 ms.
Both activations may start at 0 ms. Similarly, 1E5's first 230 ms swing precedes
its 320 ms Ultimate grant; subsequent eligible strikes by either arm receive
the piercing bonus. Existing snapshot, expiry, damage, shield and cost rules
remain unchanged. Fully prepared enhancement probes now explicitly gate the
attack hand, and simultaneous-hit probes align actual release times. Original
test sources and result packages are preserved in the correction evidence.

## Shielding ignore and simultaneous sharing

Shielding ignore skips **capacity**, without consuming or damaging that skipped
stock. Each packet carries its own finite budget through the ordered defenses
it actually intercepts: forward Block layers, then the personal regenerative
shield. Skipping an 800-HP Block spends 800 of a 4000 budget; it does not grant
another 4000 against the next layer. A non-intercepted layer spends no budget.
Use each layer's pre-batch HP so independent packets cannot change one another's
budget by being processed first. The budget renews for each eligible attack
under the timed Ultimate, rather than being one shared 4000-HP resource.

For layer HP `S`, packet damage `d_i` and its remaining ignore budget `b_i`,
the maximum absorption from that packet is `min(d_i, max(0, S - b_i))`.
Allocate up to `S` total in proportion to current incoming raw damage, cap each
packet at that maximum and redistribute capped shares among the other packets.
The packet's next-layer budget is `max(0, b_i - S)` for an intercepted layer.
Exact rational arithmetic preserves packet/order conservation. With zero
budgets this is the author's existing proportional simultaneous rule.

Examples:

- A 440-damage thrust ignoring 4000 against a 4000-HP shield deals its ordinary
  unshielded HP/armor damage; the shield keeps 4000 HP and gains no recovery debt.
- With an 800-HP forward Block plus 4000 personal shield, 800 of the budget skips
  Block. The remaining 3200 leaves 800 effective personal shielding, enough to
  absorb all 440. Block keeps 800 HP and cannot trigger a counter from this hit.
- Simultaneous 1000/1000 damage against an 800-HP layer, with ignore budgets
  0/500, absorbs 500/300. The capped second share is redistributed to the first;
  skipped capacity never removes stock on behalf of another packet.

Only actual absorption reduces shield HP, supplies shield recovery debt or emits
a successful-Block signal. Shield-derived status/toxin resistance remains while
the shield exists: ignoring absorption is not removal of the shield. Body/solid
contact still follows the delivery's physical geometry. In particular, an old
life's frozen Block remains a separate receiver under the existing lifetime
rules; no overflow is transferred into the restored body's life. This increment
does not add body piercing or arbitrary secondary contacts to the thrust.

## Architecture and evidence

`AttackModifiers` owns grants and immutable release snapshots on the existing
coordinator. `ModifierValues` composes pure values; shared defense-layer and
simultaneous-damage functions route budgets without kit-specific branches.
Venom and bleeding read the captured attack values rather than live buffs.
The supported capture boundaries are timed thrust and component melee; other
projectile/composite deliveries must add their real release boundary before accepting an
enhancement. A formula field alone does not implement another character kit.

**Initial 2E4 milestone:** 1583 full-suite tests passed in 236.985 s, including 39 new checks. Eight
ordinary complete API/CLI captures, three full hash controls, three combined
precision/observation/order controls and preserved review/historical replays
verify actual interactions. Inputs, logs and final provenance are in
[the evidence package](results/attack-modifiers/README.md).

The [subsequent 1E5 component milestone](COMPONENT_MELEE.md) now verifies actual
alternation, passive double bleed and timed piercing through this same mechanism.
Next are shared spatial transitions and linked-body constraints.
Grapples/bindings and the remaining kit deliveries still gate
the complete six-character engine. Advanced NPCs and mass experiments remain
deferred.
