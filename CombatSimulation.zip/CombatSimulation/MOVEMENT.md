# Straight-line walking and running

Current request: add straight-line walking/running. No animations are required.
Scripted forward movement is now integrated into the shared combat event loop
for an author-approved **geometry and timing** test. Attacks, statuses and
dyspnea are excluded in that explicit test scope; the earlier battles keep
their stationary scopes.

Author temporary collision rule: at cubes, other characters and the finite
ground edge, characters **just stop moving** for now. Detailed body-collision
behavior will be developed by the author. Do not add sliding, falling or bounce
as the current collision response.

## Confirmed speeds

| Character | Walking speed | Running speed | Source |
|---|---|---|---|
| 1E1 | 2 m/s | 6.4 m/s | Author walking clarification; 1E1.odt profile |
| 1E2 | 2 m/s | 6.4 m/s | Author walking clarification; 1E2.odt profile |

The speeds are baseline values, not a decision about acceleration or the effect
of instability, facing, terrain or action phases.

## Relevant primary rules

- `Collision details.odt`: instability reduces movement speed by U/200 m/s.
  Instability decays by one per millisecond. Character collisions give 300
  disorientation and instability per 5 m/s of velocity in the collision
  direction; incoming collision statuses use the documented resistance formula.
- `Details.odt`: running increases Gathering, hand Recovery and self
  disorientation/instability by 20%; it reduces accuracy. Direction relative to
  facing also modifies running speed. The directional wording/formula remains
  to be resolved before arbitrary-facing movement is claimed.
- `1E1.odt` and `1E2.odt`, basic ability 3: switching run ↔ walk lists self
  disorientation 80, self instability 80 and dyspnea value 0.5. The timing of
  payment and state change, and which running modifier applies at a switch,
  are not established by these listed values alone. The revised character
  files now give walk ↔ run an Active transition of 150 ms.
- `Details.odt`: stopping is opposite movement input, with self disorientation
  and instability 150 per 5 m/s of travel, and unmitigated slide distance
  0.5 m per 10 m/s. The slide-resistance formula is
  S2 = S − (H/500 + armor/10)^1.1 / 250. The author now supplies
  stopping timing separately. The later correction deletes linear stopping;
  the special stop uses instability-based sliding. See [STOPPING_REVIEW.md](STOPPING_REVIEW.md).
- `Dyspnea details.odt`: allowed dyspnea recovery is 30/s when walking or
  stationary and 18/s when running. Disorientation, instability, Gathering,
  Recovery, Active, sprinting and the other listed blockers pause recovery.
  No separate continuous running dyspnea cost is invented from the general
  statement that running fills dyspnea.

## Author transition timing clarification

Applies to both 1E1 and 1E2:

- Walk ↔ run: **150 ms Active**, confirmed in the revised root character ODTs.
  Acceleration/deceleration happens during this Active interval.
- Stand ↔ walk: **both directions use the stopping mechanic**. The author
  removes Recovery/3 in both directions. Apply 150 ms per 5 m/s to the
  magnitude of the 0 ↔ 2 m/s change: **60 ms Active** in either direction.
  This correction does not change hand Recovery.
- Stopping: **150 ms Active per 5 m/s of speed at the start of stopping**.
  Equivalently T = 30 × starting speed in milliseconds: 192 ms at 6.4 m/s,
  60 ms at 2 m/s. Linear stopping is now deleted. Slide duration equals
  the base stopping instability, with the author-approved linear slide decay.

The revised ODTs also contain a 200 ms run ↔ sprint transition. Sprint remains
outside the requested walking/running milestone; it is not implemented here.

## Special stopping

The author keeps instability-based stopping and deletes ordinary linear stopping.
Sliding begins at Active start, lasts for the base instability contributed by
that stop, and decays linearly to zero velocity. Initial slide speed is derived
from mitigated distance and duration: 2 × distance / duration. Negative slide
distance is floored to zero and stops travel immediately. These rules are
implemented and tested; see [STOPPING_REVIEW.md](STOPPING_REVIEW.md).

Temporary response to cubes, other bodies and ground edges is confirmed as
just stopping. Detailed body-contact effects remain deferred; the precise
body/footprint criterion at the finite ground edge must be explicit before
that boundary case is integrated.

First verify isolated forward straight-line motion, then its status/resource
interactions and collision response. Keep movement policy, geometry and combat
mechanics separate. Do not infer an aiming/leading rule for moving targets.

Faster projectile arc selection is confirmed separately in [GRAVITY.md](GRAVITY.md).

## Verified isolated walk/run transition

[Data](data/movement/walk_run.json) separates the confirmed character speeds
and 150 ms Active duration from [exact motion](combat_sim/mechanics/movement.py).
Constant acceleration is ±88/3 m/s² for 2 ↔ 6.4 m/s over 150 ms. Each transition
covers exactly 0.63 m. This is a baseline result without instability or other
speed modifiers, not an assertion about the fully integrated character.

Twelve tests cover both directions, integrated intermediate positions, arbitrary
explicit unit direction, fractional-millisecond queries, duration bounds and
character data. This stage passed 533 tests. No slide,
status application, dyspnea payment, facing response or body collision behavior
is inferred by the mathematical primitive. Shared combat remains stationary.

## Verified standing/walking timing

Author's final correction: standing → walking and walking → standing both
follow the stopping mechanic. Recovery/3 is superseded in both directions
and removed from movement data and executable timing. For 0 ↔ 2 m/s,
Active duration is 60 ms. Running → standing remains 192 ms from 6.4 m/s;
walk ↔ run retains its specifically authored 150 ms duration.

The isolated standing → walking helper accelerates linearly from 0 to 2 m/s
over 60 ms, covering 0.06 m. This is acceleration travel at baseline, without
status modifiers. The duration helper specifies timing only; the now-confirmed special slide
curve is implemented separately in mechanics/stopping.py. No slide is
automatically added to starting movement.

Nineteen movement tests pass; the full suite passes **540 tests**. Both
directions' timing, absence of the removed Recovery override, exact positions
and speed-dependent stopping duration are checked. Battle integration remains
pending; historical frozen results are untouched.

## Basic jump extension

Author confirms upward takeoff velocity half base running speed, retained
horizontal velocity, gravity and takeoff at Active start. Isolated jump flight
and takeoff timing are implemented; see [JUMPING.md](JUMPING.md) for rules,
verification and explicit integration boundaries. The full suite now passes
551 tests; this does not establish locomotion in shared combat.

## Shared combat-engine geometry test

[Scenario](scenarios/scripted_movement_geometry.json) runs both characters
on the existing shared timeline: stand → walk, walk → run, running jump,
run → walk. Six-cuboid bodies follow positions and vertical flight continuously.
The separate [contact-stop scenario](scenarios/scripted_movement_contact_stop.json)
checks the temporary cube stop. Static and walking jumps and body-to-body stops
are covered by integration tests. No animation is used.

The scope is forward motion with fixed facing, non-overlapping commands and
same-flat-ground jump landing. Airborne obstacle/body contacts and ground-edge
footprint cases are rejected. Full movement/effect interactions and attacks
on moving targets remain outside this first geometry test.

[Results and replay](results/scripted-movement-shared/REPORT.md) preserve the
trace, positions/speeds/heights, inspection page and verification evidence.

## Completed shared special-stop test

[New scenario](scenarios/scripted_movement_stopping.json) adds special running
and walking stops and jumps from running, standing and walking. Both characters
finish at x≈26.7734558179 m, standing and grounded. The running stop covers
about 0.1434558179 m in 192 ms; walking stops travel immediately because
resistance cancels slide distance, with its 60 ms Active retained.

The full suite passes **591 tests**. The previous saved movement traces remain
unchanged; [new results](results/scripted-movement-stopping/REPORT.md) preserve
this additional milestone separately. Effects/resources and moving-target
attacks remain outside the author-approved geometry/timing test scope.

## Standing climb test; collision interaction paused

[CLIMBING.md](CLIMBING.md) documents cube_1's climbable flag, origin-based
range and tested standing climb path. Full suite: 617 tests. The author
requested waiting for new body-collision details before the moving-to-climb
handoff and new collision responses are implemented.

## Moving climb eligibility resolved

Walking/running continues through climb Gathering; range is checked once at
Active start. Success switches to the climb path; failure preserves ordinary
movement, with collision only on physical contact. See [CLIMBING.md](CLIMBING.md)
and [moving scenario](scenarios/scripted_moving_climb_geometry.json).

## Crouch and sprint extension

Approved crouch/stand geometry and 11.2 m/s sprint are now implemented on the
shared timeline. Run ↔ sprint is 200 ms; crouch and stand are 150 ms each.
Ground pace is retained while posture changes. See
[CROUCH_SPRINT.md](CROUCH_SPRINT.md) and the new
[scenario](scenarios/scripted_crouch_sprint_geometry.json). Current full suite:
665 tests; prior frozen traces remain preserved.
