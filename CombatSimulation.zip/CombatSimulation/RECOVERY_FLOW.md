# Analytic shield-recovery flow

Verified 2026-10-28. Current moving combat uses these plans for recovery from
actual point and continuous losses. The subsequent
[heat/shield coupling](HEAT_SHIELD_COUPLING.md) now also uses them for net stock
balance and immediate absorption of returning shield at zero stock.

## Source and engineering decisions

Current `1E1.odt` p30/p227 specifies 4000 shield HP, recovery of losses older
than 20 seconds, and 400 HP/s. The author's clarifications require individual
loss delays and one shared rate. Initial missing shield has no invented loss
history. Those rules are unchanged; the new representation is a delegated
engineering decision. Existing profiles supply their own delay/rate values.

`DelayedShieldRecovery.plan(begin,end)` returns a detached, immutable forecast
of service from **currently known losses**. It exposes delivered work at any
prefix, rates in HP/s, and analytic pieces. Previewing does not advance time,
change an actor, consume recovery or schedule events.

```python
plan = recovery.plan(begin_ms, end_ms)
amount = plan.delivered(observation_ms)
rate = plan.rate(observation_ms)
recovery.commit_plan(plan, until_ms=observation_ms)
```

Commit consumes a plan once. Another commit needs a new plan from the updated
state. Owner token, generation, recovered-work baseline and immutable history
key reject stale/cross-stream consumption before mutation. The key also detects
edits through the legacy public loss list. Records expose values, never tokens
or object addresses. Nested input curves and output records cannot mutate a
stored loss or plan.

## Queue mathematics and continuous curves

Eligible losses form cumulative supply `E(t)`; recovered work `U(t)` cannot
exceed it and has the profile's shared service capacity. Supply-limited pieces
follow the eligible loss rate. With backlog, pieces deliver at constant capacity
until the queue empties. Empty idle time cannot be banked for later recovery.
Point loss arriving at the right endpoint cannot serve earlier work.

Heat loss rates are nonnegative sums of affine square roots. A recovery piece
is either that same family or a constant. Therefore recovered work spent as
another shield loss can retain its exact continuous distribution and be delayed
again without inventing ticks. The new `sum_root_v1` curve record contains a
nonnegative constant plus affine-root terms; existing curve formats remain valid.

Between source expression boundaries, a positive sum of affine roots is
concave. The planner locates both capacity crossings around its maximum and
then any backlog-empty boundary. Constant-rate empty times are solved directly;
other roots refine to `1e-25 ms`. Growing, cooling, mixed and constant sources
are covered. Cooling-zero times are explicit knots even if a recorded interval
extends beyond them; carrying the clipped curve through zero would invalidate
the concavity argument. Legacy advancement now observes those knots too.

These are finite-precision Decimal analytic integrals, not symbolic exact
arithmetic. Tests compare 50/80-digit and observation partitions within
`1e-21 HP`; captures retain inputs, precision, root tolerance and source hashes.
Rates use the right-hand piece at interior boundaries and the left-hand rate at
the plan's final endpoint. Positive pieces and idle pieces both appear in records.

## Shared-engine use and compatibility

Current world data declares `shield_recovery.mode=analytic_flow_v1`, requiring
the typed-effect world. The common coordinator previews/commits recovery on
each actual interval; positive `shield_regenerated` events include the plan.
The same mechanism handles real gun losses and a dead caster's prior beam
losses. It grants no regeneration to a dead recipient and does not revive anyone.

Frozen inputs without the flag retain their earlier accumulator and trace
presentation. Their full replays still match. Both paths preserve intended
per-loss/shared-rate mathematics. The old evidence packages are unchanged.

Forecasts are conditional: callers must stop at a new loss/state event and
replan. The coupling solver also ends before **unrecorded current
losses could themselves become eligible** (the positive profile delay).
Predicting known history does not authorize assuming that future combat is idle.

The coupled solver uses `RecoveryCursor` to consume increasing prefixes from one
immutable plan without double payment. It checks owner, eligible-history key and
recovered-work baseline; newly recorded losses beyond the plan horizon do not
invalidate its supply. Its opt-in 1e-24 HP work roundoff budget retains numerical
debt while preventing micro-bursts of full-rate service. Delivered work is always
clipped to actual eligible supply. Other plans retain their default zero budget.

## Original prerequisite checkpoint

**1094 tests pass** (28 new: 22 primitive and six shared-combat checks). The
64-test focused run also includes existing recovery and heat interactions.
All five original review checks pass. Two ordinary 35-second API/CLI captures
and three isolated forecast records reproduce exactly. Prior heat, collider,
projectile, ownership, climb and classified historical traces still replay.
[Evidence and commands](results/recovery-flow/REPORT.md).

At this earlier 1094-test checkpoint, the overlap guard remained. Its required
follow-up, now implemented in [HEAT_SHIELD_COUPLING.md](HEAT_SHIELD_COUPLING.md), was:

1. Couple incoming heat and recovery **before** finding shield exhaustion, using
   `S(t)=S(begin)+U(t)-incoming_loss(t)` rather than subtracting heat first or
   checking only the end balance.
2. Handle a shield held at zero by continuous incoming heat. Recovery must
   contribute continuously; it must not manufacture repeated fresh thermal
   clocks, arbitrary recharge thresholds or zero-time break/reform loops.
3. Add per-source incident thermal state and choose/document the continuous
   allocation/layer-exposure rule under delegation. Preserve the author's cold
   HP-start case, shield residual non-transfer, independent sources and current
   defenses. Warm HP memory when a shield reforms also needs an explicit rule.
4. Record newly consumed shield recovery as real delayed loss using this closed
   curve family, without double-counting, healing/revival credit or future supply
   leaking into earlier state. Preserve observation-independent outcomes.

The later 1129-test checkpoint verified all four items with seven ordinary
coupled encounters and additional numerical/interaction tests.
[Evidence](results/heat-shield-coupling/REPORT.md). This is not full A3, complete
kits or general 5v5 completion. [Pause clocks](COOLDOWN_PAUSES.md) and
[attribution](DAMAGE_LEDGER.md) now follow it; healing/life transitions and revival
remain unfinished.
