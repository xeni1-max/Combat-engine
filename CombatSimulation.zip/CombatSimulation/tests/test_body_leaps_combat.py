"""Actual existing leaps, controlled descent and shared combat interactions."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import json
import unittest

from combat_sim.grapple_links import LinkCommand
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from tests.test_equilibrium_combat import scene as base_scene,run,rules
from tests.test_binding_combat import run as configured_run
from tests.test_mobile_combat import command,events,read,PROFILES
from tests.test_world_colliders_combat import wall
from tests.test_impact_bindings_combat import add
from tests.test_transport_combat import transport


def scene(duration=3000,*,character='3E5',target=(35,-20,'1.75')):
    s=base_scene(duration,character=character);s['id']='actual_body_leap'
    s['encounter']['participants']['B']['position_m']=[35,-20]
    s['action_selection']['A'].update(abilities=['3'],start_ms=0,reload_when_empty=False)
    if target is not None:s['action_selection']['A']['ability_targets']={'3':{'kind':'world_point','point_m':list(target)}}
    return s


class BodyLeapCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        json.dumps(r);loss=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-loss.amount(target=name)),D('1e-8'))
        return loss

    def test_1e1_authored_speed_phases_cost_cooldown_and_native_landing(self):
        r=run(scene(character='1E1',target=None));self.conserved(r);row=r['body_leaps'][0]
        self.assertEqual((D(row['launched_at_ms']),D(row['launch_active_end_ms'])),(140,390))
        self.assertLess(abs(sum(D(v)**2 for v in row['launch_velocity_mps'])-225),D('1e-40'))
        paid=[e for e in events(r,'dyspnea_paid','A') if e['ability']=='3']
        self.assertEqual(len(paid),1);self.assertEqual(D(paid[0]['amount']),D('12.25'))
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),9140)
        self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),D(225)/D('9.81'),places=35)
        self.assertEqual(len(events(r,'body_launch_landed','A')),1)
        self.assertFalse(events(r,'jump_takeoff'));self.assertFalse(r.get('owned_contact_volumes'))

    def test_3e5_authored_total_speed_and_one_composite_payment(self):
        r=run(scene());self.conserved(r);row=r['body_leaps'][0]
        self.assertLess(abs(sum(D(v)**2 for v in row['launch_velocity_mps'])-400),D('1e-40'))
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),2990)
        self.assertEqual([D(e['amount']) for e in events(r,'dyspnea_paid','A') if e['ability']=='3'],[9])
        self.assertEqual(row['self_effects'],{'disorientation':'150','instability':'150'})
        self.assertGreater(D(row['kick_started_at_ms']),D(row['launch_active_end_ms']))

    def test_real_descending_foot_hit_deals_blunt_and_releases_downward_knock(self):
        r=run(scene());self.assertEqual(self.conserved(r).amount(target='B'),D('562.5'))
        contact=events(r,'owned_contact_committed','A')[0]
        self.assertEqual(contact['target'],'B');self.assertEqual(contact['hit_parts'],['head'])
        knock=r['knock_impulses'][0]
        self.assertEqual(tuple(map(D,knock['direction'])),(0,0,-1))
        self.assertEqual(D(knock['assessment']['maximum_hp_sum']),8140)
        self.assertEqual(D(knock['expiry_ms'])-D(knock['started_at_ms']),500)
        self.assertLess(D(knock['initial_velocity_delta_mps'][2]),0)

    def test_kick_uses_contact_instability_instead_of_launch_instability(self):
        r=run(scene());self.conserved(r);power=next(p for p in r['released_attack_power'] if p.get('attack_id'))
        self.assertEqual(D(power['instability_at_release']),0)
        self.assertEqual(D(power['components']['strike']['base']),600)
        self.assertEqual(D(power['components']['strike']['output']),600)
        self.assertEqual(power['released_at_ms'],events(r,'owned_contact_committed')[0]['time_ms'])

    def test_default_forward_control_can_miss_and_consumes_one_ground_contact(self):
        s=scene(3500,target=None);r=run(s);self.conserved(r)
        self.assertEqual(events(r,'owned_contact_committed')[0]['target'],'ground')
        self.assertEqual(len(events(r,'owned_contact_committed')),1)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_low_ground_target_can_hit_body_side_without_confirming_a_foot_strike(self):
        r=run(scene(target=(35,-20,0)));self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertFalse([e for e in events(r,'owned_contact_committed') if e['target']=='B'])

    def test_public_running_leap_keeps_magnitude_and_resumes_ground_pace(self):
        r=run(read('scenarios/1e1_leap.json'),interval=17);self.conserved(r);row=r['body_leaps'][0]
        self.assertEqual(row['self_effects'],{'disorientation':'180.0','instability':'180.0'})
        self.assertLess(abs(sum(D(v)**2 for v in row['launch_velocity_mps'])-225),D('1e-40'))
        landed=events(r,'body_launch_landed','A')[0]
        after=next(p['states']['A'] for p in r['curve'] if D(landed['time_ms'])<D(p['time_ms'])<D(landed['time_ms'])+30)
        self.assertEqual(after['locomotion']['mode'],'running')
        self.assertEqual(landed['self_effects'],{'disorientation':'204.0','instability':'228.0'})
        self.assertEqual(len([e for e in events(r,'dyspnea_paid','A') if e['ability']=='3']),1)

    def test_left_facing_default_leap_retains_direction_without_an_enemy(self):
        s=scene(character='1E1',target=None)
        for p in s['encounter']['participants'].values():p['team']='A'
        s['encounter']['participants']['A']['facing']='-x';r=run(s);self.conserved(r)
        self.assertLess(D(r['body_leaps'][0]['launch_velocity_mps'][0]),0)
        self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),-D(225)/D('9.81'),places=35)

    def test_explicit_world_target_with_only_allies_still_supports_utility_launch(self):
        s=scene(character='1E1',target=(15,-20,0))
        for p in s['encounter']['participants'].values():p['team']='A'
        r=run(s);self.conserved(r);self.assertEqual(len(r['body_leaps']),1)
        self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),D(15),places=30)

    def test_unreachable_target_spends_no_cost_or_cooldown(self):
        r=run(scene(500,target=(200,-20,0)));self.conserved(r)
        self.assertFalse(r['body_leaps']);self.assertTrue(r['body_leap_attempts'])
        self.assertFalse(events(r,'dyspnea_paid','A'));self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),0)

    def test_independent_qard_and_leap_retain_separate_owners_and_release(self):
        s=scene(1200,character='1E1',target=None);s['action_selection']['A']['abilities']=['3','1']
        r=run(s);self.conserved(r)
        self.assertEqual({e['ability'] for e in events(r,'ability_started','A') if D(e['time_ms'])==0},{'1','3'})
        self.assertTrue(events(r,'projectile_released','A'));self.assertFalse(events(r,'controlled_action_cancelled','A'))

    def test_short_arc_landing_before_jump_active_end_does_not_invent_a_later_kick(self):
        s=scene(500,target=(1,-20,0));s['encounter']['participants']['B']['position_m']=[35,-20]
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'body_launch_landed','A'));self.assertFalse(events(r,'falling_kick_started'))
        self.assertFalse(r.get('owned_contact_volumes'));self.assertEqual(len(events(r,'dyspnea_paid','A')),1)

    def test_personal_shield_uses_the_same_strike_without_an_extra_hp_hit(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['shield']=1000
        r=run(s);self.assertEqual(self.conserved(r).amount(target='B'),0)
        self.assertEqual(D(r['final_states']['B']['shield']),400)
        self.assertEqual(len(events(r,'owned_contact_committed')),1)

    def test_friendly_body_takes_one_hit_without_enemy_healing_credit(self):
        s=scene();s['encounter']['participants']['B']['team']='A';r=run(s)
        self.assertEqual(self.conserved(r).amount(target='B'),D('562.5'))
        self.assertEqual(D(r['damage_credit_totals']['A']['eligible_hp_dealt']),0)

    def test_real_material_top_intercepts_and_takes_blunt_damage(self):
        s=scene(target=(35,-20,2));s['encounter']['participants']['B']['position_m']=[45,-20]
        s['initial_colliders']=[wall('landing_wall',x=35,hp=2000,z=1,size=(3,3,2))]
        r=run(s);self.conserved(r)
        self.assertEqual(events(r,'owned_contact_committed')[0]['target'],'landing_wall')
        self.assertEqual(D(r['world_collider_states']['landing_wall']['hp']),1400)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_contact_created_at_launch_completion_horizon_still_commits_once(self):
        from combat_sim.hitboxes import Cuboid
        from combat_sim.world_colliders import ColliderPolicy
        s=scene(390,target=(5,-20,0))
        def register(w):w.push(390,'fixture_binding',{'operation':1},priority=0)
        def platform(w):
            x,y=w.fighters['A'].position_m;feet=min(b.bounds[0][2] for b in w.world_bodies['A'])
            from combat_sim.battle_models import decimal_value as dec
            w.collider_system.spawn((Cuboid('top',(x,y,dec(feet)-D('.05')),(1,1,'.1')),),
                source='leap_horizon_contact_api_probe',entity_id='horizon_platform',hp=2000,policy=ColliderPolicy(True,True,True))
        r=run(s,operations=((0,register),(100000,platform)));self.conserved(r)
        self.assertEqual(len(events(r,'owned_contact_committed')),1)
        self.assertEqual(D(events(r,'owned_contact_committed')[0]['time_ms']),390)
        self.assertEqual(D(r['world_collider_states']['horizon_platform']['hp']),1400)

    def test_fixed_tether_uses_actual_constrained_descent_gate(self):
        s=scene(2400,target=None)
        def attach(w):w.distance_constraints.attach_fixed('A',w.terrain_anchors.below('A',5),maximum_m=5,
            expires_at_ms=5000,source='leap_fixed_limit_api_probe',expected_life=1)
        r=run(s,operations=((0,attach),));self.conserved(r)
        row=r['body_leaps'][0];free_apex=D(140)+D(row['launch_velocity_mps'][2])/D('9.81')*1000
        self.assertLess(D(row['kick_started_at_ms']),free_apex)
        self.assertEqual(r['distance_constraints'][0]['status'],'active')
        self.assertFalse([e for e in events(r,'owned_contact_committed') if e['target']=='B'])

    def test_grapple_weighted_ascent_uses_actual_apex_without_charging_partner(self):
        s=scene(2600,target=None)
        def attach(w):w.grapple_links.commit(w.grapple_links.prepare(
            LinkCommand('attach','leap_pair_api_probe','A','B',1,1,5000),source='leap_pair_api_probe'))
        r=run(s,operations=((0,attach),));self.conserved(r)
        row=r['body_leaps'][0];free_apex=D(140)+D(row['launch_velocity_mps'][2])/D('9.81')*1000
        self.assertLess(D(row['kick_started_at_ms']),free_apex)
        self.assertEqual(D(r['metrics']['B']['dyspnea_paid']),0)

    def test_post_takeoff_control_loss_cancels_kick_but_not_landing_debt(self):
        def restrict(w):w.apply_action_restriction('A',source='leap_control_api_probe',functions=['lower_body'],until_ms=3000)
        r=run(scene(),operations=((500,restrict),));self.conserved(r)
        self.assertFalse(events(r,'owned_contact_committed'));self.assertTrue(events(r,'body_launch_landed','A'))
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_transport_of_uncontrolled_leap_retains_landing_and_velocity(self):
        s=scene(2800,character='1E1',target=None);base=run(s);r=run(s,operations=((500,lambda w:transport(w,(0,10,0))),))
        self.conserved(r)
        self.assertEqual(events(r,'body_launch_landed')[0]['time_ms'],events(base,'body_launch_landed')[0]['time_ms'])
        self.assertEqual(D(r['final_states']['A']['position_m'][1])-D(base['final_states']['A']['position_m'][1]),10)
        self.assertEqual(base['final_states']['A']['dyspnea'],r['final_states']['A']['dyspnea'])

    def test_active_falling_volume_follows_transport_and_does_not_hit_old_location(self):
        r=run(scene(3500),operations=((1500,lambda w:transport(w,(0,10,0))),));self.conserved(r)
        contacts=events(r,'owned_contact_committed','A');self.assertEqual(len(contacts),1)
        self.assertEqual(contacts[0]['target'],'ground');self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(D(contacts[0]['location_m'][1]),-10)

    def test_reversed_descent_withdraws_and_rearms_control_without_a_second_cost(self):
        def relaunch(w):
            m=w.motion['A'];w.launch_body(w.fighters['A'],(1,0,4),ground_drive_velocity=m['jump']['ground_drive_velocity'],allow_nonupward=True)
        r=run(scene(3600),operations=((1500,relaunch),));self.conserved(r)
        self.assertEqual(len(events(r,'falling_kick_started','A')),2)
        self.assertEqual(r['owned_contact_volumes'][0]['end_reason'],'source_not_descending')
        self.assertEqual(len(events(r,'owned_contact_committed','A')),1)
        self.assertEqual([D(e['amount']) for e in events(r,'dyspnea_paid','A') if e['ability']=='3'],[9])
        self.assertEqual(len(events(r,'body_launch_landed','A')),1)

    def test_attack_restriction_during_wait_prevents_kick_without_removing_flight(self):
        def restrict(w):w.apply_action_restriction('A',source='leap_attack_api_probe',functions=['attack'],until_ms=3000)
        r=run(scene(),operations=((500,restrict),));self.conserved(r)
        self.assertFalse(events(r,'owned_contact_committed','A'));self.assertTrue(events(r,'body_launch_landed','A'))
        self.assertEqual(r['body_leaps'][0]['end_reason'],'kick_requirements_unavailable')

    def test_native_grabbed_pair_receives_summed_stat_downward_knock(self):
        s=scene();add(s,'C',['36.1',-20],character='1E5',team='A')
        s['encounter']['participants']['C']['facing']='-x'
        s['action_selection']['C'].update(abilities=['2'],start_ms=1200,reload_when_empty=False)
        r=run(s);self.conserved(r);knock=r['knock_impulses'][0]
        self.assertEqual(set(knock['assessment']['actors']),{'B','C'})
        self.assertEqual(D(knock['assessment']['maximum_hp_sum']),D(PROFILES['1E2']['max_hp'])+D(PROFILES['1E5']['max_hp']))

    def test_real_block_surface_absorbs_the_descending_contact(self):
        s=scene(2500,target=('34.5',-20,'1.5'));s['encounter']['participants']['B']['character']='2E4'
        s['action_selection']['B'].update(abilities=['basic_8'],held_blocks=['basic_8'],start_ms=1850,reload_when_empty=False)
        r=run(s);self.assertEqual(self.conserved(r).amount(target='B'),0)
        self.assertTrue(events(r,'owned_contact_committed')[0]['hit_parts'][0].startswith('block:'))
        self.assertTrue(any(D(layer['hp'])==200 for layer in r['block_layers']))

    def test_real_kick_death_can_trigger_earned_revival_without_rehitting_new_life(self):
        s=scene(4500);b=s['encounter']['participants']['B'];b.update(character='2E4',facing='+x');b['initial_state']['hp']=100
        s['action_selection']['B'].update(abilities=['1'],start_ms=0,reload_when_empty=False)
        add(s,'C',['36.1',-20],character='1E2',team='A')
        r=run(s);self.conserved(r)
        self.assertEqual(len(r['actor_lives']['B']),2)
        self.assertGreater(D(r['actor_lives']['B'][1]['initial_hp']),0)
        contacts=events(r,'owned_contact_committed','A');self.assertEqual(len(contacts),1)
        self.assertEqual(contacts[0]['target_life_generation'],1)

    def test_source_death_during_preparation_or_flight_retires_owned_kick(self):
        for at in (100,500):
            def die(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
            r=run(scene(),operations=((at,die),));json.dumps(r)
            self.assertFalse(events(r,'owned_contact_committed','A'))
            self.assertFalse(events(r,'body_launch_landed','A'))
            self.assertFalse(r['final_states']['A']['alive'])

    def test_precision_sampling_order_and_ambient_context_preserve_real_hit(self):
        s=scene();base=run(s)
        other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        with localcontext(Context(prec=28)):r=run(other,precision=80,interval=17)
        self.conserved(r)
        self.assertEqual(len(r['body_leaps']),len(base['body_leaps']))
        self.assertAlmostEqual(D(r['body_leaps'][0]['kick_started_at_ms']),D(base['body_leaps'][0]['kick_started_at_ms']),places=30)
        for name in base['final_states']:
            for k in ('hp','armor','shield','dyspnea','disorientation','instability'):
                self.assertLess(abs(D(base['final_states'][name][k])-D(r['final_states'][name][k])),D('1e-8'))

    def test_missing_selected_dependencies_and_invalid_definitions_reject(self):
        cfg=rules();cfg.pop('body_leaps')
        with self.assertRaises(UnsupportedMechanicError):configured_run(scene(),rules=cfg)
        p=deepcopy(PROFILES);p['3E5']['abilities']['3']['initial_speed_mps']='NaN'
        with self.assertRaises(ValueError):configured_run(scene(),rules=rules(),profiles=p)
