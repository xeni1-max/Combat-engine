from decimal import Decimal as D
import unittest
from combat_sim.battle_actions import AbilityOption, ActorOptions, PriorityWhenReady


class BattlePolicyTests(unittest.TestCase):
    def choose(self, abilities, time=0, busy=0, reload=False):
        return PriorityWhenReady().choose(ActorOptions('a','b',D(time),D(busy),tuple(abilities),reload))

    def test_priority_and_available_fallback(self):
        self.assertEqual(self.choose([AbilityOption('beam',D(0)),AbilityOption('gun',D(0))]).ability_id,'beam')
        self.assertEqual(self.choose([AbilityOption('beam',D(9)),AbilityOption('gun',D(0))]).ability_id,'gun')

    def test_earliest_available_time_and_boundary(self):
        r=self.choose([AbilityOption('a',D(10)),AbilityOption('b',D(8))])
        self.assertEqual((r.kind,r.at_ms),('wait',D(8)))
        self.assertEqual(self.choose([AbilityOption('a',D(10))],time=10).kind,'activate')

    def test_reload_can_overlap_weapon_cooldown(self):
        r=self.choose([AbilityOption('gun',D(400),0)],time=40,reload=True)
        self.assertEqual((r.kind,r.at_ms,r.ability_id),('reload',D(40),'gun'))

    def test_busy_actor_waits(self):
        r=self.choose([AbilityOption('gun',D(0),0)],time=40,busy=80,reload=True)
        self.assertEqual((r.kind,r.at_ms),('wait',D(80)))

    def test_empty_weapon_without_reload_has_no_future_choice(self):
        r=self.choose([AbilityOption('gun',D(400),0)])
        self.assertEqual(r.kind,'wait');self.assertTrue(r.at_ms.is_infinite())

    def test_empty_priority_list_rejected(self):
        with self.assertRaises(ValueError):self.choose([])
