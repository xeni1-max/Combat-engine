from fractions import Fraction
import unittest

from combat_sim.exact import ExactAmount, ExactRootProduct
from combat_sim.mechanics.heat import heat_coefficient, heat_damage_rate, heat_damage_between, full_exposure_and_recovery_damage
from combat_sim.models import UnsupportedMechanicError


class HeatFormulaTests(unittest.TestCase):
    def test_average_of_squared_defenses_and_rate_precedence(self):
        # (10² - (6²+8²)/2)/10 = 5; sqrt(4)=2 => 10 DPS.
        self.assertEqual(heat_coefficient(10, 6, 8), 5)
        self.assertEqual(heat_damage_rate(10, 6, 8, 4).as_fraction(), 10)

    def test_1e1_beam_coefficient_and_cooling_factor_against_2e4(self):
        self.assertEqual(heat_coefficient(900, 165, 165), Fraction(3479, 4))
        self.assertEqual(heat_damage_rate(900, 165, 165, Fraction(1, 4)).as_fraction(), Fraction(3479, 8))
        self.assertEqual(heat_damage_rate(900, 165, 165, 3, 1).as_fraction(), Fraction(3479, 4))
        self.assertEqual(heat_damage_rate(900, 165, 165, 3, Fraction(3, 2)).as_fraction(), 0)

    def test_exact_peak_and_full_phase_integrals(self):
        peak = heat_damage_rate(900, 165, 165, 3)
        self.assertEqual(peak, ExactRootProduct(Fraction(3479, 4), 3))
        exposure = heat_damage_between(900, 165, 165, 0, 3, 3)
        residual = heat_damage_between(900, 165, 165, 3, 0, Fraction(3, 2))
        self.assertEqual(exposure, ExactAmount(roots=(ExactRootProduct(Fraction(3479, 2), 3),)))
        self.assertEqual(residual, ExactAmount(roots=(ExactRootProduct(Fraction(3479, 4), 3),)))
        self.assertEqual(full_exposure_and_recovery_damage(900, 165, 165, 3), exposure + residual)

    def test_splitting_intervals_does_not_round_or_change_damage(self):
        first = heat_damage_between(900, 165, 165, 0, Fraction(3, 10), Fraction(3, 10))
        rest = heat_damage_between(900, 165, 165, Fraction(3, 10), 3, Fraction(27, 10))
        self.assertEqual(first + rest, heat_damage_between(900, 165, 165, 0, 3, 3))

    def test_stat_change_uses_new_coefficient_only_for_new_interval(self):
        first = heat_damage_between(900, 165, 165, 0, Fraction(3, 10), Fraction(3, 10))
        rest = heat_damage_between(900, 0, 0, Fraction(3, 10), 3, Fraction(27, 10))
        tail = heat_damage_between(900, 0, 0, 3, 0, Fraction(3, 2))
        expected = ExactAmount(roots=(ExactRootProduct(2700, 3), ExactRootProduct(Fraction(-121, 20), Fraction(3, 10))))
        self.assertEqual(first + rest + tail, expected)

    def test_negative_damage_coefficient_floors_at_zero(self):
        self.assertEqual(heat_coefficient(10, 20, 20), 0)
        self.assertEqual(heat_damage_rate(10, 20, 20, 3).as_fraction(), 0)
        self.assertEqual(full_exposure_and_recovery_damage(10, 20, 20, 3).as_fraction(), 0)

    def test_constant_root_and_zero_duration_intervals(self):
        self.assertEqual(heat_damage_between(10, 0, 0, 1, 1, 2).as_fraction(), 20)
        self.assertEqual(heat_damage_between(10, 0, 0, 1, 1, 0).as_fraction(), 0)
        with self.assertRaises(ValueError):
            heat_damage_between(10, 0, 0, 0, 1, 0)

    def test_invalid_inputs_and_unsupported_root_orders(self):
        for output, armor, resistance in ((0, 0, 0), (-1, 0, 0), (10, -1, 0), (10, 0, -1)):
            with self.subTest(values=(output, armor, resistance)), self.assertRaises(ValueError):
                heat_coefficient(output, armor, resistance)
        with self.assertRaises(ValueError):
            heat_damage_rate(10, 0, 0, 1, 1)
        with self.assertRaises(ValueError):
            heat_coefficient(10, 0, 0, 1)
        with self.assertRaises(UnsupportedMechanicError):
            heat_coefficient(10, 0, 0, 3)
