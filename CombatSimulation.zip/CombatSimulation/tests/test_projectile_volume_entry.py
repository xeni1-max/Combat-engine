"""Continuous radial eligibility, independently of combat scheduling."""
from math import sqrt
from types import SimpleNamespace
import unittest

from combat_sim.projectile_volume_entry import first_radial_entry


def path(position,duration=1,times=()):
    return SimpleNamespace(at=lambda t:SimpleNamespace(position_m=position(t)),duration=duration,times=times)


class ProjectileVolumeEntryTests(unittest.TestCase):
    def test_linear_entry_has_actual_inside_upper_witness(self):
        p=path(lambda t:(2-4*t,0,0))
        r=first_radial_entry(p,(0,0),1,0,1)
        self.assertLessEqual(r.time_lower_s,.25)
        self.assertGreaterEqual(r.time_upper_s,.25)
        self.assertLessEqual(r.time_upper_s-r.time_lower_s,1e-12)
        self.assertLessEqual(abs(p.at(r.time_upper_s).position_m[0]),1)

    def test_curve_enters_and_exits_between_two_outside_endpoints(self):
        p=path(lambda t:(2-8*t+8*t*t,0,0))
        r=first_radial_entry(p,(0,0),1,0,1,acceleration_bound_mps2=16)
        self.assertAlmostEqual(r.time_upper_s,(1-1/sqrt(2))/2,places=10)

    def test_immediate_closed_overlap_includes_birth_boundary(self):
        for x in (0,1):
            r=first_radial_entry(path(lambda t:(x,0,0)),(0,0),1,0,0)
            self.assertEqual((r.time_lower_s,r.time_upper_s),(0,0))

    def test_no_entry_reports_none_including_vertical_projection_outside_disk(self):
        for p in (path(lambda t:(2,2,t)),path(lambda t:(2+t,0,0))):
            self.assertIsNone(first_radial_entry(p,(0,0),1,0,1))

    def test_cylinder_projection_is_independent_of_height_while_ball_is_not(self):
        p=path(lambda t:(2-4*t,0,100))
        self.assertIsNotNone(first_radial_entry(p,(0,0),1,0,1))
        self.assertIsNone(first_radial_entry(p,(0,0,0),1,0,1,dimensions=3))

    def test_query_window_excludes_earlier_entry(self):
        p=path(lambda t:(2-4*t,0,0))
        r=first_radial_entry(p,(0,0),1,.4,.5)
        self.assertEqual((r.time_lower_s,r.time_upper_s),(.4,.4))
        self.assertIsNone(first_radial_entry(p,(0,0),1,.9,1))

    def test_immutable_trajectory_knots_preserve_first_entry(self):
        p=path(lambda t:(2-4*t,0,0),times=(0,.2,.4,.6,.8,1))
        r=first_radial_entry(p,(0,0),1,0,1)
        self.assertAlmostEqual(r.time_upper_s,.25,places=10)

    def test_finite_projectile_radius_can_be_supplied_by_caller(self):
        p=path(lambda t:(2-4*t,0,0))
        r=first_radial_entry(p,(0,0),1.02,0,1)
        self.assertAlmostEqual(r.time_upper_s,.245,places=10)

    def test_invalid_controls_fail_before_path_queries(self):
        p=path(lambda t:(_ for _ in ()).throw(AssertionError('queried invalid path')))
        for kwargs in ({'radius_m':0},{'radius_m':True},{'begin_s':-1},{'end_s':2},
                {'end_s':float('inf')},{'dimensions':1},{'dimensions':True},
                {'acceleration_bound_mps2':-1},{'time_tolerance_s':0},{'clearance_tolerance_m':-1}):
            args=dict(radius_m=1,begin_s=0,end_s=1);args.update(kwargs)
            with self.assertRaises(ValueError):first_radial_entry(p,(0,0),**args)
