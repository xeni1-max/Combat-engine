"""Blunt joins shared pre-hit snapshots without acquiring slash bleeding."""
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.simultaneous import DamagePacket, calculate_simultaneous_impacts


class BluntBatchTests(unittest.TestCase):
    def test_authored_blunt_hp_and_armor_use_one_original_snapshot(self):
        hits=calculate_simultaneous_impacts((DamagePacket('blunt',500),)*2,165,0,82.5)
        self.assertEqual([h.hp_damage for h in hits],[F(8911,20)]*2)
        self.assertEqual([h.armor_loss for h in hits],[F(1364063,140000)]*2)

    def test_mixed_families_share_raw_shield_instead_of_independent_stock(self):
        packets=(DamagePacket('blunt',500),DamagePacket('slash',300,40),DamagePacket('qard',200))
        hits=calculate_simultaneous_impacts(packets,100,400,50)
        self.assertEqual([h.shield_absorbed for h in hits],[200,120,80])
        self.assertEqual([h.damage_left_after_shield for h in hits],[300,180,120])
        self.assertTrue(all(h.pre_hit_armor==100 for h in hits))
        self.assertEqual(hits[0].hp_damage,F(800,3))

    def test_zero_and_fully_shielded_hits_do_not_divide_or_damage_armor(self):
        for damage,shield in ((0,0),(500,800)):
            h=calculate_simultaneous_impacts((DamagePacket('blunt',damage),),165,shield,0)[0]
            self.assertEqual((h.hp_damage,h.armor_loss),(0,0))

    def test_blunt_has_no_undocumented_piercing_input(self):
        with self.assertRaisesRegex(ValueError,'no piercing'):
            calculate_simultaneous_impacts((DamagePacket('blunt',500,1),),100,0,0)


if __name__=='__main__':unittest.main()
