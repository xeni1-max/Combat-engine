"""Directional velocity loss and relative-speed collision status rules."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.body_collision import CollisionCharacter, collide_characters, collide_static_obstacle, collide_ground
from combat_sim.models import UnsupportedMechanicError


def character(centre,velocity,hp=8140,armor=150,resistance=0):
    return CollisionCharacter(centre,velocity,hp,armor,resistance)


class DirectionalBodyCollisionTests(unittest.TestCase):
    def test_head_on_uses_relative_speed_and_full_amount_for_both(self):
        r=collide_characters(character([0,0,0],['6.4',0,0]),character([1,0,0],['-6.4',0,0]))
        self.assertEqual(r.relative_speed_in_direction_mps,D('12.8'))
        for c in (r.first,r.second):
            self.assertEqual(c.raw_disorientation,768)
            self.assertEqual(c.raw_instability,768)
            self.assertEqual(c.velocity_after_mps,(0,0,0))
            self.assertLess(c.added_instability,c.raw_instability)

    def test_same_direction_characters_use_difference_not_sum(self):
        r=collide_characters(character([0,0,0],['6.4',0,0]),character([1,0,0],[2,0,0]))
        self.assertEqual(r.relative_speed_in_direction_mps,D('4.4'))
        self.assertEqual(r.first.raw_disorientation,264)
        self.assertEqual(r.second.raw_disorientation,264)
        self.assertEqual(r.first.velocity_after_mps,(0,0,0))
        self.assertEqual(r.second.velocity_after_mps,(0,0,0))

    def test_oblique_line_preserves_perpendicular_motion(self):
        r=collide_characters(character([0,0,0],[5,0,0]),character([3,4,0],[0,0,0]))
        self.assertEqual(r.direction_unit,(D('.6'),D('.8'),0))
        self.assertEqual(r.relative_speed_in_direction_mps,3)
        self.assertEqual(r.first.velocity_after_mps,(D('3.2'),D('-2.4'),0))
        self.assertEqual(r.first.raw_instability,180)
        self.assertEqual(sum(v*n for v,n in zip(r.first.velocity_after_mps,r.direction_unit)),0)
        self.assertEqual(sum(v*v for v in r.first.velocity_after_mps),16)

    def test_stationary_character_receives_the_full_relative_impact(self):
        r=collide_characters(character([0,0,0],[5,0,0]),character([1,0,0],[0,0,0]))
        self.assertEqual(r.first.raw_instability,300)
        self.assertEqual(r.second.raw_instability,300)
        self.assertEqual(r.second.velocity_after_mps,(0,0,0))

    def test_resistances_are_independent_and_floor_status_at_zero(self):
        r=collide_characters(character([0,0,0],[1,0,0],resistance=100),character([1,0,0],[0,0,0]))
        self.assertEqual(r.first.raw_instability,r.second.raw_instability)
        self.assertEqual(r.first.added_instability,0)
        self.assertGreater(r.second.added_instability,0)

    def test_ground_removes_vertical_component_and_preserves_horizontal(self):
        r=collide_ground(character([0,0,'.875'],[2,3,'-3.2']))
        self.assertEqual(r.direction_unit,(0,0,1))
        self.assertEqual(r.relative_speed_in_direction_mps,D('3.2'))
        self.assertEqual(r.first.raw_disorientation,192)
        self.assertEqual(r.first.velocity_after_mps,(2,3,0))
        self.assertIsNone(r.second)

    def test_static_obstacle_has_zero_velocity(self):
        r=collide_static_obstacle(character([0,0,0],[0,5,0]),surface_normal=(0,1,0))
        self.assertEqual(r.relative_speed_in_direction_mps,5)
        self.assertEqual(r.first.raw_instability,300)
        self.assertEqual(r.first.velocity_after_mps,(0,0,0))

    def test_zero_velocity_adds_no_status(self):
        r=collide_ground(character([0,0,1],[0,0,0]))
        self.assertEqual(r.first.raw_disorientation,0)
        self.assertEqual(r.first.added_instability,0)

    def test_ambient_context_does_not_change_results(self):
        a=character([0,0,0],[F(1,3),2,0]);b=character([1,1,1],[0,0,0])
        with localcontext() as c:
            c.prec=7
            low=collide_characters(a,b)
        self.assertEqual(low,collide_characters(a,b))

    def test_off_centre_cube_face_uses_surface_normal_not_cube_centre(self):
        r=collide_static_obstacle(character(['4.95','.5','.875'],['6.4',0,0]),surface_normal=(-1,0,0))
        self.assertEqual(r.first.velocity_after_mps,(0,0,0))
        self.assertEqual(r.relative_speed_in_direction_mps,D('6.4'))
        self.assertEqual(r.first.raw_instability,384)
        other=collide_static_obstacle(character(['4.95','-.3','1.1'],['6.4',0,0]),surface_normal=(-1,0,0))
        self.assertEqual(r,other)

    def test_invalid_centres_and_defenses_are_rejected(self):
        with self.assertRaises(UnsupportedMechanicError):
            collide_characters(character([0,0,0],[1,0,0]),character([0,0,0],[0,0,0]))
        with self.assertRaises(ValueError):character([0,0,0],[0,0,0],armor=-1)

    def test_swapping_characters_preserves_each_characters_response(self):
        a=character([0,0,0],[1,2,3],resistance=10)
        b=character([3,4,0],[-2,1,0],hp=10000,armor=100)
        original=collide_characters(a,b);swapped=collide_characters(b,a)
        self.assertEqual(original.first,swapped.second)
        self.assertEqual(original.second,swapped.first)
        self.assertEqual(original.relative_speed_in_direction_mps,swapped.relative_speed_in_direction_mps)

    def test_glancing_obstacle_collision_retains_surface_parallel_motion(self):
        r=collide_static_obstacle(character([0,0,0],['6.4',2,0]),surface_normal=(-1,0,0))
        self.assertEqual(r.first.velocity_after_mps,(0,2,0))
        self.assertEqual(r.first.raw_disorientation,384)
        self.assertEqual(r.first.raw_instability,384)

    def test_normal_sign_and_scale_do_not_change_response(self):
        a=character([0,0,0],[3,4,5])
        forward=collide_static_obstacle(a,surface_normal=(10,0,0))
        backward=collide_static_obstacle(a,surface_normal=(-1,0,0))
        self.assertEqual(forward.first,backward.first)
        self.assertEqual(forward.relative_speed_in_direction_mps,backward.relative_speed_in_direction_mps)

    def test_explicit_oblique_surface_normal(self):
        r=collide_static_obstacle(character([0,0,0],[5,0,3]),surface_normal=(3,4,0))
        self.assertEqual(r.direction_unit,(D('.6'),D('.8'),0))
        self.assertEqual(r.first.velocity_after_mps,(D('3.2'),D('-2.4'),3))
        self.assertEqual(r.first.raw_instability,180)

    def test_zero_or_malformed_surface_normal_is_rejected(self):
        a=character([0,0,0],[1,0,0])
        with self.assertRaisesRegex(UnsupportedMechanicError,'nonzero'):
            collide_static_obstacle(a,surface_normal=(0,0,0))
        with self.assertRaises(ValueError):collide_static_obstacle(a,surface_normal=(1,0))

    def test_surface_normal_must_be_explicit_not_an_old_positional_centre(self):
        with self.assertRaises(TypeError):
            collide_static_obstacle(character([0,0,0],[1,0,0]),[6,0,'.9'])
