"""Finite piercing-line geometry, solid arbitration and immutable combat signals."""
from dataclasses import FrozenInstanceError
from decimal import Decimal as D
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.line_delivery import sweep_line
from combat_sim.reaction_models import BlockSignal


def box(name,x,y=0,z=1,size=(1,1,1)):
    return Cuboid(name,(x,y,z),size)


class LineDeliveryTests(unittest.TestCase):
    def sweep(self,receivers,solids=None,**kwargs):
        return sweep_line((0,0,1),(5,0,1),'.02',receivers,solids or {},**kwargs)

    def test_hits_each_receiver_once_and_does_not_stop_at_the_first_body(self):
        r=self.sweep({'a':[box('torso',1),box('arm',1)],'b':[box('torso',4)]})
        self.assertEqual([name for name,_ in r.recipients],['a','b'])
        self.assertEqual(r.recipients[0][1].part,'arm');self.assertIsNone(r.blocker)

    def test_nearest_compound_solid_clips_only_receivers_behind_it(self):
        r=self.sweep({'a':[box('body',1)],'b':[box('body',4)]},
            {'far':[box('wall',4.5)],'near':[box('one',3),box('two',2.5)]})
        self.assertEqual([name for name,_ in r.recipients],['a'])
        self.assertEqual((r.blocker[0],r.blocker[1].part),('near','two'))

    def test_solid_wins_a_closed_coincident_boundary(self):
        b=box('shared',2)
        r=self.sweep({'a':[b]},{'wall':[b]})
        self.assertFalse(r.recipients);self.assertEqual(r.blocker[0],'wall')

    def test_closed_endpoint_has_physical_thickness_without_infinite_range(self):
        r=self.sweep({'touch':[box('body','5.52')],'miss':[box('body','5.520001')]})
        self.assertEqual([name for name,_ in r.recipients],['touch'])

    def test_rounded_corner_is_not_an_axis_expanded_box(self):
        # Both transverse gaps .015 exceed radius .02 jointly, although each
        # lies within an incorrectly axis-expanded box.
        r=self.sweep({'corner':[box('body',2,'.515','1.515')]})
        self.assertFalse(r.recipients)

    def test_behind_origin_and_vertical_miss_are_excluded(self):
        r=self.sweep({'behind':[box('body',-1)],'above':[box('body',2,z=3)]})
        self.assertFalse(r.recipients)

    def test_empty_receivers_still_report_solid_contact(self):
        r=self.sweep({}, {'wall':[box('wall',3)]})
        self.assertFalse(r.recipients);self.assertEqual(r.blocker[0],'wall')

    def test_order_and_precision_do_not_choose_the_receiver(self):
        parts={'z':[box('body',4)],'a':[box('body',1)]}
        a=self.sweep(parts);b=self.sweep(dict(reversed(list(parts.items()))),precision=80)
        self.assertEqual([k for k,_ in a.recipients],[k for k,_ in b.recipients])
        self.assertEqual([h.parameter for _,h in a.recipients],[h.parameter for _,h in b.recipients])

    def test_invalid_geometry_rejects(self):
        for start,end,radius in (((0,0),(1,0,1),1),((0,0,1),(0,0,1),1),((0,0,1),(1,0,1),-1)):
            with self.assertRaises(ValueError):sweep_line(start,end,radius,{}, {})


class BlockSignalTests(unittest.TestCase):
    def test_signal_is_immutable_and_input_lists_are_detached(self):
        ids=['layer'];s=BlockSignal('s','A',1,10,50,ids,['shot'])
        ids.append('not_source');self.assertEqual(s.layer_ids,('layer',))
        with self.assertRaises(FrozenInstanceError):s.actor='B'
        record=s.record();record['layer_ids'].append('fake');self.assertEqual(s.layer_ids,('layer',))

    def test_life_references_amount_and_depth_are_required(self):
        for change in ({'source_life_generation':None},{'source_life_generation':0},
                {'absorbed':0},{'layer_ids':[]},{'incoming_ids':['a','a']},{'parent_depth':True},{'actor':''}):
            args=dict(id='s',actor='A',source_life_generation=1,time_ms=0,absorbed=1,
                layer_ids=['l'],incoming_ids=['p']);args.update(change)
            with self.subTest(change=change),self.assertRaises(ValueError):BlockSignal(**args)


if __name__=='__main__':unittest.main()
