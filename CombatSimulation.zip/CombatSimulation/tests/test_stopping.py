"""Special slide distance, base-instability duration and approved decay curve."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.stopping import calculate_stopping_slide
PROFILE={'stopping_base_instability_per_mps':30}

class StoppingSlideTests(unittest.TestCase):
    def test_run_slide_has_source_distance_and_base_duration(self):
        slide=calculate_stopping_slide('6.4',8140,150,PROFILE)
        self.assertEqual(slide.duration_ms,192)
        self.assertEqual(slide.raw_distance_m,D('.32'))
        self.assertLess(abs(slide.distance_m-D('0.1434558179345469477301631676252904454620161835496')),D('1e-45'))
        self.assertNotEqual(slide.at(0).speed_mps,D('6.4'))

    def test_speed_and_distance_are_consistent_over_linear_slide(self):
        slide=calculate_stopping_slide('6.4',8140,150,PROFILE)
        with localcontext() as c:
            c.prec=60
            self.assertLess(abs(slide.initial_slide_speed_mps*D('.192')/2-slide.distance_m),D('1e-45'))
        self.assertEqual(slide.at(192).speed_mps,0)
        self.assertEqual(slide.at(192).distance_m,slide.distance_m)
        self.assertEqual(slide.at(0).distance_m,0)

    def test_midpoint_has_half_speed_and_three_quarters_distance(self):
        slide=calculate_stopping_slide('6.4',8140,150,PROFILE)
        self.assertAlmostEqual(slide.at(96).speed_mps,slide.initial_slide_speed_mps/2,places=25)
        self.assertAlmostEqual(slide.at(96).distance_m,slide.distance_m*D('.75'),places=25)

    def test_walking_resistance_cancels_all_travel(self):
        slide=calculate_stopping_slide(2,8140,150,PROFILE)
        self.assertEqual(slide.duration_ms,60)
        self.assertEqual(slide.distance_m,0)
        for time in (0,30,60):
            self.assertEqual(slide.at(time).distance_m,0)
            self.assertEqual(slide.at(time).speed_mps,0)

    def test_no_defenses_matches_raw_slide_distance(self):
        slide=calculate_stopping_slide('6.4',0,0,PROFILE)
        self.assertEqual(slide.distance_m,D('.32'))
        self.assertEqual(slide.resistance_reduction_m,0)

    def test_zero_speed_is_immediate_no_travel(self):
        slide=calculate_stopping_slide(0,8140,150,PROFILE)
        self.assertEqual(slide.duration_ms,0)
        self.assertEqual(slide.at(0).speed_mps,0)

    def test_current_armor_changes_distance_but_not_duration(self):
        low=calculate_stopping_slide('6.4',8140,0,PROFILE)
        high=calculate_stopping_slide('6.4',8140,150,PROFILE)
        self.assertGreater(low.distance_m,high.distance_m)
        self.assertEqual(low.duration_ms,high.duration_ms)

    def test_precision_does_not_change_duration_and_converges(self):
        with localcontext() as c:
            c.prec=7
            low=calculate_stopping_slide('6.4',8140,150,PROFILE)
        high=calculate_stopping_slide('6.4',8140,150,PROFILE,precision=80)
        self.assertEqual(low.duration_ms,high.duration_ms)
        self.assertLess(abs(low.distance_m-high.distance_m),D('1e-45'))

    def test_invalid_inputs_and_times_are_rejected(self):
        for values in ((-1,8140,150),(1,-1,150),(1,8140,-1)):
            with self.assertRaises(ValueError):calculate_stopping_slide(*values,PROFILE)
        slide=calculate_stopping_slide('6.4',8140,150,PROFILE)
        for time in (-1,193):
            with self.assertRaises(ValueError):slide.at(time)
