"""Movement runs on the real shared combat event loop, with effects excluded."""
from copy import deepcopy
from decimal import Decimal as D, Context, localcontext
import json
from pathlib import Path
import unittest

from combat_sim.engine import run_scenario
from combat_sim.shared_engine import run_shared_scenario
from combat_sim.models import UnsupportedMechanicError

ROOT=Path(__file__).resolve().parents[1]
load=lambda path:json.loads((ROOT/path).read_text())
SCENARIO=load('scenarios/scripted_movement_geometry.json')
PROFILES=load('data/characters.json')['characters']
BODY=load('data/body_hitboxes.json')
TERRAIN=load('data/terrain/stationary_arena.json')
MOVEMENT=load('data/movement/walk_run.json')
JUMP=load('data/movement/jump.json')
KWARGS=dict(body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,jump_definition=JUMP)

def run(s=SCENARIO,**kwargs):
    return run_shared_scenario(s,PROFILES,**KWARGS,**kwargs)

def events(r,kind):return [e for e in r['events'] if e['type']==kind]

class SharedMovementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.result=run()

    def test_public_engine_dispatch_uses_shared_timeline(self):
        self.assertEqual(run_scenario(SCENARIO,PROFILES,**KWARGS),self.result)
        self.assertEqual(self.result['execution_model'],'shared_encounter')
        self.assertEqual(self.result['movement_test_scope']['kind'],'shared_engine_geometry_and_timing')

    def test_provenance_labels_do_not_change_physics_or_replace_mechanical_validation(self):
        options=deepcopy(KWARGS)
        options['movement_definition']['status']='author_rules_and_delegated_profile_defaults'
        options['jump_definition']['status']='source_and_delegated_anchors'
        result=run_shared_scenario(SCENARIO,PROFILES,**options)
        self.assertEqual(result['final_states'],self.result['final_states'])
        options['movement_definition']['units']['speed']='km/h'
        with self.assertRaisesRegex(UnsupportedMechanicError,'units'):
            run_shared_scenario(SCENARIO,PROFILES,**options)

    def test_straight_walk_run_transition_and_final_positions(self):
        for name,state in self.result['final_states'].items():
            self.assertEqual(D(state['position_m'][0]),D('21.62'))
            self.assertEqual(D(state['position_m'][1]),D(-20 if name=='A_1E1' else -30))
            self.assertEqual(state['locomotion']['mode'],'walking')
            self.assertEqual(D(state['locomotion']['speed_mps']),2)
            durations=[D(e['active_ms']) for e in events(self.result,'movement_transition_started') if e['actor']==name]
            self.assertEqual(durations,[60,150,150])

    def test_body_geometry_tracks_final_position(self):
        for name,state in self.result['final_states'].items():
            body=self.result['body_geometry'][name]
            self.assertEqual(list(map(D,body['origin_m'][:2])),list(map(D,state['position_m'])))
            self.assertEqual(D(body['origin_m'][2]),D('.875'))
            self.assertEqual(len(body['parts']),6)

    def test_jump_takeoff_is_after_running_gathering_and_retains_speed(self):
        for e in events(self.result,'jump_takeoff'):
            self.assertEqual(D(e['time_ms']),2320)
            self.assertEqual(D(e['upward_speed_mps']),D('3.2'))
            self.assertEqual(D(e['horizontal_speed_mps']),D('6.4'))
            self.assertEqual(D(e['active_end_ms']),2470)
            self.assertGreater(D(e['landing_at_ms']),D(e['active_end_ms']))

    def test_landing_resets_vertical_motion_only(self):
        land=events(self.result,'jump_landed')
        self.assertEqual(len(land),2)
        with localcontext(Context(prec=60)):
            self.assertLess(abs(D(land[0]['time_ms'])-(D(2320)+D(640000)/981)),D('1e-40'))
        for state in self.result['final_states'].values():
            self.assertTrue(state['locomotion']['grounded'])
            self.assertEqual(D(state['locomotion']['velocity_mps'][2]),0)

    def test_active_ending_does_not_end_airborne_state(self):
        points=[p for p in self.result['curve'] if D(p['time_ms'])==2470]
        self.assertTrue(points)
        for point in points:
            for state in point['states'].values():
                self.assertFalse(state['locomotion']['grounded'])
                self.assertGreater(D(state['body_origin_m'][2]),D('.875'))

    def test_effects_are_explicitly_excluded_and_state_is_preserved(self):
        for name,state in self.result['final_states'].items():
            initial=self.result['initial_states'][name]
            for field in ('hp','armor','shield','disorientation','instability','dyspnea'):
                self.assertEqual(D(state[field]),D(initial[field]))
        self.assertFalse(events(self.result,'projectile_released'))
        self.assertEqual(self.result['movement_test_scope']['statuses_and_dyspnea'],'excluded_by_author_for_this_test')

    def test_precision_and_observations_do_not_change_cadence_or_positions(self):
        cadence=lambda r:[(e['time_ms'],e['type'],e.get('actor')) for e in r['events'] if e['type'].startswith(('movement_','jump_'))]
        for trial in (run(precision=80),run(sample_interval_ms=137),run(sample_interval_ms=None)):
            a,b=cadence(trial),cadence(self.result)
            self.assertEqual([(e[1],e[2]) for e in a],[(e[1],e[2]) for e in b])
            for x,y in zip(a,b):self.assertLess(abs(D(x[0])-D(y[0])),D('1e-35'))
            for name,state in trial['final_states'].items():
                for a,b in zip(state['body_origin_m'],self.result['final_states'][name]['body_origin_m']):
                    self.assertLess(abs(D(a)-D(b)),D('1e-35'))

    def test_explicit_inputs_are_required(self):
        with self.assertRaisesRegex(UnsupportedMechanicError,'explicit movement'):
            run_shared_scenario(SCENARIO,PROFILES,body_definition=BODY,terrain_definition=TERRAIN)

    def test_overlapping_commands_are_rejected(self):
        s=deepcopy(SCENARIO);s['movement_script'].append({'actor':'A_1E1','at_ms':10,'action':'run'})
        with self.assertRaisesRegex(UnsupportedMechanicError,'overlap'):run(s)

    def test_direct_standing_to_running_is_not_invented(self):
        s=deepcopy(SCENARIO);s['movement_script'][0]['action']='run'
        with self.assertRaisesRegex(UnsupportedMechanicError,'stand-to-run'):run(s)

    def test_walking_stop_has_zero_travel_and_retains_active_duration(self):
        s=deepcopy(SCENARIO);s['movement_script'].append({'actor':'A_1E1','at_ms':4000,'action':'stop'})
        r=run(s)
        self.assertEqual(D(r['final_states']['A_1E1']['position_m'][0]),D('17.62'))
        stop=next(e for e in events(r,'special_stop_started') if e['actor']=='A_1E1')
        self.assertEqual(D(stop['slide_distance_m']),0)
        self.assertEqual(D(stop['slide_duration_ms']),60)
        self.assertTrue(stop['zero_distance_stops_travel_immediately'])
        self.assertEqual(r['final_states']['A_1E1']['locomotion']['mode'],'standing')

    def test_cube_stops_full_body_at_first_contact_without_tunnelling(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['A_1E1']['position_m']=[0,0]
        s['movement_script']=[i for i in s['movement_script'] if i['at_ms']<=1000]
        r=run(s,sample_interval_ms=None)
        stop=next(e for e in events(r,'movement_blocked') if e['actor']=='A_1E1')
        self.assertEqual(D(stop['time_ms']),D('1521.875'))
        self.assertEqual(D(r['final_states']['A_1E1']['position_m'][0]),D('4.95'))
        self.assertEqual(r['final_states']['A_1E1']['locomotion']['mode'],'standing')

    def test_body_to_body_contact_stops_both(self):
        s=deepcopy(SCENARIO)
        s['encounter']['participants']['B_1E2'].update(position_m=[3,-20],facing='-x')
        s['movement_script']=[i for i in s['movement_script'] if i['at_ms']==0]
        r=run(s,sample_interval_ms=None)
        a,b=(D(r['final_states'][n]['position_m'][0]) for n in ('A_1E1','B_1E2'))
        self.assertEqual(b-a,D('.3'))
        self.assertEqual(len(events(r,'movement_blocked')),2)

    def test_starting_overlap_is_rejected(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['A_1E1']['position_m']=[6,0]
        with self.assertRaisesRegex(UnsupportedMechanicError,'overlapping'):run(s)

    def test_previous_terrain_trace_with_corrected_initial_hand_snapshot(self):
        from tests.historical_assertions import with_correct_initial_hands
        folder=ROOT/'results/stationary-2v2-terrain'
        r=run_shared_scenario(json.loads((folder/'scenario.json').read_text()),json.loads((folder/'characters.json').read_text())['characters'],
            body_definition=json.loads((folder/'body_hitboxes.json').read_text()),terrain_definition=json.loads((folder/'terrain.json').read_text()))
        profiles=json.loads((folder/'characters.json').read_text())['characters']
        self.assertEqual(r,with_correct_initial_hands(json.loads((folder/'run.json').read_text()),profiles))

    def test_stationary_and_walking_jumps_use_current_horizontal_velocity(self):
        for walking in (False,True):
            s=deepcopy(SCENARIO);s['encounter']['duration_ms']=2000
            actions=[(0,'walk'),(1000,'jump')] if walking else [(0,'jump')]
            s['movement_script']=[{'actor':n,'at_ms':t,'action':a} for t,a in actions for n in s['encounter']['participants']]
            r=run(s)
            for e in events(r,'jump_takeoff'):
                self.assertEqual(D(e['time_ms']),1100 if walking else 100)
                self.assertEqual(D(e['horizontal_speed_mps']),2 if walking else 0)
            for e in events(r,'jump_apex'):
                self.assertLess(abs(D(e['height_above_ground_m'])-D(512)/981),D('1e-25'))
                self.assertLess(abs(D(e['vertical_velocity_mps'])),D('1e-40'))

    def test_negative_facing_walks_forward_along_negative_world_x(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['B_1E2']['facing']='-x'
        r=run(s)
        self.assertEqual(D(r['final_states']['B_1E2']['position_m'][0]),D('-21.62'))

    def test_collision_during_acceleration_cancels_transition(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['A_1E1']['position_m']=['4.93',0]
        s['movement_script']=[i for i in s['movement_script'] if i['at_ms']==0]
        r=run(s,sample_interval_ms=None)
        self.assertEqual(D(r['final_states']['A_1E1']['position_m'][0]),D('4.95'))
        self.assertFalse(any(e['actor']=='A_1E1' for e in events(r,'movement_transition_completed')))

    def test_special_stop_midpoint_obeys_distance_and_velocity_curve(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=2500
        s['movement_script']=[{'actor':n,'at_ms':t,'action':a} for t,a in [(0,'walk'),(1000,'run'),(2000,'stop')]
                              for n in s['encounter']['participants']]
        r=run(s,sample_interval_ms=1048)
        point=next(p for p in r['curve'] if D(p['time_ms'])==2096)
        for name,state in point['states'].items():
            stop=next(e for e in events(r,'special_stop_started') if e['actor']==name)
            self.assertLess(abs(D(state['position_m'][0])-D('8.01')-D(stop['slide_distance_m'])*D('.75')),D('1e-25'))
            self.assertLess(abs(D(state['locomotion']['speed_mps'])-D(stop['initial_slide_speed_mps'])/2),D('1e-25'))
            self.assertEqual(state['locomotion']['phase'],'stopping_active')
            self.assertLess(abs(D(r['final_states'][name]['position_m'][0])-D('8.01')-D(stop['slide_distance_m'])),D('1e-25'))
            self.assertEqual(D(r['final_states'][name]['locomotion']['speed_mps']),0)

    def test_complete_walk_run_stop_and_three_jump_modes(self):
        r=run(load('scenarios/scripted_movement_stopping.json'))
        for name,state in r['final_states'].items():
            self.assertTrue(state['locomotion']['grounded'])
            self.assertEqual(state['locomotion']['mode'],'standing')
            self.assertEqual(D(state['locomotion']['speed_mps']),0)
            self.assertLess(abs(D(state['position_m'][0])-D('26.7734558179345469477301631676252904454620161835496')),D('1e-25'))
            self.assertEqual(r['metrics'][name]['special_stops'],2)
            self.assertEqual(r['metrics'][name]['landings'],3)
            stops=[e for e in events(r,'special_stop_started') if e['actor']==name]
            self.assertEqual([D(e['slide_duration_ms']) for e in stops],[192,60])
            launches=[e for e in events(r,'jump_takeoff') if e['actor']==name]
            self.assertEqual([D(e['horizontal_speed_mps']) for e in launches],[D('6.4'),0,2])

    def test_collision_during_slide_cancels_slide_completion(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=3000
        s['encounter']['participants']['A_1E1']['position_m']=[0,0]
        s['movement_script']=[{'actor':n,'at_ms':t,'action':a} for t,a in [(0,'walk'),(1000,'run'),(1500,'stop')]
                              for n in s['encounter']['participants']]
        r=run(s,sample_interval_ms=None)
        self.assertEqual(D(r['final_states']['A_1E1']['position_m'][0]),D('4.95'))
        self.assertTrue(any(e['actor']=='A_1E1' for e in events(r,'movement_blocked')))
        self.assertFalse(any(e['actor']=='A_1E1' for e in events(r,'special_stop_completed')))

    def test_previous_shared_movement_complete_traces_unchanged(self):
        folder=ROOT/'results/scripted-movement-shared'
        options={k:json.loads((folder/f).read_text()) for k,f in [
            ('body_definition','body_hitboxes.json'),('terrain_definition','terrain.json'),
            ('movement_definition','movement.json'),('jump_definition','jump.json')]}
        profiles=json.loads((folder/'characters.json').read_text())['characters']
        for scenario,result in [('scenario.json','run.json'),('contact_scenario.json','contact_run.json')]:
            actual=run_shared_scenario(json.loads((folder/scenario).read_text()),profiles,**options)
            self.assertEqual(actual,json.loads((folder/result).read_text()))
