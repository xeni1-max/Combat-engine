"""Persistent shared-world link probes, not an authored grapple/knockback cast."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.shared_engine import run_shared_scenario
from combat_sim.spatial_transitions import SpatialChange,StaleSpatialPlan
from tests.test_combat_reactions import engine
from tests.test_motion_boundary_combat import scene as base_scene,CURRENT
from tests.test_mobile_combat import BODY,MOVEMENT,PROFILES,TERRAIN,command,events
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_world_colliders_combat import wall
from combat_sim.mechanics.grapple import shared_velocity
from combat_sim.mechanics.velocity_projection import BlockedDirection


def scene(duration=1000):
    s=base_scene(duration,(0,-20));s['encounter']['participants']['B']['position_m']=[0,-22]
    return s


def attach(time=0,controller='A',target='B',identity='hold',duration=5000,**kw):
    return {'at_ms':time,'scope':'engineering','source':'scenario:grapple_motion_probe','grapple':{
        'operation':'attach','id':identity,'controller':controller,'target':target,'controller_life_generation':1,
        'target_life_generation':1,'duration_ms':duration,**kw}}


def force(time,actor,velocity=None,reference=None,life=1):
    return {'at_ms':time,'scope':'engineering','source':'scenario:group_force_probe','changes':[
        {'actor':actor,'expected_life_generation':life,**({'velocity_mps':velocity} if velocity is not None else {}),
            **({'reference_m':reference} if reference is not None else {})}]}


def run(s,*,precision=50,interval=None):
    return run_shared_scenario(s,PROFILES,precision=precision,sample_interval_ms=interval,body_definition=BODY,
        terrain_definition=TERRAIN,movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
        jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS)


def vel(r,actor):return tuple(map(D,r['final_states'][actor]['locomotion']['velocity_mps']))
def pos(r,actor):return tuple(map(D,r['final_states'][actor]['body_origin_m']))


class GrappleMotionTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_free_drives_remain_independent_but_share_motion_persistently(self):
        s=scene();s['spatial_interventions']=[force(0,'A',[3,0,0]),attach()]
        r=run(s)
        self.assertEqual(vel(r,'A'),(D('1.5'),0,0));self.assertEqual(vel(r,'A'),vel(r,'B'))
        self.assertEqual(pos(r,'A'),(D('1.5'),-20,D('.875')))
        self.assertEqual(pos(r,'B'),(D('1.5'),-22,D('.875')))
        self.assertEqual(r['grapple_links'][0]['status'],'active')

    def test_later_real_walk_transition_keeps_the_actors_together(self):
        s=scene();s['spatial_interventions']=[force(0,'A',[3,0,0]),attach()];command(s,'A',400,'walk')
        r=run(s)
        self.assertEqual(vel(r,'A'),(1,0,0));self.assertEqual(vel(r,'A'),vel(r,'B'))
        self.assertEqual(pos(r,'A')[0],D('1.215'));self.assertEqual(pos(r,'A')[0],pos(r,'B')[0])
        self.assertTrue(events(r,'movement_active_completed'))

    def test_force_on_one_member_sets_the_whole_group_velocity_once(self):
        s=scene();s['spatial_interventions']=[attach(),force(100,'B',[3,0,0])]
        r=run(s)
        self.assertEqual(vel(r,'A'),(3,0,0));self.assertEqual(vel(r,'A'),vel(r,'B'))
        self.assertEqual(pos(r,'A')[0],D('2.7'));self.assertEqual(pos(r,'B')[0],D('2.7'))
        self.assertEqual([b['actor'] for b in r['spatial_transitions'][0]['bodies']],['A','B'])
        self.assertEqual(r['grapple_links'][0]['status'],'active')

    def test_group_upward_force_has_one_gravity_and_two_real_landings(self):
        s=scene();s['spatial_interventions']=[attach(),force(0,'B',[3,0,3])]
        r=run(s)
        self.assertEqual(pos(r,'A'),(3,-20,D('.875')));self.assertEqual(pos(r,'B'),(3,-22,D('.875')))
        landed=events(r,'jump_landed');self.assertEqual(len(landed),2)
        for e in landed:
            self.assertAlmostEqual(D(e['time_ms']),D(6000)/D('9.81'),places=15)
            self.assertEqual(e['self_effects'],{'disorientation':'0','instability':'0'})
        self.assertFalse(events(r,'dyspnea_paid'));self.assertFalse(events(r,'jump_takeoff'))

    def test_one_wall_contact_blocks_the_group_and_preserves_tangent_motion(self):
        s=scene(600);s['encounter']['participants']['A']['position_m']=[4,0]
        s['encounter']['participants']['B']['position_m']=[2,-2]
        s['spatial_interventions']=[attach(),force(0,'A',[3,1,0])]
        r=run(s)
        self.assertEqual(len(events(r,'body_contact')),1)
        self.assertEqual(vel(r,'A'),(0,1,0));self.assertEqual(vel(r,'A'),vel(r,'B'))
        self.assertAlmostEqual(pos(r,'A')[0],D('4.95'),places=15)
        self.assertAlmostEqual(pos(r,'B')[0],D('2.95'),places=15)
        self.assertEqual(r['metrics']['B']['collision_stops'],0)

    def test_group_relocation_is_one_translation_and_one_atomic_update(self):
        s=scene(100);s['spatial_interventions']=[attach(),force(0,'A',reference=[3,-15,'.875'])]
        r=run(s);self.assertEqual(pos(r,'A'),(3,-15,D('.875')));self.assertEqual(pos(r,'B'),(3,-17,D('.875')))
        self.assertEqual(len(r['spatial_transitions'][0]['bodies']),2)

    def test_invalid_partner_destination_rejects_the_entire_group_change(self):
        s=scene(200);s['encounter']['participants']['A']['position_m']=[0,0]
        s['encounter']['participants']['B']['position_m']=[0,2]
        s['spatial_interventions']=[attach(),force(0,'A',reference=[6,-2,'.875'])]
        r=run(s);self.assertEqual(r['spatial_interventions'][1]['status'],'rejected')
        self.assertFalse(r['spatial_transitions']);self.assertEqual(pos(r,'A')[0],0);self.assertEqual(pos(r,'B')[0],0)

    def test_expiry_restores_independent_free_drives_without_new_impulse(self):
        s=scene();s['spatial_interventions']=[force(0,'A',[3,0,0]),attach(duration=500)]
        r=run(s);self.assertEqual(vel(r,'A'),(3,0,0));self.assertEqual(vel(r,'B'),(0,0,0))
        self.assertEqual(pos(r,'A')[0],D('2.25'));self.assertEqual(pos(r,'B')[0],D('.75'))
        self.assertEqual(r['grapple_links'][0]['end_reason'],'duration_expired')

    def test_actual_jump_lifts_the_group_and_keeps_the_jumpers_landing_effects(self):
        s=scene(1200);s['spatial_interventions']=[attach()];command(s,'A',0,'jump')
        r=run(s);self.assertEqual(pos(r,'A')[2],D('.875'));self.assertEqual(pos(r,'B')[2],D('.875'))
        self.assertEqual(len(events(r,'jump_takeoff')),1);self.assertEqual(len(events(r,'jump_landed')),2)
        effects={e['actor']:e['self_effects'] for e in events(r,'jump_landed')}
        self.assertGreater(D(effects['A']['instability']),0);self.assertEqual(D(effects['B']['instability']),0)

    def test_real_jump_does_not_average_the_existing_horizontal_motion_twice(self):
        s=scene(1200);s['spatial_interventions']=[force(0,'A',[3,0,0]),attach()];command(s,'A',0,'jump')
        r=run(s)
        for n in ('A','B'):
            self.assertEqual(vel(r,n),(D('1.5'),0,0))
            self.assertLess(abs(pos(r,n)[0]-D('1.8')),D('1e-20'))
        self.assertEqual(len(events(r,'jump_takeoff')),1)

    def test_expiry_at_the_force_timestamp_releases_membership_before_the_force(self):
        s=scene();s['spatial_interventions']=[attach(duration=500),force(500,'B',[3,0,0])]
        r=run(s);self.assertEqual(vel(r,'A'),(0,0,0));self.assertEqual(vel(r,'B'),(3,0,0))
        self.assertEqual(pos(r,'A')[0],0);self.assertEqual(pos(r,'B')[0],D('1.5'))
        self.assertEqual([b['actor'] for b in r['spatial_transitions'][0]['bodies']],['B'])

    def test_no_ordinary_dyspnea_recovery_while_the_link_holds(self):
        s=scene();s['spatial_interventions']=[attach(duration=500)]
        for row in s['encounter']['participants'].values():row['initial_state']['dyspnea']=40
        r=run(s)
        for n in ('A','B'):self.assertEqual(D(r['final_states'][n]['dyspnea']),25)
        self.assertFalse([e for e in events(r,'dyspnea_recovered') if D(e['time_ms'])<=500])

    def test_graph_cycles_count_each_actor_once_for_motion_and_knock_resistance(self):
        s=scene(500);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=[0,-24];s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        s['spatial_interventions']=[force(0,'A',[6,0,0]),attach(identity='ab'),
            attach(controller='B',target='C',identity='bc'),attach(controller='C',target='A',identity='ca')]
        r=run(s)
        for n in ('A','B','C'):self.assertEqual(vel(r,n),(2,0,0));self.assertEqual(pos(r,n)[0],1)
        w=engine(s);w.run();assessment=w.grapple_links.knockback_distance('B',15)
        self.assertEqual(assessment.actors,('A','B','C'))
        self.assertEqual(assessment.maximum_hp_sum,3*D(PROFILES['1E2']['max_hp']))

    def test_attach_requires_current_living_participant_lives(self):
        s=scene(100);s['spatial_interventions']=[attach(target_life_generation=2)]
        r=run(s);self.assertEqual(r['spatial_interventions'][0]['status'],'skipped');self.assertFalse(r['grapple_links'])

    def test_link_change_makes_a_prepared_spatial_plan_stale(self):
        w=engine(scene(1));plan=w.spatial_transitions.prepare((SpatialChange('A',1,velocity_mps=(3,0,0)),),source='probe:stale')
        command=w.grapple_links.parse_command(attach()['grapple']);w.grapple_links.commit(w.grapple_links.prepare(command,source='probe:link'))
        with self.assertRaises(StaleSpatialPlan):w.spatial_transitions.commit(plan)

    def test_group_force_is_observation_precision_and_participant_order_independent(self):
        s=scene();s['spatial_interventions']=[attach(),force(0,'B',[3,0,3])]
        baseline=run(s,interval=100);other=deepcopy(s)
        other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        r=run(other,precision=80,interval=137)
        for n in ('A','B'):
            for x,y in zip(pos(baseline,n),pos(r,n)):self.assertLess(abs(x-y),D('1e-20'))
            self.assertEqual(vel(baseline,n),vel(r,n))
        self.assertEqual(len(events(baseline,'body_contact')),len(events(r,'body_contact')))

    def test_oblique_character_contact_transmits_the_centre_line_constraint(self):
        s=scene();s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=[2,'-20.1'];s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        s['spatial_interventions']=[attach(),force(0,'A',[3,0,0])]
        r=run(s)
        self.assertEqual(len(events(r,'body_contact')),1)
        for n in ('A','B','C'):
            self.assertTrue(all(abs(v)<D('1e-20') for v in vel(r,n)))
        self.assertEqual(r['metrics']['B']['collision_stops'],0)
        self.assertEqual(len(events(r,'grapple_contact_transmitted')),1)

    def test_two_grapple_groups_collide_without_reinjecting_partner_velocity(self):
        s=scene(1500)
        for name,y in (('C',-20),('D',-18)):
            s['encounter']['participants'][name]=deepcopy(s['encounter']['participants']['B'])
            s['encounter']['participants'][name]['position_m']=[5,y]
            s['action_selection'][name]=deepcopy(s['action_selection']['B'])
        s['spatial_interventions']=[attach(identity='ab'),attach(controller='C',target='D',identity='cd'),
            force(0,'A',[3,0,0]),force(0,'D',[-2,0,0])]
        r=run(s);self.assertEqual(len(events(r,'body_contact')),1)
        for n in ('A','B','C','D'):self.assertEqual(vel(r,n),(0,0,0))
        self.assertEqual(pos(r,'A')[0],pos(r,'B')[0]);self.assertEqual(pos(r,'C')[0],pos(r,'D')[0])
        self.assertEqual(len(events(r,'grapple_contact_transmitted')),2)

    def test_simultaneous_different_member_contacts_constrain_the_group_once(self):
        s=scene(600);s['encounter']['participants']['A']['position_m']=[4,0]
        s['encounter']['participants']['B']['position_m']=[0,4]
        s['initial_colliders']=[{'id':'cross_wall','source':'scenario_geometry','hp':None,'duration_ms':None,
            'climbable':False,'blocking':{'projectiles':True,'bodies':True,'areas':False},
            'parts':[{'part':'panel','centre_m':[1,'5.4','.9'],'size_m':[2,'.2','1.8']}]}]
        s['spatial_interventions']=[attach(),force(0,'A',[3,3,0])]
        baseline=run(s,interval=100);other=deepcopy(s)
        other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        r=run(other,precision=80,interval=137)
        for result in (baseline,r):
            self.assertEqual(len(events(result,'body_contact')),2)
            self.assertEqual(len(events(result,'grapple_contact_transmitted')),1)
            self.assertEqual(vel(result,'A'),(0,0,0));self.assertEqual(vel(result,'B'),(0,0,0))
        for n in ('A','B'):
            for x,y in zip(pos(baseline,n),pos(r,n)):self.assertLess(abs(x-y),D('1e-20'))

    def test_ceiling_contact_removes_upward_motion_then_gravity_starts_falling(self):
        s=scene(1500);s['initial_colliders']=[wall('ceiling',x=0,hp=None,size=(6,6,'.2'),z=3)]
        s['spatial_interventions']=[attach(),force(0,'A',[0,0,5])]
        r=run(s);self.assertEqual(len(events(r,'body_contact')),4)
        self.assertEqual(len(events(r,'jump_landed')),2)
        self.assertEqual(pos(r,'A')[2],D('.875'));self.assertEqual(pos(r,'B')[2],D('.875'))
        self.assertEqual(r['grapple_links'][0]['status'],'active')

    def test_downward_group_force_contacts_the_ground_without_creating_a_prone_flag(self):
        s=scene(300);s['spatial_interventions']=[attach(),force(0,'A',[0,0,-4])]
        r=run(s);self.assertEqual(len(events(r,'body_contact')),2)
        for n in ('A','B'):
            self.assertEqual(pos(r,n)[2],D('.875'));self.assertEqual(vel(r,n),(0,0,0))
            self.assertFalse(r['final_states'][n].get('knocked_down',False))

    def test_existing_special_stop_changes_the_free_drive_without_splitting_the_group(self):
        s=scene();s['spatial_interventions']=[attach(),force(0,'A',[3,0,0])];command(s,'A',400,'stop')
        r=run(s);self.assertEqual(len(events(r,'special_stop_started')),1)
        self.assertEqual(vel(r,'A'),(D('1.5'),0,0));self.assertEqual(vel(r,'B'),vel(r,'A'))
        self.assertEqual(pos(r,'A')[0],pos(r,'B')[0])

    def test_real_gun_damage_changes_the_shared_weight_using_current_armor(self):
        s=scene(200);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=[30,-20]
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=0)
        s['spatial_interventions']=[force(0,'A',[3,0,0]),attach()]
        r=run(s);self.assertEqual(len(events(r,'impact_batch_resolved')),1)
        armor=D(r['final_states']['A']['armor']);self.assertLess(armor,D(PROFILES['1E2']['base_armor']))
        expected=shared_velocity((3,0,0),(0,0,0),first_max_hp=PROFILES['1E2']['max_hp'],first_armor=armor,
            second_max_hp=PROFILES['1E2']['max_hp'],second_armor=PROFILES['1E2']['base_armor'])
        self.assertLess(abs(vel(r,'A')[0]-expected[0]),D('1e-40'));self.assertEqual(vel(r,'A'),vel(r,'B'))
        self.assertLess(vel(r,'A')[0],D('1.5'))

    def test_actual_gun_kill_releases_the_link_and_preserves_the_survivors_force_motion(self):
        s=scene();s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=[30,-20]
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=0)
        s['spatial_interventions']=[attach(),force(0,'A',[3,0,0])]
        r=run(s);death=D(r['final_states']['A']['died_at_ms'])
        self.assertEqual(D(r['grapple_links'][0]['ended_at_ms']),death)
        self.assertEqual(r['grapple_links'][0]['status'],'ended')
        self.assertEqual(vel(r,'A'),(0,0,0));self.assertEqual(vel(r,'B'),(3,0,0))
        self.assertLess(abs(pos(r,'A')[0]-3*death/1000),D('1e-20'));self.assertEqual(pos(r,'B')[0],3)

    def test_real_revival_does_not_rejoin_a_retired_grapple(self):
        import json
        from pathlib import Path
        s=json.loads(Path('results/death-revival/gun_return_scenario.json').read_text())
        s['spatial_interventions']=[attach(duration=10000),force(3500,'A',[3,0,0],life=1)]
        r=run(s);self.assertGreaterEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(r['grapple_links'][0]['status'],'ended')
        self.assertEqual(r['spatial_interventions'][1]['status'],'skipped')
        self.assertNotIn('grapple_group',r['final_states']['A']['locomotion'])

    def test_real_incoming_statuses_release_an_exhausted_controller(self):
        s=scene(300);s['encounter']['participants']['A']['initial_state']['dyspnea']=95
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=[30,-20]
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=0)
        s['spatial_interventions']=[attach()]
        r=run(s);self.assertEqual(r['grapple_links'][0]['end_reason'],'controller_exhausted')
        self.assertEqual(D(r['grapple_links'][0]['ended_at_ms']),D(events(r,'impact_batch_resolved')[0]['time_ms']))
        self.assertTrue(r['final_states']['A']['alive']);self.assertTrue(r['final_states']['B']['alive'])

    def test_sprint_exhaustion_ends_the_link_at_the_real_nonlinear_cap(self):
        s=scene(5000);s['encounter']['participants']['A']['initial_state']['dyspnea']=80
        command(s,'A',0,'sprint');s['spatial_interventions']=[attach(time=1000,duration=10000)]
        r=run(s);self.assertEqual(r['spatial_interventions'][0]['status'],'applied')
        self.assertEqual(r['grapple_links'][0]['end_reason'],'controller_exhausted')
        exhaustion=next(e for e in events(r,'maximum_dyspnea_trigger') if e.get('source')=='sprint')
        self.assertEqual(D(r['grapple_links'][0]['ended_at_ms']),D(exhaustion['time_ms']))

    def test_linked_relocation_updates_real_heat_membership_without_removing_the_beam(self):
        s=scene(500);s['encounter']['participants']['B'].update(character='1E1',position_m=[30,-20])
        s['action_selection']['B'].update(abilities=['4'],start_ms=0)
        s['spatial_interventions']=[attach(duration=2000),force(400,'A',reference=[0,-10,'.875'])]
        r=run(s);self.assertTrue(any(D(e['time_ms'])==400 for e in events(r,'heat_exposure_left')))
        self.assertTrue(r['volume_instances'][0]['active'])
        self.assertEqual(pos(r,'B')[:2],(30,-10))

    def test_repeated_release_and_expiry_are_idempotent(self):
        s=scene();s['spatial_interventions']=[attach(duration=500),
            {'at_ms':200,'scope':'engineering','source':'scenario:release','grapple':{'operation':'release','id':'hold'}},
            {'at_ms':300,'scope':'engineering','source':'scenario:release','grapple':{'operation':'release','id':'hold'}}]
        r=run(s);self.assertEqual(len(events(r,'grapple_link_ended')),1)
        self.assertEqual(r['spatial_interventions'][2]['status'],'no_change')
        self.assertFalse([e for e in r['pending_events'] if e['type']=='grapple_link_expired'])

    def test_incompatible_explicit_group_changes_reject_before_any_mutation(self):
        for velocity in ([-2,0,0],[0,0,0]):
            s=scene(100);c=force(0,'A',[3,0,0]);c['changes'].append({'actor':'B','expected_life_generation':1,'velocity_mps':velocity})
            s['spatial_interventions']=[attach(),c];r=run(s)
            self.assertEqual(r['spatial_interventions'][1]['status'],'rejected');self.assertFalse(r['spatial_transitions'])
            self.assertEqual(vel(r,'A'),(0,0,0));self.assertEqual(vel(r,'B'),(0,0,0))

    def test_projection_includes_existing_links_even_when_only_one_member_is_requested(self):
        w=engine(scene(1));command=w.grapple_links.parse_command(attach()['grapple'])
        w.grapple_links.commit(w.grapple_links.prepare(command,source='probe:projection'))
        w.spatial_transitions.apply((SpatialChange('A',1,velocity_mps=(3,0,0)),),source='probe:force')
        actors={'A':1};projection,plan=w.spatial_transitions.prepare_projection(actors,
            blocked=(BlockedDirection('A',(1,0,0)),),source='probe:constraints')
        w.spatial_transitions.commit(plan)
        self.assertEqual(actors,{'A':1});self.assertEqual(projection.components,(('A','B'),))
        for n in ('A','B'):self.assertEqual(w.mobile_motion(n)[0],(0,0,0))

    def test_balanced_free_input_change_still_invalidates_a_spatial_plan(self):
        w=engine(scene(1));command=w.grapple_links.parse_command(attach()['grapple'])
        w.grapple_links.commit(w.grapple_links.prepare(command,source='probe:inputs'))
        plan=w.spatial_transitions.prepare((SpatialChange('A',1,velocity_mps=(3,0,0)),),source='probe:force')
        w.motion['A']['direction']=(-1,0)
        with self.assertRaises(StaleSpatialPlan):w.spatial_transitions.commit(plan)

    def test_link_plans_are_world_bound_and_cannot_be_committed_twice(self):
        w=engine(scene(1));other=engine(scene(1));command=w.grapple_links.parse_command(attach()['grapple'])
        plan=w.grapple_links.prepare(command,source='probe:ownership')
        with self.assertRaises(ValueError):other.grapple_links.commit(plan)
        w.grapple_links.commit(plan)
        with self.assertRaises(StaleSpatialPlan):w.grapple_links.commit(plan)

    def test_link_duration_keeps_input_precision_outside_the_callers_context(self):
        w=engine(scene(1))
        with localcontext(Context(prec=9)):
            command=w.grapple_links.parse_command(attach(duration='.123456789123456789')['grapple'])
            w.grapple_links.commit(w.grapple_links.prepare(command,source='probe:precision'))
        self.assertEqual(w.grapple_links.links['hold']['expiry_ms'],D('.123456789123456789'))

    def test_malformed_link_controls_reject_before_simulation(self):
        for field,value in (('target','missing'),('target','A'),('duration_ms',0),('duration_ms',True),
                ('controller_life_generation',True),('target_life_generation',None)):
            s=scene();entry=attach();entry['grapple'][field]=value;s['spatial_interventions']=[entry]
            with self.subTest(field=field,value=value),self.assertRaises(ValueError):run(s)

    def test_released_knock_query_uses_its_single_body_stats(self):
        w=engine(scene(1));command=w.grapple_links.parse_command(attach()['grapple'])
        w.grapple_links.commit(w.grapple_links.prepare(command,source='probe:stats'))
        before=w.grapple_links.knockback_distance('A',15)
        w.grapple_links.release('hold',reason='probe_release');after=w.grapple_links.knockback_distance('A',15)
        self.assertEqual(before.actors,('A','B'));self.assertEqual(after.actors,('A',))
        self.assertGreater(after.resisted_m,before.resisted_m)


if __name__=='__main__':unittest.main()
