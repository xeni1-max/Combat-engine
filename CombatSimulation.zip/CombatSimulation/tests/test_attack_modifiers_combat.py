"""Actual 2E4 enhancement casts; labelled lifecycle probes use engine transitions."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.simultaneous import DamagePacket,calculate_simultaneous_impacts
from combat_sim.models import UnsupportedMechanicError
from tests.test_blocking_combat import scene as base_scene,run,events
from tests.test_mobile_combat import PROFILES
from tests.test_motion_boundary_combat import CURRENT
from tests.test_world_colliders_combat import wall


def scene(duration=650,abilities=('4','1'),shield=0):
    s=base_scene(duration,distance='1.1');s['id']='attack_modifier_combat'
    s['action_selection']['A']['abilities']=list(abilities)
    s['encounter']['participants']['B']['character']='2E4'
    s['encounter']['participants']['B']['initial_state']['shield']=shield
    s['action_selection']['B'].update(abilities=['1'],start_ms=100000,reload_when_empty=False)
    return s


def hits(result,target='B'):
    return [e for e in events(result,'impact_batch_resolved') if e['target']==target]


def prepare_ultimate(s):
    # Engineering fixture: hold only the thrust hand until the actual 400 ms
    # enhancement completes. Priority order alone does not serialize actions.
    s.setdefault('initial_restrictions',[]).append({'target':'A','source':'fixture:prepare_ultimate',
        'functions':['hand:right'],'duration_ms':400})
    return s


class AttackModifierCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_next_thrust_adds_twenty_armor_loss_at_real_contact(self):
        r=run(scene(430));h=hits(r)[0]
        base=calculate_simultaneous_impacts((DamagePacket('slash',440,40),),165,0,0)[0]
        self.assertEqual(D(h['time_ms']),230)
        self.assertAlmostEqual(D(h['applied_hp_damage']),D(base.hp_damage.numerator)/D(base.hp_damage.denominator),places=40)
        self.assertAlmostEqual(D(h['applied_armor_loss']),D(base.armor_loss.numerator)/D(base.armor_loss.denominator)+20,places=40)
        self.assertEqual(r['attack_modifiers'][0]['end_reason'],'consumed')
        self.assertEqual(r['attack_modifiers'][0]['consumed_by_attack_id'],r['melee_attacks'][0]['attack_id'])
        self.assertEqual(D(r['released_attack_modifiers'][0]['values']['additional_armor_loss']),20)
        self.assertEqual([e['ability'] for e in events(r,'dyspnea_paid')],['1'])
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),9)

    def test_ultimate_bypasses_real_shield_without_loss_or_recovery_credit(self):
        r=run(prepare_ultimate(scene(630,('Ultimate','1'),4000)));h=hits(r)[0]
        self.assertEqual(D(h['time_ms']),630);self.assertGreater(D(h['applied_hp_damage']),0)
        self.assertEqual(D(h['applied_shield_damage']),0);self.assertEqual(D(r['final_states']['B']['shield']),4000)
        self.assertFalse(r['shield_loss_history']);self.assertEqual(len(events(r,'blade_attached')),1)
        self.assertEqual(D(r['attack_modifiers'][0]['start_ms']),400)
        self.assertEqual(D(r['attack_modifiers'][0]['expiry_ms']),10400)
        self.assertEqual(D(r['released_attack_modifiers'][0]['values']['shielding_ignored']),4000)
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertEqual(ledger.amount(actor='A'),D(h['applied_hp_damage']))

    def test_bypass_budget_spans_real_block_and_regenerative_shield(self):
        for stock,damages in ((3000,True),(4000,False)):
            s=prepare_ultimate(scene(630,('Ultimate','1'),stock))
            s['action_selection']['B'].update(abilities=['basic_8'],start_ms=480)
            r=run(s);h=hits(r)[0]
            self.assertEqual(D(h['applied_hp_damage'])>0,damages)
            self.assertEqual(D(r['block_layers'][0]['hp']),800)
            self.assertFalse(events(r,'combat_signal_committed'))
            self.assertFalse(r['reaction_emissions'])
            self.assertEqual(D(h['applied_shield_damage']),0 if damages else 440)

    def test_next_bonus_is_spent_on_a_miss_without_consuming_a_blade(self):
        s=scene(650);s['encounter']['participants']['B']['position_m']=[30,-20]
        r=run(s);self.assertTrue(events(r,'melee_missed'));self.assertFalse(hits(r))
        self.assertEqual(r['attack_modifiers'][0]['end_reason'],'consumed')
        self.assertFalse(events(r,'replacement_blade_summoning'))

    def test_fully_shielded_thrust_spends_bonus_without_removing_armor(self):
        r=run(scene(430,shield=4000));h=hits(r)[0]
        self.assertEqual(D(h['applied_armor_loss']),0)
        self.assertEqual(D(h['applied_shield_damage']),440)
        self.assertEqual(r['attack_modifiers'][0]['end_reason'],'consumed')

    def test_death_during_activation_cancels_before_grant(self):
        r=run(scene(300,('Ultimate',)),operations=[(250,{'op':'kill'})])
        self.assertFalse(r['attack_modifiers']);self.assertFalse(events(r,'attack_modifier_granted'))
        self.assertEqual(r['final_states']['A']['hp'],'0')

    def test_unused_grants_retire_at_death_and_do_not_return_on_restoration(self):
        r=run(scene(500,('4',)),operations=[(230,{'op':'kill'}),(300,{'op':'revive'})])
        self.assertEqual(r['attack_modifiers'][0]['end_reason'],'owner_death')
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(len(r['attack_modifiers']),1)

    def test_real_effect_expiry_does_not_wait_for_observations(self):
        s=scene(10500,('Ultimate',))
        for interval in (None,137):
            r=run(s,interval=interval)
            self.assertEqual(D(r['attack_modifiers'][0]['ended_at_ms']),10400)
            self.assertEqual(r['attack_modifiers'][0]['end_reason'],'expired')

    def test_ordinary_modifiers_can_overlap_movement_and_another_owned_attack(self):
        s=scene(200)
        s['movement_script']=[{'actor':'A','at_ms':50,'action':'walk'}]
        r=run(s)
        thrust=next(e for e in events(r,'ability_started') if e['ability']=='1')
        self.assertLess(D(thrust['time_ms']),200)
        self.assertEqual(D(r['attack_modifiers'][0]['start_ms']),200)

    def test_mode_or_recipient_validation_does_not_silently_cast_an_unsupported_buff(self):
        old=deepcopy(CURRENT);old.pop('attack_modifiers')
        with self.assertRaises(UnsupportedMechanicError):run(scene(),rules=old)
        profiles=deepcopy(PROFILES)
        profiles['2E4']['abilities']['4']['modifier']['scope_ability']='unimplemented'
        with self.assertRaises(UnsupportedMechanicError):run(scene(),profiles=profiles)

    def test_both_current_enhancements_compose_on_one_thrust(self):
        r=run(prepare_ultimate(scene(630,('4','Ultimate','1'),4000)));h=hits(r)[0]
        values=r['released_attack_modifiers'][0]['values']
        self.assertEqual(D(values['additional_armor_loss']),20)
        self.assertEqual(D(values['shielding_ignored']),4000)
        self.assertEqual(D(h['time_ms']),630);self.assertEqual(D(h['applied_shield_damage']),0)
        self.assertEqual([D(g['start_ms']) for g in r['attack_modifiers']],[200,400])
        base=calculate_simultaneous_impacts((DamagePacket('slash',440,40,4000,20),),165,4000,0)[0]
        self.assertAlmostEqual(D(h['applied_armor_loss']),D(base.armor_loss.numerator)/D(base.armor_loss.denominator),places=40)

    def test_normal_and_bypassing_packets_share_real_target_without_erasing_stock(self):
        s=prepare_ultimate(scene(630,('Ultimate','1'),4000))
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(position_m=['2.2',-20],facing='-x')
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=400)
        r=run(s);h=hits(r)[0];packets={p['actor']:p for p in h['hits']}
        self.assertEqual(set(packets),{'A','C'})
        self.assertEqual(D(packets['A']['shield_absorbed']),0)
        self.assertEqual(D(packets['C']['shield_absorbed']),440)
        self.assertEqual(D(h['applied_shield_damage']),440)
        self.assertEqual(D(r['final_states']['B']['shield']),3560)
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertGreater(ledger.amount(actor='A'),0);self.assertEqual(ledger.amount(actor='C'),0)
        self.assertEqual(len(r['shield_loss_history']),1)

    def test_next_bonus_does_not_reduce_armor_snapshot_for_an_independent_simultaneous_hit(self):
        s=scene(430)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(position_m=['2.2',-20],facing='-x')
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=0)
        h=hits(run(s))[0];a,c=h['hits']
        self.assertEqual(D(h['pre_hit_armor']),165)
        self.assertEqual(D(a['nominal_hp_damage']),D(c['nominal_hp_damage']))
        self.assertAlmostEqual(abs(D(a['calculated_armor_loss'])-D(c['calculated_armor_loss'])),20,places=40)

    def test_block_and_automatic_counter_do_not_consume_a_next_thrust_grant(self):
        s=scene(300,('4','basic_8'))
        s['action_selection']['B']['start_ms']=0
        r=run(s)
        self.assertEqual(r['attack_modifiers'][0]['status'],'active')
        self.assertEqual(len(r['reaction_emissions']),1)
        self.assertFalse([s for s in r['released_attack_modifiers'] if s['actor']=='A'])

    def test_cancelled_preparation_preserves_the_unused_next_attack_bonus(self):
        # The grant starts at 200 ms; the now-concurrent thrust emits at 230 ms.
        r=run(scene(500),operations=[(220,{'op':'restriction','functions':['upper_body'],'until':600})])
        self.assertFalse(r['released_attack_modifiers'])
        self.assertEqual(r['attack_modifiers'][0]['status'],'active')
        self.assertTrue(events(r,'controlled_action_cancelled'))

    def test_obstacle_contact_consumes_bonus_but_grants_no_character_hp_credit(self):
        s=scene(430);s['encounter']['participants']['B']['position_m']=[3,-20]
        s['initial_colliders']=[wall(x='.7',hp=400)]
        r=run(s)
        self.assertEqual(r['attack_modifiers'][0]['end_reason'],'consumed')
        self.assertFalse(hits(r));self.assertEqual(DamageLedger.from_record(r['applied_hp_history']).amount(actor='A'),0)
        self.assertEqual(events(r,'world_collider_removed')[0]['collider']['status'],'destroyed')

    def test_next_attack_bonus_is_used_once_across_actual_replacement_and_grab(self):
        r=run(scene(2400));snapshots=r['released_attack_modifiers']
        self.assertGreater(len(snapshots),1)
        self.assertEqual(D(snapshots[0]['values']['additional_armor_loss']),20)
        self.assertTrue(all(D(s['values']['additional_armor_loss'])==0 for s in snapshots[1:]))
        self.assertTrue(events(r,'blade_equipped'))

    def test_recasting_an_unused_next_attack_grant_refreshes_without_stacking(self):
        r=run(scene(9300,('4',)))
        self.assertEqual(len(r['attack_modifiers']),2)
        self.assertEqual(r['attack_modifiers'][0]['end_reason'],'replaced')
        self.assertEqual(D(r['attack_modifiers'][1]['start_ms']),9200)
        self.assertEqual(D(r['attack_modifiers'][1]['values']['additional_armor_loss']),20)

    def test_real_pause_stops_cooldown_work_but_not_modifier_lifetime(self):
        s=scene(13300,('Ultimate',))
        s['encounter']['participants']['C']=dict(character='1E2',team='B',position_m=[30,-19],facing='-x',initial_state={'shield':0})
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['2'],start_ms=0)
        r=run(s)
        self.assertEqual(r['attack_modifiers'][0]['end_reason'],'expired')
        self.assertEqual(D(r['attack_modifiers'][0]['ended_at_ms']),10400)
        clock=r['final_states']['A']['cooldown_clocks']['Ultimate']
        self.assertEqual(D(clock['ready_at_ms']),68000)

    def test_released_bypass_survives_real_mutual_death_and_keeps_clipped_credit(self):
        s=prepare_ultimate(scene(630,('Ultimate','1'),4000))
        for row in s['encounter']['participants'].values():row['initial_state'].update(hp=1,armor=0)
        s['action_selection']['B']['start_ms']=400
        r=run(s);ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertEqual((ledger.amount(actor='A'),ledger.amount(actor='B')),(1,1))
        self.assertTrue(all(not s['alive'] for s in r['final_states'].values()))
        self.assertEqual(r['attack_modifiers'][0]['end_reason'],'owner_death')
        a=next(p for p in r['released_attack_modifiers'] if p['actor']=='A')
        self.assertEqual(D(a['values']['shielding_ignored']),4000)

    def test_precision_observation_and_participant_order_preserve_actual_mixed_damage(self):
        s=scene(830,('4','Ultimate','1'),4000);baseline=run(s)
        other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        result=run(other,precision=80,interval=137)
        self.assertEqual([e['end_reason'] for e in baseline['attack_modifiers'] if 'end_reason' in e],
            [e['end_reason'] for e in result['attack_modifiers'] if 'end_reason' in e])
        for name,row in baseline['final_states'].items():
            for field in ('hp','shield','armor','dyspnea','instability','disorientation'):
                self.assertAlmostEqual(D(row[field]),D(result['final_states'][name][field]),places=8)


if __name__=='__main__':unittest.main()
