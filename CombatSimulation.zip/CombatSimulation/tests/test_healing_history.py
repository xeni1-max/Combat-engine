"""Stored healing curves are queried in their recorded numerical context."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import json
import unittest

from combat_sim.mechanics.healing_history import HealingHistory


def record():
    return {'precision':50,'observed_until_ms':2000,'curves':{'h1':{
        'curve_kind':'quartic_hp_dose_v1','begin_ms':0,'end_ms':1000,
        'initial_hp':0,'final_hp':100,'coefficients':[0,100,0,0]}},'entries':[
        {'id':'one','actor':'A','recipient_life_generation':1,'begin_ms':0,'end_ms':1000,
         'requested_hp':100,'applied_healing_hp':100,'curve_basis_hp':100,'curve_id':'h1'},
        {'id':'two','actor':'A','recipient_life_generation':2,'begin_ms':1500,'end_ms':1500,
         'requested_hp':100,'applied_healing_hp':40,'curve_basis_hp':None,'curve_id':None}]}


class HealingHistoryTests(unittest.TestCase):
    def test_nonlinear_prefix_window_and_life_filters(self):
        h=HealingHistory.from_record(record())
        self.assertEqual(h.amount(actor='A',end=500),25)
        self.assertEqual(h.amount(actor='A',end=1000,window_ms=500),75)
        self.assertEqual(h.amount(actor='A',recipient_life_generation=2),40)
        self.assertEqual(h.amount(actor='A'),140)

    def test_point_old_boundary_is_excluded_and_now_is_included(self):
        h=HealingHistory.from_record(record())
        self.assertEqual(h.amount(end=1500,window_ms=100),40)
        self.assertEqual(h.amount(end=2000,window_ms=500),0)

    def test_saved_roundtrip_and_queries_use_owned_precision(self):
        h=HealingHistory.from_record(record());values=[]
        for precision in (8,28,80):
            with localcontext(Context(prec=precision)):values.append(h.amount(end=777,window_ms=333))
        self.assertEqual(values,[values[0]]*3)
        saved=json.loads(json.dumps(h.record(),default=str))
        self.assertEqual(HealingHistory.from_record(saved).amount(end=777,window_ms=333),values[0])

    def test_snapshot_mutation_cannot_change_queries(self):
        h=HealingHistory.from_record(record());copy=h.record();copy['entries'][0]['applied_healing_hp']=10000
        self.assertEqual(h.amount(),140)
        with self.assertRaises(TypeError):h.curves['h1']=None

    def test_corrupt_curve_payout_identity_or_clock_is_rejected(self):
        for key,value in (('applied_healing_hp',200),('curve_basis_hp',1000),
                ('recipient_life_generation',0),('end_ms',3000),('id','two')):
            bad=record();bad['entries'][0][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):HealingHistory.from_record(bad)

    def test_future_query_or_nonpositive_window_is_rejected(self):
        h=HealingHistory.from_record(record())
        for kwargs in ({'end':2001},{'window_ms':0},{'recipient_life_generation':True}):
            with self.assertRaises(ValueError):h.amount(**kwargs)


if __name__=='__main__':unittest.main()
