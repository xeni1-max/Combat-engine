"""Register pre-existing test ceilings without bypassing world lookup identity.

These older fixtures supply geometry directly, rather than casting abilities.
New lifecycle tests use the production creation/removal/expiry APIs.
"""


def add_fixture_collider(world,entity_id,parts):
    world.collider_system.registry.add(parts,time=world.time,source='geometry_fixture',kind='terrain',entity_id=entity_id)
    world.collider_system.sync()
    world.collider_system.dirty=world.mobile_mode
