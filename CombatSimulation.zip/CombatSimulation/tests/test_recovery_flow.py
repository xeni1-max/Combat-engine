"""Recovery forecasts preserve loss distributions, capacity and source ownership."""
from dataclasses import FrozenInstanceError
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.mechanics.continuous_numeric import recorded_root_integral,recorded_root_rate
from combat_sim.mechanics.delayed_shield import DelayedShieldRecovery
from combat_sim.mechanics.recovery_flow import RateShape,RootRate,_rate_crossings


def curve(coefficient=900,q=0,reference=0,slope=1):
    return {'curve_kind':'affine_root_v1','coefficient':D(coefficient),'q_reference':D(q),
            'reference_ms':D(reference),'slope_per_second':D(slope)}


def add(recovery,definition,begin,end):
    begin,end=D(begin),D(end)
    recovery.add_curve(begin,end,recorded_root_integral(definition,begin,end),definition)


class RecoveryFlowTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=60));context.__enter__()
        self.addCleanup(context.__exit__,None,None,None)

    def test_point_work_waits_for_delay_and_never_exceeds_service(self):
        r=DelayedShieldRecovery(20000,400);r.add_impact(D(100),D(1000))
        p=r.plan(0,25000)
        self.assertEqual(p.delivered(20100),0)
        self.assertEqual(p.delivered(21100),400)
        self.assertEqual(p.total,1000)
        self.assertEqual(p.rate(20100),400)
        self.assertEqual(p.rate(25000),0)
        self.assertEqual(r.recovered,0)

    def test_point_arriving_at_right_endpoint_cannot_serve_earlier_work(self):
        r=DelayedShieldRecovery(0,400)
        r.add_impact(D(0),D(40));r.add_impact(D(1000),D(400))
        p=r.plan(0,1000)
        self.assertAlmostEqual(p.total,40,places=22)
        self.assertEqual(p.rate(900),0)
        self.assertAlmostEqual(p.delivered(100),40,places=22)

    def test_separated_arrivals_do_not_store_unused_service(self):
        r=DelayedShieldRecovery(0,400)
        r.add_impact(D(0),D(40));r.add_impact(D(1000),D(400))
        p=r.plan(0,2000)
        self.assertAlmostEqual(p.delivered(1500),240,places=22)
        self.assertAlmostEqual(p.total,440,places=22)

    def test_growing_supply_starts_below_capacity_then_becomes_busy(self):
        r=DelayedShieldRecovery(0,400);add(r,curve(600),0,3000)
        p=r.plan(0,3000)
        crossing=D(1000)*D(4)/9
        expected=D(400)*D(8)/27+400*(D(3)-D(4)/9)
        self.assertAlmostEqual(p.pieces[0].end,crossing,places=23)
        self.assertAlmostEqual(p.total,expected,places=22)
        self.assertAlmostEqual(p.rate(100),600*D('.1').sqrt(),places=45)
        self.assertEqual(p.rate(1000),400)

    def test_cooling_supply_retains_backlog_after_arrivals_end(self):
        r=DelayedShieldRecovery(0,400);add(r,curve(900,3,3000,-2),3000,4500)
        p=r.plan(3000,8000)
        self.assertAlmostEqual(p.total,900*D(3).sqrt(),places=22)
        self.assertEqual(p.rate(5000),400)
        self.assertEqual(p.rate(7500),0)

    def test_mixed_root_rate_has_two_capacity_crossings(self):
        shape=RateShape(terms=(RootRate(800,1,0,-1),RootRate(800,0,0,1)))
        roots=_rate_crossings(shape,D(0),D(1000),D(1100))
        ratio=D(1100)/800
        expected=(1-(1-(ratio*ratio-1)**2).sqrt())*500
        self.assertEqual(len(roots),2)
        self.assertAlmostEqual(roots[0],expected,places=23)
        self.assertAlmostEqual(roots[1],1000-expected,places=23)

    def test_mixed_supply_returns_to_supply_limited_before_piece_end(self):
        r=DelayedShieldRecovery(0,1100)
        add(r,curve(800,1,0,-1),0,1000);add(r,curve(800),0,1000)
        p=r.plan(0,1000)
        self.assertLess(p.rate(10),1100)
        self.assertEqual(p.rate(500),1100)
        self.assertLess(p.rate(999),1100)
        self.assertAlmostEqual(p.total,D(3200)/3,places=22)

    def test_constant_supply_at_capacity_is_continuous(self):
        r=DelayedShieldRecovery(0,400)
        definition=RateShape(D(400)).record();add(r,definition,0,1000)
        p=r.plan(0,2000)
        self.assertEqual(p.total,400)
        self.assertEqual(p.rate(500),400)
        self.assertEqual(p.rate(1500),0)

    def test_cooling_zero_splits_even_if_recorded_interval_extends_later(self):
        r=DelayedShieldRecovery(0,1000);add(r,curve(900,1,0,-2),0,3000)
        p=r.plan(0,1000)
        self.assertEqual(p.total,300)
        self.assertEqual(p.rate(750),0)
        self.assertAlmostEqual(r.advance(D(0),D(1000)),300,places=30)

    def test_plan_rates_can_be_delayed_again_without_loss_ticks(self):
        first=DelayedShieldRecovery(0,400);first.add_impact(D(0),D(400))
        p=first.plan(0,2000)
        second=DelayedShieldRecovery(500,1000)
        for piece in p.pieces:
            amount=piece.shape.integral(piece.begin,piece.end)
            if amount:second.add_curve(piece.begin,piece.end,amount,piece.shape.record())
        q=second.plan(0,2000)
        self.assertAlmostEqual(q.delivered(1250),300,places=22)
        self.assertAlmostEqual(q.total,400,places=22)
        self.assertAlmostEqual(second.advance(D(0),D(2000)),q.total,places=22)

    def test_recorded_rate_and_integral_round_trip(self):
        shape=RateShape(D(40),(RootRate(600,0,0,1),RootRate(100,3,0,-1)))
        record=shape.record()
        self.assertEqual(recorded_root_rate(record,D(1000)),shape.rate(D(1000)))
        self.assertEqual(recorded_root_integral(record,D(0),D(2000)),shape.integral(D(0),D(2000)))

    def test_nested_curve_input_cannot_mutate_recorded_loss(self):
        r=DelayedShieldRecovery(0,400)
        definition=RateShape(terms=(RootRate(600,0,0,1),)).record()
        add(r,definition,0,3000);before=r.eligible(D(3000))
        definition['terms'][0]['coefficient']=D(1)
        self.assertEqual(r.eligible(D(3000)),before)

    def test_direct_legacy_history_edit_also_invalidates_commit(self):
        r=DelayedShieldRecovery(0,400);r.add_impact(D(0),D(400))
        p=r.plan(0,1000);r.losses[0]['amount']=D(200)
        with self.assertRaisesRegex(ValueError,'stale'):r.commit_plan(p)
        self.assertEqual(r.recovered,0)

    def test_negative_recorded_constant_cannot_create_recovery_work(self):
        definition={'curve_kind':'sum_root_v1','constant_per_second':D(-1),'terms':[]}
        with self.assertRaises(ValueError):recorded_root_integral(definition,D(0),D(1000))
        with self.assertRaises(ValueError):recorded_root_rate(definition,D(0))

    def test_plan_is_immutable_and_detached_from_history_and_records(self):
        r=DelayedShieldRecovery(0,400);add(r,curve(),0,3000)
        p=r.plan(0,5000);saved=p.record();total=p.total
        r.losses[0]['curve']['coefficient']=D(1)
        saved['pieces'][0]['curve']['terms'].clear()
        self.assertEqual(p.total,total)
        self.assertTrue(p.record()['pieces'][0]['curve']['terms'])
        with self.assertRaises(FrozenInstanceError):p.end=D(1)

    def test_commit_consumes_forecast_once(self):
        r=DelayedShieldRecovery(0,400);r.add_impact(D(0),D(1000))
        p=r.plan(0,1000)
        self.assertEqual(r.commit_plan(p),400)
        self.assertEqual(r.recovered,400)
        with self.assertRaisesRegex(ValueError,'stale'):r.commit_plan(p)

    def test_partial_commit_and_following_plan_retain_service(self):
        r=DelayedShieldRecovery(0,400);r.add_impact(D(0),D(1000))
        p=r.plan(0,3000)
        self.assertEqual(r.commit_plan(p,500),200)
        q=r.plan(500,3000)
        self.assertAlmostEqual(r.commit_plan(q),800,places=22)
        self.assertAlmostEqual(r.recovered,1000,places=22)

    def test_source_mutation_and_other_consumption_invalidate_forecast(self):
        for mutation in ('impact','curve','advance'):
            with self.subTest(mutation=mutation):
                r=DelayedShieldRecovery(0,400);r.add_impact(D(0),D(1000))
                p=r.plan(0,1000)
                if mutation=='impact':r.add_impact(D(2000),D(100))
                elif mutation=='curve':add(r,curve(),0,1000)
                else:r.advance(D(0),D(1))
                before=r.recovered
                with self.assertRaisesRegex(ValueError,'stale'):r.commit_plan(p)
                self.assertEqual(r.recovered,before)

    def test_plans_cannot_be_committed_to_another_stream(self):
        a,b=DelayedShieldRecovery(0,400),DelayedShieldRecovery(0,400)
        a.add_impact(D(0),D(400));b.add_impact(D(0),D(400))
        with self.assertRaisesRegex(ValueError,'another'):b.commit_plan(a.plan(0,1000))
        self.assertEqual(b.recovered,0)

    def test_empty_plan_and_zero_duration_preserve_state(self):
        r=DelayedShieldRecovery(0,400)
        self.assertEqual(r.plan(0,1000).total,0)
        self.assertEqual(r.plan(5,5).total,0)
        self.assertEqual(r.plan(5,5).rate(5),0)
        self.assertEqual(r.recovered,0)

    def test_bounds_and_nonpositive_rate_data_reject_before_commit(self):
        r=DelayedShieldRecovery(0,400);r.add_impact(D(0),D(400));p=r.plan(0,1000)
        for time in (-1,1001,float('nan'),True):
            with self.assertRaises(ValueError):r.commit_plan(p,time)
        self.assertEqual(r.recovered,0)
        with self.assertRaises(ValueError):r.plan(100,99)
        with self.assertRaises(ValueError):RateShape(-1)
        with self.assertRaises(ValueError):RootRate(1,0,0,D('NaN'))

    def test_prefixes_match_legacy_service_at_both_precisions(self):
        for precision in (50,80):
            with localcontext(Context(prec=precision)):
                r=DelayedShieldRecovery(1000,400)
                r.add_impact(D(0),D(200));add(r,curve(600),0,3000)
                add(r,curve(900,2,3000,-2),3000,5000)
                p=r.plan(0,10000)
                begin=D(0)
                for end in map(D,(37,499,1000,1037,1521,3000,4000,5123,7000,10000)):
                    r.advance(begin,end);begin=end
                    self.assertAlmostEqual(r.recovered,p.delivered(end),places=21)


if __name__=='__main__':unittest.main()
