"""Approaching-reference contacts and bounded restitution in crowded material."""
from decimal import Decimal as D
from types import SimpleNamespace as NS
import unittest

from combat_sim.knock_motion import KnockMotion
from combat_sim.mobile_combat import MovingCombatRules


class World:
    precision=50
    time=D(100)
    contact_repeat_ms=D(1)
    def __init__(self,velocities=None,groups=()):
        self.velocities=velocities or {'A':(3,2,0),'B':(1,-2,0),'C':(0,0,0)}
        self.fighters={n:NS(profile={'max_hp':1000},armor=0,life_generation=1) for n in self.velocities}
        self.grapple_links=NS(group=lambda n:next((g for g in groups if n in g),(n,)))
        self.collider_system=NS(registry=NS(objects={'wall':NS(collision_revision=0)}))
        self.records=[]
    def mobile_motion(self,n):return tuple(map(D,self.velocities[n])),(D(0),)*3
    def log(self,kind,**kw):self.records.append((kind,kw))


PAIR={'first':'A','second':'B','normals':[(-1,0,0)]}
WALL={'first':'A','second':'wall','normals':[(-1,0,0)]}


def elastic(w):
    k=KnockMotion(w)
    k.impulses['probe']={'status':'active','elasticity':D(1),
        'components':{n:{'life_generation':1,'velocity_mps':(0,0,0)} for n in w.fighters}}
    return k


class ReferenceContactTests(unittest.TestCase):
    def test_zero_elasticity_preserves_authored_removal_of_each_own_component(self):
        k=KnockMotion(World());k.contact_frames={'A':(20,0,0)}
        self.assertEqual(k.elastic_response('A',(3,2,0),(0,2,0),basis=((1,0,0),)),(0,2,0))

    def test_static_bounce_reverses_normal_and_preserves_tangent(self):
        k=elastic(World());k.contact_frames=k.rebound_frames([WALL])
        self.assertEqual(k.elastic_response('A',(3,2,0),(0,2,0),basis=((1,0,0),)),(-3,2,0))

    def test_equal_weight_moving_pair_exchanges_normal_speeds(self):
        w=World();k=elastic(w);k.contact_frames=k.rebound_frames([PAIR])
        a=k.elastic_response('A',(3,2,0),(0,2,0),basis=((1,0,0),))
        b=k.elastic_response('B',(1,-2,0),(0,-2,0),basis=((1,0,0),))
        self.assertEqual(a,(1,2,0));self.assertEqual(b,(3,-2,0))
        self.assertEqual(a[0]**2+b[0]**2,3**2+1**2)

    def test_moving_pair_rebound_is_invariant_under_common_translation(self):
        w=World({'A':(13,0,0),'B':(11,0,0)});k=elastic(w);k.contact_frames=k.rebound_frames([PAIR])
        self.assertEqual(k.elastic_response('A',(13,0,0),(0,0,0),basis=((1,0,0),)),(11,0,0))
        self.assertEqual(k.elastic_response('B',(11,0,0),(0,0,0),basis=((1,0,0),)),(13,0,0))

    def test_actual_joint_members_share_the_external_contact_frame(self):
        w=World({'A':(3,0,0),'B':(0,0,0),'C':(3,0,0)},groups=(('A','C'),));k=elastic(w)
        frames=k.rebound_frames([PAIR]);self.assertEqual(set(frames),{'A','B','C'})
        self.assertEqual(set(frames.values()),{(2,0,0)})

    def test_static_contact_fixes_the_entire_contact_component_frame(self):
        w=World();k=elastic(w);self.assertEqual(k.rebound_frames([PAIR,WALL]),{'A':(0,0,0),'B':(0,0,0)})

    def test_pose_contact_does_not_transmit_a_fake_joint_momentum_impulse(self):
        w=World({'A':(3,0,0),'B':(3,0,0)},groups=(('A','B'),))
        self.assertFalse(MovingCombatRules.reference_contact_closing(w,PAIR))
        k=elastic(w);self.assertEqual(k.rebound_frames([dict(PAIR,pose_only=True)]),{})

    def test_separating_reference_contact_preserves_movement_but_approaching_contact_is_physical(self):
        w=World({'A':(-3,0,0),'B':(0,0,0)})
        self.assertFalse(MovingCombatRules.reference_contact_closing(w,WALL))
        w.velocities['A']=(3,0,0);self.assertTrue(MovingCombatRules.reference_contact_closing(w,WALL))

    def test_acceleration_into_a_resting_surface_is_still_a_physical_contact(self):
        w=World({'A':(0,0,0),'B':(0,0,0)})
        w.mobile_motion=lambda n:((D(0),)*3,(D(0),D(0),D('-9.81')))
        self.assertTrue(MovingCombatRules.reference_contact_closing(w,dict(WALL,normals=[(0,0,1)])))

    def test_rapid_repeated_contact_absorbs_only_the_current_joint_normal_response(self):
        w=World(groups=(('A','C'),));k=elastic(w)
        self.assertEqual(k.stabilize_repeats([WALL]),set())
        w.time+=D('.5');k.contact_inelastic=k.stabilize_repeats([WALL])
        self.assertEqual(k.contact_inelastic,{'A','C'});self.assertEqual(k.elasticity('B'),1)
        self.assertEqual(k.elastic_response('A',(3,2,0),(0,2,0),basis=((1,0,0),)),(0,2,0))
        self.assertEqual(w.records[0][0],'body_contact_stabilized')

    def test_contact_window_boundary_new_life_and_new_geometry_do_not_inherit_stabilization(self):
        w=World();k=elastic(w);k.stabilize_repeats([WALL]);w.time+=1
        self.assertEqual(k.stabilize_repeats([WALL]),set())
        w.time+=D('.1');w.fighters['A'].life_generation+=1
        self.assertEqual(k.stabilize_repeats([WALL]),set())
        w.time+=D('.1');w.collider_system.registry.objects['wall'].collision_revision+=1
        self.assertEqual(k.stabilize_repeats([WALL]),set())

    def test_pose_only_query_does_not_start_a_physical_repeat_clock(self):
        w=World();k=elastic(w);k.stabilize_repeats([dict(WALL,pose_only=True)])
        self.assertEqual(k.last_contacts,{})


if __name__=='__main__':unittest.main()
