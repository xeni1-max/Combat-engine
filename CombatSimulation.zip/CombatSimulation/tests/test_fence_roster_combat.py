"""Actual electrical delivery to every authored profile and the shared heat path."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from tests.test_mobile_combat import events
from tests.test_segment_fields_combat import scene as fence_scene,run

RESISTANCE={'1E1':150,'1E2':150,'1E3':150,'1E5':350,'2E4':165,'3E5':250}

def scene(character,*,shield=0,heat=False):
    s=fence_scene(1200 if heat else 1000);s['id']='fence_recipient_'+character
    s['encounter']['participants']['B'].update(character=character,initial_state={'shield':shield})
    if heat:
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(character='1E1',position_m=[0,-24])
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['4'],start_ms=0,reload_when_empty=False)
    return s

class FenceRosterCombatTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def ledger(self,r):
        loss=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        for actor,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=actor)
            self.assertLess(abs(supplied-D(r['final_states'][actor]['hp'])-loss.amount(target=actor)),D('1e-8'))
        return loss

    def test_actual_fence_uses_all_six_authored_body_resistances(self):
        for character,resistance in RESISTANCE.items():
            with self.subTest(character=character):
                r=run(scene(character));loss=self.ledger(r);expected=(D(800)-D(resistance)**2/800)*D('.7')
                self.assertLess(abs(loss.amount(target='B')-expected),D('1e-8'))
                self.assertEqual({e.contribution.kind for e in loss.entries},{'electrocution'})
                self.assertEqual(D(r['segment_field_contacts'][0]['applied_at_ms']),300)
                self.assertEqual(len(r['released_damage_streams']),1)
                self.assertEqual(len(r['binding_instances']),1)
                self.assertEqual(r['run_until_ms'],'1000')

    def test_actual_fence_exhausts_each_shield_before_body_resistance(self):
        for character,resistance in RESISTANCE.items():
            with self.subTest(character=character):
                r=run(scene(character,shield=200));loss=self.ledger(r)
                expected=(D(800)-D(resistance)**2/800)*D('.45')
                self.assertEqual(D(r['final_states']['B']['shield']),0)
                self.assertLess(abs(loss.amount(target='B')-expected),D('1e-8'))
                self.assertEqual(r['segment_field_contacts'][0]['status'],'active')

    def test_actual_fence_and_beam_share_layers_for_every_profile(self):
        for character in RESISTANCE:
            with self.subTest(character=character):
                r=run(scene(character,shield=200,heat=True));loss=self.ledger(r)
                kinds={e.contribution.kind for e in loss.entries if e.target=='B'}
                self.assertEqual(kinds,{'electrocution','heat'})
                self.assertTrue(events(r,'beam_deployed','C'))
                self.assertEqual(len(r['segment_field_contacts']),1)
                self.assertTrue(r['released_damage_streams'][0]['autonomous'])
                self.assertLess(D(r['final_states']['B']['hp']),D(r['initial_states']['B']['hp']))

    def test_repaired_profiles_match_precision_order_and_observation_controls(self):
        for character in ('1E1','3E5'):
            with self.subTest(character=character):
                s=scene(character,shield=200,heat=True);a=run(s,precision=50,interval=None);self.ledger(a)
                s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
                with localcontext(Context(prec=28)):b=run(s,precision=80,interval=17)
                self.ledger(b)
                for name,left in a['final_states'].items():
                    right=b['final_states'][name]
                    for key in ('hp','shield','armor','dyspnea','disorientation','instability'):
                        self.assertLess(abs(D(left[key])-D(right[key])),D('1e-8'))
                    for x,y in zip(left['body_origin_m'],right['body_origin_m']):self.assertLess(abs(D(x)-D(y)),D('1e-8'))
                self.assertEqual(len(a['segment_field_contacts']),len(b['segment_field_contacts']))
                self.assertEqual(len(a['released_damage_streams']),len(b['released_damage_streams']))
