"""Current shared ledges: ordinary traversal plus labelled placement/link probes."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from tests.test_equilibrium_combat import scene as base_scene,run
from tests.test_mobile_combat import read,command,events
from tests.test_world_colliders_combat import wall
from tests.test_climb_combat import climb
from tests.test_grapple_links_combat import force,attach as grapple
from tests.test_impact_bindings_combat import add
from tests.test_binding_combat import run as configured_run


def climb_scene(duration=2000,action='walk'):
    s=base_scene(duration);s['id']='raised_support_traversal'
    s['encounter']['participants']['A']['position_m']=['4.59',0]
    s['action_selection']['A']['start_ms']=100000
    command(s,'A',0,'walk');climb(s,time=0)
    command(s,'A',800,action)
    return s


def platform_scene(duration=300,*,x='20.95',velocity=2,character='1E2',expiry=None):
    s=base_scene(duration,character=character);s['id']='static_support_engineering_probe'
    s['action_selection']['A']['start_ms']=100000
    s['initial_colliders']=[wall('deck',x=20,z='.9',size=('1.8',)*3,hp=2000,climbable=True,duration=expiry)]
    height={'1E5':'2.9375','3E5':'2.71875'}.get(character,'2.675')
    s['spatial_interventions']=[force(0,'A',[velocity,0,0],reference=[x,-20,height])]
    return s


def heavy_scene():
    s=platform_scene(1300,velocity=0)
    add(s,'C',[10,-20],character='3E5',team='B')
    s['encounter']['participants']['C']['facing']='+x'
    s['spatial_interventions'].append(force(0,'C',reference=['19.85',-20,'2.71875']))
    s['action_selection']['C'].update(abilities=['4'],start_ms=20,reload_when_empty=False)
    return s


def native_grab_scene(duration=2400):
    s=platform_scene(duration,x=20,velocity=0,character='1E5')
    s['initial_colliders'][0]['parts'][0]['size_m']=[4,4,'1.8']
    s['spatial_interventions'].append(force(0,'B',reference=['21.1',-20,'2.675']))
    s['action_selection']['A'].update(abilities=['2'],start_ms=20,reload_when_empty=False)
    command(s,'A',700,'walk')
    return s


class TerrainSupportCombatTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=70));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for n,lives in r['actor_lives'].items():
            supply=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=n)
            self.assertLess(abs(supply-D(r['final_states'][n]['hp'])-ledger.amount(target=n)),D('1e-8'))

    def test_review_ordinary_climb_then_walk_reaches_horizon_and_lands(self):
        r=run(climb_scene());self.conserved(r)
        self.assertEqual(r['run_until_ms'],'2000');self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),7)
        self.assertTrue(events(r,'world_support_lost','A'));self.assertTrue(events(r,'jump_landed','A'))
        self.assertFalse(events(r,'jump_takeoff','A'))

    def test_running_leaves_the_same_static_surface_through_native_flight(self):
        s=climb_scene(2000);command(s,'A',900,'run');r=run(s);self.conserved(r)
        self.assertTrue(events(r,'world_support_lost','A'));self.assertEqual(r['metrics']['A']['jumps_started'],0)
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),8)

    def test_stationary_partial_overhang_remains_supported(self):
        r=run(platform_scene(300,velocity=0));self.conserved(r)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'deck')
        self.assertFalse(events(r,'world_support_lost'));self.assertFalse(events(r,'body_contact'))

    def test_forced_departure_preserves_position_and_velocity_without_a_jump_fee(self):
        r=run(platform_scene());self.conserved(r)
        lost=events(r,'world_support_lost','A');self.assertEqual(len(lost),1)
        self.assertAlmostEqual(D(lost[0]['time_ms']),25,places=15)
        self.assertEqual(tuple(map(D,lost[0]['velocity_mps'])),(2,0,0))
        state=r['final_states']['A'];elapsed=(300-D(lost[0]['time_ms']))/1000
        self.assertAlmostEqual(D(state['body_origin_m'][2]),D('2.675')-D('9.81')*elapsed**2/2,places=15)
        self.assertEqual(D(state['position_m'][0]),D('21.55'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0);self.assertFalse(events(r,'jump_takeoff'))

    def test_all_six_scaled_bodies_can_depart_and_use_native_ground_contacts(self):
        for character in ('1E1','1E2','1E3','1E5','2E4','3E5'):
            with self.subTest(character=character):
                s=platform_scene(1400,character=character)
                r=run(s);self.conserved(r)
                self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'ground')
                self.assertTrue(events(r,'world_support_lost','A'))
                self.assertFalse(events(r,'jump_takeoff','A'));self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_adjacent_alternate_top_retains_support_without_fake_fall(self):
        s=platform_scene(700)
        s['initial_colliders'].append(wall('next_deck',x='21.8',z='.9',size=('1.8',)*3,hp=2000))
        r=run(s);self.conserved(r)
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'next_deck')
        self.assertFalse(events(r,'world_support_lost','A'));self.assertFalse(events(r,'jump_landed','A'))
        self.assertAlmostEqual(D(r['final_states']['A']['body_origin_m'][2]),D('2.675'),places=20)

    def test_small_gap_can_be_bridged_by_actual_foot_overlap(self):
        s=platform_scene(700)
        s['initial_colliders'].append(wall('next_deck',x='21.9',z='.9',size=('1.8',)*3,hp=2000))
        r=run(s);self.conserved(r)
        self.assertFalse(events(r,'world_support_lost','A'))
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'next_deck')

    def test_crouch_on_partial_support_retains_actual_feet_contact(self):
        s=platform_scene(600,velocity=0);command(s,'A',0,'crouch');r=run(s);self.conserved(r)
        self.assertEqual(r['metrics']['A']['crouches_completed'],1)
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'deck')
        self.assertFalse(events(r,'world_support_lost','A'))

    def test_support_expiry_at_departure_does_not_release_twice(self):
        s=platform_scene(expiry='24.999999999999999995');r=run(s);self.conserved(r)
        self.assertEqual(len(events(r,'world_support_lost','A')),1)
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])

    def test_basic_jump_then_later_ledge_fall_does_not_repeat_owed_landing_status(self):
        s=platform_scene(2500,x=20,velocity=0)
        command(s,'A',0,'jump');command(s,'A',900,'walk')
        r=run(s);self.conserved(r)
        self.assertEqual(r['metrics']['A']['jumps_started'],1)
        self.assertEqual(len([e for e in events(r,'jump_landed','A') if any(D(x) for x in e['self_effects'].values())]),1)
        self.assertTrue(events(r,'world_support_lost','A'))

    def test_native_heavy_punch_keeps_released_knock_through_terrain_departure(self):
        r=run(heavy_scene());self.conserved(r)
        self.assertTrue(r['knock_impulses']);self.assertTrue(events(r,'world_support_lost','A'))
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),21)
        self.assertTrue(events(r,'jump_landed','A'));self.assertEqual(r['metrics']['A']['jumps_started'],0)

    def test_rigid_grapple_uses_one_gravity_after_both_leave_the_platform(self):
        s=platform_scene(300)
        s['encounter']['participants']['B']['position_m']=[30,-22]
        s['initial_colliders'][0]['parts'][0]['size_m']=['1.8',5,'1.8']
        s['spatial_interventions'].append(force(0,'B',[2,0,0],reference=['20.95',-22,'2.675']))
        s['spatial_interventions'].append(grapple(duration=1000))
        r=run(s);self.conserved(r)
        self.assertEqual(r['grapple_links'][0]['status'],'active')
        for name in ('A','B'):
            self.assertFalse(r['final_states'][name]['locomotion']['grounded'])
            self.assertAlmostEqual(D(r['final_states'][name]['body_origin_m'][2]),D('2.675')-D('9.81')*D('.275')**2/2,places=14)
            self.assertEqual(r['metrics'][name]['jumps_started'],0)

    def test_actual_grab_and_drag_remains_owned_while_the_linked_pair_leaves_terrain(self):
        r=run(native_grab_scene());self.conserved(r)
        self.assertTrue(r['grapple_holds']);self.assertTrue(r['grapple_links'])
        self.assertTrue(any(h['status']=='active' for h in r['grapple_holds']))
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
        self.assertFalse(r['final_states']['B']['locomotion']['grounded'])
        self.assertGreater(D(r['metrics']['B']['continuous_hp_damage_received']),0)
        self.assertEqual(r['metrics']['A']['jumps_started'],0)

    def test_live_distance_constraint_survives_support_loss(self):
        s=platform_scene(300)
        s['initial_colliders'].append(wall('anchor_deck',x=10,z='.9',size=('1.8',)*3,hp=2000))
        s['spatial_interventions'].append(force(0,'B',reference=[10,-20,'2.675']))
        def tether(w):w.distance_constraints.attach('A','B',maximum_m='11.2',expires_at_ms=1000,
            source='terrain_support_tether_probe',expected_lives={'A':1,'B':1})
        r=run(s,operations=((1,tether),));self.conserved(r)
        self.assertTrue(events(r,'world_support_lost','A'));self.assertEqual(r['distance_constraints'][0]['status'],'active')
        self.assertTrue(events(r,'distance_response_started'))
        a,b=(tuple(map(D,r['final_states'][n]['body_origin_m'])) for n in ('A','B'))
        self.assertLessEqual(sum((x-y)**2 for x,y in zip(a,b)),D('11.2')**2+D('1e-18'))

    def test_precision_observations_order_and_ambient_context_keep_departure_outcomes(self):
        s=climb_scene();a=run(s,interval=None)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        with localcontext(Context(prec=28)):b=run(s,precision=80,interval=17)
        self.conserved(a);self.conserved(b)
        self.assertEqual(len(events(a,'world_support_lost')),len(events(b,'world_support_lost')))
        self.assertLess(abs(D(events(a,'world_support_lost','A')[0]['time_ms'])-D(events(b,'world_support_lost','A')[0]['time_ms'])),D('1e-8'))
        for n in a['final_states']:
            for key in ('hp','dyspnea','instability','disorientation'):
                self.assertLess(abs(D(a['final_states'][n][key])-D(b['final_states'][n][key])),D('1e-8'))

    def test_old_selected_rules_keep_their_explicit_raised_departure_guard(self):
        cfg=read('data/movement/combat_locomotion.json');cfg.pop('terrain_support')
        with self.assertRaisesRegex(UnsupportedMechanicError,'Raised-support departure'):
            configured_run(climb_scene(),rules=cfg)


if __name__=='__main__':unittest.main()
