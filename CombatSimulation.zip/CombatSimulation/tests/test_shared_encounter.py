"""Shared-state interaction, numerical, and unsupported-scope regression tests."""
from copy import deepcopy
from decimal import Context, Decimal as D, ROUND_CEILING, ROUND_FLOOR, localcontext
import json
from pathlib import Path
import unittest

from combat_sim.analysis import summarize
from combat_sim.benchmark import run_benchmark_case
from combat_sim.engine import run_scenario
from combat_sim.shared_engine import SharedEncounter, run_shared_scenario
from combat_sim.mechanics.status import mitigate_status
from combat_sim.models import UnsupportedMechanicError

ROOT=Path(__file__).resolve().parents[1]
PROFILES=json.loads((ROOT/'data/characters.json').read_text())['characters']
SCENARIO=json.loads((ROOT/'scenarios/1e1_vs_1e2_shared.json').read_text())


def events(run,kind):return [e for e in run['events'] if e['type']==kind]


def passive_case(ability,shield=4000,horizon=10000):
    s=deepcopy(SCENARIO)
    s['encounter']['duration_ms']=horizon
    if ability=='gun':
        s['action_selection']['caster']['start_ms']=20000
        target='caster'
    else:
        s['action_selection']['gunner']['start_ms']=20000
        s['action_selection']['caster']['abilities']=[ability]
        target='gunner'
    s['encounter']['participants'][target]['initial_state']={'shield':shield}
    return s,target


class SharedEncounterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.run_data=run_shared_scenario(SCENARIO,PROFILES)

    def test_cli_dispatch_and_summary(self):
        run=run_scenario(SCENARIO,PROFILES)
        self.assertEqual(run,self.run_data)
        summary=summarize(run)
        self.assertEqual(set(summary['participants']),{'caster','gunner'})
        self.assertEqual(summary['stop_reason']['kind'],'observation_horizon_reached')
        self.assertEqual(summary['run_until_ms'],'10000')

    def test_both_actors_use_one_clock_and_distinct_state(self):
        r=self.run_data
        self.assertEqual([e['actor'] for e in events(r,'ability_started')[:2]],['caster','gunner'])
        times=[D(e['time_ms']) for e in r['events']]
        self.assertEqual(times,sorted(times))
        self.assertEqual(r['final_states']['caster']['character'],'1E1')
        self.assertEqual(r['final_states']['gunner']['character'],'1E2')
        self.assertLess(D(r['final_states']['caster']['armor']),150)
        self.assertEqual(D(r['final_states']['gunner']['armor']),150)

    def test_first_bullet_extends_gathering_and_cancels_old_transition(self):
        first=events(self.run_data,'gathering_extended')[0]
        self.assertEqual(first['time_ms'],'52')
        self.assertEqual(first['old_active_start_ms'],'180')
        self.assertEqual(first['new_active_start_ms'],'246')
        self.assertEqual(D(first['added_disorientation']),mitigate_status(110,8140,150,0))
        starts=[e for e in events(self.run_data,'active_started') if e['actor']=='caster']
        self.assertEqual(starts[0]['time_ms'],'246')
        self.assertEqual(sum(e['action_id']==starts[0]['action_id'] for e in starts),1)

    def test_active_does_not_gain_new_gathering_and_beam_is_independent(self):
        r=self.run_data
        effects=events(r,'heat_started')
        self.assertEqual(effects[0]['time_ms'],'246')
        self.assertEqual(effects[0]['effect']['leave'],'3246')
        self.assertEqual(events(r,'summoning_active_completed')[0]['time_ms'],'546')
        # A hit at 452 applies O/U during the summoning Active, but does not extend it.
        self.assertTrue(any(e['time_ms']=='452' and e['target']=='caster' for e in events(r,'impact_resolved')))
        releases=[e for e in events(r,'projectile_released') if e['actor']=='caster']
        self.assertLess(D(releases[0]['time_ms']),3246)
        self.assertTrue(any(D(e['applied_shield_damage'])>0 and D(e['interval_end_ms'])>546
                            for e in events(r,'continuous_damage_resolved') if e['target']=='gunner'))

    def test_cooldowns_and_ammo_are_separate_per_actor_and_ability(self):
        r=self.run_data
        beam_starts=[e for e in events(r,'ability_started') if e['actor']=='caster' and e['ability']=='4']
        self.assertEqual([e['time_ms'] for e in beam_starts],['0','9000'])
        releases=[e for e in events(r,'projectile_released') if e['actor']=='gunner']
        self.assertEqual([int(e['time_ms']) for e in releases[:11]],[40+400*i for i in range(11)])
        self.assertEqual([e['ammo'] for e in releases[:11]],list(range(10,-1,-1)))
        self.assertEqual(r['final_states']['gunner']['ammo']['1'],1)
        self.assertEqual(r['final_states']['caster']['ammo'],{})

    def test_reload_overlaps_cooldown_and_incoming_status_changes_later_shot(self):
        r=self.run_data
        reload=events(r,'reload_requested')[0]
        self.assertEqual(reload['time_ms'],'4040')
        self.assertEqual(reload['active_start_ms'],'4221')
        done=events(r,'reload_completed')[0]
        self.assertEqual(done['time_ms'],'6021')
        shot=next(e for e in events(r,'ability_started') if e['actor']=='gunner' and e['time_ms']=='6021')
        self.assertEqual(shot['active_start_ms'],'6074')
        self.assertGreater(D(shot['disorientation_at_start']),0)
        self.assertEqual(int(done['time_ms'])-int(reload['active_start_ms']),1800)

    def test_shield_break_heat_handoff_and_no_shield_bleeds(self):
        r=self.run_data
        hp_start=events(r,'hp_heat_exposure_started')[0]
        self.assertEqual(hp_start['target'],'gunner')
        self.assertEqual(hp_start['exposure_seconds'],0)
        self.assertTrue(D(2900)<D(hp_start['time_ms'])<3000)
        bleeding=events(r,'bleeding_started')
        self.assertEqual(bleeding[0]['time_ms'],'3652')
        self.assertTrue(all(e['effect']['target']=='caster' for e in bleeding))
        firsthit=next(e for e in events(r,'impact_resolved') if e['actor']=='gunner')
        self.assertEqual(D(firsthit['damage_calculation']['applied_hp_damage']),0)
        self.assertEqual(D(firsthit['damage_calculation']['armor_loss']),0)

    def test_state_conservation_and_damage_calculations(self):
        r=self.run_data
        with localcontext(Context(prec=70)):
            for name in ('caster','gunner'):
                initial,final=r['initial_states'][name],r['final_states'][name]
                m=r['metrics'][name]
                lost=D(initial['hp'])-D(final['hp'])
                self.assertLess(abs(lost-D(m['direct_hp_damage_received'])-D(m['continuous_hp_damage_received'])),D('1e-44'))
                self.assertLess(abs(D(initial['shield'])-D(final['shield'])-D(m['shield_damage_received'])),D('1e-44'))
                self.assertGreaterEqual(min(D(final[k]) for k in ('hp','armor','shield','disorientation','instability')),0)
            for hit in events(r,'impact_resolved'):
                c=hit['damage_calculation']
                self.assertEqual(D(c['incoming']),D(c['shield_absorbed'])+D(c['damage_left_after_shield']))
                if hit['actor']=='caster':self.assertEqual(D(c['armor_loss']),0)

    def test_target_status_uses_armor_before_own_hit_loss(self):
        r=self.run_data
        for hit in events(r,'impact_resolved'):
            if hit['actor']!='gunner' or not D(hit['damage_calculation']['armor_loss']):continue
            matching=next(e for e in events(r,'target_status_applied') if e['target']=='caster' and e['time_ms']==hit['time_ms'])
            self.assertEqual(matching['pre_hit_armor'],hit['pre_hit_armor'])
            self.assertEqual(D(matching['additions']['disorientation']),mitigate_status(110,8140,D(hit['pre_hit_armor']),0))

    def test_no_eligible_shield_regeneration_and_loss_history_retained(self):
        r=self.run_data
        self.assertEqual(r['shield_regenerated_total'],0)
        for loss in r['shield_loss_history']:
            self.assertGreaterEqual(D(loss.get('eligible_at_ms',loss.get('eligible_interval_start_ms'))),20000)
        with localcontext(Context(prec=70)):
            for target in ('caster','gunner'):
                total=sum((D(e['amount']) for e in r['shield_loss_history'] if e['target']==target),D(0))
                self.assertLess(abs(total-4000),D('1e-20'))

    def test_pending_actions_and_effects_are_inspectable(self):
        r=self.run_data
        a=r['final_states']['caster']['current_action']
        self.assertEqual(a['phase'],'active')
        self.assertEqual(a['active_end_ms'],'10012')
        self.assertTrue(any(e['type']=='active_completed' and e['time_ms']=='10012' for e in r['pending_events']))
        self.assertTrue(any(e['kind']=='heat' and e['actor']=='caster' for e in r['pending_effects']))
        self.assertTrue(any(e['kind']=='bleeding' for e in r['pending_effects']))

    def test_passive_cases_match_previous_known_benchmarks(self):
        with localcontext(Context(prec=70)):
            for ability,key in [('1','1E1_1'),('4','1E1_4'),('gun','1E2_1')]:
                for shield in (0,4000):
                    s,target=passive_case(ability,shield)
                    run=run_shared_scenario(s,PROFILES)
                    old=run_benchmark_case(PROFILES,key,'1E1',bool(shield))
                    for field,metric in [('hp','final_hp'),('armor','final_armor'),('shield','final_shield')]:
                        self.assertLess(abs(D(run['final_states'][target][field])-D(old['metrics'][metric])),D('1e-20'))

    def test_precision_sampling_context_and_immutability(self):
        before=deepcopy(PROFILES);scenario_before=deepcopy(SCENARIO)
        high=run_shared_scenario(SCENARIO,PROFILES,precision=80)
        alternate=run_shared_scenario(SCENARIO,PROFILES,sample_interval_ms=137)
        with localcontext(Context(prec=90)):
            for trial in (high,alternate):
                for name in ('caster','gunner'):
                    for field in ('hp','armor','shield','disorientation','instability'):
                        self.assertLess(abs(D(self.run_data['final_states'][name][field])-D(trial['final_states'][name][field])),D('1e-20'))
                self.assertEqual([(e['time_ms'],e['actor']) for e in events(trial,'projectile_released')],
                                 [(e['time_ms'],e['actor']) for e in events(self.run_data,'projectile_released')])
        for prec,rounding in [(6,ROUND_FLOOR),(80,ROUND_CEILING)]:
            with localcontext() as ctx:
                ctx.prec=prec;ctx.rounding=rounding
                self.assertEqual(run_shared_scenario(SCENARIO,PROFILES),self.run_data)
        self.assertEqual(PROFILES,before);self.assertEqual(SCENARIO,scenario_before)

    def test_hp_zero_is_observation_stop_with_pending_work(self):
        s=deepcopy(SCENARIO)
        s['encounter']['participants']['caster']['initial_state']={'hp':100,'shield':0}
        r=run_shared_scenario(s,PROFILES)
        self.assertEqual(r['run_until_ms'],'52')
        self.assertEqual(r['stop_reason']['kind'],'hp_zero_observation_stop')
        self.assertEqual(D(r['final_states']['caster']['hp']),0)
        self.assertTrue(r['pending_events'])
        self.assertTrue(all(D(e['time_ms'])<=52 for e in r['events']))
        self.assertNotIn('winner',r)

    def test_continuous_hp_zero_is_located_without_ticks(self):
        s,target=passive_case('4',0,5000)
        s['encounter']['participants'][target]['initial_state']['hp']=100
        r=run_shared_scenario(s,PROFILES)
        self.assertEqual(r['stop_reason']['kind'],'hp_zero_observation_stop')
        with localcontext(Context(prec=80)):
            expected=D(180)+1000*(D(3)*100/(2*875))**(D(2)/3)
            self.assertLess(abs(D(r['run_until_ms'])-expected),D('1e-22'))
        self.assertEqual(D(r['final_states'][target]['hp']),0)
        self.assertTrue(r['stop_reason']['boundary_brackets'])

    def test_residual_shield_break_ends_heat_without_hp_transfer(self):
        s,target=passive_case('4',4000,5000)
        r=run_shared_scenario(s,PROFILES)
        self.assertEqual(len(events(r,'shield_residual_terminated')),1)
        self.assertEqual(D(r['final_states'][target]['hp']),8140)
        self.assertEqual(D(r['final_states'][target]['shield']),0)

    def test_two_profiles_can_have_independent_named_instances(self):
        s=deepcopy(SCENARIO)
        s['encounter']['participants']['caster']['character']='1E2'
        s['action_selection']['caster']['abilities']=['1']
        s['action_selection']['caster']['reload_when_empty']=True
        r=run_shared_scenario(s,PROFILES)
        self.assertEqual(r['final_states']['caster']['ammo'],r['final_states']['gunner']['ammo'])
        self.assertEqual(r['final_states']['caster']['hp'],r['final_states']['gunner']['hp'])
        self.assertEqual(D(r['initial_states']['caster']['hp']),8140)

    def test_same_target_simultaneous_impacts_are_rejected(self):
        s=deepcopy(SCENARIO)
        s['encounter']['participants']['second_gunner']={'character':'1E2','team':'B'}
        s['action_selection']['second_gunner']=deepcopy(s['action_selection']['gunner'])
        with self.assertRaisesRegex(UnsupportedMechanicError,'multiple hits'):
            run_shared_scenario(s,PROFILES)

    def test_phase_transition_tied_to_incoming_hit_is_rejected(self):
        s=deepcopy(SCENARIO)
        s['action_selection']['gunner']['start_ms']=128
        # Bullet releases at168 and arrives exactly at the initial180ms Active start.
        with self.assertRaisesRegex(UnsupportedMechanicError,'incoming hit/phase tie'):
            run_shared_scenario(s,PROFILES)

    def test_successive_hits_extend_same_gathering_without_duplicate_active(self):
        s=deepcopy(SCENARIO)
        s['encounter']['duration_ms']=1000
        s['encounter']['participants']['caster']['initial_state']={'disorientation':500}
        r=run_shared_scenario(s,PROFILES)
        first_action=events(r,'ability_started')[0]['action_id']
        extensions=[e for e in events(r,'gathering_extended') if e['action_id']==first_action]
        self.assertEqual([e['new_active_start_ms'] for e in extensions],['746','812'])
        starts=[e for e in events(r,'active_started') if e['action_id']==first_action]
        self.assertEqual([e['time_ms'] for e in starts],['812'])

    def test_armor_changing_attack_updates_other_actors_ongoing_heat(self):
        s=deepcopy(SCENARIO)
        s['encounter']['duration_ms']=1000
        s['encounter']['participants']['defender']={'character':'1E2','team':'C','initial_state':{'shield':0}}
        s['action_selection']['caster']['abilities']=['4']
        s['action_selection']['caster']['target']='defender'
        s['action_selection']['gunner']['target']='defender'
        s['action_selection']['defender']={'kind':'priority_when_ready','target':'caster','abilities':['1'],'start_ms':20000}
        r=run_shared_scenario(s,PROFILES)
        coefficients=[D(p['coefficient']) for e in events(r,'continuous_damage_resolved') if e['target']=='defender'
                      for p in e['components'] if p['kind']=='heat']
        self.assertGreater(max(coefficients),min(coefficients))
        first=min(coefficients)
        with localcontext(Context(prec=60)):
            first_hit=next(e for e in events(r,'impact_resolved') if e['target']=='defender')
            a=D(first_hit['state_after']['armor'])
            expected=(D(900)**2-(a*a+D(150)**2)/2)/900
            self.assertLess(abs(first-expected),D('1e-44'))

    def test_heat_reads_current_armor_in_shared_state(self):
        s,target=passive_case('4',0,5000)
        with localcontext(Context(prec=60)):
            r=SharedEncounter(s,PROFILES)
            r.time=D(0)
            r.decide('caster')
            r.time=D(180)
            r.active_started({'actor':'caster'})
            original=r.components(D(180),D(1180))[target][0]
            r.fighters[target].armor=D(0)
            changed=r.components(D(180),D(1180))[target][0]
            # Coefficients: 875 at armor150/Rh150; 887.5 at armor0/Rh150.
            self.assertEqual(original['coefficient'],875)
            self.assertEqual(changed['coefficient'],D('887.5'))
            self.assertEqual(changed['amount']/original['amount'],D('887.5')/875)

    def test_unsupported_scope_and_long_regeneration_window_rejected(self):
        for field in ('dyspnea_eligibility','recovery_eligibility','movement'):
            s=deepcopy(SCENARIO);s['scope'][field]='enabled'
            with self.assertRaises(UnsupportedMechanicError):run_shared_scenario(s,PROFILES)
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=20000
        with self.assertRaises(UnsupportedMechanicError):run_shared_scenario(s,PROFILES)
        s=deepcopy(SCENARIO);s['encounter']['teleport']=True
        with self.assertRaises(UnsupportedMechanicError):run_shared_scenario(s,PROFILES)

    def test_initial_zero_hp_and_initial_bounds(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['caster']['initial_state']={'hp':0}
        r=run_shared_scenario(s,PROFILES)
        self.assertEqual(r['run_until_ms'],'0');self.assertEqual(len(events(r,'ability_started')),0)
        for invalid in ({'hp':-1},{'shield':4001},{'instability':-1},{'hp':8141}):
            s=deepcopy(SCENARIO);s['encounter']['participants']['caster']['initial_state']=invalid
            with self.assertRaises(ValueError):run_shared_scenario(s,PROFILES)
