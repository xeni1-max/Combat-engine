"""Shared movement/combat tests, including in-flight target changes."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
from pathlib import Path
import unittest

from combat_sim.mobile_combat import MOBILE_SCOPE
from combat_sim.shared_engine import SharedEncounter, run_shared_scenario
from combat_sim.mechanics.status import mitigate_status
from combat_sim.models import UnsupportedMechanicError


ROOT = Path(__file__).resolve().parents[1]
def read(path):
    return json.loads((ROOT/path).read_text())

PROFILES = read('data/characters.json')['characters']
BODY = read('data/body_hitboxes.json')
TERRAIN = read('data/terrain/stationary_arena.json')
MOVEMENT = read('data/movement/walk_run.json')
# These fixtures specify the pre-ownership exclusive action timeline. New
# owned-action tests use current root rules explicitly; keep historical phase
# and numerical expectations tied to the rule version they were written for.
EFFECTS = read('tests/fixtures/combat_locomotion_exclusive_v2.json')


def scenario(horizon=1000, *, fire_at=100000, target=(30,-20)):
    return {'id':'mobile_combat_test','execution_model':'shared_encounter',
        'scope':dict(MOBILE_SCOPE),'terrain_profile':TERRAIN['id'],
        'encounter':{'duration_ms':horizon,'ground_z_m':0,'participants':{
            'A':{'character':'1E2','team':'A','position_m':[0,-20],'facing':'+x','initial_state':{'shield':0}},
            'B':{'character':'1E2','team':'B','position_m':list(target),'facing':'-x','initial_state':{'shield':0}}}},
        'action_selection':{name:{'kind':'priority_when_ready','target':'nearest_living_enemy',
            'abilities':['1'],'reload_when_empty':True,'start_ms':fire_at if name=='A' else 100000}
            for name in ('A','B')},'movement_script':[]}


def command(s, actor, time, action):
    s['movement_script'].append({'actor':actor,'at_ms':time,'action':action})


def run(s, **kwargs):
    return run_shared_scenario(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
        movement_definition=MOVEMENT,combat_locomotion_definition=EFFECTS,**kwargs)


def events(r,kind,actor=None):
    return [e for e in r['events'] if e['type']==kind and (actor is None or e.get('actor')==actor)]


class MovingCombatTests(unittest.TestCase):
    def test_walking_and_resources_advance_together(self):
        s=scenario();command(s,'A',0,'walk')
        s['encounter']['participants']['A']['initial_state']['dyspnea']=50
        r=run(s);f=r['final_states']['A']
        self.assertEqual(D(f['position_m'][0]),D('1.94'))
        self.assertEqual(D(f['dyspnea']),D('21.8'))  # 60 ms Active, then 30/s.
        self.assertEqual(f['locomotion']['mode'],'walking')

    def test_instability_floor_and_expiry_are_continuous_motion_boundaries(self):
        s=scenario();command(s,'A',0,'walk')
        s['encounter']['participants']['A']['initial_state']['instability']=600
        for interval in (None,37,100):
            r=run(s,sample_interval_ms=interval)
            # Actual walking starts at200 ms, reaches2m/s at600 ms.
            self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),D('1.2'),places=30)
            self.assertEqual(D(r['final_states']['A']['instability']),0)

    def test_walk_run_pays_and_applies_self_status_during_transition(self):
        s=scenario(250);command(s,'A',0,'walk');command(s,'A',100,'run')
        r=run(s);f=r['final_states']['A']
        start=events(r,'movement_active_started','A')[1]
        self.assertEqual(D(start['self_effects']['instability']),96)
        self.assertEqual(D(start['self_effects']['disorientation']),96)
        self.assertEqual(D(f['dyspnea']),D('.25'))
        self.assertEqual(D(f['position_m'][0]),D('.74696'))
        self.assertEqual(f['locomotion']['mode'],'running')

    def test_direct_run_intent_uses_walk_then_run(self):
        s=scenario(210);command(s,'A',0,'run')
        r=run(s)
        self.assertEqual([(e['action'],e['time_ms']) for e in events(r,'movement_active_started','A')],
                         [('walk','0'),('run','60')])
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'running')

    def test_running_uses_18_per_second_resource_recovery(self):
        s=scenario(500);command(s,'A',0,'run')
        s['encounter']['participants']['A']['initial_state']['dyspnea']=50
        r=run(s)
        # No free interval between Active phases; transition costs(0.5+0.5)^2=1.
        self.assertEqual(D(r['final_states']['A']['dyspnea']),D('45.78'))

    def test_unaffordable_transition_waits_without_overdrawing(self):
        s=scenario(600);command(s,'A',0,'run')
        s['encounter']['participants']['A']['initial_state']['dyspnea']=100
        r=run(s)
        self.assertTrue(events(r,'movement_waiting_for_capacity'))
        start=next(e for e in events(r,'movement_active_started','A') if e['action']=='run')
        self.assertGreater(D(start['time_ms']),60)
        self.assertTrue(all(0<=D(p['states']['A']['dyspnea'])<=100 for p in r['curve']))

    def test_movement_intent_waits_for_current_weapon_active(self):
        s=scenario(300,fire_at=0);command(s,'A',50,'walk')
        r=run(s)
        release=events(r,'projectile_released','A')[0]
        movement=events(r,'movement_active_started','A')[0]
        self.assertEqual(release['time_ms'],'111')
        self.assertEqual(movement['time_ms'],release['time_ms'])
        self.assertLess(r['events'].index(release),r['events'].index(movement))

    def test_running_weapon_recovery_scales_before_one_ceiling(self):
        s=scenario(500,fire_at=300);command(s,'A',0,'run')
        r=run(s)
        self.assertEqual(D(events(r,'ability_started','A')[0]['recovery_ms']),85)
        self.assertEqual(D(events(r,'self_status_applied','A')[0]['additions']['instability']),162)

    def test_projectile_hits_a_target_that_is_moving_on_shared_clock(self):
        s=scenario(900,fire_at=500);command(s,'B',0,'run')
        r=run(s)
        hit=events(r,'projectile_body_collision')[0]
        self.assertEqual(hit['target'],'B')
        self.assertLess(D(hit['distance_m']),30)
        self.assertLess(D(r['final_states']['B']['hp']),8140)
        self.assertLess(D(r['final_states']['B']['position_m'][0]),27)
        self.assertTrue(events(r,'bleeding_started'))
        self.assertGreater(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_fast_lateral_target_is_missed_without_predictive_aiming(self):
        s=scenario(1500,fire_at=1000,target=(100,-20))
        s['encounter']['participants']['B']['movement_direction']=[0,1]
        command(s,'B',0,'run')
        r=run(s)
        self.assertEqual(len(events(r,'projectile_released')),1)
        self.assertFalse(events(r,'projectile_body_collision'))
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        s['movement_script']=[]
        self.assertEqual(len(events(run(s),'projectile_body_collision')),1)

    def test_starting_movement_after_release_changes_a_predicted_hit_to_miss(self):
        s=scenario(450,fire_at=0,target=(200,-20))
        s['encounter']['participants']['B']['movement_direction']=[0,1]
        self.assertEqual(len(events(run(s),'projectile_body_collision')),1)
        command(s,'B',120,'walk')
        r=run(s)
        self.assertEqual(events(r,'projectile_released')[0]['time_ms'],'111')
        self.assertFalse(events(r,'projectile_body_collision'))

    def test_stopping_after_release_changes_a_miss_to_hit(self):
        s=scenario(450,fire_at=0,target=(200,-20))
        s['encounter']['participants']['B']['movement_direction']=[0,1]
        command(s,'B',0,'walk')
        self.assertFalse(events(run(s),'projectile_body_collision'))
        command(s,'B',120,'stop')
        r=run(s)
        self.assertEqual(len(events(r,'projectile_body_collision')),1)
        self.assertEqual(D(events(r,'special_stop_started')[0]['slide_distance_m']),0)

    def test_cube_contact_applies_status_once_and_stops_normal_motion(self):
        s=scenario(2000);s['encounter']['participants']['A']['position_m']=[0,0]
        command(s,'A',0,'run')
        r=run(s,sample_interval_ms=None)
        self.assertEqual(len(events(r,'body_contact')),1)
        self.assertEqual(D(events(r,'body_contact')[0]['raw_status']),384)
        self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),D('4.95'),places=25)
        self.assertEqual(D(r['final_states']['A']['locomotion']['speed_mps']),0)

    def test_glancing_contact_preserves_tangential_motion(self):
        s=scenario(5000);a=s['encounter']['participants']['A']
        a['position_m']=[0,-4.95];a['movement_direction']=[1,1]
        command(s,'A',0,'walk')
        r=run(s,sample_interval_ms=None)
        self.assertEqual(len(events(r,'body_contact')),1)
        f=r['final_states']['A']
        self.assertAlmostEqual(D(f['position_m'][0]),D('4.95'),places=25)
        self.assertGreater(D(f['position_m'][1]),0)
        self.assertGreater(D(f['locomotion']['velocity_mps'][1]),0)

    def test_character_collision_uses_full_relative_speed_once_per_body(self):
        s=scenario(3500);command(s,'A',0,'run');command(s,'B',0,'run')
        r=run(s,sample_interval_ms=None)
        contact=events(r,'body_contact')
        self.assertEqual(len(contact),1)
        self.assertEqual(D(contact[0]['raw_status']),768)
        self.assertEqual({e['target'] for e in events(r,'target_status_applied')},{'A','B'})
        self.assertTrue(all(D(f['locomotion']['speed_mps'])==0 for f in r['final_states'].values()))

    def test_no_enemy_or_sample_events_still_resolve_contact_and_reach_horizon(self):
        s=scenario(4000);s['encounter']['participants']['A']['position_m']=[0,0]
        s['encounter']['participants']['B']['team']='A'
        command(s,'A',0,'walk')
        r=run(s,sample_interval_ms=None)
        self.assertEqual(D(r['run_until_ms']),4000)
        self.assertEqual(len(events(r,'body_contact')),1)
        self.assertFalse(any(e['type']=='movement_contact' for e in r['pending_events']))

    def test_death_cancels_movement_and_later_intents(self):
        s=scenario(800,fire_at=0)
        s['encounter']['participants']['B']['initial_state']['hp']=1
        command(s,'B',0,'walk');command(s,'B',500,'run')
        r=run(s)
        self.assertFalse(r['final_states']['B']['alive'])
        self.assertEqual(D(r['final_states']['B']['locomotion']['speed_mps']),0)
        self.assertTrue(events(r,'movement_intent_rejected','B'))
        death=events(r,'character_died','B')[0]
        self.assertEqual(death['state']['position_m'],r['final_states']['B']['position_m'])

    def test_observations_precision_and_actor_order_do_not_change_outcomes(self):
        s=scenario(1200,fire_at=500);command(s,'B',0,'run');command(s,'B',900,'stop')
        baseline=run(s,sample_interval_ms=None)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        for precision,interval in ((50,37),(80,113)):
            r=run(s,precision=precision,sample_interval_ms=interval)
            self.assertEqual(len(events(r,'projectile_body_collision')),len(events(baseline,'projectile_body_collision')))
            for name in ('A','B'):
                for field in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertAlmostEqual(D(r['final_states'][name][field]),D(baseline['final_states'][name][field]),places=20)
                for x,y in zip(r['final_states'][name]['position_m'],baseline['final_states'][name]['position_m']):
                    self.assertAlmostEqual(D(x),D(y),places=20)

    def test_simultaneous_body_contacts_mitigate_each_incoming_effect(self):
        s=scenario()
        actors=s['encounter']['participants']
        actors['B']['position_m']=[-.3,-20];actors['B']['facing']='+x'
        actors['C']=deepcopy(actors['B']);actors['C']['position_m']=[.3,-20];actors['C']['facing']='-x'
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        with localcontext(Context(prec=50)):
            engine=SharedEncounter(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=EFFECTS)
            for name in ('B','C'):
                engine.motion[name].update(speed=D(2),mode='walking')
            at,contacts=engine.next_mobile_contacts(D(1))
            self.assertEqual(at,0)
            engine.resolve_mobile_contacts(contacts)
            expected=2*mitigate_status(120,8140,150,0)
            self.assertEqual(engine.fighters['A'].instability,expected)

    def test_unsupported_payment_anchor_is_not_silently_ignored(self):
        definition=deepcopy(EFFECTS)
        definition['dyspnea_payment_timing']='active_end'
        with self.assertRaises(UnsupportedMechanicError):
            run_shared_scenario(scenario(),PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=definition)

    def test_full_duel_has_no_repeated_resting_contacts_at_higher_precision(self):
        s=read('scenarios/moving_gun_duel.json')
        baseline=run(s,sample_interval_ms=None)
        r=run(s,precision=80,sample_interval_ms=137)
        self.assertEqual(D(r['run_until_ms']),5000)
        self.assertEqual(len(events(r,'body_contact')),1)
        for name in ('A','B'):
            self.assertAlmostEqual(D(r['final_states'][name]['hp']),
                                   D(baseline['final_states'][name]['hp']),places=20)


if __name__=='__main__':
    unittest.main()
