"""Narrow migration of historical expectations for the reviewed F5 snapshot bug."""
from copy import deepcopy


def with_correct_initial_hands(saved_result,profiles):
    """Keep every old result field except aliased initial hand coordinates.

    The old result files remain evidence of the defect. Expected initial hands
    come from their own frozen profile, never the current engine's output.
    Events, observations, calculations and final state still compare in full.
    """
    expected=deepcopy(saved_result)
    for state in expected['initial_states'].values():
        if 'hands_m' in state:
            state['hands_m']=deepcopy(profiles[state['character']]['initial_hand_positions_m'])
    return expected
