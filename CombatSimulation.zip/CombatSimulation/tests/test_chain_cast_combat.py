"""Actual damage-free chain casts, spatial binding/Break and shared interactions."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.binding import escape_work
from tests.test_saved_body_paths_combat import scene as base_scene
from tests.test_binding_combat import run,read,control
from tests.test_mobile_combat import events,command
from tests.test_grapple_links_combat import force,pos,vel
from tests.test_world_colliders_combat import wall


def scene(duration=1500,distance=10):
    s=base_scene(duration);s['id']='actual_chain_cast'
    s['encounter']['participants']['A']['character']='3E5'
    s['encounter']['participants']['B']['position_m']=[distance,-20]
    s['action_selection']['A'].update(abilities=['2'],reload_when_empty=False,start_ms=0)
    return s


def heavy_scene(*,held=False):
    s=scene(2200)
    s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
    s['encounter']['participants']['C'].update(position_m=['8.9','-20.45'])
    s['action_selection']['C']=dict(s['action_selection']['A'],abilities=['4'],start_ms=1000)
    if held:
        s['encounter']['participants']['D']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['D'].update(character='1E5',position_m=['11.1',-20],facing='-x')
        s['action_selection']['D']=dict(s['action_selection']['A'],abilities=['2'],start_ms=1000)
    return s


class ChainCastCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=70));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-damage.amount(target=name)),D('1e-8'))
        return damage

    def test_real_throw_cost_clock_status_and_damage_free_binding(self):
        r=run(scene());b=r['binding_instances'][0]
        self.assertEqual([D(e['time_ms']) for e in events(r,'projectile_released')],[400])
        self.assertEqual([D(e['time_ms']) for e in events(r,'self_status_applied')],[290])
        payment=events(r,'dyspnea_paid')[0]
        self.assertEqual((D(payment['time_ms']),D(payment['amount'])),(400,D('12.25')))
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['2']),9400)
        self.assertEqual((b['kind'],D(b['binding_value']),D(b['maximum_m'])),('distance',6,20))
        self.assertEqual(D(b['expiry_ms'])-D(b['started_at_ms']),15000)
        self.assertEqual(D(b['escape_work_required']),escape_work(6,b['maximum_hp']))
        self.assertEqual(self.conserved(r).amount(),0)
        self.assertEqual(D(r['final_states']['B']['armor']),D(read('data/characters.json')['characters']['1E2']['base_armor']))

    def test_personal_shield_does_not_stop_a_damage_free_body_attachment(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['shield']=4000
        r=run(s);self.assertEqual(len(r['binding_instances']),1)
        self.assertEqual(D(r['final_states']['B']['shield']),4000);self.assertEqual(self.conserved(r).amount(),0)

    def test_independent_block_intercepts_without_damage_or_attachment(self):
        s=scene();s['encounter']['participants']['B']['character']='2E4'
        s['action_selection']['B'].update(abilities=['basic_8'],held_blocks=['basic_8'],start_ms=550)
        r=run(s);self.assertTrue(events(r,'binding_projectile_blocked'))
        self.assertFalse(r['binding_instances']);self.assertFalse(events(r,'block_layer_damage'))
        self.assertEqual(self.conserved(r).amount(),0)

    def test_terrain_intercepts_without_fake_hp_damage(self):
        s=scene();s['initial_colliders']=[wall('chain_wall',x=5,hp=1000)]
        r=run(s);self.assertTrue(events(r,'projectile_terrain_collision'))
        self.assertFalse(r['binding_instances']);self.assertEqual(self.conserved(r).amount(),0)

    def test_friendly_interception_uses_the_actual_first_body(self):
        s=scene();s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(character='1E2',position_m=[5,-20])
        s['action_selection']['C']=dict(s['action_selection']['B'])
        r=run(s);self.assertEqual(r['binding_instances'][0]['target'],'C');self.assertEqual(self.conserved(r).amount(),0)

    def test_chain_ends_at_the_live_moving_anchor_limit(self):
        r=run(scene(distance=30));self.assertFalse(r['binding_instances'])
        self.assertEqual(len(events(r,'projectile_range_ended')),1)
        self.assertFalse(events(r,'projectile_body_collision'));self.assertEqual(self.conserved(r).amount(),0)

    def test_moving_caster_can_reach_target_beyond_initial_twenty_metres(self):
        s=scene(1800,distance=25);command(s,'A',0,'run')
        r=run(s);self.assertEqual(len(r['binding_instances']),1)
        self.assertFalse(events(r,'projectile_range_ended'));self.conserved(r)

    def test_retreating_anchor_limits_a_previously_near_target(self):
        s=scene(1800,distance=17);s['encounter']['participants']['A']['movement_direction']=[-1,0];command(s,'A',0,'run')
        r=run(s);self.assertFalse(r['binding_instances']);self.assertTrue(events(r,'projectile_range_ended'))

    def test_range_is_independent_of_observation_schedule_and_precision(self):
        for distance in (30,150):
            a=run(scene(distance=distance));b=run(scene(distance=distance),interval=17,precision=80)
            self.assertEqual([e['time_ms'] for e in events(a,'projectile_range_ended')],[e['time_ms'] for e in events(b,'projectile_range_ended')])

    def test_ballistically_unreachable_opponent_causes_a_paid_range_limited_miss(self):
        r=run(scene(distance=150));self.assertFalse(r['binding_instances'])
        self.assertTrue(events(r,'projectile_range_ended'));self.assertFalse(events(r,'projectile_body_collision'))
        launch=events(r,'projectile_released')[0]
        self.assertEqual(launch['aim_solver']['range_limited_aim']['rule'],'algebraically_unreachable_target_range_proxy')
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('12.25'));self.conserved(r)

    def test_physical_contact_wins_a_same_quantum_flight_limit(self):
        s=scene();base=run(s);release=events(base,'projectile_released')[0]
        contact=events(base,'projectile_body_collision')[0]
        quantum=D(read('data/physics/projectile_gravity.json')['event_quantum_ms'])
        seconds=(D(contact['time_ms'])-D(release['time_ms'])-quantum/2)/1000
        point=[D(str(p))+D(str(v))*seconds for p,v in zip(release['origin_m'],release['initial_velocity_mps'])]
        point[2]-=D('9.81')*seconds*seconds/2
        anchor=(D(0),D(-20),D('.875'))
        profiles=read('data/characters.json')['characters']
        # A numerical length control places extension in the same contact tick;
        # the authored runtime value remains 20 m.
        profiles['3E5']['abilities']['2']['binding']['maximum_m']=str(sum((p-a)**2 for p,a in zip(point,anchor)).sqrt())
        r=run(s,profiles=profiles)
        self.assertEqual(len(events(r,'projectile_body_collision')),1)
        self.assertFalse(events(r,'projectile_range_ended'));self.conserved(r)

    def test_common_break_releases_the_actual_spatial_binding(self):
        s=scene(5000);control(s,900,command='break_binding')
        r=run(s);b=r['binding_instances'][0]
        self.assertEqual(b['end_reason'],'break_escaped')
        self.assertEqual(r['distance_constraints'][0]['end_reason'],'break_escaped')
        self.assertEqual(b['ended_at_ms'],r['distance_constraints'][0]['ended_at_ms'])
        self.assertEqual(D(b['escape_work_done']),escape_work(6,b['maximum_hp']));self.conserved(r)

    def test_two_actual_casts_keep_independent_expiry_and_no_global_exclusivity(self):
        r=run(scene(16000));bindings=r['binding_instances']
        self.assertEqual(len(bindings),2);self.assertEqual(bindings[0]['end_reason'],'duration_expired')
        self.assertEqual(bindings[1]['status'],'active');self.assertEqual(r['distance_constraints'][0]['status'],'ended')
        self.assertEqual(r['distance_constraints'][1]['status'],'active');self.conserved(r)

    def test_cast_hand_is_available_while_the_binding_remains(self):
        s=scene(1500);s['action_selection']['A']['abilities']=['2','4']
        r=run(s);self.assertTrue(any(e['ability']=='4' and D(e['time_ms'])>=400 for e in events(r,'ability_started')))
        self.assertEqual(r['binding_instances'][0]['status'],'active');self.conserved(r)

    def test_actual_heavy_punch_transmits_through_the_actual_chain(self):
        r=run(heavy_scene());self.assertTrue(r['binding_instances']);self.assertTrue(r['knock_impulses'])
        self.assertGreater(r['distance_path_steps_planned'],0);self.assertGreater(pos(r,'A')[0],0)
        self.assertLessEqual(sum((x-y)**2 for x,y in zip(pos(r,'A'),pos(r,'B'))),400+D('1e-18'));self.conserved(r)

    def test_real_hold_and_chain_keep_the_author_grapple_resistance_group(self):
        r=run(heavy_scene(held=True));knock=r['knock_impulses'][0]
        self.assertEqual(knock['assessment']['actors'],['B','D'])
        profiles=read('data/characters.json')['characters']
        self.assertEqual(D(knock['assessment']['maximum_hp_sum']),D(profiles['1E2']['max_hp'])+D(profiles['1E5']['max_hp']))
        self.assertTrue(r['binding_instances']);self.assertTrue(r['grapple_holds']);self.conserved(r)

    def test_death_before_payment_cancels_throw_without_cost(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        r=run(scene(),operations=((350,kill),))
        self.assertFalse(events(r,'projectile_released'));self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_released_projectile_survives_source_death_but_cannot_bind_dead_anchor(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        r=run(scene(),operations=((450,kill),))
        self.assertTrue(events(r,'projectile_body_collision'));self.assertFalse(r['binding_instances'])
        self.assertEqual(events(r,'binding_contact_resolved')[0]['result'],'anchor_life_ended')

    def test_source_death_ends_existing_binding_and_distance_together(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        r=run(scene(),operations=((900,kill),))
        self.assertEqual(r['binding_instances'][0]['end_reason'],'anchor_life_ended')
        self.assertEqual(r['distance_constraints'][0]['ended_at_ms'],'900')

    def test_revived_source_cannot_become_an_old_projectiles_anchor(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        def revive(w):self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='engineering:chain_life'))
        r=run(scene(1000),operations=((450,kill),(600,revive)))
        self.assertEqual(r['final_states']['A']['life_generation'],2);self.assertFalse(r['binding_instances'])

    def test_external_separation_releases_break_and_constraint_together(self):
        s=scene(1200);control(s,800,command='break_binding')
        s['spatial_interventions']=[force(900,'B',reference=[40,-20,'.875'])]
        r=run(s);self.assertEqual(r['binding_instances'][0]['end_reason'],'external_separation')
        self.assertEqual(r['binding_break_attempts'][0]['end_reason'],'external_separation')
        self.assertEqual(r['distance_constraints'][0]['end_reason'],'external_separation')

    def test_outside_range_attachment_is_not_partially_created(self):
        s=scene(distance=30)
        def probe(w):
            p={'actor':'A','ability':'2','action_id':999,'source_life_generation':1,'target':'B','target_life_generation':1}
            self.assertIsNone(w.bindings.create(p,kind='distance',value=6,duration_ms=1000,maximum_m=20))
            self.assertFalse(w.bindings.bindings);self.assertFalse(w.distance_constraints.rows)
        run(s,operations=((0,probe),))

    def test_actual_gun_kills_source_after_release_without_cancelling_flight(self):
        s=scene();s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=400
        r=run(s);self.assertEqual(D(r['final_states']['A']['hp']),0)
        self.assertTrue(any(e['actor']=='A' for e in events(r,'projectile_body_collision')))
        self.assertEqual(events(r,'binding_contact_resolved')[0]['result'],'anchor_life_ended');self.conserved(r)

    def test_actual_recipient_revives_without_inheriting_the_chain(self):
        s=scene(4000,distance='1.1');s['encounter']['participants']['B']['character']='2E4'
        s['encounter']['participants']['B']['initial_state']['hp']=1
        s['action_selection']['B'].update(abilities=['1'],start_ms=0,reload_when_empty=False)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(character='1E2',position_m=[4,-20],facing='-x')
        s['action_selection']['C']=dict(s['action_selection']['A'],abilities=['1'],start_ms=900)
        r=run(s);self.assertTrue(events(r,'life_restored'))
        self.assertGreaterEqual(r['final_states']['B']['life_generation'],2)
        self.assertEqual(r['binding_instances'][0]['end_reason'],'recipient_life_ended')
        self.assertEqual(r['distance_constraints'][0]['status'],'ended');self.conserved(r)

    def test_upper_body_restriction_cancels_unpaid_throw_only(self):
        def restrict(w):w.apply_action_restriction('A',source='engineering:chain_restriction',functions=['upper_body'],until_ms=2000)
        r=run(scene(1000),operations=((350,restrict),))
        self.assertFalse(events(r,'projectile_released'));self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_body_edge_contact_outside_reference_length_does_not_overstretch(self):
        r=run(scene(distance='20.1'))
        self.assertTrue(events(r,'projectile_body_collision'));self.assertFalse(r['binding_instances'])
        self.assertEqual(events(r,'binding_contact_resolved')[0]['result'],'outside_maximum_distance');self.conserved(r)

    def test_actual_target_death_before_arrival_removes_its_hitboxes(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['hp']=1
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(character='1E2',position_m=[10,-10])
        s['action_selection']['C']=dict(s['action_selection']['A'],abilities=['1'],start_ms=450)
        r=run(s);self.assertEqual(D(r['final_states']['B']['hp']),0)
        self.assertFalse(r['binding_instances']);self.conserved(r)

    def test_actual_gunfire_pauses_common_break_on_the_chain(self):
        s=scene(6000);control(s,900,command='break_binding')
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(character='1E2',position_m=[10,-10])
        s['action_selection']['C']=dict(s['action_selection']['A'],abilities=['1'],start_ms=2000)
        r=run(s);self.assertTrue(any(e['attempt']['status']=='paused_disorientation' for e in events(r,'binding_break_state')))
        b=r['binding_instances'][0]
        if b.get('end_reason')=='break_escaped':self.assertGreater(D(b['ended_at_ms']),900+D(b['escape_work_required'])*50)
        self.conserved(r)

    def test_released_range_binding_and_status_payload_ignore_later_profile_changes(self):
        profiles=read('data/characters.json')['characters']
        def revise(w):
            ability=w.fighters['A'].profile['abilities']['2']
            ability['binding'].update(maximum_m=100,binding_value=1,duration_ms=1)
            ability['target_effects'].update(disorientation=0,instability=0)
        r=run(scene(),profiles=profiles,operations=((500,revise),))
        b=r['binding_instances'][0]
        self.assertEqual((D(b['maximum_m']),D(b['binding_value'])),(20,6))
        self.assertEqual(D(b['expiry_ms'])-D(b['started_at_ms']),15000)
        self.assertTrue(any(D(e['status_additions']['instability'])>0 for e in events(r,'impact_batch_resolved')))
        far=run(scene(distance=30),profiles=read('data/characters.json')['characters'],operations=((500,revise),))
        self.assertTrue(events(far,'projectile_range_ended'));self.assertFalse(far['binding_instances'])

    def test_projectile_copy_retains_the_released_contact_and_range_payload(self):
        def copy(w):self.assertIsNotNone(w.projectile_system.copy('projectile:1',source='engineering:chain_copy',offset_m=(0,1,0)))
        r=run(scene(distance=30),operations=((500,copy),))
        self.assertEqual(len(events(r,'projectile_copied')),1)
        self.assertEqual(len(events(r,'projectile_range_ended')),2)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('12.25'));self.conserved(r)


if __name__=='__main__':unittest.main()
