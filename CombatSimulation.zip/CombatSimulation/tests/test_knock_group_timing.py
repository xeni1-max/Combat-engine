"""The author's impact membership rule also applies to the existing 1E5 hold."""
from decimal import Context,Decimal as D,localcontext
import unittest

from tests.test_grapple_casts_combat import scene
from tests.test_equilibrium_combat import run
from tests.test_impact_bindings_combat import add
from tests.test_mobile_combat import events,PROFILES
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory


class KnockGroupTimingTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def result(self):
        s=scene(1500);add(s,'C',[0,'-21.2'],team='B')
        s['encounter']['participants']['C'].update(character='3E5',facing='-x')
        s['action_selection']['C'].update(abilities=['4'],start_ms=400,reload_when_empty=False)
        r=run(s);damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for n,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=n)
            self.assertLess(abs(supplied-D(r['final_states'][n]['hp'])-damage.amount(target=n)),D('1e-8'))
        return r

    def test_existing_hold_receives_joint_knock_before_the_same_hit_causes_fatigue(self):
        r=self.result();knock=events(r,'knock_applied')[0]
        self.assertEqual(knock['assessment']['actors'],['A','B']);self.assertEqual(set(knock['components']),{'A','B'})
        self.assertEqual(D(knock['assessment']['maximum_hp_sum']),D(PROFILES['1E5']['max_hp'])+D(PROFILES['2E4']['max_hp']))
        self.assertEqual(D(knock['assessment']['armor_sum']),D(PROFILES['1E5']['base_armor'])+D(PROFILES['2E4']['base_armor']))
        self.assertEqual(r['grapple_holds'][0]['end_reason'],'controller_exhausted')
        kinds=[e['type'] for e in r['events']]
        self.assertLess(kinds.index('knock_applied'),kinds.index('grapple_holding_ended'))

    def test_released_components_keep_both_lives_through_hold_release_and_expiry(self):
        r=self.result();force=r['knock_impulses'][0]
        self.assertEqual(force['status'],'ended')
        self.assertEqual({c['actor'] for c in force['retired_components']},{'A','B'})
        self.assertTrue(all(c['life_generation']==1 for c in force['retired_components']))
        self.assertEqual(D(force['ended_at_ms']),D(force['started_at_ms'])+500)
