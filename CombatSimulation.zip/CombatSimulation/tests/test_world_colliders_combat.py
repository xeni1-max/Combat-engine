"""Fixed world entities interact with real shared actions, flights and bodies.

Initial barriers are scenario geometry. Scripted API changes are engineering
fixtures, not claims that the corresponding character abilities are cast.

These numerical/phase contracts select the pre-equilibrium rules explicitly.
Current selected-rule interactions are covered in test_equilibrium_interactions.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from combat_sim.analysis import summarize
from combat_sim.world_colliders import ColliderPolicy
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events, read, scenario
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_projectile_entities_combat import one_shot_profiles

CURRENT=read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json')


def wall(name='gate',*,x=10,hp=500,duration=None,blocking=None,climbable=False,size=('.2',4,3),z='1.5'):
    return {'id':name,'source':'scenario_barrier','hp':hp,'duration_ms':duration,'climbable':climbable,
        'blocking':blocking or {'projectiles':True,'bodies':True,'areas':False},
        'parts':[{'part':'panel','centre_m':[x,-20,z],'size_m':list(size)}]}


def platform(name='platform'):
    return wall(name,x=2,hp=None,climbable=True,size=('1.8','1.8','1.8'),z='.9')


def shell():
    obj=wall('shell',hp=4000,blocking={'projectiles':True,'bodies':True,'areas':True})
    obj['parts']=[{'part':name,'centre_m':list(centre),'size_m':list(size)} for name,centre,size in (
        ('left',(-1.15,-20,1),(.1,2.4,2.4)),('right',(1.15,-20,1),(.1,2.4,2.4)),
        ('front',(0,-21.15,1),(2.4,.1,2.4)),('back',(0,-18.85,1),(2.4,.1,2.4)),
        ('roof',(0,-20,2.15),(2.4,2.4,.1)),('floor',(0,-20,-.15),(2.4,2.4,.1)))]
    return obj


def run(s,*,operations=(),profiles=PROFILES,precision=50,interval=None,effects=CURRENT):
    class Fixture(SharedEncounter):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            for when,operation in operations:self.push(when,'fixture_world',operation)

        def _process(self,kind,p):
            if kind!='fixture_world':return super()._process(kind,p)
            if p['op']=='remove':self.collider_system.remove(p['id'],reason='fixture_removal')
            elif p['op']=='expiry':self.collider_system.set_expiry(p['id'],p['at'])
            elif p['op']=='damage':self.collider_system.damage(p['id'],p['amount'],source='fixture_damage')
            elif p['op']=='reshape':
                parts=tuple(Cuboid(v['part'],v['centre_m'],v['size_m']) for v in p['parts']) if 'parts' in p else None
                policy=ColliderPolicy.from_definition(p['blocking']) if 'blocking' in p else None
                self.collider_system.reshape(p['id'],parts=parts,policy=policy)
            elif p['op']=='spawn':self.collider_system.spawn_definition(p['definition'])
            elif p['op']=='spawn_on_shot':
                shot=next(f for f in self.projectile_flights.values() if f['actor']=='A')
                point=self.mobile_flight_state(shot,self.time)[0]
                self.collider_system.spawn((Cuboid('panel',point,('.2',2,2)),),source='geometry_probe',entity_id='new_gate',hp=1000)
            elif p['op']=='spawn_at_body':
                front=max(box.bounds[1][0] for box in self.world_bodies['A'])
                self.collider_system.spawn((Cuboid('panel',(front+F(1,10),-20,F(3,2)),(F(1,5),4,3)),),
                    source='geometry_probe',entity_id='new_gate')
            elif p['op']=='spawn_landing_deck':
                x=self.fighters['A'].body_origin_m[0]+2
                self.collider_system.spawn((Cuboid('unrelated_high_pillar',(x-D('4.1'),-20,D('.5')),('.2',4,1)),
                    Cuboid('roof',(x,-20,D('.25')),(8,4,'.1'))),source='compound_landing_probe',entity_id='deck')
            elif p['op']=='owned_spawn':
                self.collider_system.spawn((Cuboid('panel',(10,-15,D('1.5')),('.2',2,3)),),
                    source='independent_lifecycle_probe',entity_id='owned',hp=4000,owner='A',ability='1')
            elif p['op']=='copy':
                shot=next(f for f in self.projectile_flights.values() if f['actor']=='A')
                self.projectile_system.copy(shot['id'],source='fixture:copy-field',offset_m=(0,0,0))
            elif p['op']=='area':
                self.log('fixture_area_recipients',recipients=self.body_area_recipients(p['centre'],p['radius'],p['shape']))
            else:raise ValueError('Unknown collider fixture operation')

    with localcontext(Context(prec=precision)):
        return Fixture(s,profiles,precision=precision,sample_interval_ms=interval,body_definition=BODY,
            terrain_definition=TERRAIN,movement_definition=MOVEMENT,combat_locomotion_definition=effects,
            projectile_physics_definition=PHYSICS if s['scope']==GRAVITY_MOBILE_SCOPE else None,
            jump_definition=JUMP,climb_definition=CLIMB).run()


class WorldColliderCombatTests(unittest.TestCase):
    def test_repeated_real_gunfire_destroys_barrier_and_later_shots_hit_body(self):
        s=scenario(1500,fire_at=0,target=(100,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['initial_colliders']=[wall()]
        r=run(s)
        damage=events(r,'world_collider_impact_batch')
        self.assertEqual(len(damage),2)
        self.assertEqual(damage[0]['hp_before'],'500')
        self.assertGreater(D(damage[0]['hp_after']),0)
        self.assertEqual(D(damage[1]['hp_after']),0)
        self.assertEqual(r['world_collider_states']['gate']['status'],'destroyed')
        self.assertEqual(r['scope']['obstacles'],'fixed_compound_colliders')
        self.assertEqual(r['scope']['area_occlusion'],'per_collider_witness_policy')
        self.assertEqual(r['configuration']['scope'],s['scope'])
        summary=summarize(r)
        self.assertEqual(summary['world_colliders']['gate']['status'],'destroyed')
        self.assertEqual(D(summary['world_colliders']['gate']['hp']),0)
        self.assertEqual(D(summary['participants']['A']['hp_damage_received']),0)
        self.assertTrue(events(r,'projectile_body_collision'))
        self.assertLess(D(r['final_states']['B']['hp']),8140)
        self.assertTrue(all(D(e['time_ms'])>D(damage[1]['time_ms']) for e in events(r,'projectile_body_collision')))
        self.assertTrue(all(e['effect']['target']!='gate' for e in events(r,'bleeding_started')))

    def test_simultaneous_shots_share_hp_snapshot_and_all_stop_without_overkill_transmission(self):
        s=scenario(650,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['initial_colliders']=[wall(x=100)]
        r=run(s,profiles=one_shot_profiles(),operations=[(200,{'op':'copy'})])
        batch=events(r,'world_collider_impact_batch')[0]
        self.assertEqual(len(batch['hits']),2)
        self.assertEqual(batch['hp_before'],'500')
        self.assertEqual(batch['applied_hp_damage'],'500')
        self.assertEqual([f['collision_target'] for f in r['projectile_flights']],['gate','gate'])
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_expiry_during_flight_reopens_original_trajectory(self):
        s=scenario(600,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['initial_colliders']=[wall(x=100,hp=4000,duration=200)]
        r=run(s,profiles=one_shot_profiles())
        self.assertEqual(r['world_collider_states']['gate']['status'],'expired')
        self.assertFalse(events(r,'world_collider_damaged'))
        self.assertEqual(events(r,'projectile_body_collision')[0]['target'],'B')

    def test_expiry_at_declared_contact_time_wins_before_the_incoming_batch(self):
        s=scenario(600,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['initial_colliders']=[wall(x=100,hp=4000)]
        contact=events(run(s,profiles=one_shot_profiles()),'projectile_terrain_collision')[0]
        s['initial_colliders'][0]['duration_ms']=contact['time_ms']
        r=run(s,profiles=one_shot_profiles())
        self.assertFalse(events(r,'world_collider_damaged'))
        self.assertEqual(events(r,'projectile_body_collision')[0]['target'],'B')

    def test_new_barrier_intercepts_an_already_released_shot(self):
        s=scenario(600,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        definition=wall(x=100,hp=1000)
        r=run(s,profiles=one_shot_profiles(),operations=[(180,{'op':'spawn','definition':definition})])
        self.assertEqual(events(r,'projectile_terrain_collision')[0]['target'],'gate')
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_projectile_blocking_and_body_blocking_are_independent(self):
        s=scenario(2100,fire_at=0,target=(100,-20));command(s,'A',0,'walk')
        s['initial_colliders']=[wall(x=3,hp=500,blocking={'projectiles':False,'bodies':True,'areas':False})]
        r=run(s)
        self.assertTrue(any(e['second']=='gate' for e in events(r,'body_contact')))
        self.assertLess(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(r['world_collider_states']['gate']['hp'],'500')

    def test_projectile_only_wall_allows_body_to_walk_through(self):
        s=scenario(2500,target=(100,-20));command(s,'A',0,'walk');s['action_selection']['B']['start_ms']=0
        s['initial_colliders']=[wall(x=3,hp=None,blocking={'projectiles':True,'bodies':False,'areas':False})]
        r=run(s,profiles=one_shot_profiles())
        self.assertTrue(events(r,'projectile_terrain_collision','B'))
        self.assertFalse(events(r,'body_contact'))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('4.94'))

    def test_hollow_compound_barrier_contains_body_and_shares_hp_in_both_directions(self):
        s=scenario(350,fire_at=0,target=(100,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['action_selection']['B']['start_ms']=0;s['initial_colliders']=[shell()]
        r=run(s,profiles=one_shot_profiles())
        collisions=events(r,'projectile_terrain_collision')
        self.assertEqual(len(collisions),2)
        self.assertTrue(all(e['target']=='shell' for e in collisions))
        self.assertEqual(len(r['world_collider_states']['shell']['parts']),6)
        self.assertLess(D(r['world_collider_states']['shell']['hp']),4000)
        self.assertEqual(D(r['final_states']['A']['hp']),8140)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_area_cover_blocks_inward_outward_and_downward_paths_until_removal(self):
        s=scenario(500,target=(3,-20));s['initial_colliders']=[shell()]
        ops=[(10,{'op':'area','centre':[3,-20,1],'radius':4,'shape':'sphere'}),
            (20,{'op':'area','centre':[0,-20,1],'radius':4,'shape':'sphere'}),
            (30,{'op':'area','centre':[0,-20,1],'radius':4,'shape':'vertical_cylinder'}),
            (40,{'op':'remove','id':'shell'}),
            (50,{'op':'area','centre':[3,-20,1],'radius':4,'shape':'sphere'})]
        queried=events(run(s,operations=ops),'fixture_area_recipients')
        self.assertEqual([e['recipients'] for e in queried],[['B'],['A'],['B'],['A','B']])

    def test_ordinary_cubes_do_not_suddenly_block_area_queries(self):
        s=scenario(100,target=(8,0));s['encounter']['participants']['A']['position_m']=[0,0]
        r=run(s,operations=[(10,{'op':'area','centre':[5.1,0,1],'radius':4,'shape':'sphere'})])
        self.assertEqual(events(r,'fixture_area_recipients')[0]['recipients'],['B'])

    def test_removing_a_climbed_support_starts_real_fall_while_weapon_finishes(self):
        s=scenario(1600,fire_at=500,target=(100,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['encounter']['participants']['A']['position_m']=[.6,-20];s['initial_colliders']=[platform()]
        s['movement_script']=[{'actor':'A','at_ms':0,'action':'climb','target':'platform'}]
        r=run(s,operations=[(600,{'op':'remove','id':'platform'})])
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertEqual(len(events(r,'world_support_lost','A')),1)
        landed=events(r,'jump_landed','A')[0]
        self.assertEqual(landed['support_id'],'ground')
        self.assertEqual(landed['self_effects'],{'disorientation':'0','instability':'0'})
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)
        self.assertTrue(any(D(e['time_ms'])>600 for e in events(r,'projectile_released','A')))
        self.assertEqual(r['metrics']['A']['jumps_started'],0)

    def test_removing_climb_target_during_active_preserves_path_momentum_and_cancels_completion(self):
        s=scenario(3000,target=(100,-20));s['encounter']['participants']['A']['position_m']=[.6,-20]
        s['initial_colliders']=[platform()]
        s['movement_script']=[{'actor':'A','at_ms':0,'action':'climb','target':'platform'}]
        r=run(s,operations=[(250,{'op':'remove','id':'platform'})])
        self.assertEqual(r['metrics']['A']['climbs_completed'],0)
        self.assertEqual(len(events(r,'climb_interrupted','A')),1)
        self.assertGreater(D(events(r,'climb_interrupted','A')[0]['velocity_before_contact_mps'][2]),0)
        self.assertTrue(events(r,'jump_landed','A'))

    def test_expiring_target_cancels_gathering_without_payment_or_fake_collision(self):
        s=scenario(600);s['encounter']['participants']['A']['position_m']=[.6,-20]
        obj=platform();obj['duration_ms']=100;s['initial_colliders']=[obj]
        s['movement_script']=[{'actor':'A','at_ms':0,'action':'climb','target':'platform'}]
        r=run(s)
        self.assertFalse(events(r,'dyspnea_paid','A'))
        self.assertFalse(events(r,'body_contact'))
        self.assertFalse(events(r,'climb_completed'))
        self.assertFalse(r['final_states']['A']['owned_actions'])

    def test_expiry_refresh_at_completion_does_not_create_support_on_an_expired_target(self):
        s=scenario(1400);s['encounter']['participants']['A']['position_m']=[.6,-20]
        obj=platform();obj['duration_ms']=1000;s['initial_colliders']=[obj]
        s['movement_script']=[{'actor':'A','at_ms':0,'action':'climb','target':'platform'}]
        r=run(s,operations=[(400,{'op':'expiry','id':'platform','at':450})])
        self.assertEqual(r['metrics']['A']['climbs_completed'],0)
        self.assertTrue(events(r,'climb_interrupted','A'))
        self.assertNotEqual(r['final_states']['A']['locomotion']['support_id'],'platform')

    def test_expiry_refresh_ignores_old_clock_and_damage_does_not_cancel_new_clock(self):
        s=scenario(350);s['initial_colliders']=[wall(duration=100,hp=500)]
        r=run(s,operations=[(50,{'op':'expiry','id':'gate','at':250}),(150,{'op':'damage','id':'gate','amount':100})])
        removed=events(r,'world_collider_removed')
        self.assertEqual([e['time_ms'] for e in removed],['250'])
        self.assertEqual(r['world_collider_states']['gate']['hp'],'400')
        self.assertEqual(r['world_collider_states']['gate']['status'],'expired')

    def test_spawning_a_solid_inside_a_body_is_rejected_without_a_fabricated_push(self):
        s=scenario(100);s['initial_colliders']=[wall(x=0)]
        with self.assertRaisesRegex(ValueError,'penetrate'):
            run(s)

    def test_current_collider_mode_is_required_and_ground_cannot_be_removed(self):
        s=scenario(100);s['initial_colliders']=[wall()]
        old=deepcopy(CURRENT);old.pop('world_colliders')
        with self.assertRaisesRegex(UnsupportedMechanicError,'explicit current'):
            run(s,effects=old)
        s.pop('initial_colliders')
        with self.assertRaisesRegex(ValueError,'Permanent ground'):
            run(s,operations=[(10,{'op':'remove','id':'ground'})])

    def test_precision_observations_and_actor_order_preserve_barrier_results(self):
        s=scenario(1500,fire_at=0,target=(100,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['initial_colliders']=[wall()]
        base=run(s)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        for precision,interval in ((50,37),(80,113)):
            r=run(s,precision=precision,interval=interval)
            self.assertEqual(r['world_collider_states']['gate']['status'],base['world_collider_states']['gate']['status'])
            self.assertEqual([(e['time_ms'],e['collider_id']) for e in events(r,'world_collider_impact_batch')],
                [(e['time_ms'],e['collider_id']) for e in events(base,'world_collider_impact_batch')])
            for name in ('A','B'):
                for field in ('hp','armor','dyspnea'):
                    self.assertLess(abs(D(r['final_states'][name][field])-D(base['final_states'][name][field])),D('1e-7'))

    def test_materializing_over_a_shot_resolves_its_initial_overlap_at_the_creation_boundary(self):
        s=scenario(500,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        r=run(s,profiles=one_shot_profiles(),operations=[(180,{'op':'spawn_on_shot'})])
        hit=events(r,'projectile_terrain_collision')[0]
        self.assertEqual((hit['target'],D(hit['time_ms'])),('new_gate',D(180)))
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_materializing_at_a_moving_body_surface_causes_one_actual_contact(self):
        s=scenario(500);command(s,'A',0,'run')
        r=run(s,operations=[(180,{'op':'spawn_at_body'})])
        contact=events(r,'body_contact')
        self.assertEqual(len(contact),1)
        self.assertEqual((contact[0]['second'],D(contact[0]['time_ms'])),('new_gate',D(180)))
        self.assertGreater(D(contact[0]['relative_speed_mps']),0)
        self.assertEqual(D(r['final_states']['A']['locomotion']['speed_mps']),0)

    def test_disabling_projectile_blocking_at_contact_keeps_the_shot_live(self):
        s=scenario(600,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['initial_colliders']=[wall(x=100,hp=1000)]
        baseline=run(s,profiles=one_shot_profiles())
        at=D(events(baseline,'projectile_terrain_collision')[0]['time_ms'])
        r=run(s,profiles=one_shot_profiles(),operations=[(at,{'op':'reshape','id':'gate',
            'blocking':{'projectiles':False,'bodies':True,'areas':False}})])
        self.assertEqual(events(r,'projectile_body_collision')[0]['target'],'B')
        self.assertEqual(r['world_collider_states']['gate']['hp'],'1000')
        self.assertEqual(r['world_collider_states']['gate']['collision_revision'],1)

    def test_reshaping_barrier_changes_later_contact_and_retains_actual_distance(self):
        s=scenario(600,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['initial_colliders']=[wall(x=100,hp=1000)]
        shifted=wall(x=150,hp=1000)
        r=run(s,profiles=one_shot_profiles(),operations=[(200,{'op':'reshape','id':'gate','parts':shifted['parts']})])
        hit=events(r,'projectile_terrain_collision')[0]
        self.assertEqual(hit['collider_revision'],1)
        self.assertGreater(D(hit['distance_m']),149)
        self.assertGreater(D(hit['time_ms']),260)

    def test_compound_support_uses_the_hit_part_instead_of_the_first_parts_height(self):
        s=scenario(1150);command(s,'A',0,'run');command(s,'A',300,'jump')
        r=run(s,operations=[(650,{'op':'spawn_landing_deck'})])
        landed=events(r,'jump_landed','A')[0]
        self.assertEqual(landed['support_id'],'deck')
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),D('.3'))
        self.assertEqual(r['world_collider_states']['deck']['parts'][0]['maximum_m'][2],'1')

    def test_attributed_deployed_collider_survives_its_owners_death(self):
        s=scenario(500);s['action_selection']['B']['start_ms']=0
        s['encounter']['participants']['A']['initial_state']['hp']=1
        r=run(s,profiles=one_shot_profiles(),operations=[(10,{'op':'owned_spawn'})])
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertEqual(r['world_collider_states']['owned']['owner'],'A')
        self.assertEqual(r['world_collider_states']['owned']['status'],'active')

    def test_jump_can_leave_a_raised_support_and_land_on_ground(self):
        s=scenario(2300);s['encounter']['participants']['A']['position_m']=[.6,-20]
        s['initial_colliders']=[platform()]
        s['movement_script']=[{'actor':'A','at_ms':0,'action':'climb','target':'platform'}]
        command(s,'A',600,'run');command(s,'A',820,'jump')
        widened=platform();widened['parts'][0]['size_m']=[10,'1.8','1.8']
        r=run(s,operations=[(500,{'op':'reshape','id':'platform','parts':widened['parts']})])
        self.assertTrue(events(r,'jump_takeoff','A'))
        self.assertEqual(events(r,'jump_landed','A')[0]['support_id'],'ground')
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),7)

    def test_unsupported_live_heat_cover_change_is_atomic_but_terminal_removal_is_a_noop(self):
        with localcontext(Context(prec=50)):
            engine=SharedEncounter(scenario(100),PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,jump_definition=JUMP,climb_definition=CLIMB)
            key=engine.collider_system.spawn((Cuboid('wall',(10,-20,1),(1,2,2)),),source='scope_probe',
                policy=ColliderPolicy(areas=True))
            before=engine.collider_system.registry.record()
            engine.effects.append({'kind':'heat','start':D(0),'leave':D(100)})
            with self.assertRaisesRegex(UnsupportedMechanicError,'volume/exposure'):
                engine.collider_system.remove(key,reason='unimplemented_exposure_change')
            self.assertEqual(engine.collider_system.registry.record(),before)
            engine.effects.clear()
            self.assertTrue(engine.collider_system.remove(key,reason='ordinary_removal'))
            engine.effects.append({'kind':'heat','start':D(0),'leave':D(100)})
            self.assertFalse(engine.collider_system.remove(key,reason='already_terminal'))
