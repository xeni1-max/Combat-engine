from decimal import Decimal as D, Context, localcontext
from fractions import Fraction
import unittest
from combat_sim.mechanics.continuous_numeric import root_integral, root_curve_integral, bleed_integral
from combat_sim.mechanics.slash import bleeding_damage_between
from combat_sim.mechanics.heat import full_exposure_and_recovery_damage


class ContinuousNumericTests(unittest.TestCase):
    def test_known_root_and_full_beam_integrals(self):
        with localcontext(Context(prec=60)):
            self.assertEqual(root_integral(D(3),D(0),D(4),D(2)),D(8))
            self.assertEqual(root_integral(D(3),D(4),D(4),D(2)),D(12))
            got=root_curve_integral(D(875),D(180),D(3180),D(4680),D(0),D(6000),D(2))
            expected=D(2625)*D(3).sqrt()
            self.assertLess(abs(got-expected),D('1e-54'))

    def test_zero_and_reversed_curve_boundaries(self):
        self.assertEqual(root_integral(D(900),D(0),D(0),D(1)),0)
        self.assertEqual(root_curve_integral(D(900),D(180),D(3180),D(4680),D(0),D(100),D(2)),0)
        self.assertEqual(root_curve_integral(D(900),D(180),D(3180),D(4680),D(5000),D(6000),D(2)),0)
        with self.assertRaises(ValueError):root_integral(D(1),D(-1),D(0),D(1))
        with self.assertRaises(ValueError):root_curve_integral(*map(D,[1,0,3,2,0,4,2]))

    def test_small_interval_avoids_cancellation(self):
        with localcontext(Context(prec=80)):
            value=root_integral(D(3),D(4),D(4)+D('1e-65'),D('1e-10'))
            self.assertLess(abs(value-D('6e-10')),D('1e-70'))

    def test_bleed_matches_exact_documented_intervals(self):
        with localcontext(Context(prec=60)):
            for begin,end in [(0,8000),(100,4000),(7000,9000),(9000,10000)]:
                value=bleed_integral(D('412.5'),D(100),D(begin+100),D(end+100))
                exact=bleeding_damage_between(Fraction(825,2),Fraction(begin,1000),Fraction(end,1000))
                self.assertLess(abs(value-D(exact.numerator)/D(exact.denominator)),D('1e-54'))
            self.assertEqual(bleed_integral(D(100),D(0),D(0),D(8000)),10)

    def test_splitting_does_not_change_damage(self):
        with localcontext(Context(prec=80)):
            whole=root_curve_integral(*map(D,[900,180,3180,4680,0,5000,2]))
            pieces=sum((root_curve_integral(*map(D,[900,180,3180,4680,a,b,2])) for a,b in
                        [(0,731),(731,3180),(3180,4001),(4001,5000)]),D(0))
            self.assertLess(abs(whole-pieces),D('1e-70'))

    def test_nonfinite_and_invented_bleed_duration_rejected(self):
        with self.assertRaises(ValueError):root_integral(D('NaN'),D(1),D(1),D(1))
        with self.assertRaises(ValueError):bleed_integral(D(100),D(0),D(0),D(1),D(4000))
