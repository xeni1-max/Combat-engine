"""Origin-to-surface eligibility and constant-speed up/across climb geometry."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import unittest
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.climbing import ClimbPath, surface_distance_squared, within_climb_range

class ClimbGeometryTests(unittest.TestCase):
    def setUp(self):self.box=Cuboid('cube_1',[6,0,.9],[1.8,1.8,1.8])

    def test_exact_half_metre_origin_gap_is_allowed(self):
        self.assertEqual(surface_distance_squared(['4.6',0,'.875'],self.box),F(1,4))
        self.assertTrue(within_climb_range(['4.6',0,'.875'],self.box,'.5'))
        self.assertFalse(within_climb_range(['4.5999',0,'.875'],self.box,'.5'))

    def test_diagonal_distance_is_euclidean(self):
        self.assertEqual(surface_distance_squared(['4.8','-1.3','.875'],self.box),F(1,4))
        self.assertTrue(within_climb_range(['4.8','-1.3','.875'],self.box,'.5'))

    def test_vertical_range_uses_actual_top_surface(self):
        self.assertTrue(within_climb_range([6,0,'2.3'],self.box,'.5'))
        self.assertFalse(within_climb_range([6,0,'2.3001'],self.box,'.5'))

    def test_path_reaches_top_before_moving_to_centre(self):
        p=ClimbPath(['4.6',0,'.875'],self.box,'.875',300)
        self.assertEqual(p.length,D('3.2'))
        self.assertEqual(p.corner_ms,D('168.75'))
        self.assertEqual(p.at(0).position_m,(D('4.6'),0,D('.875')))
        self.assertEqual(p.at(p.corner_ms).position_m,(D('4.6'),0,D('2.675')))
        self.assertEqual(p.at(300).position_m,(6,0,D('2.675')))
        self.assertEqual(p.at(300).velocity_mps,(0,0,0))

    def test_midpoints_have_expected_positions(self):
        p=ClimbPath(['4.6',0,'.875'],self.box,'.875',300)
        self.assertAlmostEqual(p.at(D('84.375')).position_m[2],D('1.775'),places=40)
        self.assertEqual(p.at(D('234.375')).position_m,(D('5.30'),0,D('2.675')))

    def test_path_speed_is_constant_on_both_segments(self):
        p=ClimbPath(['4.6',0,'.875'],self.box,'.875',300)
        with localcontext() as c:
            c.prec=70
            for t in (0,50,150,200,250):
                state=p.at(t);speed=sum(v*v for v in state.velocity_mps).sqrt()
                self.assertLess(abs(speed-p.speed),D('1e-40'))
            self.assertLess(abs(p.speed-D(32)/3),D('1e-40'))

    def test_body_offset_is_supplied_not_hardcoded(self):
        p=ClimbPath(['4.6',0,'.9'],self.box,'.9',300)
        self.assertEqual(p.target[2],D('2.7'))

    def test_precision_is_independent_of_ambient_context(self):
        with localcontext() as c:
            c.prec=7
            p=ClimbPath(['4.6',0,'.875'],self.box,'.875',300)
        other=ClimbPath(['4.6',0,'.875'],self.box,'.875',300)
        self.assertEqual(p.at(100),other.at(100))

    def test_invalid_path_controls_and_queries_are_rejected(self):
        for duration,offset in ((0,'.875'),(300,0)):
            with self.assertRaises(ValueError):ClimbPath(['4.6',0,'.875'],self.box,offset,duration)
        p=ClimbPath(['4.6',0,'.875'],self.box,'.875',300)
        for t in (-1,301):
            with self.assertRaises(ValueError):p.at(t)
