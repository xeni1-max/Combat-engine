"""Consumed healing funding and saved continuous HP rate interfaces."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.damage_ledger import (DamageLedger,DamageContribution,BleedDose,
    AffineHeatDose,QuarticDose,PiecewiseDose,dose_rate,dose_knots,dose_from_record)
from combat_sim.mechanics.healing_allowance import HealingAllowance


def loss(history,time,amount,*,target='A',curve=None,begin=None):
    history.record_loss('loss:'+str(len(history.entries)+1),target,time if begin is None else begin,time,
        (DamageContribution(EffectSource('Enemy','1',1),D(amount),'slash',True,curve),),amount)


class HealingAllowanceTests(unittest.TestCase):
    def setUp(self):
        self.history=DamageLedger();self.allowance=HealingAllowance(self.history)

    def test_initial_deficit_without_real_hp_loss_does_not_fund_healing(self):
        self.history.observe_until(1000)
        q=self.allowance.claim('heal:1','A',1000,500,missing_hp=2000)
        self.assertEqual(q.amount,0)

    def test_actual_incoming_hp_funds_90_percent_once(self):
        loss(self.history,0,100)
        q=self.allowance.claim('heal:1','A',0,60,missing_hp=100)
        self.assertEqual(q.amount,60)
        q=self.allowance.claim('heal:2','A',0,60,missing_hp=100)
        self.assertEqual(q.amount,30)
        self.assertEqual(self.allowance.available('A',0),0)

    def test_healing_cannot_exceed_missing_hp_and_unused_capacity_stays(self):
        loss(self.history,0,100)
        q=self.allowance.claim('heal:1','A',0,200,missing_hp=20)
        self.assertEqual(q.amount,20)
        self.assertEqual(self.allowance.available('A',0),70)

    def test_zero_or_dead_payout_is_still_a_once_only_receipt(self):
        loss(self.history,0,100)
        for receipt,alive,missing in (('full',True,0),('dead',False,100)):
            q=self.allowance.claim(receipt,'A',0,100,missing_hp=missing,alive=alive)
            self.assertEqual(q.amount,0)
            with self.assertRaises(ValueError):self.allowance.claim(receipt,'A',0,100,missing_hp=100)
        self.assertEqual(self.allowance.available('A',0),90)

    def test_spent_funding_does_not_reappear_before_expiry(self):
        loss(self.history,0,100);self.allowance.claim('first','A',0,90,missing_hp=100)
        self.history.observe_until(7999)
        self.assertEqual(self.allowance.available('A',7999),0)

    def test_expired_old_healing_does_not_penalize_new_wounds(self):
        loss(self.history,0,100);self.allowance.claim('first','A',0,30,missing_hp=100)
        self.history.observe_until(8000)
        self.assertEqual(self.allowance.available('A',8000),0)
        loss(self.history,8100,100)
        q=self.allowance.claim('new','A',8100,200,missing_hp=200)
        self.assertEqual(q.amount,90)
        self.assertEqual(q.cursor_base,90)

    def test_old_boundary_expires_exactly_at_eight_seconds(self):
        loss(self.history,100,100);self.history.observe_until(8100)
        self.assertEqual(self.allowance.available('A',D('8099.999')),90)
        self.assertEqual(self.allowance.available('A',8100),0)

    def test_continuous_wounds_expire_using_their_actual_nonlinear_curve(self):
        curve=QuarticDose(0,1000,0,100,(0,100,0,0))
        loss(self.history,1000,100,curve=curve,begin=0);self.history.observe_until(8500)
        self.assertEqual(self.allowance.available('A',8500),D('67.5'))
        self.allowance.claim('late','A',8500,30,missing_hp=100)
        self.history.observe_until(8750)
        self.assertEqual(self.allowance.available('A',8750),D('37.5'))

    def test_quote_and_observation_reads_never_spend(self):
        loss(self.history,0,100);before=self.allowance.record()
        for _ in range(3):
            self.assertEqual(self.allowance.quote('A',0,100,missing_hp=100).amount,90)
        self.assertEqual(self.allowance.record(),before)

    def test_duplicate_foreign_stale_or_past_commits_do_not_mutate(self):
        loss(self.history,0,100);q=self.allowance.quote('A',0,20,missing_hp=100)
        self.allowance.commit('one',q);saved=self.allowance.record()
        foreign=HealingAllowance(self.history).quote('A',0,20,missing_hp=100)
        for receipt,quote in (('one',q),('stale',q),('foreign',foreign)):
            with self.assertRaises(ValueError):self.allowance.commit(receipt,quote)
            self.assertEqual(self.allowance.record(),saved)
        self.history.observe_until(100)
        self.allowance.claim('now','A',100,10,missing_hp=100)
        with self.assertRaises(ValueError):self.allowance.claim('past','A',99,10,missing_hp=100)

    def test_new_same_time_damage_invalidates_an_uncommitted_quote(self):
        loss(self.history,0,100);q=self.allowance.quote('A',0,90,missing_hp=100)
        loss(self.history,0,20)
        with self.assertRaises(ValueError):self.allowance.commit('stale',q)
        self.assertFalse(self.allowance.claims)

    def test_actor_funding_is_separate_and_uses_owned_precision(self):
        loss(self.history,0,100);loss(self.history,0,200,target='B')
        self.assertEqual(self.allowance.available('B',0),180)
        with localcontext(Context(prec=8)):
            q=self.allowance.claim('fraction','A',0,D('0.1234567890123456789'),missing_hp=100)
        self.assertEqual(q.amount,D('0.1234567890123456789'))
        self.assertEqual(self.allowance.available('B',0),180)

    def test_invalid_inputs_do_not_create_funding(self):
        for fraction,window in ((0,8000),(2,8000),('.9',0),('NaN',8000)):
            with self.assertRaises(ValueError):HealingAllowance(self.history,fraction=fraction,window_ms=window)
        self.history.observe_until(100)
        for actor,time,request,missing,alive in (('',100,1,1,True),('A',101,1,1,True),
                ('A',100,-1,1,True),('A',100,1,-1,True),('A',100,1,1,1)):
            with self.assertRaises(ValueError):self.allowance.quote(actor,time,request,missing_hp=missing,alive=alive)
        self.assertFalse(self.allowance.claims)

    def test_continuous_spending_and_expiry_share_one_fifo_cursor(self):
        curve=QuarticDose(0,1000,0,1000,(1000,0,0,0))
        loss(self.history,1000,1000,curve=curve,begin=0);self.history.observe_until(8250)
        q=self.allowance.commit_flow('flow:1','A',8000,8250,5,5,225)
        self.assertEqual(q.amount,5);self.assertEqual(self.allowance.available('A',8250),675)
        self.history.observe_until(8500)
        self.allowance.commit_flow('flow:2','A',8250,8500,5,5,450)
        self.assertEqual(self.allowance.available('A',8500),450)

    def test_invalid_continuous_spending_is_atomic(self):
        loss(self.history,0,100);self.history.observe_until(1000);saved=self.allowance.record()
        for requested,amount,cursor in ((10,20,20),(20,20,10),(200,100,100),(20,20,80)):
            with self.subTest(values=(requested,amount,cursor)),self.assertRaises(ValueError):
                self.allowance.commit_flow('bad','A',0,1000,requested,amount,cursor)
            self.assertEqual(self.allowance.record(),saved)

    def test_a_previously_consumed_continuous_plan_cannot_pay_again(self):
        loss(self.history,0,100);self.history.observe_until(1000)
        self.allowance.commit_flow('once','A',0,1000,40,40,40)
        with self.assertRaises(ValueError):self.allowance.commit_flow('again','A',0,1000,40,40,40)
        self.assertEqual(self.allowance.available('A',1000),50)


class DoseRateTests(unittest.TestCase):
    def test_bleed_and_root_rates_match_the_authored_equations(self):
        self.assertEqual(dose_rate(BleedDose(320,0),1000),7)
        self.assertEqual(dose_rate(BleedDose(320,0),8000),0)
        self.assertEqual(dose_rate(AffineHeatDose(3,4,0,-2),1500),3)
        self.assertEqual(dose_rate(AffineHeatDose(3,4,0,-2),2500),0)

    def test_dense_derivative_and_piecewise_right_hand_boundary(self):
        first=QuarticDose(0,1000,0,100,(0,100,0,0))
        second=QuarticDose(1000,2000,0,50,(50,0,0,0))
        curve=PiecewiseDose(((D(0),D(1000),first),(D(1000),D(2000),second)))
        self.assertEqual(dose_rate(curve,500),100)
        self.assertEqual(dose_rate(curve,1000),50)
        self.assertEqual(dose_rate(curve,2500),0)
        self.assertEqual(dose_knots(curve),(0,1000,2000))
        self.assertEqual(dose_rate(dose_from_record(curve.record()),500),100)


if __name__=='__main__':unittest.main()
