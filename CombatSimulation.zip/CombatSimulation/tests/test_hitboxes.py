"""Exact geometry of the confirmed body and explicit fixed world placements."""
from copy import deepcopy
from fractions import Fraction as F
from decimal import Context, Decimal as D, localcontext
import json
from pathlib import Path
import unittest

from combat_sim.hitboxes import (
    Cuboid, combined_bounds, standing_cuboids, world_standing_cuboids, segment_intersections,
)


ROOT=Path(__file__).resolve().parents[1]
DEFINITION=json.loads((ROOT/'data/body_hitboxes.json').read_text())


class CuboidGeometryTests(unittest.TestCase):
    def test_bounds_and_closed_containment(self):
        box=Cuboid('test',[0,0,0],[2,4,6])
        self.assertEqual(box.bounds,((-1,-2,-3),(1,2,3)))
        self.assertTrue(box.contains([1,2,3]))
        self.assertFalse(box.contains([F(1)+F(1,10**40),0,0]))

    def test_segment_entry_exit_and_reverse_direction(self):
        box=Cuboid('test',[0,0,0],[2,2,2])
        self.assertEqual(box.segment_interval([-2,0,0],[2,0,0]),(F(1,4),F(3,4)))
        self.assertEqual(box.segment_interval([2,0,0],[-2,0,0]),(F(1,4),F(3,4)))

    def test_parallel_misses_inside_starts_and_stationary_segments(self):
        box=Cuboid('test',[0,0,0],[2,2,2])
        self.assertIsNone(box.segment_interval([-2,2,0],[2,2,0]))
        self.assertEqual(box.segment_interval([0,0,0],[2,0,0]),(0,F(1,2)))
        self.assertEqual(box.segment_interval([0,0,0],[0,0,0]),(0,1))
        self.assertIsNone(box.segment_interval([3,0,0],[3,0,0]))

    def test_endpoint_touch_is_reported_without_inventing_gameplay_priority(self):
        box=Cuboid('test',[0,0,0],[2,2,2])
        self.assertEqual(box.segment_interval([-2,0,0],[-1,0,0]),(1,1))

    def test_invalid_shapes_fail(self):
        for centre,size in (([0,0],[1,1,1]),([0,0,0],[0,1,1]),([0,0,0],[-1,1,1])):
            with self.assertRaises(ValueError):
                Cuboid('invalid',centre,size)


class StandingBodyGeometryTests(unittest.TestCase):
    def setUp(self):
        self.boxes=standing_cuboids(DEFINITION)

    def test_exact_six_parts_and_confirmed_overall_bounds(self):
        self.assertEqual({box.part for box in self.boxes},
                         {'head','torso','left_arm','right_arm','left_leg','right_leg'})
        self.assertEqual(combined_bounds(self.boxes),
                         ((F(-35,100),F(-15,100),F(-875,1000)),
                          (F(35,100),F(15,100),F(875,1000))))

    def test_head_torso_and_arm_segments_have_distinct_part_intersections(self):
        head=segment_intersections(self.boxes,[0,-1,.75],[0,1,.75])
        torso=segment_intersections(self.boxes,[0,-1,.275],[0,1,.275])
        across=segment_intersections(self.boxes,[-1,0,.225],[1,0,.225])
        self.assertEqual(set(head),{'head'})
        self.assertEqual(head['head'],(F(7,16),F(9,16)))
        self.assertEqual(set(torso),{'torso'})
        self.assertEqual(set(across),{'left_arm','torso','right_arm'})

    def test_body_union_preserves_empty_regions_inside_overall_bounds(self):
        point=[.3,.1,.3]
        low,high=combined_bounds(self.boxes)
        self.assertTrue(all(a <= F(str(p)) <= b for p,a,b in zip(point,low,high)))
        self.assertFalse(any(box.contains(point) for box in self.boxes))

    def test_incomplete_body_cannot_silently_drop_a_limb(self):
        broken=deepcopy(DEFINITION)
        del broken['parts']['left_arm']
        with self.assertRaises(ValueError):
            standing_cuboids(broken)


class WorldStandingBodyTests(unittest.TestCase):
    def test_fixed_team_facings_map_right_arms_to_opposite_world_sides(self):
        origin=[0,0,F(7,8)]
        a={box.part:box for box in world_standing_cuboids(DEFINITION,origin,'+x')}
        b={box.part:box for box in world_standing_cuboids(DEFINITION,origin,'-x')}
        self.assertEqual(a['right_arm'].centre_m,(0,F(-3,10),F(11,10)))
        self.assertEqual(b['right_arm'].centre_m,(0,F(3,10),F(11,10)))
        self.assertEqual(a['torso'].size_m,(F(3,10),F(1,2),F(7,10)))

    def test_explicit_body_origin_puts_feet_on_supplied_ground_level(self):
        body=world_standing_cuboids(DEFINITION,[30,4,F(7,8)],'-x')
        low,high=combined_bounds(body)
        self.assertEqual(low,(F(597,20),F(73,20),0))
        self.assertEqual(high,(F(603,20),F(87,20),F(7,4)))

    def test_world_segment_detects_local_torso_after_translation_and_rotation(self):
        body=world_standing_cuboids(DEFINITION,[30,4,F(7,8)],'-x')
        hits=segment_intersections(body,[29,4,F(23,20)],[31,4,F(23,20)])
        self.assertEqual(set(hits),{'torso'})
        self.assertEqual(hits['torso'],(F(17,40),F(23,40)))

    def test_facing_must_be_explicitly_supported(self):
        with self.assertRaises(ValueError):
            world_standing_cuboids(DEFINITION,[0,0,0],'+y')


class BodyAreaGeometryTests(unittest.TestCase):
    def test_sphere_can_intersect_a_body_whose_centre_is_outside_radius(self):
        body=world_standing_cuboids(DEFINITION,[0,F(21,5),F(7,8)],'+x')
        self.assertTrue(any(box.intersects_sphere([0,0,F(23,20)],4) for box in body))

    def test_sphere_respects_vertical_separation(self):
        box=Cuboid('box',[0,0,10],[2,2,2])
        self.assertFalse(box.intersects_sphere([0,0,0],4))

    def test_sphere_tangent_contact_and_corner_miss(self):
        box=Cuboid('box',[0,0,0],[2,2,2])
        self.assertTrue(box.intersects_sphere([2,1,0],1))
        self.assertFalse(box.intersects_sphere([2,2,0],1))

    def test_vertical_column_uses_radial_xy_overlap(self):
        box=Cuboid('box',[0,0,10],[2,2,2])
        self.assertTrue(box.intersects_vertical_column([2,1],1))
        self.assertFalse(box.intersects_vertical_column([2,2],1))

    def test_invalid_area_parameters_fail(self):
        box=Cuboid('box',[0,0,0],[2,2,2])
        with self.assertRaises(ValueError):
            box.intersects_sphere([0,0,0],-1)
        with self.assertRaises(ValueError):
            box.intersects_vertical_column([0,0],-1)
        with self.assertRaises(ValueError):
            box.intersects_vertical_column([0,0,0],1)


class SweptSphereTests(unittest.TestCase):
    def setUp(self):
        self.box=Cuboid('box',[0,0,0],[2,2,2])

    def test_two_centimetre_sphere_contacts_face_before_its_centre_enters_box(self):
        hit=self.box.swept_sphere_contact([-2,0,0],[2,0,0],F(1,50))
        self.assertEqual(hit.parameter,D('.245'))
        self.assertEqual(hit.centre_m,(D('-1.02'),D(0),D(0)))
        self.assertEqual(hit.closest_box_point_m,(D(-1),D(0),D(0)))

    def test_rounded_corner_does_not_use_expanded_box_false_positive(self):
        self.assertIsNone(self.box.swept_sphere_contact([-2,1.09,1.09],[2,1.09,1.09],F(1,10)))

    def test_corner_contact_has_the_correct_spherical_radius(self):
        hit=self.box.swept_sphere_contact([-2,1.05,1.05],[2,1.05,1.05],F(1,10))
        with localcontext(Context(prec=60)):
            squared=sum((a-b)**2 for a,b in zip(hit.centre_m,hit.closest_box_point_m))
            self.assertLess(abs(squared-D('.01')),D('1e-45'))
            expected=(D(1)-D('.005').sqrt())/4
            self.assertLess(abs(hit.parameter-expected),D('1e-45'))

    def test_reverse_direction_and_point_projectile(self):
        hit=self.box.swept_sphere_contact([2,0,0],[-2,0,0],F(1,50))
        self.assertEqual(hit.closest_box_point_m,(D(1),D(0),D(0)))
        self.assertEqual(hit.parameter,D('.245'))
        point=self.box.swept_sphere_contact([-2,0,0],[2,0,0],0)
        self.assertEqual(point.parameter,D('.25'))

    def test_initial_overlap_and_stationary_miss(self):
        self.assertEqual(self.box.swept_sphere_contact([0,0,0],[0,0,0],F(1,50)).parameter,0)
        self.assertIsNone(self.box.swept_sphere_contact([3,0,0],[3,0,0],F(1,50)))

    def test_fixed_precision_does_not_inherit_callers_context(self):
        expected=self.box.swept_sphere_contact([-2,1.05,1.05],[2,1.05,1.05],F(1,10))
        with localcontext(Context(prec=6)):
            actual=self.box.swept_sphere_contact([-2,1.05,1.05],[2,1.05,1.05],F(1,10))
        self.assertEqual(actual,expected)

    def test_invalid_radius_or_precision_fails(self):
        with self.assertRaises(ValueError):
            self.box.swept_sphere_contact([-2,0,0],[2,0,0],-1)
        with self.assertRaises(ValueError):
            self.box.swept_sphere_contact([-2,0,0],[2,0,0],1,precision=5)
