"""Atomic motion API probes with real shared combat, gravity and contacts.

Scripted forces/relocations are labelled engineering operations, not casts of
an unimplemented portal, grapple or knockback ability.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.shared_engine import SharedEncounter,run_shared_scenario
from combat_sim.spatial_transitions import SpatialChange,StaleSpatialPlan
from combat_sim.mechanics.velocity_projection import VelocityEquality,BlockedDirection
from tests.test_combat_reactions import engine
from tests.test_motion_boundary_combat import scene as base_scene,CURRENT
from tests.test_mobile_combat import BODY,MOVEMENT,PROFILES,TERRAIN,command,events
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS


def scene(duration=1000):return base_scene(duration,(0,-20))


def changes(world,rows):
    return tuple(SpatialChange(row['actor'],row.get('generation',world.fighters[row['actor']].life_generation),
        reference_m=row.get('reference'),velocity_mps=row.get('velocity')) for row in rows)


def run(s,*,operations=(),interval=None,precision=50):
    class Probe(SharedEncounter):
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw)
            for time,p in operations:self.push(D(time),'probe_spatial',p,priority=p.get('priority',5))

        def _process(self,kind,p):
            if kind!='probe_spatial':return super()._process(kind,p)
            if p.get('op')=='project':
                r,_=self.spatial_transitions.project({name:self.fighters[name].life_generation for name in p['actors']},
                    tuple(VelocityEquality(*pair) for pair in p['edges']),
                    tuple(BlockedDirection(name,normal) for name,normal in p.get('blocked',())),source='probe:group_projection')
                self.log('probe_projection',projection=r.record());return
            if p.get('op')=='invalid':
                before=self.states();records=len(self.event_log.records())
                try:self.spatial_transitions.apply(changes(self,p['changes']),source='probe:invalid')
                except ValueError:
                    if self.states()!=before or len(self.event_log.records())!=records:raise AssertionError('Invalid preparation changed the world')
                    self.log('probe_atomic_rejection',unchanged=True);return
                raise AssertionError('Expected invalid preparation')
            self.spatial_transitions.apply(changes(self,p['changes']),source='probe:spatial')

    with localcontext(Context(prec=precision)):
        return Probe(s,PROFILES,precision=precision,sample_interval_ms=interval,body_definition=BODY,
            terrain_definition=TERRAIN,movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
            jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS).run()


class AtomicSpatialTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_multi_body_swap_validates_final_positions_together(self):
        w=engine(scene(1));a=w.spatial_transitions.reference('A');b=w.spatial_transitions.reference('B')
        plan=w.spatial_transitions.prepare((SpatialChange('B',1,reference_m=a),SpatialChange('A',1,reference_m=b)),source='probe:swap')
        w.spatial_transitions.commit(plan)
        self.assertEqual(w.spatial_transitions.reference('A'),b);self.assertEqual(w.spatial_transitions.reference('B'),a)
        self.assertEqual([r['actor'] for r in w.spatial_transitions.records[0]['bodies']],['A','B'])

    def test_invalid_second_destination_is_atomic_during_live_jump_and_weapon_control(self):
        s=scene(1000);s['encounter']['participants']['A']['character']='1E5';s['action_selection']['A']['start_ms']=0
        command(s,'A',0,'jump');baseline=run(s)
        r=run(s,operations=[(200,{'op':'invalid','changes':[{'actor':'A','reference':[0,-18,3]},
            {'actor':'B','reference':[6,0,'.875']}]})])
        self.assertEqual(r['final_states'],baseline['final_states']);self.assertTrue(events(r,'probe_atomic_rejection'))
        self.assertFalse(r['spatial_transitions'])

    def test_stale_plan_rejects_before_any_commit_after_status_change(self):
        w=engine(scene(1));plan=w.spatial_transitions.prepare((SpatialChange('A',1,velocity_mps=(3,0,0)),),source='probe:stale')
        w.fighters['B'].instability+=1;before=w.states()
        with self.assertRaises(StaleSpatialPlan):w.spatial_transitions.commit(plan)
        self.assertEqual(w.states(),before);self.assertFalse(w.spatial_transitions.records)

    def test_plan_cannot_be_committed_to_another_world_or_twice(self):
        w=engine(scene(1));other=engine(scene(1));plan=w.spatial_transitions.prepare((SpatialChange('A',1,velocity_mps=(3,0,0)),),source='probe:plan')
        with self.assertRaises(ValueError):other.spatial_transitions.commit(plan)
        w.spatial_transitions.commit(plan)
        with self.assertRaises(StaleSpatialPlan):w.spatial_transitions.commit(plan)

    def test_support_metadata_change_rejects_a_prepared_plan(self):
        w=engine(scene(1));plan=w.spatial_transitions.prepare((SpatialChange('A',1,velocity_mps=(3,0,0)),),source='probe:support')
        w.motion['A']['support_part']='changed_support'
        with self.assertRaises(StaleSpatialPlan):w.spatial_transitions.commit(plan)
        self.assertFalse(w.spatial_transitions.records)

    def test_generation_guard_and_duplicate_actor_reject_without_motion(self):
        w=engine(scene(1));before=w.states()
        for rows in ((SpatialChange('A',2,velocity_mps=(3,0,0)),),
                (SpatialChange('A',1),SpatialChange('A',1))):
            with self.assertRaises(ValueError):w.spatial_transitions.prepare(rows,source='probe:bad')
        self.assertEqual(w.states(),before)

    def test_noop_and_subresolution_updates_do_not_interrupt_climb(self):
        s=scene(500);s['encounter']['participants']['A']['position_m']=['4.8',0]
        command(s,'A',0,'climb cube_1')
        # The ordinary source command is represented by an explicit target.
        s['movement_script'][0].update(action='climb',target='cube_1')
        r=run(s,operations=[(200,{'changes':[{'actor':'A'}]})])
        self.assertFalse(events(r,'climb_interrupted'));self.assertEqual(len(events(r,'climb_completed')),1)
        w=engine(scene(1));reference=w.spatial_transitions.reference('A')
        output=tuple(x+D('1e-25') for x in reference)
        self.assertIsNone(w.spatial_transitions.apply((SpatialChange('A',1,reference_m=output),),source='probe:noise'))

    def test_upward_force_uses_gravity_contacts_without_a_fake_jump_payment(self):
        r=run(scene(1000),operations=[(0,{'changes':[{'actor':'A','velocity':[0,0,3]}]})])
        self.assertFalse(events(r,'jump_takeoff'));self.assertFalse(events(r,'dyspnea_paid'))
        land=events(r,'jump_landed','A');self.assertEqual(len(land),1)
        self.assertAlmostEqual(D(land[0]['time_ms']),D(6000)/D('9.81'),places=12)
        self.assertEqual(land[0]['self_effects'],{'disorientation':'0','instability':'0'})
        self.assertEqual(D(r['final_states']['A']['body_origin_m'][2]),D('.875'))

    def test_ground_imposed_motion_is_not_reduced_or_accelerated_by_instability(self):
        s=scene(500);s['encounter']['participants']['A']['initial_state']['instability']=500
        r=run(s,operations=[(0,{'changes':[{'actor':'A','velocity':[3,0,0]}]})])
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('1.5'))
        self.assertEqual(D(r['final_states']['A']['locomotion']['velocity_mps'][0]),3)
        self.assertEqual(r['final_states']['A']['locomotion']['motion_driver'],'imposed')

    def test_imposed_motion_can_be_stopped_by_the_existing_special_stop(self):
        s=scene(1000);command(s,'A',400,'stop')
        r=run(s,operations=[(0,{'changes':[{'actor':'A','velocity':[3,0,0]}]})])
        stop=events(r,'special_stop_started','A')[0];self.assertEqual(D(stop['original_speed_mps']),3)
        self.assertEqual(D(r['final_states']['A']['locomotion']['velocity_mps'][0]),0)
        self.assertNotIn('motion_driver',r['final_states']['A']['locomotion'])

    def test_imposed_horizontal_momentum_survives_force_flight_and_landing(self):
        r=run(scene(1000),operations=[(0,{'changes':[{'actor':'A','velocity':[3,0,3]}]})])
        self.assertEqual(len(events(r,'jump_landed','A')),1)
        self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),3,places=12)
        self.assertEqual(D(r['final_states']['A']['locomotion']['velocity_mps'][0]),3)

    def test_actual_wall_contact_removes_only_the_normal_component(self):
        s=scene(600);s['encounter']['participants']['A']['position_m']=[4,0]
        r=run(s,operations=[(0,{'changes':[{'actor':'A','velocity':[3,1,0]}]})])
        contacts=events(r,'body_contact');self.assertTrue(contacts)
        v=list(map(D,r['final_states']['A']['locomotion']['velocity_mps']))
        self.assertEqual(v,[D(0),D(1),D(0)])
        self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),D('4.95'),places=12)

    def test_reference_relocation_interrupts_climb_at_current_pose_with_inherited_velocity(self):
        s=scene(700);s['encounter']['participants']['A']['position_m']=['4.8',0]
        s['movement_script']=[{'actor':'A','at_ms':0,'action':'climb','target':'cube_1'}]
        r=run(s,operations=[(200,{'changes':[{'actor':'A','reference':[3,0,2]}]})])
        self.assertEqual(len(events(r,'climb_interrupted')),1);self.assertFalse(events(r,'climb_completed'))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),3)
        self.assertGreater(D(r['final_states']['A']['body_origin_m'][2]),2)

    def test_projection_applies_three_actor_velocity_changes_in_one_transition(self):
        s=scene(500)
        s['encounter']['participants']['B']['position_m']=[0,-30]
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(character='1E5',position_m=[0,-40])
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        rows=[{'actor':name,'velocity':[speed,0,0]} for name,speed in [('A',2),('B',6),('C',-1)]]
        r=run(s,operations=[(0,{'changes':rows}),(0,{'op':'project','actors':['C','A','B'],'edges':[['A','B'],['B','C'],['C','A']]})])
        velocities=[tuple(map(D,r['final_states'][name]['locomotion']['velocity_mps'])) for name in ('A','B','C')]
        self.assertEqual(velocities[0],velocities[1]);self.assertEqual(velocities[1],velocities[2])
        self.assertEqual(len(r['spatial_transitions'][1]['bodies']),3)
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),velocities[0][0]/2)

    def test_projection_with_a_blocked_direction_does_not_invent_a_collision_status(self):
        r=run(scene(500),operations=[(0,{'changes':[{'actor':'A','velocity':[3,1,0]}]}),
            (0,{'op':'project','actors':['A','B'],'edges':[['A','B']],'blocked':[['B',[1,0,0]]]})])
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),0)
        self.assertFalse(events(r,'body_contact'))

    def test_relocated_target_is_not_hit_at_its_old_projectile_contact(self):
        s=scene(300);s['action_selection']['A'].update(start_ms=0,reload_when_empty=False)
        baseline=run(s);self.assertTrue(events(baseline,'projectile_body_collision'))
        r=run(s,operations=[(140,{'changes':[{'actor':'B','reference':[30,-15,'.875']}],'priority':0})])
        self.assertFalse(events(r,'projectile_body_collision'))
        self.assertEqual(r['final_states']['B']['hp'],r['initial_states']['B']['hp'])

    def test_independent_weapon_action_continues_after_body_relocation(self):
        s=scene(500);s['action_selection']['A'].update(start_ms=0,reload_when_empty=False)
        r=run(s,operations=[(70,{'changes':[{'actor':'A','reference':[0,-21,'.875']}],'priority':0})])
        self.assertTrue(events(r,'projectile_released'));self.assertFalse(events(r,'controlled_action_cancelled'))

    def test_numerical_context_observations_and_order_preserve_forced_motion(self):
        s=scene(1000);ops=[(0,{'changes':[{'actor':'A','velocity':[3,0,3]}]})]
        baseline=run(s,operations=ops);other=deepcopy(s)
        other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        result=run(other,operations=ops,interval=137,precision=80)
        for name in ('A','B'):
            for x,y in zip(baseline['final_states'][name]['body_origin_m'],result['final_states'][name]['body_origin_m']):
                self.assertLess(abs(D(x)-D(y)),D('1e-8'))

    def test_inward_contact_at_the_observation_horizon_settles_immediately(self):
        s=scene(100);s['encounter']['participants']['A']['position_m']=['4.95',0]
        r=run(s,operations=[(100,{'changes':[{'actor':'A','velocity':[3,0,0]}]})])
        hit=events(r,'body_contact')[0]
        self.assertEqual(D(hit['time_ms']),100);self.assertEqual(D(hit['relative_speed_mps']),3)
        self.assertEqual(D(r['final_states']['A']['locomotion']['velocity_mps'][0]),0)

    def test_a_relocation_during_partial_crouch_preserves_the_pose_and_freezes_old_control(self):
        s=scene(200);command(s,'A',0,'crouch')
        r=run(s,operations=[(75,{'changes':[{'actor':'A','reference':[0,-19,'.875']}],'priority':0})])
        final=r['final_states']['A']
        self.assertEqual(D(final['locomotion']['crouch_fraction']),D('.5'))
        self.assertEqual(D(final['locomotion']['feet_z_m']),0)
        self.assertEqual(D(final['position_m'][1]),-19)
        self.assertEqual(len(events(r,'controlled_action_cancelled')),1)

    def test_retired_life_plan_cannot_move_a_real_restored_actor(self):
        w=engine(scene(1));plan=w.spatial_transitions.prepare((SpatialChange('A',1,velocity_mps=(3,0,0)),),source='probe:old_life')
        w.fighters['A'].hp=D(0);w.finish_team_deaths()
        self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='probe:restoration'))
        before=w.states()
        with self.assertRaises(StaleSpatialPlan):w.spatial_transitions.commit(plan)
        self.assertEqual(w.states(),before);self.assertEqual(w.fighters['A'].life_generation,2)

    def test_unsupported_floor_and_dynamic_support_destinations_reject_atomically(self):
        w=engine(scene(1));before=w.states()
        for ref in ((300,-20,'.875'),(0,-20,-10),(30,-20,'2.625')):
            with self.subTest(ref=ref),self.assertRaises(ValueError):
                w.spatial_transitions.apply((SpatialChange('A',1,reference_m=ref),),source='probe:invalid_support')
        self.assertEqual(w.states(),before);self.assertFalse(w.spatial_transitions.records)

    def test_relocation_exits_a_real_pause_area_and_resumes_remaining_work_at_that_time(self):
        s=scene(600);s['action_selection']['A'].update(abilities=['2'],start_ms=0)
        s['encounter']['participants']['C']={'character':'1E2','team':'B','position_m':[30,-19],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['2'],start_ms=0)
        r=run(s,operations=[(500,{'changes':[{'actor':'A','reference':[0,-5,'.875']}]})])
        exits=[e for e in events(r,'cooldown_pause_left') if e['target']=='A']
        self.assertEqual(D(exits[0]['time_ms']),500)
        self.assertEqual(D(r['final_states']['A']['cooldown_clocks']['2']['ready_at_ms']),9300)

    def test_relocation_leaves_a_real_heat_volume_without_removing_it(self):
        s=scene(600)
        s['encounter']['participants']['C']={'character':'1E1','team':'B','position_m':[30,-19],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['4'],start_ms=0)
        r=run(s,operations=[(300,{'changes':[{'actor':'A','reference':[0,-35,'.875']}]})])
        self.assertTrue(r['volume_instances'][0]['active'])
        self.assertTrue(events(r,'spatial_transition_committed'))
        self.assertLess(D(r['final_states']['A']['hp']),D(r['initial_states']['A']['hp']))
        heat=[e for e in r['effect_instances'] if e['kind']=='heat' and e['target']=='A']
        self.assertTrue(heat);self.assertTrue(all(not e['exposed'] for e in heat))
        left=[e for e in events(r,'heat_exposure_left') if e['target']=='A']
        self.assertEqual(D(left[0]['time_ms']),300)

    def test_velocity_projection_is_an_instantaneous_update_and_not_a_hidden_persistent_link(self):
        s=scene(700);s['encounter']['participants']['B']['position_m']=[0,-30]
        # A walk targets the already-shared2 m/s; that case previously passed
        # only because Decimal text differed("2.00" versus"2"). Request an
        # actually different independent drive and compare numerical values.
        command(s,'A',300,'run')
        r=run(s,operations=[(0,{'changes':[{'actor':'A','velocity':[4,0,0]}]}),
            (0,{'op':'project','actors':['A','B'],'edges':[['A','B']]})])
        self.assertEqual(tuple(map(D,r['final_states']['A']['locomotion']['velocity_mps'])),(D('6.4'),0,0))
        self.assertEqual(tuple(map(D,r['final_states']['B']['locomotion']['velocity_mps'])),(2,0,0))
        self.assertFalse(r['grapple_links'])

    def test_imposed_driver_stops_at_real_projectile_death_and_cannot_restart_the_ghost(self):
        s=scene(500);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B'].update(start_ms=0,reload_when_empty=False)
        s['spatial_interventions']=[intervention(0,[{'actor':'A','expected_life_generation':1,'velocity_mps':[3,0,0]}]),
            intervention(300,[{'actor':'A','expected_life_generation':1,'velocity_mps':[8,0,0]}])]
        r=engine(s).run();death=D(r['final_states']['A']['died_at_ms'])
        self.assertLess(death,300)
        self.assertLess(abs(D(r['final_states']['A']['position_m'][0])-3*death/1000),D('1e-12'))
        self.assertNotIn('motion_driver',r['final_states']['A']['locomotion'])
        self.assertEqual([p['status'] for p in r['spatial_interventions']],['applied','skipped'])

    def test_force_during_an_actual_jump_keeps_the_owed_landing_effects(self):
        s=scene(1300);command(s,'A',250,'jump')
        r=run(s,operations=[(0,{'changes':[{'actor':'A','velocity':[3,0,0]}]}),
            (450,{'changes':[{'actor':'A','velocity':[4,0,2]}]})])
        self.assertEqual(len(events(r,'jump_takeoff','A')),1)
        land=events(r,'jump_landed','A')[0]
        self.assertGreater(D(land['self_effects']['disorientation']),0)
        self.assertGreater(D(land['self_effects']['instability']),0)
        self.assertEqual(len([e for e in events(r,'dyspnea_paid') if e['ability']=='jump']),1)

    def test_mutable_request_coordinates_are_copied_and_caller_precision_does_not_own_the_plan(self):
        w=engine(scene(1));reference=[0,'-18.123456789123456789','.875']
        change=SpatialChange('A',1,reference_m=reference);reference[1]=10
        with localcontext(Context(prec=9)):
            plan=w.spatial_transitions.prepare((change,),source='probe:immutable')
            w.spatial_transitions.commit(plan)
        self.assertEqual(w.spatial_transitions.reference('A')[1],D('-18.123456789123456789'))


def intervention(time,changes):
    return {'at_ms':time,'scope':'engineering','source':'scenario:spatial_probe','changes':changes}


def public_run(s):
    return run_shared_scenario(s,PROFILES,sample_interval_ms=None,body_definition=BODY,
        terrain_definition=TERRAIN,movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
        jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS)


class InterventionControlTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=50));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_public_intervention_matches_the_same_direct_world_operation(self):
        s=scene(1000);s['spatial_interventions']=[intervention(0,[{'actor':'A','expected_life_generation':1,'velocity_mps':[3,0,3]}])]
        public=public_run(s);control=deepcopy(s);control.pop('spatial_interventions')
        direct=run(control,operations=[(0,{'changes':[{'actor':'A','velocity':[3,0,3]}]})])
        self.assertEqual(public['final_states'],direct['final_states'])
        with localcontext(Context(prec=9)):
            self.assertEqual(public_run(s),public)
        self.assertEqual(public['spatial_interventions'][0]['status'],'applied')
        self.assertEqual(public['spatial_interventions'][0]['scope'],'engineering')

    def test_rejected_intervention_preserves_actual_jump_and_combat(self):
        s=scene(1000);s['encounter']['participants']['A']['character']='1E5';s['action_selection']['A']['start_ms']=0
        command(s,'A',0,'jump');baseline=public_run(s)
        s['spatial_interventions']=[intervention(200,[{'actor':'A','expected_life_generation':1,'reference_m':[0,-18,3]},
            {'actor':'B','expected_life_generation':1,'reference_m':[6,0,'.875']}])]
        r=public_run(s)
        self.assertEqual(r['spatial_interventions'][0]['status'],'rejected')
        self.assertEqual(r['final_states'],baseline['final_states']);self.assertFalse(r['spatial_transitions'])

    def test_one_stale_life_skips_the_whole_scripted_batch(self):
        s=scene(100);s['spatial_interventions']=[intervention(50,[
            {'actor':'A','expected_life_generation':1,'reference_m':[0,-18,'.875']},
            {'actor':'B','expected_life_generation':2,'reference_m':[0,-30,'.875']}])]
        r=public_run(s);self.assertEqual(r['spatial_interventions'][0]['status'],'skipped')
        self.assertFalse(r['spatial_transitions'])
        self.assertEqual(tuple(map(D,r['final_states']['A']['position_m'])),tuple(map(D,r['initial_states']['A']['position_m'])))

    def test_repeated_script_callback_is_once_only(self):
        s=scene(200);s['spatial_interventions']=[intervention(0,[{'actor':'A','expected_life_generation':1,'velocity_mps':[3,0,0]}])]
        w=engine(s);w.run();before=w.states();records=len(w.spatial_transitions.records)
        w.spatial_transitions.process_intervention({'intervention_id':'intervention:1'})
        self.assertEqual(w.states(),before);self.assertEqual(len(w.spatial_transitions.records),records)

    def test_scripted_projection_solves_the_complete_cycle_in_the_public_world(self):
        s=scene(500);s['encounter']['participants']['B']['position_m']=[0,-30]
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(character='1E5',position_m=[0,-40])
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        s['spatial_interventions']=[intervention(0,[{'actor':n,'expected_life_generation':1,'velocity_mps':[v,0,0]}
            for n,v in [('A',2),('B',6),('C',-1)]]),
            {'at_ms':0,'scope':'engineering','source':'scenario:graph_probe','projection':{
                'actors':{'C':1,'B':1,'A':1},'equalities':[['C','A'],['A','B'],['B','C']]}}]
        r=public_run(s);velocities=[r['final_states'][n]['locomotion']['velocity_mps'] for n in ('A','B','C')]
        self.assertEqual(velocities[0],velocities[1]);self.assertEqual(velocities[1],velocities[2])
        self.assertEqual(r['spatial_interventions'][1]['projection']['components'],[['A','B','C']])

    def test_malformed_or_unlabelled_controls_reject_before_simulation(self):
        for change in ('scope','actor','life','projection'):
            s=scene(100);entry=intervention(0,[{'actor':'A','expected_life_generation':1,'velocity_mps':[3,0,0]}])
            if change=='scope':entry['scope']='ability'
            elif change=='actor':entry['changes'][0]['actor']='unknown'
            elif change=='life':entry['changes'][0].pop('expected_life_generation')
            else:
                entry.pop('changes');entry['projection']={'actors':{'A':1},'equalities':['AA']}
            s['spatial_interventions']=[entry]
            with self.subTest(change=change),self.assertRaises(ValueError):engine(s)

    def test_engineering_controls_do_not_become_selectable_character_abilities(self):
        s=scene(100);s['action_selection']['A']['abilities']=['spatial_intervention']
        with self.assertRaises(ValueError):engine(s)


if __name__=='__main__':unittest.main()
