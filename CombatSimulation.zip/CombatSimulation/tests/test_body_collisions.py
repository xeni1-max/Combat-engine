"""Integrated fixed cuboids, swept projectiles, live-body filtering and areas."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
from pathlib import Path
import unittest

from combat_sim.engine import run_scenario
from combat_sim.shared_engine import run_shared_scenario
from combat_sim.models import UnsupportedMechanicError


ROOT=Path(__file__).resolve().parents[1]
PROFILES=json.loads((ROOT/'data/characters.json').read_text())['characters']
BODY=json.loads((ROOT/'data/body_hitboxes.json').read_text())
SCENARIO=json.loads((ROOT/'scenarios/stationary_2v2_hitboxes.json').read_text())


def events(run,kind):
    return [e for e in run['events'] if e['type']==kind]


def duel(horizon=1300,ability='1'):
    s=deepcopy(SCENARIO)
    s['encounter']['duration_ms']=horizon
    s['encounter']['participants']={
        'caster':{'character':'1E1','team':'A','position_m':[0,0],'facing':'+x','initial_state':{'shield':0}},
        'gunner':{'character':'1E2','team':'B','position_m':[30,0],'facing':'-x','initial_state':{'shield':0}},
    }
    s['action_selection']={
        'caster':{'kind':'priority_when_ready','target':'nearest_living_enemy','abilities':[ability]},
        'gunner':{'kind':'priority_when_ready','target':'nearest_living_enemy','abilities':['1'],
                  'reload_when_empty':True,'start_ms':200000},
    }
    return s


def run(scenario,profiles=PROFILES,**kwargs):
    return run_shared_scenario(scenario,profiles,body_definition=BODY,**kwargs)


class BodyCollisionIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result=run(SCENARIO)

    def test_explicit_dispatch_and_separate_body_input(self):
        self.assertEqual(run_scenario(SCENARIO,PROFILES,body_definition=BODY),self.result)
        with self.assertRaisesRegex(UnsupportedMechanicError,'body definition'):
            run_shared_scenario(SCENARIO,PROFILES)
        old=json.loads((ROOT/'scenarios/stationary_2v2.json').read_text())
        with self.assertRaises(UnsupportedMechanicError):
            run_shared_scenario(old,PROFILES,body_definition=BODY)

    def test_all_approved_cuboids_are_placed_with_fixed_team_facing(self):
        for name,body in self.result['body_geometry'].items():
            self.assertEqual(len(body['parts']),6)
            self.assertEqual(body['facing'],'+x' if name.startswith('A_') else '-x')
            self.assertEqual(D(body['origin_m'][2]),D('.875'))
            torso=next(p for p in body['parts'] if p['part']=='torso')
            self.assertEqual(list(map(D,torso['size_m'])),[D('.3'),D('.5'),D('.7')])

    def test_authored_launch_hands_and_torso_aim_points(self):
        expected={'A_1E1':(D('.4'),D('-.1'),D('1.055')),
                  'A_1E2':(D('.3'),D('10'),D('1.025')),
                  'B_1E1':(D('29.6'),D('.1'),D('1.055')),
                  'B_1E2':(D('29.7'),D('4'),D('1.025'))}
        for name,origin in expected.items():
            release=next(e for e in events(self.result,'projectile_released') if e['actor']==name)
            self.assertEqual(tuple(map(D,release['origin_m'])),origin)
            self.assertEqual(D(release['aim_point_m'][2]),D('1.15'))
            self.assertEqual(D(release['radius_m']),D('.02'))

    def test_projectile_contacts_body_surface_with_its_spherical_extent(self):
        r=run(duel())
        contact=events(r,'projectile_body_collision')[0]
        self.assertEqual(contact['target'],'gunner')
        self.assertEqual(contact['hit_parts'],['torso'])
        self.assertEqual(contact['time_ms'],'693')
        self.assertLess(abs(D(contact['location_m'][0])-D('29.85')),D('1e-40'))
        self.assertLess(abs(D(contact['projectile_centre_m'][0])-D('29.83')),D('1e-40'))
        self.assertTrue(any(e['time_ms']=='1193' for e in events(r,'delayed_blast')))

    def test_shooter_is_ignored_and_first_friendly_body_intercepts(self):
        s=duel(1000)
        s['encounter']['participants']['blocker']={'character':'1E1','team':'A','position_m':[15,0],
                                                  'facing':'+x','initial_state':{'shield':0}}
        s['action_selection']['blocker']={'kind':'priority_when_ready','target':'nearest_living_enemy',
                                         'abilities':['1'],'start_ms':200000}
        r=run(s)
        contact=events(r,'projectile_body_collision')[0]
        self.assertEqual((contact['actor'],contact['target'],contact['aim_target']),('caster','blocker','gunner'))
        self.assertEqual(D(r['final_states']['caster']['hp']),8140)
        self.assertEqual(D(r['final_states']['gunner']['hp']),8140)
        self.assertLess(D(r['final_states']['blocker']['hp']),8140)

    def target_dies(self,start_ms=0,far_body=False):
        s=duel(1400)
        s['encounter']['participants']['gunner']['initial_state']['hp']=1
        s['encounter']['participants']['ally']={'character':'1E2','team':'A','position_m':[0,1],'facing':'+x'}
        s['action_selection']['ally']={'kind':'priority_when_ready','target':'nearest_living_enemy',
                                      'abilities':['1'],'reload_when_empty':True,'start_ms':start_ms}
        if far_body:
            s['encounter']['participants']['far']={'character':'1E1','team':'B','position_m':[40,0],'facing':'-x'}
            s['action_selection']['far']={'kind':'priority_when_ready','target':'nearest_living_enemy',
                                         'abilities':['1'],'start_ms':200000}
        return run(s)

    def test_dead_target_before_release_produces_no_automatic_qard_mark(self):
        r=self.target_dies()
        release=next(e for e in events(r,'projectile_released') if e['actor']=='caster')
        self.assertEqual(release['aim_target'],'gunner')
        self.assertIsNone(release['scheduled_collision_target'])
        self.assertFalse(any(e['actor']=='caster' for e in events(r,'delayed_blast')))
        pending=next(p for p in r['pending_projectiles'] if p['actor']=='caster')
        self.assertEqual(pending['status'],'no_live_body_contact_pending')

    def test_body_dying_in_flight_is_skipped_without_retargeting_trajectory(self):
        r=self.target_dies(start_ms=300,far_body=True)
        contact=next(e for e in events(r,'projectile_body_collision') if e['actor']=='caster')
        self.assertEqual((contact['target'],contact['aim_target']),('far','gunner'))
        self.assertTrue(any(e['actor']=='caster' and e['target']=='gunner'
                            for e in events(r,'projectile_skipped_dead_body')))
        blasts=[e for e in events(r,'delayed_blast') if e['actor']=='caster']
        self.assertEqual(len(blasts),1)
        self.assertGreater(D(blasts[0]['location_m'][0]),39)

    def test_deployed_beam_hits_each_overlapping_body_once_at_full_strength(self):
        s=duel(1000,'4')
        s['encounter']['participants']['edge']={'character':'1E1','team':'B','position_m':[30,7.2],
                                               'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['edge']={'kind':'priority_when_ready','target':'nearest_living_enemy',
                                      'abilities':['1'],'start_ms':200000}
        r=run(s)
        beam=events(r,'beam_deployed')[0]
        self.assertEqual(set(beam['recipients']),{'gunner','edge'})
        effects=events(r,'heat_started')
        self.assertEqual(len(effects),2)
        self.assertEqual(D(r['final_states']['gunner']['hp']),D(r['final_states']['edge']['hp']))

    def test_beam_area_also_includes_the_caster_when_its_body_is_inside(self):
        s=duel(1000,'4')
        s['encounter']['participants']['gunner']['position_m']=[3,0]
        r=run(s)
        self.assertEqual(set(events(r,'beam_deployed')[0]['recipients']),{'caster','gunner'})

    def test_delayed_sphere_blast_affects_both_grouped_bodies_once(self):
        blast=next(e for e in events(self.result,'delayed_blast') if e['actor']=='A_1E1')
        self.assertEqual(blast['recipients'],['B_1E1','B_1E2'])
        for name in blast['recipients']:
            batch=next(e for e in events(self.result,'impact_batch_resolved')
                       if e['time_ms']==blast['time_ms'] and e['target']==name)
            self.assertEqual(sum(h['component']=='delayed_blast' and h['actor']=='A_1E1' for h in batch['hits']),1)

    def test_each_projectile_has_its_own_configurable_radius(self):
        small=run(duel(1000))
        profiles=deepcopy(PROFILES)
        profiles['1E1']['abilities']['1']['projectile_geometry']['radius_m']=.1
        large=run(duel(1000),profiles)
        a=events(small,'projectile_body_collision')[0]
        b=events(large,'projectile_body_collision')[0]
        self.assertLess(D(b['distance_m']),D(a['distance_m']))
        self.assertLess(D(b['time_ms']),D(a['time_ms']))

    def test_coincident_contacts_with_different_bodies_are_rejected(self):
        s=duel(1000)
        s['encounter']['participants']['blocker']={'character':'1E1','team':'A','position_m':[30,0],'facing':'+x'}
        s['action_selection']['blocker']={'kind':'priority_when_ready','target':'nearest_living_enemy',
                                         'abilities':['1'],'start_ms':200000}
        with self.assertRaisesRegex(UnsupportedMechanicError,'different bodies'):
            run(s)

    def test_body_origin_and_facing_are_not_silently_guessed(self):
        for missing in ('facing','ground'):
            s=duel(1000)
            if missing=='facing':
                del s['encounter']['participants']['caster']['facing']
            else:
                del s['encounter']['ground_z_m']
            with self.assertRaises((ValueError,UnsupportedMechanicError)):
                run(s)

    def test_earlier_point_trace_with_corrected_initial_hand_snapshot(self):
        from tests.historical_assertions import with_correct_initial_hands
        folder=ROOT/'results/stationary-2v2'
        profiles=json.loads((folder/'characters.json').read_text())['characters']
        actual=run_shared_scenario(json.loads((folder/'scenario.json').read_text()),
                                   profiles)
        self.assertEqual(actual,with_correct_initial_hands(json.loads((folder/'run.json').read_text()),profiles))

    def test_precision_and_observation_spacing_preserve_body_encounter(self):
        cadence=lambda r:[(e['time_ms'],e.get('actor'),e.get('target'),e.get('ability'),e['type'])
                           for e in r['events'] if e['type'] in ('ability_started','projectile_released','reload_completed')]
        for trial in (run(SCENARIO,precision=80),run(SCENARIO,sample_interval_ms=137),
                      run(SCENARIO,sample_interval_ms=None)):
            self.assertEqual(cadence(trial),cadence(self.result))
            with localcontext(Context(prec=90)):
                for name,state in self.result['final_states'].items():
                    other=trial['final_states'][name]
                    self.assertEqual(state['alive'],other['alive'])
                    for field in ('hp','armor','shield','dyspnea','disorientation','instability','died_at_ms'):
                        if state[field] is not None:
                            self.assertLess(abs(D(state[field])-D(other[field])),D('1e-20'))
