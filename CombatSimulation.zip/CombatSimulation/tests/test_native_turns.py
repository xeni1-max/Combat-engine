"""Native common turns: actual shared phases, motion, casts and obstructions."""
from copy import deepcopy
from dataclasses import replace
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.angular_paths import YawArc,RotatingBoxPath
from combat_sim.angular_contacts import box_path_contact
from combat_sim.angular_kinematics import margins,point_velocity,witness
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.models import UnsupportedMechanicError
from combat_sim.orientation import YawFrame
from combat_sim.terrain import RectangularGround
from tests.test_actor_facing_combat import scene,run,oriented
from tests.test_mobile_combat import command,events,PROFILES
from tests.test_world_colliders_combat import wall


def turn(s,angle=90,time=0,actor='A'):
    s.setdefault('turn_script',[]).append(dict(actor=actor,at_ms=time,angle_degrees=angle))
    return s


def wall_scene():
    s=turn(scene(300));s['initial_colliders']=[wall('wall',x='.3',z=1,size=('.05',2,2),hp=None)]
    return s


def gun_scene():
    s=turn(scene(650),360)
    for c in s['action_selection'].values():c['start_ms']=0
    return s


class NativeTurnTests(unittest.TestCase):
    def test_all_six_characters_use_confirmed_turn_timing(self):
        for name in PROFILES:
            with self.subTest(character=name):
                r=run(turn(scene(200,character=name)))
                self.assertEqual(events(r,'turn_completed')[0]['time_ms'],'150')
                self.assertEqual(r['final_states']['A']['facing'],{'yaw_frame':{'cosine':'0','sine':'1'}})
                self.assertFalse(events(r,'dyspnea_paid'))

    def test_partial_turn_updates_real_body_frame_at_horizon(self):
        r=run(turn(scene(75)))
        self.assertFalse(events(r,'turn_completed'))
        self.assertEqual(r['body_turns']['A']['status'],'active')
        frame=r['final_states']['A']['facing']['yaw_frame']
        self.assertLess(abs(F(frame['cosine'])-F(frame['sine'])),F(1,10**50))
        self.assertEqual(F(frame['cosine'])**2+F(frame['sine'])**2,1)

    def test_signed_turn_retains_initial_noncardinal_heading(self):
        s=oriented(scene(200));turn(s,-90)
        r=run(s);frame=r['final_states']['A']['facing']['yaw_frame'];initial=YawFrame.from_degrees(37)
        self.assertEqual(F(frame['cosine']),initial.sine)
        self.assertEqual(F(frame['sine']),-initial.cosine)

    def test_walk_and_turn_use_independent_resources_and_world_drive(self):
        s=turn(scene(),90,200);command(s,'A',0,'walk');r=run(s)
        self.assertEqual(events(r,'turn_completed')[0]['time_ms'],'430')
        self.assertEqual(r['final_states']['A']['position_m'],['1.94','-20'])
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'walking')

    def test_turn_samples_current_physical_speed_at_start(self):
        s=turn(scene(),90,400);command(s,'A',0,'run');r=run(s)
        start=events(r,'turn_started')[0];speed=D(start['sampled_speed_mps'])
        self.assertEqual(D(start['active_end_ms'])-D(start['time_ms']),150+40*speed)
        self.assertGreater(speed,2)

    def test_turn_does_not_steer_subsequent_explicit_world_movement(self):
        s=turn(scene());command(s,'A',200,'walk');r=run(s)
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),1)
        self.assertEqual(D(r['final_states']['A']['position_m'][1]),-20)

    def test_explicit_turns_queue_by_owned_completion(self):
        s=turn(scene(400));turn(s,-90,20);r=run(s)
        self.assertEqual([e['time_ms'] for e in events(r,'turn_started')],['0','150'])
        self.assertEqual([e['time_ms'] for e in events(r,'turn_completed')],['150','300'])
        self.assertEqual(r['final_states']['A']['facing'],{'yaw_frame':{'cosine':'1','sine':'0'}})

    def test_zero_angle_does_not_acquire_an_action_or_block_next_command(self):
        s=turn(scene(200),0);turn(s,90);r=run(s)
        self.assertEqual(len(events(r,'turn_started')),1)
        self.assertEqual(events(r,'turn_completed')[0]['time_ms'],'150')

    def test_lower_body_restriction_defers_turn_without_spending(self):
        s=turn(scene(300));s['initial_restrictions']=[dict(target='A',source='turn_test',functions=['lower_body'],duration_ms=80)]
        r=run(s)
        self.assertEqual(events(r,'turn_started')[0]['time_ms'],'80')
        self.assertEqual(events(r,'turn_completed')[0]['time_ms'],'230')

    def test_wrong_life_command_is_ignored(self):
        s=turn(scene(200));s['turn_script'][0]['expected_life_generation']=2;r=run(s)
        self.assertFalse(events(r,'turn_started'));self.assertEqual(r['turn_commands'][0]['status'],'ignored')

    def test_actual_wall_contact_interrupts_and_uses_angular_surface_velocity(self):
        r=run(wall_scene());contact=events(r,'body_contact')[0]
        self.assertGreater(D(contact['raw_status']),50)
        self.assertEqual(events(r,'turn_cancelled')[0]['reason'],'body_contact')
        self.assertFalse(events(r,'turn_completed'))
        self.assertEqual(r['final_states']['A']['position_m'],['0','-20'])
        self.assertTrue(all(D(v)==0 for v in r['final_states']['A']['locomotion']['velocity_mps']))

    def test_turn_away_from_touching_wall_can_resume_without_retrigger(self):
        s=wall_scene();turn(s,-45,100);r=run(s)
        self.assertEqual(len(events(r,'turn_cancelled')),1)
        self.assertEqual(len(events(r,'turn_completed')),1)

    def test_actual_body_contact_stops_turn_and_both_reference_components(self):
        s=turn(scene(300));s['encounter']['participants']['B']['position_m']=['.45',-20]
        r=run(s);contact=events(r,'body_contact')[0]
        self.assertEqual(contact['second'],'B');self.assertGreater(D(contact['raw_status']),100)
        for name in ('A','B'):
            self.assertGreaterEqual(r['metrics'][name]['collision_stops'],1)
            self.assertTrue(all(D(v)==0 for v in r['final_states'][name]['locomotion']['velocity_mps']))

    def test_actual_gunfire_during_full_turn_keeps_both_action_lifetimes(self):
        r=run(gun_scene());self.assertEqual(events(r,'turn_completed')[0]['time_ms'],'600')
        self.assertTrue(any(D(e['time_ms'])<600 for e in events(r,'projectile_released','A')))
        self.assertTrue(events(r,'projectile_released','B'))
        self.assertLess(D(r['final_states']['A']['hp']),PROFILES['1E2']['max_hp'])

    def test_held_block_and_turn_keep_independent_owners_and_real_projectile_contact(self):
        from tests.test_actor_facing_combat import selected_cases
        r=run(turn(selected_cases()['block'],180))
        self.assertEqual(events(r,'turn_completed')[0]['time_ms'],'300')
        self.assertTrue(any(e.get('action_kind')=='block' for e in events(r,'active_started')))
        self.assertLess(D(r['final_states']['A']['hp']),D(PROFILES['2E4']['max_hp']))

    def test_real_fatal_projectile_cancels_turn_and_stale_completion(self):
        s=gun_scene();s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['A']['start_ms']=100000;r=run(s)
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertFalse(events(r,'turn_completed'))
        self.assertEqual(r['body_turns']['A']['status'],'cancelled')

    def test_observations_do_not_reanchor_reference_or_yaw(self):
        s=turn(scene(500),180,100);command(s,'A',0,'walk')
        a=run(s,interval=None);b=run(s,interval=17)
        for key in ('position_m','facing'):
            self.assertEqual(a['final_states']['A'][key],b['final_states']['A'][key])
        self.assertEqual(a['body_path_frames_created'],b['body_path_frames_created'])

    def test_precision_and_reversed_participants_keep_wall_contact(self):
        a=run(wall_scene());s=wall_scene();s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        self.assertLess(abs(D(events(a,'body_contact')[0]['time_ms'])-D(events(b,'body_contact')[0]['time_ms'])),D('1e-8'))
        self.assertLess(abs(D(events(a,'body_contact')[0]['raw_status'])-D(events(b,'body_contact')[0]['raw_status'])),D('1e-8'))

    def test_active_field_combination_executes_on_shared_turn_clock(self):
        s=turn(scene(1000,character='1E1'),720)
        s['action_selection']['A'].update(start_ms=0,abilities=['4'])
        r=run(s)
        self.assertTrue(events(r,'beam_deployed'));self.assertTrue(events(r,'turn_started'))
        self.assertLess(D(r['final_states']['B']['hp']),PROFILES['1E2']['max_hp'])

    def test_near_finite_edge_turn_keeps_real_support(self):
        s=turn(scene(300));s['encounter']['participants']['A']['position_m']=['249.8',-20]
        r=run(s)
        self.assertTrue(events(r,'turn_completed'));self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_invalid_turn_commands_are_rejected(self):
        for row in ({'actor':'C','at_ms':0,'angle_degrees':90}, {'actor':'A','at_ms':-1,'angle_degrees':90},
                    {'actor':'A','at_ms':0,'angle_degrees':True}, {'actor':'A','at_ms':0,'angle_degrees':90,'extra':1}):
            with self.subTest(row=row),self.assertRaises(ValueError):
                s=scene(100);s['turn_script']=[row];run(s)

    def test_unselected_turn_mode_does_not_add_result_fields(self):
        r=run(scene(100));self.assertNotIn('body_turns',r);self.assertNotIn('turn_commands',r)


class NativeAngularGeometryTests(unittest.TestCase):
    def test_query_slices_retain_original_angular_anchor(self):
        arc=YawArc(0,1,YawFrame(),137)
        sliced=replace(arc,begin_s=F('.123'),end_s=F('.789'))
        self.assertEqual(arc.frame_at(F('.456')),sliced.frame_at(F('.456')))
        self.assertEqual(sliced.record()['anchor_s'],'0')

    def test_exact_signed_vertical_coefficients_preserve_anchored_foot(self):
        p=RotatingBoxPath(BodyPathPiece(0,150,(0,0,0),(0,0,0),(0,0,0)),
            YawArc(0,F('.15'),YawFrame(),600),Cuboid('foot',(0,0,F('.5')),('.2','.2',1)),
            local_acceleration_mps2=(0,0,1),size_acceleration_mps2=(0,0,2))
        self.assertEqual(p.projection_range((0,0,1),0,F('.15'))[0],0)
        ground=RectangularGround('ground',(-250,-250,0),(250,250,0))
        self.assertIsNone(box_path_contact(p,ground,0,F('.15'),minimum_overlap_m=F(1,10**22)))

    def test_overlap_resolution_is_explicit_and_default_closed_touch_is_retained(self):
        a=Cuboid('a',(0,0,0),(1,1,1));b=Cuboid('b',(1,0,0),(1,1,1))
        self.assertIsNotNone(box_path_contact(a,b,0,1))
        self.assertIsNone(box_path_contact(a,b,0,1,minimum_overlap_m=F(1,10**22)))

    def test_contact_witness_is_in_both_solids_and_has_actual_point_velocity(self):
        arc=YawArc(0,1,YawFrame(),90)
        p=RotatingBoxPath(BodyPathPiece(0,1000,(0,0,0),(0,0,0),(0,0,0)),arc,Cuboid('arm',(0,1,1),('.1',1,'.1')))
        first=p.at_time(0);other=Cuboid('wall',(F('1.5'),0,1),('.01',1,1))
        point=witness(first,other)
        self.assertTrue(first.contains(point));self.assertTrue(other.contains(point))
        self.assertEqual(point_velocity(p,0,point)[0],0)
        self.assertGreater(point_velocity(p,0,point)[1],2)


if __name__=='__main__':unittest.main()
