"""Actual 1E3 field and split interactions; labelled API probes isolate ties/lives."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from tests.test_equilibrium_combat import run, rules
from tests.test_binding_combat import run as configured_run
from tests.test_mobile_combat import read, events, PROFILES
from tests.test_impact_bindings_combat import add
from tests.test_world_colliders_combat import wall


def scene(duration=1600, centre=(30,-20,0)):
    s=read('scenarios/1e3_duplication.json');s['encounter']['duration_ms']=duration
    s['action_selection']['A']['ability_targets']['Ultimate']['point_m']=list(centre)
    return s


def field_only(s):
    s['action_selection']['A']['abilities']=['Ultimate']
    s['action_selection']['A']['ability_targets'].pop('1')


def block(name,x,y,*,size=('.4','.5',2),hp=2000):
    obj=wall(name,x=x,hp=hp,z=1,size=size,blocking={'projectiles':True,'bodies':False,'areas':False})
    obj['parts'][0]['centre_m'][1]=y
    return obj


class ProjectileDuplicationCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        json.dumps(r);losses=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(row['initial_hp']) for row in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-losses.amount(target=name)),D('1e-8'))
        return losses

    def test_actual_source_phases_and_independent_hands_with_no_summon_cost(self):
        r=run(scene());self.conserved(r);field=r['projectile_duplication_fields'][0]
        self.assertEqual(D(field['deployed_at_ms']),300)
        self.assertEqual(D(field['expiry_ms']),25300)
        self.assertEqual(field['definition'],{'shape':'vertical_cylinder','radius_m':12,'duration_ms':25000,'separation_m':4})
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['Ultimate']),65000)
        self.assertEqual({e['ability'] for e in events(r,'ability_started','A') if D(e['time_ms'])==0},{'Ultimate','1'})
        self.assertFalse([e for e in events(r,'dyspnea_paid','A') if e['ability']=='Ultimate'])
        self.assertFalse([e for e in events(r,'self_status_applied','A') if e['ability']=='Ultimate'])
        self.assertEqual(len(events(r,'projectile_released','A')),1)

    def test_symmetric_four_metre_shift_retains_velocity_arc_length_and_birth_snapshot(self):
        r=run(scene());split=r['projectile_duplication_splits'][0]
        left=tuple(map(D,split['parent_origin_m']));right=tuple(map(D,split['child_origin_m']))
        centre=tuple(map(D,split['centre_before_m']))
        self.assertLess(abs(sum((b-a)**2 for a,b in zip(left,right))-16),D('1e-40'))
        for a,b,c in zip(left,right,centre):self.assertLess(abs((a+b)/2-c),D('1e-40'))
        self.assertLess(abs(sum((b-a)*v for a,b,v in zip(left,right,map(D,split['retained_velocity_mps'])))),D('1e-40'))
        flights={f['id']:f for f in r['projectile_flights']}
        a,b=flights[split['parent_projectile_id']],flights[split['child_projectile_id']]
        self.assertEqual(a['initial_velocity_mps'],b['initial_velocity_mps'])
        self.assertEqual(a['distance_offset_m'],b['distance_offset_m'])
        self.assertEqual(a['root_projectile_id'],b['root_projectile_id'])
        self.assertEqual(a['accuracy'],b['accuracy'])
        self.assertEqual(a['birth_kinematics']['initial_velocity_mps'],a['accuracy']['actual_velocity_mps'])
        self.assertEqual(len(r['released_attack_power']),1)
        self.assertEqual(len(r['projectile_accuracy_releases']),1)

    def test_real_damage_and_mark_payload_reach_both_offset_targets_once(self):
        r=run(scene());ledger=self.conserved(r)
        self.assertGreater(ledger.amount(target='B'),0);self.assertGreater(ledger.amount(target='D'),0)
        self.assertEqual(len(events(r,'projectile_body_collision')),2)
        self.assertEqual({m['target'] for m in r['binding_marks']},{'B','D'})
        self.assertTrue(all(m['actor']=='A' and m['source_life_generation']==1 for m in r['binding_marks']))

    def test_repeated_real_shots_have_independent_lineage_and_three_marks_freeze_each_body(self):
        r=run(scene(5000));self.conserved(r)
        self.assertGreaterEqual(len(r['projectile_duplication_splits']),3)
        upper=[b for b in r['binding_instances'] if b['kind']=='upper_body']
        self.assertEqual({b['target'] for b in upper},{'B','D'})
        self.assertEqual(r['metrics']['A']['projectile_copies_created'],len(r['projectile_duplication_splits']))
        self.assertGreaterEqual(r['metrics']['A']['projectiles_released'],len(r['projectile_duplication_splits']))
        self.assertFalse(events(r,'dyspnea_paid','A'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_existing_personal_shields_absorb_each_branch_without_erasing_marks(self):
        s=scene()
        for name in ('B','D'):s['encounter']['participants'][name]['initial_state']['shield']=1000
        r=run(s);self.assertEqual(self.conserved(r).amount(),0)
        self.assertLess(D(r['final_states']['B']['shield']),1000)
        self.assertLess(D(r['final_states']['D']['shield']),1000)
        self.assertEqual({m['target'] for m in r['binding_marks']},{'B','D'})

    def test_birth_inside_field_splits_at_release_clock(self):
        r=run(scene(centre=(0,-20,0)));self.conserved(r)
        self.assertEqual(r['projectile_duplication_splits'][0]['at_ms'],events(r,'projectile_released')[0]['time_ms'])
        self.assertEqual(len(r['projectile_duplication_splits']),1)

    def test_deploying_over_an_already_flying_projectile_splits_it_immediately(self):
        s=scene();s['action_selection']['A']['abilities']=['1'];s['action_selection']['A']['ability_targets'].pop('Ultimate')
        add(s,'C',[0,-25],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['Ultimate'],start_ms=100,reload_when_empty=False,
            ability_targets={'Ultimate':{'kind':'world_point','point_m':[0,-20,0]}})
        r=run(s);self.conserved(r)
        self.assertEqual(D(r['projectile_duplication_fields'][0]['deployed_at_ms']),400)
        self.assertEqual(D(r['projectile_duplication_splits'][0]['at_ms']),400)

    def test_enemy_projectiles_cross_without_duplication(self):
        s=scene();field_only(s);s['action_selection']['B'].update(abilities=['1'],start_ms=500,reload_when_empty=True)
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'projectile_released','B'))
        self.assertEqual(r['projectile_duplication_splits'],[])
        self.assertEqual(len(events(r,'projectile_copied')),0)

    def test_other_ally_gets_copy_and_keeps_damage_credit_instead_of_field_owner(self):
        s=scene();field_only(s);s['encounter']['participants']['A']['position_m']=[0,-25]
        add(s,'C',[0,-20],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['1'],start_ms=400,reload_when_empty=False,
            ability_targets={'1':{'kind':'world_point','point_m':[60,-20,'1.15']}})
        r=run(s);ledger=self.conserved(r)
        self.assertGreater(ledger.amount(actor='C'),0);self.assertEqual(ledger.amount(actor='A'),0)
        self.assertEqual(r['projectile_duplication_splits'][0]['field_actor'],'A')
        self.assertTrue(all(f['actor']=='C' for f in r['projectile_flights']))

    def test_two_overlapping_actual_fields_each_split_branches_without_recursing(self):
        s=scene();add(s,'C',[0,-25],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['Ultimate'],start_ms=0,reload_when_empty=False,
            ability_targets={'Ultimate':{'kind':'world_point','point_m':[30,-20,0]}})
        r=run(s);self.conserved(r)
        self.assertEqual(len(r['projectile_duplication_fields']),2)
        self.assertEqual(len(r['projectile_duplication_splits']),3)
        self.assertEqual(len(r['projectile_flights']),4)
        self.assertTrue(all(len(set(f['duplication_sources']))==2 for f in r['projectile_flights']))

    def test_parent_or_descendant_cannot_split_again_in_same_field(self):
        observed=[]
        def duplicate(w):
            for name in ('projectile:1','projectile:2'):
                observed.append(w.projectile_system.split(name,source='duplication-field:1',separation_m=4))
        r=run(scene(),operations=((550,duplicate),))
        self.assertEqual(observed,[None,None]);self.assertEqual(len(r['projectile_flights']),2)

    def test_material_before_field_consumes_shot_without_copy(self):
        s=scene();s['initial_colliders']=[wall('front_wall',x=10,hp=2000)]
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'projectile_terrain_collision'))
        self.assertFalse(r['projectile_duplication_splits'])
        self.assertLess(D(r['world_collider_states']['front_wall']['hp']),2000)

    def test_shifted_endpoint_inside_material_collides_at_exact_split_clock(self):
        s=scene(centre=(0,-20,0));s['initial_colliders']=[block('endpoint_wall','.15','-22.2')]
        r=run(s);self.conserved(r)
        split=r['projectile_duplication_splits'][0]
        hit=next(e for e in events(r,'projectile_terrain_collision') if e['target']=='endpoint_wall')
        self.assertEqual(hit['time_ms'],split['at_ms'])
        self.assertEqual(hit['projectile_id'],split['parent_projectile_id'])
        self.assertLess(D(r['world_collider_states']['endpoint_wall']['hp']),2000)

    def test_shifted_endpoint_inside_body_hits_it_immediately(self):
        s=scene(centre=(0,-20,0));add(s,'E',['.15','-22.32'],character='1E2',team='B')
        r=run(s);self.conserved(r)
        split=r['projectile_duplication_splits'][0]
        hit=next(e for e in events(r,'projectile_body_collision') if e['target']=='E')
        self.assertEqual(hit['time_ms'],split['at_ms'])

    def test_native_field_can_duplicate_an_impact_device_and_both_area_payloads_survive(self):
        s=scene(2500);field_only(s);s['encounter']['participants']['A']['position_m']=[0,-25]
        add(s,'C',[0,-20],character='1E2',team='A')
        s['action_selection']['C'].update(abilities=['Ultimate'],start_ms=400,reload_when_empty=False,
            ability_targets={'Ultimate':{'kind':'world_point','point_m':[60,-20,'1.15']}})
        r=run(s);self.conserved(r)
        self.assertEqual(len(r['projectile_duplication_splits']),1)
        self.assertEqual(len(r['impact_area_bursts']),2)
        self.assertTrue(all(m['actor']=='C' for m in r['gathering_modifiers']))
        self.assertGreaterEqual(len(r['gathering_modifiers']),2)

    def test_actual_hook_payloads_can_split_with_independent_finite_rope_resolution(self):
        s=scene(2300,centre=(15,-20,0));field_only(s);s['encounter']['participants']['A']['position_m']=[0,-25]
        add(s,'C',[0,-20],character='1E2',team='A')
        s['action_selection']['C'].update(abilities=['3'],start_ms=400,reload_when_empty=False,
            ability_targets={'3':{'kind':'world_point','point_m':[25,-20,0]}})
        r=run(s);self.conserved(r)
        self.assertEqual(len(r['projectile_duplication_splits']),1)
        self.assertEqual(len(r['projectile_flights']),2)
        self.assertTrue(all('hook' in f['contact_payload'] for f in r['projectile_flights']))

    def test_source_death_before_deployment_cancels_field(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        r=run(scene(),operations=((150,kill),))
        self.assertEqual(r['projectile_duplication_fields'],[])
        self.assertEqual(r['projectile_duplication_splits'],[])

    def test_source_death_after_release_keeps_field_and_projectile_damage_life(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        r=run(scene(),operations=((350,kill),))
        self.assertEqual(len(r['projectile_duplication_splits']),1)
        self.assertEqual(r['projectile_duplication_fields'][0]['status'],'active')
        self.assertTrue(all(f['source_life_generation']==1 for f in r['projectile_flights']))
        self.assertLess(D(r['final_states']['B']['hp']),8140)

    def test_source_restoration_does_not_relabel_old_field_or_old_projectile_branches(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        def restore(w):self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=8140,source='duplication_life_api_probe'))
        r=run(scene(),operations=((350,kill),(600,restore)))
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(r['projectile_duplication_fields'][0]['source_life_generation'],1)
        self.assertEqual(r['projectile_duplication_splits'][0]['source_life_generation'],1)

    def test_active_field_expiry_is_independent_and_excludes_later_projectiles(self):
        s=scene(27000);field_only(s);s['encounter']['participants']['A']['position_m']=[0,-25]
        add(s,'C',[0,-20],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['1'],start_ms=25500,reload_when_empty=False,
            ability_targets={'1':{'kind':'world_point','point_m':[60,-20,'1.15']}})
        r=run(s);self.conserved(r)
        self.assertEqual(r['projectile_duplication_fields'][0]['status'],'expired')
        self.assertFalse(r['projectile_duplication_splits'])
        self.assertTrue(events(r,'projectile_released','C'))

    def test_exact_expiry_entry_tie_uses_expiry_first_engineering_duration(self):
        reference=run(scene());at=D(reference['projectile_duplication_splits'][0]['at_ms'])
        profiles=deepcopy(PROFILES)
        profiles['1E3']['abilities']['Ultimate']['projectile_duplication']['duration_ms']=str(at-300)
        r=configured_run(scene(),rules=rules(),profiles=profiles)
        self.assertFalse(r['projectile_duplication_splits'])
        self.assertEqual(D(r['projectile_duplication_fields'][0]['ended_at_ms']),at)

    def test_due_phase_solid_creation_at_entry_is_resolved_before_split(self):
        from combat_sim.world_colliders import ColliderPolicy
        at=D(run(scene())['projectile_duplication_splits'][0]['at_ms'])
        def install(w):w.push(at,'fixture_binding',{'operation':1},priority=0)
        def solid(w):
            point=w.mobile_flight_state(w.projectile_flights['projectile:1'],w.time)[0]
            w.collider_system.spawn((Cuboid('panel',point,('.1','.1','.1')),),source='field_tie_api_probe',
                entity_id='tie_solid',hp=1000,policy=ColliderPolicy(True,False,False))
        r=run(scene(),operations=((0,install),(100000,solid)))
        self.conserved(r)
        self.assertFalse(r['projectile_duplication_splits'])
        self.assertEqual(D(events(r,'projectile_terrain_collision')[0]['time_ms']),at)
        self.assertLess(D(r['world_collider_states']['tie_solid']['hp']),1000)

    def test_api_vertical_apex_split_uses_world_x_and_preserves_zero_velocity(self):
        from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
        seen=[]
        def apex(w):
            p=w.projectile_flights['projectile:1'];point,_,_,distance=w.mobile_flight_state(p,w.time)
            p.update(origin_m=point,trajectory_started_at_ms=w.time,initial_velocity_mps=(0,0,0),
                distance_offset_m=distance,acceleration_mps2=D(0),revision=p['revision']+1)
            w.gravity_trajectories[p['id']]=PersistentProjectileTrajectory(point,(0,0,0),float((w.horizon-w.time)/1000))
            seen.append(w.projectile_system.split(p['id'],source='vertical_apex_api_probe',separation_m=4))
        run(scene(),operations=((400,apex),))
        row=seen[0]
        self.assertEqual(tuple(map(D,row['retained_velocity_mps'])),(0,0,0))
        delta=tuple(D(b)-D(a) for a,b in zip(row['parent_origin_m'],row['child_origin_m']))
        self.assertEqual(delta,(4,0,0))

    def test_api_numerically_stopped_flight_cannot_split_while_terminal_receipt_is_pending(self):
        from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
        seen=[]
        def inert(w):
            p=w.projectile_flights['projectile:1'];point,_,_,distance=w.mobile_flight_state(p,w.time)
            p.update(origin_m=point,trajectory_started_at_ms=w.time,initial_velocity_mps=(0,0,0),
                distance_offset_m=distance,acceleration_mps2=D(-300),revision=p['revision']+1)
            path=PersistentProjectileTrajectory(point,(0,0,0),float((w.horizon-w.time)/1000),deceleration_mps2=300)
            w.gravity_trajectories[p['id']]=path
            p['stops_at_ms']=w.time;w.projectile_system.schedule_stop(p,priority=3)
            seen.append(w.projectile_system.split(p['id'],source='inert_split_api_probe',separation_m=4))
        r=run(scene(),operations=((400,inert),))
        self.assertEqual(seen,[None]);self.assertEqual(len(r['projectile_flights']),1)

    def test_world_target_allows_field_cast_with_only_allied_bodies(self):
        s=scene();field_only(s)
        for p in s['encounter']['participants'].values():p['team']='A'
        r=run(s);self.conserved(r)
        self.assertEqual(len(r['projectile_duplication_fields']),1)
        self.assertFalse(r['projectile_flights'])

    def test_unrelated_default_enemy_target_freezes_area_centre_at_selection(self):
        s=scene();field_only(s);s['action_selection']['A'].pop('ability_targets')
        from tests.test_mobile_combat import command
        command(s,'B',0,'walk')
        r=run(s);self.conserved(r)
        self.assertEqual(tuple(map(D,r['projectile_duplication_fields'][0]['centre_m'][:2])),(60,-22))
        self.assertNotEqual(tuple(map(D,r['final_states']['B']['position_m'])),(60,-22))

    def test_numerical_precision_actor_order_and_observation_controls_preserve_actual_damage(self):
        s=scene();base=run(s)
        for interval in (17,37):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,precision=80,interval=interval);self.conserved(r)
            self.assertEqual([x['at_ms'] for x in r['projectile_duplication_splits']],[x['at_ms'] for x in base['projectile_duplication_splits']])
            for name in base['final_states']:
                for key in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertLess(abs(D(base['final_states'][name][key])-D(r['final_states'][name][key])),D('1e-8'))

    def test_actual_field_also_works_in_supported_straight_flight_world(self):
        from combat_sim.mobile_combat import MOBILE_SCOPE
        from combat_sim.shared_engine import run_shared_scenario
        from tests.test_aim_combat import inputs
        cfg=rules();cfg.pop('impact_bindings');cfg.pop('contact_constructs')
        s=scene();s['scope']=dict(MOBILE_SCOPE)
        s['action_selection']['A']['ability_targets'].pop('1')
        s['encounter']['participants']['B']['position_m']=[59,-20]
        s['encounter']['participants']['D']['position_m']=[59,-18]
        add(s,'E',[59,-22],character='1E2',team='B')
        kw=inputs(cfg);profiles=kw.pop('profiles');kw['projectile_physics_definition']=None
        r=run_shared_scenario(s,profiles,**kw);self.conserved(r)
        self.assertEqual(len(r['projectile_duplication_splits']),1)
        self.assertGreater(self.conserved(r).amount(),0)

    def test_bad_selected_definitions_fail_without_disabling_unrelated_scenarios(self):
        profiles=deepcopy(PROFILES);profiles['1E3']['abilities']['Ultimate']['projectile_duplication']['shape']='box'
        with self.assertRaises(UnsupportedMechanicError):configured_run(scene(),rules=rules(),profiles=profiles)
        cfg=rules();cfg.pop('projectile_duplication')
        with self.assertRaises(UnsupportedMechanicError):configured_run(scene(),rules=cfg)
