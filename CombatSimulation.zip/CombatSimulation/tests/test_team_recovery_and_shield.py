"""Individual Recovery timing and delayed continuous shield-supply examples."""
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.continuous_numeric import root_curve_integral
from combat_sim.mechanics.delayed_shield import DelayedShieldRecovery
from combat_sim.mechanics.recovery import hand_recovery


class HandRecoveryTests(unittest.TestCase):
    def test_gun_hands_move_in_parallel(self):
        with localcontext(Context(prec=50)):
            duration, hands = hand_recovery(
                {'left':[-.20,.15,-.1], 'right':[.20,.15,-.1]},
                {'left':[0,.30,.15], 'right':[.05,.25,.1]}, 200)
            self.assertEqual(duration, 71)
            self.assertGreater(hands['left']['duration_ms'], hands['right']['duration_ms'])

    def test_initial_beam_and_ability_switches(self):
        self.assertEqual(hand_recovery({'right':[.20,.15,-.1]}, {'right':[.30,.15,.45]}, 200)[0],112)
        self.assertEqual(hand_recovery({'right':[.30,.15,.45]}, {'right':[.1,.4,.18]}, 200)[0],84)

    def test_reload_and_return_to_firing(self):
        self.assertEqual(hand_recovery({'right':[.05,.25,.1]}, {'right':[.15,-.25,-.2]},200)[0],119)
        self.assertEqual(hand_recovery({'right':[.05,.25,.1]}, {'right':[.05,.25,.1]},200)[0],0)

    def test_exact_ceiling_survives_low_decimal_context(self):
        with localcontext(Context(prec=6)):
            duration,_ = hand_recovery({'right':[0,0,0]}, {'right':[F(1)+F(1,10**40),0,0]},1)
            self.assertEqual(duration,2)

    def test_invalid_or_missing_hand_poses_fail(self):
        for current,required,value in (({}, {'right':[0,0,0]},200),
                                       ({'right':[0,0,0]}, {'right':[0,0]},200),
                                       ({'right':[0,0,0]}, {'right':[0,0,0]},-1)):
            with self.assertRaises(ValueError):
                hand_recovery(current,required,value)


class DelayedContinuousShieldTests(unittest.TestCase):
    def setUp(self):
        self.context = localcontext(Context(prec=60))
        self.context.__enter__()

    def tearDown(self):
        self.context.__exit__(None,None,None)

    def test_point_losses_keep_individual_delays_and_share_one_rate(self):
        recovery=DelayedShieldRecovery(20000,400)
        recovery.add_impact(D(0),D(1000))
        recovery.add_impact(D(500),D(1000))
        self.assertEqual(recovery.advance(D(0),D(20000)),0)
        self.assertEqual(recovery.advance(D(20000),D(22000)),800)
        self.assertEqual(recovery.advance(D(22000),D(30000)),1200)
        self.assertEqual(recovery.recovered,2000)

    def test_no_recovery_can_precede_a_loss_eligibility_jump(self):
        recovery=DelayedShieldRecovery(20000,400)
        recovery.add_impact(D(10000),D(1000))
        self.assertEqual(recovery.advance(D(0),D(30000)),0)
        self.assertEqual(recovery.advance(D(30000),D(31000)),400)

    def exposure(self):
        recovery=DelayedShieldRecovery(20000,400)
        c={'coefficient':D(900),'start_ms':D(0),'leave_ms':D(3000),'expiry_ms':D(4500),'k':D(2)}
        amount=root_curve_integral(D(900),D(0),D(3000),D(4500),D(0),D(1000),D(2))
        recovery.add_curve(D(0),D(1000),amount,c)
        return recovery

    def test_growing_continuous_loss_supply_has_correct_shared_service(self):
        recovery=self.exposure()
        self.assertEqual(recovery.advance(D(0),D(20000)),0)
        amount=recovery.advance(D(20000),D(21000))
        # Supply is 900*sqrt(t) HP/s. It reaches 400 at t=16/81 s;
        # before that recover supply, afterward recover 400/s.
        self.assertLess(abs(amount-D(90800)/243),D('1e-20'))
        recovery.advance(D(21000),D(30000))
        self.assertEqual(recovery.recovered,600)

    def test_continuous_supply_is_independent_of_observation_partition(self):
        whole=self.exposure()
        whole.advance(D(0),D(21000))
        partitioned=self.exposure()
        begin=D(0)
        for end in (D(19999),D(20137),D(20411),D(20777),D(21000)):
            partitioned.advance(begin,end)
            begin=end
        self.assertLess(abs(whole.recovered-partitioned.recovered),D('1e-20'))

    def test_initially_missing_shield_has_no_invented_loss_history(self):
        recovery=DelayedShieldRecovery(20000,400)
        self.assertEqual(recovery.advance(D(0),D(30000)),0)

    def test_decreasing_residual_supply_recovers_only_observed_loss(self):
        recovery=DelayedShieldRecovery(20000,400)
        c={'coefficient':D(900),'start_ms':D(0),'leave_ms':D(3000),'expiry_ms':D(4500),'k':D(2)}
        amount=root_curve_integral(D(900),D(0),D(3000),D(4500),D(3000),D(4500),D(2))
        recovery.add_curve(D(3000),D(4500),amount,c)
        self.assertLess(abs(recovery.advance(D(0),D(24000))-400),D('1e-20'))
        recovery.advance(D(24000),D(30000))
        self.assertEqual(recovery.recovered,amount)
