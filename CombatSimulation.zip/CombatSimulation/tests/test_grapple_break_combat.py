"""Common Break/response inputs act on actual 1E5 grabs in the shared engine."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.status import mitigate_status
from combat_sim.models import UnsupportedMechanicError
from tests.test_grapple_casts_combat import scene as grab_scene,run,engine,drag_dose
from tests.test_mobile_combat import events,command
from tests.test_motion_boundary_combat import CURRENT
from tests.test_grapple_links_combat import force,pos


def control(s,time,actor,kind,**fields):
    s.setdefault('control_script',[]).append({'at_ms':time,'actor':actor,'command':kind,**fields})


def scene(duration=1500,dyspnea=15,answered=True):
    s=grab_scene(duration);s['id']='actual_common_grapple_break'
    s['encounter']['participants']['B']['initial_state']['dyspnea']=dyspnea
    control(s,200,'B','break')
    if answered:control(s,220,'A','continue_grapple')
    return s


class GrappleBreakCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for actor,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=actor)
            self.assertLess(abs(supplied-D(r['final_states'][actor]['hp'])-ledger.amount(target=actor)),D('1e-8'))
        return ledger

    def test_actual_immediate_break_releases_the_hold_without_extra_cost(self):
        s=grab_scene(800);control(s,500,'B','break');r=run(s);row=r['grapple_break_contests'][0]
        self.assertEqual((row['end_reason'],D(row['ended_at_ms'])),('break_escaped',500))
        self.assertEqual(row['effort_channel_ids'],[]);self.assertEqual(D(row['penalty_base']),0)
        self.assertFalse(r['final_states']['A']['owned_actions']);self.assertFalse(r['final_states']['B']['owned_actions'])
        self.assertEqual(len(events(r,'dyspnea_paid')),1);self.assertEqual(D(r['controlled_damage_streams'][0]['ended_at_ms']),500)
        self.conserved(r)

    def test_no_response_expires_exactly_at_the_window_end(self):
        r=run(scene(800,40,False));row=r['grapple_break_contests'][0]
        self.assertEqual((row['end_reason'],D(row['ended_at_ms'])),('break_no_response',350))
        self.assertEqual(row['effort_channel_ids'],[]);self.assertEqual(D(row['actual_break_dyspnea']),0)
        self.assertAlmostEqual(self.conserved(r).amount(actor='A'),drag_dose(160,D(165)),places=8)

    def test_response_adds_two_fixed_rates_and_escapes_on_the_continuous_boundary(self):
        r=run(scene());row=r['grapple_break_contests'][0];time=D(row['ended_at_ms'])
        self.assertEqual(row['end_reason'],'break_escaped');self.assertGreater(time,1000);self.assertLess(time,1500)
        channels={c['id']:c for c in r['continuous_effort_channels']}
        for identity in row['effort_channel_ids']:
            channel=channels[identity];self.assertEqual((channel['kind'],D(channel['base'])),('fill',20))
            self.assertLess(abs(D(channel['gained'])-20*(time-220)/1000),D('1e-12'))
        gained=sum((D(channels[i]['gained']) for i in row['effort_channel_ids']),D(0))
        self.assertEqual(D(row['actual_break_dyspnea']),gained)
        self.assertLess(abs(D(row['penalty_base'])-3*gained),D('1e-40'))
        self.assertEqual(r['grapple_holds'][0]['ended_at_ms'],row['ended_at_ms']);self.conserved(r)

    def test_actual_escape_agrees_with_an_independent_rk4_bar_comparison(self):
        r=run(scene());actual=D(r['grapple_break_contests'][0]['ended_at_ms'])
        # Independent source equations: D_a=4 at contact190, Dd2 until220,
        # then D_a'=(2+D_a/100)^2+20 and D_b=9.3+20*t. Statuses vanish by337.
        value=100*(D('2.04')/(1-D('2.04')*D('.03')/100)-2)
        step=D('.0001');time=D(0);previous=value-D('9.3')
        derivative=lambda d:(2+d/100)**2+20
        for _ in range(20000):
            k1=derivative(value);k2=derivative(value+k1*step/2)
            k3=derivative(value+k2*step/2);k4=derivative(value+k3*step)
            value+=step*(k1+2*k2+2*k3+k4)/6;time+=step
            margin=value-(D('9.3')+20*time)
            if margin>=0:
                crossing=220+1000*(time-step+step*(-previous)/(margin-previous));break
            previous=margin
        else:self.fail('Independent comparison never crossed')
        self.assertGreater(crossing,337);self.assertLess(abs(actual-crossing),D('1e-5'))

    def test_pending_request_can_escape_before_a_response_is_due(self):
        r=run(scene(600,0,False));row=r['grapple_break_contests'][0]
        self.assertEqual(row['end_reason'],'break_escaped');self.assertLess(D(row['ended_at_ms']),350)
        self.assertEqual(row['effort_channel_ids'],[]);self.assertEqual(D(row['penalty_base']),0)

    def test_response_at_the_deadline_is_late(self):
        s=scene(500,40,False);control(s,350,'A','continue_grapple');r=run(s)
        self.assertEqual(r['grapple_break_contests'][0]['end_reason'],'break_no_response')
        self.assertEqual(r['combat_control_commands'][1]['result']['status'],'ignored')
        self.assertEqual(len(r['continuous_effort_channels']),1)

    def test_rational_deadline_does_not_depend_on_the_callers_decimal_context(self):
        s=grab_scene(1200);s['encounter']['participants']['B']['initial_state']['dyspnea']=40
        control(s,'2701/3','B','break');control(s,'3151/3','A','continue_grapple')
        with localcontext(Context(prec=28)):w=engine(s)
        r=w.run();row=r['grapple_break_contests'][0]
        self.assertEqual(row['status'],'ended')
        self.assertEqual(row['end_reason'],'break_no_response')
        self.assertEqual(r['combat_control_commands'][1]['result']['status'],'ignored')

    def test_response_just_before_the_deadline_is_accepted(self):
        s=scene(400,40,False);control(s,'349.999','A','continue_grapple');r=run(s)
        self.assertEqual(r['grapple_break_contests'][0]['status'],'filling')
        self.assertEqual(len(r['grapple_break_contests'][0]['effort_channel_ids']),2)
        self.assertEqual(r['grapple_holds'][0]['status'],'active')

    def test_duplicate_request_does_not_extend_the_response_window(self):
        s=scene(500,40,False);control(s,300,'B','break');r=run(s)
        self.assertEqual(len(r['grapple_break_contests']),1)
        self.assertEqual(D(r['grapple_break_contests'][0]['ended_at_ms']),350)
        self.assertEqual(r['combat_control_commands'][1]['result']['status'],'duplicate')

    def test_repeated_response_and_event_delivery_cannot_start_extra_channels(self):
        s=scene(500);control(s,230,'A','continue_grapple');w=engine(s);r=w.run()
        self.assertEqual(len(r['grapple_break_contests'][0]['effort_channel_ids']),2)
        count=len(w.continuous_effort.channels)
        w.grapple_break.process('combat_control',{'command_id':'combat-control:2'})
        self.assertEqual(len(w.continuous_effort.channels),count)
        with self.assertRaises(ValueError):w.grapple_break.load_script()

    def test_wrong_controller_or_unknown_link_cannot_answer(self):
        s=scene(500,40,False);control(s,220,'B','continue_grapple');control(s,230,'A','continue_grapple',link_id='unknown')
        r=run(s);self.assertEqual(r['grapple_break_contests'][0]['end_reason'],'break_no_response')
        self.assertTrue(all(c['result']['status']=='ignored' for c in r['combat_control_commands'][1:]))

    def test_stale_script_life_cannot_operate_a_current_actor(self):
        s=grab_scene(500);control(s,200,'B','break',expected_life_generation=2);r=run(s)
        self.assertFalse(r['grapple_break_contests']);self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertEqual(r['combat_control_commands'][0]['result']['reason'],'actor_life_ended')

    def test_owner_release_keeps_accumulated_break_penalty(self):
        s=scene(700,40);control(s,600,'A','release_grapple');r=run(s);row=r['grapple_break_contests'][0]
        self.assertEqual((row['end_reason'],D(row['ended_at_ms'])),('controller_released',600))
        self.assertLess(abs(D(row['actual_break_dyspnea'])-D('15.2')),D('1e-12'))
        self.assertLess(abs(D(row['penalty_base'])-D('45.6')),D('1e-12'))
        self.assertTrue(all(D(c['ended_at_ms'])==600 for c in r['continuous_effort_channels']))

    def test_natural_expiry_of_an_answered_contest_also_pays_its_actual_penalty(self):
        r=run(scene(3300,40));row=r['grapple_break_contests'][0]
        self.assertEqual((row['end_reason'],D(row['ended_at_ms'])),('duration_expired',3190))
        self.assertLess(abs(D(row['actual_break_dyspnea'])-D('118.8')),D('1e-10'))
        self.assertLess(abs(D(row['penalty_base'])-D('356.4')),D('1e-10'));self.conserved(r)

    def test_expiry_penalty_does_not_retract_a_thrust_active_start_due_now(self):
        s=scene(3300,30);s['action_selection']['B']['start_ms']=3050;r=run(s)
        active=[e for e in events(r,'active_started') if e['actor']=='B']
        self.assertEqual(len(active),1);self.assertEqual(D(active[0]['time_ms']),3190)
        self.assertFalse([e for e in events(r,'gathering_extended') if e['actor']=='B'])
        applied=events(r,'grapple_break_penalty_applied')[0]
        self.assertEqual(D(applied['time_ms']),3190)
        self.assertGreater(r['events'].index(applied),r['events'].index(active[0]));self.conserved(r)

    def test_a_penalty_receipt_is_applied_only_once(self):
        w=engine(scene());r=w.run();before=deepcopy(w.states())
        w.grapple_break.process('grapple_break_penalty',{'contest_id':r['grapple_break_contests'][0]['id']})
        self.assertEqual(w.states(),before);self.assertEqual(len(events(r,'grapple_break_penalty_applied')),1)

    def test_penalty_uses_individual_defenses_once_and_excludes_holding_effort(self):
        r=run(scene());row=r['grapple_break_contests'][0];base=D(row['penalty_base'])
        for penalty in row['penalties']:
            actor=penalty['actor'];state=r['initial_states'][actor]
            hp=20000 if actor=='A' else 9080
            expected=mitigate_status(base,hp,D(state['armor']),0)
            self.assertEqual(D(penalty['disorientation']),expected)
            self.assertEqual(penalty['instability'],penalty['disorientation'])
        holding=next(c for c in r['continuous_effort_channels'] if c['tag'].startswith('grapple_holding:'))
        self.assertGreater(D(holding['gained']),0)
        self.assertNotIn(holding['id'],row['effort_channel_ids'])

    def test_break_does_not_require_a_free_hand_or_lock_locomotion(self):
        s=scene(1400);command(s,'B',350,'walk')
        r=run(s,operations=[(180,{'op':'restriction','actor':'B','functions':['hand:left']})])
        self.assertTrue(events(r,'movement_active_completed'))
        self.assertEqual(r['grapple_break_contests'][0]['end_reason'],'break_escaped');self.conserved(r)

    def test_actual_sprint_and_break_add_to_one_bar_while_a_real_hold_persists(self):
        s=scene(800);command(s,'B',300,'sprint');r=run(s)
        self.assertEqual(r['grapple_break_contests'][0]['status'],'filling')
        self.assertGreater(D(r['metrics']['B']['sprint_dyspnea_gained']),0)
        channels={c['id']:c for c in r['continuous_effort_channels']}
        row=r['grapple_break_contests'][0]
        filling=sum(D(channels[i]['gained']) for i in row['effort_channel_ids'] if channels[i]['actor']=='B')
        expected=D('9.3')+filling+D(r['metrics']['B']['sprint_dyspnea_gained'])+D(r['metrics']['B']['dyspnea_paid'])
        self.assertLess(abs(D(r['final_states']['B']['dyspnea'])-expected),D('1e-8'));self.conserved(r)

    def test_actual_sprint_cap_stops_movement_without_cancelling_break_or_filling_twice(self):
        s=scene(1000,'93.7');command(s,'B',300,'sprint');r=run(s)
        self.assertEqual(r['grapple_break_contests'][0]['status'],'filling')
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertEqual(D(r['final_states']['B']['dyspnea']),100)
        caps=[e for e in events(r,'maximum_dyspnea_trigger') if e['actor']=='B']
        self.assertEqual(len(caps),1);self.assertEqual(caps[0]['source'],'sprint')
        self.assertEqual(r['final_states']['B']['locomotion']['mode'],'standing')
        channels={c['id']:c for c in r['continuous_effort_channels']};row=r['grapple_break_contests'][0]
        filling=sum(D(channels[i]['gained']) for i in row['effort_channel_ids'] if channels[i]['actor']=='B')
        supplied=88+filling+D(r['metrics']['B']['sprint_dyspnea_gained'])+D(r['metrics']['B']['dyspnea_paid'])
        self.assertLess(abs(supplied-100),D('1e-8'));self.conserved(r)

    def test_same_time_incoming_status_invalidates_a_forecast_escape(self):
        baseline=run(scene());before=D(baseline['grapple_break_contests'][0]['ended_at_ms'])
        w=engine(scene(1600));original=w._process
        def process(kind,p):
            if kind!='engineering_break_status':return original(kind,p)
            w.log('engineering_status_probe',target='B',meaning='Already adjusted incoming O/U timing control')
            w.apply_target_status_additions('B',{'disorientation':D(100),'instability':D(100)},w.fighters['B'].armor)
        w._process=process;w.push(before,'engineering_break_status',{},priority=0);r=w.run()
        after=D(r['grapple_break_contests'][0]['ended_at_ms'])
        self.assertGreater(after,before+1);self.assertLess(after,before+101)
        self.assertEqual(r['grapple_break_contests'][0]['end_reason'],'break_escaped');self.conserved(r)

    def test_imposed_group_flight_keeps_the_contest_and_its_life_owners(self):
        s=scene(650,40);s['spatial_interventions']=[force(500,'B',[2,0,3])];r=run(s)
        self.assertEqual(r['grapple_break_contests'][0]['status'],'filling')
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertEqual(pos(r,'A')[2]-D('1.1375'),pos(r,'B')[2]-D('.875'))
        self.assertGreater(pos(r,'A')[2],D('.875'));self.assertFalse([e for e in events(r,'controlled_action_cancelled')
            if e['action']['kind']=='grapple_break'])

    def test_actual_break_filling_can_reject_independent_gun_payment_safely(self):
        s=scene(700,'93.7');s['encounter']['participants']['B']['character']='1E2'
        s['action_selection']['B'].update(abilities=['1'],start_ms=300);r=run(s)
        failures=events(r,'dyspnea_payment_rejected');self.assertEqual(len(failures),1)
        self.assertEqual((failures[0]['actor'],failures[0]['phase']),('B','active_firing_end'))
        self.assertEqual(r['grapple_break_contests'][0]['status'],'filling')
        self.assertEqual(r['grapple_holds'][0]['status'],'active');self.assertEqual(r['final_states']['B']['ammo']['1'],11)
        self.assertFalse(events(r,'projectile_released'));self.conserved(r)

    def test_controller_cap_fatigue_wins_a_tied_escape_and_counts_only_actual_fill(self):
        s=scene(1100,100);s['encounter']['participants']['A']['initial_state']['dyspnea']=73
        r=run(s);row=r['grapple_break_contests'][0]
        self.assertEqual(row['end_reason'],'controller_exhausted')
        channels={c['id']:c for c in r['continuous_effort_channels']}
        target=next(channels[i] for i in row['effort_channel_ids'] if channels[i]['actor']=='B')
        self.assertLess(abs(D(target['gained'])-D('5.7')),D('1e-10'))
        self.assertEqual(len(events(r,'maximum_dyspnea_trigger')),2)
        self.assertTrue(all(D(c['gained'])>=0 for c in channels.values()));self.conserved(r)

    def test_real_gun_death_cleans_up_contest_without_retracting_other_work(self):
        s=scene(1000,40);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['C']={'character':'1E2','team':'B','position_m':[-30,-21],
            'facing':'+x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['1'],start_ms=200)
        r=run(s);row=r['grapple_break_contests'][0]
        self.assertEqual(row['ended_at_ms'],r['final_states']['A']['died_at_ms'])
        self.assertTrue(all(c['ended_at_ms']==row['ended_at_ms'] for c in r['continuous_effort_channels']))
        self.assertEqual([p['actor'] for p in row['penalties']],['B']);self.conserved(r)

    def test_continuous_beam_death_ends_filling_at_the_actual_hp_boundary(self):
        s=scene(1000,40);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['C']={'character':'1E1','team':'B','position_m':[30,-18],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['4'],start_ms=300)
        r=run(s);row=r['grapple_break_contests'][0];death=D(r['final_states']['A']['died_at_ms'])
        self.assertGreater(death,220);self.assertLess(death,1000)
        self.assertEqual(D(row['ended_at_ms']),death)
        self.assertTrue(all(D(c['ended_at_ms'])==death for c in r['continuous_effort_channels']))
        self.assertTrue(r['volume_instances'][0]['active'])
        ledger=self.conserved(r);self.assertEqual(ledger.amount(actor='A'),ledger.amount(actor='A',end=death))

    def test_real_recipient_revival_does_not_inherit_old_contest_or_commands(self):
        s=scene(3500);s['encounter']['participants']['B']['initial_state']['hp']=500
        s['action_selection']['B']['start_ms']=0;control(s,3000,'B','break',expected_life_generation=1)
        r=run(s);self.assertTrue(events(r,'life_restored'));self.assertEqual(r['final_states']['B']['life_generation'],2)
        self.assertEqual(len(r['grapple_break_contests']),1)
        self.assertEqual(r['grapple_break_contests'][0]['status'],'ended')
        self.assertEqual(r['combat_control_commands'][-1]['result']['reason'],'actor_life_ended');self.conserved(r)

    def test_configured_window_and_early_break_preserve_the_original_grab_tail(self):
        rules=deepcopy(CURRENT);rules['grapple_break']['response_window_ms']=50
        r=run(scene(260,40,False),rules=rules)
        self.assertEqual(D(r['grapple_break_contests'][0]['ended_at_ms']),250)
        actions=r['final_states']['A']['owned_actions'];self.assertEqual(len(actions),1)
        self.assertEqual(actions[0]['action']['kind'],'grapple_grab');self.assertEqual(actions[0]['occupies'],['hand:left','weapon:2'])
        self.assertFalse(r['final_states']['B']['owned_actions'])

    def test_expiry_phase_precedes_same_time_control_input(self):
        s=grab_scene(3200);control(s,3190,'B','break');r=run(s)
        self.assertFalse(r['grapple_break_contests']);self.assertEqual(r['combat_control_commands'][0]['result']['status'],'ignored')

    def test_two_independent_contests_use_separate_owners_and_only_pair_penalties(self):
        s=scene(1100,40);s['encounter']['participants']['C']=dict(s['encounter']['participants']['A'],
            position_m=['2.2',-20],facing='-x')
        s['action_selection']['C']=dict(s['action_selection']['A'])
        s['control_script']=[]
        for time,actor,cmd,identity in ((200,'B','break','grapple:3'),(210,'B','break','grapple:4'),
                (220,'A','continue_grapple','grapple:3'),(230,'C','continue_grapple','grapple:4'),
                (900,'A','release_grapple','grapple:3')):control(s,time,actor,cmd,link_id=identity)
        r=run(s);rows=r['grapple_break_contests'];self.assertEqual(len(rows),2)
        ended=next(c for c in rows if c['status']=='ended');live=next(c for c in rows if c['status']=='filling')
        self.assertEqual(ended['controller'],'A');self.assertEqual(live['controller'],'C')
        self.assertEqual({p['actor'] for p in ended['penalties']},{'A','B'})
        self.assertFalse([e for e in events(r,'target_status_applied') if e['target']=='C'])
        self.assertEqual(len([a for a in r['final_states']['B']['owned_actions'] if a['action']['kind']=='grapple_break']),1)
        self.conserved(r)

    def test_numeric_observation_and_participant_order_preserve_escape_outcomes(self):
        s=scene();base=run(s);time=D(base['grapple_break_contests'][0]['ended_at_ms'])
        for precision,interval in ((50,17),(50,100),(80,137)):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,precision=precision,interval=interval)
            self.assertLess(abs(D(r['grapple_break_contests'][0]['ended_at_ms'])-time),D('1e-8'))
            for actor in ('A','B'):
                for field in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertLess(abs(D(r['final_states'][actor][field])-D(base['final_states'][actor][field])),D('1e-8'))
            self.conserved(r)

    def test_invalid_script_modes_and_life_tokens_reject(self):
        for fields in ({'actor':[]},{'command':'invented'},{'at_ms':-1},{'expected_life_generation':True},{'link_id':''}):
            s=scene();s['control_script'][0].update(fields)
            with self.subTest(fields=fields),self.assertRaises(ValueError):run(s)
        rules=deepcopy(CURRENT);rules['grapple_break']['response_window_ms']=0
        with self.assertRaises(ValueError):run(scene(),rules=rules)
        rules=deepcopy(CURRENT);rules['grapple_break']['mode']='unknown'
        with self.assertRaises(UnsupportedMechanicError):run(scene(),rules=rules)

    def test_bad_later_script_row_does_not_schedule_earlier_rows(self):
        w=engine(grab_scene(500));before=len(w.queue)
        w.scenario['control_script']=[{'at_ms':200,'actor':'B','command':'break'},
            {'at_ms':220,'actor':'A','command':'invalid'}]
        with self.assertRaises(ValueError):w.grapple_break.load_script()
        self.assertEqual(len(w.queue),before);self.assertFalse(w.grapple_break.commands)


if __name__=='__main__':unittest.main()
