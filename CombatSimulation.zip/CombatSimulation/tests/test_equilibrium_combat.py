"""Source balance and existing Get Up on actual shared geometry/action clocks."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import json
import unittest

from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE
from tests.test_binding_combat import run as shared_run
from tests.test_mobile_combat import scenario,command,events,read
from tests.test_world_colliders_combat import wall


def rules():
    # Exercise the selected public rules rather than enabling a private test
    # variant. Earlier numerical contracts have an explicit versioned input.
    return read('data/movement/combat_locomotion.json')


def scene(duration=2000,*,down=False,o=0,u=0,character='1E2'):
    s=scenario(duration);s['scope']=dict(GRAVITY_MOBILE_SCOPE);s['id']='equilibrium_combat'
    a=s['encounter']['participants']['A'];a['character']=character
    a['initial_state'].update(knocked_down=down,disorientation=o,instability=u)
    return s


def run(s,**kwargs):return shared_run(s,rules=rules(),**kwargs)


class EquilibriumCombatTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=70));context.__enter__();self.addCleanup(context.__exit__,None,None,None)

    def test_initial_prone_get_up_uses_all_six_source_profiles_and_real_geometry(self):
        for character,active,cost in (('1E1',400,9),('1E2',400,9),('1E3',500,9),
                ('1E5',400,D('5.76')),('2E4',300,D('5.76')),('3E5',300,D('5.76'))):
            with self.subTest(character=character):
                r=run(scene(600,down=True,character=character));start=r['initial_states']['A']
                expected_prone={'1E5':D('.48'),'3E5':D('.345')}.get(character,D('.3'))
                expected_standing={'1E5':D('2.275'),'3E5':D('1.8375')}.get(character,D('1.75'))
                self.assertEqual(D(start['locomotion']['body_height_m']),expected_prone)
                self.assertTrue(start['knocked_down']);self.assertFalse(r['final_states']['A']['knocked_down'])
                self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_started','A')],[0])
                self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_completed','A')],[active])
                self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),cost)
                self.assertEqual(D(r['final_states']['A']['locomotion']['body_height_m']),expected_standing)
                self.assertTrue(all(D(p['states']['A']['locomotion']['feet_z_m'])==0 for p in r['curve']))
                json.dumps(r)

    def test_source_loss_of_equilibrium_matches_analytic_integral_and_paid_get_up(self):
        r=run(scene(o=1000,u=1000));fallen=events(r,'knockdown_applied','A')[0]
        with localcontext(Context(prec=80)):expected=100*(D(12)-D(84).sqrt())
        self.assertAlmostEqual(D(fallen['time_ms']),expected,places=35)
        self.assertEqual(D(fallen['state']['locomotion']['body_height_m']),D('.3'))
        self.assertEqual(D(events(r,'get_up_completed','A')[0]['time_ms'])-D(fallen['time_ms']),400)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),9)

    def test_partial_loss_recovers_without_knockdown_or_cost(self):
        r=run(scene(700,o=200,u=200),interval=100)
        self.assertFalse(events(r,'knockdown_applied'));self.assertFalse(events(r,'get_up_started'))
        samples={D(p['time_ms']):p['states']['A'] for p in r['curve']}
        self.assertAlmostEqual(D(samples[D(200)]['locomotion']['balance_fraction']),D('.2'),places=35)
        self.assertEqual(r['equilibrium_states']['A']['progress'],'0')
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'standing')

    def test_crouch_and_its_own_statuses_do_not_cancel_the_crouch(self):
        s=scene(400);command(s,'A',0,'crouch');r=run(s,interval=25)
        self.assertEqual(r['metrics']['A']['crouches_completed'],1)
        self.assertFalse([e for e in events(r,'controlled_action_cancelled','A') if e['action']['kind']=='posture'])
        sample=next(p['states']['A'] for p in r['curve'] if D(p['time_ms'])==75)
        self.assertEqual(D(sample['locomotion']['crouch_fraction']),D('.5'))
        self.assertGreater(D(sample['locomotion']['balance_fraction']),0)
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'crouched')
        self.assertEqual(D(r['final_states']['A']['locomotion']['body_height_m']),D('1.35'))

    def test_initial_prone_under_cover_waits_without_cost_or_penetration(self):
        s=scene(300,down=True);s['initial_colliders']=[wall('ceiling',x=0,hp=None,z='.65',size=(4,4,'.1'))]
        r=run(s);self.assertFalse(events(r,'get_up_started'))
        self.assertTrue(events(r,'get_up_waiting_for_clearance'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)
        self.assertEqual(D(r['final_states']['A']['locomotion']['body_height_m']),D('.3'))

    def test_cover_removal_wakes_get_up_at_the_actual_world_boundary(self):
        s=scene(700,down=True);s['initial_colliders']=[wall('ceiling',x=0,hp=2000,z='.65',size=(4,4,'.1'))]
        def remove(w):w.collider_system.remove('ceiling',reason='clearance_probe')
        r=run(s,operations=((203,remove),))
        self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_started','A')],[203])
        self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_completed','A')],[603])

    def test_new_cover_interrupts_paid_get_up_then_a_fresh_attempt_finishes(self):
        s=scene(800,down=True)
        def cover(w):w.collider_system.spawn_definition(wall('ceiling',x=0,hp=2000,z='.85',size=(4,4,'.1')))
        def remove(w):w.collider_system.remove('ceiling',reason='clearance_probe')
        r=run(s,operations=((100,cover),(300,remove)))
        self.assertEqual(r['metrics']['A']['get_ups_started'],2)
        self.assertEqual(r['metrics']['A']['get_ups_completed'],1)
        self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_completed','A')],[700])
        self.assertGreater(D(r['metrics']['A']['dyspnea_paid']),18)
        self.assertTrue([e for e in events(r,'controlled_action_cancelled','A') if e['action']['kind']=='get_up'])

    def test_explicit_knockdown_during_get_up_keeps_cost_and_requires_a_new_attempt(self):
        def knock(w):w.apply_knockdown('A',source='knockdown_lifecycle_probe')
        r=run(scene(1000,down=True),operations=((100,knock),))
        self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_started','A')],[0,475])
        self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_completed','A')],[875])
        self.assertEqual(r['metrics']['A']['knockdowns_received'],1)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),18)

    def test_real_gun_death_cancels_get_up_and_freezes_the_deceased_pose(self):
        s=scene(1000,down=True);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=0;r=run(s)
        self.assertEqual(D(r['final_states']['A']['hp']),0)
        self.assertEqual(r['metrics']['A']['get_ups_completed'],0)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),9)
        death=events(r,'character_died','A')[0]
        self.assertEqual(D(death['state']['locomotion']['body_height_m']),D(r['final_states']['A']['locomotion']['body_height_m']))

    def test_observations_precision_and_participant_order_preserve_balance_timing(self):
        s=scene(o=1000,u=1000);a=run(s)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        self.assertAlmostEqual(D(events(a,'knockdown_applied','A')[0]['time_ms']),D(events(b,'knockdown_applied','A')[0]['time_ms']),places=25)
        self.assertEqual(a['metrics']['A']['get_ups_completed'],b['metrics']['A']['get_ups_completed'])
        self.assertAlmostEqual(D(a['final_states']['A']['dyspnea']),D(b['final_states']['A']['dyspnea']),places=20)
        self.assertEqual(D(a['final_states']['A']['locomotion']['body_height_m']),D(b['final_states']['A']['locomotion']['body_height_m']))


if __name__=='__main__':unittest.main()
