"""Imposed body motion interrupts a real shared climb without path rewind.

Explicit position/velocity changes are engineering fixtures for future authored
knockback/drag/teleport delivery, not new abilities assigned to the actors.
Actual action payment, gravity, contacts, projectiles and heat use the world.

These numerical/phase contracts select the pre-equilibrium rules explicitly.
Current selected-rule interactions are covered in test_equilibrium_interactions.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.models import UnsupportedMechanicError
from combat_sim.hitboxes import world_standing_cuboids
from combat_sim.shared_engine import SharedEncounter
from tests.test_climb_combat import CLIMB, climb, scene
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events, read
from tests.test_airborne_combat import JUMP
from tests.test_gravity_mobile_combat import PHYSICS

CURRENT = read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json')


def run(s, *, operations=(), interval=None, precision=50, effects=CURRENT, rules=CLIMB, profiles=PROFILES):
    class Fixture(SharedEncounter):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for when, operation in operations:
                self.push(D(when), 'fixture_body_displacement', operation, priority=2)

        def _process(self, kind, p):
            if kind != 'fixture_body_displacement':
                return super()._process(kind, p)
            actor = self.fighters[p.get('actor', 'A')]
            before = tuple(map(D, actor.body_origin_m))
            delta = tuple(map(D, p.get('delta', (0, 0, 0))))
            after = tuple(x+y for x, y in zip(before, delta))
            interface = p.get('interface', 'full')
            if interface == 'full':
                actor.position_m, actor.body_origin_m = after[:2], after
            elif interface == 'body_only':
                actor.body_origin_m = after
            elif interface == 'xy_only':
                actor.position_m = after[:2]
            elif interface == 'reference_only':
                self.motion[actor.id]['body_reference_z'] = after[2]
            else:
                raise ValueError('Unknown fixture pose interface')
            if not self._climbing(actor.id) and interface == 'full':
                # Outside a climb, this fixture owns the ordinary pose/cache
                # update. The climb attachment hook is not a generic teleport.
                self.motion[actor.id]['body_reference_z'] = after[2]
                self.world_bodies[actor.id] = world_standing_cuboids(BODY, after, actor.facing)
            if 'velocity' in p:
                self.motion[actor.id]['jump'] = {'velocity': tuple(map(D, p['velocity'])), 'basic_jump': False}
            if p.get('refresh'):
                self.refresh_mobile_locomotion()
            self.log('fixture_body_displaced', actor=actor.id, origin_before_m=before,
                requested_origin_m=after, velocity_override=p.get('velocity'), interface=interface)

    with localcontext(Context(prec=precision)):
        return Fixture(s, profiles, precision=precision, sample_interval_ms=interval,
            body_definition=BODY, terrain_definition=TERRAIN, movement_definition=MOVEMENT,
            combat_locomotion_definition=effects, jump_definition=JUMP, climb_definition=rules,
            projectile_physics_definition=PHYSICS).run()


def attempt(horizon=600):
    s = scene(horizon)
    climb(s)
    return s


class ClimbDisplacementTests(unittest.TestCase):
    def setUp(self):
        ctx = localcontext(Context(prec=70))
        ctx.__enter__()
        self.addCleanup(ctx.__exit__, None, None, None)

    def test_normal_approved_path_keeps_attachment_above_activation_radius(self):
        r = run(attempt(450))
        self.assertEqual(D(r['final_states']['A']['body_origin_m'][2]), D('2.675'))
        self.assertEqual(r['metrics']['A']['climbs_completed'], 1)
        self.assertFalse(events(r, 'climb_attachment_lost'))

    def test_outward_displacement_during_ascent_cancels_before_path_can_rewind(self):
        r = run(attempt(500), operations=[(200, {'delta': (-1, 0, 0)})])
        loss = events(r, 'climb_attachment_lost', 'A')[0]
        self.assertEqual(D(loss['time_ms']), 200)
        self.assertEqual(D(loss['actual_origin_m'][0]), D('3.6'))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]), D('3.6'))
        interrupted = events(r, 'climb_interrupted', 'A')
        self.assertEqual(len(interrupted), 1)
        self.assertEqual(interrupted[0]['reason'], 'external_displacement')
        self.assertFalse(events(r, 'climb_completed', 'A'))
        self.assertFalse(events(r, 'climb_top_reached', 'A'))
        self.assertEqual(r['metrics']['A']['climb_interruptions'], 1)

    def test_position_only_change_keeps_current_momentum_then_gravity(self):
        r = run(attempt(400), operations=[(200, {'delta': (-1, 0, 0)})])
        z_at_force = D('.875')+D(32)/3*D('.05')
        elapsed = D('.2')
        expected = z_at_force+D(32)/3*elapsed-D('9.81')*elapsed**2/2
        self.assertAlmostEqual(D(r['final_states']['A']['body_origin_m'][2]), expected, places=25)
        self.assertAlmostEqual(D(r['final_states']['A']['locomotion']['velocity_mps'][2]),
                               D(32)/3-D('9.81')*elapsed, places=25)

    def test_supplied_velocity_takes_over_and_landing_adds_no_basic_jump_penalties(self):
        r = run(attempt(800), operations=[(200, {'delta': (-1, 0, 0), 'velocity': (0, 0, 0)})])
        interrupted = events(r, 'climb_interrupted', 'A')[0]
        self.assertEqual(list(map(D, interrupted['velocity_before_contact_mps'])), [D(0)]*3)
        landed = events(r, 'jump_landed', 'A')[0]
        self.assertEqual(landed['self_effects'], {'disorientation': '0', 'instability': '0'})
        self.assertEqual(r['metrics']['A']['jumps_started'], 0)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']), 0)

    def test_paid_costs_and_self_effects_are_not_reapplied_or_refunded(self):
        r = run(attempt(201), operations=[(200, {'delta': (-1, 0, 0), 'velocity': (0, 0, 0)})])
        paid = events(r, 'dyspnea_paid', 'A')
        self.assertEqual(len(paid), 1)
        self.assertEqual(D(paid[0]['amount']), D('12.25'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']), D('12.25'))
        self.assertEqual(D(r['final_states']['A']['disorientation']), 29)
        self.assertEqual(D(r['final_states']['A']['instability']), 199)
        cancelled = events(r, 'controlled_action_cancelled', 'A')
        self.assertEqual([e['action']['kind'] for e in cancelled], ['climb'])

    def test_vertical_pose_is_preserved_even_when_refresh_would_rebuild_posture(self):
        r = run(attempt(201), operations=[(200, {'delta': (0, 0, 2), 'velocity': (0, 0, 0), 'refresh': True})])
        expected = D('.875')+D(32)/3*D('.05')+2-D('9.81')*D('.001')**2/2
        self.assertAlmostEqual(D(r['final_states']['A']['body_origin_m'][2]), expected, places=25)
        self.assertEqual(len(events(r, 'climb_attachment_lost', 'A')), 1)

    def test_pose_interfaces_cannot_bypass_the_attachment_guard(self):
        for interface, delta in (('body_only', (-1, 0, 0)), ('xy_only', (-1, 0, 0)),
                                 ('reference_only', (0, 0, 2))):
            with self.subTest(interface=interface):
                r = run(attempt(201), operations=[(200, {'delta': delta, 'interface': interface})])
                self.assertEqual(len(events(r, 'climb_attachment_lost', 'A')), 1)
                self.assertFalse(events(r, 'climb_completed', 'A'))

    def test_velocity_override_interrupts_without_waiting_for_a_later_pose_sample(self):
        r = run(attempt(201), operations=[(200, {'velocity': (-2, 0, 0)})])
        self.assertEqual(D(events(r, 'climb_interrupted', 'A')[0]['time_ms']), 200)
        self.assertEqual(tuple(map(D, r['final_states']['A']['locomotion']['velocity_mps']))[:2], (D(-2), D(0)))
        self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]), D('4.598'), places=25)

    def test_external_reposition_still_in_reach_ends_this_prescribed_climb(self):
        r = run(attempt(), operations=[(200, {'delta': ('.1', 0, 0), 'velocity': (0, 0, 0)})])
        self.assertEqual(D(events(r, 'climb_attachment_lost', 'A')[0]['actual_origin_m'][0]), D('4.7'))
        self.assertFalse(events(r, 'climb_completed', 'A'))
        self.assertEqual(r['metrics']['A']['climbs_started'], 1)

    def test_zero_displacement_and_numerical_roundoff_do_not_cancel(self):
        for delta in ((0, 0, 0), ('-1e-30', 0, 0)):
            with self.subTest(delta=delta):
                r = run(attempt(), operations=[(200, {'delta': delta})])
                self.assertEqual(r['metrics']['A']['climbs_completed'], 1)
                self.assertFalse(events(r, 'climb_attachment_lost', 'A'))

    def test_before_corner_and_exact_corner_keep_the_correct_segment_momentum(self):
        for when, horizontal in (('318.749999', False), ('318.75', True)):
            with self.subTest(when=when):
                r = run(attempt(320), operations=[(when, {'delta': (-1, 0, 0)})])
                v = list(map(D, events(r, 'climb_interrupted', 'A')[0]['velocity_before_contact_mps']))
                self.assertAlmostEqual(v[0] if horizontal else v[2], D(32)/3, places=25)
                self.assertEqual(v[2] if horizontal else v[0], 0)
                self.assertFalse(events(r, 'climb_completed', 'A'))

    def test_displacement_just_before_completion_invalidates_late_completion(self):
        r = run(attempt(500), operations=[('449.999999', {'delta': (-3, 0, 0), 'velocity': (0, 0, 0)})])
        self.assertEqual(r['metrics']['A']['climbs_completed'], 0)
        self.assertEqual(r['metrics']['A']['climb_interruptions'], 1)
        self.assertFalse([e for e in r['pending_events'] if e['type'] in ('active_completed', 'movement_climb_corner')])

    def test_due_completion_precedes_displacement_tied_at_the_same_timestamp(self):
        r = run(attempt(500), operations=[(450, {'delta': (-3, 0, 0), 'velocity': (0, 0, 0)})])
        self.assertEqual(r['metrics']['A']['climbs_completed'], 1)
        self.assertEqual(r['metrics']['A']['climb_interruptions'], 0)
        self.assertFalse(events(r, 'climb_attachment_lost', 'A'))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]), 3)

    def test_displacement_at_horizon_is_settled_without_another_time_step(self):
        r = run(attempt(200), operations=[(200, {'delta': (-1, 0, 0), 'velocity': (0, 0, 0)})])
        self.assertEqual(D(r['run_until_ms']), 200)
        self.assertEqual(r['metrics']['A']['climb_interruptions'], 1)
        self.assertNotIn('climb_target', r['final_states']['A']['locomotion'])
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])

    def test_displacement_during_gathering_uses_existing_entry_gate_without_charge(self):
        r = run(attempt(400), operations=[(100, {'delta': (-1, 0, 0)})])
        self.assertFalse(events(r, 'climb_active_started', 'A'))
        self.assertFalse(events(r, 'climb_interrupted', 'A'))
        self.assertFalse(events(r, 'dyspnea_paid', 'A'))
        self.assertEqual(events(r, 'climb_rejected', 'A')[0]['reason'], 'outside_activation_range')

    def test_a_later_explicit_climb_can_start_after_displacement_and_landing(self):
        s = attempt(1200)
        climb(s, time=650)
        r = run(s, operations=[(200, {'delta': ('.1', 0, 0), 'velocity': (0, 0, 0)})])
        self.assertEqual(r['metrics']['A']['climbs_started'], 2)
        self.assertEqual(r['metrics']['A']['climbs_completed'], 1)
        self.assertEqual(r['metrics']['A']['climb_interruptions'], 1)
        self.assertGreater(D(events(r, 'climb_completed', 'A')[0]['time_ms']), 450)

    def test_queued_movement_waits_for_real_landing_after_interruption(self):
        s = attempt(1000)
        command(s, 'A', 180, 'walk')
        r = run(s, operations=[(200, {'delta': (-1, 0, 0), 'velocity': (0, 0, 0)})])
        landed = events(r, 'jump_landed', 'A')[0]
        walk = events(r, 'movement_active_started', 'A')[0]
        self.assertGreaterEqual(D(walk['time_ms']), D(landed['time_ms']))
        self.assertEqual(r['final_states']['A']['locomotion']['mode'], 'walking')
        self.assertLess(len(r['events']), 200)

    def test_other_climber_is_not_cancelled(self):
        s = attempt(800)
        s['encounter']['participants']['B']['position_m'] = ['7.4', 0]
        climb(s, actor='B')
        r = run(s, operations=[(200, {'delta': (-1, 0, 0), 'velocity': (0, 0, 0)})])
        self.assertEqual(r['metrics']['A']['climbs_completed'], 0)
        self.assertEqual(r['metrics']['B']['climbs_completed'], 1)
        self.assertFalse(events(r, 'climb_attachment_lost', 'B'))

    def test_cancellation_selects_body_action_while_independent_hands_are_busy(self):
        # Requirements are an explicit engineering variant; no extra ability is
        # granted. Verify selective cancellation for eligible parallel actions.
        effects = deepcopy(CURRENT)
        effects['action_ownership']['actions']['climb']['occupies'] = ['locomotion']
        s = attempt(900)
        s['encounter']['participants']['A']['character'] = '1E1'
        s['action_selection']['A'].update(abilities=['4'], start_ms=200, reload_when_empty=False)
        r = run(s, effects=effects, operations=[(330, {'delta': (-2, 0, 0), 'velocity': (0, 0, 0)})])
        self.assertEqual([e['action']['kind'] for e in events(r, 'controlled_action_cancelled', 'A')], ['climb'])
        self.assertEqual(len(events(r, 'beam_deployed', 'A')), 1)
        self.assertTrue(events(r, 'summoning_active_completed', 'A'))

    def test_deployed_beam_continues_after_its_owner_is_displaced_from_climb(self):
        s = scene(2000)
        s['encounter']['participants']['A']['character'] = '1E1'
        s['action_selection']['A'].update(abilities=['4'], start_ms=0, reload_when_empty=False)
        climb(s, time=700)
        clean = run(s)
        r = run(s, operations=[(900, {'delta': (-1, 0, 0), 'velocity': (0, 0, 0)})])
        self.assertEqual(len(events(r, 'climb_interrupted', 'A')), 1)
        self.assertAlmostEqual(D(r['final_states']['B']['hp']), D(clean['final_states']['B']['hp']), places=20)

    def test_displaced_climber_leaves_real_heat_volume_without_removing_the_beam(self):
        s = attempt(600)
        s['encounter']['participants']['B']['character'] = '1E1'
        s['action_selection']['B'].update(abilities=['4'], start_ms=0, reload_when_empty=False)
        r = run(s, operations=[(330, {'delta': (-10, 0, 0), 'velocity': (0, 0, 0)})])
        left = next(e for e in events(r, 'heat_exposure_left') if e['target'] == 'A')
        self.assertEqual(D(left['time_ms']), 330)
        self.assertEqual(len(events(r, 'beam_deployed', 'B')), 1)
        self.assertEqual(r['metrics']['A']['climbs_completed'], 0)
        self.assertLess(D(r['final_states']['A']['hp']), 8140)
        volume = next(v for v in r['volume_instances'] if v['id'] == left['volume_id'])
        deployment = events(r, 'beam_deployed', 'B')[0]
        self.assertTrue(volume['active'])
        activation = next(e for e in events(r, 'ability_started', 'B') if e['ability'] == '4')
        self.assertEqual(volume['id'], deployment['volume_id'])
        self.assertEqual((volume['actor'], volume['ability'], volume['action_id']),
                         ('B', '4', activation['action_id']))
        self.assertEqual(D(volume['expiry']) - D(volume['start']), 3000)
        self.assertGreater(D(volume['expiry']), D(r['run_until_ms']))
        self.assertNotIn('A', volume['eligible_targets'])

    def test_released_projectile_still_hits_after_owner_climb_is_displaced(self):
        s = scene(600, fire_at=0, target=(-240, 0))
        climb(s, time=120)
        profiles = deepcopy(PROFILES)
        profiles['1E2']['abilities']['1']['weapon_cooldown_ms'] = 100000
        r = run(s, profiles=profiles, operations=[(390, {'delta': (-1, 0, 0), 'velocity': (0, 0, 0)})])
        interrupted = events(r, 'climb_interrupted', 'A')[0]
        hit = events(r, 'projectile_body_collision', 'A')[0]
        self.assertLess(D(events(r, 'projectile_released', 'A')[0]['time_ms']), D(interrupted['time_ms']))
        self.assertGreater(D(hit['time_ms']), D(interrupted['time_ms']))
        self.assertTrue(events(r, 'bleeding_started'))
        self.assertGreater(D(r['damage_credit_totals']['A']['eligible_hp_dealt']), 0)

    def test_precision_observations_and_actor_order_preserve_displacement_outcome(self):
        s = attempt(800)
        ops = [(200, {'delta': (-1, 0, 0), 'velocity': (0, 0, 0)})]
        baseline = run(s, operations=ops)
        reversed_s = deepcopy(s)
        reversed_s['encounter']['participants'] = dict(reversed(list(s['encounter']['participants'].items())))
        for case, precision, interval in ((s, 50, 17), (reversed_s, 80, 113)):
            r = run(case, operations=ops, precision=precision, interval=interval)
            self.assertEqual(D(events(r, 'climb_interrupted', 'A')[0]['time_ms']), 200)
            self.assertAlmostEqual(D(events(r, 'jump_landed', 'A')[0]['time_ms']),
                                   D(events(baseline, 'jump_landed', 'A')[0]['time_ms']), places=20)
            self.assertEqual(r['metrics']['A']['climbs_completed'], 0)
            self.assertEqual(r['metrics']['A']['climb_interruptions'], 1)

    def test_unknown_attachment_mode_is_rejected_without_guessing(self):
        bad = deepcopy(CLIMB)
        bad['ongoing_attachment'] = {'mode': 'unknown'}
        with self.assertRaisesRegex(UnsupportedMechanicError, 'ongoing climb attachment'):
            run(attempt(), rules=bad)
