"""Exact baseline transition verification; no inferred standing/slide rules."""
from fractions import Fraction as F
import json
from pathlib import Path
import unittest

from combat_sim.mechanics.movement import LinearSpeedTransition, standing_to_walk_transition, stopping_slide_duration_ms


class LinearMovementTests(unittest.TestCase):
    def test_walk_to_run_exact_endpoint_and_distance(self):
        p=LinearSpeedTransition([0,0],[1,0],2,'6.4',150)
        self.assertEqual(p.acceleration_mps2,F(88,3))
        self.assertEqual(p.at(150).speed_mps,F(32,5))
        self.assertEqual(p.at(150).distance_m,F(63,100))
        self.assertEqual(p.at(150).position_m,(F(63,100),0))

    def test_run_to_walk_exact_endpoint_and_distance(self):
        p=LinearSpeedTransition([0,0],[1,0],'6.4',2,150)
        self.assertEqual(p.acceleration_mps2,-F(88,3))
        self.assertEqual(p.at(150).speed_mps,2)
        self.assertEqual(p.at(150).distance_m,F(63,100))

    def test_midpoint_uses_integrated_speed_not_endpoint_interpolation(self):
        p=LinearSpeedTransition([0,0],[1,0],2,'6.4',150)
        self.assertEqual(p.at(75).speed_mps,F(21,5))
        self.assertEqual(p.at(75).distance_m,F(93,400))

    def test_reverse_midpoint(self):
        p=LinearSpeedTransition([0,0],[1,0],'6.4',2,150)
        self.assertEqual(p.at(75).distance_m,F(159,400))

    def test_initial_state(self):
        p=LinearSpeedTransition([2,3],[0,-1],2,'6.4',150)
        self.assertEqual(p.at(0).position_m,(2,3))
        self.assertEqual(p.at(0).distance_m,0)
        self.assertEqual(p.at(0).speed_mps,2)

    def test_negative_world_direction(self):
        p=LinearSpeedTransition([10,3],[-1,0],2,'6.4',150)
        self.assertEqual(p.at(150).position_m,(F(937,100),3))

    def test_explicit_oblique_unit_direction(self):
        p=LinearSpeedTransition([0,0],[F(3,5),F(4,5)],2,'6.4',150)
        self.assertEqual(p.at(150).position_m,(F(189,500),F(63,125)))

    def test_fractional_millisecond_queries_are_exact(self):
        p=LinearSpeedTransition([0,0],[1,0],2,'6.4',150)
        a,b=F(1,3),F(2,3)
        expected=p.at(a).speed_mps*(b-a)/1000+p.acceleration_mps2*((b-a)/1000)**2/2
        self.assertEqual(p.at(b).distance_m-p.at(a).distance_m,expected)

    def test_query_order_does_not_change_motion(self):
        p=LinearSpeedTransition([0,0],[1,0],2,'6.4',150)
        end=p.at(150)
        for t in (137,20,75,0):p.at(t)
        self.assertEqual(p.at(150),end)

    def test_invalid_transition_inputs(self):
        for direction,start,end,duration in (([0,0],2,6,150),([1,1],2,6,150),([1,0],-1,2,150),
                                             ([1,0],2,-1,150),([1,0],2,6,0)):
            with self.assertRaises(ValueError):LinearSpeedTransition([0,0],direction,start,end,duration)

    def test_queries_outside_active_are_rejected(self):
        p=LinearSpeedTransition([0,0],[1,0],2,'6.4',150)
        for t in (-1,151):
            with self.assertRaises(ValueError):p.at(t)

    def test_current_character_profiles_retain_their_own_running_speeds(self):
        data=json.loads((Path(__file__).resolve().parents[1]/'data/movement/walk_run.json').read_text())
        expected={'1E1':(F(32,5),F(63,100)),'1E2':(F(32,5),F(63,100)),
            '1E3':(F(32,5),F(63,100)),
            '1E5':(F(7),F(27,40)),
            '2E4':(F(8),F(3,4)),'3E5':(F(8),F(3,4))}
        self.assertEqual(set(data['characters']),set(expected))
        for name,values in data['characters'].items():
            p=LinearSpeedTransition([0,0],[1,0],values['walking_speed_mps'],values['running_speed_mps'],values['walk_run_active_ms'])
            self.assertEqual((p.at(150).speed_mps,p.at(150).distance_m),expected[name])


class StandingAndStoppingTimingTests(unittest.TestCase):
    def setUp(self):
        root=Path(__file__).resolve().parents[1]
        self.profiles=json.loads((root/'data/movement/walk_run.json').read_text())['characters']

    def test_standing_to_walk_uses_stopping_mechanic(self):
        for profile in self.profiles.values():
            p=standing_to_walk_transition([0,0],[1,0],profile)
            self.assertEqual(p.duration_ms,60)
            self.assertEqual(p.acceleration_mps2,F(100,3))
            self.assertEqual(p.at(p.duration_ms).speed_mps,2)
            self.assertEqual(p.at(p.duration_ms).distance_m,F(3,50))

    def test_both_directions_share_duration_and_have_no_recovery_override(self):
        for profile in self.profiles.values():
            self.assertNotIn('stand_to_walk_recovery_divisor',profile)
            self.assertNotIn('recovery_value',profile)
            start=standing_to_walk_transition([0,0],[1,0],profile)
            self.assertEqual(start.duration_ms,stopping_slide_duration_ms(2,profile))

    def test_walk_to_stand_uses_stopping_rule(self):
        for profile in self.profiles.values():
            self.assertEqual(stopping_slide_duration_ms(profile['walking_speed_mps'],profile),60)
            self.assertNotEqual(stopping_slide_duration_ms(2,profile),F(200,3))

    def test_run_to_stand_uses_stopping_rule(self):
        expected={'1E1':192,'1E2':192,'1E3':192,'1E5':210,'2E4':240,'3E5':240}
        for name,profile in self.profiles.items():
            self.assertEqual(stopping_slide_duration_ms(profile['running_speed_mps'],profile),expected[name])

    def test_stopping_uses_current_speed_without_rounding(self):
        for profile in self.profiles.values():
            self.assertEqual(stopping_slide_duration_ms('1.25',profile),F(75,2))
            self.assertEqual(stopping_slide_duration_ms(0,profile),0)

    def test_invalid_stopping_speed_is_rejected(self):
        for profile in self.profiles.values():
            with self.assertRaises(ValueError):stopping_slide_duration_ms(-1,profile)

    def test_standing_to_walk_intermediate_state(self):
        for profile in self.profiles.values():
            p=standing_to_walk_transition([3,4],[0,-1],profile)
            state=p.at(30)
            self.assertEqual(state.speed_mps,1)
            self.assertEqual(state.position_m,(3,F(797,200)))

    def test_linear_stopping_is_explicitly_removed(self):
        from combat_sim.models import UnsupportedMechanicError
        with self.assertRaisesRegex(UnsupportedMechanicError,'Linear stopping is removed'):
            LinearSpeedTransition([0,0],[1,0],'6.4',0,192)
