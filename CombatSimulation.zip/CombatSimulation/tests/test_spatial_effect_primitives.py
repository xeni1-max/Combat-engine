"""Analytic membership boundaries and thermal memory, independent of combat policy."""
from dataclasses import FrozenInstanceError
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.effect_models import EffectSource, HeatExposure, HeatParameters
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.continuous_numeric import root_affine_integral
from combat_sim.mechanics.delayed_shield import DelayedShieldRecovery
from combat_sim.volume_geometry import column_cells


ZERO=(0,0,0)


def part(centre,size=(2,2,2),velocity=ZERO,acceleration=ZERO,size_rate=ZERO):
    return (Cuboid('part',centre,size),velocity,acceleration,size_rate)


class HeatColumnGeometryTests(unittest.TestCase):
    def cells(self,parts,duration,*,radius=1,blockers=()):
        with localcontext(Context(prec=50)):
            return column_cells(ZERO,radius,parts,blockers,D(duration))

    def test_crossing_has_distinct_entry_and_exit(self):
        cells=self.cells([part((-3,0,1),velocity=(1,0,0))],6)
        self.assertEqual([state for _,state in cells],[False,True,False])
        self.assertAlmostEqual(cells[1][0],1,places=27)
        self.assertAlmostEqual(cells[2][0],5,places=27)

    def test_corner_membership_uses_circle_not_expanded_square(self):
        self.assertFalse(self.cells([part(('1.8','1.8',0))],1)[0][1])
        self.assertTrue(self.cells([part(('1.6','1.6',0))],1)[0][1])

    def test_tangent_contact_without_exposure_has_no_positive_cell(self):
        # The corner touches the circle only at (3/5,4/5), at t=1.
        self.assertEqual(self.cells([part(('-2.4','4.8',1),velocity=(4,-3,0))],2),[(D(0),False)])

    def test_tangential_translation_on_boundary_remains_exposed(self):
        # A cuboid translating vertically remains in contact with the column.
        self.assertEqual(self.cells([part((2,0,1),velocity=(0,0,2))],1),[(D(0),True)])

    def test_acceleration_boundary_is_not_a_linear_approximation(self):
        cells=self.cells([part((-3,0,1),acceleration=(2,0,0))],3)
        self.assertEqual([state for _,state in cells],[False,True,False])
        self.assertAlmostEqual(cells[1][0],1,places=27)
        self.assertAlmostEqual(cells[2][0],D(5).sqrt(),places=25)

    def test_any_part_exposes_character_only_once(self):
        self.assertEqual(self.cells([part((0,0,1)),part((0,0,2))],1),[(D(0),True)])

    def test_vertical_cover_exit_and_height_boundary_are_analytic(self):
        roof=Cuboid('roof',(0,0,3),(2,2,1))
        cells=self.cells([part((0,0,1),size=(1,1,1),velocity=(2,0,0))],1,radius=5,blockers=[roof])
        self.assertEqual([state for _,state in cells],[False,True])
        self.assertAlmostEqual(cells[1][0],D('.75'),places=27)
        cells=self.cells([part((0,0,1),size=(1,1,1),velocity=(0,0,2))],2,blockers=[roof])
        self.assertEqual([state for _,state in cells],[False,True])
        self.assertAlmostEqual(cells[1][0],1,places=27)

    def test_pose_size_change_can_expose_top_above_cover(self):
        roof=Cuboid('roof',(0,0,2),(2,2,1))
        cells=self.cells([part((0,0,1),size=(1,1,1),size_rate=(0,0,2))],2,blockers=[roof])
        self.assertEqual([state for _,state in cells],[False,True])
        self.assertAlmostEqual(cells[1][0],1,places=27)

    def test_precision_refines_same_physical_boundary(self):
        results=[]
        for precision in (50,80):
            with localcontext(Context(prec=precision)):
                results.append(column_cells(ZERO,1,[part((-3,0,1),acceleration=(2,0,0))],[],D(3),precision=precision))
        self.assertEqual([s for _,s in results[0]],[s for _,s in results[1]])
        self.assertAlmostEqual(results[0][2][0],results[1][2][0],places=35)


class HeatMemoryTests(unittest.TestCase):
    def exposure(self):
        return HeatExposure('effect:1',EffectSource('A','4',1),'volume:1','B','actor','hp',HeatParameters(900),D(0),D(0))

    def test_exit_cools_and_reentry_resumes_remaining_memory(self):
        e=self.exposure()
        self.assertTrue(e.set_exposed(D(1000),False))
        self.assertEqual(e.expiry,1500)
        self.assertEqual(e.q_at(D(1200)),D('.6'))
        self.assertTrue(e.set_exposed(D(1200),True))
        self.assertIsNone(e.expiry)
        self.assertEqual(e.q_at(D(1600)),1)
        self.assertEqual(e.revision,2)

    def test_duplicate_membership_updates_do_not_reset_clock(self):
        e=self.exposure()
        self.assertFalse(e.set_exposed(D(1000),True))
        self.assertEqual(e.q_at(D(2000)),2)
        self.assertEqual(e.revision,0)

    def test_complete_curve_matches_confirmed_heat_total(self):
        with localcontext(Context(prec=50)):
            e=self.exposure()
            total=e.integral(D(900),D(0),D(3000))
            e.set_exposed(D(3000),False)
            total+=e.integral(D(900),D(3000),D(6000))
            self.assertAlmostEqual(total,2700*D(3).sqrt(),places=43)

    def test_affine_integrals_are_additive_and_clip_at_cooling_zero(self):
        with localcontext(Context(prec=50)):
            whole=root_affine_integral(D(900),D(1),D(1000),D(-2),D(1000),D(2000))
            pieces=sum((root_affine_integral(D(900),D(1),D(1000),D(-2),a,b)
                        for a,b in ((D(1000),D(1200)),(D(1200),D(1500)),(D(1500),D(2000)))),D(0))
            self.assertAlmostEqual(whole,pieces,places=43)
            self.assertEqual(whole,300)

    def test_sources_are_immutable_and_beams_have_independent_memory(self):
        a,b=self.exposure(),self.exposure()
        a.set_exposed(D(1000),False)
        self.assertEqual(a.q_at(D(1200)),D('.6'))
        self.assertEqual(b.q_at(D(1200)),D('1.2'))
        with self.assertRaises(FrozenInstanceError):a.source.actor='other'

    def test_delayed_shield_history_retains_affine_distribution(self):
        with localcontext(Context(prec=50)):
            recovery=DelayedShieldRecovery(20000,400)
            curve={'curve_kind':'affine_root_v1','coefficient':D(900),'q_reference':D(0),
                   'reference_ms':D(0),'slope_per_second':D(1)}
            recovery.add_curve(D(0),D(3000),1800*D(3).sqrt(),curve)
            self.assertEqual(recovery.eligible(D(20000)),0)
            self.assertEqual(recovery.eligible(D(21000)),600)
            self.assertLess(recovery.advance(D(0),D(21000)),400)
            recovered=recovery.recovered
            recovery.advance(D(21000),D(35000))
            self.assertGreater(recovery.recovered,recovered)
            self.assertAlmostEqual(recovery.recovered,1800*D(3).sqrt(),places=42)

    def test_exposure_rejects_backwards_clocks_and_nonboolean_membership(self):
        e=self.exposure();e.set_exposed(D(1000),False)
        with self.assertRaises(ValueError):e.set_exposed(D(999),True)
        with self.assertRaises(ValueError):e.q_at(D(999))
        with self.assertRaises(ValueError):e.set_exposed(D(1000),'inside')

    def test_unknown_recorded_curve_is_not_silently_legacy_heat(self):
        from combat_sim.mechanics.continuous_numeric import recorded_root_integral
        with self.assertRaisesRegex(ValueError,'Unknown'):
            recorded_root_integral({'curve_kind':'future_unimplemented'},D(0),D(1000))


if __name__=='__main__':unittest.main()
