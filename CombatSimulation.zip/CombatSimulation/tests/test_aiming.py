"""Analytic fastest-arc aim is checked by independent trajectory evaluation."""
from math import atan2, hypot, sqrt
import unittest

from combat_sim.mechanics.aiming import fastest_ballistic_launch
from combat_sim.mechanics.gravity import ProjectileTrajectory
from combat_sim.models import UnsupportedMechanicError


class FastestBallisticAimTests(unittest.TestCase):
    def assert_reaches(self,origin,target,speed):
        launch=fastest_ballistic_launch(origin,target,speed)
        state=ProjectileTrajectory(origin,launch.velocity_mps,launch.flight_time_s).at(launch.flight_time_s)
        for actual,expected in zip(state.position_m,target):self.assertAlmostEqual(actual,expected,places=9)
        self.assertAlmostEqual(hypot(*launch.velocity_mps),speed,places=9)
        return launch

    def test_qard_compensates_hand_to_torso_height_and_range(self):
        launch=self.assert_reaches([.4,-.1,1.055],[30,0,1.15],100)
        self.assertGreater(launch.velocity_mps[2],0)
        self.assertLess(launch.flight_time_s,.3)

    def test_selects_faster_of_two_same_height_arcs(self):
        speed=100;distance=30;g=9.81
        launch=self.assert_reaches([0,0,1],[distance,0,1],speed)
        high_time=sqrt(2*(speed**2+sqrt(speed**4-g*g*distance*distance))/(g*g))
        self.assertLess(launch.flight_time_s,high_time)
        self.assertLess(atan2(launch.velocity_mps[2],launch.velocity_mps[0]),.7853981634)

    def test_uphill_and_downhill_aim(self):
        self.assert_reaches([0,0,2],[30,4,12],100)
        self.assert_reaches([0,0,12],[30,-4,2],100)

    def test_arbitrary_horizontal_direction(self):
        self.assert_reaches([7,-3,2],[-20,-12,4],100)

    def test_vertical_target_above(self):
        launch=self.assert_reaches([0,0,1],[0,0,5],10)
        self.assertGreater(launch.velocity_mps[2],0)
        self.assertLess(launch.flight_time_s,10/9.81)

    def test_vertical_target_below_uses_downward_launch(self):
        launch=self.assert_reaches([0,0,5],[0,0,1],10)
        self.assertLess(launch.velocity_mps[2],0)

    def test_maximum_range_single_arc(self):
        speed=9.81
        launch=self.assert_reaches([0,0,1],[9.81,0,1],speed)
        self.assertAlmostEqual(launch.velocity_mps[0],launch.velocity_mps[2],places=8)

    def test_out_of_range_is_rejected(self):
        with self.assertRaisesRegex(UnsupportedMechanicError,'unreachable'):
            fastest_ballistic_launch([0,0,1],[2000,0,1],100)

    def test_unreachable_height_is_rejected(self):
        with self.assertRaises(UnsupportedMechanicError):fastest_ballistic_launch([0,0,1],[0,0,20],10)

    def test_zero_gravity_reduces_to_direct_aim(self):
        launch=fastest_ballistic_launch([0,0,0],[3,4,0],10,gravity_mps2=0)
        self.assertEqual(launch.velocity_mps,(6,8,0))
        self.assertEqual(launch.flight_time_s,.5)

    def test_short_shot_avoids_small_root_cancellation(self):
        launch=self.assert_reaches([0,0,1],[.000001,0,1],100)
        self.assertAlmostEqual(launch.flight_time_s,1e-8,places=18)

    def test_invalid_and_coincident_inputs_are_rejected(self):
        for speed in (0,-1,float('nan')):
            with self.assertRaises(ValueError):fastest_ballistic_launch([0,0,0],[1,0,0],speed)
        with self.assertRaises(UnsupportedMechanicError):fastest_ballistic_launch([0,0,0],[0,0,0],100)
