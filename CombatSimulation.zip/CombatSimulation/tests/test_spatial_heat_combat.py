"""Existing beam casts exercise shared movement, layer changes and world lifetimes."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.analysis import summarize
from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE
from combat_sim.models import UnsupportedMechanicError
from tests.test_mobile_combat import PROFILES,command,events,scenario
from tests.test_world_colliders_combat import run,wall


def beam_scene(horizon=5000):
    s=scenario(horizon)
    s['encounter']['participants']['A']['character']='1E1'
    s['action_selection']['A'].update(abilities=['4'],reload_when_empty=False,start_ms=0)
    return s


def roof(*,hp=None,duration=None):
    return wall('roof',x=30,hp=hp,z=2,size=(4,4,'.2'),duration=duration,
        blocking={'projectiles':True,'bodies':True,'areas':True})


def hp_coefficient():
    p=PROFILES['1E2']
    return (D(900)**2-(D(p['base_armor'])**2+D(p['resistances']['heat'])**2)/2)/900


def segment(coefficient,q0,q1,slope):
    return 2*coefficient*(q1*q1.sqrt()-q0*q0.sqrt())/(3*slope)


class SpatialHeatCombatTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=60));context.__enter__()
        self.addCleanup(context.__exit__,None,None,None)

    def test_complete_beam_preserves_confirmed_stationary_curve(self):
        r=run(beam_scene())
        with localcontext(Context(prec=50)):
            expected=D(PROFILES['1E2']['max_hp'])-3*hp_coefficient()*D(3).sqrt()
        self.assertAlmostEqual(D(r['final_states']['B']['hp']),expected,places=39)
        self.assertEqual(events(r,'beam_deployed')[0]['time_ms'],'292')
        self.assertEqual(len(r['volume_instances']),1)
        self.assertEqual(r['volume_instances'][0]['eligible_targets'],[])
        self.assertEqual(r['effect_instances'][0]['status'],'ended')
        self.assertEqual(r['effect_instances'][0]['ability'],'4')
        self.assertEqual(r['persistent_effect_rules']['mode'],'typed_heat_volumes_v1')
        self.assertEqual(r['metrics']['A']['dyspnea_paid'],'0')

    def test_running_target_leaves_fixed_column_then_cools(self):
        s=beam_scene();s['encounter']['participants']['B']['movement_direction']=[0,1]
        command(s,'B',0,'run')
        r=run(s)
        leave=events(r,'heat_exposure_left')[0]
        self.assertAlmostEqual(D(leave['time_ms']),D('1440.4375'),places=25)
        with localcontext(Context(prec=50)):
            exposure=(D(leave['time_ms'])-292)/1000
            expected=3*hp_coefficient()*exposure*exposure.sqrt()/3
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),expected,places=25)
        self.assertLess(D(events(r,'effect_expired')[0]['time_ms']),D(events(r,'volume_expired')[0]['time_ms']))
        self.assertAlmostEqual(D(events(r,'beam_deployed')[0]['location_m'][1]),D('-18.80824'),places=39)

    def test_later_entrant_is_detected_without_deployment_membership(self):
        s=beam_scene(3100)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(position_m=[33,-30],movement_direction=[0,1])
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        command(s,'C',0,'run')
        r=run(s)
        self.assertEqual(events(r,'beam_deployed')[0]['recipients'],['B'])
        enter=[e for e in events(r,'heat_exposure_entered') if e['target']=='C'][0]
        leave=[e for e in events(r,'heat_exposure_left') if e['target']=='C'][0]
        self.assertGreater(D(enter['time_ms']),292)
        self.assertLess(D(leave['time_ms']),3292)
        self.assertEqual(enter['q_seconds'],'0')
        self.assertLess(D(r['final_states']['C']['hp']),D(PROFILES['1E2']['max_hp']))

    def test_cover_reentry_resumes_memory_and_invalidates_old_cooling_timer(self):
        operations=[(1000,{'op':'spawn','definition':roof()}),(1100,{'op':'remove','id':'roof'})]
        r=run(beam_scene(),operations=operations)
        enters=events(r,'heat_exposure_entered')
        self.assertEqual(len(enters),2)
        self.assertEqual(enters[0]['effect_id'],enters[1]['effect_id'])
        self.assertEqual(enters[1]['time_ms'],'1100')
        self.assertEqual(D(enters[1]['q_seconds']),D('.508'))
        self.assertEqual(len(events(r,'effect_expired')),1)
        self.assertEqual(D(events(r,'effect_expired')[0]['time_ms']),4642)
        with localcontext(Context(prec=50)):
            c=hp_coefficient()
            expected=segment(c,D(0),D('.708'),D(1))+segment(c,D('.708'),D('.508'),D(-2))
            expected+=segment(c,D('.508'),D('2.7'),D(1))+segment(c,D('2.7'),D(0),D(-2))
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),expected,places=38)

    def test_reentry_after_full_cooling_creates_a_new_episode(self):
        r=run(beam_scene(),operations=[(1000,{'op':'spawn','definition':roof()}),(2000,{'op':'remove','id':'roof'})])
        enters=events(r,'heat_exposure_entered')
        self.assertEqual(len(enters),2)
        self.assertNotEqual(enters[0]['effect_id'],enters[1]['effect_id'])
        self.assertEqual(enters[1]['q_seconds'],'0')
        self.assertEqual(len(r['effect_instances']),2)

    def test_cover_change_at_horizon_settles_membership_without_extra_damage(self):
        s=beam_scene(1000)
        r=run(s,operations=[(1000,{'op':'spawn','definition':roof()})])
        control=run(s)
        self.assertEqual(r['final_states']['B']['hp'],control['final_states']['B']['hp'])
        self.assertEqual(r['volume_instances'][0]['eligible_targets'],[])
        self.assertFalse(r['effect_instances'][0]['exposed'])
        self.assertEqual(events(r,'heat_exposure_left')[0]['time_ms'],'1000')

    def test_cover_removal_at_horizon_starts_no_past_damage(self):
        s=beam_scene(1100);s['initial_colliders']=[roof()]
        r=run(s,operations=[(1100,{'op':'remove','id':'roof'})])
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(r['volume_instances'][0]['eligible_targets'],['B'])
        self.assertEqual(r['effect_instances'][0]['q_seconds'],'0')
        self.assertEqual(events(r,'heat_exposure_entered')[0]['time_ms'],'1100')

    def test_independent_casters_stack_with_distinct_sources(self):
        s=beam_scene(2000)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[0,-25]
        s['action_selection']['C']=deepcopy(s['action_selection']['A'])
        r=run(s)
        self.assertEqual(len(r['volume_instances']),2)
        effects=[e for e in r['effect_instances'] if e['target']=='B']
        self.assertEqual({e['actor'] for e in effects},{'A','C'})
        self.assertEqual(len({e['volume_id'] for e in effects}),2)
        with localcontext(Context(prec=50)):
            expected=segment(2*hp_coefficient(),D(0),D('1.708'),D(1))
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),expected,places=38)

    def test_friendly_fire_and_multi_target_expiry_order(self):
        s=beam_scene();s['encounter']['participants']['B']['position_m']=[6,-20]
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[6,-25]
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        s['action_selection']['C'].update(abilities=['4'],reload_when_empty=False)
        r=run(s)
        self.assertEqual(events(r,'beam_deployed')[0]['recipients'],['A','B','C'])
        self.assertEqual([e['target'] for e in events(r,'heat_exposure_left')],['A','B','C'])
        self.assertEqual(len(r['effect_instances']),3)
        self.assertTrue(all(D(f['hp'])<8140 for f in r['final_states'].values()))

    def test_jump_retains_xy_membership_without_resetting_thermal_clock(self):
        s=beam_scene();command(s,'B',1000,'jump')
        r=run(s);control=run(beam_scene())
        self.assertTrue(events(r,'jump_takeoff'))
        self.assertAlmostEqual(D(r['final_states']['B']['hp']),D(control['final_states']['B']['hp']),places=37)
        self.assertEqual(len(r['effect_instances']),1)
        self.assertEqual(len(events(r,'heat_exposure_entered')),1)

    def test_real_gunfire_changes_current_heat_defenses_without_resetting_memory(self):
        s=beam_scene(1500)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(team='A',position_m=[0,-25],facing='+x')
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        s['action_selection']['C']['start_ms']=700
        r=run(s)
        heat=[p for e in events(r,'continuous_damage_resolved') if e['target']=='B'
              for p in e['components'] if p['kind']=='heat']
        self.assertGreater(len({p['coefficient'] for p in heat}),1)
        self.assertEqual(len({p['effect_id'] for p in heat}),1)
        self.assertEqual({p['inputs']['reference_ms'] for p in heat},{'292'})
        self.assertLess(D(r['final_states']['B']['armor']),150)

    def test_caster_death_does_not_cancel_deployed_heat(self):
        s=beam_scene();s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=500
        r=run(s)
        death=events(r,'character_died','A')[0]
        self.assertGreater(D(death['time_ms']),292)
        self.assertLess(D(death['time_ms']),3292)
        self.assertEqual(len(events(r,'beam_deployed')),1)
        with localcontext(Context(prec=50)):
            expected=D(PROFILES['1E2']['max_hp'])-3*hp_coefficient()*D(3).sqrt()
        self.assertAlmostEqual(D(r['final_states']['B']['hp']),expected,places=36)
        self.assertEqual(r['volume_instances'][0]['actor'],'A')

    def test_controlled_summoning_cancellation_does_not_remove_released_volume(self):
        s=beam_scene()
        # This upper-body restriction begins after deployment through
        # the existing registry's ordinary source lifecycle (fixture below).
        from combat_sim.shared_engine import SharedEncounter
        from tests.test_mobile_combat import BODY,TERRAIN,MOVEMENT
        from tests.test_world_colliders_combat import CURRENT
        from tests.test_airborne_combat import JUMP
        class RestrictionFixture(SharedEncounter):
            def __init__(self,*args,**kwargs):
                super().__init__(*args,**kwargs);self.push(350,'fixture_restrict',{})
            def _process(self,kind,p):
                if kind=='fixture_restrict':
                    self.apply_action_restriction('A',source='freeze_probe',functions={'upper_body'},until_ms=D(1000))
                else:super()._process(kind,p)
        with localcontext(Context(prec=50)):
            r=RestrictionFixture(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,jump_definition=JUMP).run()
        self.assertEqual(events(r,'volume_expired')[0]['time_ms'],'3292')
        self.assertEqual(len(events(r,'beam_deployed')),1)
        self.assertLess(D(r['final_states']['B']['hp']),4000)

    def test_shield_break_starts_fresh_hp_exposure(self):
        s=beam_scene();s['encounter']['participants']['B']['initial_state']['shield']=500
        r=run(s)
        shield_effect,hp_effect=[e for e in r['effect_instances'] if e['target']=='B']
        self.assertEqual([shield_effect['mode'],hp_effect['mode']],['shield','hp'])
        start=D(hp_effect['start'])
        with localcontext(Context(prec=50)):
            t=(D(1500)/1800)**(D(2)/3)
            expected=D(PROFILES['1E2']['max_hp'])-hp_coefficient()*(3-t)**D('1.5')
        self.assertAlmostEqual(start,292+1000*t,places=21)
        self.assertAlmostEqual(D(r['final_states']['B']['hp']),expected,places=21)
        self.assertEqual(D(hp_effect['q_reference']),0)
        self.assertAlmostEqual(sum(D(loss['amount']) for loss in r['shield_loss_history']),500,places=25)
        self.assertTrue(all(loss['curve']['curve_kind']=='affine_root_v1' for loss in r['shield_loss_history']))

    def test_shield_residual_depletion_never_transfers_to_hp(self):
        s=beam_scene();s['encounter']['participants']['B']['initial_state']['shield']=3300
        r=run(s)
        self.assertGreater(D(events(r,'shield_broken')[0]['time_ms']),3292)
        self.assertEqual(D(r['final_states']['B']['hp']),D(PROFILES['1E2']['max_hp']))
        self.assertEqual(D(r['final_states']['B']['shield']),0)
        self.assertEqual(len(r['effect_instances']),1)
        self.assertEqual(events(r,'shield_residual_terminated')[0]['transferred_hp_damage'],0)

    def test_cover_burns_away_and_exposes_body_at_same_continuous_boundary(self):
        s=beam_scene();s['initial_colliders']=[roof(hp=1000)]
        r=run(s)
        self.assertEqual(events(r,'beam_deployed')[0]['recipients'],[])
        self.assertEqual(events(r,'beam_deployed')[0]['collider_recipients'],['roof'])
        removal=events(r,'world_collider_removed')[0]
        entry=[e for e in events(r,'heat_exposure_entered') if e['target']=='B'][0]
        self.assertEqual(entry['time_ms'],removal['time_ms'])
        self.assertEqual(r['world_collider_states']['roof']['status'],'destroyed')
        with localcontext(Context(prec=50)):
            burn_seconds=(D(3000)/1800)**(D(2)/3)
            expected=D(PROFILES['1E2']['max_hp'])-hp_coefficient()*(3-burn_seconds)**D('1.5')
        self.assertAlmostEqual(D(removal['time_ms']),292+1000*burn_seconds,places=21)
        self.assertAlmostEqual(D(r['final_states']['B']['hp']),expected,places=21)
        self.assertTrue(all(not e['character_recovery_credit'] for e in events(r,'world_collider_damaged')))

    def test_damageable_cover_receives_full_left_interval_before_expiry(self):
        s=beam_scene();s['initial_colliders']=[roof(hp=10000,duration=1292)]
        r=run(s)
        self.assertEqual(r['world_collider_states']['roof']['status'],'expired')
        self.assertAlmostEqual(D(r['world_collider_states']['roof']['hp']),9400,places=30)
        entry=[e for e in events(r,'heat_exposure_entered') if e['target']=='B'][0]
        self.assertEqual(entry['time_ms'],'1292')

    def test_ordinary_cubes_still_do_not_occlude_beam(self):
        s=beam_scene();s['initial_colliders']=[wall('roof',x=30,z=2,size=(4,4,'.2'),hp=None)]
        r=run(s)
        self.assertEqual(events(r,'beam_deployed')[0]['recipients'],['B'])
        self.assertFalse(events(r,'world_collider_continuous_damage'))

    def test_removing_cover_after_volume_expiry_cannot_start_heat(self):
        s=beam_scene();s['initial_colliders']=[roof()]
        r=run(s,operations=[(3500,{'op':'remove','id':'roof'})])
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(r['effect_instances'],[])
        self.assertEqual(events(r,'volume_expired')[0]['time_ms'],'3292')

    def test_weapon_and_lower_body_movement_can_overlap(self):
        s=beam_scene(700);command(s,'A',0,'walk')
        r=run(s)
        self.assertEqual(events(r,'movement_active_started','A')[0]['time_ms'],'0')
        self.assertEqual(events(r,'beam_deployed')[0]['time_ms'],'292')
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),1)

    def test_typed_bleed_preserves_projectile_and_action_attribution(self):
        s=scenario(1000,fire_at=0);s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        r=run(s)
        effects=[e for e in r['effect_instances'] if e['kind']=='bleeding']
        self.assertTrue(effects)
        self.assertTrue(all(e['actor']=='A' and e['ability']=='1' and e['projectile_id'].startswith('projectile:') for e in effects))
        self.assertLess(D(r['final_states']['B']['hp']),D(PROFILES['1E2']['max_hp']))

    def test_summary_exposes_independent_volume_and_effect_lifetimes(self):
        r=run(beam_scene(1500));summary=summarize(r)
        self.assertEqual(summary['persistent_effects']['active_instances'],1)
        self.assertEqual(D(summary['persistent_effects']['numerics']['membership_boundary_tolerance_ms']),D('1e-24'))
        volume=summary['persistent_effects']['volumes']['volume:1']
        self.assertEqual(volume['actor'],'A')
        self.assertEqual(volume['ability'],'4')
        self.assertEqual(volume['eligible_targets'],['B'])

    def test_historical_heat_recovery_model_remains_explicitly_guarded(self):
        s=beam_scene(26000)
        s['encounter']['participants']['B']['initial_state'].update(shield=4000,armor=1000)
        from tests.test_world_colliders_combat import CURRENT
        legacy=deepcopy(CURRENT);legacy.pop('heat_shield_coupling')
        for mode in ('binding_effects','grapple_break','grapple_casts','controlled_damage','continuous_effort'):legacy.pop(mode,None)
        with self.assertRaisesRegex(UnsupportedMechanicError,'regeneration overlapping ongoing heat'):
            run(s,effects=legacy)

    def test_precision_observations_and_participant_order_preserve_heat(self):
        s=beam_scene();s['initial_colliders']=[roof(hp=1000)]
        baseline=run(s)
        for precision,interval,reverse in ((50,37,False),(80,113,True)):
            with self.subTest(precision=precision,interval=interval):
                other=deepcopy(s)
                if reverse:other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
                r=run(other,precision=precision,interval=interval)
                self.assertAlmostEqual(D(r['final_states']['B']['hp']),D(baseline['final_states']['B']['hp']),places=20)
                self.assertAlmostEqual(D(events(r,'world_collider_removed')[0]['time_ms']),
                    D(events(baseline,'world_collider_removed')[0]['time_ms']),places=20)

    def test_moving_exposure_boundaries_do_not_depend_on_observations(self):
        s=beam_scene();s['encounter']['participants']['B']['movement_direction']=[0,1]
        command(s,'B',0,'run')
        baseline=run(s)
        for precision,interval in ((50,37),(80,113)):
            with self.subTest(precision=precision,interval=interval):
                r=run(s,precision=precision,interval=interval)
                self.assertAlmostEqual(D(r['final_states']['B']['hp']),D(baseline['final_states']['B']['hp']),places=23)
                self.assertAlmostEqual(D(events(r,'heat_exposure_left')[0]['time_ms']),
                    D(events(baseline,'heat_exposure_left')[0]['time_ms']),places=23)


if __name__=='__main__':unittest.main()
