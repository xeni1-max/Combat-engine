"""Actual native turns with finite, raised and living support in the shared engine."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from tests.test_turn_fields import run
from tests.test_native_turns import turn
from tests.test_actor_facing_combat import scene
from tests.test_terrain_support_combat import climb_scene,platform_scene
from tests.test_body_support_combat import scene as stack_scene
from tests.test_finite_ground_combat import scene as edge_scene
from tests.test_mobile_combat import command,events
from tests.test_world_colliders_combat import wall
from tests.test_grapple_links_combat import force
from tests.test_finite_ground_combat import driven
from combat_sim.orientation import YawFrame


def edge():
    s=edge_scene(800,x='249.8');s['id']='turning_finite_support'
    command(s,'A',0,'walk');turn(s,180,0);return s


def climbed():
    s=climb_scene(2000);s['id']='turning_climb_departure';turn(s,360,800);return s


def deck():
    s=platform_scene(700,x='20.95',velocity=0);s['id']='turning_partial_deck';turn(s,360,0);return s


def stack(which='both'):
    s=stack_scene(700);s['id']='turning_body_support'
    if which in ('upper','both'):turn(s,360,0,'A')
    if which in ('lower','both'):turn(s,-360,0,'B')
    return s


def rotation_loss():
    s=platform_scene(200,x='21.09',velocity=0);s['id']='rotation_only_support_loss'
    s['encounter']['participants']['A']['facing']={'yaw_degrees':45};turn(s,-45,0);return s


def lower_rotation_loss():
    s=stack_scene(200);s['id']='rotating_head_support_loss'
    s['spatial_interventions'][0]['changes'][0]['reference_m']=['30.25',-20,'2.625']
    s['encounter']['participants']['B']['facing']={'yaw_degrees':45};turn(s,-45,0,'B');return s


def falling_pair():
    s=stack();s['id']='coaccelerating_turning_support';s['encounter']['duration_ms']=200
    s['spatial_interventions']=[force(0,'A',reference=[30,-20,'4.625']),force(0,'B',reference=[30,-20,'2.875'])]
    return s


def sheet_case(kind):
    args={'return':dict(duration=1000,reference=[251,-20,2],velocity=(-2,0,0)),
          'underside':dict(duration=300,reference=[0,-20,-1],velocity=(0,0,3)),
          'edge':dict(duration=300,reference=['250.4',-20,0],velocity=(-2,0,0))}[kind]
    s=driven(**args);s['id']='turning_sheet_'+kind;turn(s,720,0);return s


def grazing_sheet():
    # Maximum left-foot reach, then rotate outward. The positive projection
    # is below the existing support/contact band; no vertical impact is due.
    angle='63.43494882292202';frame=YawFrame.from_degrees(angle,precision=80)
    with localcontext(Context(prec=90)):
        reach=D('.2')*D(frame.sine.numerator)/D(frame.sine.denominator)+D('.1')*D(frame.cosine.numerator)/D(frame.cosine.denominator)
        x=str(D(250)+reach-D('5e-21'))
    s=driven(100,reference=[x,-20,'.875'],velocity=(0,0,-1));s['id']='turning_grazing_sheet'
    s['encounter']['participants']['A']['facing']={'yaw_degrees':angle};turn(s,90,0);return s


class TurningSupportTests(unittest.TestCase):
    def conserved(self,r):
        damage=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-damage.amount(target=name)),D('1e-8'))

    def test_partial_floor_turn_is_supported_without_whole_body_containment(self):
        s=edge_scene(250,x='249.95');turn(s,90,0);r=run(s);self.conserved(r)
        self.assertTrue(events(r,'turn_completed'));self.assertFalse(events(r,'world_support_lost'))
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_walk_turn_crosses_actual_finite_support_boundary_once(self):
        r=run(edge());self.conserved(r)
        self.assertEqual(len(events(r,'world_support_lost','A')),1)
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
        self.assertFalse(events(r,'jump_takeoff'));self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_ordinary_climb_then_walk_and_turn_depart_and_land(self):
        r=run(climbed());self.conserved(r)
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertTrue(events(r,'world_support_lost','A'));self.assertTrue(events(r,'jump_landed','A'))
        self.assertFalse(events(r,'jump_takeoff','A'))

    def test_partial_raised_deck_can_keep_alternate_feet_while_turning(self):
        r=run(deck());self.conserved(r)
        self.assertTrue(events(r,'turn_completed'));self.assertFalse(events(r,'world_support_lost'))
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'deck')

    def test_adjacent_top_retains_support_during_walking_turn(self):
        s=platform_scene(700);s['id']='turning_alternate_support'
        s['initial_colliders'].append(wall('next_deck',x='21.8',z='.9',size=('1.8',)*3,hp=2000))
        turn(s,90,0);r=run(s);self.conserved(r)
        self.assertFalse(events(r,'world_support_lost'));self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'next_deck')

    def test_turning_on_static_body_keeps_actual_support_without_fake_impact(self):
        r=run(stack('upper'));self.conserved(r)
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'B')
        self.assertFalse(events(r,'body_contact'));self.assertFalse(events(r,'world_support_lost'))
        self.assertTrue(events(r,'turn_completed','A'))

    def test_both_turning_bodies_keep_one_vertical_support_response(self):
        r=run(stack());self.conserved(r)
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'B')
        self.assertEqual(len(events(r,'turn_completed')),2);self.assertFalse(events(r,'body_contact'))

    def test_lower_body_motion_and_turn_release_upper_to_native_gravity(self):
        s=stack('lower');s['encounter']['participants']['B']['movement_direction']=[-1,0]
        command(s,'B',0,'walk');r=run(s);self.conserved(r)
        self.assertTrue(events(r,'world_support_lost','A'));self.assertFalse(events(r,'jump_takeoff'))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),30)

    def test_real_fall_into_rotating_living_support_uses_native_landing(self):
        s=stack_scene(900,height='3.625');turn(s,720,0,'B');r=run(s);self.conserved(r)
        self.assertTrue(events(r,'jump_landed','A'));self.assertTrue(events(r,'body_contact'))
        self.assertEqual(events(r,'jump_landed','A')[0]['support_id'],'B')

    def test_precision_and_observations_keep_support_loss(self):
        a=run(edge());s=edge();s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        self.assertLess(abs(D(events(a,'world_support_lost')[0]['time_ms'])-D(events(b,'world_support_lost')[0]['time_ms'])),D('1e-8'))
        self.assertLess(abs(D(a['final_states']['A']['body_origin_m'][2])-D(b['final_states']['A']['body_origin_m'][2])),D('1e-8'))

    def test_rotation_alone_can_remove_last_static_witness(self):
        r=run(rotation_loss());self.conserved(r);lost=events(r,'world_support_lost','A')
        self.assertEqual(len(lost),1);self.assertGreater(D(lost[0]['time_ms']),0)
        self.assertLess(D(lost[0]['time_ms']),75);self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('21.09'))
        elapsed=(200-D(lost[0]['time_ms']))/1000
        self.assertLess(abs(D(r['final_states']['A']['body_origin_m'][2])-(D('2.675')-D('9.81')*elapsed**2/2)),D('1e-8'))
        self.assertFalse(events(r,'jump_takeoff'));self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_lower_rotation_can_withdraw_real_head_support(self):
        r=run(lower_rotation_loss());self.conserved(r)
        self.assertTrue(events(r,'world_support_lost','A'));self.assertTrue(events(r,'turn_completed','B'))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('30.25'))
        self.assertFalse(r['final_states']['A']['locomotion']['grounded']);self.assertFalse(events(r,'jump_takeoff'))

    def test_coaccelerating_turning_stack_keeps_relative_height_and_one_gravity(self):
        r=run(falling_pair());self.conserved(r)
        a=D(r['final_states']['A']['body_origin_m'][2]);b=D(r['final_states']['B']['body_origin_m'][2])
        self.assertLess(abs(a-b-D('1.75')),D('1e-8'))
        self.assertLess(abs(b-(D('2.875')-D('9.81')*D('.2')**2/2)),D('1e-8'))
        self.assertFalse(events(r,'body_contact'));self.assertTrue(r['body_support_contacts'])

    def test_support_expiry_during_turn_releases_once_without_a_jump_fee(self):
        s=platform_scene(300,x=20,velocity=0,expiry=100);turn(s,360,0);r=run(s);self.conserved(r)
        self.assertEqual(len(events(r,'world_support_lost','A')),1)
        self.assertEqual(D(events(r,'world_support_lost','A')[0]['time_ms']),100)
        self.assertFalse(events(r,'jump_takeoff'));self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_crouch_and_turn_preserve_actual_platform_feet(self):
        s=deck();command(s,'A',0,'crouch');r=run(s,interval=17);self.conserved(r)
        self.assertEqual(r['metrics']['A']['crouches_completed'],1);self.assertTrue(events(r,'turn_completed'))
        self.assertFalse(events(r,'world_support_lost'));self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),D('1.8'))

    def test_all_six_scaled_profiles_can_turn_on_partial_floor(self):
        for character in ('1E1','1E2','1E3','1E5','2E4','3E5'):
            with self.subTest(character=character):
                s=edge_scene(200,x='249.95',character=character);turn(s,90,0);r=run(s);self.conserved(r)
                self.assertTrue(events(r,'turn_completed'));self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_turning_return_from_above_lands_on_real_sheet(self):
        r=run(sheet_case('return'));self.conserved(r)
        self.assertEqual(len(events(r,'jump_landed','A')),1);self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_turning_underside_impact_does_not_establish_ground_support(self):
        r=run(sheet_case('underside'));self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertFalse(events(r,'jump_landed'))
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])

    def test_turning_finite_edge_intercepts_a_straddling_body(self):
        r=run(sheet_case('edge'));self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertFalse(events(r,'jump_landed'))
        self.assertTrue(events(r,'turn_cancelled'))

    def test_outgoing_subresolution_floor_graze_does_not_invent_vertical_impact(self):
        r=run(grazing_sheet());self.conserved(r)
        self.assertFalse(events(r,'body_contact'));self.assertFalse(events(r,'jump_landed'))
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])


if __name__=='__main__':unittest.main()
