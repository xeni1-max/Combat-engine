"""Actual authored dashes through the shared action, flight and contact clock."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.grapple import shared_velocity
from combat_sim.models import UnsupportedMechanicError
from tests.test_grapple_casts_combat import scene as base_scene,run,RULES
from tests.test_grapple_links_combat import force,pos,vel
from tests.test_mobile_combat import PROFILES,command,events
from tests.test_world_colliders_combat import wall


def scene(duration=1200,character='1E5',abilities=('3',),distance=30):
    s=base_scene(duration,abilities,distance)
    s['id']='authored_body_dash'
    s['encounter']['participants']['A']['character']=character
    return s


def grab_before_dash(s):
    # Engineering setup: let the real hand-controlled grab make contact before
    # locomotion is available. Priority alone does not serialize free resources.
    s.setdefault('initial_restrictions',[]).append({'target':'A','source':'fixture:grab_before_dash',
        'functions':['lower_body'],'duration_ms':200})
    return s


class BodyDashCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        for actor,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=actor)
            self.assertLess(abs(supplied-D(r['final_states'][actor]['hp'])-ledger.amount(target=actor)),D('1e-8'))

    def test_1e5_actual_away_dash_range_phases_cost_and_cooldown(self):
        r=run(scene());launch=r['body_dash_launches'][0]
        self.assertEqual((D(launch['launched_at_ms']),D(launch['active_end_ms'])),(140,290))
        self.assertEqual(pos(r,'A'),(D('-13.5'),-20,D('1.1375')));self.assertEqual(vel(r,'A'),(0,0,0))
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),5340)
        paid=[e for e in events(r,'dyspnea_paid') if e['actor']=='A']
        self.assertEqual(len(paid),1);self.assertEqual((D(paid[0]['time_ms']),D(paid[0]['amount'])),(140,D('6.25')))
        self.assertFalse(r['final_states']['A']['owned_actions']);self.conserved(r)

    def test_2e4_uses_the_same_delivery_with_its_own_range_and_cooldown(self):
        r=run(scene(character='2E4'));launch=r['body_dash_launches'][0]
        self.assertEqual(pos(r,'A'),(14,-20,D('.875')))
        self.assertEqual(D(launch['free_velocity_mps'][2]),D(PROFILES['2E4']['running_speed_mps'])/2)
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),2990)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('6.25'));self.conserved(r)

    def test_active_completion_does_not_end_flight_or_pay_landing_early(self):
        r=run(scene(400));self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
        self.assertFalse(r['final_states']['A']['owned_actions'])
        self.assertTrue(events(r,'body_dash_active_completed')[0]['airborne'])
        self.assertFalse(events(r,'body_launch_landed'))
        full=run(scene());land=events(full,'body_launch_landed')[0]
        self.assertAlmostEqual(D(land['time_ms']),140+D(7000)/D('9.81'),places=18)
        self.assertEqual(land['self_effects'],{'disorientation':'120','instability':'160'})

    def test_own_dash_keeps_both_hands_and_can_gather_an_independent_attack(self):
        r=run(scene(150,abilities=('3','1'),distance='1.1'))
        starts=[e for e in events(r,'ability_started') if e['actor']=='A']
        self.assertEqual({e['ability'] for e in starts},{'1','3'})
        self.assertTrue(all(D(e['time_ms'])==0 for e in starts))
        owners=r['final_states']['A']['owned_actions']
        dash=next(o for o in owners if o['action']['kind']=='ballistic_dash')
        self.assertEqual(dash['occupies'],['locomotion'])
        other=next(o for o in owners if o['action']['kind']=='component_melee')
        self.assertEqual(other['action']['phase'],'active')
        self.assertEqual(r['final_states']['A']['hands_m'],PROFILES['1E5']['initial_hand_positions_m'])

    def test_solid_contact_uses_continuous_sweep_and_stops_only_normal_motion(self):
        s=scene();s['initial_colliders']=[wall('dash_wall',x=-3,hp=None,size=('.2',4,4),z=2)]
        r=run(s);contacts=events(r,'body_contact')
        self.assertTrue(contacts);self.assertLess(D(contacts[0]['time_ms']),290)
        self.assertAlmostEqual(pos(r,'A')[0],D('-2.66'),places=18)
        self.assertEqual(pos(r,'A')[2],D('1.1375'));self.assertEqual(len(events(r,'body_launch_landed')),1)
        self.assertGreater(D(r['metrics']['A']['collision_stops']),0);self.conserved(r)

    def test_real_character_contact_cannot_tunnel_or_become_fake_attack_damage(self):
        s=scene();s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=[-3,-20]
        s['encounter']['participants']['C']['team']='A'
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s);self.assertTrue([e for e in events(r,'body_contact') if e['second']=='C'])
        self.assertEqual(DamageLedger.from_record(r['applied_hp_history']).amount(),0)
        self.assertEqual(len(events(r,'body_launch_landed')),1);self.conserved(r)

    def test_ceiling_impact_uses_gravity_and_one_actual_landing(self):
        # Preserve the original0.25 m overhead gap for taller1E5.
        s=scene();s['initial_colliders']=[wall('ceiling',x=-5,hp=None,size=(30,4,'.2'),z='2.625')]
        r=run(s);self.assertEqual(len(events(r,'body_launch_landed')),1)
        self.assertLess(D(events(r,'body_launch_landed')[0]['time_ms']),D(854))
        self.assertEqual(pos(r,'A')[2],D('1.1375'));self.conserved(r)

    def test_actual_climb_then_dash_falls_from_the_cube_with_a_real_longer_range(self):
        s=scene(1900);s['encounter']['participants']['A']['position_m']=['4.8',0]
        s['action_selection']['A']['start_ms']=500
        s['movement_script'].append({'actor':'A','at_ms':0,'action':'climb','target':'cube_1'})
        r=run(s);launch=r['body_dash_launches'][0];land=events(r,'body_launch_landed')[0]
        self.assertEqual(D(launch['reference_m'][2]),D('2.9375'))
        self.assertGreater(D(land['time_ms'])-D(launch['launched_at_ms']),D(launch['nominal_same_height_duration_ms']))
        horizontal=sum((D(a)-D(b))**2 for a,b in zip(land['body_origin_m'][:2],launch['reference_m'][:2])).sqrt()
        self.assertGreater(horizontal,D('13.5'));self.assertEqual(pos(r,'A')[2],D('1.1375'))
        self.assertEqual(land['support_id'],'ground');self.conserved(r)

    def test_queued_walk_waits_for_actual_landing_and_resumes_on_the_same_clock(self):
        s=scene();command(s,'A',300,'walk');r=run(s)
        land=D(events(r,'body_launch_landed')[0]['time_ms'])
        movement=events(r,'movement_active_started')
        self.assertTrue(movement);self.assertTrue(all(D(e['time_ms'])>=land for e in movement))
        self.assertGreater(pos(r,'A')[0],D('-13.5'))

    def test_running_launch_resumes_ground_pace_without_adding_that_speed_to_range(self):
        s=scene(1600);s['action_selection']['A']['start_ms']=600;command(s,'A',0,'run')
        r=run(s);launch=r['body_dash_launches'][0]
        self.assertEqual(launch['self_effects'],{'disorientation':'96.0','instability':'96.0'})
        self.assertEqual(D(launch['nominal_range_m']),D('13.5'))
        self.assertEqual(D(r['final_states']['A']['locomotion']['nominal_speed_mps']),7)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'running')
        self.assertEqual(len(events(r,'body_launch_landed')),1)
        landed=events(r,'body_launch_landed')[0]
        self.assertAlmostEqual(D(landed['body_origin_m'][0])-D(launch['reference_m'][0]),D('-13.5'),places=18)

    def test_sprint_is_replaced_at_launch_without_continuing_its_effort(self):
        s=scene(1600);s['action_selection']['A']['start_ms']=1000;command(s,'A',0,'sprint')
        r=run(s);launch=r['body_dash_launches'][0];time=D(launch['launched_at_ms'])
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'running')
        self.assertFalse([e for e in events(r,'sprint_dyspnea_gained') if D(e['interval_start_ms'])>=time])

    def test_actual_hold_is_kept_through_dash_and_lands_as_one_group(self):
        r=run(grab_before_dash(scene(1400,abilities=('2','3'),distance='1.1')))
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertEqual(vel(r,'A'),vel(r,'B'));self.assertEqual(vel(r,'A'),(0,0,0))
        self.assertAlmostEqual(pos(r,'B')[0]-pos(r,'A')[0],D('1.1'),places=18)
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),D(r['final_states']['B']['locomotion']['feet_z_m']))
        launch=r['body_dash_launches'][0]
        expected=shared_velocity(tuple(map(D,launch['free_velocity_mps'])),(0,0,0),
            first_max_hp=20000,first_armor=350,second_max_hp=9080,second_armor=165)
        for x,y in zip(map(D,launch['shared_velocity_mps']),expected):self.assertAlmostEqual(x,y,places=18)
        self.assertEqual(len(events(r,'body_launch_landed')),1);self.conserved(r)

    def test_external_force_cancels_control_but_keeps_the_paid_landing_obligation(self):
        s=scene(1500);s['spatial_interventions']=[force(200,'A',[2,0,3])]
        r=run(s);self.assertFalse(events(r,'body_dash_active_completed'))
        land=events(r,'body_launch_landed');self.assertEqual(len(land),1)
        self.assertEqual(land[0]['self_effects'],{'disorientation':'120','instability':'160'})
        self.assertEqual(len([e for e in events(r,'dyspnea_paid') if e['actor']=='A']),1)
        self.conserved(r)

    def test_external_ground_destination_keeps_landing_until_real_support_contact(self):
        s=scene(500);s['spatial_interventions']=[force(200,'A',[0,0,0],reference=[-5,-20,'1.1375'])]
        r=run(s);land=events(r,'body_launch_landed')
        self.assertEqual(len(land),1);self.assertEqual(D(land[0]['time_ms']),200)
        self.assertEqual(pos(r,'A'),(-5,-20,D('1.1375')))

    def test_lower_body_restriction_before_takeoff_has_no_cost_or_cooldown(self):
        r=run(scene(500),operations=[(100,{'op':'restriction','functions':['lower_body']})])
        self.assertNotIn('body_dash_launches',r);self.assertFalse(events(r,'body_launch_landed'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),0)

    def test_restriction_after_takeoff_preserves_ballistic_motion_and_landing(self):
        r=run(scene(),operations=[(200,{'op':'restriction','functions':['lower_body']})])
        self.assertEqual(pos(r,'A'),(D('-13.5'),-20,D('1.1375')))
        self.assertFalse(events(r,'body_dash_active_completed'));self.assertEqual(len(events(r,'body_launch_landed')),1)

    def test_real_gun_death_during_active_cancels_control_and_all_future_landing(self):
        s=scene(1200);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['B']['character']='1E2';s['action_selection']['B'].update(abilities=['1'],start_ms=0)
        r=run(s);death=D(r['final_states']['A']['died_at_ms'])
        self.assertGreater(death,140);self.assertLess(death,290)
        self.assertEqual(len(r['body_dash_launches']),1);self.assertFalse(events(r,'body_launch_landed'))
        self.assertFalse(r['final_states']['A']['owned_actions']);self.conserved(r)

    def test_another_life_cannot_inherit_a_landing_obligation(self):
        r=run(scene(),operations=[(200,{'op':'kill'}),(300,{'op':'revive','hp':1000})])
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertFalse(events(r,'body_launch_landed'))
        self.assertFalse(events(r,'body_dash_active_completed'))

    def test_unpaid_dash_cancels_safely_during_real_hold_and_answered_break(self):
        s=grab_before_dash(scene(800,abilities=('2','3'),distance='1.1'))
        s['encounter']['participants']['A']['initial_state']['dyspnea']=75
        s['encounter']['participants']['B']['initial_state']['dyspnea']=100
        s['control_script']=[{'actor':'B','at_ms':190,'command':'break'},
            {'actor':'A','at_ms':200,'command':'continue_grapple'}]
        r=run(s)
        failures=[e for e in events(r,'dyspnea_payment_rejected') if e['ability']=='3']
        self.assertTrue(failures);self.assertNotIn('body_dash_launches',r)
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),0)
        self.assertTrue(r['grapple_break_contests']);self.conserved(r)

    def test_precision_observation_and_participant_order_preserve_actual_results(self):
        s=scene(1400,abilities=('2','3'),distance='1.1');baseline=run(s,interval=100)
        reverse=deepcopy(s);reverse['encounter']['participants']=dict(reversed(list(reverse['encounter']['participants'].items())))
        other=run(reverse,precision=80,interval=137)
        for actor in ('A','B'):
            for key in ('hp','armor','shield','dyspnea','instability','disorientation'):
                self.assertLess(abs(D(baseline['final_states'][actor][key])-D(other['final_states'][actor][key])),D('1e-8'))
            for a,b in zip(pos(baseline,actor),pos(other,actor)):self.assertLess(abs(a-b),D('1e-18'))
        self.assertEqual(len(events(baseline,'body_launch_landed')),len(events(other,'body_launch_landed')))
        self.assertFalse(baseline['grapple_holds']);self.assertTrue(events(baseline,'melee_missed'))
        self.conserved(baseline);self.conserved(other)

    def test_missing_body_requirements_reject_before_running(self):
        rules=deepcopy(RULES);rules['action_ownership']['actions'].pop('ballistic_dash')
        with self.assertRaises(UnsupportedMechanicError):run(scene(),rules=rules)

    def test_cooldown_allows_another_actual_dash_with_a_new_landing_receipt(self):
        r=run(scene(6400));launches=r['body_dash_launches']
        self.assertEqual(len(launches),2);self.assertEqual([D(l['launched_at_ms']) for l in launches],[140,5480])
        self.assertEqual(len(events(r,'body_launch_landed')),2)
        self.assertAlmostEqual(pos(r,'A')[0],D(-27),places=18);self.conserved(r)

    def test_real_beam_shield_hp_and_exposure_boundaries_compose_with_dash_flight(self):
        s=scene(1600);s['encounter']['participants']['A']['initial_state']['shield']=100
        s['encounter']['participants']['C']={'character':'1E1','team':'B','position_m':[30,-18],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['4'],start_ms=0)
        r=run(s);self.assertEqual(len(events(r,'body_launch_landed')),1)
        self.assertEqual(D(r['final_states']['A']['shield']),0)
        self.assertGreater(DamageLedger.from_record(r['applied_hp_history']).amount(target='A'),0)
        self.conserved(r)

    def test_actual_pause_area_suspends_dash_cooldown_until_physical_exit(self):
        s=scene(1200);s['encounter']['participants']['B']['character']='1E2'
        s['action_selection']['B'].update(abilities=['2'],start_ms=0)
        results=[run(s,interval=100),run(s,interval=137,precision=80)]
        for r in results:
            entered=next(e for e in events(r,'cooldown_pause_entered') if e['target']=='A')
            left=next(e for e in events(r,'cooldown_pause_left') if e['target']=='A')
            self.assertEqual(D(entered['time_ms']),200)
            self.assertLess(D(left['time_ms']),D(events(r,'body_launch_landed')[0]['time_ms']))
            ready=D(r['final_states']['A']['ability_ready_at_ms']['3'])
            self.assertLess(abs(ready-(5340+D(left['time_ms'])-200)),D('1e-18'))
            self.assertEqual(len(events(r,'body_launch_landed')),1);self.conserved(r)
        self.assertLess(abs(D(results[0]['final_states']['A']['ability_ready_at_ms']['3'])-
            D(results[1]['final_states']['A']['ability_ready_at_ms']['3'])),D('1e-18'))


if __name__=='__main__':unittest.main()
