import unittest
from fractions import Fraction

from combat_sim.mechanics.slash import (
    armor_reduction, bleeding_damage_between, bleeding_damage_rate, calculate_impact, post_mitigation_damage,
    raw_armor_reduction, raw_post_mitigation_damage,
)


class SlashDamageTests(unittest.TestCase):
    def test_combined_impact_uses_pre_hit_armor_for_damage_and_armor_loss(self):
        impact = calculate_impact(440, 150, 40, 0)
        self.assertEqual(impact.pre_hit_armor, 150)
        self.assertEqual(impact.hp_damage, Fraction(825, 2))
        self.assertEqual(impact.armor_loss, Fraction(26429, 3080))

    def test_combined_impact_uses_only_shield_overflow_in_both_equations(self):
        impact = calculate_impact(440, 150, 40, 100)
        self.assertEqual(impact.shield_damage, 100)
        self.assertEqual(impact.shield_after, 0)
        self.assertEqual(impact.damage_left_after_shield, 340)
        self.assertEqual(impact.hp_damage, Fraction(5175, 17))
        self.assertEqual(impact.armor_loss, Fraction(15509, 2380))

    def test_fully_absorbed_and_zero_damage_impacts_skip_undefined_formulas(self):
        for damage, shield, after in ((440, 500, 60), (0, 100, 100)):
            with self.subTest(damage=damage, shield=shield):
                impact = calculate_impact(damage, 150, 40, shield)
                self.assertEqual(impact.shield_after, after)
                self.assertEqual(impact.damage_left_after_shield, 0)
                self.assertEqual(impact.hp_damage, 0)
                self.assertEqual(impact.armor_loss, 0)

    def test_2e4_unmodified_thrust_formula_values_against_150_armor(self):
        # Formula inputs only: raw d=440, a=150, p=40; no impact order chosen.
        self.assertEqual(post_mitigation_damage(440, 150, 40), Fraction(825, 2))
        self.assertEqual(armor_reduction(440, 150), Fraction(26429, 3080))

    def test_slash_armor_loss_uses_documented_shared_formula_and_zero_floor(self):
        self.assertEqual(armor_reduction(300, 150), Fraction(159, 28))
        self.assertEqual(raw_armor_reduction(300, 400), Fraction(-2, 21))
        self.assertEqual(armor_reduction(300, 400), 0)

    def test_slash_armor_loss_rejects_undefined_and_negative_inputs(self):
        with self.assertRaisesRegex(ValueError, "d=0"):
            armor_reduction(0, 150)
        for values in ((-1, 0), (1, -1)):
            with self.subTest(values=values), self.assertRaisesRegex(ValueError, "nonnegative"):
                armor_reduction(*values)

    def test_representative_mitigated_hit(self):
        self.assertEqual(post_mitigation_damage(300, 150, 50), Fraction(800, 3))

    def test_piercing_beyond_armor_keeps_effective_armor_at_zero(self):
        self.assertEqual(post_mitigation_damage(100, 10, 10), 100)
        self.assertEqual(post_mitigation_damage(100, 10, 30), 100)
        self.assertEqual(post_mitigation_damage(100, 0, 40), 100)

    def test_negative_final_damage_is_floored(self):
        self.assertEqual(raw_post_mitigation_damage(100, 200, 0), -300)
        self.assertEqual(post_mitigation_damage(100, 200, 0), 0)

    def test_zero_damage_denominator_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "d=0"):
            post_mitigation_damage(0, 0, 0)

    def test_negative_inputs_are_rejected(self):
        for damage, armor, piercing in ((-1, 0, 0), (1, -1, 0), (1, 0, -1)):
            with self.subTest(damage=damage, armor=armor, piercing=piercing):
                with self.assertRaisesRegex(ValueError, "nonnegative"):
                    post_mitigation_damage(damage, armor, piercing)


class BleedingRateTests(unittest.TestCase):
    def test_continuous_bleed_integral_for_one_full_effect(self):
        self.assertEqual(bleeding_damage_between(Fraction(825, 2), 0, 8), Fraction(165, 4))
        self.assertEqual(bleeding_damage_between(Fraction(825, 2), 0, 1), Fraction(2475, 256))
        self.assertEqual(bleeding_damage_between(Fraction(825, 2), 1, 2), Fraction(2145, 256))
        self.assertEqual(bleeding_damage_between(Fraction(825, 2), 2, 8), Fraction(1485, 64))

    def test_integral_clips_at_expiry_and_handles_zero_length(self):
        self.assertEqual(bleeding_damage_between(320, 0, 100), 32)
        self.assertEqual(bleeding_damage_between(320, 8, 100), 0)
        self.assertEqual(bleeding_damage_between(320, 4, 4), 0)
        with self.assertRaises(ValueError):
            bleeding_damage_between(320, 2, 1)

    def test_known_rates_in_seconds(self):
        self.assertEqual(bleeding_damage_rate(320, 0), 8)
        self.assertEqual(bleeding_damage_rate(320, 4), 4)

    def test_fractional_2e4_formula_example_is_exact(self):
        # Given y=412.5, b(0)=10.3125; b(0.25)=9.990234375 DPS.
        self.assertEqual(bleeding_damage_rate(Fraction(825, 2), 0), Fraction(165, 16))
        self.assertEqual(bleeding_damage_rate(Fraction(825, 2), Fraction(1, 4)), Fraction(5115, 512))

    def test_rate_reaches_zero_at_eight_seconds_and_does_not_turn_negative(self):
        self.assertEqual(bleeding_damage_rate(320, Fraction(7999, 1000)), Fraction(1, 1000))
        self.assertEqual(bleeding_damage_rate(320, 8), 0)
        self.assertEqual(bleeding_damage_rate(320, 1000000), 0)

    def test_zero_damage_has_no_bleed_rate(self):
        self.assertEqual(bleeding_damage_rate(0, 0), 0)
        self.assertEqual(bleeding_damage_rate(0, 4), 0)

    def test_negative_inputs_are_rejected(self):
        for values in ((-1, 0), (1, -1)):
            with self.subTest(values=values), self.assertRaisesRegex(ValueError, "nonnegative"):
                bleeding_damage_rate(*values)


if __name__ == "__main__":
    unittest.main()
