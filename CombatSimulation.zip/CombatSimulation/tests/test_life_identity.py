"""Life identity, immutable history filters and stopped-clock resumption."""
from copy import deepcopy
from decimal import Decimal as D
import unittest

from combat_sim.battle_models import BattleAction, Combatant
from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.cooldown import CooldownClock
from combat_sim.mechanics.damage_ledger import BleedDose, DamageContribution, DamageLedger
from combat_sim.mechanics.delayed_shield import DelayedShieldRecovery
from combat_sim.projectile_entities import ProjectileRegistry


class LifeIdentityTests(unittest.TestCase):
    def test_source_life_is_immutable_and_positive(self):
        source=EffectSource('A','1',1,life_generation=2)
        self.assertEqual(source.life_record(),{'source_life_generation':2})
        with self.assertRaises(AttributeError):source.life_generation=3
        for value in (0,-1,True,1.0,'1'):
            with self.subTest(value=value),self.assertRaises(ValueError):
                EffectSource('A','1',1,life_generation=value)

    def test_history_sums_actor_windows_across_lives_and_can_filter_each_life(self):
        ledger=DamageLedger()
        for receipt,time,owner,target,amount in (
                ('first',100,1,1,100),('old_source_after_revival',300,1,2,40),('new_source',400,2,2,60)):
            source=EffectSource('A','1',1 if owner==1 else 2,life_generation=owner)
            ledger.record_loss(receipt,'T',time,time,[DamageContribution(source,D(amount),'slash',True)],amount,
                target_life_generation=target)
        self.assertEqual(ledger.amount(actor='A',window_ms=10000,eligible_only=True),200)
        self.assertEqual(ledger.amount(actor='A',source_life_generation=1),140)
        self.assertEqual(ledger.amount(target='T',target_life_generation=2),100)
        self.assertEqual(ledger.amount(source_life_generation=1,target_life_generation=2),40)
        self.assertEqual(ledger.amount(end=400,window_ms=300),100)

    def test_continuous_history_retains_source_and_recipient_lives_after_reload(self):
        ledger=DamageLedger()
        source=EffectSource('A','1',4,'projectile:1',1)
        contribution=DamageContribution(source,D(100),'bleeding',True,BleedDose(1000,0),effect_id='bleed:1')
        ledger.record_loss('bleed','T',0,8000,[contribution],100,target_life_generation=2)
        restored=DamageLedger.from_record(deepcopy(ledger.record()))
        self.assertEqual(restored.record(),ledger.record())
        self.assertEqual(restored.amount(source_life_generation=1,target_life_generation=2,window_ms=4000),25)
        self.assertEqual(restored.amount(target_life_generation=1),0)

    def test_invalid_recipient_life_does_not_mutate_history(self):
        ledger=DamageLedger();before=ledger.record()
        c=DamageContribution(EffectSource('A','1',1,life_generation=1),D(100),'slash',True)
        for generation in (0,-1,True,'1'):
            with self.assertRaises(ValueError):
                ledger.record_loss('bad','T',0,0,[c],100,target_life_generation=generation)
            self.assertEqual(ledger.record(),before)

    def test_saved_loss_must_agree_with_receipts_recipient_life(self):
        ledger=DamageLedger();c=DamageContribution(EffectSource('A','1',1),D(100),'slash',True)
        ledger.record_loss('hit','T',0,0,[c],100,target_life_generation=1)
        data=ledger.record();data['entries'][0]['target_life_generation']=2
        with self.assertRaises(ValueError):DamageLedger.from_record(data)

    def test_legacy_history_has_no_invented_life_attribution(self):
        ledger=DamageLedger();c=DamageContribution(EffectSource('A','1',1),D(100),'slash',True)
        ledger.record_loss('hit','T',0,0,[c],100)
        data=ledger.record()
        self.assertNotIn('source_life_generation',data['entries'][0])
        self.assertNotIn('target_life_generation',data['receipts'][0])
        self.assertEqual(DamageLedger.from_record(data).record(),data)

    def test_stopped_cooldown_resumes_remaining_work_without_dead_time_credit(self):
        clock=CooldownClock();clock.start(0,1000);clock.stop(100)
        self.assertEqual(clock.remaining(5000),900)
        clock.resume(5000)
        self.assertEqual(clock.remaining(5000),900)
        self.assertEqual(clock.ready_at(5000),5900)
        self.assertEqual(clock.remaining(5100),800)

    def test_resumed_cooldown_rebinds_current_pause_sources(self):
        clock=CooldownClock();clock.start(0,1000);clock.pause(100,'expired_field',True);clock.stop(200)
        clock.resume(2000,pause_sources=['current_field'])
        self.assertEqual(clock.pauses,{'current_field'})
        self.assertIsNone(clock.ready_at(2000))
        clock.pause(2500,'current_field',False)
        self.assertEqual(clock.ready_at(2500),3400)

    def test_invalid_cooldown_resume_is_atomic(self):
        clock=CooldownClock();clock.start(0,1000);clock.stop(100);before=clock.record(100)
        for time,sources in ((99,()),(200,('',))):
            with self.assertRaises(ValueError):clock.resume(time,pause_sources=sources)
            self.assertEqual(clock.record(100),before)
        clock.resume(200)
        with self.assertRaises(ValueError):clock.resume(300)

    def test_copy_cannot_transfer_a_projectile_to_another_source_life(self):
        registry=ProjectileRegistry({'trace_schema':'entity_v1'})
        args=dict(action_id=1,owner='A',ability='1',created_at_ms=0,kinematics={'status':'in_flight'})
        parent=registry.create(**args,source_life_generation=1)
        with self.assertRaises(ValueError):registry.create(**args,parent=parent['id'],source_life_generation=2)
        self.assertEqual(len(registry.flights),1)
        child=registry.create(**args,parent=parent['id'],source_life_generation=1)
        self.assertEqual(registry.link(child)['source_life_generation'],1)

    def test_new_life_cannot_acquire_a_controlled_action_from_an_old_life(self):
        actor=Combatant('A','1E2','A',{},D(100),D(0),D(0),life_generation=2,life_reporting=True)
        action=BattleAction(1,'A','T','1','slash_projectile',D(0),D(0),D(40),life_generation=1)
        with self.assertRaises(ValueError):actor.current=action
        self.assertIsNone(actor.current)
        action.life_generation=None;actor.current=action
        self.assertEqual(action.life_generation,2)
        actor.current=None;actor.hp=D(0);actor.died_at_ms=D(100)
        with self.assertRaises(ValueError):actor.current=action

    def test_life_boundary_invalidates_a_shield_forecast_but_keeps_known_debt(self):
        recovery=DelayedShieldRecovery(20000,400)
        recovery.add_impact(D(0),D(100))
        old_plan=recovery.plan(D(20000),D(20500))
        recovery.invalidate_plans()
        with self.assertRaises(ValueError):recovery.commit_plan(old_plan)
        self.assertEqual(recovery.recovered,0)
        # Debt may mature while dead; work starts again only at the new life.
        resumed=recovery.plan(D(30000),D(30100))
        self.assertEqual(recovery.commit_plan(resumed),40)


if __name__=='__main__':unittest.main()
