"""Curved moving contact, reference comparisons and interval invariance."""
from math import sqrt
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.gravity import ProjectileTrajectory
from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.moving_gravity_collisions import moving_curve_contact
from combat_sim.moving_projectiles import earliest_moving_sphere_contact
from combat_sim.terrain import RectangularGround


class MovingGravityCollisionTests(unittest.TestCase):
    def assertBracket(self, contact, expected, tolerance=1e-12):
        self.assertIsNotNone(contact)
        self.assertLessEqual(contact.time_lower_s, expected+1e-15)
        self.assertGreaterEqual(contact.time_upper_s, expected-1e-15)
        self.assertLessEqual(contact.time_upper_s-contact.time_lower_s, tolerance)

    def test_zero_gravity_matches_exact_quadratic_moving_contact(self):
        box = Cuboid('torso', [20, 0, 1], [.3, .5, .7])
        projectile = ProjectileTrajectory([0, 0, 1], [100, 0, 0], .3, gravity_mps2=0)
        velocity, acceleration = [2, 0, 0], [4, 0, 0]
        exact = earliest_moving_sphere_contact([0, 0, 1], [100, 0, 0], [0, 0, 0],
                                              .02, box, velocity, acceleration, .3)
        curve = moving_curve_contact(projectile, box, .02, 0, .3, velocity, acceleration)
        self.assertBracket(curve, float(exact.time_s))
        self.assertEqual(curve.centre_m, projectile.at(curve.time_upper_s).position_m)
        self.assertAlmostEqual(curve.surface_point_m[0]-curve.centre_m[0], .02, places=9)
        self.assertAlmostEqual(curve.distance_upper_m, 100*curve.time_upper_s, places=12)

    def test_ground_contact_uses_actual_curved_distance(self):
        floor = RectangularGround('ground', [-250, -250, 0], [250, 250, 0])
        projectile = ProjectileTrajectory([0, 0, 1], [100, 0, 0], .6)
        contact = moving_curve_contact(projectile, floor, .02, 0, .6)
        self.assertBracket(contact, sqrt(2*.98/9.81))
        self.assertEqual(contact.surface_point_m[2], 0)
        self.assertGreater(contact.distance_lower_m, 100*contact.time_lower_s)

    def test_gravity_static_cube_contact(self):
        box = Cuboid('cube', [6, 0, .9], [1.8]*3)
        projectile = ProjectileTrajectory([0, 0, 1], [100, 0, 0], .1)
        contact = moving_curve_contact(projectile, box, .02, 0, .1)
        self.assertBracket(contact, .0508)
        self.assertEqual(contact.surface_point_m[0], 5.1)

    def test_target_moving_away_from_path_misses(self):
        box = Cuboid('torso', [30, 0, 1], [.3, .5, .7])
        projectile = ProjectileTrajectory([0, 0, 1], [100, 0, 1.5], .4)
        self.assertIsNotNone(moving_curve_contact(projectile, box, .02, 0, .4))
        self.assertIsNone(moving_curve_contact(projectile, box, .02, 0, .4, [0, 6.4, 0]))

    def test_target_crossing_into_path_hits(self):
        box = Cuboid('torso', [30, -1.8, 1], [.3, .5, .7])
        projectile = ProjectileTrajectory([0, 0, 1], [100, 0, 1.5], .4)
        self.assertIsNone(moving_curve_contact(projectile, box, .02, 0, .4))
        contact = moving_curve_contact(projectile, box, .02, 0, .4, [0, 6.4, 0])
        self.assertIsNotNone(contact)
        self.assertLess(abs(contact.centre_m[1]-contact.surface_point_m[1]), .021)

    def test_accelerated_box_contact_uses_relative_curve_enclosure(self):
        box = Cuboid('crossing', [5, 1, 1], [.2]*3)
        projectile = ProjectileTrajectory([0, 0, 1], [10, 0, 0], 1,
                                          gravity_mps2=0, max_step_s=1)
        # At both ends the box is at y=1; at t=.5 it crosses y=0.
        # The relative endpoint chord misses, but the relative curve hits.
        self.assertIsNone(box.swept_sphere_contact(projectile.at(0).position_m,
                                                   projectile.at(1).position_m, .02))
        contact = moving_curve_contact(projectile, box, .02, 0, 1,
                                       [0, -4, 0], [0, 8, 0])
        self.assertBracket(contact, .488)

    def test_split_interval_has_same_contact_and_world_surface(self):
        box = Cuboid('torso', [30, 0, 1.15], [.3, .5, .7])
        projectile = PersistentProjectileTrajectory([0, 0, 1.15], [900, 0, .2], .1,
                                                     deceleration_mps2=300)
        original_states = projectile.states
        velocity, acceleration = (2, 0, 0), (4, 0, 0)
        full = moving_curve_contact(projectile, box, .02, 0, .1, velocity, acceleration)
        split = .017
        self.assertIsNone(moving_curve_contact(projectile, box, .02, 0, split, velocity, acceleration))
        moved = Cuboid('torso', [float(p)+v*split+a*split**2/2 for p, v, a in
                                 zip(box.centre_m, velocity, acceleration)], box.size_m)
        suffix = moving_curve_contact(projectile, moved, .02, split, .1,
                                      [v+a*split for v, a in zip(velocity, acceleration)], acceleration)
        self.assertLess(abs(full.time_upper_s-suffix.time_upper_s), 1e-12)
        self.assertLess(abs(full.distance_upper_m-suffix.distance_upper_m), 1e-9)
        for a, b in zip(full.surface_point_m, suffix.surface_point_m):
            self.assertAlmostEqual(a, b, places=8)
        self.assertIs(projectile.states, original_states)

    def test_rounded_corner_miss_is_not_expanded_box_hit(self):
        box = Cuboid('box', [1, 1, 1], [2, 2, 2])
        projectile = ProjectileTrajectory([-1, -.019, -.019], [100, 0, 0], .04, gravity_mps2=0)
        self.assertIsNone(moving_curve_contact(projectile, box, .02, 0, .04))

    def test_finite_ground_does_not_invent_infinite_floor(self):
        floor = RectangularGround('ground', [-250, -250, 0], [250, 250, 0])
        projectile = ProjectileTrajectory([251, 0, 1], [0, 0, 0], .6)
        self.assertIsNone(moving_curve_contact(projectile, floor, .02, 0, .6))

    def test_begin_overlap_has_absolute_time_and_world_coordinates(self):
        projectile = ProjectileTrajectory([0, 0, 1], [100, 0, 0], .1, gravity_mps2=0)
        box = Cuboid('torso', [5, 0, 1], [.3, .5, .7])
        contact = moving_curve_contact(projectile, box, .02, .05, .05, [3, 0, 0])
        self.assertEqual((contact.time_lower_s, contact.time_upper_s), (.05, .05))
        self.assertEqual(contact.centre_m, (5, 0, 1))
        self.assertEqual(contact.distance_upper_m, 5)

    def test_collision_eligibility_is_caller_controlled(self):
        projectile = ProjectileTrajectory([0, 0, 1], [100, 0, 0], .1, gravity_mps2=0)
        owner = Cuboid('owner', [0, 0, 1], [.3, .5, .7])
        self.assertEqual(moving_curve_contact(projectile, owner, .02, 0, .1).time_upper_s, 0)

    def test_near_tangent_remains_explicitly_unresolved(self):
        projectile = ProjectileTrajectory([-1, -.02000000001, 1], [100, 0, 0], .04, gravity_mps2=0)
        box = Cuboid('box', [1, 1, 1], [2, 2, 2])
        with self.assertRaisesRegex(UnsupportedMechanicError, 'unresolved'):
            moving_curve_contact(projectile, box, .02, 0, .04,
                                 time_tolerance_s=1e-8, clearance_tolerance_m=1e-10)

    def test_invalid_or_extrapolated_intervals_and_vectors_fail(self):
        projectile = ProjectileTrajectory([0, 0, 1], [100, 0, 0], .1)
        box = Cuboid('box', [5, 0, 1], [1, 1, 1])
        for begin, end in ((-.01, .1), (0, .101), (.05, .04), (0, float('nan')), (False, .1)):
            with self.subTest(begin=begin, end=end), self.assertRaises(ValueError):
                moving_curve_contact(projectile, box, .02, begin, end)
        for kwargs in ({'box_velocity': [1, 2]}, {'box_acceleration': [0, float('inf'), 0]},
                       {'box_velocity': [True, 0, 0]}, {'time_tolerance_s': 0}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                moving_curve_contact(projectile, box, .02, 0, .1, **kwargs)


if __name__ == '__main__':
    unittest.main()
