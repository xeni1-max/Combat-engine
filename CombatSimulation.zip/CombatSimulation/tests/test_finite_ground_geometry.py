"""Finite-sheet occupancy and edge classification, independent of engine state."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.terrain import RectangularGround
from combat_sim.movement_contacts import first_box_contact
from combat_sim.mechanics.support_geometry import crosses_finite_sheet,grazing_vertical_departure


class FiniteGroundGeometryTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=70));context.__enter__();self.addCleanup(context.__exit__,None,None,None)
        self.floor=RectangularGround('floor',(-2,-2,0),(2,2,0))

    def contact(self,centre,velocity,acceleration=(0,0,0),duration=1):
        return first_box_contact(Cuboid('part',centre,('.5',)*3),self.floor,velocity,acceleration,duration,
            allow_flat_static_right=True,contact_resolution=('1e-20','1e-24','1e-24'))

    def test_partial_projection_can_land_on_actual_positive_area(self):
        self.assertEqual(self.contact(('2.2',0,1),(0,0,-1)),D('.75'))

    def test_outside_falling_path_never_hits_an_infinite_plane(self):
        self.assertIsNone(self.contact(('2.3',0,1),(0,0,-1)))

    def test_exact_zero_area_vertical_edge_tangency_is_not_a_landing(self):
        self.assertIsNone(self.contact(('2.25',0,1),(0,0,-1)))

    def test_accelerated_descent_uses_the_actual_finite_surface(self):
        t=self.contact((0,0,1),(0,0,0),(0,0,-6))
        self.assertEqual(t,D('.5'))

    def test_lateral_entry_only_meets_edge_when_body_straddles_the_sheet(self):
        self.assertEqual(self.contact((3,0,0),(-1,0,0)),D('.75'))
        self.assertIsNone(self.contact((3,0,1),(-1,0,0)))
        self.assertIsNone(self.contact((3,0,-1),(-1,0,0)))

    def test_underside_is_a_surface_without_becoming_support(self):
        self.assertEqual(self.contact((0,0,-1),(0,0,1)),D('.75'))

    def test_sheet_crossing_requires_positive_area_and_vertical_straddling(self):
        def crosses(centre):
            return crosses_finite_sheet(Cuboid('part',centre,('.5',)*3),self.floor,distance_epsilon='1e-20')
        self.assertTrue(crosses((0,0,0)));self.assertTrue(crosses(('2.2',0,0)))
        for centre in ((0,0,'.25'),(0,0,'-.25'),('2.25',0,0),('2.3',0,0),(0,0,-1)):
            with self.subTest(centre=centre):self.assertFalse(crosses(centre))

    def test_sheet_crossing_respects_shared_roundoff_band(self):
        part=Cuboid('part',(0,0,D('.25')-D('1e-25')),('.5',)*3)
        self.assertFalse(crosses_finite_sheet(part,self.floor,distance_epsilon='1e-20'))

    def grazing(self,velocity,acceleration):
        return grazing_vertical_departure((D('1.25'),0,D('.25')),(D('1.25'),1,D('.25')),
            velocity,(0,0,0),relative_acceleration=acceleration,half_size_acceleration=(0,0,0),
            distance_epsilon='1e-20',speed_epsilon='1e-24',acceleration_epsilon='1e-24')

    def test_outward_acceleration_at_zero_speed_cannot_recreate_support(self):
        self.assertTrue(self.grazing((0,0,0),(1,0,-10)))

    def test_inward_acceleration_and_velocity_still_admit_contacts(self):
        self.assertFalse(self.grazing((0,0,0),(-1,0,-10)))
        self.assertFalse(self.grazing((-1,0,0),(1,0,-10)))

    def test_outward_speed_dominates_inward_acceleration_at_this_boundary(self):
        self.assertTrue(self.grazing((1,0,0),(-1,0,-10)))

