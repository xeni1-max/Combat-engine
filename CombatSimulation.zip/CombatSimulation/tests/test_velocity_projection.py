"""Whole-graph velocity projection rather than sequential pair averaging."""
from dataclasses import FrozenInstanceError
from decimal import Context,Decimal as D,localcontext
from itertools import permutations
import unittest

from combat_sim.mechanics.grapple import shared_velocity
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality,BlockedDirection,project_velocities


def node(name,velocity,hp=10000,armor=100):return VelocityNode(name,velocity,hp,armor)


class VelocityProjectionTests(unittest.TestCase):
    def test_two_body_projection_matches_the_source_formula(self):
        a=node('A',(2,-3,7),8140,150);b=node('B',(-1,8,0),20000,350)
        r=project_velocities((a,b),(VelocityEquality('A','B'),))
        expected=shared_velocity(a.velocity_mps,b.velocity_mps,first_max_hp=a.maximum_hp,
            first_armor=a.armor,second_max_hp=b.maximum_hp,second_armor=b.armor)
        for x,y in zip(dict(r.velocities)['A'],expected):self.assertLess(abs(x-y),D('1e-45'))
        self.assertEqual(dict(r.velocities)['A'],dict(r.velocities)['B'])

    def test_three_body_cycle_is_one_projection_and_not_an_edge_order(self):
        nodes=(node('A',(9,0,0)),node('B',(0,3,0)),node('C',(0,0,6)))
        edges=(VelocityEquality('A','B'),VelocityEquality('B','C'),VelocityEquality('C','A'))
        for order in permutations(edges):
            r=project_velocities(reversed(nodes),order)
            self.assertEqual(set(dict(r.velocities).values()),{(D(3),D(1),D(2))})
            self.assertEqual(r.components,(('A','B','C'),))

    def test_disconnected_components_and_isolated_actors_remain_independent(self):
        r=project_velocities((node('A',(2,0,0)),node('B',(6,0,0)),node('C',(-9,1,2))),
            (VelocityEquality('A','B'),))
        self.assertEqual(dict(r.velocities),{'A':(D(4),D(0),D(0)),'B':(D(4),D(0),D(0)),'C':(D(-9),D(1),D(2))})

    def test_one_members_blocked_component_constrains_the_whole_connected_group(self):
        r=project_velocities((node('A',(2,4,6)),node('B',(6,0,2))),
            (VelocityEquality('A','B'),),(BlockedDirection('B',(1,0,0)),))
        self.assertEqual(set(dict(r.velocities).values()),{(D(0),D(2),D(4))})

    def test_redundant_and_nonorthogonal_directions_are_solved_together(self):
        directions=(BlockedDirection('A',(1,1,0)),BlockedDirection('A',(2,2,0)),BlockedDirection('A',(0,1,1)))
        for order in permutations(directions):
            value=dict(project_velocities((node('A',(3,2,1)),),blocked=order).velocities)['A']
            with localcontext(Context(prec=50)):expected=(D(2)/3,-D(2)/3,D(2)/3)
            self.assertEqual(value,expected)

    def test_unconstrained_weighted_velocity_sum_is_conserved_to_output_precision(self):
        r=project_velocities((node('A',(2,1,-1),8140,150),node('B',(-3,7,4),9080,165)),(VelocityEquality('A','B'),),precision=80)
        with localcontext(Context(prec=80)):
            weights=dict(r.weights);v=dict(r.velocities)
            before=[sum(weights[n]*D(x[i]) for n,x in [('A',(2,1,-1)),('B',(-3,7,4))]) for i in range(3)]
            after=[sum(weights[n]*v[n][i] for n in weights) for i in range(3)]
            for a,b in zip(before,after):self.assertLess(abs(a-b),D('1e-70'))

    def test_caller_context_and_hashable_immutable_inputs_do_not_change_results(self):
        nodes=(node('A',(2,1,0)),node('B',(1,2,0)));edges=(VelocityEquality('A','B'),)
        with localcontext(Context(prec=9)):a=project_velocities(nodes,edges,precision=60)
        with localcontext(Context(prec=90)):b=project_velocities(reversed(nodes),edges,precision=60)
        self.assertEqual(a,b)
        with self.assertRaises(FrozenInstanceError):nodes[0].armor=0

    def test_invalid_nodes_edges_normals_and_precision_reject(self):
        for velocity in ((1,2),('NaN',0,0),(True,0,0)):
            with self.subTest(velocity=velocity),self.assertRaises(ValueError):node('A',velocity)
        for hp,armor in ((0,0),(-1,0),(1,-1),(True,1)):
            with self.assertRaises(ValueError):node('A',(0,0,0),hp,armor)
        for edges in ((VelocityEquality('A','missing'),),(VelocityEquality('A','A'),)):
            with self.assertRaises(ValueError):project_velocities((node('A',(0,0,0)),),edges)
        with self.assertRaises(ValueError):BlockedDirection('A',(0,0,0))
        with self.assertRaises(ValueError):project_velocities((node('A',(0,0,0)),)*2)
        with self.assertRaises(ValueError):project_velocities((),precision=20)


if __name__=='__main__':unittest.main()
