"""Face support uses actual yaw footprints and shared signed reference bounds."""
from dataclasses import replace
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.angular_paths import RotatingBoxPath,YawArc
from combat_sim.angular_support import support_cells,support_departure
from combat_sim.angular_contacts import box_path_contact
from combat_sim.angular_kinematics import impact_normals
from combat_sim.box_motion import footprint_overlap
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.terrain import RectangularGround

EPS=F(1,10**20)


def path(*,angle=90,reference=(0,0,0),centre=(0,1,'.5'),size=('.2','.8',1),velocity=(0,0,0),
         acceleration=(0,0,0),local_velocity=(0,0,0),rate=(0,0,0),local_acceleration=(0,0,0),size_acceleration=(0,0,0)):
    return RotatingBoxPath(BodyPathPiece(0,1000,reference,velocity,acceleration),YawArc(0,1,YawFrame(),angle,70),
        Cuboid('upper',centre,size),local_velocity,local_acceleration,rate,size_acceleration)


class AngularSupportTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def cells(self,a,b,end=1):return support_cells(a,b,0,end,distance_epsilon=EPS,precision=70,first_boundary_only=False)

    def test_turning_foot_can_depart_without_reference_translation(self):
        p=path();deck=Cuboid('deck',(1,0,'-.5'),('.4','.4',1))
        cells=self.cells(p,deck);self.assertEqual([s for _,s in cells],[True,False])
        t=F(cells[1][0]);self.assertFalse(footprint_overlap(p.at_time(t),deck,distance_epsilon=EPS))
        self.assertGreater(t,0);self.assertLess(t,F('.3'))

    def test_multiple_revolutions_report_real_reentry(self):
        cells=self.cells(path(angle=720),Cuboid('deck',(1,0,'-.5'),('.4','.4',1)))
        self.assertEqual([s for _,s in cells],[True,False,True,False,True])

    def test_broad_finite_ground_keeps_rotating_feet_supported(self):
        p=path();floor=RectangularGround('floor',(-250,-250,0),(250,250,0))
        self.assertEqual(self.cells(p,floor),[(D(0),True)])

    def test_zero_area_edge_is_not_a_support(self):
        p=path(angle=0,reference=(F('1.5'),0,0),centre=(0,0,'.5'),size=(1,1,1))
        self.assertEqual(self.cells(p,Cuboid('deck',(0,0,'-.5'),(2,2,1))),[(D(0),False)])

    def test_own_projected_width_must_exceed_contact_band(self):
        p=path(centre=(0,0,'.5'),size=(EPS/2,1,1));deck=Cuboid('deck',(0,0,'-.5'),(10,10,1))
        self.assertEqual(self.cells(p,deck),[(D(0),False)])

    def test_vertical_withdrawal_crosses_existing_band_once(self):
        p=path(centre=(0,0,'.5'),size=(1,1,1),local_velocity=(0,0,1))
        deck=Cuboid('deck',(0,0,'-.5'),(10,10,1));loss=support_departure(p,deck,0,1,distance_epsilon=EPS,precision=70)
        self.assertGreater(loss,EPS);self.assertLess(loss-EPS,F(1,10**27))

    def test_common_gravity_and_translation_cancel_before_bounding(self):
        common=dict(centre=(0,0,0),size=(1,1,2),velocity=(1,2,0),acceleration=(3,4,F('-9.81')))
        a=path(reference=(0,0,1),**common);b=path(reference=(0,0,-1),angle=-90,**common)
        self.assertEqual(self.cells(a,b),[(D(0),True)])

    def test_accelerating_pose_keeps_anchored_underside(self):
        p=path(centre=(0,0,'.5'),size=(1,1,1),local_acceleration=(0,0,1),size_acceleration=(0,0,2))
        self.assertEqual(self.cells(p,Cuboid('deck',(0,0,'-.5'),(10,10,1))),[(D(0),True)])

    def test_closed_initial_witness_is_consumed_past_a_subresolution_loss(self):
        p=path(angle=0,reference=(F('1.5')-EPS-F(1,10**30),0,0),centre=(0,0,'.5'),size=(1,1,1),velocity=(1,0,0))
        deck=Cuboid('deck',(0,0,'-.5'),(2,2,1))
        loss=support_departure(p,deck,0,F(1,10**25),distance_epsilon=EPS,precision=70)
        self.assertGreater(loss,0);self.assertLess(loss,F(1,10**27))
        self.assertFalse(footprint_overlap(p.at_time(loss),deck,distance_epsilon=EPS))

    def test_both_turning_parts_use_actual_relative_footprints(self):
        a=path();b=path(reference=(1,0,-1),centre=(0,0,'.5'),size=('.4','.4',1),angle=-137)
        cells=self.cells(a,b)
        self.assertTrue(cells[0][1]);self.assertFalse(cells[-1][1])
        for i in range(31):
            time=F(i,30);expected=footprint_overlap(a.at_time(time),b.at_time(time),distance_epsilon=EPS)
            actual=next(s for t,s in reversed(cells) if F(t)<=time)
            self.assertEqual(actual,expected)

    def test_static_rotated_top_uses_its_real_axes(self):
        p=path();deck=OrientedCuboid('deck',(1,0,'-.5'),('.4','.2',1),YawFrame.from_degrees(37))
        cells=self.cells(p,deck);self.assertEqual([s for _,s in cells],[True,False])

    def test_slice_preserves_angle_and_absolute_departure(self):
        p=path();deck=Cuboid('deck',(1,0,'-.5'),('.4','.4',1))
        a=support_departure(p,deck,0,1,distance_epsilon=EPS,precision=70)
        sliced=replace(p,reference=p.reference.slice(10,1000),yaw=replace(p.yaw,begin_s=F('.01')))
        b=support_departure(sliced,deck,F('.01'),1,distance_epsilon=EPS,precision=70)
        self.assertLess(abs(a-b),F(1,10**27))

    def test_invalid_interval_and_zero_duration_are_explicit(self):
        p=path();deck=Cuboid('deck',(1,0,'-.5'),('.4','.4',1))
        self.assertEqual(self.cells(p,deck,0),[(D(0),True)])
        for begin,end,eps in ((-1,1,EPS),(0,2,EPS),(0,1,0)):
            with self.assertRaises(ValueError):support_cells(p,deck,begin,end,distance_epsilon=eps)

    def test_cofalling_touching_boxes_need_no_collision_search_refinement(self):
        a=path(reference=(0,0,1),centre=(0,0,'.5'),size=(1,1,1),velocity=(0,0,-1),acceleration=(0,0,F('-9.81')))
        b=path(centre=(0,0,'.5'),size=(1,1,1),angle=-137,velocity=(0,0,-1),acceleration=(0,0,F('-9.81')))
        self.assertIsNone(box_path_contact(a,b,0,1,minimum_overlap_m=EPS/100,node_limit=256))

    def test_relative_projection_combines_reference_and_local_pose_coefficients(self):
        a=path(reference=(0,0,1),centre=(0,0,'.5'),size=(1,1,1),velocity=(0,0,-2),
            local_velocity=(0,0,1),acceleration=(0,0,F('-9.81')))
        b=path(centre=(0,0,'.5'),size=(1,1,1),angle=-137,velocity=(0,0,F('-.5')),
            local_velocity=(0,0,F('-.5')),acceleration=(0,0,F('-9.81')))
        self.assertIsNone(box_path_contact(a,b,0,1,minimum_overlap_m=EPS/100,node_limit=256))

    def test_relative_bounds_preserve_real_approach_and_contact(self):
        a=path(reference=(0,0,2),centre=(0,0,'.5'),size=(1,1,1),velocity=(0,0,-2),acceleration=(0,0,F('-9.81')))
        b=path(centre=(0,0,'.5'),size=(1,1,1),angle=-137,velocity=(0,0,-1),acceleration=(0,0,F('-9.81')))
        hit=box_path_contact(a,b,0,1,node_limit=1000)
        self.assertIsNotNone(hit);self.assertEqual(hit.time_upper_s,1)

    def test_outgoing_angular_footprint_drops_false_vertical_normal(self):
        p=path(reference=(F('1.5')-EPS/2,0,F('.5')),centre=(0,0,0),size=('.6','.8',1),velocity=(0,0,-1))
        p=replace(p,yaw=replace(p.yaw,initial_frame=YawFrame(F(4,5),F(3,5))))
        floor=RectangularGround('floor',(-1,-1,0),(1,1,0))
        self.assertEqual(impact_normals(p,floor,0,distance_epsilon=EPS,speed_epsilon=F('1e-24'),acceleration_epsilon=F('1e-24')),())

    def test_actual_inward_corner_keeps_horizontal_and_vertical_normals(self):
        p=path(reference=(F('1.5')-EPS/2,0,F('.5')),centre=(0,0,0),size=('.6','.8',1),velocity=(-1,0,-1))
        p=replace(p,yaw=replace(p.yaw,initial_frame=YawFrame(F(4,5),F(3,5))))
        floor=RectangularGround('floor',(-1,-1,0),(1,1,0))
        normals=impact_normals(p,floor,0,distance_epsilon=EPS,speed_epsilon=F('1e-24'),acceleration_epsilon=F('1e-24'))
        self.assertIn((0,0,1),normals);self.assertIn((1,0,0),normals)


if __name__=='__main__':unittest.main()
