import unittest
from decimal import Decimal, localcontext
from fractions import Fraction

from combat_sim.mechanics.dyspnea import (
    DyspneaContext,
    apply_action_dyspnea,
    action_dyspnea_value,
    advance_continuous_action_dyspnea,
    apply_maximum_dyspnea_disorientation,
    continuous_action_dyspnea_rate,
    decay_dyspnea,
    dyspnea_loss_rate,
    net_continuous_action_dyspnea_rate,
)


class DyspneaMechanicTests(unittest.TestCase):
    def test_action_value_formula(self):
        # Da = (Db + D/100)^2 = (3.5 + 0.5)^2.
        self.assertEqual(action_dyspnea_value(Fraction(7, 2), 50), Fraction(16))

    def test_continuous_action_rate_formula(self):
        # Dc = (Dd + D/100)^2 = (2 + 0.5)^2.
        self.assertEqual(continuous_action_dyspnea_rate(2, 50), Fraction(25, 4))

    def test_recovery_depends_on_movement(self):
        for movement, rate in (("stationary", 30), ("walking", 30), ("running", 18), ("sprinting", 0)):
            with self.subTest(movement=movement):
                self.assertEqual(dyspnea_loss_rate(DyspneaContext(movement)), rate)

    def test_each_blocker_stops_recovery_even_while_walking_or_running(self):
        for blocker in ("disoriented", "unstable", "on_grapple_ability", "active", "gathering", "recovering"):
            for movement in ("stationary", "walking", "running"):
                with self.subTest(blocker=blocker, movement=movement):
                    context = DyspneaContext(movement, **{blocker: True})
                    self.assertEqual(decay_dyspnea(50, 1000, context=context), 50)

    def test_sprint_gain_has_no_recovery_subtracted(self):
        self.assertEqual(
            net_continuous_action_dyspnea_rate(2, 50, context=DyspneaContext("sprinting")),
            Fraction(25, 4),
        )

    def test_running_continuous_gain_combines_with_18_per_second_loss(self):
        self.assertEqual(
            net_continuous_action_dyspnea_rate(2, 50, context=DyspneaContext("running")),
            Fraction(-47, 4),
        )

    def test_action_cost_is_added_when_capacity_is_sufficient(self):
        result = apply_action_dyspnea(50, Fraction(5, 2))
        self.assertTrue(result.allowed)
        self.assertEqual(result.action_value, Fraction(9))
        self.assertEqual(result.available_capacity, Fraction(50))
        self.assertEqual(result.after, Fraction(59))
        self.assertFalse(result.reached_maximum)

    def test_exact_capacity_reaches_max_and_emits_one_disorientation_trigger(self):
        result = apply_action_dyspnea(0, 10)
        self.assertTrue(result.allowed)
        self.assertEqual(result.after, Fraction(100))
        self.assertTrue(result.reached_maximum)
        self.assertEqual(result.disorientation_trigger, Fraction(200))

    def test_action_exceeding_remaining_capacity_is_rejected(self):
        result = apply_action_dyspnea(50, 8)
        self.assertFalse(result.allowed)
        self.assertEqual(result.after, Fraction(50))
        self.assertFalse(result.reached_maximum)
        self.assertEqual(result.disorientation_trigger, Fraction(0))

    def test_an_action_at_the_cap_does_not_retrigger_disorientation(self):
        result = apply_action_dyspnea(100, 0)
        self.assertFalse(result.allowed)
        self.assertFalse(result.reached_maximum)
        self.assertEqual(result.disorientation_trigger, Fraction(0))

    def test_maximum_trigger_bypasses_mitigation_and_adds_running_penalty(self):
        self.assertEqual(apply_maximum_dyspnea_disorientation(200), 400)
        self.assertEqual(apply_maximum_dyspnea_disorientation(200, is_running_at_application=True), 440)

    def test_formulas_allow_dyspnea_at_the_documented_maximum(self):
        self.assertEqual(action_dyspnea_value(2, 100), Fraction(9))
        self.assertEqual(continuous_action_dyspnea_rate(2, 100), Fraction(9))

    def test_walking_loss_is_30_per_second(self):
        self.assertEqual(decay_dyspnea(50, 1250, context=DyspneaContext("walking")), Fraction(25, 2))

    def test_running_loss_is_18_per_second(self):
        self.assertEqual(decay_dyspnea(50, 1250, context=DyspneaContext("running")), Fraction(55, 2))

    def test_recovery_pauses_and_resumes_at_explicit_context_boundaries(self):
        after_walk = decay_dyspnea(50, 250, context=DyspneaContext("walking"))
        after_active = decay_dyspnea(after_walk, 250, context=DyspneaContext("walking", active=True))
        after_run = decay_dyspnea(after_active, 500, context=DyspneaContext("running"))
        self.assertEqual(after_active, Fraction(85, 2))
        self.assertEqual(after_run, Fraction(67, 2))

    def test_loss_stops_at_zero(self):
        self.assertEqual(decay_dyspnea(50, 4000, context=DyspneaContext("stationary")), Fraction(0))

    def test_continuous_action_evolution_uses_current_d_over_time(self):
        result = advance_continuous_action_dyspnea(0, 2, 1000, context=DyspneaContext("sprinting"))
        # Solving D'=(2+D/100)^2 from D=0 gives D(1 second)=200/49.
        with localcontext() as context:
            context.prec = 50
            self.assertLess(abs(result.after - Decimal(200) / 49), Decimal("1e-45"))
        self.assertEqual(result.loss_rate_per_second, 0)
        self.assertEqual(result.context, DyspneaContext("sprinting"))
        self.assertFalse(result.reached_maximum)

    def test_continuous_action_evolution_is_consistent_across_time_splits(self):
        for movement in ("walking", "running", "sprinting"):
            with self.subTest(movement=movement):
                state = DyspneaContext(movement)
                single = advance_continuous_action_dyspnea(50, 2, 1000, context=state).after
                first = advance_continuous_action_dyspnea(50, 2, 400, context=state).after
                split = advance_continuous_action_dyspnea(first, 2, 600, context=state).after
                with localcontext() as context:
                    context.prec = 50
                    self.assertLess(abs(single - split), Decimal("1e-45"))

    def test_nonzero_recovery_solutions_match_independent_numerical_examples(self):
        # References calculated independently with RK4, 4000 steps over 1 s.
        cases = (
            ("running", 2, "37.956128672601366807"),
            ("walking", 2, "25.665978621501867602"),
            ("walking", 6, "63.087609633305862761"),
        )
        for movement, base, expected in cases:
            with self.subTest(movement=movement, base=base), localcontext() as context:
                context.prec = 50
                result = advance_continuous_action_dyspnea(50, base, 1000, context=DyspneaContext(movement))
                self.assertLess(abs(result.after - Decimal(expected)), Decimal("1e-17"))

    def test_zero_gain_and_blocked_loss_leave_an_empty_bar_unchanged(self):
        result = advance_continuous_action_dyspnea(0, 0, 1_000_000, context=DyspneaContext("sprinting"))
        self.assertEqual(result.after, 0)
        self.assertFalse(result.reached_maximum)

    def test_nonzero_recovery_can_still_reach_max_when_gain_is_greater(self):
        result = advance_continuous_action_dyspnea(0, 6, 100_000, context=DyspneaContext("walking"))
        self.assertEqual(result.after, 100)
        self.assertTrue(result.reached_maximum)

    def test_continuous_action_clamps_at_zero(self):
        result = advance_continuous_action_dyspnea(20, 2, 4000, context=DyspneaContext("running"))
        self.assertEqual(result.after, Decimal(0))
        self.assertFalse(result.reached_maximum)

    def test_sprint_reaches_maximum_at_the_derived_threshold(self):
        # D=100 is reached after 50/3 seconds for Dd=2, D0=0, recovery=0.
        before_cap = advance_continuous_action_dyspnea(0, 2, 16666, context=DyspneaContext("sprinting"))
        after_cap = advance_continuous_action_dyspnea(0, 2, 16667, context=DyspneaContext("sprinting"))
        self.assertLess(before_cap.after, 100)
        self.assertFalse(before_cap.reached_maximum)
        self.assertEqual(after_cap.after, 100)
        self.assertTrue(after_cap.reached_maximum)

    def test_continuous_action_reaching_max_triggers_once(self):
        result = advance_continuous_action_dyspnea(0, 2, 17000, context=DyspneaContext("sprinting"))
        self.assertEqual(result.after, Decimal(100))
        self.assertTrue(result.reached_maximum)
        self.assertEqual(result.disorientation_trigger, Fraction(200))

    def test_continuous_action_already_at_max_does_not_retrigger(self):
        for movement in ("sprinting", "walking"):
            with self.subTest(movement=movement):
                result = advance_continuous_action_dyspnea(100, 10, 1_000_000, context=DyspneaContext(movement))
                self.assertEqual(result.after, Decimal(100))
                self.assertFalse(result.reached_maximum)
                self.assertEqual(result.disorientation_trigger, Fraction(0))

    def test_maximum_trigger_rearms_after_recovery(self):
        recovered = decay_dyspnea(100, 1000, context=DyspneaContext("running"))
        result = advance_continuous_action_dyspnea(recovered, 2, 3000, context=DyspneaContext("sprinting"))
        self.assertTrue(result.reached_maximum)
        self.assertEqual(result.disorientation_trigger, 200)

    def test_unknown_movement_is_rejected_instead_of_assuming_a_rate(self):
        with self.assertRaisesRegex(ValueError, "movement"):
            dyspnea_loss_rate(DyspneaContext("swimming"))

    def test_blocked_recovery_is_zero_without_inventing_an_unknown_movement_rate(self):
        self.assertEqual(dyspnea_loss_rate(DyspneaContext("swimming", active=True)), 0)

    def test_airborne_recovery_is_explicitly_zero(self):
        self.assertEqual(dyspnea_loss_rate(DyspneaContext("airborne")), 0)

    def test_current_dyspnea_outside_zero_to_100_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "between 0 and 100"):
            action_dyspnea_value(2, 101)
        with self.assertRaisesRegex(ValueError, "between 0 and 100"):
            continuous_action_dyspnea_rate(2, -1)

    def test_negative_elapsed_time_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Elapsed time"):
            decay_dyspnea(50, -1, context=DyspneaContext("walking"))
        with self.assertRaisesRegex(ValueError, "Elapsed time"):
            advance_continuous_action_dyspnea(50, 2, -1, context=DyspneaContext("sprinting"))


if __name__ == "__main__":
    unittest.main()
