import json
import unittest
from copy import deepcopy
from fractions import Fraction
from pathlib import Path

from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario


ROOT = Path(__file__).resolve().parents[1]
CHARACTERS = json.loads((ROOT / "data/characters.json").read_text())["characters"]
SCENARIO = json.loads((ROOT / "scenarios/one_blunt_impact.json").read_text())


class StateBoundaryTests(unittest.TestCase):
    def test_hp_and_armor_floor_without_hiding_nominal_formula_outputs(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"].update(hp=100, armor=0, shield=0)
        run = run_scenario(scenario, CHARACTERS)
        target = run["final_states"]["1E1"]
        calculation = run["events"][0]["damage_calculation"]
        self.assertEqual(target["hp"]["exact"], "0")
        self.assertEqual(target["armor"]["exact"], "0")
        self.assertEqual(calculation["outputs"]["y"]["exact"], "300")
        self.assertEqual(calculation["outputs"]["Ar"]["exact"], "6")
        self.assertEqual(calculation["applied_state_losses"]["hp"]["exact"], "100")
        self.assertEqual(calculation["applied_state_losses"]["armor"]["exact"], "0")
        self.assertEqual(calculation["excess_formula_outputs"]["hp"]["exact"], "200")
        summary = summarize(run)
        self.assertEqual(summary["hp_damage"]["exact"], "100")
        self.assertEqual(summary["nominal_hp_damage"]["exact"], "300")
        self.assertEqual(summary["excess_hp_damage"]["exact"], "200")
        self.assertEqual(summary["armor_lost"]["exact"], "0")
        self.assertEqual(summary["nominal_armor_loss"]["exact"], "6")

    def test_armor_floor_preserves_pre_hit_armor_for_hp_formula(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"].update(hp=1000, armor=1, shield=0)
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(run["final_states"]["1E1"]["armor"]["exact"], "0")
        self.assertEqual(Fraction(run["final_states"]["1E1"]["hp"]["exact"]), Fraction(210001, 300))
        self.assertEqual(summarize(run)["armor_lost"]["exact"], "1")

    def test_zero_armor_stays_zero_across_successive_hits(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"].update(hp=1000, armor=0, shield=0)
        first = scenario["action_sequence"][0]
        first.pop("action_start_ms")
        first.update(kind="impact", time_ms=0)
        second = deepcopy(first)
        second["time_ms"] = 1000
        scenario["action_sequence"].append(second)
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(run["final_states"]["1E1"]["hp"]["exact"], "400")
        self.assertEqual(run["final_states"]["1E1"]["armor"]["exact"], "0")
        self.assertEqual(summarize(run)["hp_damage"]["exact"], "600")

    def test_exact_hp_depletion_has_no_excess(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"].update(hp=300, armor=0, shield=0)
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(run["final_states"]["1E1"]["hp"]["exact"], "0")
        self.assertEqual(summarize(run)["excess_hp_damage"]["exact"], "0")

    def test_negative_initial_states_are_rejected(self):
        for field in ("hp", "armor", "shield"):
            with self.subTest(field=field):
                scenario = deepcopy(SCENARIO)
                scenario["encounter"]["initial_states"]["1E1"][field] = -1
                with self.assertRaisesRegex(ValueError, "nonnegative"):
                    run_scenario(scenario, CHARACTERS)


if __name__ == "__main__":
    unittest.main()
