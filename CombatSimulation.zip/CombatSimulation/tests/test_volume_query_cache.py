"""Exact repeated geometry with mutable callers, invalidation and Decimal signals."""
from decimal import Context,Decimal as D,Inexact,Rounded,DivisionByZero,localcontext,getcontext,ROUND_FLOOR
from fractions import Fraction as F
from unittest.mock import Mock
import unittest
from combat_sim.hitboxes import Cuboid
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.volume_geometry import column_cells,box_cells,sphere_cells
from combat_sim.volume_query_cache import VolumeQueryCache

ZERO=(0,0,0)
def body(x=0):return [(Cuboid('body',(x,0,0),(1,1,1)),ZERO,ZERO,ZERO)]

class VolumeQueryCacheTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=50));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def test_repeated_actual_cells_reuse_work_and_return_detached_lists(self):
        cache=VolumeQueryCache();query=Mock(wraps=column_cells);parts=body()
        a=cache.query(query,ZERO,1,parts,[],1);a[0]=(D(0),False)
        self.assertEqual(cache.query(query,ZERO,1,parts,[],1),[(D(0),True)])
        self.assertEqual((query.call_count,cache.hits,cache.misses),(1,1,1))

    def test_same_clock_mutation_of_parts_and_size_rates_rechecks_geometry(self):
        cache=VolumeQueryCache();parts=body()
        self.assertTrue(cache.query(column_cells,ZERO,1,parts,[],1)[0][1])
        parts[0]=(Cuboid('body',(10,0,0),(1,1,1)),ZERO,ZERO,[0,0,0])
        self.assertFalse(cache.query(column_cells,ZERO,1,parts,[],1)[0][1])
        parts[0][3][2]=-2
        with self.assertRaises(ValueError):cache.query(column_cells,ZERO,1,parts,[],1)
        self.assertEqual(len(cache.entries),2)

    def test_orientation_and_cover_geometry_are_part_of_the_input(self):
        cache=VolumeQueryCache();a=OrientedCuboid('body',('1.4',0,0),(2,'.1',1),YawFrame(1,0))
        b=OrientedCuboid('body',('1.4',0,0),(2,'.1',1),YawFrame(0,1))
        self.assertFalse(cache.query(column_cells,ZERO,1,[(a,ZERO,ZERO,ZERO)],[],1)[0][1])
        self.assertTrue(cache.query(column_cells,ZERO,1,[(b,ZERO,ZERO,ZERO)],[],1)[0][1])
        roof=Cuboid('roof',(0,0,3),(4,4,1));parts=body()
        self.assertTrue(cache.query(column_cells,ZERO,1,parts,[],1)[0][1])
        self.assertFalse(cache.query(column_cells,ZERO,1,parts,[roof],1)[0][1])
        self.assertTrue(cache.query(column_cells,ZERO,1,parts,[],1)[0][1])

    def test_iterators_are_consumed_once_by_the_original_query(self):
        cache=VolumeQueryCache();parts=(p for p in body())
        self.assertEqual(cache.query(column_cells,ZERO,1,parts,[],1),[(D(0),True)])
        self.assertEqual((cache.bypasses,len(cache.entries)),(1,0));self.assertEqual(list(parts),[])

    def test_boolean_geometry_cannot_hit_a_numeric_cache_entry(self):
        cache=VolumeQueryCache();parts=body()
        cache.query(sphere_cells,ZERO,1,parts,1)
        with self.assertRaises(ValueError):cache.query(sphere_cells,ZERO,True,parts,1)
        self.assertEqual(len(cache.entries),1)

    def test_context_precision_rounding_and_flags_are_preserved(self):
        cache=VolumeQueryCache()
        query=Mock(side_effect=lambda:[(D(2)/3,True)])
        ctx=getcontext();ctx.clear_flags();a=cache.query(query)
        self.assertTrue(ctx.flags[Inexact]);self.assertTrue(ctx.flags[Rounded])
        ctx.clear_flags();self.assertEqual(cache.query(query),a)
        self.assertTrue(ctx.flags[Inexact]);self.assertTrue(ctx.flags[Rounded]);self.assertEqual(query.call_count,1)
        with localcontext(Context(prec=80)):
            b=cache.query(query);self.assertNotEqual(a,b)
        with localcontext(Context(prec=50,rounding=ROUND_FLOOR)):
            c=cache.query(query);self.assertNotEqual(a,c)
        self.assertEqual(query.call_count,3)

    def test_preexisting_flags_do_not_hide_a_later_hits_signals(self):
        cache=VolumeQueryCache();ctx=getcontext();ctx.flags[Inexact]=ctx.flags[Rounded]=True
        cache.query(lambda:[(D(1)/3,True)])
        query=lambda:[(D(1)/7,True)];cache.query(query);ctx.clear_flags();cache.query(query)
        self.assertTrue(ctx.flags[Inexact]);self.assertTrue(ctx.flags[Rounded])

    def test_raised_signals_and_traps_keep_the_original_failure_semantics(self):
        cache=VolumeQueryCache();ctx=getcontext();query=Mock(side_effect=lambda:[(D(1)/0,True)])
        ctx.clear_flags()
        with self.assertRaises(DivisionByZero):cache.query(query)
        self.assertTrue(ctx.flags[DivisionByZero]);self.assertEqual(len(cache.entries),0)
        ctx.traps[DivisionByZero]=False;ctx.clear_flags();value=cache.query(query)
        self.assertTrue(value[0][0].is_infinite());self.assertTrue(ctx.flags[DivisionByZero])
        ctx.clear_flags();cache.query(query);self.assertTrue(ctx.flags[DivisionByZero]);self.assertEqual(query.call_count,2)
        ctx.traps[DivisionByZero]=True
        with self.assertRaises(DivisionByZero):cache.query(query)
        self.assertEqual(query.call_count,3)

    def test_lru_storage_is_bounded_and_does_not_change_evicted_results(self):
        cache=VolumeQueryCache(2);query=Mock(wraps=column_cells)
        for x in (0,3,6,6,0):
            self.assertEqual(cache.query(query,ZERO,1,body(x),[],1),column_cells(ZERO,1,body(x),[],1))
        self.assertEqual((len(cache.entries),query.call_count,cache.hits),(2,4,1))
        cache.clear();self.assertFalse(cache.entries)

    def test_independent_world_caches_and_all_volume_families(self):
        first,second=VolumeQueryCache(),VolumeQueryCache();parts=body();panel=Cuboid('panel',ZERO,(1,1,1))
        for function,args in ((column_cells,(ZERO,1,parts,[],1)),(box_cells,([panel],parts,1)),(sphere_cells,(ZERO,1,parts,1))):
            expected=function(*args)
            self.assertEqual(first.query(function,*args),expected);self.assertEqual(second.query(function,*args),expected)
            self.assertEqual(first.query(function,*args),expected)
        self.assertEqual((first.hits,first.misses,second.hits,second.misses),(3,3,0,3))
