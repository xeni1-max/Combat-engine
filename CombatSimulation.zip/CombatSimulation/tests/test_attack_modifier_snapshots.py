"""Controller boundary probes; no character casts or combat results are inferred."""
from copy import deepcopy
from dataclasses import FrozenInstanceError
from decimal import Decimal as D
from types import SimpleNamespace
import unittest

from combat_sim.attack_modifiers import AttackModifiers
from combat_sim.models import UnsupportedMechanicError
from tests.test_mobile_combat import PROFILES


class ModifierSnapshotTests(unittest.TestCase):
    def setUp(self):
        self.world=SimpleNamespace(time=D(0),life_cycles=SimpleNamespace(enabled=True),
            effort_system=SimpleNamespace(enabled=True),log=lambda *a,**kw:None,push=lambda *a,**kw:None)
        self.controller=AttackModifiers(self.world,{'mode':'release_snapshot_v1'})
        self.actor=SimpleNamespace(id='A',life_generation=1,profile=deepcopy(PROFILES['2E4']))
        self.action=SimpleNamespace(id=1,ability_id='1',life_generation=1)

    def grant(self,identity):
        action=SimpleNamespace(id=2,ability_id=identity,life_generation=1)
        self.controller.grant(self.actor,action,self.actor.profile['abilities'][identity])

    def test_expiry_is_half_open_even_before_the_expiry_callback(self):
        self.grant('Ultimate');self.world.time=D('9999.999999')
        before=self.controller.capture(self.actor,self.action,'before')
        self.world.time=D(10000)
        exact=self.controller.capture(self.actor,self.action,'exact')
        self.assertEqual(before.values.shielding_ignored,4000)
        self.assertEqual(exact.values.shielding_ignored,0)
        self.assertEqual(self.controller.grants['modifier:1']['status'],'active')
        self.controller.expire({'modifier_id':'modifier:1'})
        self.assertEqual(before.values.shielding_ignored,4000)

    def test_capture_is_immutable_idempotent_and_consumes_only_once(self):
        self.grant('4');snapshot=self.controller.capture(self.actor,self.action,'attack')
        self.assertIs(snapshot,self.controller.capture(self.actor,self.action,'attack'))
        with self.assertRaises(FrozenInstanceError):snapshot.actor='other'
        with self.assertRaises(FrozenInstanceError):snapshot.values.additional_armor_loss=0
        self.assertEqual(self.controller.capture(self.actor,self.action,'next').values.additional_armor_loss,0)
        detached=snapshot.record();detached['values']['additional_armor_loss']=0
        self.assertEqual(snapshot.values.additional_armor_loss,20)

    def test_an_attack_identity_cannot_be_reassigned_to_another_life_or_action(self):
        self.controller.capture(self.actor,self.action,'attack')
        self.action.life_generation=2
        with self.assertRaises(ValueError):self.controller.capture(self.actor,self.action,'attack')

    def test_old_grants_do_not_transfer_to_a_new_life(self):
        self.grant('4');self.grant('Ultimate')
        self.controller.retire_life(self.actor);self.actor.life_generation=2;self.action.life_generation=2
        snapshot=self.controller.capture(self.actor,self.action,'new-life')
        self.assertEqual(snapshot.modifier_ids,())
        self.assertTrue(all(row['end_reason']=='owner_death' for row in self.controller.grants.values()))

    def test_replaced_grant_expiry_is_not_live_and_cannot_end_the_replacement(self):
        self.grant('Ultimate');self.world.time=D(1000);self.grant('Ultimate')
        self.assertFalse(self.controller.live({'modifier_id':'modifier:1'}))
        self.controller.expire({'modifier_id':'modifier:1'})
        self.assertEqual(self.controller.grants['modifier:2']['status'],'active')

    def test_unknown_modifier_values_and_uncaptured_delivery_reject(self):
        for change in ('unknown_value','other_delivery'):
            with self.subTest(change=change):
                actor=deepcopy(self.actor)
                if change=='unknown_value':actor.profile['abilities']['4']['modifier']['values']['invented']=1
                else:actor.profile['abilities']['1']['execution_model']='slash_projectile'
                with self.assertRaises(ValueError):self.controller.validate(actor,'4')


if __name__=='__main__':unittest.main()
