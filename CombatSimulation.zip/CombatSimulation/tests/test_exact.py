from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction
import unittest

from combat_sim.exact import ExactAmount, ExactRootProduct, amount_from_record, number_record


class ExactAmountTests(unittest.TestCase):
    def test_rational_roots_reduce_and_equal_radicals_combine(self):
        result = ExactAmount(1, (ExactRootProduct(2, 4), ExactRootProduct(3, 3), ExactRootProduct(-1, 3)))
        self.assertEqual(result.rational, 5)
        self.assertEqual(result.roots, (ExactRootProduct(2, 3),))

    def test_hp_subtraction_retains_exact_root_and_cancellation(self):
        first, second = ExactRootProduct(Fraction(3479, 2), 3), ExactRootProduct(Fraction(3479, 4), 3)
        hp = ExactAmount.of(9080) - first - second
        self.assertEqual(hp, ExactAmount(9080, (ExactRootProduct(Fraction(-10437, 4), 3),)))
        self.assertEqual((hp + first + second).as_fraction(), 9080)
        self.assertEqual((100 - ExactAmount.of(40)).as_fraction(), 60)

    def test_irrational_records_are_exact_expressions_not_fake_fractions(self):
        value = ExactAmount(9080, (ExactRootProduct(Fraction(-10437, 4), 3),))
        record = number_record(value)
        self.assertNotIn("exact", record)
        self.assertEqual(record["exact_expression"], "9080 - (10437/4)*sqrt(3)")
        self.assertEqual(record["root_terms"], [{"coefficient": "-10437/4", "radicand": "3"}])
        self.assertEqual(amount_from_record(record), value)

    def test_rational_record_shape_and_precision_stay_compatible(self):
        self.assertEqual(number_record(Fraction(1, 7)), {"exact": "1/7", "decimal_approx": "0.1428571428571428571428571429"})
        self.assertEqual(number_record(ExactRootProduct(3, 4))["exact"], "6")

    def test_display_is_independent_of_ambient_decimal_context(self):
        value = ExactAmount(2, (ExactRootProduct(3, 2),))
        expected = number_record(value)
        self.assertLess(abs(Decimal(expected["decimal_approx"]) - Decimal("6.2426406871192851464050661726290942357")), Decimal("1e-36"))
        for precision, rounding in ((10, ROUND_FLOOR), (60, ROUND_CEILING)):
            with localcontext() as context:
                context.prec, context.rounding = precision, rounding
                self.assertEqual(number_record(value), expected)

    def test_invalid_real_root_is_rejected(self):
        with self.assertRaises(ValueError):
            ExactRootProduct(1, -1)

    def test_zero_coefficients_disappear(self):
        self.assertEqual(ExactAmount(roots=(ExactRootProduct(0, 3),)).as_fraction(), 0)
        self.assertEqual(ExactAmount(roots=(ExactRootProduct(2, 3), ExactRootProduct(-2, 3))).as_fraction(), 0)

    def test_missing_exact_numeric_data_is_rejected(self):
        with self.assertRaises(ValueError):
            amount_from_record({"decimal_approx": "1.2"})
