import unittest
from fractions import Fraction

from combat_sim.mechanics.shield import regenerable_amount, shared_regenerable_amount, split_damage
from combat_sim.mechanics.status import add_status, apply_self_status, apply_status, decay_status, mitigate_status, self_status_value


class ShieldMechanicTests(unittest.TestCase):
    def test_shield_absorbs_raw_damage_before_hp(self):
        self.assertEqual(split_damage(300, 400), (Fraction(300), Fraction(0)))
        self.assertEqual(split_damage(300, 100), (Fraction(100), Fraction(200)))

    def test_regeneration_waits_for_delay_then_stops_at_lost_amount(self):
        self.assertEqual(regenerable_amount(100, 400, 0), Fraction(0))
        self.assertEqual(regenerable_amount(100, 400, 249), Fraction(498, 5))
        self.assertEqual(regenerable_amount(100, 400, 250), Fraction(100))
        self.assertEqual(regenerable_amount(100, 400, 500), Fraction(100))

    def test_eligible_losses_share_the_single_regeneration_rate(self):
        self.assertEqual(shared_regenerable_amount([100, 300], 400, 500), Fraction(200))
        self.assertEqual(shared_regenerable_amount([100, 300], 400, 1000), Fraction(400))


class StatusMechanicTests(unittest.TestCase):
    def test_self_effect_retains_listed_amount_and_running_increase(self):
        self.assertEqual(apply_self_status(0, 100), 100)
        self.assertEqual(apply_self_status(0, 100, is_running_at_application=True), 120)

    def test_self_and_target_use_different_application_rules(self):
        # Target receives 100-1-10=89; self receives all 100 before stacking.
        self.assertEqual(apply_status(200, 100, 500, 0, 10), 289)
        self.assertEqual(apply_self_status(200, 100), 300)
        self.assertEqual(apply_self_status(200, 100, is_running_at_application=True), 320)

    def test_zero_and_negative_self_amounts(self):
        self.assertEqual(apply_self_status(200, 0, is_running_at_application=True), 200)
        with self.assertRaisesRegex(ValueError, "nonnegative"):
            self_status_value(-1)

    def test_status_applications_add(self):
        self.assertEqual(add_status(200, 300), Fraction(500))

    def test_new_status_is_mitigated_before_it_is_added(self):
        # H=500 and armor=0 make the documented mitigation term exactly 1.
        self.assertEqual(mitigate_status(301, 500, 0, 0), 300)
        self.assertEqual(apply_status(200, 301, 500, 0, 0), 500)

    def test_mitigated_status_value_clamps_at_zero(self):
        self.assertEqual(mitigate_status(1, 500, 500, 0), 0)

    def test_only_an_explicit_status_resistance_bonus_changes_the_result(self):
        # H=500, armor=0 gives base mitigation 1. The author's illustrative
        # 200-point shield bonus is an explicit input, not a passive-shield stat.
        self.assertEqual(mitigate_status(301, 500, 0), 300)
        self.assertEqual(mitigate_status(301, 500, 0, resistance=200), 100)

    def test_status_decay_uses_milliseconds_and_stops_at_zero(self):
        self.assertEqual(decay_status(500, 200), Fraction(300))
        self.assertEqual(decay_status(500, 500), Fraction(0))
        self.assertEqual(decay_status(500, 700), Fraction(0))

if __name__ == "__main__":
    unittest.main()
