"""Actual 1E2 Ultimate delivery plus labelled duplication/life/mutation probes."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.simultaneous import DamagePacket, calculate_simultaneous_impacts
from combat_sim.models import UnsupportedMechanicError
from tests.test_equilibrium_combat import scene as base_scene, run, rules
from tests.test_binding_combat import run as configured_run
from tests.test_mobile_combat import events, command, PROFILES, read
from tests.test_world_colliders_combat import wall
from tests.test_impact_bindings_combat import add


def scene(duration=1800, distance=10):
    s=base_scene(duration);s['id']='actual_1e2_ultimate'
    s['encounter']['participants']['B']['position_m']=[distance,-20]
    s['action_selection']['A'].update(abilities=['Ultimate'],start_ms=0,reload_when_empty=False)
    return s


class ImpactAreaCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        json.dumps(r);damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-damage.amount(target=name)),D('1e-8'))
        return damage

    def test_authored_throw_timings_cost_release_power_and_cooldown(self):
        r=run(scene());self.conserved(r)
        self.assertEqual([D(e['time_ms']) for e in events(r,'projectile_released','A')],[370])
        self.assertEqual([D(e['time_ms']) for e in events(r,'self_status_applied','A')],[270])
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('2.25'))
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['Ultimate']),65370)
        power=r['released_attack_power'][0]
        self.assertEqual(power['category'],'intrinsic_momentary')
        self.assertEqual(set(power['components']),{'impact_area'})
        self.assertEqual(D(power['components']['impact_area']['output']),891)
        burst=r['impact_area_bursts'][0];modifier=r['gathering_modifiers'][0]
        self.assertEqual(burst['definition']['radius_m'],8)
        self.assertEqual(D(modifier['expiry_ms'])-D(modifier['started_at_ms']),6000)
        self.assertEqual(D(modifier['addition_ms']),250)

    def test_no_extra_direct_damage_and_each_body_once_with_friendly_self_hit(self):
        s=scene(distance=6);add(s,'C',[8,-20],team='A')
        r=run(s);ledger=self.conserved(r)
        self.assertEqual(r['impact_area_bursts'][0]['recipients'],['A','B','C'])
        self.assertEqual(sorted(m['target'] for m in r['gathering_modifiers']),['A','B','C'])
        expected=calculate_simultaneous_impacts((DamagePacket('qard',891),),150,0,75)[0]
        expected=D(expected.hp_damage.numerator)/D(expected.hp_damage.denominator)
        for name in ('A','B','C'):self.assertAlmostEqual(ledger.amount(target=name),expected,places=35)
        self.assertEqual(ledger.amount(actor='A',eligible_only=True),ledger.amount(target='B'))
        self.assertTrue(all(h['component']=='impact_area' for e in events(r,'impact_batch_resolved') for h in e['hits']))

    def test_personal_shield_absorbs_damage_but_receives_timed_modifier(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['shield']=4000
        r=run(s);self.assertEqual(self.conserved(r).amount(),0)
        self.assertEqual(D(r['final_states']['B']['shield']),3109)
        self.assertEqual(r['gathering_modifiers'][0]['target'],'B')

    def test_actual_next_gun_preparation_gets_the_bonus_separate_from_target_status(self):
        s=read('scenarios/1e2_ultimate.json');r=run(s);self.conserved(r)
        commit=events(r,'gathering_modifier_committed','B')[0]
        start=events(r,'gathering_started','B')[0]
        self.assertEqual(D(commit['added_ms']),250)
        self.assertEqual(D(start['active_start_ms']),D(commit['new_active_start_ms']))
        self.assertEqual(D(start['disorientation_at_start']),0)
        # Sustained fire waits for impact instability to decay, then still gets
        # the independent Gathering addition through its own hand Recovery.
        self.assertGreater(D(start['time_ms']),D(r['impact_area_bursts'][0]['at_ms'])+450)
        self.assertTrue(events(r,'projectile_released','B'))

    def test_existing_gathering_is_extended_on_real_hit(self):
        s=scene(2000);s['action_selection']['B']['start_ms']=100
        s['encounter']['participants']['B']['character']='1E1'
        s['action_selection']['B']['reload_when_empty']=False
        s['encounter']['participants']['B']['initial_state']['disorientation']=800
        r=run(s);self.conserved(r)
        commit=events(r,'gathering_modifier_committed','B')[0]
        self.assertEqual(D(commit['added_ms']),250)
        self.assertEqual(D(commit['time_ms']),D(r['impact_area_bursts'][0]['at_ms']))
        self.assertGreater(D(events(r,'active_started','B')[0]['time_ms']),1150)

    def test_wall_contact_triggers_one_area_and_material_pool_not_direct_plus_area(self):
        s=scene();s['initial_colliders']=[wall('wall',x=5,hp=2000)]
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'projectile_terrain_collision','A'))
        self.assertEqual(D(r['world_collider_states']['wall']['hp']),1109)
        self.assertEqual(r['impact_area_bursts'][0]['recipients'],['A','B'])
        self.assertTrue(all(not e['character_recovery_credit'] for e in events(r,'world_collider_damaged')))

    def test_explicit_area_cover_uses_pre_damage_visibility_even_if_it_breaks(self):
        s=scene();s['initial_colliders']=[wall('cover',x=5,hp=800,
            blocking={'projectiles':True,'bodies':True,'areas':True})]
        r=run(s);self.conserved(r)
        self.assertEqual(r['world_collider_states']['cover']['status'],'destroyed')
        self.assertEqual(r['impact_area_bursts'][0]['recipients'],['A'])
        self.assertFalse([m for m in r['gathering_modifiers'] if m['target']=='B'])

    def test_block_surface_triggers_device_and_explosion_uses_existing_area_semantics(self):
        s=scene(distance=4);s['encounter']['participants']['B']['character']='2E4'
        s['action_selection']['B'].update(abilities=['basic_8'],held_blocks=['basic_8'],start_ms=350)
        r=run(s);ledger=self.conserved(r)
        self.assertIn('block_layer_id',r['impact_area_bursts'][0]['origin_contact'])
        self.assertGreater(ledger.amount(target='B'),0)
        self.assertFalse(events(r,'block_layer_damage'))
        self.assertIn('B',[m['target'] for m in r['gathering_modifiers']])

    def test_source_death_before_release_cancels_unpaid_throw(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        r=run(scene(),operations=((300,kill),))
        self.assertFalse(r['impact_area_bursts']);self.assertFalse(r['gathering_modifiers'])
        self.assertFalse(events(r,'projectile_released','A'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_source_death_after_release_preserves_burst_and_effect_original_life(self):
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        r=run(scene(),operations=((400,kill),))
        self.assertEqual(len(r['impact_area_bursts']),1)
        self.assertEqual(r['gathering_modifiers'][0]['source_life_generation'],1)
        self.assertEqual(r['gathering_modifiers'][0]['status'],'active')

    def test_lethal_burst_has_no_post_death_modifier_or_stale_effect_on_revival(self):
        s=scene(3000);s['encounter']['participants']['B'].update(character='2E4')
        s['encounter']['participants']['B']['initial_state']['hp']=100
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'character_died','B'));self.assertEqual(r['gathering_modifiers'],[])
        self.assertEqual(r['impact_area_effect_hits'][0]['status'],'recipient_life_ended')
        # No earlier eligible damage means2E4 has no revival allowance.
        self.assertEqual(r['final_states']['B']['life_generation'],1)
        self.assertFalse(r['final_states']['B']['alive'])

    def test_real_revive_uses_earned_allowance_and_has_no_old_life_modifier(self):
        s=scene(3000);s['encounter']['participants']['B'].update(character='2E4')
        s['encounter']['participants']['B']['initial_state']['hp']=100
        s['action_selection']['B'].update(start_ms=0,reload_when_empty=False)
        add(s,'C',['8.9','-19.55'],team='A')
        r=run(s);self.conserved(r)
        self.assertEqual(r['final_states']['B']['life_generation'],2)
        self.assertFalse([m for m in r['gathering_modifiers'] if m['target']=='B'])

    def test_real_hit_cancels_sustained_preparation_but_does_not_lose_later_modifier(self):
        s=scene(2000);s['action_selection']['B']['start_ms']=100
        s['encounter']['participants']['B']['initial_state']['disorientation']=900
        r=run(s);self.conserved(r)
        cancelled=events(r,'controlled_action_cancelled','B')[0]
        self.assertEqual(cancelled['reason'],'sustained_control_instability')
        self.assertEqual(D(cancelled['time_ms']),D(r['impact_area_bursts'][0]['at_ms']))
        commits=events(r,'gathering_modifier_committed','B')
        self.assertTrue(commits)
        self.assertTrue(all(e['action_id']!=cancelled['action_id'] for e in commits))
        self.assertTrue(events(r,'projectile_released','B'))

    def test_copy_explodes_independently_in_same_defense_snapshot_without_stacking_delay(self):
        def copy(w):w.projectile_system.copy('projectile:1',source='explicit_ultimate_duplication_api_probe',offset_m=(0,0,0))
        s=scene();s['encounter']['participants']['B']['initial_state']['shield']=1000
        r=run(s,operations=((400,copy),));ledger=self.conserved(r)
        self.assertEqual(len(r['impact_area_bursts']),2);self.assertEqual(len(r['gathering_modifiers']),2)
        batches=events(r,'impact_batch_resolved');self.assertEqual(len(batches),1)
        self.assertEqual(len(batches[0]['hits']),2)
        cs=calculate_simultaneous_impacts((DamagePacket('qard',891),)*2,150,1000,75)
        expected=sum((D(c.hp_damage.numerator)/D(c.hp_damage.denominator) for c in cs),D(0))
        self.assertAlmostEqual(ledger.amount(target='B'),expected,places=35)

    def test_release_freezes_radius_duration_status_and_family_against_later_profile_changes(self):
        profiles=deepcopy(PROFILES)
        def change(w):
            a=w.fighters['A'].profile['abilities']['Ultimate']
            a['impact_area']['radius_m']=1;a['impact_area']['gathering_modifier']['addition_ms']=999
            a['target_effects']['disorientation']=0;a['damage_type']='blunt';a['pre_mitigation_damage']=1
        s=scene();r=configured_run(s,rules=rules(),profiles=profiles,operations=((400,change),))
        self.assertEqual(r['impact_area_bursts'][0]['damage_type'],'qard')
        self.assertEqual(r['impact_area_bursts'][0]['definition']['radius_m'],8)
        self.assertEqual(D(r['gathering_modifiers'][0]['addition_ms']),250)
        self.assertEqual(r['final_states']['B']['hp'],run(s)['final_states']['B']['hp'])

    def test_no_enemy_explicit_ground_target_still_throws_hits_ground_and_can_self_damage(self):
        s=scene(2000);s['encounter']['participants']['B']['team']='A'
        s['encounter']['participants']['B']['position_m']=[30,-20]
        s['action_selection']['A']['ability_targets']={'Ultimate':{'kind':'world_point','point_m':[5,-20,0]}}
        r=run(s);ledger=self.conserved(r)
        self.assertTrue(events(r,'projectile_terrain_collision'))
        self.assertEqual(r['impact_area_bursts'][0]['recipients'],['A'])
        self.assertGreater(ledger.amount(target='A'),0)

    def test_current_input_order_precision_and_sampling_controls_agree(self):
        s=scene();reference=run(s)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        r=run(s,precision=80,interval=17);self.conserved(r)
        self.assertEqual(reference['impact_area_bursts'][0]['recipients'],r['impact_area_bursts'][0]['recipients'])
        for name in r['final_states']:
            for key in ('hp','armor','shield','disorientation','instability','dyspnea'):
                self.assertLess(abs(D(reference['final_states'][name][key])-D(r['final_states'][name][key])),D('1e-8'))

    def test_missing_rules_and_unsupported_delivery_definitions_fail_on_selection(self):
        cfg=rules();cfg.pop('timed_gathering')
        with self.assertRaises(UnsupportedMechanicError):configured_run(scene(),rules=cfg)
        profiles=deepcopy(PROFILES);profiles['1E2']['abilities']['Ultimate']['impact_area']['shape']='cube'
        with self.assertRaises(UnsupportedMechanicError):configured_run(scene(),rules=rules(),profiles=profiles)
