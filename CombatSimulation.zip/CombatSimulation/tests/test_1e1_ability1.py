"""Controlled ability tests; synthetic fixtures are labeled where used."""

from copy import deepcopy
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction
import json
from pathlib import Path
import unittest

from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario
from combat_sim.models import UnsupportedMechanicError

ROOT = Path(__file__).resolve().parents[1]
CHARACTERS = json.loads((ROOT / "data/characters.json").read_text())["characters"]
SCENARIO = json.loads((ROOT / "scenarios/1e1_projectile_and_delayed_blast.json").read_text())


def impacts(run):
    return [event for event in run["events"] if event["type"] == "impact_resolved"]


class Ability1E1Tests(unittest.TestCase):
    def test_two_qard_hits_at_documented_times_and_expected_final_state(self):
        run = run_scenario(SCENARIO, CHARACTERS)
        hits = impacts(run)
        self.assertEqual([hit["time_ms"] for hit in hits], [420, 920])
        self.assertEqual([hit["damage_calculation"]["outputs"]["y"]["exact"] for hit in hits], ["779/2", "779/2"])
        self.assertEqual(run["final_states"]["2E4"]["hp"]["exact"], "8301")
        self.assertEqual(run["final_states"]["2E4"]["armor"]["exact"], "165")
        self.assertEqual(summarize(run)["hp_damage"]["exact"], "779")
        self.assertEqual(summarize(run)["armor_lost"]["exact"], "0")
        self.assertEqual(next(e["time_ms"] for e in run["events"] if e["type"] == "self_effect_triggered"), 230)
        release = next(e for e in run["events"] if e["type"] == "projectile_released")
        self.assertEqual(release["time_ms"], 320)
        self.assertEqual(Decimal(release["actor_state"]["disorientation"]["decimal"]), 50)
        self.assertEqual(Decimal(run["final_states"]["1E1"]["disorientation"]["decimal"]), 0)

    def test_self_effect_ignores_hp_armor_and_additional_resistance(self):
        # Synthetic defenses vary greatly; both self effects remain 140.
        for hp, armor, resistance in ((500, 0, 10), (50000, 10000, 10000)):
            with self.subTest(hp=hp, armor=armor, resistance=resistance):
                scenario, characters = deepcopy(SCENARIO), deepcopy(CHARACTERS)
                characters["1E1"].update(max_hp=hp, status_resistance=resistance)
                scenario["encounter"]["initial_states"]["1E1"].update(hp=hp, armor=armor)
                run = run_scenario(scenario, characters)
                applications = [e for e in run["events"] if e["type"] == "status_applied" and e["origin"] == "self"]
                self.assertEqual(len(applications), 2)
                self.assertEqual([Decimal(e["after"]["decimal"]) for e in applications], [140, 140])
                self.assertTrue(all(e["mitigation_applied"] is False for e in applications))
                self.assertTrue(all("after_mitigation" not in e for e in applications))
                self.assertTrue(all(set(e["inputs"]) == {"N"} for e in applications))
                release = next(e for e in run["events"] if e["type"] == "projectile_released")
                self.assertEqual(Decimal(release["actor_state"]["instability"]["decimal"]), 50)

    def test_fully_shielded_hits_still_apply_both_target_effects(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["2E4"]["shield"] = 900
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(run["final_states"]["2E4"]["hp"]["exact"], "9080")
        self.assertEqual(run["final_states"]["2E4"]["armor"]["exact"], "165")
        self.assertEqual(run["final_states"]["2E4"]["shield"]["exact"], "0")
        effects = [e for e in run["events"] if e["type"] == "status_applied" and e["target"] == "2E4"]
        self.assertEqual([e["time_ms"] for e in effects], [420, 420, 920, 920])
        self.assertTrue(all(Decimal(e["after_mitigation"]["decimal"]) > 0 for e in effects))

    def test_only_shield_overflow_enters_qard_formula(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["2E4"]["shield"] = 600
        run = run_scenario(scenario, CHARACTERS)
        first, second = impacts(run)
        self.assertEqual(first["damage_calculation"]["formula_evaluation"], "skipped_fully_absorbed_by_shield")
        calculation = second["damage_calculation"]
        self.assertEqual(calculation["shield_handling"]["damage_to_shield"]["exact"], "150")
        self.assertEqual(calculation["formula_inputs"]["dq_left_after_shield"], "300")
        # (300² - 165²)/300 = 209.25; no Qard armor loss.
        self.assertEqual(calculation["outputs"]["y"]["exact"], "837/4")
        self.assertEqual(run["final_states"]["2E4"]["hp"]["exact"], "35483/4")
        self.assertEqual(run["final_states"]["2E4"]["armor"]["exact"], "165")
        self.assertEqual([e["eligible_at_ms"] for e in run["events"] if e["type"] == "shield_regeneration_scheduled"], [20420, 20920])
        self.assertEqual([c["remaining"]["exact"] for c in run["pending_shield_regeneration"]], ["450", "150"])

    def test_both_losses_keep_their_delays_and_share_regeneration(self):
        for until, expected in ((20419, "0"), (21000, "232"), (22000, "600")):
            with self.subTest(until=until):
                scenario = deepcopy(SCENARIO)
                scenario["encounter"]["initial_states"]["2E4"]["shield"] = 600
                scenario["run_until_ms"] = until
                run = run_scenario(scenario, CHARACTERS)
                self.assertEqual(run["final_states"]["2E4"]["shield"]["exact"], expected)
                if until == 22000:
                    eligible = {a["eligible_from_ms"] for e in run["events"] if e["type"] == "shield_regenerated" for a in e["eligible_loss_allocations"]}
                    self.assertEqual(eligible, {20420, 20920})

    def test_area_can_hit_multiple_explicit_recipients_with_per_target_summary(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["3E5"] = {"hp": 11400, "armor": 250, "shield": 0}
        scenario["action_sequence"][0]["area_targets"] = ["3E5", "2E4"]
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(len(impacts(run)), 3)
        self.assertEqual(run["final_states"]["3E5"]["hp"]["exact"], "99800/9")
        self.assertEqual(run["final_states"]["3E5"]["armor"]["exact"], "250")
        summary = summarize(run)
        self.assertEqual(summary["targets"], ["2E4", "3E5"])
        self.assertEqual(summary["hp_damage"]["exact"], "9811/9")
        self.assertEqual(summary["per_target"]["2E4"]["hp_damage"]["exact"], "779")
        self.assertEqual(summary["per_target"]["3E5"]["hp_damage"]["exact"], "2800/9")
        self.assertNotIn("final_hp", summary)

    def test_explicit_empty_area_list_does_not_invent_targets(self):
        scenario = deepcopy(SCENARIO)
        scenario["action_sequence"][0]["area_targets"] = []
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(len(impacts(run)), 1)
        self.assertEqual(run["final_states"]["2E4"]["hp"]["exact"], "17381/2")
        self.assertTrue(any(e["type"] == "area_detonated" for e in run["events"]))

    def test_existing_status_decays_then_new_mitigated_status_adds(self):
        # Synthetic exact fixture: each target application is 110-1-10=99.
        # At impact O=1000-420=580; after hit 679; at blast 179; after blast 278.
        scenario, characters = deepcopy(SCENARIO), deepcopy(CHARACTERS)
        characters["2E4"].update(max_hp=500, status_resistance=10)
        characters["2E4"]["resistances"]["qard"] = 0
        characters["1E1"]["abilities"]["1"]["pre_mitigation_damage"] = 10
        scenario["encounter"]["initial_states"]["2E4"].update(hp=500, armor=0, disorientation=1000, instability=1000)
        run = run_scenario(scenario, characters)
        target = run["final_states"]["2E4"]
        self.assertEqual(Decimal(target["disorientation"]["decimal"]), 278)
        self.assertEqual(Decimal(target["instability"]["decimal"]), 278)
        self.assertEqual(target["hp"]["exact"], "480")

    def test_initial_disorientation_adds_gathering_once(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"]["disorientation"] = 80
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual([e["time_ms"] for e in impacts(run)], [500, 1000])
        self.assertEqual(impacts(run)[0]["timing_calculation"]["effective_gathering_ms"], 220)

    def test_initial_status_decays_before_later_activation(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"]["disorientation"] = 200
        scenario["action_sequence"][0]["action_start_ms"] = 100
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(impacts(run)[0]["timing_calculation"]["additional_gathering_ms"], 100)
        self.assertEqual([e["time_ms"] for e in impacts(run)], [620, 1120])

    def test_zero_distance_release_precedes_hit_at_same_time(self):
        scenario = deepcopy(SCENARIO)
        scenario["action_sequence"][0]["target_distance_m"] = 0
        run = run_scenario(scenario, CHARACTERS)
        at_release = [e["type"] for e in run["events"] if e["time_ms"] == 320]
        self.assertLess(at_release.index("projectile_released"), at_release.index("impact_resolved"))
        self.assertEqual([e["time_ms"] for e in impacts(run)], [320, 820])

    def test_replay_input_immutability_and_decimal_context_independence(self):
        scenario, characters = deepcopy(SCENARIO), deepcopy(CHARACTERS)
        baseline = run_scenario(scenario, characters)
        for precision, rounding in ((10, ROUND_CEILING), (60, ROUND_FLOOR)):
            with self.subTest(precision=precision), localcontext() as context:
                context.prec, context.rounding = precision, rounding
                self.assertEqual(run_scenario(scenario, characters), baseline)
        self.assertEqual(scenario, SCENARIO)
        self.assertEqual(characters, CHARACTERS)
        times = [Fraction(e["time_ms"]) if isinstance(e["time_ms"], int) else Fraction(e["time_ms"]["exact"]) for e in baseline["events"]]
        self.assertEqual(times, sorted(times))

    def test_unsupported_movement_repeated_activations_and_fields_are_rejected(self):
        for mutation in ("running", "repeated", "action_field", "state_field"):
            with self.subTest(mutation=mutation):
                scenario = deepcopy(SCENARIO)
                if mutation == "running":
                    scenario["encounter"]["movement"] = "running"
                elif mutation == "repeated":
                    scenario["action_sequence"].append(deepcopy(scenario["action_sequence"][0]))
                elif mutation == "action_field":
                    scenario["action_sequence"][0]["is_running"] = True
                else:
                    scenario["encounter"]["initial_states"]["1E1"]["dyspnea"] = 0
                with self.assertRaises(UnsupportedMechanicError):
                    run_scenario(scenario, CHARACTERS)

    def test_missing_duplicate_or_unknown_area_recipients_are_rejected(self):
        for targets in (None, ["2E4", "2E4"], ["unknown"]):
            with self.subTest(targets=targets):
                scenario = deepcopy(SCENARIO)
                scenario["action_sequence"][0]["area_targets"] = targets
                with self.assertRaises(ValueError):
                    run_scenario(scenario, CHARACTERS)

    def test_missing_distance_and_truncated_blast_are_rejected(self):
        scenario = deepcopy(SCENARIO)
        scenario["action_sequence"][0].pop("target_distance_m")
        with self.assertRaisesRegex(UnsupportedMechanicError, "distance is required"):
            run_scenario(scenario, CHARACTERS)
        scenario = deepcopy(SCENARIO)
        scenario["run_until_ms"] = 919
        with self.assertRaisesRegex(ValueError, "delayed blast"):
            run_scenario(scenario, CHARACTERS)

    def test_negative_initial_status_is_rejected(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"]["instability"] = -1
        with self.assertRaisesRegex(ValueError, "nonnegative"):
            run_scenario(scenario, CHARACTERS)
