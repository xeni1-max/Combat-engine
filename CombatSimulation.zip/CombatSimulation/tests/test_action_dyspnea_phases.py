"""Authored payment events, exemptions, and cancellation before payment."""
from fractions import Fraction as F
import json
from pathlib import Path
import unittest

from combat_sim.mechanics.dyspnea import apply_action_dyspnea_at_phase
from combat_sim.models import UnsupportedMechanicError


CHARACTERS = json.loads((Path(__file__).resolve().parents[1] / 'data/characters.json').read_text())['characters']
QARD = CHARACTERS['1E1']['abilities']['1']['dyspnea']
GUN = CHARACTERS['1E2']['abilities']['1']['dyspnea']
RELOAD = CHARACTERS['1E2']['abilities']['1']['reload_dyspnea']
BEAM = CHARACTERS['1E1']['abilities']['4']['dyspnea']


class ActionDyspneaPhaseTests(unittest.TestCase):
    def test_qard_and_gun_charge_at_firing_end_using_current_dyspnea(self):
        for rule in (QARD, GUN):
            with self.subTest(rule=rule):
                for phase in ('recovery_start', 'gathering_start', 'active_start'):
                    self.assertIsNone(apply_action_dyspnea_at_phase(50, rule, phase))
                paid = apply_action_dyspnea_at_phase(50, rule, 'active_firing_end')
                self.assertTrue(paid.allowed)
                self.assertEqual(paid.action_value, F(25, 4))
                self.assertEqual(paid.after, F(225, 4))

    def test_reload_pays_at_active_start_with_its_own_base_value(self):
        self.assertIsNone(apply_action_dyspnea_at_phase(50, RELOAD, 'gathering_start'))
        paid = apply_action_dyspnea_at_phase(50, RELOAD, 'active_start')
        self.assertEqual((paid.action_value, paid.after), (1, 51))
        self.assertIsNone(apply_action_dyspnea_at_phase(51, RELOAD, 'active_firing_end'))

    def test_death_before_payment_incurred_no_cost_for_any_costed_action(self):
        for rule in (QARD, GUN, RELOAD):
            self.assertIsNone(apply_action_dyspnea_at_phase(
                50, rule, rule['payment_timing'], cancelled_before_payment=True))

    def test_beam_remains_exempt_even_at_nonzero_or_maximum_dyspnea(self):
        for current in (0, 50, 100):
            for phase in ('gathering_start', 'active_start', 'active_firing_end'):
                self.assertIsNone(apply_action_dyspnea_at_phase(current, BEAM, phase))

    def test_insufficient_capacity_is_checked_at_payment_and_returns_no_addition(self):
        self.assertIsNone(apply_action_dyspnea_at_phase(95, GUN, 'active_start'))
        payment = apply_action_dyspnea_at_phase(95, GUN, 'active_firing_end')
        self.assertFalse(payment.allowed)
        self.assertEqual(payment.action_value, F(3481, 400))
        self.assertEqual(payment.after, 95)
        self.assertEqual(payment.disorientation_trigger, 0)

    def test_existing_cap_trigger_is_preserved_at_the_payment_event(self):
        rule = dict(QARD, base_value=10)
        payment = apply_action_dyspnea_at_phase(0, rule, 'active_firing_end')
        self.assertTrue(payment.reached_maximum)
        self.assertEqual(payment.after, 100)
        self.assertEqual(payment.disorientation_trigger, 200)

    def test_missing_or_incompatible_timing_cannot_silently_pay(self):
        for rule in (dict(QARD, payment_timing='unknown'),
                     dict(QARD, capacity_check_timing='active_start'),
                     {'kind': 'unknown'}):
            with self.assertRaises(UnsupportedMechanicError):
                apply_action_dyspnea_at_phase(0, rule, 'active_firing_end')
