"""Cross-feature invariants established by the principal engineering review."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from combat_sim.shared_engine import SharedEncounter
from combat_sim.hitboxes import Cuboid
from tests.collider_fixtures import add_fixture_collider
from tests.test_airborne_combat import JUMP, run as air_run
from tests.test_climb_combat import CLIMB, climb, scene
from tests.test_mobile_combat import BODY, EFFECTS, MOVEMENT, PROFILES, TERRAIN, command, events
from tests.test_sprint_combat import PHYSICS, run, scenario


class CommandInvariantTests(unittest.TestCase):
    def test_blocked_compound_run_and_sprint_finish_once_without_zero_speed_cycle(self):
        for action in ('run','sprint'):
            with self.subTest(action=action):
                s=scenario(2000);s['encounter']['participants']['A']['position_m']=[0,0]
                command(s,'A',0,action);command(s,'A',1500,action)
                r=run(s,sample_interval_ms=None)
                blocked=events(r,'movement_intent_blocked','A')
                self.assertEqual(len(blocked),1)
                self.assertEqual(blocked[0]['action'],action)
                self.assertEqual(D(blocked[0]['time_ms']),1500)
                contacts=[e for e in events(r,'body_contact') if D(e['time_ms'])==1500]
                self.assertEqual(len(contacts),1)
                self.assertEqual(D(contacts[0]['raw_status']),0)
                self.assertEqual(D(r['run_until_ms']),2000)

    def test_new_command_can_retry_after_moving_blocker_leaves(self):
        s=scenario(3000,target=(4,-20))
        s['encounter']['participants']['B']['movement_direction']=[0,1]
        command(s,'A',0,'run');command(s,'A',1500,'run')
        command(s,'B',1600,'walk');command(s,'A',2200,'run')
        r=run(s,sample_interval_ms=None)
        self.assertEqual(len(events(r,'movement_intent_blocked','A')),1)
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),6)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'running')

    def test_noops_dispatch_each_following_action_family_including_targeted_climb(self):
        for action,event in (('jump','jump_takeoff'),('crouch','crouch_completed'),
                             ('sprint','sprint_transition_requested'),('climb','climb_completed')):
            with self.subTest(action=action):
                s=scene(1200) if action=='climb' else scenario(1200)
                for noop in ('stop','stand','stop','stand'):
                    command(s,'A',0,noop)
                if action=='climb':climb(s)
                else:command(s,'A',0,action)
                r=air_run(s,climb_definition=CLIMB if action=='climb' else None,sample_interval_ms=None)
                self.assertEqual(len(events(r,event,'A')),1)
                self.assertEqual(D(r['run_until_ms']),1200)

    def test_long_noop_queue_is_iterative_and_costs_nothing(self):
        s=scenario(500)
        for i in range(1200):command(s,'A',0,'stop' if i%2 else 'stand')
        command(s,'A',0,'crouch')
        r=run(s,sample_interval_ms=None)
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)
        self.assertEqual(r['metrics']['A']['crouches_completed'],1)

    def test_future_commands_and_optional_jump_action_data_preserve_api_prefix(self):
        base=scenario(1600,target=(4,'-19.5'))
        base['encounter']['participants']['A']['movement_direction']=[1,'.2']
        command(base,'A',0,'run');command(base,'B',0,'crouch')
        before=run(base,sample_interval_ms=100)
        future=deepcopy(base);command(future,'B',1500,'jump')
        after=air_run(future,sample_interval_ms=100)
        for key in ('curve','events'):
            prefix=lambda r:[e for e in r[key] if D(e['time_ms'])<=1000]
            self.assertEqual(prefix(before),prefix(after))
        self.assertEqual(before['world_ruleset']['id'],'integrated_v2')

    def test_future_jump_or_climb_cannot_change_cli_prefix(self):
        root=Path(__file__).resolve().parents[1]
        prefixes=[]
        with tempfile.TemporaryDirectory(prefix='combat-prefix-') as directory:
            for action in (None,'jump','climb'):
                s=scenario(1600,target=(4,'-19.5'))
                s['encounter']['participants']['A']['movement_direction']=[1,'.2']
                command(s,'A',0,'run');command(s,'B',0,'crouch')
                if action=='climb':climb(s,actor='B',time=1500)
                elif action:command(s,'B',1500,action)
                path=Path(directory)/(str(action)+'.json');path.write_text(json.dumps(s))
                r=json.loads(subprocess.check_output([sys.executable,'-B','-m','combat_sim','run',str(path)],cwd=root,text=True,timeout=15))
                prefixes.append([e for e in r['curve'] if D(e['time_ms'])<=1000])
        self.assertEqual(prefixes[0],prefixes[1])
        self.assertEqual(prefixes[0],prefixes[2])

    def test_airborne_fire_does_not_increase_commanded_pace_across_repeated_jumps(self):
        for pace,speed in (('walk',D(2)),('run',D('6.4'))):
            for precision,interval in ((50,None),(80,37)):
                with self.subTest(pace=pace,precision=precision):
                    s=scenario(2800,fire_at=900,target=(200,-20))
                    command(s,'A',0,pace);command(s,'A',300,'jump');command(s,'A',1500,'jump')
                    r=air_run(s,precision=precision,sample_interval_ms=interval)
                    self.assertEqual(r['metrics']['A']['jumps_started'],2)
                    self.assertGreaterEqual(r['metrics']['A']['landings'],2)
                    f=r['final_states']['A']['locomotion']
                    self.assertTrue(f['grounded'])
                    self.assertEqual(D(f['nominal_speed_mps']),speed)
                    self.assertLessEqual(D(f['speed_mps']),speed)

    def test_record_is_a_value_snapshot_of_nested_hands_and_locomotion(self):
        s=scenario(200,fire_at=0)
        with localcontext(Context(prec=50)):
            engine=SharedEncounter(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=EFFECTS,
                projectile_physics_definition=PHYSICS)
            actor=engine.fighters['A'];saved=actor.record();expected=deepcopy(saved)
            actor.hands['left'][0]=999
            actor.locomotion['hand_world_positions_m']['left'][0]='999'
            self.assertEqual(saved,expected)
        r=run(s,sample_interval_ms=None)
        self.assertEqual(r['initial_states']['A']['hands_m'],PROFILES['1E2']['initial_hand_positions_m'])
        self.assertEqual(r['initial_states']['A']['hands_m'],r['curve'][0]['states']['A']['hands_m'])

    def test_incoming_airborne_instability_cannot_become_ground_drive(self):
        s=scenario(1450,target=(200,-20));s['action_selection']['B']['start_ms']=300
        command(s,'A',0,'run');command(s,'A',300,'jump')
        r=air_run(s,sample_interval_ms=37)
        landing=D(events(r,'jump_landed','A')[0]['time_ms'])
        hits=[e for e in events(r,'projectile_body_collision','B') if e['target']=='A' and 420<D(e['time_ms'])<landing]
        self.assertTrue(hits)
        self.assertEqual(D(r['final_states']['A']['locomotion']['nominal_speed_mps']),D('6.4'))
        self.assertLessEqual(D(r['final_states']['A']['locomotion']['speed_mps']),D('6.4'))
        air=[p['states']['A'] for p in r['curve'] if 420<D(p['time_ms'])<landing]
        self.assertTrue(all(D(f['locomotion']['velocity_mps'][0])==D('6.4') for f in air))

    def test_blocked_stand_prerequisite_rejects_parent_climb_without_retry(self):
        s=scene(700);command(s,'A',0,'crouch');climb(s,time=200)
        class ObstructedEncounter(SharedEncounter):
            def __init__(self,*args,**kwargs):
                super().__init__(*args,**kwargs);self.push(D(150),'fixture_ceiling',{})
            def _process(self,kind,payload):
                if kind=='fixture_ceiling':
                    add_fixture_collider(self,'ceiling',(Cuboid('ceiling',['4.6',0,'1.6'],[1,2,'.2']),))
                    return
                return super()._process(kind,payload)
        with localcontext(Context(prec=50)):
            r=ObstructedEncounter(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=EFFECTS,
                jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS).run()
        rejected=events(r,'movement_intent_rejected','A')
        self.assertEqual(len(rejected),1)
        self.assertEqual(rejected[0]['action'],'climb')
        self.assertEqual(rejected[0]['reason'],'prerequisite_rejected')
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)
        self.assertEqual(r['metrics']['A']['climbs_started'],0)


if __name__=='__main__':unittest.main()
