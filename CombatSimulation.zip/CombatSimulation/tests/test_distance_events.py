"""Quadratic distance exits, including tangencies and moving anchors."""
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.distance_events import first_distance_exit


class DistanceEventTests(unittest.TestCase):
    def test_radial_crossing_has_exact_bracket(self):
        low,high=first_distance_exit((0,0,0),(2,0,0),(0,0,0),10,10)
        self.assertLessEqual(low,5);self.assertGreaterEqual(high,5);self.assertLessEqual(high-low,F(1,10**18))

    def test_tangential_motion_at_limit_exits_immediately(self):
        self.assertEqual(first_distance_exit((10,0,0),(0,2,0),(0,0,0),10,1),(0,0))

    def test_inward_motion_and_internal_tangent_are_not_exits(self):
        self.assertIsNone(first_distance_exit((10,0,0),(-2,0,0),(0,0,0),10,1))
        self.assertIsNone(first_distance_exit((9,0,0),(2,0,0),(-2,0,0),10,2))

    def test_gravity_and_outward_endpoint_are_detected(self):
        self.assertEqual(first_distance_exit((0,0,0),(0,0,0),(0,0,-2),1,1),(1,1))

    def test_initial_outside_and_relative_anchor_speed(self):
        self.assertEqual(first_distance_exit((11,0,0),(-1,0,0),(0,0,0),10,1),(0,0))
        a=first_distance_exit((0,0,0),(30,0,0),(0,0,0),20,2)
        b=first_distance_exit((0,0,0),(22,0,0),(0,0,0),20,2)
        self.assertGreater(b[0],a[1])


if __name__=='__main__':unittest.main()
