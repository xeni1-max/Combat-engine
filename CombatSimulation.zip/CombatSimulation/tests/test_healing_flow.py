"""Continuous healing is jointly constrained with incoming HP and funding."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.damage_ledger import DamageLedger,DamageContribution,QuarticDose,AffineHeatDose
from combat_sim.mechanics.healing_flow import DoseSum,ExpiringFunding,build_healing_flow


def constant(rate,end=1000):return QuarticDose(0,end,0,D(rate)*D(end)/1000,(D(rate),0,0,0))


def plan(*,hp=100,max_hp=1000,incoming=100,entitlement=20,funding=0,cursor=0,end=1000,
         incoming_curve=None,entitlement_curve=None,history=None,begin=0):
    history=history or DamageLedger();history.observe_until(begin)
    incoming_curve=incoming_curve or constant(incoming,end)
    entitlement_curve=entitlement_curve or constant(entitlement,end)
    expiry=ExpiringFunding.snapshot(history,'A',D(begin),D(end))
    return build_healing_flow(D(begin),D(end),hp=hp,max_hp=max_hp,
        incoming=DoseSum(((D(1),incoming_curve),)),entitlement=DoseSum(((D(1),entitlement_curve),)),
        funding_total=D(funding),cursor=D(cursor),expiring=expiry)


class HealingFlowTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=50));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_lifesteal_changes_the_continuous_death_crossing(self):
        p=plan(end=2000)
        self.assertAlmostEqual(p.death(),D(1250),places=8)
        hp,heal,cursor=p.at(1000)
        self.assertAlmostEqual(hp,20,places=20)
        self.assertAlmostEqual(heal,20,places=20)
        self.assertAlmostEqual(cursor,20,places=20)

    def test_incoming_damage_can_exceed_initial_hp_while_healing_keeps_body_alive(self):
        p=plan(hp=100,incoming=200,entitlement=150)
        hp,heal,cursor=p.at(1000)
        self.assertAlmostEqual(hp,50,places=20)
        self.assertAlmostEqual(heal,150,places=20)
        self.assertIsNone(p.death())

    def test_empty_budget_limits_healing_to_new_90_percent_flow(self):
        p=plan(hp=500,incoming=100,entitlement=200)
        hp,heal,cursor=p.at(1000)
        self.assertLess(abs(heal-90),D('1e-9'))
        self.assertLess(abs(hp-490),D('1e-9'))
        self.assertLess(abs(cursor-90),D('1e-9'))

    def test_old_funding_can_be_consumed_then_fresh_flow_supplies_the_cap(self):
        p=plan(hp=500,incoming=100,entitlement=200,funding=50)
        # 200/s initially; after 50/(200-90) s the funding queue empties.
        self.assertLess(abs(p.at(1000)[1]-140),D('1e-8'))

    def test_no_incoming_funding_means_initial_missing_hp_cannot_be_healed(self):
        p=plan(hp=100,incoming=0,entitlement=200)
        self.assertEqual(p.at(1000),(D(100),D(0),D(0)))

    def test_maximum_hp_limits_healing_without_banking_extra_entitlement(self):
        p=plan(hp=990,max_hp=1000,incoming=0,entitlement=100,funding=100)
        self.assertLess(abs(p.at(1000)[0]-1000),D('1e-8'))
        self.assertLess(abs(p.at(1000)[1]-10),D('1e-8'))

    def test_full_hp_still_allows_simultaneous_damage_replacement(self):
        p=plan(hp=1000,max_hp=1000,incoming=100,entitlement=200,funding=100)
        self.assertLess(abs(p.at(1000)[0]-1000),D('1e-8'))
        self.assertLess(abs(p.at(1000)[1]-100),D('1e-8'))

    def test_prefix_reads_do_not_rebuild_or_change_the_dense_solution(self):
        p=plan(hp=500,incoming=100,entitlement=200,funding=50)
        final=p.at(1000);steps=p.dense.steps
        for time in (137,20,777,0,400):p.at(time)
        self.assertEqual(p.at(1000),final);self.assertIs(p.dense.steps,steps)
        self.assertLess(abs(p.healing_curve().integral(D(0),D(777))-p.at(777)[1]),D('1e-8'))

    def test_nonlinear_root_outgoing_heals_with_its_actual_time_distribution(self):
        root=AffineHeatDose(100,0,0,1)
        p=plan(hp=500,incoming=200,entitlement_curve=root,funding=100)
        self.assertLess(abs(p.at(1000)[1]-D(200)/3),D('1e-8'))

    def test_expiring_continuous_capacity_advances_the_fifo_cursor(self):
        history=DamageLedger();curve=constant(1000,1000)
        history.record_loss('wound','A',0,1000,
            (DamageContribution(EffectSource('B','1',1),1000,'slash',True,curve),),1000)
        p=plan(hp=100,incoming=0,entitlement=20,funding=900,history=history,begin=8000,end=8250,
            incoming_curve=QuarticDose(8000,8250,0,0,(0,0,0,0)),
            entitlement_curve=QuarticDose(8000,8250,0,5,(20,0,0,0)))
        self.assertLess(abs(p.at(8250)[1]-5),D('1e-8'))
        self.assertLess(abs(p.at(8250)[2]-225),D('1e-8'))


if __name__=='__main__':unittest.main()
