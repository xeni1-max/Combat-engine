"""Continuous open cells, cover witnesses and shared saved angular clocks."""
from dataclasses import replace
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.angular_paths import RotatingBoxPath, YawArc
from combat_sim.angular_volumes import angular_cells
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.models import UnsupportedMechanicError
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.volume_geometry import sphere_cells, column_cells, box_cells


def path(*,angle=90,centre=(0,1,0),size=('.2','.8',1),reference=(0,0,0),velocity=(0,0,0),
         acceleration=(0,0,0),local_velocity=(0,0,0),rate=(0,0,0),size_accel=(0,0,0),precision=70):
    return RotatingBoxPath(BodyPathPiece(0,1000,reference,velocity,acceleration),
        YawArc(0,1,YawFrame(),angle,precision),Cuboid('part',centre,size),local_velocity_mps=local_velocity,
        size_rate_mps=rate,size_acceleration_mps2=size_accel)


class AngularVolumeTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def same(self,a,b):
        self.assertEqual([s for _,s in a],[s for _,s in b])
        for (x,_),(y,_) in zip(a,b):self.assertLess(abs(x-y),D('1e-24'))

    def test_column_and_sphere_have_same_planar_exit(self):
        p=path();a=sphere_cells((1,0,0),'.15',[p],1,precision=70)
        b=column_cells((1,0,0),'.15',[p],[],1,precision=70)
        self.same(a,b);self.assertEqual([s for _,s in a],[True,False])
        self.assertGreater(a[1][0],D('.16'));self.assertLess(a[1][0],D('.17'))

    def test_column_remains_vertical_but_sphere_has_finite_height(self):
        p=path(reference=(0,0,5))
        self.assertFalse(sphere_cells((1,0,0),'.15',[p],1)[0][1])
        self.assertTrue(column_cells((1,0,0),'.15',[p],[],1)[0][1])

    def test_multiple_revolutions_preserve_all_open_exposure_windows(self):
        cells=column_cells((1,0,0),'.15',[path(angle=720)],[],1,precision=70)
        self.assertEqual([s for _,s in cells],[True,False,True,False,True])
        self.assertLess(abs(cells[3][0]-cells[1][0]-D('.5')),D('1e-24'))

    def test_angular_box_contact_is_not_an_enclosing_aabb_hit(self):
        p=path();panel=Cuboid('field',(1,0,0),('.3',1,1))
        cells=box_cells([panel],[p],1,precision=70)
        self.assertEqual([s for _,s in cells],[True,False])
        self.assertGreater(cells[1][0],D('.4'));self.assertLess(cells[1][0],D('.41'))
        self.assertEqual(box_cells([Cuboid('far',(4,4,0),('.1',)*3)],[p],1),[(D(0),False)])

    def test_cover_uses_the_rotating_nearest_vertical_witness(self):
        p=path(centre=(0,1,1));roof=Cuboid('roof',('.8',0,3),('.6',3,'.2'))
        cells=column_cells((0,0,0),2,[p],[roof],1,precision=70)
        self.assertEqual([s for _,s in cells],[False,True])
        self.assertGreater(cells[1][0],D('.37'));self.assertLess(cells[1][0],D('.38'))
        self.assertEqual(column_cells((0,0,0),2,[p],[],1),[(D(0),True)])

    def test_cover_at_equal_top_height_does_not_block(self):
        p=path(centre=(0,1,1));roof=Cuboid('roof',(0,0,1), (4,4,1))
        self.assertEqual(column_cells((0,0,0),2,[p],[roof],1),[(D(0),True)])

    def test_rotated_cover_and_union_order_keep_the_same_boundary(self):
        p=path(centre=(0,1,1));roof=OrientedCuboid('roof',('.8',0,3),('.6',3,'.2'),YawFrame.from_degrees(37))
        a=column_cells((0,0,0),2,[p,p],[roof],1,precision=70)
        b=column_cells((0,0,0),2,[replace(p,yaw=replace(p.yaw,precision=80))],[roof],1,precision=80)
        self.same(a,b)
        for i in range(21):
            time=F(i,20);expected=column_cells((0,0,0),2,[(p.at_time(time),(0,0,0),(0,0,0),(0,0,0))],[roof],0)[0][1]
            actual=next(s for t,s in reversed(a) if F(t)<=time)
            self.assertEqual(actual,expected)

    def test_persistent_sphere_tangent_survives_yaw_and_fixed_foot(self):
        p=path(centre=(0,0,2),size=(4,4,2),local_velocity=(0,0,1),rate=(0,0,2))
        self.assertEqual(sphere_cells((0,0,0),1,[p],1),[(D(0),True)])

    def test_isolated_quadratic_tangent_has_no_open_exposure(self):
        p=path(centre=(0,0,'.5'),size=(4,4,1),reference=(0,0,'1.25'),velocity=(0,0,-1),acceleration=(0,0,2))
        self.assertEqual(sphere_cells((0,0,0),1,[p],1),[(D(0),False)])

    def test_persistent_box_contact_preserves_the_exact_vertical_face(self):
        p=path(centre=(0,0,1),size=(1,1,2),local_velocity=(0,0,1),rate=(0,0,2))
        floor=Cuboid('floor',(0,0,'-.5'),(10,10,1))
        self.assertEqual(box_cells([floor],[p],1),[(D(0),True)])

    def test_mixed_fixed_heading_and_angular_union_does_not_duplicate_exposure(self):
        p=path();fixed=(Cuboid('other',(1,0,0),(1,1,1)),(0,0,0),(0,0,0),(0,0,0))
        self.assertEqual(sphere_cells((1,0,0),'.15',[p,fixed],1),[(D(0),True)])
        self.assertEqual(sphere_cells((1,0,0),'.15',[fixed,p],1),[(D(0),True)])

    def test_zero_rate_angular_adapter_agrees_with_original_polynomials(self):
        p=path(angle=0,centre=(0,0,0),reference=(-3,0,0),velocity=(6,0,0))
        fixed=(p.at_time(0),(6,0,0),(0,0,0),(0,0,0))
        self.same(sphere_cells((0,0,0),1,[p],1),sphere_cells((0,0,0),1,[fixed],1))

    def test_query_slice_retains_original_angle_anchor_and_boundary(self):
        p=path();sliced=replace(p,reference=p.reference.slice(100,1000),yaw=replace(p.yaw,begin_s=F('.1')))
        a=column_cells((1,0,0),'.15',[p],[],1,precision=70)
        b=column_cells((1,0,0),'.15',[sliced],[],'.9',precision=70)
        self.assertEqual(a[0][1],b[0][1]);self.assertLess(abs(a[1][0]-b[1][0]-D('.1')),D('1e-24'))

    def test_zero_duration_and_empty_material_are_explicit(self):
        p=path();self.assertEqual(sphere_cells((1,0,0),'.15',[p],0),[(D(0),True)])
        self.assertEqual(box_cells([],[p],1),[(D(0),False)])

    def test_first_boundary_forecast_matches_complete_multi_turn_partition(self):
        p=path(angle=720)
        complete=column_cells((1,0,0),'.15',[p],[],1,precision=70)
        first=column_cells((1,0,0),'.15',[p],[],1,precision=70,first_boundary_only=True)
        self.same(first,complete[:2])

    def test_invalid_query_horizon_and_exhausted_budget_raise(self):
        p=path()
        with self.assertRaises(ValueError):sphere_cells((1,0,0),1,[p],2)
        with self.assertRaises(UnsupportedMechanicError):
            angular_cells('sphere',[p],1,centre=(1,0,0),radius='.15',node_limit=1)


if __name__=='__main__':unittest.main()
