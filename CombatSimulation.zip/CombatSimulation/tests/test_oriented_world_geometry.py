"""Independent geometry checks for native oriented material consumers."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.box_motion import (axis_motions,impact_normals,touching_normals,
    footprint_overlap,closest_surface_point,on_surface)
from combat_sim.mechanics.support_geometry import static_witnesses,static_face_gaps,first_overlap_departure
from combat_sim.mechanics.gravity import ProjectileTrajectory
from combat_sim.moving_gravity_collisions import moving_curve_contact
from combat_sim.gravity_collisions import first_contact
from combat_sim.world_colliders import segment_crosses_interior
from combat_sim.volume_geometry import column_cells,box_cells,sphere_cells
from combat_sim.mechanics.climbing import surface_distance_squared,within_climb_range
from combat_sim.owned_contacts import OwnedContacts
from combat_sim.spatial_motion import CONTACT_DISTANCE_EPS_M

ZERO=(0,0,0)


def rotated(name,centre,size,angle=45):
    return OrientedCuboid(name,centre,size,YawFrame.from_degrees(F(angle)+90))


class OrientedWorldGeometryTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def test_false_enclosing_support_does_not_create_a_witness(self):
        deck=OrientedCuboid('top',(0,0,'-.5'),(4,'.2',1),YawFrame(F(3,5),F(4,5)))
        foot=Cuboid('foot',('1.6','1.2','.1'),('.1','.1','.2'))
        self.assertFalse(footprint_overlap(foot,deck,distance_epsilon='1e-20'))
        self.assertFalse(static_witnesses('A',(foot,),{'deck':(deck,)},distance_epsilon='1e-20'))

    def test_real_partial_rotated_support_is_not_full_containment(self):
        deck=rotated('top',(0,0,'-.5'),(4,'.2',1))
        foot=Cuboid('foot',('.1',0,'.1'),('.2','.2','.2'))
        self.assertEqual(len(static_witnesses('A',(foot,),{'deck':(deck,)},distance_epsilon='1e-20')),1)

    def test_support_departure_solves_actual_face_not_aabb(self):
        deck=rotated('top',(0,0,'-.5'),(4,'.2',1));foot=Cuboid('foot',(0,0,1),('.2','.2',2))
        gaps=static_face_gaps(foot,deck,(2,0,0),ZERO,distance_epsilon=F(1,10**20))
        loss=first_overlap_departure(gaps,1,distance_epsilon=F(1,10**20))
        t=D(loss.numerator)/D(loss.denominator);expected=(D('.1')*D(2).sqrt()+D('.2'))/2
        self.assertLess(abs(t-expected),D('1e-19'))
        for delta,supported in ((-F(1,10**8),True),(F(1,10**8),False)):
            moved=Cuboid('foot',(2*(loss+delta),0,1),foot.size_m)
            self.assertEqual(footprint_overlap(moved,deck),supported)

    def test_thin_self_width_cannot_supply_subresolution_support(self):
        deck=rotated('top',ZERO,(4,'1e-25',1));foot=Cuboid('foot',(0,0,1),(1,1,1))
        self.assertFalse(footprint_overlap(foot,deck,distance_epsilon='1e-20'))

    def test_actual_face_normals_and_one_sided_contact_are_consistent(self):
        wall=rotated('wall',ZERO,('.2',4,3));n=wall.frame.right
        radius=F('.1')*(abs(n[0])+abs(n[1]))
        centre=tuple(-(F('.1')+radius)*v for v in n)
        body=Cuboid('body',centre,('.2',)*3)
        rows=axis_motions(body,wall,n,ZERO)
        normals=impact_normals(rows,distance_epsilon='1e-20',speed_epsilon='1e-24',acceleration_epsilon='1e-24')
        self.assertEqual(normals,(tuple(-v for v in n),))
        self.assertEqual(touching_normals(body,wall,distance_epsilon='1e-20'),normals)
        separating=axis_motions(body,wall,tuple(-v for v in n),ZERO)
        self.assertFalse(impact_normals(separating,distance_epsilon='1e-20',speed_epsilon='1e-24',acceleration_epsilon='1e-24'))

    def test_stationary_tangent_does_not_become_a_new_impact(self):
        wall=rotated('wall',ZERO,('.2',4,3));n=wall.frame.right
        radius=F('.1')*(abs(n[0])+abs(n[1]));body=Cuboid('body',tuple(-(F('.1')+radius)*v for v in n),('.2',)*3)
        rows=axis_motions(body,wall,wall.frame.forward,ZERO)
        self.assertFalse(impact_normals(rows,distance_epsilon='1e-20',speed_epsilon='1e-24',acceleration_epsilon='1e-24'))

    def test_owned_volume_touching_retains_the_metric_contact_band(self):
        wall=rotated('wall',ZERO,('.2',4,3));n=wall.frame.right
        radius=F('.1')*(abs(n[0])+abs(n[1]));eps=F(CONTACT_DISTANCE_EPS_M)
        for gap,expected in ((F(0),True),(eps/2,True),(2*eps,False)):
            with self.subTest(gap=gap):
                body=Cuboid('owned',tuple(-(F('.1')+radius+gap)*v for v in n),('.2',)*3)
                self.assertEqual(OwnedContacts.touching(body,wall),expected)

    def test_cover_ray_uses_actual_material_and_keeps_tangency_free(self):
        wall=rotated('roof',(0,0,'2.5'),(8,'.2',1))
        self.assertFalse(segment_crosses_interior(('2.5','-2.5',10),('2.5','-2.5',0),wall))
        self.assertTrue(segment_crosses_interior((1,1,10),(1,1,0),wall))
        edge=wall.frame.to_world_point((0,F('.1'),0),wall.centre_m)
        self.assertFalse(segment_crosses_interior((*edge[:2],10),(*edge[:2],0),wall))

    def test_anchor_projection_retains_an_exact_physical_face(self):
        wall=rotated('wall',(7,-20,2),('.2',4,3))
        for point in (wall.centre_m,(10,-15,3),(7,-20,2)):
            p=closest_surface_point(wall,point)
            self.assertTrue(on_surface(wall,p));self.assertTrue(wall.contains(p))

    def test_gravity_contact_rejects_false_aabb_corner(self):
        box=OrientedCuboid('thin',ZERO,(4,'.2',2),YawFrame(F(3,5),F(4,5)))
        flight=ProjectileTrajectory(['1.6','1.2',-3],[0,0,6],1,gravity_mps2=0)
        self.assertIsNone(moving_curve_contact(flight,box,'.01',0,1,confirm_near_entry=True))
        self.assertIsNone(first_contact(flight,(box,),'.01',confirm_near_entry=True))

    def test_gravity_contact_preserves_world_flight_and_arc_distance(self):
        wall=rotated('wall',(15,0,10),('.2',20,20));flight=ProjectileTrajectory([0,0,10],[100,0,0],'.3',deceleration_mps2=20)
        original=flight.states;hit=moving_curve_contact(flight,wall,'.02',0,'.3',confirm_near_entry=True)
        self.assertIsNotNone(hit);state=flight.at(hit.time_upper_s)
        self.assertEqual(hit.centre_m,state.position_m);self.assertEqual(hit.distance_upper_m,state.distance_m)
        self.assertIs(flight.states,original)
        local=wall.frame.to_local_point(hit.surface_point_m,wall.centre_m)
        self.assertLess(abs(abs(float(local[0]))-.1),1e-10)

    def test_static_curve_api_uses_the_same_actual_oriented_solid(self):
        wall=rotated('wall',(15,0,10),('.2',20,20));flight=ProjectileTrajectory([0,0,10],[100,0,0],'.3')
        a=first_contact(flight,(wall,),'.02',time_tolerance_s=1e-12,clearance_tolerance_m=1e-14,confirm_near_entry=True)
        b=moving_curve_contact(flight,wall,'.02',0,'.3',confirm_near_entry=True)
        self.assertLess(abs(a.time_upper_s-b.time_upper_s),1e-12)

    def test_gravity_interval_split_retains_first_oriented_contact(self):
        wall=rotated('wall',(15,0,10),('.2',20,20));flight=ProjectileTrajectory([0,0,10],[100,0,0],'.3',deceleration_mps2=20)
        a=moving_curve_contact(flight,wall,'.02',0,'.3',confirm_near_entry=True)
        self.assertIsNone(moving_curve_contact(flight,wall,'.02',0,'.07',confirm_near_entry=True))
        b=moving_curve_contact(flight,wall,'.02','.07','.3',confirm_near_entry=True)
        self.assertLess(abs(a.time_upper_s-b.time_upper_s),1e-12)
        self.assertLess(abs(a.distance_upper_m-b.distance_upper_m),1e-9)

    def test_rotated_shadow_entry_and_exit_are_polynomial_boundaries(self):
        body=Cuboid('body',(0,0,'.5'),('.2',)*3);roof=rotated('roof',(1,0,'2.5'),(4,'.2',1))
        cells=column_cells((0,0,10),100,[(body,(2,0,0),ZERO,ZERO)],(roof,),1)
        self.assertEqual([s for _,s in cells],[True,False,True])
        a=(D('1.1')-D('.1')*D(2).sqrt())/2;b=(D('1.1')+D('.1')*D(2).sqrt())/2
        self.assertLess(abs(cells[1][0]-a),D('1e-37'));self.assertLess(abs(cells[2][0]-b),D('1e-37'))

    def test_rotated_field_union_uses_actual_contact_cells(self):
        body=Cuboid('body',(0,0,'.5'),('.2',)*3);field=rotated('field',(1,0,'.5'),(4,'.2',1))
        cells=box_cells((field,field),[(body,(2,0,0),ZERO,ZERO)],1)
        self.assertEqual([s for _,s in cells],[False,True,False])
        half=D('.1')*D(2).sqrt()+D('.2')
        self.assertLess(abs(cells[1][0]-(1-half)/2),D('1e-37'))
        self.assertLess(abs(cells[2][0]-(1+half)/2),D('1e-37'))

    def test_oriented_sphere_cells_are_covariant_under_fixed_frame(self):
        frame=YawFrame(F(3,5),F(4,5));local=Cuboid('local',(-3,0,0),(1,1,1))
        world=OrientedCuboid('world',frame.to_world_point(local.centre_m),local.size_m,frame)
        a=sphere_cells(ZERO,1,[(local,(6,0,0),ZERO,ZERO)],1)
        b=sphere_cells(ZERO,1,[(world,frame.to_world_vector((6,0,0)),ZERO,ZERO)],1)
        self.assertEqual(a,b)

    def test_climb_range_uses_actual_surface_beyond_the_enclosing_corner(self):
        cube=rotated('cube',(0,0,'.9'),('1.8',)*3)
        self.assertGreater(surface_distance_squared(('1.25','1.25','.875'),cube),F(1,4))
        self.assertFalse(within_climb_range(('1.25','1.25','.875'),cube,'.5'))

