"""Static faces share positive-area witnesses and quadratic departure cells."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.support_geometry import static_witnesses,static_face_gaps,first_overlap_departure

EPS=F(1,10**20)


class StaticSupportGeometryTests(unittest.TestCase):
    def setUp(self):
        self.body=Cuboid('foot',(0,0,1),('.2','.2',2))
        self.deck=Cuboid('top',(0,0,'-.5'),(2,2,1))

    def loss(self,body=None,velocity=(0,0,0),acceleration=(0,0,0),size_rate=(0,0,0),duration=2):
        gaps=static_face_gaps(body or self.body,self.deck,velocity,acceleration,size_rate=size_rate,distance_epsilon=EPS)
        return first_overlap_departure(gaps,duration,distance_epsilon=EPS)

    def assert_root_encloses(self,root,expected):
        self.assertGreaterEqual(root,expected)
        self.assertLess(root-expected,F(1,10**30))

    def test_partial_overhang_is_supported_until_actual_overlap_loss(self):
        body=Cuboid('foot',('1.05',0,1),('.2','.2',2))
        self.assertEqual(len(static_witnesses('A',(body,),{'deck':(self.deck,)},distance_epsilon=EPS)),1)
        self.assert_root_encloses(self.loss(body,velocity=(2,0,0)),(F('.05')-EPS)/2)

    def test_zero_area_and_subresolution_overlap_are_not_support(self):
        for x in (F('1.1'),F('1.1')-EPS/2):
            body=Cuboid('foot',(x,0,1),('.2','.2',2))
            self.assertFalse(static_witnesses('A',(body,),{'deck':(self.deck,)},distance_epsilon=EPS))

    def test_any_actual_underside_can_support_even_with_lower_parts_beside_it(self):
        side=Cuboid('lower',(2,0,0),('.2','.2',1))
        rows=static_witnesses('A',(side,self.body),{'deck':(self.deck,)},distance_epsilon=EPS)
        self.assertEqual([(r.upper_part,r.lower) for r in rows],[('foot','deck')])

    def test_alternate_witnesses_have_canonical_order(self):
        rows=static_witnesses('A',(self.body,),{'z':(self.deck,),'a':(self.deck,)},distance_epsilon=EPS)
        self.assertEqual([r.lower for r in rows],['a','z'])

    def test_linear_departure_uses_current_contact_band(self):
        self.assert_root_encloses(self.loss(velocity=(2,0,0)),(F('1.1')-EPS)/2)

    def test_accelerated_path_finds_first_exit_before_a_return(self):
        loss=self.loss(velocity=(4,0,0),acceleration=(-8,0,0),duration=1)
        self.assertIsNone(loss)  # Maximum displacement is 1 m; the foot still overlaps.
        loss=self.loss(velocity=(6,0,0),acceleration=(-12,0,0),duration=1)
        self.assertIsNotNone(loss)
        with localcontext(Context(prec=80)):
            t=D(loss.numerator)/D(loss.denominator)
            self.assertLess(abs(6*t-6*t*t-D('1.1')+D('1e-20')),D('1e-25'))
            self.assertLess(t,D('.5'))

    def test_size_change_can_withdraw_a_support_face_without_translation(self):
        body=Cuboid('foot',('1.1',0,1),('.4','.2',2))
        self.assert_root_encloses(self.loss(body,size_rate=(-4,0,0)),(F('.1')-EPS)/2)

    def test_vertical_withdrawal_leaves_the_same_contact_band(self):
        self.assert_root_encloses(self.loss(velocity=(0,0,1)),EPS)


if __name__=='__main__':unittest.main()
