"""Crouch geometry changes shape around anchored feet and re-centres origins."""
from decimal import Decimal as D
from fractions import Fraction as F
import json
from pathlib import Path
import unittest

from combat_sim.hitboxes import combined_bounds, local_to_world_point, world_standing_cuboids
from combat_sim.postures import body_origin_from_bounds, world_posture_cuboids, pose_local_hand_position

ROOT=Path(__file__).resolve().parents[1]
BODY=json.loads((ROOT/'data/body_hitboxes.json').read_text())

class PostureGeometryTests(unittest.TestCase):
    def boxes(self,fraction):return world_posture_cuboids(BODY,[0,0,F(7,8)],'+x',fraction,F(2,5))

    def test_feet_are_fixed_through_crouch(self):
        for q in (0,F(1,4),F(1,2),F(3,4),1):
            boxes=self.boxes(q);low,high=combined_bounds(boxes)
            self.assertEqual(low[2],0)
            self.assertEqual(high[2],F(7,4)-F(2,5)*q)
            for b in boxes:
                if b.part.endswith('leg'):self.assertEqual(b.bounds[0][2],0)

    def test_standing_pose_is_unchanged(self):
        self.assertEqual(self.boxes(0),world_standing_cuboids(BODY,[0,0,F(7,8)],'+x'))

    def test_crouched_height_and_leg_size(self):
        low,high=combined_bounds(self.boxes(1))
        self.assertEqual(high[2]-low[2],F(27,20))
        for b in self.boxes(1):
            if b.part.endswith('leg'):self.assertEqual(b.size_m[2],F(2,5))

    def test_upper_parts_keep_size_and_lower_together(self):
        standing={b.part:b for b in self.boxes(0)}
        for b in self.boxes(1):
            if b.part.endswith('leg'):continue
            self.assertEqual(b.size_m,standing[b.part].size_m)
            self.assertEqual(b.centre_m[2],standing[b.part].centre_m[2]-F(2,5))

    def test_body_centre_tracks_new_bounds(self):
        self.assertEqual(body_origin_from_bounds(self.boxes(0)),(0,0,F(7,8)))
        self.assertEqual(body_origin_from_bounds(self.boxes(F(1,2))),(0,0,F(31,40)))
        self.assertEqual(body_origin_from_bounds(self.boxes(1)),(0,0,F(27,40)))

    def test_horizontal_dimensions_remain_constant(self):
        for q in (0,F(1,2),1):
            low,high=combined_bounds(self.boxes(q))
            self.assertEqual(tuple(b-a for a,b in zip(low[:2],high[:2])),(F(3,10),F(7,10)))

    def test_hand_and_projectile_pose_follow_upper_body(self):
        for hand in ([.2,.15,-.1],[.1,.4,.18],[0,.3,.15]):
            before=local_to_world_point(hand,[0,0,F(7,8)],'+x')
            local=pose_local_hand_position(hand,F(2,5))
            after=local_to_world_point(local,[0,0,F(27,40)],'+x')
            self.assertEqual(after[:2],before[:2])
            self.assertEqual(after[2],before[2]-F(2,5))

    def test_pose_stays_anchored_on_raised_support(self):
        boxes=world_posture_cuboids(BODY,[6,0,F(107,40)],'-x',1,F(2,5))
        self.assertEqual(combined_bounds(boxes)[0][2],F(9,5))
        self.assertEqual(body_origin_from_bounds(boxes)[2],F(99,40))

    def test_invalid_crouch_geometry_is_rejected(self):
        for fraction,target in ((-1,.4),(2,.4),(1,0),(1,1)):
            with self.assertRaises(ValueError):world_posture_cuboids(BODY,[0,0,F(7,8)],'+x',fraction,target)
