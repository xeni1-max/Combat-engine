from decimal import Context, Decimal as D, localcontext
from fractions import Fraction
import unittest

from combat_sim.mechanics.binding import escape_work


class BindingThresholdTests(unittest.TestCase):
    def test_source_mathml_is_twenty_times_b_minus_hp_over_five_hundred(self):
        with localcontext(Context(prec=70)):
            expected = (D(80)-D(8140)/500)**D('.9')
        self.assertLess(abs(escape_work(4,8140)-expected),D('1e-37'))

    def test_floor_keeps_the_fractional_power_real_and_nonnegative(self):
        self.assertEqual(escape_work(0,8140),0)
        self.assertEqual(escape_work(1,10000),0)
        self.assertEqual(escape_work(1,10001),0)

    def test_stronger_bindings_require_more_and_larger_bodies_require_less(self):
        self.assertGreater(escape_work(6,8140),escape_work(4,8140))
        self.assertLess(escape_work(4,15000),escape_work(4,8140))

    def test_rational_inputs_and_owned_precision_ignore_the_callers_context(self):
        with localcontext(Context(prec=7)):
            a=escape_work(Fraction(13,3),Fraction(25001,3))
        with localcontext(Context(prec=80)):
            b=escape_work(Fraction(13,3),Fraction(25001,3))
        self.assertEqual(a,b)

    def test_invalid_values_are_rejected(self):
        for b,h in ((-1,8140),(True,8140),(4,0),(4,-1),(4,False),('NaN',8000),('Infinity',8000)):
            with self.subTest(b=b,h=h),self.assertRaises(ValueError):escape_work(b,h)
        for precision in (10,True,39):
            with self.assertRaises(ValueError):escape_work(4,8140,precision=precision)
