"""Author-defined takeoff speed, inherited horizontal movement and gravity."""
from fractions import Fraction as F
import json
from pathlib import Path
import unittest

from combat_sim.mechanics.jumping import JumpFlight, jump_initial_speed_mps, basic_jump_takeoff_time_ms
from combat_sim.mechanics.gravity import ProjectileTrajectory

ROOT=Path(__file__).resolve().parents[1]
PROFILES=json.loads((ROOT/'data/movement/jump.json').read_text())['characters']
MOVEMENT=json.loads((ROOT/'data/movement/walk_run.json').read_text())['characters']


class JumpTests(unittest.TestCase):
    def test_both_characters_take_off_at_half_base_run_speed(self):
        for name in PROFILES:
            self.assertEqual(jump_initial_speed_mps(MOVEMENT[name]['running_speed_mps']),F(16,5))

    def test_jump_speed_scales_with_base_run_speed(self):
        self.assertEqual(jump_initial_speed_mps(8),4)

    def test_takeoff_retains_horizontal_walking_or_running_velocity(self):
        for horizontal in ((0,0),(2,0),(F(32,5),0),(0,-2),(F(6,5),F(8,5))):
            flight=JumpFlight([1,2,F(7,8)],horizontal,'6.4')
            self.assertEqual(flight.at(0).velocity_mps,(*horizontal,F(16,5)))
            state=flight.at(F(1,5))
            self.assertEqual(state.velocity_mps[:2],horizontal)
            self.assertEqual(state.position_m[:2],tuple(o+F(v)/5 for o,v in zip((1,2),horizontal)))

    def test_apex_time_height_and_zero_vertical_velocity_are_exact(self):
        flight=JumpFlight([0,0,0],[0,0],'6.4')
        self.assertEqual(flight.apex_time_s,F(320,981))
        self.assertEqual(flight.apex_rise_m,F(512,981))
        state=flight.at(flight.apex_time_s)
        self.assertEqual(state.position_m[2],flight.apex_rise_m)
        self.assertEqual(state.velocity_mps[2],0)

    def test_return_to_same_height_has_opposite_vertical_speed(self):
        flight=JumpFlight([3,4,F(7,8)],[2,0],'6.4')
        self.assertEqual(flight.same_height_return_time_s,F(640,981))
        state=flight.at(flight.same_height_return_time_s)
        self.assertEqual(state.position_m[2],F(7,8))
        self.assertEqual(state.velocity_mps[2],-F(16,5))
        self.assertEqual(state.position_m[0]-3,2*F(640,981))

    def test_vertical_energy_is_conserved(self):
        flight=JumpFlight([0,0,0],[2,0],'6.4')
        for t in (0,F(1,10),flight.apex_time_s,flight.same_height_return_time_s):
            state=flight.at(t)
            energy=state.velocity_mps[2]**2/2+flight.gravity_mps2*state.position_m[2]
            self.assertEqual(energy,flight.initial_upward_speed_mps**2/2)

    def test_matches_independent_existing_ballistic_evaluator(self):
        flight=JumpFlight([1,2,3],[2,-1],'6.4')
        reference=ProjectileTrajectory([1,2,3],[2,-1,3.2],float(flight.same_height_return_time_s))
        for t in (F(1,10),flight.apex_time_s,flight.same_height_return_time_s):
            actual=flight.at(t);other=reference.at(float(t))
            for a,b in zip((*actual.position_m,*actual.velocity_mps),(*other.position_m,*other.velocity_mps)):
                self.assertAlmostEqual(float(a),b,places=12)

    def test_basic_jump_takes_off_at_active_start(self):
        for profile in PROFILES.values():
            time,calculation=basic_jump_takeoff_time_ms(0,profile)
            self.assertEqual(time,100)
            self.assertEqual(calculation['active_end_ms'],250)
            self.assertEqual(calculation['active_start_ms'],time)

    def test_existing_running_and_disorientation_rules_modify_gathering(self):
        for profile in PROFILES.values():
            time,_=basic_jump_takeoff_time_ms(17,profile,is_running_at_gathering_start=True,
                                             disorientation_at_gathering_start=F(1,3))
            self.assertEqual(time,138)

    def test_active_end_does_not_end_flight(self):
        flight=JumpFlight([0,0,0],[0,0],'6.4')
        self.assertGreater(flight.at(F(150,1000)).position_m[2],0)
        self.assertGreater(flight.same_height_return_time_s,F(150,1000))

    def test_invalid_inputs_and_queries_fail(self):
        for speed in (0,-1):
            with self.assertRaises(ValueError):JumpFlight([0,0,0],[0,0],speed)
        with self.assertRaises(ValueError):JumpFlight([0,0,0],[0,0],6,gravity_mps2=0)
        flight=JumpFlight([0,0,0],[0,0],'6.4')
        for t in (-1,1):
            with self.assertRaises(ValueError):flight.at(t)
