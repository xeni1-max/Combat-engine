import unittest
from fractions import Fraction

from combat_sim.mechanics.venom import venom_delivery_ratio, venomous_damage_rate, venomous_full_phase_damage
from combat_sim.mechanics.shield import split_damage
from combat_sim.mechanics.slash import calculate_impact


class VenomousFormulaTests(unittest.TestCase):
    def test_delivery_is_slash_post_armor_over_post_shield_pre_armor_damage(self):
        for damage, armor, piercing, expected in (
            (440, 150, 40, Fraction(15, 16)),
            (340, 150, 40, Fraction(1035, 1156)),
            (100, 200, 0, Fraction(0)),
            (100, 0, 0, Fraction(1)),
            (100, 10, 30, Fraction(1)),
        ):
            with self.subTest(damage=damage, armor=armor, piercing=piercing):
                self.assertEqual(venom_delivery_ratio(damage, armor, piercing), expected)

    def test_fully_shielded_thrust_has_no_toxin_rate_or_integrated_damage(self):
        for shield in (440, 500, 4000):
            with self.subTest(shield=shield):
                impact = calculate_impact(440, 150, 40, shield)
                self.assertEqual(impact.damage_left_after_shield, 0)
                self.assertEqual(venom_delivery_ratio(impact.damage_left_after_shield, 150, 40), 0)
                self.assertEqual(venomous_damage_rate(impact.damage_left_after_shield, 150, 40, 700, 40, 1, 0).as_fraction(), 0)
                self.assertEqual(venomous_full_phase_damage(impact.damage_left_after_shield, 150, 40, 700, 40, 1).as_fraction(), 0)

    def test_delivery_rejects_negative_inputs_even_when_damage_is_zero(self):
        for values in ((-1, 0, 0), (0, -1, 0), (0, 0, -1)):
            with self.subTest(values=values), self.assertRaisesRegex(ValueError, "nonnegative"):
                venom_delivery_ratio(*values)

    def test_continuous_full_exposure_and_recovery_have_equal_integrals(self):
        # C=17991/28; ∫_0^1 C sqrt(t) dt = 5997/14.
        phase = venomous_full_phase_damage(440, 150, 40, 700, 40, 1)
        self.assertEqual(phase.as_fraction(), Fraction(5997, 14))

    def test_short_phase_integral_and_exact_irrational_representation(self):
        self.assertEqual(venomous_full_phase_damage(440, 150, 40, 700, 40, Fraction(1, 4)).as_fraction(), Fraction(5997, 112))
        phase = venomous_full_phase_damage(10, 0, 0, 10, 0, 2)
        self.assertEqual(phase.coefficient, Fraction(40, 3))
        self.assertEqual(phase.radicand, 2)
        self.assertIsNone(phase.as_fraction())

    def test_phase_zero_duration_and_invalid_duration(self):
        self.assertEqual(venomous_full_phase_damage(10, 0, 0, 10, 0, 0).as_fraction(), 0)
        with self.assertRaisesRegex(ValueError, "nonnegative"):
            venomous_full_phase_damage(10, 0, 0, 10, 0, -1)

    def test_venom_d_is_slash_overflow_before_armor_mitigation(self):
        absorbed, damage = split_damage(440, 100)
        self.assertEqual(absorbed, 100)
        self.assertEqual(damage, 340)
        # Delivery uses 340, not 440 or slash's post-armor HP damage.
        self.assertEqual(venomous_damage_rate(damage, 150, 40, 700, 40, 1, 0).as_fraction(), Fraction(1241379, 2023))

    def test_2e4_explicit_pre_hit_snapshot_rate_example(self):
        # Pure formula fixture, not a chosen runtime armor/exposure policy:
        # d=440,a=150,p=40,Tp=700,RT=40 => delivery 15/16;
        # toxin factor 23988/35; at tT=1,to=0 the rate is 17991/28 DPS.
        self.assertEqual(venomous_damage_rate(440, 150, 40, 700, 40, 1, 0).as_fraction(), Fraction(17991, 28))
        self.assertEqual(venomous_damage_rate(440, 150, 40, 700, 40, Fraction(1, 4), 0).as_fraction(), Fraction(17991, 56))

    def test_formula_with_integer_square_root(self):
        # ((100 - (6-2)^2)/100) * ((100 - 10*(2-2/5)^2)/10) * sqrt(13-9)
        result = venomous_damage_rate(10, 6, 2, 10, 2, 13, 9)
        self.assertEqual(result.as_fraction(), Fraction(7812, 625))

    def test_piercing_offsets_toxin_resistance_by_one_fifth(self):
        # RT - p/5 = 0, leaving a 10 damage-rate factor and sqrt(4)=2.
        result = venomous_damage_rate(10, 10, 10, 10, 2, 13, 9)
        self.assertEqual(result.as_fraction(), Fraction(20))

    def test_adjusted_armor_and_resistance_stop_at_zero_before_squared(self):
        result = venomous_damage_rate(10, 0, 20, 100, 1, 1, 0)
        self.assertEqual(result.as_fraction(), 100)

    def test_piercing_beyond_armor_preserves_remaining_resistance(self):
        result = venomous_damage_rate(100, 10, 30, 100, 10, 1, 0)
        self.assertEqual(result.as_fraction(), Fraction(492, 5))

    def test_more_piercing_after_resistance_reaches_zero_does_not_restore_it(self):
        first = venomous_damage_rate(100, 0, 50, 100, 10, 1, 0)
        second = venomous_damage_rate(100, 0, 100, 100, 10, 1, 0)
        self.assertEqual(first.as_fraction(), 100)
        self.assertEqual(second.as_fraction(), 100)

    def test_irrational_result_is_preserved_exactly(self):
        result = venomous_damage_rate(10, 0, 0, 10, 0, 3, 1)
        self.assertEqual(result.coefficient, Fraction(10))
        self.assertEqual(result.radicand, Fraction(2))
        self.assertIsNone(result.as_fraction())

    def test_negative_damage_rate_is_clamped_to_zero(self):
        result = venomous_damage_rate(10, 0, 0, 2, 1, 3, 2)
        self.assertEqual(result.coefficient, Fraction(0))
        self.assertEqual(result.radicand, Fraction(0))

    def test_two_negative_factors_do_not_create_positive_damage(self):
        # Delivery -3 and toxin -90 each floor to 0, instead of yielding 270.
        result = venomous_damage_rate(100, 200, 0, 10, 10, 1, 0)
        self.assertEqual(result.as_fraction(), 0)

    def test_negative_delivery_factor_stops_otherwise_positive_toxin_damage(self):
        # Delivery -3 floors to 0; the toxin factor would be +10.
        result = venomous_damage_rate(100, 200, 0, 10, 0, 1, 0)
        self.assertEqual(result.as_fraction(), 0)

    def test_delivery_factor_at_zero_stops_damage(self):
        result = venomous_damage_rate(100, 100, 0, 10, 0, 1, 0)
        self.assertEqual(result.as_fraction(), 0)

    def test_zero_exposure_interval_returns_zero(self):
        result = venomous_damage_rate(10, 0, 0, 10, 0, 5, 5)
        self.assertEqual(result.as_fraction(), Fraction(0))

    def test_zero_toxicity_denominator_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Tp=0"):
            venomous_damage_rate(10, 0, 0, 0, 0, 1, 0)

    def test_negative_square_root_argument_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "tT >= to"):
            venomous_damage_rate(10, 0, 0, 10, 0, 1, 2)


if __name__ == "__main__":
    unittest.main()
