"""Single grenade with explicit nonlethal exposure/exit windows; no inferred locomotion."""
from copy import deepcopy
from decimal import Decimal,localcontext,ROUND_CEILING,ROUND_FLOOR
from fractions import Fraction
import json
from pathlib import Path
import unittest
from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario
from combat_sim.exact import ExactAmount,ExactRootProduct,amount_from_record
from combat_sim.models import UnsupportedMechanicError
from combat_sim.poison_grenade_engine import _nonlethal

ROOT=Path(__file__).resolve().parents[1]
CHARACTERS=json.loads((ROOT/'data/characters.json').read_text())['characters']
BASE=json.loads((ROOT/'scenarios/1e1_ultimate_poison_grenade.json').read_text())


def events(run,kind): return [e for e in run['events'] if e['type']==kind]


class PoisonGrenadeTests(unittest.TestCase):
    def test_exact_damage_final_hp_and_unchanged_shield_armor(self):
        r=summarize(run_scenario(BASE,CHARACTERS)); expected=ExactAmount.of(ExactRootProduct(Fraction(142064,45),2))
        self.assertEqual(amount_from_record(r['hp_damage']),expected)
        self.assertEqual(amount_from_record(r['final_hp']),9080-expected)
        self.assertEqual(r['final_shield']['exact'],'4000')
        self.assertEqual(r['final_armor']['exact'],'165')
        self.assertEqual(r['armor_lost']['exact'],'0')
        self.assertEqual(r['shield_damage']['exact'],'0')
        self.assertEqual(set(r['damage_by_effect']),{'poison'})
        self.assertEqual(r['impact_count'],0)

    def test_equip_firing_flight_cooldown_cloud_and_effect_times(self):
        run=run_scenario(BASE,CHARACTERS)
        times={'ultimate_started':0,'weapon_swap_completed':300,'grenade_gathering_started':300,
               'grenade_active_started':440,'self_effect_triggered':530,'projectile_released':620,
               'grenade_detonated':1620,'weapon_cooldown_completed':1770,'poison_exposure_ended':3620,
               'poison_expired':5620,'cloud_expired':9620}
        for kind,time in times.items(): self.assertEqual([e['time_ms'] for e in events(run,kind)],[time])
        self.assertEqual(run['run_until_ms'],9620)
        self.assertEqual(run['final_weapon_state']['ammo'],9)
        self.assertEqual(run['active_continuous_effects_final'],[])

    def test_continuous_intervals_split_at_cooldown_and_exposure_boundary(self):
        run=run_scenario(BASE,CHARACTERS); intervals=events(run,'continuous_damage_resolved')
        self.assertEqual([(e['interval_start_ms'],e['interval_end_ms']) for e in intervals],[(1620,1770),(1770,3620),(3620,5620)])
        growing=sum((amount_from_record(e['applied_hp_damage']) for e in intervals[:2]),ExactAmount())
        residual=amount_from_record(intervals[-1]['applied_hp_damage'])
        self.assertEqual(growing,residual)
        self.assertTrue(all('not a damage tick' in e['damage_payment'] for e in intervals))
        self.assertEqual(intervals[-1]['components']['poison']['inputs']['tT_end_seconds'],'2')
        self.assertEqual(intervals[-1]['components']['poison']['inputs']['to_end_seconds'],'2')

    def test_poison_hp_damage_is_independent_of_shield_amount(self):
        expected=summarize(run_scenario(BASE,CHARACTERS))['hp_damage']
        for shield in (0,50,4000):
            s=deepcopy(BASE); s['encounter']['initial_states']['2E4']['shield']=shield
            r=run_scenario(s,CHARACTERS)
            self.assertEqual(summarize(r)['hp_damage'],expected)
            self.assertEqual(r['final_states']['2E4']['shield']['exact'],str(shield))
            self.assertEqual(r['pending_shield_regeneration'],[])

    def test_armor_affects_incoming_status_but_not_poison(self):
        s=deepcopy(BASE); s['encounter']['initial_states']['2E4']['armor']=1000
        run=run_scenario(s,CHARACTERS)
        self.assertEqual(summarize(run)['hp_damage'],summarize(run_scenario(BASE,CHARACTERS))['hp_damage'])
        self.assertEqual(summarize(run)['final_armor']['exact'],'1000')
        self.assertTrue(all(e['inputs']['a']=='1000' for e in events(run,'status_applied') if e['origin']=='grenade_area'))

    def test_self_effects_at_midpoint_bypass_resistance_and_do_not_delay_active(self):
        c=deepcopy(CHARACTERS); c['1E1']['status_resistance']=100000
        run=run_scenario(BASE,c)
        effects=[e for e in events(run,'status_applied') if e['origin']=='self']
        self.assertTrue(all(e['time_ms']==530 and Decimal(e['applied_increment']['decimal'])==140 and not e['mitigation_applied'] for e in effects))
        release=events(run,'projectile_released')[0]
        self.assertEqual(release['time_ms'],620)
        self.assertEqual(Decimal(release['actor_state']['disorientation']['decimal']),50)

    def test_multi_target_area_effects_once_and_individual_exposure_windows(self):
        s=deepcopy(BASE); s['encounter']['initial_states']['3E5']={'hp':11400,'armor':250,'shield':4000}
        action=s['action_sequence'][0]; action['area_targets'].append('3E5'); action['exposure_durations_ms']['3E5']=1000
        run=run_scenario(s,CHARACTERS); r=summarize(run)
        effects=[e for e in events(run,'status_applied') if e['origin']=='grenade_area']
        self.assertEqual(len(effects),4)
        self.assertTrue(all(e['time_ms']==1620 for e in effects))
        self.assertEqual(r['targets'],['2E4','3E5'])
        self.assertEqual(r['per_target']['3E5']['hp_damage']['exact'],'7758/5')
        self.assertEqual(events(run,'poison_expired')[0]['time_ms'],3620)
        self.assertEqual(amount_from_record(r['hp_damage']),sum((amount_from_record(t['hp_damage']) for t in r['per_target'].values()),ExactAmount()))

    def test_explicit_caster_recipient_executes_friendly_fire(self):
        s=deepcopy(BASE); a=s['action_sequence'][0]; a['area_targets'].append('1E1'); a['exposure_durations_ms']['1E1']=1000
        run=run_scenario(s,CHARACTERS); r=summarize(run)
        self.assertEqual(r['per_target']['1E1']['hp_damage']['exact'],'14240/9')
        self.assertEqual(r['per_target']['1E1']['final_shield']['exact'],'4000')
        caster_area=[e for e in events(run,'status_applied') if e['target']=='1E1' and e['origin']=='grenade_area']
        self.assertEqual(len(caster_area),2)
        self.assertTrue(all(e['mitigation_applied'] for e in caster_area))

    def test_zero_exposure_still_gets_area_status_but_no_poison_damage(self):
        s=deepcopy(BASE); s['action_sequence'][0]['exposure_durations_ms']['2E4']=0
        run=run_scenario(s,CHARACTERS); r=summarize(run)
        self.assertEqual(r['hp_damage']['exact'],'0')
        self.assertEqual(r['target'],'2E4')
        self.assertEqual(r['final_hp']['exact'],'9080')
        self.assertEqual(r['damage_by_effect']['poison']['exact'],'0')
        self.assertEqual(len([e for e in events(run,'status_applied') if e['origin']=='grenade_area']),2)
        self.assertEqual(events(run,'continuous_damage_resolved'),[])

    def test_empty_area_is_valid(self):
        s=deepcopy(BASE); s['encounter']['initial_states'].pop('2E4')
        s['action_sequence'][0].update(area_targets=[],exposure_durations_ms={})
        r=summarize(run_scenario(s,CHARACTERS))
        self.assertEqual(r['hp_damage']['exact'],'0')
        self.assertEqual(r['targets'],[])

    def test_three_second_canonical_exposure_and_full_cloud_rejection(self):
        s=deepcopy(BASE); s['action_sequence'][0]['exposure_durations_ms']['2E4']=3000
        run=run_scenario(s,CHARACTERS)
        self.assertEqual(events(run,'poison_expired')[0]['time_ms'],7620)
        self.assertEqual(run['run_until_ms'],9620)
        self.assertEqual(amount_from_record(summarize(run)['hp_damage']),ExactAmount.of(ExactRootProduct(Fraction(71032,15),3)))
        s['action_sequence'][0]['exposure_durations_ms']['2E4']=8000
        with self.assertRaisesRegex(UnsupportedMechanicError,'nonlethal'): run_scenario(s,CHARACTERS)

    def test_full_cloud_and_long_residual_lifecycle_with_synthetic_mitigation(self):
        c=deepcopy(CHARACTERS); c['2E4']['resistances']['toxin']=400 # Synthetic complete mitigation; canonical resistance remains 44.
        s=deepcopy(BASE); s['action_sequence'][0]['exposure_durations_ms']['2E4']=8000
        run=run_scenario(s,c)
        self.assertEqual(events(run,'cloud_expired')[0]['time_ms'],9620)
        self.assertEqual(events(run,'poison_exposure_ended')[0]['time_ms'],9620)
        self.assertEqual(events(run,'poison_expired')[0]['time_ms'],17620)
        self.assertEqual(run['run_until_ms'],17620)
        self.assertEqual(summarize(run)['hp_damage']['exact'],'0')

    def test_delayed_activation_and_zero_distance(self):
        s=deepcopy(BASE); a=s['action_sequence'][0]; a['action_start_ms']=1000; a['target_distance_m']=0
        run=run_scenario(s,CHARACTERS)
        self.assertEqual(events(run,'projectile_released')[0]['time_ms'],1620)
        self.assertEqual(events(run,'grenade_detonated')[0]['time_ms'],1620)
        types=[e['type'] for e in run['events']]
        self.assertLess(types.index('projectile_released'),types.index('grenade_detonated'))

    def test_replay_context_and_inputs_unchanged(self):
        s,c=deepcopy(BASE),deepcopy(CHARACTERS); run=run_scenario(s,c)
        for precision,rounding in ((8,ROUND_FLOOR),(60,ROUND_CEILING)):
            with localcontext() as ctx:
                ctx.prec,ctx.rounding=precision,rounding
                self.assertEqual(run_scenario(s,c),run)
        self.assertEqual(s,BASE); self.assertEqual(c,CHARACTERS)
        times=[e['time_ms'] for e in run['events']]; self.assertEqual(times,sorted(times))

    def test_bad_exposure_geometry_truncation_and_initial_caster_status_rejected(self):
        for kind in ('long','missing','duplicate','geometry','partial','status','repeat','unconfirmed'):
            s=deepcopy(BASE); a=s['action_sequence'][0]
            if kind=='long': a['exposure_durations_ms']['2E4']=8001
            if kind=='missing': a['exposure_durations_ms']={}
            if kind=='duplicate': a['area_targets'].append('2E4')
            if kind=='geometry': s['encounter']['geometry']='automatic'
            if kind=='partial': s['run_until_ms']=5620
            if kind=='status': s['encounter']['initial_states']['1E1']['disorientation']=80
            if kind=='repeat': s['action_sequence'].append(deepcopy(a))
            if kind=='unconfirmed': a['hit_confirmed']=False
            with self.subTest(kind=kind),self.assertRaises((ValueError,UnsupportedMechanicError)): run_scenario(s,CHARACTERS)

    def test_missing_resistance_and_unconfirmed_modes_rejected(self):
        c=deepcopy(CHARACTERS); c['2E4']['resistances'].pop('toxin')
        with self.assertRaisesRegex(UnsupportedMechanicError,'toxin'): run_scenario(BASE,c)
        for field,value in (('shield_interaction','shield_first'),('armor_loss','yes'),('damage_payment','ticks')):
            c=deepcopy(CHARACTERS); c['1E1']['abilities']['Ultimate'][field]=value
            with self.assertRaises(UnsupportedMechanicError): run_scenario(BASE,c)

    def test_exact_nonlethal_boundary(self):
        self.assertFalse(_nonlethal(Fraction(10),ExactAmount.of(10)))
        self.assertFalse(_nonlethal(Fraction(1),ExactAmount.of(ExactRootProduct(1,2))))
        self.assertTrue(_nonlethal(Fraction(2),ExactAmount.of(ExactRootProduct(1,2))))
