"""Current-rule invariants from the November review and nearby interactions."""
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import importlib.util
from pathlib import Path
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.shared_engine import SharedEncounter
from tests.test_grapple_links_combat import force
from tests.test_world_colliders_combat import platform, wall

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('principal_review_specs_20261103',ROOT/'results/principal-review-2026-11-03/reproduce.py')
review=importlib.util.module_from_spec(spec);spec.loader.exec_module(review)


class OriginalReviewSpecifications(review.ReviewRegressions):
    """Keep all seven independent review assertions unchanged and discoverable."""


class IndependentReadinessTests(unittest.TestCase):
    def conserved(self,r):
        loss=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-loss.amount(target=name)),D('1e-8'))

    def test_both_priority_orders_acquire_disjoint_hands_at_zero(self):
        for order in (False,True):
            with self.subTest(block_first=order):
                r=review.run(review.concurrency_scene(block_first=order))
                first={key:time for time,key in reversed(review.starts(r))}
                self.assertEqual((first['1'],first['basic_8']),('0','0'));self.conserved(r)

    def test_inert_input_preserves_combat_receipts_and_released_shots(self):
        a=review.run(review.concurrency_scene());b=review.run(review.concurrency_scene(noop=True))
        self.assertEqual(a['applied_hp_history'],b['applied_hp_history'])
        self.assertEqual(a['projectile_flights'],b['projectile_flights'])
        self.assertEqual(review.starts(a),review.starts(b))
        for n in a['metrics']:
            self.assertEqual({k:v for k,v in a['metrics'][n].items() if k!='movement_commands'},
                {k:v for k,v in b['metrics'][n].items() if k!='movement_commands'})

    def test_four_disjoint_existing_abilities_reach_readiness_at_the_same_clock(self):
        s=review.concurrency_scene();s['encounter']['duration_ms']=1
        s['action_selection']['A']['abilities']=['1','4','Ultimate','basic_8']
        s['action_selection']['B']['start_ms']=100000
        r=review.run(s);self.assertEqual(set(review.starts(r)),{('0',k) for k in ('1','4','Ultimate','basic_8')})
        owners=r['final_states']['A']['owned_actions'];self.assertEqual(len(owners),4)
        resources=[v for owner in owners for v in owner['occupies']]
        self.assertEqual(len(resources),len(set(resources)));self.assertLess(len(r['events']),100)

    def test_current_sword_block_and_dodge_have_independent_owners_and_stock(self):
        s=review.concurrency_scene();s['encounter']['duration_ms']=1
        s['action_selection']['A']['abilities']=['1','basic_8','basic_9'];s['action_selection']['B']['start_ms']=100000
        r=review.run(s);self.assertEqual(set(review.starts(r)),{('0','1'),('0','basic_8'),('0','basic_9')})
        self.assertEqual(len(review.events(r,'block_charges_spent')),1)
        self.assertEqual(len(review.events(r,'dodge_charges_spent')),1)

    def test_unaffordable_actions_do_not_spin_or_spend_reserved_capacity(self):
        s=review.concurrency_scene();s['encounter']['duration_ms']=2
        s['action_selection']['A']['abilities']=['1','4','Ultimate','basic_8'];s['action_selection']['B']['start_ms']=100000
        s['encounter']['participants']['A']['initial_state']['dyspnea']=98
        r=review.run(s)
        self.assertEqual(set(review.starts(r)),{('0','4'),('0','Ultimate')})
        self.assertFalse(review.events(r,'dyspnea_paid'));self.assertLess(len(r['events']),100)

    def test_payments_charges_and_cooldown_starts_are_once_per_action(self):
        r=review.run(review.concurrency_scene())
        paid=review.events(r,'dyspnea_paid');self.assertEqual(len(paid),len({(x['actor'],x['action_id'],x['phase']) for x in paid}))
        charges=review.events(r,'block_charges_spent');self.assertEqual(len(charges),len({x['action_id'] for x in charges}))
        cooldowns=review.events(r,'cooldown_started')
        self.assertTrue(paid);self.assertTrue(charges);self.assertTrue(cooldowns)
        self.assertEqual(len(cooldowns),len({(x['actor'],x['ability'],x.get('action_id')) for x in cooldowns}))
        for actor in r['metrics']:
            self.assertLess(abs(sum((D(p['amount']) for p in paid if p['actor']==actor),D(0))-D(r['metrics'][actor]['dyspnea_paid'])),D('1e-8'))
        self.conserved(r)


class ConcurrentEnhancementTests(unittest.TestCase):
    def scene(self,character,duration,abilities,shield=0):
        s=review.scene('current_concurrent_enhancements',duration)
        s['encounter']['participants']['A']['character']=character
        s['encounter']['participants']['B'].update(character='2E4',position_m=['1.1',-20])
        s['encounter']['participants']['B']['initial_state']['shield']=shield
        s['action_selection']['A'].update(abilities=abilities,start_ms=0,reload_when_empty=False)
        return s

    def test_actual_2e4_grants_begin_when_complete_without_rewriting_earlier_release(self):
        r=review.run(self.scene('2E4',450,['4','Ultimate','1'],4000))
        first={key:time for time,key in reversed(review.starts(r))}
        self.assertEqual({key:first[key] for key in ('4','Ultimate','1')},{key:'0' for key in ('4','Ultimate','1')})
        self.assertEqual([D(g['start_ms']) for g in r['attack_modifiers']],[200,400])
        shot=r['released_attack_modifiers'][0]
        self.assertEqual(D(shot['released_at_ms']),230)
        self.assertEqual(D(shot['values']['additional_armor_loss']),20)
        self.assertEqual(D(shot['values']['shielding_ignored']),0)
        first_hit=next(e for e in review.events(r,'impact_batch_resolved') if e['target']=='B')
        self.assertEqual(D(first_hit['applied_hp_damage']),0)
        self.assertEqual(D(first_hit['applied_shield_damage']),440)

    def test_actual_1e5_early_strike_is_unbuffed_then_both_arms_use_completed_grant(self):
        r=review.run(self.scene('1E5',1000,['Ultimate','1']))
        shots=r['released_attack_modifiers'];early=[s for s in shots if D(s['released_at_ms'])<320]
        active=[s for s in shots if D(s['released_at_ms'])>=320]
        self.assertTrue(early);self.assertTrue(active)
        self.assertTrue(all(D(s['values']['additional_piercing'])==0 for s in early))
        self.assertTrue(all(D(s['values']['additional_piercing'])==80 for s in active))
        self.assertEqual({s['component_id'] for s in active},{'a','b'})
        self.assertTrue(all(D(s['values']['bleeding_multiplier'])==2 for s in shots))


class CurrentReadinessInteractionTests(unittest.TestCase):
    def test_early_dash_can_miss_grab_while_explicit_grab_first_keeps_the_group(self):
        for grab_first in (False,True):
            with self.subTest(grab_first=grab_first):
                s=review.scene('current_grab_dash',1400)
                s['encounter']['participants']['A']['character']='1E5'
                s['encounter']['participants']['B'].update(character='2E4',position_m=['1.1',-20])
                s['action_selection']['A'].update(abilities=['2','3'],start_ms=0,reload_when_empty=False)
                if grab_first:
                    s['initial_restrictions']=[{'target':'A','source':'fixture:grab_before_dash',
                        'functions':['lower_body'],'duration_ms':200}]
                r=review.run(s);launch=r['body_dash_launches'][0]
                if grab_first:
                    self.assertEqual(r['grapple_holds'][0]['status'],'active')
                    self.assertGreater(D(launch['launched_at_ms']),D(review.events(r,'grapple_holding_started')[0]['time_ms']))
                    a,b=(tuple(map(D,r['final_states'][n]['body_origin_m'])) for n in ('A','B'))
                    self.assertLess(abs(b[0]-a[0]-D('1.1')),D('1e-20'))
                    self.assertEqual(a[2]-D('1.1375'),b[2]-D('.875'))
                    self.assertLess(abs(D(launch['shared_velocity_mps'][0])),abs(D(launch['free_velocity_mps'][0])))
                else:
                    self.assertEqual(set(review.starts(r)),{('0','2'),('0','3')})
                    self.assertFalse(r['grapple_holds']);self.assertTrue(review.events(r,'melee_missed'))
                    self.assertEqual(D(launch['launched_at_ms']),140)
                self.assertEqual(len(review.events(r,'body_launch_landed')),1)

    def test_two_concurrent_guards_protect_while_one_guard_allows_released_mutual_kills(self):
        for single_guard in (False,True):
            with self.subTest(single_guard=single_guard):
                s=review.scene('current_mutual_counter',249)
                for name in ('A','B'):
                    s['encounter']['participants'][name].update(character='2E4')
                    s['encounter']['participants'][name]['initial_state'].update(hp=1,armor=0)
                    s['action_selection'][name].update(abilities=['1','basic_8'],start_ms=0,reload_when_empty=False)
                    s['movement_script'].append({'actor':name,'at_ms':150,'action':'walk'})
                    if single_guard:
                        s.setdefault('initial_restrictions',[]).append({'target':name,
                            'source':'fixture:single_guard_before_counter','functions':['hand:left'],'duration_ms':150})
                s['encounter']['participants']['B'].update(position_m=['1.1',-20])
                r=review.run(s);self.assertEqual(len(r['reaction_emissions']),2)
                self.assertEqual(len(r['block_layers']),2 if single_guard else 4)
                ledger=DamageLedger.from_record(r['applied_hp_history'])
                for name in ('A','B'):
                    self.assertEqual(D(r['final_states'][name]['hp']),0 if single_guard else 1)
                    self.assertEqual(ledger.amount(actor=name,eligible_only=True),1 if single_guard else 0)
                    if single_guard:
                        attempt=next(a for a in r['revival_attempts'] if a['actor']==name)
                        self.assertEqual(D(attempt['restoration_hp']),1)


class PoseContactClimbTests(unittest.TestCase):
    def completed_on_cube(self,r,*,active=210,completed=510):
        self.assertFalse(review.events(r,'climb_interrupted'))
        self.assertFalse(review.events(r,'movement_intent_blocked'))
        self.assertEqual([D(e['time_ms']) for e in review.events(r,'climb_active_started')],[active])
        self.assertEqual([D(e['time_ms']) for e in review.events(r,'climb_completed')],[completed])
        state=r['final_states']['A'];self.assertEqual(tuple(map(D,state['body_origin_m'])),(6,0,D('2.675')))
        self.assertEqual(state['locomotion']['support_id'],'cube_1')
        self.assertTrue(state['locomotion']['grounded'])
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        costs=[e for e in review.events(r,'dyspnea_paid') if e['actor']=='A' and e['ability']=='climb']
        self.assertEqual(len(costs),1);self.assertEqual(D(costs[0]['amount']),D('12.25'))

    def test_pose_contact_freezes_deformation_without_consuming_climb_intent(self):
        for x in ('4.59','4.589998'):
            with self.subTest(x=x):
                r=review.run(review.climb_scene(x),interval=100);self.completed_on_cube(r)
                self.assertTrue(review.events(r,'body_pose_contact'))
                self.assertTrue(review.events(r,'equilibrium_deformation_blocked'))
                self.assertFalse(review.events(r,'body_contact'))
                during=next(p['states']['A'] for p in r['curve'] if D(p['time_ms'])==300)
                self.assertTrue(any(a['action']['kind']=='climb' for a in during['owned_actions']))

    def test_current_rules_keep_climb_outcome_across_observations_precision_and_order(self):
        for x in ('4.59','4.589998'):
            for precision,interval in ((50,None),(50,1),(50,37),(50,100),(80,113)):
                with self.subTest(x=x,precision=precision,interval=interval):
                    s=review.climb_scene(x)
                    s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
                    r=review.run(s,precision=precision,interval=interval);self.completed_on_cube(r)
                    self.assertFalse(review.events(r,'body_contact'))

    def test_read_only_body_audit_keeps_all_six_cuboids_outside_solids(self):
        # Inspect the actual world boxes at 1 ms observations. This fixture
        # neither injects events nor changes body/pose/velocity state.
        case=self
        class Audit(SharedEncounter):
            observations=0
            def sample(self,label):
                for name,boxes in self.world_bodies.items():
                    case.assertEqual(len(boxes),6)
                    for collider,parts in self.body_terrain_colliders().items():
                        for box in boxes:
                            low,high=box.bounds
                            for part in parts:
                                other_low,other_high=part.bounds
                                depth=min(min(a,b)-max(c,d) for a,b,c,d in zip(high,other_high,low,other_low))
                                case.assertLessEqual(depth,F(1,10**20),(self.time,name,collider,box.part))
                self.observations+=1
                return super().sample(label)
        with localcontext(Context(prec=50)):
            for x in ('4.59','4.589998'):
                world=Audit(review.climb_scene(x),review.PROFILES,precision=50,sample_interval_ms=1,**review.INPUTS)
                r=world.run();self.completed_on_cube(r);self.assertGreaterEqual(world.observations,651)

    def test_real_contact_just_before_active_still_delays_gathering(self):
        for precision,interval in ((50,None),(50,37),(80,113)):
            with self.subTest(precision=precision,interval=interval):
                r=review.run(review.climb_scene('4.590002'),precision=precision,interval=interval)
                contact=review.events(r,'body_contact');self.assertEqual(len(contact),1)
                self.assertEqual(D(contact[0]['time_ms']),D('209.999'))
                self.assertEqual(D(contact[0]['relative_speed_mps']),2)
                self.completed_on_cube(r,active=286,completed=586)

    def test_true_overhead_translation_contact_still_interrupts_climb(self):
        for precision,interval in ((50,None),(50,37),(80,113)):
            with self.subTest(precision=precision,interval=interval):
                s=review.climb_scene('4.6',walking=False);s['encounter']['duration_ms']=1100
                roof=wall('roof',x='4.6',hp=None,size=(1,2,'.2'),z='2.9')
                roof['parts'][0]['centre_m'][1]=0;s['initial_colliders']=[roof]
                r=review.run(s,precision=precision,interval=interval)
                cancelled=review.events(r,'climb_interrupted');self.assertEqual(len(cancelled),1)
                self.assertEqual(cancelled[0]['reason'],'body_contact')
                self.assertGreater(D(cancelled[0]['velocity_before_contact_mps'][2]),0)
                contacts=review.events(r,'body_contact');self.assertTrue(contacts)
                self.assertGreater(D(contacts[0]['relative_speed_mps']),0)
                self.assertTrue(review.events(r,'movement_intent_blocked'))
                self.assertFalse(review.events(r,'climb_completed'))
                self.assertTrue(r['final_states']['A']['locomotion']['grounded'])
                self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)

    def test_imposed_velocity_still_preempts_climb_and_lands_under_gravity(self):
        s=review.climb_scene('4.6',walking=False);s['encounter']['duration_ms']=1300
        # Explicit engineering intervention; no new character ability.
        s['spatial_interventions']=[force(220,'A',[-5,0,0])]
        r=review.run(s);cancelled=review.events(r,'climb_interrupted')
        self.assertEqual(len(cancelled),1);self.assertEqual(D(cancelled[0]['time_ms']),220)
        self.assertEqual(cancelled[0]['reason'],'external_velocity')
        self.assertFalse(review.events(r,'climb_completed'))
        self.assertEqual(r['metrics']['A']['landings'],1)
        self.assertLess(D(r['final_states']['A']['position_m'][0]),D('4.6'))

    def test_target_expiry_at_completion_cannot_complete_or_repay_climb(self):
        s=review.scene('current_target_expiry',1100,('.6',-20))
        target=platform();target['duration_ms']=450;s['initial_colliders']=[target]
        review.command(s,0,'climb','platform');r=review.run(s)
        cancelled=review.events(r,'climb_interrupted');self.assertEqual(len(cancelled),1)
        self.assertEqual((D(cancelled[0]['time_ms']),cancelled[0]['reason']),(450,'lifetime_expired'))
        self.assertFalse(review.events(r,'climb_completed'))
        costs=[e for e in review.events(r,'dyspnea_paid') if e['actor']=='A' and e['ability']=='climb']
        self.assertEqual(len(costs),1);self.assertEqual(D(costs[0]['amount']),D('12.25'))
