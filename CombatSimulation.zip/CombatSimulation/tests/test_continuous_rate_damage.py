"""Shared heat/rate layer accounting, not a separate damage runner."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.constriction import damage_rate
from combat_sim.mechanics.delayed_shield import DelayedShieldRecovery
from combat_sim.mechanics.rate_damage import RateDamageSource
from combat_sim.mechanics.recovery_flow import AffineRate,RootRate
from combat_sim.mechanics.thermal_balance import ThermalSource,build_thermal_plan


def source(name='drag',raw=900,armor=150,*,begin=1000,slope=0):
    return RateDamageSource(name,AffineRate(raw,begin,slope),D(armor))


def recovery(begin=1000,end=2000,rate=400,backlog=0):
    r=DelayedShieldRecovery(1,rate)
    if backlog:r.add_impact(D(0),D(backlog))
    return r,r.plan(D(begin),D(end))


class ContinuousRateTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_primary_constriction_rate_uses_the_25_over_4_armor_term(self):
        self.assertEqual(damage_rate(900,150),F(2975,4))
        self.assertEqual(damage_rate(900,400),0);self.assertEqual(damage_rate(0,150),0)
        for raw,armor in ((-1,0),(1,-1),(True,0),(1,'NaN')):
            with self.assertRaises(ValueError):damage_rate(raw,armor)

    def test_without_shield_or_recovery_only_post_armor_damage_reaches_hp(self):
        _,r=recovery();p=build_thermal_plan(r,D(0),(source(),))
        stock,q,hp,shield=p.at(D(2000))
        self.assertEqual(stock,0);self.assertEqual(q,(D(0),));self.assertEqual(shield,(D(0),))
        self.assertLess(abs(hp[0]-D('743.75')),D('1e-20'))

    def test_positive_shield_uses_full_pressure_without_body_damage(self):
        _,r=recovery();p=build_thermal_plan(r,D(1000),(source(),))
        stock,_,hp,shield=p.at(D(2000))
        self.assertEqual(stock,100);self.assertEqual(hp,(D(0),));self.assertEqual(shield,(D(900),))

    def test_stock_exhaustion_is_one_physical_boundary_then_body_damage(self):
        manager,r=recovery();first=build_thermal_plan(r,D(100),(source(),))
        self.assertTrue(first.depleted)
        self.assertLess(abs(first.end-D(1000)-D(1000)/9),D('1e-20'))
        second=build_thermal_plan(manager.plan(first.end,D(2000)),D(0),(source(),))
        stock,_,hp,_=second.at(D(2000));self.assertEqual(stock,0)
        expected=D('743.75')*(2000-first.end)/1000
        self.assertLess(abs(hp[0]-expected),D('1e-20'))

    def test_zero_stock_uses_recovery_before_mitigating_remaining_pressure(self):
        _,r=recovery(rate=500,backlog=10000)
        p=build_thermal_plan(r,D(0),(source(),));stock,_,hp,shield=p.at(D(2000))
        self.assertEqual(stock,0);self.assertEqual(shield,(D(500),))
        self.assertLess(abs(hp[0]-D('48.4375')),D('1e-20'))

    def test_recovery_and_armor_can_together_block_all_body_damage(self):
        _,r=recovery(rate=600,backlog=10000)
        p=build_thermal_plan(r,D(0),(source(),));stock,_,hp,shield=p.at(D(2000))
        self.assertEqual(stock,0);self.assertEqual(shield,(D(600),));self.assertEqual(hp,(D(0),))

    def test_simultaneous_sources_share_recovery_before_individual_defenses(self):
        _,r=recovery(rate=500,backlog=10000)
        p=build_thermal_plan(r,D(0),(source('a',900),source('b',600)))
        stock,_,hp,shield=p.at(D(2000));self.assertEqual(stock,0)
        self.assertEqual(shield,(D(300),D(200)))
        self.assertLess(abs(hp[0]-D('365.625')),D('1e-20'))
        self.assertLess(abs(hp[1]-D('48.4375')),D('1e-20'))

    def test_mixed_heat_and_constriction_use_one_stock_balance(self):
        _,r=recovery();heat=ThermalSource('heat',RootRate(400,0,1000,1),D(0),D(300),True,False)
        p=build_thermal_plan(r,D(1000),(source(),heat))
        self.assertTrue(p.depleted)
        seconds=(p.end-1000)/1000
        self.assertLess(abs(900*seconds+D(800)/3*seconds**D('1.5')-1000),D('1e-20'))
        self.assertEqual(p.at(p.end)[2],(D(0),D(0)))
        self.assertLess(abs(sum(p.at(p.end)[3])-1000),D('1e-20'))

    def test_dense_prefixes_for_affine_damage_are_observation_independent(self):
        _,r=recovery();p=build_thermal_plan(r,D(0),(source(raw=880,slope=250),))
        full=p.at(D(2000))[2][0]
        times=list(map(D,(1000,1017,1100,1137,1500,1739,2000)))
        pieces=sum(p.at(b)[2][0]-p.at(a)[2][0] for a,b in zip(times,times[1:]))
        self.assertLess(abs(full-pieces),D('1e-40'))
        # Independent antiderivative: integral(d - (25*a^2)/(4*d)).
        first,last=D(880),D(1130);expected=(first+last)/2-D(25)*150**2/(4*250)*(last/first).ln()
        self.assertLess(abs(full-expected),D('1e-9'))

    def test_mixed_heat_recovery_and_rate_damage_converge_with_tighter_error_control(self):
        _,r=recovery(rate=500,backlog=10000)
        inputs=(source(),ThermalSource('heat',RootRate(400,0,1000,1),D(0),D(300),True,False))
        p=build_thermal_plan(r,D(0),inputs)
        tighter=build_thermal_plan(r,D(0),inputs,absolute=D('1e-18'),relative=D('1e-17'))
        a,b=p.at(D(2000)),tighter.at(D(2000))
        self.assertEqual(a[0],0);self.assertEqual(b[0],0)
        for x,y in zip(a[2],b[2]):self.assertLess(abs(x-y),D('1e-8'))
        self.assertLess(abs(sum(a[3])-500),D('1e-20'))


if __name__=='__main__':unittest.main()
