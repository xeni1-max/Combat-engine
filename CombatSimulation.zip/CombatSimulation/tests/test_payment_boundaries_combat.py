"""Real pending casts meet continuous effort at their authoritative payment.

Filling/expiry presets explicitly exercise the shared resource API; they are
engineering fixtures, not claims that common Break is already implemented.
"""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.shared_engine import SharedEncounter
from tests.test_motion_boundary_combat import scene,CURRENT
from tests.test_continuous_effort_combat import owner
from tests.test_mobile_combat import BODY,MOVEMENT,PROFILES,TERRAIN,events
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS


def build(character='1E2',*,dyspnea=91,duration=200,ability='1',interval=None,precision=50,
        base_fill=20,release_at=None,empty=False,distance=30,position=(0,-20)):
    s=scene(duration,position);s['id']='engineering_payment_boundary'
    s['encounter']['participants']['A']['character']=character
    s['encounter']['participants']['A']['initial_state']['dyspnea']=dyspnea
    s['encounter']['participants']['B']['position_m']=[distance,-20]
    s['action_selection']['A'].update(abilities=[ability],start_ms=0)

    class ResourceFixture(SharedEncounter):
        def _process(self,kind,p):
            if kind!='fixture_release_budget':return super()._process(kind,p)
            actor=self.fighters[p['actor']];action=actor.action_by_id(p['action_id'])
            if action is not None:self.cancel_owned_action(actor,action,'engineering_budget_expired')

    w=ResourceFixture(s,PROFILES,precision=precision,sample_interval_ms=interval,body_definition=BODY,
        terrain_definition=TERRAIN,movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
        jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS)
    a=owner(w,until=max(duration,1000));actor=w.fighters['A']
    if empty:actor.ammo['1']=0
    channel=w.continuous_effort.start(actor,a,tag='engineering:future_break_fill',kind='fill',base=base_fill,
        until_ms=max(duration,1000))
    if release_at is not None:w.push(release_at,'fixture_release_budget',{'actor':'A','action_id':a.id})
    w.initial=w.states()
    return w,a,channel


class PaymentBoundaryCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_gun_end_failure_releases_only_the_unpaid_action_and_no_shot(self):
        w,placeholder,channel=build();r=w.run();actor=w.fighters['A']
        rejected=events(r,'dyspnea_payment_rejected');self.assertEqual(len(rejected),1)
        e=rejected[0];self.assertEqual((D(e['time_ms']),e['phase']),(111,'active_firing_end'))
        self.assertEqual((D(e['before']),D(e['required'])),(D('93.22'),D('8.59779684')))
        self.assertFalse(events(r,'dyspnea_paid'));self.assertFalse(events(r,'projectile_released'))
        self.assertEqual(actor.ammo['1'],11);self.assertEqual(actor.ready['1'],0)
        self.assertEqual(actor.dyspnea,95);self.assertEqual(channel.gained,4)
        self.assertEqual(actor.live_actions(),(placeholder,));self.assertEqual(actor.action_registry.reserved(),0)
        cancelled=events(r,'controlled_action_cancelled');self.assertEqual(len(cancelled),1)
        self.assertEqual(cancelled[0]['reason'],'payment_capacity_exhausted')
        self.assertEqual(cancelled[0]['action_id'],e['action_id'])

    def test_qard_end_failure_does_not_create_flight_mark_or_splash(self):
        w,_,_=build('1E1',duration=400);r=w.run()
        e=events(r,'dyspnea_payment_rejected')[0]
        self.assertEqual((D(e['time_ms']),e['phase']),(398,'active_firing_end'))
        self.assertFalse(events(r,'projectile_released'));self.assertFalse(events(r,'delayed_blast'))
        self.assertFalse(r['released_attack_power']);self.assertEqual(w.fighters['A'].ready['1'],0)

    def test_thrust_start_failure_does_not_spend_a_blade_or_create_venom(self):
        w,_,_=build('2E4',dyspnea=84,duration=400);r=w.run()
        self.assertEqual(events(r,'dyspnea_payment_rejected')[0]['phase'],'active_start')
        self.assertFalse([e for e in events(r,'active_started') if e['actor']=='A'])
        self.assertFalse(r['melee_attacks']);self.assertFalse(events(r,'replacement_blade_summoning'))
        self.assertEqual(r['blade_items'][0]['status'],'held');self.assertFalse(events(r,'blade_attached'))
        self.assertFalse(events(r,'self_status_applied'))

    def test_component_start_failure_keeps_the_same_next_arm(self):
        w,_,_=build('1E5',duration=400);r=w.run()
        self.assertEqual(events(r,'dyspnea_payment_rejected')[0]['phase'],'active_start')
        self.assertFalse(r['melee_attacks']);self.assertFalse(r['released_attack_power'])
        self.assertEqual(r['melee_component_sequences'][0]['next_component'],'a')
        self.assertFalse(events(r,'self_status_applied'))

    def test_grab_start_failure_does_not_start_cooldown_or_link(self):
        w,_,_=build('1E5',ability='2',duration=300,distance='1.1');r=w.run()
        self.assertEqual(events(r,'dyspnea_payment_rejected')[0]['phase'],'active_start')
        self.assertFalse(r['grapple_holds']);self.assertFalse(r['grapple_links']);self.assertFalse(r['melee_attacks'])
        self.assertEqual(w.fighters['A'].ready['2'],0);self.assertFalse(r['controlled_damage_streams'])

    def test_reload_start_failure_does_not_refill_ammo(self):
        w,_,_=build(dyspnea=97,duration=1500,empty=True);r=w.run()
        rejected=events(r,'dyspnea_payment_rejected');self.assertEqual(len(rejected),1)
        self.assertEqual((rejected[0]['action_kind'],rejected[0]['phase']),('reload','active_start'))
        self.assertEqual(w.fighters['A'].ammo['1'],0);self.assertFalse(events(r,'reload_completed'))
        self.assertFalse(events(r,'projectile_released'));self.assertFalse(events(r,'dyspnea_paid'))

    def test_completed_prior_self_statuses_are_not_retracted_on_failure(self):
        w,_,_=build();r=w.run();self.assertEqual(len(events(r,'self_status_applied')),1)
        applied=events(r,'self_status_applied')[0];failure=events(r,'dyspnea_payment_rejected')[0]
        self.assertLess(D(applied['time_ms']),D(failure['time_ms']))
        amount=D(applied['additions']['instability']);elapsed=w.time-D(applied['time_ms'])
        self.assertEqual(w.fighters['A'].instability,max(D(0),amount-elapsed))

    def test_a_previously_paid_released_shot_still_hits_after_later_failure(self):
        w,_,_=build(dyspnea=74,duration=900,distance=240,position=(-200,-20));r=w.run()
        paid=events(r,'dyspnea_paid');failures=events(r,'dyspnea_payment_rejected')
        self.assertEqual(len(paid),1);self.assertEqual(len(events(r,'projectile_released')),1)
        self.assertEqual(len(failures),1)
        hits=[e for e in events(r,'impact_batch_resolved') if e['target']=='B']
        self.assertEqual(len(hits),1);self.assertGreater(D(hits[0]['time_ms']),D(failures[0]['time_ms']))
        self.assertGreater(D(hits[0]['applied_hp_damage']),0)
        self.assertEqual(w.fighters['A'].ammo['1'],10)

    def test_recovery_after_the_independent_effort_ends_can_retry_normally(self):
        w,_,channel=build(duration=1000,release_at=200);r=w.run()
        self.assertEqual(channel.ended_at_ms,200)
        failures=events(r,'dyspnea_payment_rejected');self.assertEqual(len(failures),1)
        paid=events(r,'dyspnea_paid');self.assertTrue(paid)
        self.assertGreater(D(paid[0]['time_ms']),200)
        self.assertTrue(events(r,'projectile_released'))
        self.assertTrue(all(e['action_id']!=failures[0]['action_id'] for e in paid))
        self.assertFalse([a for a in w.fighters['A'].live_actions() if a.id==failures[0]['action_id']])

    def test_effortless_mark_deploys_with_a_full_bar(self):
        w,_,_=build(dyspnea=99,duration=250,ability='2');r=w.run()
        self.assertFalse(events(r,'dyspnea_payment_rejected'));self.assertFalse(events(r,'dyspnea_paid'))
        self.assertTrue(r['cooldown_pause_volumes']);self.assertEqual(w.fighters['A'].dyspnea,100)
        self.assertEqual(len(events(r,'maximum_dyspnea_trigger')),1)

    def test_real_grab_survives_its_recipients_independent_failed_gun_payment(self):
        from tests.test_grapple_casts_combat import scene as grab_scene,engine
        s=grab_scene(700);s['encounter']['participants']['B']['character']='1E2'
        s['encounter']['participants']['B']['initial_state']['dyspnea']='83.5'
        s['action_selection']['B'].update(abilities=['1'],start_ms=300)
        w=engine(s);bookkeeping=owner(w,name='B');target=w.fighters['B']
        channel=w.continuous_effort.start(target,bookkeeping,tag='engineering:future_break_fill',
            kind='fill',base=20,until_ms=1000);w.initial=w.states();r=w.run()
        failures=events(r,'dyspnea_payment_rejected');self.assertEqual(len(failures),1)
        self.assertEqual((failures[0]['actor'],failures[0]['phase']),('B','active_firing_end'))
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertIsNone(r['controlled_damage_streams'][0]['ended_at_ms'])
        self.assertEqual(target.dyspnea,D('97.5'));self.assertEqual(channel.gained,14)
        self.assertEqual(target.ammo['1'],11);self.assertFalse(events(r,'projectile_released'))
        self.assertGreater(D(r['metrics']['B']['continuous_hp_damage_received']),0)

    def test_death_before_payment_keeps_the_author_no_cost_rule(self):
        w,_,_=build(duration=300);w.fighters['A'].hp=D(1)
        w.choices['A']['start_ms']=100;w.choices['B']['start_ms']=0;w.initial=w.states();r=w.run()
        self.assertEqual(w.fighters['A'].hp,0)
        self.assertFalse([e for e in events(r,'dyspnea_paid') if e['actor']=='A'])
        self.assertFalse([e for e in events(r,'dyspnea_payment_rejected') if e['actor']=='A'])
        self.assertFalse([e for e in events(r,'projectile_released') if e['actor']=='A'])

    def test_observation_precision_and_actor_order_do_not_choose_failure_time(self):
        baseline=None
        for precision,interval in ((50,None),(50,17),(50,100),(80,137)):
            w,_,_=build(interval=interval,precision=precision)
            w.fighters=dict(reversed(list(w.fighters.items())));r=w.run()
            rows=[(e['time_ms'],e['phase'],e['before'],e['required']) for e in events(r,'dyspnea_payment_rejected')]
            if baseline is None:baseline=rows
            else:self.assertEqual(rows,baseline)
            self.assertEqual(w.fighters['A'].dyspnea,95)


if __name__=='__main__':unittest.main()
