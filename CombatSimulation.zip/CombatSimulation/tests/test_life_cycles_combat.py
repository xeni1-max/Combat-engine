"""Life transitions exercise real shared actions and autonomous interactions.

Explicit restoration/zero-HP/registry probes are engineering fixtures, not new
abilities or an implementation claim for 2E4's authored revival cast.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.shared_engine import SharedEncounter
from combat_sim.analysis import summarize
from combat_sim.models import UnsupportedMechanicError
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB, climb
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_motion_boundary_combat import CURRENT, scene
from tests.test_world_colliders_combat import wall
from tests.test_cooldown_fields_combat import marking_scene
from tests.test_spatial_heat_combat import beam_scene
from tests.test_thermal_recovery_combat import coupled_scene
from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE, MOBILE_SCOPE
from tests.test_projectile_entities_combat import one_shot_profiles


def duel(duration=1200):
    s=scene(duration,(0,-20))
    for c in s['action_selection'].values():c['start_ms']=0
    s['encounter']['participants']['B']['initial_state']['hp']=1
    return s


def run(s,*,operations=(),interval=100,precision=50,profiles=PROFILES,effects=CURRENT):
    class Fixture(SharedEncounter):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            for when,op in operations:self.push(when,'fixture_life',op)

        def _process(self,kind,p):
            if kind!='fixture_life':return super()._process(kind,p)
            actor=self.fighters[p.get('actor','B')]
            if p['op']=='revive':
                success=self.life_cycles.revive(actor.id,expected_generation=p.get('generation',1),
                    hp=p.get('hp',1000),source='fixture:life_restoration')
                self.log('fixture_life_restoration',actor=actor.id,success=success,state=actor.record())
            elif p['op']=='kill':
                self.log('fixture_hp_zero',actor=actor.id,hp_before=actor.hp,damage_credit=False,
                    reason='explicit_lifecycle_probe_not_an_attack')
                actor.hp=D(0)
            elif p['op']=='restriction':
                self.apply_action_restriction(actor.id,source=p.get('source','fixture:binding'),
                    functions=p.get('functions',['lower_body']),until_ms=D(p['until']))
            elif p['op']=='stale_decision':
                payload={'actor':actor.id,'revision':actor.decision_revision,'actor_life_generation':p.get('generation',1)}
                event=(self.time,D(10),0,'decision',payload)
                self.log('fixture_stale_life_event',actor=actor.id,live=self._live(event))
                self.push(self.time,'decision',payload,priority=10)
            elif p['op']=='spawn':self.collider_system.spawn_definition(p['definition'])
            elif p['op']=='remove':self.collider_system.remove(p['id'],reason='fixture_removal')
            elif p['op']=='copy':
                shot=next(f for f in self.projectile_flights.values() if f['actor']==actor.id)
                offset=(0,0,0)
                if p.get('at_owner'):
                    point=self.mobile_flight_state(shot,self.time)[0]
                    offset=tuple(a-b for a,b in zip(actor.body_origin_m,point))
                child=self.projectile_system.copy(shot['id'],source='fixture:copy',offset_m=offset)
                self.log('fixture_copied_old_life',actor=actor.id,projectile_id=child)
            else:raise ValueError('Unknown life fixture')

    with localcontext(Context(prec=precision)):
        return Fixture(s,profiles,precision=precision,sample_interval_ms=interval,
            body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,
            combat_locomotion_definition=effects,jump_definition=JUMP,climb_definition=CLIMB,
            projectile_physics_definition=PHYSICS if s['scope']==GRAVITY_MOBILE_SCOPE else None).run()


class LifeCyclesCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_real_lethal_gun_hit_and_restoration_create_distinct_inspectable_lives(self):
        r=run(duel(),operations=[(300,{'op':'revive'})])
        self.assertEqual(r['initial_states']['B']['life_generation'],1)
        self.assertEqual(r['final_states']['B']['life_generation'],2)
        lives=r['actor_lives']['B']
        self.assertEqual([x['generation'] for x in lives],[1,2])
        self.assertEqual(lives[0]['died_at_ms'],events(r,'character_died','B')[0]['time_ms'])
        self.assertEqual(D(lives[1]['born_at_ms']),300)
        self.assertEqual(lives[1]['initial_hp'],'1000')
        self.assertTrue(r['final_states']['B']['alive'])

    def test_old_recipient_bleed_ends_while_old_source_bleed_keeps_its_life(self):
        r=run(duel(),operations=[(300,{'op':'revive'})])
        old_target=[e for e in r['effect_instances'] if e['kind']=='bleeding' and e['target']=='B'
                    and e['target_life_generation']==1]
        self.assertTrue(old_target)
        self.assertTrue(all(e['status']=='ended' and e['end_reason']=='target_life_ended' for e in old_target))
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        old_source_after=[e for e in ledger.entries if e.contribution.source.actor=='B'
            and e.contribution.source.life_generation==1 and e.end>D(300)]
        self.assertTrue(old_source_after)
        self.assertTrue(all(e.contribution.kind=='bleeding' for e in old_source_after))
        self.assertTrue(any(e.contribution.source.life_generation==2 for e in ledger.entries if e.contribution.source.actor=='B'))

    def test_damage_history_keeps_actual_hp_across_recipient_lives(self):
        r=run(duel(),operations=[(300,{'op':'revive'})]);ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertEqual(ledger.amount(target='B',target_life_generation=1),1)
        self.assertGreater(ledger.amount(target='B',target_life_generation=2),0)
        self.assertAlmostEqual(ledger.amount(target='B'),1+1000-D(r['final_states']['B']['hp']),places=20)
        self.assertGreater(D(r['actor_lives']['B'][0]['eligible_damage_last_10s_at_death']),0)

    def test_summary_reports_actual_damage_instead_of_initial_minus_restored_hp(self):
        r=run(duel(),operations=[(300,{'op':'revive'})]);summary=summarize(r)
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertAlmostEqual(D(summary['participants']['B']['hp_damage_received']),ledger.amount(target='B'),places=20)
        self.assertGreater(D(summary['participants']['B']['hp_damage_received']),0)
        self.assertEqual(summary['life_cycles']['actor_lives'],r['actor_lives'])

    def test_restoration_retains_ammo_armor_shield_and_fatigue(self):
        r=run(duel(301),operations=[(300,{'op':'revive'})])
        dead=events(r,'character_died','B')[0]['state']
        restored=events(r,'life_restored','B')[0]['state']
        for key in ('ammo','armor','shield','dyspnea','disorientation','instability','hands_m'):
            self.assertEqual(restored[key],dead[key],key)
        self.assertFalse(restored['owned_actions'])
        self.assertGreater(D(restored['cooldown_clocks']['1']['remaining_work_ms']),0)
        self.assertEqual(restored['cooldown_clocks']['1']['remaining_work_ms'],dead['cooldown_clocks']['1']['remaining_work_ms'])
        self.assertEqual(D(restored['cooldown_clocks']['1']['ready_at_ms']),
            300+D(dead['cooldown_clocks']['1']['remaining_work_ms']))

    def test_repeated_old_generation_restore_cannot_refill_the_new_life(self):
        r=run(duel(302),operations=[(300,{'op':'revive'}),(301,{'op':'revive','hp':8000})])
        self.assertEqual([e['success'] for e in events(r,'fixture_life_restoration')],[True,False])
        self.assertEqual(len(events(r,'life_restored')),1)
        self.assertLessEqual(D(r['final_states']['B']['hp']),1000)

    def test_old_life_event_with_current_decision_revision_is_still_stale(self):
        r=run(duel(302),operations=[(300,{'op':'revive'}),(301,{'op':'stale_decision'})])
        self.assertFalse(events(r,'fixture_stale_life_event')[0]['live'])
        self.assertTrue(all(e['details'].get('actor_life_generation')==2 for e in r['pending_events']
            if e['details'].get('actor')=='B' and e['type']=='decision'))

    def test_new_life_wakes_opponents_after_they_ran_out_of_living_targets(self):
        r=run(duel(1800),operations=[(1000,{'op':'revive'})])
        shots=events(r,'projectile_released','A')
        self.assertTrue(any(D(e['time_ms'])>1000 for e in shots))
        hits=[e for e in events(r,'projectile_body_collision','A') if D(e['time_ms'])>1000]
        self.assertTrue(hits);self.assertTrue(all(e['target_life_generation']==2 for e in hits))

    def test_removed_function_restriction_and_its_old_expiry_do_not_cross_lives(self):
        ops=[(50,{'op':'restriction','until':500}),
             (300,{'op':'revive'}),(400,{'op':'restriction','until':900})]
        r=run(duel(950),operations=ops)
        after=next(p['states']['B'] for p in r['curve'] if D(p['time_ms'])==600)
        self.assertEqual(after['action_restrictions'],{'fixture:binding':['lower_body']})
        expiries=events(r,'action_restriction_expired','B')
        self.assertEqual([D(e['time_ms']) for e in expiries],[900])

    def test_body_occupancy_blocks_restoration_without_teleport_then_clearance_allows_it(self):
        blocker=wall('occupied',x=30,hp=None,size=(2,2,2),z=1)
        ops=[(200,{'op':'spawn','definition':blocker}),(300,{'op':'revive'}),
             (350,{'op':'remove','id':'occupied'}),(400,{'op':'revive'})]
        r=run(duel(401),operations=ops)
        attempts=events(r,'fixture_life_restoration')
        self.assertEqual([e['success'] for e in attempts],[False,True])
        self.assertEqual(attempts[0]['state']['life_generation'],1)
        self.assertEqual(D(attempts[0]['state']['hp']),0)
        self.assertEqual(r['final_states']['B']['life_generation'],2)

    def test_airborne_restoration_uses_gravity_and_does_not_finish_the_old_jump(self):
        s=scene(900,(0,-20));command(s,'A',0,'jump')
        r=run(s,operations=[(200,{'op':'kill','actor':'A'}),
                           (300,{'op':'revive','actor':'A'})])
        self.assertFalse(events(r,'jump_active_completed','A'))
        self.assertEqual(r['metrics']['A']['jumps_started'],1)
        landed=events(r,'jump_landed','A')[0]
        self.assertGreater(D(landed['time_ms']),300)
        self.assertEqual(landed['self_effects'],{'disorientation':'0','instability':'0'})
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)

    def test_climb_death_cannot_resume_or_complete_its_old_path(self):
        s=scene(1000,('4.6',0));climb(s)
        r=run(s,operations=[(200,{'op':'kill','actor':'A'}),
                           (300,{'op':'revive','actor':'A'})])
        self.assertEqual(len(events(r,'climb_interrupted','A')),1)
        self.assertFalse(events(r,'climb_completed','A'))
        self.assertFalse(events(r,'climb_top_reached','A'))
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_invalid_hp_requests_fail_before_a_life_transition(self):
        for hp in (0,-1,True,100000):
            with self.subTest(hp=hp),self.assertRaises(ValueError):
                run(duel(301),operations=[(300,{'op':'revive','hp':hp})])

    def test_precision_and_observation_schedules_preserve_the_life_outcome(self):
        baseline=run(duel(),operations=[(300,{'op':'revive'})],interval=None)
        for precision,interval in ((50,37),(80,113)):
            r=run(duel(),operations=[(300,{'op':'revive'})],precision=precision,interval=interval)
            for name,lives in r['actor_lives'].items():
                self.assertEqual(len(lives),len(baseline['actor_lives'][name]))
                for actual,expected in zip(lives,baseline['actor_lives'][name]):
                    for key in actual:
                        if key in ('initial_hp','eligible_damage_last_10s_at_death'):
                            self.assertLessEqual(abs(D(actual[key])-D(expected[key])),D('1e-8'))
                        else:self.assertEqual(actual[key],expected[key])
            for name in r['final_states']:
                self.assertEqual(r['final_states'][name]['life_generation'],baseline['final_states'][name]['life_generation'])
                self.assertLess(abs(D(r['final_states'][name]['hp'])-D(baseline['final_states'][name]['hp'])),D('1e-8'))

    def test_heat_volume_survives_source_death_and_keeps_its_original_source_life(self):
        s=beam_scene(2000);s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        r=run(s,operations=[(500,{'op':'kill','actor':'A'}),(1000,{'op':'revive','actor':'A'})])
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(len(r['volume_instances']),1)
        self.assertTrue(r['volume_instances'][0]['active'])
        self.assertEqual(r['volume_instances'][0]['source_life_generation'],1)
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        later=[e for e in ledger.entries if e.begin>=1000 and e.contribution.source.actor=='A']
        self.assertTrue(later)
        self.assertTrue(all(e.contribution.source.life_generation==1 for e in later))

    def test_revived_recipient_inside_persistent_beam_gets_a_fresh_heat_track(self):
        s=beam_scene(2000);s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['encounter']['participants']['B']['initial_state']['hp']=1
        r=run(s,operations=[(1000,{'op':'revive'})])
        self.assertEqual(r['final_states']['B']['life_generation'],2)
        started=[e['effect'] for e in events(r,'heat_started') if e['effect']['target']=='B']
        self.assertEqual([e['target_life_generation'] for e in started],[1,2])
        self.assertEqual(D(started[1]['q_reference']),0)
        self.assertEqual(D(started[1]['reference_ms']),1000)
        self.assertEqual(started[1]['source_life_generation'],1)
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertAlmostEqual(ledger.amount(target='B'),1001-D(r['final_states']['B']['hp']),places=20)

    def test_fluid_heat_and_old_expiries_cannot_restore_the_previous_body_memory(self):
        s=coupled_scene(24000);s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        r=run(s,operations=[(20500,{'op':'kill'}),(22000,{'op':'revive','hp':8000})])
        self.assertTrue(events(r,'thermal_recovery_activated'))
        self.assertEqual(r['final_states']['B']['life_generation'],2)
        old=[e for e in r['effect_instances'] if e.get('target_life_generation')==1]
        self.assertTrue(old)
        self.assertTrue(all(e['status']=='ended' for e in old))
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertFalse(any(e.target=='B' and e.target_life_generation==1 and e.end>D(20500) for e in ledger.entries))
        self.assertTrue(all(e.target_life_generation in (1,2) for e in ledger.entries))

    def test_mature_shield_debt_survives_death_but_dead_time_supplies_no_work(self):
        s=scene(20800,(0,-20));s['action_selection']['A']['start_ms']=0
        s['encounter']['participants']['B']['initial_state']['shield']=1000
        profiles=deepcopy(PROFILES);profiles['1E2']['abilities']['1']['weapon_cooldown_ms']=100000
        r=run(s,profiles=profiles,operations=[(200,{'op':'kill'}),(20500,{'op':'revive'})])
        dead=events(r,'character_died','B')[0]['state'];restored=events(r,'life_restored','B')[0]['state']
        self.assertEqual(dead['shield'],restored['shield'])
        self.assertLess(D(restored['shield']),1000)
        self.assertAlmostEqual(D(r['metrics']['B']['shield_regenerated']),120,places=20)
        self.assertAlmostEqual(D(r['final_states']['B']['shield'])-D(restored['shield']),120,places=20)
        self.assertTrue(all(loss['target_life_generation']==1 for loss in r['shield_loss_history']))

    def test_restoration_in_a_live_pause_field_rebinds_pauses_until_its_actual_expiry(self):
        r=run(marking_scene(5000),operations=[(300,{'op':'kill'}),(1000,{'op':'revive'})])
        restored=events(r,'life_restored','B')[0]['state']['cooldown_clocks']['1']
        self.assertEqual(restored['pause_sources'],['pause-volume:1'])
        self.assertEqual(D(restored['remaining_work_ms']),271)
        self.assertIsNone(restored['ready_at_ms'])
        self.assertEqual([D(e['time_ms']) for e in events(r,'projectile_released','B')],[111,4511,4911])

    def test_expired_pause_source_does_not_trap_the_new_life(self):
        r=run(marking_scene(5000),operations=[(300,{'op':'kill'}),(4500,{'op':'revive'})])
        restored=events(r,'life_restored','B')[0]['state']['cooldown_clocks']['1']
        self.assertEqual(restored['pause_sources'],[])
        self.assertEqual(D(restored['ready_at_ms']),4771)
        self.assertEqual([D(e['time_ms']) for e in events(r,'projectile_released','B')],[111,4811])

    def test_released_projectile_and_copy_retain_old_source_after_owner_restoration(self):
        s=scene(600,(0,-20));s['action_selection']['A']['start_ms']=0
        s['encounter']['participants']['B']['position_m']=[240,-20]
        ops=[(150,{'op':'kill','actor':'A'}),(200,{'op':'revive','actor':'A'}),
             (250,{'op':'copy','actor':'A'})]
        r=run(s,operations=ops)
        old=[f for f in r['projectile_flights'] if f['source_life_generation']==1]
        self.assertEqual(len(old),2)
        self.assertTrue(all(f['status']=='collided' for f in old))
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertGreater(ledger.amount(actor='A',source_life_generation=1),0)
        self.assertEqual(r['final_states']['A']['life_generation'],2)

    def test_existing_qard_mark_hits_the_revived_life_with_original_release_power(self):
        s=scene(1400,(0,-20));s['action_selection']['A'].update(start_ms=0,reload_when_empty=False)
        s['encounter']['participants']['A']['character']='1E1'
        s['encounter']['participants']['B']['initial_state']['hp']=1
        baseline=run(s);death=D(events(baseline,'character_died','B')[0]['time_ms'])
        r=run(s,operations=[(death+100,{'op':'revive'})])
        blast=next(e for e in events(r,'impact_batch_resolved') if e['target']=='B'
                   and e['hits'][0]['component']=='delayed_blast')
        self.assertEqual(blast['hits'][0]['target_life_generation'],2)
        self.assertEqual(blast['hits'][0]['source_life_generation'],1)
        self.assertEqual(D(blast['hits'][0]['incoming']),445)
        self.assertEqual(r['final_states']['B']['life_generation'],2)

    def test_second_real_death_advances_generation_and_rejects_first_life_retries(self):
        ops=[(300,{'op':'revive','hp':1}),(800,{'op':'revive','generation':2}),
             (900,{'op':'revive','generation':1})]
        r=run(duel(1000),operations=ops)
        self.assertEqual([e['success'] for e in events(r,'fixture_life_restoration')],[True,True,False])
        self.assertEqual([e['generation'] for e in r['actor_lives']['B']],[1,2,3])
        self.assertEqual(len(events(r,'character_died','B')),2)
        self.assertEqual(r['final_states']['B']['life_generation'],3)

    def test_unknown_life_mode_and_missing_history_reject_before_execution(self):
        rules=deepcopy(CURRENT);rules['life_cycles']={'mode':'unknown'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'Actor lives'):run(duel(),effects=rules)
        rules=deepcopy(CURRENT);rules.pop('damage_ledger')
        with self.assertRaisesRegex(UnsupportedMechanicError,'Actor lives'):run(duel(),effects=rules)

    def test_birth_immunity_ends_with_its_owner_life_and_cannot_cover_the_restored_body(self):
        for owner in ('consume_after_separation','impact_after_separation'):
            with self.subTest(owner=owner):
                s=scene(400,(0,-20));s['scope']=dict(MOBILE_SCOPE);s['action_selection']['A']['start_ms']=0
                profiles=one_shot_profiles(speed='.1',acceleration=0,owner=owner,inside=True)
                r=run(s,profiles=profiles,operations=[(200,{'op':'kill','actor':'A'}),
                    (250,{'op':'revive','actor':'A'})])
                flight=r['projectile_flights'][0]
                self.assertIsNotNone(flight['owner_cleared_at_ms'])
                self.assertEqual(D(flight['owner_cleared_at_ms']),200)
                self.assertEqual(D(flight['collided_at_ms']),250)
                self.assertEqual(flight['collision_target_life_generation'],2)
                self.assertEqual(flight['source_life_generation'],1)
                self.assertEqual(flight['status'],'consumed' if owner.startswith('consume') else 'collided')
                if owner.startswith('impact'):
                    self.assertLess(D(r['final_states']['A']['hp']),1000)
                    self.assertEqual(D(r['damage_credit_totals']['A']['eligible_hp_dealt']),0)

    def test_copy_born_inside_a_later_owner_life_gets_no_old_life_birth_immunity(self):
        s=scene(400,(0,-20));s['scope']=dict(MOBILE_SCOPE);s['action_selection']['A']['start_ms']=0
        profiles=one_shot_profiles(owner='consume_after_separation')
        r=run(s,profiles=profiles,operations=[(150,{'op':'kill','actor':'A'}),
            (200,{'op':'revive','actor':'A'}),(250,{'op':'copy','actor':'A','at_owner':True})])
        child=next(f for f in r['projectile_flights'] if f['parent_projectile_id'] is not None)
        self.assertEqual(child['source_life_generation'],1)
        self.assertEqual(D(child['owner_cleared_at_ms']),250)
        self.assertEqual(child['status'],'consumed')
        self.assertEqual(child['collision_target_life_generation'],2)


if __name__=='__main__':unittest.main()
