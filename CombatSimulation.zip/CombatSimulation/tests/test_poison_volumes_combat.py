"""Labelled released-gas API probes on the actual shared combat timeline.

No test claims that the separate launcher controller already exists. Ordinary
movement, attacks, defenses and life transitions remain the shared engine's.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.effect_models import EffectSource
from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.spatial_transitions import SpatialChange
from tests.test_binding_combat import run as shared_run
from tests.test_equilibrium_combat import scene as base_scene,rules
from tests.test_mobile_combat import PROFILES,command,events
from tests.test_world_colliders_combat import wall
from tests.test_impact_bindings_combat import add


def scene(horizon=4000,*,shield=0,target_character='1E2'):
    s=base_scene(horizon,character='1E1');s['id']='released_poison_volume_api'
    s['encounter']['participants']['B']['character']=target_character
    s['encounter']['participants']['B']['initial_state']['shield']=shield
    return s


def deploy(w,*,centre=(30,-20,'.875'),radius=5,toxicity=1200,duration=1000,actor='A',action_id=999,life=1):
    return w.poison_volumes.deploy(EffectSource(actor,'Ultimate',action_id,'gas-probe:'+str(action_id),life),
        centre,radius_m=radius,toxicity=toxicity,duration_ms=duration)


def run(s,*,operations=(),**kw):
    return shared_run(s,rules=rules(),operations=operations,**kw)


def move(target,dy):
    def operation(w):
        ref=w.spatial_transitions.reference(target)
        w.spatial_transitions.commit(w.spatial_transitions.prepare_transport((SpatialChange(target,
            w.fighters[target].life_generation,reference_m=(ref[0],ref[1]+D(dy),ref[2])),),source='gas_geometry_api_probe'))
    return operation


def coefficient(character='1E2',toxicity=1200,shield=0):
    p=PROFILES[character];rt=D(p['resistances']['toxin'])+dec(p.get('shield_toxin_resistance_per_hp',0))*shield
    tp=D(toxicity)
    return max(D(0),(tp*tp-10*rt*rt)/tp) if tp else D(0)


def zero_tie_operations():
    performed=[False]
    def early(w):
        if performed[0]:return
        performed[0]=True;move('B',-10)(w);w.poison_volumes.settle()
        w.log('poison_zero_tie_probe',exposure_count=len(w.poison_volumes.effects))
    def setup(w):
        deploy(w,duration=2000)
        # A due phase may reconcile membership before the queued zero timer.
        w.push(1000,'fixture_binding',{'operation':1},priority=0)
    return ((0,setup),(1000,early),(500,move('B',10)))


def revival_scene():
    s=scene(2800,target_character='2E4');s['encounter']['participants']['B']['initial_state']['hp']=300
    add(s,'C',['28.9',-20],character='1E2',team='A')
    s['encounter']['participants']['C']['initial_state']['hp']=500
    s['action_selection']['B'].update(abilities=['1'],start_ms=0,reload_when_empty=False)
    return s


def beam_gas_reference(r):
    """Independent scalar quadrature of known no-break shield/beam physics.

    Shield = 4000 - 600*(t-beam_start)^(3/2); RT = 44 + shield/100.
    Substitute sqrt(q)=x separately in exposure and residual to regularize the
    endpoints. This reference does not use the engine's RK or dose curves.
    """
    start=D(events(r,'beam_deployed')[0]['time_ms'])/1000
    def c(t):
        h=max(D(0),t-start);shield=4000-600*h*h.sqrt();rt=44+shield/100
        return max(D(0),(D(300)**2-10*rt*rt)/300)
    def integral(f,a,b):
        fa,fm,fb=f(a),f((a+b)/2),f(b);whole=(b-a)*(fa+4*fm+fb)/6
        def step(a,b,fa,fm,fb,whole,tol,depth):
            m=(a+b)/2;fl,fr=f((a+m)/2),f((m+b)/2)
            left=(m-a)*(fa+4*fl+fm)/6;right=(b-m)*(fm+4*fr+fb)/6;delta=left+right-whole
            if not depth or abs(delta)<=15*tol:return left+right+delta/15
            return step(a,m,fa,fl,fm,left,tol/2,depth-1)+step(m,b,fm,fr,fb,right,tol/2,depth-1)
        return step(a,b,fa,fm,fb,whole,D('1e-12'),30)
    exposed=lambda x:2*x*x*c(x*x)
    residual=lambda x:2*x*x*c(2-x*x)
    cut=start.sqrt()
    return integral(exposed,D(0),cut)+integral(exposed,cut,D(1))+integral(residual,D(0),D(1))


class PoisonVolumeCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=70));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        heals=HealingHistory.from_run(r) if 'healing_history' in r else None
        for n,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+(heals.amount(actor=n) if heals else 0)
            self.assertLess(abs(supplied-D(r['final_states'][n]['hp'])-ledger.amount(target=n)),D('1e-8'))
        return ledger

    def test_constant_exposure_then_residual_matches_primary_analytic_integral(self):
        r=run(scene(),operations=((0,deploy),));expected=4*coefficient()/3
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),expected,places=35)
        exposure=r['poison_exposures'][0]
        self.assertEqual(exposure['status'],'ended');self.assertEqual(D(exposure['ended_at_ms']),2000)
        self.assertEqual([D(e['time_ms']) for e in events(r,'poison_volume_expired')],[1000])
        self.assertEqual(exposure['source_life_generation'],1);self.conserved(r)

    def test_gas_bypasses_personal_shield_without_armor_loss_or_extra_statuses(self):
        r=run(scene(shield=4000),operations=((0,deploy),));f=r['final_states']['B']
        self.assertEqual(D(f['shield']),4000);self.assertEqual(D(f['armor']),150)
        self.assertEqual(D(f['disorientation']),0);self.assertEqual(D(f['instability']),0)
        self.assertEqual(D(r['metrics']['B']['shield_damage_received']),0)
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(f['hp']),4*coefficient()/3,places=35)
        self.conserved(r)

    def test_two_independent_clouds_add_without_sharing_memory(self):
        r=run(scene(),operations=((0,deploy),(0,lambda w:deploy(w,action_id=1000))))
        self.assertEqual(len(r['poison_volumes']),2);self.assertEqual(len(r['poison_exposures']),2)
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),8*coefficient()/3,places=35)
        self.assertEqual({e['action_id'] for e in r['poison_exposures']},{999,1000});self.conserved(r)

    def test_friendly_and_self_exposure_have_no_enemy_damage_credit(self):
        s=scene();s['encounter']['participants']['B'].update(position_m=[3,-20],team='A')
        r=run(s,operations=((0,lambda w:deploy(w,centre=(0,-20,'.875'))),))
        self.assertEqual({e['target'] for e in r['poison_exposures']},{'A','B'})
        ledger=self.conserved(r);self.assertGreater(ledger.amount(actor='A'),0)
        self.assertEqual(ledger.amount(actor='A',eligible_only=True),0)

    def test_ordinary_walking_exit_preserves_the_actual_exposure_residual(self):
        s=scene();s['encounter']['participants']['B']['movement_direction']=[0,1];command(s,'B',0,'walk')
        r=run(s,operations=((0,lambda w:deploy(w,radius=1,duration=3000)),))
        left=events(r,'poison_exposure_left')[0];t=D(left['time_ms'])/1000
        self.assertGreater(t,0);self.assertLess(t,2)
        self.assertAlmostEqual(D(r['poison_exposures'][0]['ended_at_ms']),2*D(left['time_ms']),places=25)
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),4*coefficient()*t*t.sqrt()/3,places=25)
        self.conserved(r)

    def test_reentry_before_zero_resumes_one_net_load_and_invalidates_old_timer(self):
        r=run(scene(),operations=((0,deploy),(500,move('B',10)),(750,move('B',-10))))
        enters=events(r,'poison_exposure_entered');self.assertEqual(len(enters),2)
        self.assertEqual(enters[0]['effect_id'],enters[1]['effect_id']);self.assertEqual(D(enters[1]['q_seconds']),D('.25'))
        self.assertEqual(len(r['poison_exposures']),1);self.assertEqual(D(r['poison_exposures'][0]['ended_at_ms']),1500)
        expected=D(2)/3*coefficient()*(4*D('.5')**D('1.5')-2*D('.25')**D('1.5'))
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),expected,places=35)
        self.conserved(r)

    def test_reentry_after_zero_starts_a_fresh_episode(self):
        r=run(scene(),operations=((0,lambda w:deploy(w,duration=2000)),(500,move('B',10)),(1250,move('B',-10))))
        self.assertEqual(len(r['poison_exposures']),2)
        self.assertEqual([D(e['q_seconds']) for e in events(r,'poison_exposure_entered')],[0,0])
        self.assertEqual([D(e['ended_at_ms']) for e in r['poison_exposures']],[1000,2750])
        expected=D(4)/3*coefficient()*(D('.5')**D('1.5')+D('.75')**D('1.5'))
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),expected,places=35)
        self.conserved(r)

    def test_zero_released_toxicity_and_full_resistance_still_keep_correct_clocks(self):
        for power in (0,10):
            r=run(scene(),operations=((0,lambda w,p=power:deploy(w,toxicity=p)),))
            self.assertEqual(D(r['final_states']['B']['hp']),8140)
            self.assertEqual(D(r['poison_exposures'][0]['ended_at_ms']),2000);self.conserved(r)

    def test_solid_cover_and_destructible_material_do_not_absorb_gas(self):
        s=scene();s['initial_colliders']=[wall('roof',x=30,z=2,size=(4,4,'.2'),hp=2000,
            blocking={'projectiles':True,'bodies':True,'areas':True})]
        r=run(s,operations=((0,deploy),));self.assertEqual(D(r['world_collider_states']['roof']['hp']),2000)
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),4*coefficient()/3,places=35)
        self.assertTrue(all(e['target']=='B' for e in r['poison_exposures']));self.conserved(r)

    def test_current_crouch_geometry_can_leave_a_small_high_cloud(self):
        s=scene(1000);command(s,'B',0,'crouch')
        r=run(s,operations=((0,lambda w:deploy(w,centre=(30,-20,'1.8'),radius='.2',duration=700)),))
        left=events(r,'poison_exposure_left')[0]
        self.assertGreater(D(left['time_ms']),0);self.assertLess(D(left['time_ms']),150)
        self.assertEqual(r['metrics']['B']['crouches_completed'],1);self.conserved(r)

    def test_native_jump_leaves_and_reenters_without_reusing_spent_residual(self):
        s=scene(1500);command(s,'B',0,'jump')
        r=run(s,operations=((0,lambda w:deploy(w,centre=(30,-20,'.1'),radius='.2',duration=1000)),))
        self.assertGreaterEqual(len(events(r,'poison_exposure_entered')),2)
        self.assertGreaterEqual(len(r['poison_exposures']),2)
        self.assertTrue(events(r,'jump_landed','B'));self.conserved(r)

    def test_real_gun_kills_source_but_released_cloud_keeps_its_original_life(self):
        s=scene(3000);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=0
        r=run(s,operations=((0,lambda w:deploy(w,duration=2000)),))
        self.assertFalse(r['final_states']['A']['alive']);death=D(events(r,'character_died','A')[0]['time_ms'])
        self.assertTrue(any(D(e['interval_start_ms'])>=death and e['target']=='B'
            for e in events(r,'continuous_damage_resolved')))
        self.assertEqual(r['poison_volumes'][0]['source_life_generation'],1);self.conserved(r)

    def test_recipient_death_retires_toxin_at_the_exact_hp_boundary(self):
        s=scene(1500);s['encounter']['participants']['B']['initial_state']['hp']=100
        r=run(s,operations=((0,lambda w:deploy(w,duration=8000)),))
        expected=(D(150)/coefficient())**(D(2)/3)*1000
        self.assertAlmostEqual(D(events(r,'character_died','B')[0]['time_ms']),expected,places=22)
        self.assertEqual(r['poison_exposures'][0]['end_reason'],'target_life_ended')
        self.assertTrue(r['poison_volumes'][0]['active']);self.assertEqual(self.conserved(r).amount(target='B'),100)

    def test_restored_recipient_inside_a_surviving_cloud_gets_fresh_zero_load(self):
        s=scene(1500);s['encounter']['participants']['B']['initial_state']['hp']=100
        def restore(w):self.assertTrue(w.life_cycles.revive('B',expected_generation=1,hp=1000,source='gas_life_api_probe'))
        r=run(s,operations=((0,lambda w:deploy(w,duration=2000)),(1000,restore)))
        self.assertEqual(len(r['actor_lives']['B']),2)
        self.assertEqual([e['target_life_generation'] for e in r['poison_exposures']],[1,2])
        fresh=events(r,'poison_exposure_started')[1]
        self.assertEqual(D(fresh['time_ms']),1000);self.assertEqual(D(fresh['effect']['q_seconds']),0)
        self.conserved(r)

    def test_explicit_2e4_shield_stock_bonus_remains_a_live_toxin_defense(self):
        r=run(scene(target_character='2E4',shield=4000),operations=((0,deploy),))
        expected=D(4)/3*coefficient('2E4',shield=4000)
        self.assertLess(abs(D(PROFILES['2E4']['max_hp'])-D(r['final_states']['B']['hp'])-expected),D('1e-8'))
        self.assertEqual(D(r['final_states']['B']['shield']),4000);self.conserved(r)

    def test_actual_beam_reduces_shield_resistance_and_increases_gas_hp_dose(self):
        s=scene(2000,target_character='2E4',shield=4000)
        control=run(s,operations=((0,lambda w:deploy(w,toxicity=300)),))
        s['action_selection']['A'].update(abilities=['4'],start_ms=0,reload_when_empty=False)
        r=run(s,operations=((0,lambda w:deploy(w,toxicity=300)),))
        dose=lambda x:sum((D(p['amount']) for e in events(x,'continuous_damage_resolved')
            if e['target']=='B' for p in e['components'] if p['kind']=='poison'),D(0))
        self.assertTrue(events(r,'beam_deployed'));self.assertGreater(dose(r),dose(control))
        self.assertLess(D(r['final_states']['B']['shield']),4000);self.conserved(r)

    def test_horizon_creation_starts_zero_load_without_past_damage(self):
        r=run(scene(1000),operations=((1000,deploy),))
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(D(r['poison_exposures'][0]['q_seconds']),0)
        self.assertTrue(r['poison_volumes'][0]['active']);self.assertTrue(r['pending_effects']);self.conserved(r)

    def test_invalid_release_rejects_before_consuming_identity_or_mutating_world(self):
        def check(w):
            source=EffectSource('A','Ultimate',999,life_generation=1)
            for kw in ({'radius_m':0},{'toxicity':-1},{'duration_ms':0},{'centre':(0,0,'NaN')},
                    {'source':EffectSource('A','Ultimate',999,life_generation=2)},
                    {'source':EffectSource('A','unknown',999,life_generation=1)}):
                args=dict(source=source,centre=(30,-20,'.875'),radius_m=5,toxicity=1200,duration_ms=1000);args.update(kw)
                queued=len(w.queue)
                with self.assertRaises(ValueError):w.poison_volumes.deploy(**args)
                self.assertFalse(w.poison_volumes.volumes);self.assertEqual(len(w.queue),queued)
            self.assertEqual(deploy(w),'poison-volume:1')
        r=run(scene(),operations=((0,check),));self.assertEqual(len(r['poison_volumes']),1)

    def test_unselected_feature_cannot_silently_create_a_volume(self):
        cfg=rules();cfg.pop('poison_volumes')
        with self.assertRaises(UnsupportedMechanicError):shared_run(scene(),rules=cfg,operations=((0,deploy),))

    def test_observation_precision_participant_order_and_ambient_context_preserve_outcomes(self):
        s=scene(2500);a=run(s,operations=((0,deploy),),interval=100)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        with localcontext(Context(prec=28)):b=run(s,operations=((0,deploy),),interval=17,precision=80)
        self.assertLess(abs(D(a['final_states']['B']['hp'])-D(b['final_states']['B']['hp'])),D('1e-8'))
        self.assertEqual(a['poison_exposures'],b['poison_exposures']);self.conserved(a);self.conserved(b)

    def test_reentry_exactly_at_zero_starts_new_episode_before_old_timer_dispatch(self):
        r=run(scene(3000),operations=zero_tie_operations())
        self.assertEqual(events(r,'poison_zero_tie_probe')[0]['exposure_count'],2)
        self.assertEqual(len(r['poison_exposures']),2)
        self.assertEqual([D(e['time_ms']) for e in events(r,'poison_exposure_entered')],[0,1000])
        self.assertEqual([D(e['q_seconds']) for e in events(r,'poison_exposure_entered')],[0,0]);self.conserved(r)

    def test_restored_source_does_not_replace_a_released_clouds_original_life(self):
        s=scene(1800);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=0
        def restore(w):self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='gas_source_life_api_probe'))
        r=run(s,operations=((0,lambda w:deploy(w,duration=2000)),(1000,restore)))
        self.assertEqual(len(r['actor_lives']['A']),2)
        self.assertEqual({e['source_life_generation'] for e in r['poison_exposures']},{1})
        self.assertEqual(r['poison_volumes'][0]['source_life_generation'],1);self.conserved(r)

    def test_release_from_an_already_dead_known_source_life_is_valid(self):
        s=scene(1800);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=0
        def released(w):
            self.assertEqual(w.fighters['A'].hp,0);deploy(w)
        r=run(s,operations=((750,released),))
        self.assertEqual(D(r['poison_volumes'][0]['start_ms']),750)
        self.assertEqual(r['poison_volumes'][0]['source_life_generation'],1)
        self.assertLess(D(r['final_states']['B']['hp']),8140);self.conserved(r)

    def test_native_healing_delays_gas_death_and_earned_revival_acquires_fresh_toxin(self):
        s=revival_scene();ops=((0,lambda w:deploy(w,duration=3000)),)
        r=run(s,operations=ops);cfg=rules();cfg.pop('hp_recovery')
        control=shared_run(s,rules=cfg,operations=ops)
        death=D(events(r,'character_died','B')[0]['time_ms'])
        self.assertGreater(death,D(events(control,'character_died','B')[0]['time_ms'])+50)
        self.assertGreater(D(r['metrics']['B']['hp_healed']),0)
        restored=events(r,'life_restored','B')[0]
        self.assertEqual(D(restored['time_ms'])-death,2000)
        attempt=r['revival_attempts'][0];ledger=self.conserved(r)
        expected=ledger.amount(actor='B',end=death,window_ms=10000,eligible_only=True)
        self.assertLess(abs(D(attempt['restoration_hp'])-expected),D('1e-8'))
        self.assertEqual(r['revival_states']['B']['charges_remaining'],2)
        self.assertEqual([e['target_life_generation'] for e in r['poison_exposures'] if e['target']=='B'],[1,2])
        self.conserved(control)

    def test_different_casters_keep_independent_source_and_projectile_attribution(self):
        s=scene();add(s,'C',[0,-30],character='1E1',team='A')
        r=run(s,operations=((0,deploy),(0,lambda w:deploy(w,actor='C',action_id=1000))))
        self.assertEqual({e['actor'] for e in r['poison_exposures']},{'A','C'})
        self.assertEqual({e['projectile_id'] for e in r['poison_exposures']},{'gas-probe:999','gas-probe:1000'})
        ledger=self.conserved(r)
        self.assertAlmostEqual(ledger.amount(actor='A'),ledger.amount(actor='C'),places=35)

    def test_full_eight_second_volume_keeps_eight_seconds_of_residual_after_expiry(self):
        r=run(scene(17000),operations=((0,lambda w:deploy(w,duration=8000,toxicity=200)),))
        self.assertEqual([D(e['time_ms']) for e in events(r,'poison_volume_expired')],[8000])
        self.assertEqual(D(r['poison_exposures'][0]['ended_at_ms']),16000)
        self.assertAlmostEqual(D(PROFILES['1E2']['max_hp'])-D(r['final_states']['B']['hp']),
            D(4)/3*coefficient(toxicity=200)*8*D(8).sqrt(),places=35)
        self.assertFalse(r['poison_volumes'][0]['active']);self.conserved(r)

    def test_observation_horizon_preserves_unfinished_exposure_and_volume(self):
        r=run(scene(500),operations=((0,deploy),))
        self.assertTrue(r['poison_volumes'][0]['active'])
        self.assertEqual(r['poison_exposures'][0]['status'],'active')
        self.assertEqual(D(r['poison_exposures'][0]['q_seconds']),D('.5'))
        self.assertTrue(r['poison_exposures'][0]['exposed']);self.assertFalse(events(r,'poison_exposure_ended'))
        self.conserved(r)

    def test_unsupported_modes_and_missing_life_defense_dependencies_reject(self):
        for missing in ('life_cycles','shield_recovery'):
            cfg=rules();cfg.pop(missing)
            with self.subTest(missing=missing),self.assertRaises(UnsupportedMechanicError):shared_run(scene(),rules=cfg)
        cfg=rules();cfg['poison_volumes']={'mode':'unknown'}
        with self.assertRaises(UnsupportedMechanicError):shared_run(scene(),rules=cfg)

    def test_actual_beam_gas_dose_agrees_with_an_independent_scalar_quadrature(self):
        s=scene(2000,target_character='2E4',shield=4000)
        s['action_selection']['A'].update(abilities=['4'],start_ms=0,reload_when_empty=False)
        r=run(s,operations=((0,lambda w:deploy(w,toxicity=300)),))
        actual=D(PROFILES['2E4']['max_hp'])-D(r['final_states']['B']['hp'])
        self.assertLess(abs(actual-beam_gas_reference(r)),D('1e-8'))
        self.conserved(r)

    def test_native_delayed_shield_regeneration_changes_gas_resistance_continuously(self):
        s=scene(22000,target_character='2E4')
        # Explicitly supplied existing shield debt, then the native 20s delay
        # and 400 HP/s recovery. This is a labelled defense API probe.
        r=run(s,operations=((0,lambda w:w._record_shield_loss('B',D(4000))),
            (20000,lambda w:deploy(w,toxicity=300))))
        c0=D(300)-D(44)**2/30;c1=-D(352)/30;c2=-D(16)/30
        expected=(2*c0+2*c1+4*c2)*D(2)/3-4*c2*D(2)/5+2*c2*D(2)/7
        actual=D(PROFILES['2E4']['max_hp'])-D(r['final_states']['B']['hp'])
        self.assertLess(abs(actual-expected),D('1e-8'))
        self.assertEqual(D(r['final_states']['B']['shield']),800);self.conserved(r)


if __name__=='__main__':unittest.main()
