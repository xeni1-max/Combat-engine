"""Exact modifier composition and constrained simultaneous shield allocation."""
from dataclasses import FrozenInstanceError
from fractions import Fraction as F
import itertools
import unittest

from combat_sim.mechanics.attack_modifiers import ModifierValues
from combat_sim.mechanics.defense_layers import DefenseLayer,allocate_layers
from combat_sim.mechanics.shield import split_simultaneous_damage
from combat_sim.mechanics.simultaneous import DamagePacket,calculate_simultaneous_impacts


class ModifierValueTests(unittest.TestCase):
    def test_composition_adds_bonuses_and_multiplies_bleed(self):
        a=ModifierValues(80,20,4000,2);b=ModifierValues(10,3,200,3)
        self.assertEqual(a.combine(b),ModifierValues(90,23,4200,6))
        self.assertEqual(a.combine(ModifierValues()),a)
        with self.assertRaises(FrozenInstanceError):a.additional_piercing=0

    def test_invalid_values_reject(self):
        for key in ModifierValues().record():
            with self.subTest(key=key),self.assertRaises(ValueError):ModifierValues(**{key:-1})


class ShieldBypassTests(unittest.TestCase):
    def test_full_bypass_leaves_shield_stock_untouched(self):
        self.assertEqual(split_simultaneous_damage((440,),4000,shielding_ignored=(4000,)),((0,440),))

    def test_normal_packet_can_use_stock_skipped_by_another(self):
        self.assertEqual(split_simultaneous_damage((440,440),4000,shielding_ignored=(4000,0)),((0,440),(440,0)))

    def test_partial_bypass_caps_and_redistributes_proportional_share(self):
        self.assertEqual(split_simultaneous_damage((1000,1000),800,shielding_ignored=(0,500)),((500,500),(300,700)))
        self.assertEqual(split_simultaneous_damage((300,900),800,shielding_ignored=(700,0)),((100,200),(700,200)))

    def test_uncapped_weight_uses_raw_damage(self):
        self.assertEqual(split_simultaneous_damage((400,800,1200),600,shielding_ignored=(0,0,550)),
            ((F(550,3),F(650,3)),(F(1100,3),F(1300,3)),(50,1150)))

    def test_budgets_span_layers_and_only_intercepted_layers_spend_them(self):
        layers=(DefenseLayer('front',800,(0,)),DefenseLayer('regen',4000,(0,1)))
        a=allocate_layers((440,440),layers,shielding_ignored=(4000,4000))
        self.assertEqual(a.layer_shares,(('front',(0,0)),('regen',(440,0))))
        self.assertEqual(a.overflow,(0,440));self.assertEqual(a.bypass_remaining,(0,0))
        b=allocate_layers((440,),layers[:1],shielding_ignored=(5000,))
        self.assertEqual(b.bypass_remaining,(4200,));self.assertEqual(b.overflow,(440,))

    def test_permutations_conserve_packet_damage_and_shield_capacity(self):
        damage=(F(7,3),20,800,1200);bypass=(0,800,400,30)
        expected=split_simultaneous_damage(damage,800,shielding_ignored=bypass)
        for order in itertools.permutations(range(4)):
            result=split_simultaneous_damage((damage[i] for i in order),800,shielding_ignored=(bypass[i] for i in order))
            self.assertEqual(result,tuple(expected[i] for i in order))
            self.assertLessEqual(sum(s for s,_ in result),800)
            for i,(s,left) in zip(order,result):
                self.assertEqual(s+left,damage[i]);self.assertLessEqual(s,max(0,800-bypass[i]))

    def test_zero_and_unmodified_allocations_preserve_existing_contract(self):
        for raw in ((),(0,0),(100,200),(1800,900)):
            for stock in (0,800,4000):
                self.assertEqual(split_simultaneous_damage(raw,stock),
                    split_simultaneous_damage(raw,stock,shielding_ignored=(0,)*len(raw)))

    def test_invalid_budget_length_or_sign_rejects(self):
        for b in ((),(-1,),(0,0)):
            with self.subTest(b=b),self.assertRaises(ValueError):
                split_simultaneous_damage((1,),800,shielding_ignored=b)
            with self.assertRaises(ValueError):allocate_layers((1,),(),shielding_ignored=b)

    def test_extra_armor_loss_does_not_change_same_batch_hp_or_piercing(self):
        base,extra=calculate_simultaneous_impacts((DamagePacket('slash',440,40),
            DamagePacket('slash',440,40,0,20)),165,0,0)
        self.assertEqual(base.hp_damage,extra.hp_damage)
        self.assertEqual(extra.armor_loss,base.armor_loss+20)
        full=calculate_simultaneous_impacts((DamagePacket('slash',440,40,0,20),),165,4000,0)[0]
        self.assertEqual((full.hp_damage,full.armor_loss),(0,0))

    def test_bypass_does_not_change_raw_damage_or_create_armor_loss_at_zero_power(self):
        hit=calculate_simultaneous_impacts((DamagePacket('slash',0,40,4000,20),),165,4000,0)[0]
        self.assertEqual((hit.incoming_damage,hit.shield_absorbed,hit.hp_damage,hit.armor_loss),(0,0,0,0))


if __name__=='__main__':unittest.main()
