"""Continuous 3D sphere membership of translating and deforming body parts."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.volume_geometry import sphere_cells


def part(centre,size=(1,1,1),velocity=(0,0,0),acceleration=(0,0,0),rate=(0,0,0),size_acceleration=None):
    row=(Cuboid('part',centre,size),velocity,acceleration,rate)
    return row if size_acceleration is None else (*row,size_acceleration)


class SphericalVolumeGeometryTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=70));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_linear_pass_has_exact_face_entry_and_exit(self):
        cells=sphere_cells((0,0,0),1,[part((-3,0,0),velocity=(1,0,0))],6)
        self.assertEqual([v for _,v in cells],[False,True,False])
        for (actual,_),expected in zip(cells,(0,D('1.5'),D('4.5'))):
            self.assertAlmostEqual(actual,expected,places=38)

    def test_vertical_pass_uses_z_instead_of_an_infinite_column(self):
        cells=sphere_cells((0,0,0),1,[part((0,0,-3),velocity=(0,0,1))],6)
        self.assertEqual([v for _,v in cells],[False,True,False])
        self.assertAlmostEqual(cells[1][0],D('1.5'),places=38)

    def test_acceleration_enters_and_leaves_when_both_endpoints_are_outside(self):
        cells=sphere_cells((0,0,0),'.5',[part((-2,0,0),size=('.2',)*3,velocity=(4,0,0),acceleration=(-4,0,0))],2)
        self.assertEqual([v for _,v in cells],[False,True,False])
        self.assertAlmostEqual(cells[1][0],1-D('.3').sqrt(),places=38)
        self.assertAlmostEqual(cells[2][0],1+D('.3').sqrt(),places=38)

    def test_diagonal_corner_uses_euclidean_distance(self):
        self.assertEqual(sphere_cells((0,0,0),1,[part((1,1,1),size=('.2',)*3)],1),[(D(0),False)])
        self.assertEqual(sphere_cells((0,0,0),2,[part((1,1,1),size=('.2',)*3)],1),[(D(0),True)])

    def test_multiple_overlapping_parts_remain_one_union_membership(self):
        p=part((-3,0,0),velocity=(1,0,0))
        self.assertEqual(sphere_cells((0,0,0),1,[p,p],6),sphere_cells((0,0,0),1,[p],6))

    def test_isolated_tangent_does_not_create_an_exposure_interval(self):
        p=part((0,'2.1',0),size=('.2',)*3,velocity=(0,-2,0),acceleration=(0,2,0))
        self.assertEqual(sphere_cells((0,0,0),1,[p],2),[(D(0),False)])

    def test_persistent_tangent_is_a_positive_duration_contact(self):
        self.assertEqual(sphere_cells((0,0,0),1,[part((0,'1.1',0),size=('.2',)*3)],2),[(D(0),True)])

    def test_linear_part_expansion_can_create_contact_without_translation(self):
        cells=sphere_cells((0,0,0),'.5',[part((0,0,'1.5'),rate=(0,0,2))],1)
        self.assertEqual([v for _,v in cells],[False,True])
        self.assertAlmostEqual(cells[1][0],D('.5'),places=38)

    def test_accelerating_size_and_centre_with_fixed_bottom_do_not_fake_entry(self):
        p=part((0,0,2),size=(1,1,2),acceleration=(0,0,1),size_acceleration=(0,0,2))
        self.assertEqual(sphere_cells((0,0,0),'.5',[p],3),[(D(0),False)])

    def test_empty_union_and_zero_duration_are_well_defined(self):
        self.assertEqual(sphere_cells((0,0,0),1,[],3),[(D(0),False)])
        self.assertEqual(sphere_cells((0,0,0),1,[part((0,0,0))],0),[(D(0),True)])

    def test_invalid_geometry_and_nonpositive_size_trajectory_reject(self):
        for centre,radius,duration,precision in (((0,0),1,1,50),((0,0,0),0,1,50),
                ((0,0,0),1,-1,50),((0,0,0),True,1,50),((0,0,0),'NaN',1,50),
                ((0,0,'Infinity'),1,1,50),((0,0,0),1,1,28)):
            with self.subTest(values=(centre,radius,duration,precision)),self.assertRaises(ValueError):
                sphere_cells(centre,radius,[part((0,0,0))],duration,precision=precision)
        with self.assertRaises(ValueError):sphere_cells((0,0,0),1,[part((0,0,0),rate=(0,0,-2))],1)

    def test_precision_and_iterable_centre_preserve_the_same_cells(self):
        p=part((-3,0,0),velocity=(1,0,0))
        a=sphere_cells((0,0,0),1,[p],6)
        b=sphere_cells(iter((0,0,0)),1,[p],6,precision=80)
        self.assertEqual([v for _,v in a],[v for _,v in b])
        for (x,_),(y,_) in zip(a,b):self.assertAlmostEqual(x,y,places=38)


if __name__=='__main__':unittest.main()
