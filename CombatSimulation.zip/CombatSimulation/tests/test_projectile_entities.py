"""Entity identity/lifecycle invariants and whole-owner clearance geometry."""
from decimal import Decimal as D
from math import sqrt
from types import SimpleNamespace
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.models import UnsupportedMechanicError
from combat_sim.projectile_clearance import first_owner_separation
from combat_sim.projectile_entities import ProjectileContactPolicy, ProjectileRegistry


def create(registry,action=7,*,parent=None,policy=None,**extra):
    return registry.create(action_id=action,owner='A',ability='1',created_at_ms=100,
        kinematics={'status':'in_flight',**extra},parent=parent,policy=policy)


class ProjectileEntityTests(unittest.TestCase):
    def test_many_projectiles_have_independent_ids_with_one_parent_action(self):
        registry=ProjectileRegistry({'trace_schema':'entity_v1'})
        first,second=create(registry),create(registry)
        self.assertNotEqual(first['id'],second['id'])
        self.assertEqual(first['action_id'],second['action_id'])
        self.assertTrue(first['id'].startswith('projectile:'))
        self.assertEqual(len(registry.flights),2)
        self.assertEqual(registry.link(first)['action_id'],7)

    def test_identity_is_immutable_and_copies_retain_attribution(self):
        registry=ProjectileRegistry()
        first=create(registry)
        child=create(registry,parent=first['id'])
        self.assertEqual(child['parent_projectile_id'],first['id'])
        self.assertEqual(child['root_projectile_id'],first['id'])
        with self.assertRaises(AttributeError):
            registry.identities[first['id']].owner='B'
        with self.assertRaisesRegex(ValueError,'attribution'):
            registry.create(action_id=7,owner='B',ability='1',created_at_ms=100,
                kinematics={'status':'in_flight'},parent=first['id'])
        self.assertEqual(len(registry.flights),2)

    def test_terminal_transition_invalidates_predictions_and_is_idempotent(self):
        registry=ProjectileRegistry()
        shot=create(registry)
        payload=registry.link(shot)
        self.assertTrue(registry.live(payload))
        self.assertTrue(registry.terminal(shot,'collided'))
        self.assertFalse(registry.live(payload))
        self.assertFalse(registry.terminal(shot,'stopped'))
        self.assertEqual(shot['status'],'collided')
        self.assertEqual(shot['revision'],1)

    def test_duplicating_a_lineage_once_per_source_does_not_share_mutable_history(self):
        registry=ProjectileRegistry()
        first=create(registry)
        self.assertTrue(registry.claim_duplication(first['id'],'field:1'))
        child=create(registry,parent=first['id'])
        self.assertFalse(registry.claim_duplication(first['id'],'field:1'))
        self.assertFalse(registry.claim_duplication(child['id'],'field:1'))
        self.assertTrue(registry.claim_duplication(child['id'],'field:2'))
        self.assertEqual(first['duplication_sources'],['field:1'])
        self.assertEqual(child['duplication_sources'],['field:1','field:2'])

    def test_legacy_trace_projection_preserves_live_entity_state(self):
        registry=ProjectileRegistry()
        shot=create(registry)
        raw={'projectile_flights':[shot],'events':[registry.link(shot)],
            'unrelated_metadata':{'projectile_revision':99,'collision_response':'preserve'}}
        projected=registry.serialize(raw)
        self.assertEqual(projected['projectile_flights'],[{'id':7,'actor':'A','ability':'1','status':'in_flight'}])
        self.assertEqual(projected['events'],[{'actor':'A','ability':'1','action_id':7,'projectile_id':7}])
        self.assertEqual(raw['projectile_flights'][0]['id'],shot['id'])
        self.assertIn('revision',shot)
        self.assertEqual(projected['unrelated_metadata'],raw['unrelated_metadata'])

    def test_current_trace_exposes_independent_entity_metadata(self):
        registry=ProjectileRegistry({'trace_schema':'entity_v1'})
        shot=create(registry)
        self.assertEqual(registry.serialize(shot)['id'],'projectile:1')
        self.assertEqual(shot['contact_policy'],{'owner':'ignore','other_bodies':'impact','terrain':'impact'})

    def test_invalid_policy_identity_or_kinematic_overwrite_leaves_no_entity(self):
        registry=ProjectileRegistry()
        for policy in ({'owner':'ignore'},{'owner':'always','other_bodies':'impact','terrain':'impact'}):
            with self.assertRaises((ValueError,UnsupportedMechanicError)):
                ProjectileContactPolicy.from_definition(policy)
        for extra in ({'id':'forged'},{'revision':8},{'action_id':8}):
            with self.assertRaises(ValueError):create(registry,**extra)
        with self.assertRaises(ValueError):create(registry,action=True)
        with self.assertRaises(UnsupportedMechanicError):ProjectileRegistry({'trace_schema':'unknown'})
        self.assertEqual(registry.flights,{})


def path(position,*,radius=.02,acceleration=0):
    return SimpleNamespace(at=lambda t:SimpleNamespace(position_m=position(t)),
        gravity=acceleration,deceleration=0,radius_m=radius)


def box(name='torso',centre=(0,0,0),size=(.2,.2,.2),*,velocity=(0,0,0),acceleration=(0,0,0),rate=(0,0,0)):
    return Cuboid(name,centre,size),velocity,acceleration,rate


class OwnerSeparationTests(unittest.TestCase):
    def test_birth_outside_owner_is_immediately_eligible(self):
        result=first_owner_separation(path(lambda t:(1+t,0,0)),[box()],0,1)
        self.assertEqual((result.time_lower_s,result.time_upper_s),(0,0))

    def test_stationary_overlap_does_not_arm_on_observation(self):
        self.assertIsNone(first_owner_separation(path(lambda t:(0,0,0)),[box()],0,10))

    def test_exit_has_a_positive_clearance_witness(self):
        result=first_owner_separation(path(lambda t:(t,0,0)),[box()],0,1)
        self.assertLessEqual(result.time_lower_s,.12+1e-12)
        self.assertGreater(result.time_upper_s,.12)
        self.assertLessEqual(result.time_upper_s-result.time_lower_s,1e-12)

    def test_adjacent_parts_form_one_union_until_the_projectile_leaves_them_all(self):
        result=first_owner_separation(path(lambda t:(t,0,0)),[box(),box('arm',(.2,0,0))],0,1)
        self.assertAlmostEqual(result.time_upper_s,.32,places=10)

    def test_exit_and_reentry_between_endpoints_is_not_missed(self):
        result=first_owner_separation(path(lambda t:(4*t*(1-t),0,0),acceleration=8),[box()],0,1)
        expected=(1-sqrt(.88))/2
        self.assertAlmostEqual(result.time_upper_s,expected,places=10)
        self.assertLess(result.time_upper_s,.5)

    def test_owner_translation_does_not_end_immunity_while_the_sphere_stays_inside(self):
        self.assertIsNone(first_owner_separation(path(lambda t:(t,0,0)),[box(velocity=(1,0,0))],0,1))

    def test_shrinking_part_can_release_a_stationary_projectile(self):
        result=first_owner_separation(path(lambda t:(.05,0,0),radius=.01),
            [box(rate=(-.2,0,0))],0,1)
        self.assertAlmostEqual(result.time_upper_s,.6,places=10)

    def test_closed_tangency_is_not_whole_body_separation(self):
        result=first_owner_separation(path(lambda t:(.12,t,0)),[box(size=(.2,10,10))],0,1)
        self.assertIsNone(result)

    def test_rounded_corners_do_not_use_an_expanded_box_approximation(self):
        result=first_owner_separation(path(lambda t:(.115,.115,0)),[box()],0,1)
        self.assertEqual(result.time_upper_s,0)

    def test_invalid_interval_and_negative_dimensions_fail_explicitly(self):
        for begin,end in ((1,0),(-1,1),(0,float('inf')),(False,1)):
            with self.assertRaises(ValueError):
                first_owner_separation(path(lambda t:(0,0,0)),[box()],begin,end)
        with self.assertRaises(ValueError):
            first_owner_separation(path(lambda t:(0,0,0)),[box(rate=(-1,0,0))],0,1)
