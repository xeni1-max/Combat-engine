"""Actual 1E3 prison contacts on shared HP, physical geometry and life clocks.

Profile mutation, copies, typed object damage and imposed motion below are
explicit engineering probes; ordinary scenes cast only the six existing kits.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import json
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.enclosure import contains,penetrates
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from tests.test_binding_combat import run as configured_run
from tests.test_equilibrium_combat import scene as base_scene,run,rules
from tests.test_impact_bindings_combat import add
from tests.test_mobile_combat import command,events,PROFILES
from tests.test_world_colliders_combat import wall
from tests.test_grapple_links_combat import force,pos,vel
from tests.test_climb_combat import climb


def scene(duration=1800,distance=10):
    s=base_scene(duration,character='1E3');s['id']='authored_physical_prison'
    s['encounter']['participants']['B']['position_m']=[distance,-20]
    s['action_selection']['A'].update(abilities=['4'],start_ms=0,reload_when_empty=False)
    return s


def shots_scene(duration=3500):
    s=scene(duration);command(s,'B',600,'walk');s['action_selection']['B']['start_ms']=1000
    add(s,'C',[0,-22],team='A');s['action_selection']['C']['start_ms']=700
    return s


def held_scene(duration=2200):
    s=scene(duration);add(s,'C',['11.1',-20],character='1E5',team='A')
    s['action_selection']['C'].update(abilities=['2'],start_ms=0)
    return s


def revival_scene():
    s=scene(3200);s['encounter']['participants']['B'].update(character='2E4')
    s['encounter']['participants']['B']['initial_state']['hp']=100
    s['action_selection']['B'].update(abilities=['1'],start_ms=0,reload_when_empty=False)
    add(s,'C',['8.9','-19.55'],team='A');s['encounter']['participants']['C']['initial_state']['hp']=8140
    s['action_selection']['C'].update(abilities=['1'],start_ms=600,reload_when_empty=False)
    return s


def formed(r):return [x for x in r['contact_construct_hits'] if x['status']=='formed']
def cube(r,index=0):return r['world_collider_states'][formed(r)[index]['collider_id']]


class PrisonCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=70));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        json.dumps(r);damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for n,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=n)
            self.assertLess(abs(supplied-D(r['final_states'][n]['hp'])-damage.amount(target=n)),D('1e-8'))
        for row in formed(r):
            low=tuple(map(F,row['placement']['inner_min_m']));high=tuple(map(F,row['placement']['inner_max_m']))
            for name in row['placement']['occupants']:
                b=row['placement']['body_bounds'][name]
                self.assertTrue(contains((low,high),(tuple(map(F,b['minimum_m'])),tuple(map(F,b['maximum_m'])))))
            self.assertEqual(len(cube(r,formed(r).index(row))['parts']),6)
        return damage

    def test_authored_phases_cost_and_damage_free_contact_form_one_physical_cube(self):
        r=run(scene());self.assertEqual(self.conserved(r).amount(),0)
        self.assertEqual([D(e['time_ms']) for e in events(r,'projectile_released','A')],[320])
        self.assertEqual([D(e['time_ms']) for e in events(r,'self_status_applied','A')],[230])
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),4)
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['4']),9320)
        obj=cube(r);self.assertEqual((D(obj['hp']),D(obj['max_hp'])),(4000,4000))
        self.assertEqual(obj['blocking'],{'projectiles':True,'bodies':True,'areas':True})
        self.assertEqual(obj['tags'],['prison','wall']);self.assertFalse(obj['climbable'])
        self.assertEqual(obj['source_life_generation'],1);self.assertEqual(obj['owner'],'A')
        self.assertEqual(D(obj['expires_at_ms'])-D(formed(r)[0]['at_ms']),12000)
        self.assertFalse(r['binding_instances']);self.assertFalse(events(r,'block_layer_damage'))
        self.assertEqual(D(r['released_attack_power'][0]['components']['projectile']['output']),0)
        self.assertEqual(r['released_attack_power'][0]['category'],'intrinsic_momentary')

    def test_personal_shield_is_preserved_and_does_not_stop_formation(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['shield']=4000
        r=run(s);self.assertEqual(len(formed(r)),1);self.assertEqual(self.conserved(r).amount(),0)
        self.assertEqual(D(r['final_states']['B']['shield']),4000)

    def test_terrain_intercepts_carrier_without_a_cube_damage_or_counter(self):
        s=scene();s['initial_colliders']=[wall('interceptor',x=5,hp=2000)]
        r=run(s);self.assertEqual(self.conserved(r).amount(),0);self.assertFalse(formed(r))
        self.assertTrue(events(r,'construct_projectile_blocked'));self.assertEqual(D(r['world_collider_states']['interceptor']['hp']),2000)
        self.assertFalse(events(r,'world_collider_damaged'));self.assertFalse(events(r,'combat_reaction_released'))

    def test_independent_block_intercepts_without_stock_loss_or_counter(self):
        s=scene();s['encounter']['participants']['B']['character']='2E4'
        s['action_selection']['B'].update(abilities=['basic_8'],held_blocks=['basic_8'],start_ms=300)
        r=run(s);self.assertEqual(self.conserved(r).amount(),0);self.assertFalse(formed(r))
        self.assertTrue(events(r,'construct_projectile_blocked'));self.assertFalse(events(r,'block_layer_damage'))
        self.assertFalse(events(r,'combat_reaction_released'))

    def test_friendly_body_intercepts_and_is_enclosed_instead_of_selected_enemy(self):
        s=scene();add(s,'C',[5,-20],team='A');r=run(s);self.conserved(r)
        self.assertEqual(events(r,'projectile_body_collision','A')[0]['target'],'C')
        self.assertEqual(formed(r)[0]['placement']['occupants'],['C'])

    def test_moving_body_meets_real_material_without_an_intangible_freeze(self):
        s=scene();command(s,'B',600,'walk');r=run(s);self.conserved(r)
        self.assertTrue(events(r,'movement_active_started','B'));self.assertTrue(events(r,'body_contact'))
        self.assertGreater(D(r['final_states']['B']['position_m'][0]),D('9.1'))
        self.assertLess(D(r['final_states']['B']['position_m'][0]),10)
        self.assertFalse(r['binding_instances']);self.assertEqual(vel(r,'B')[0],0)

    def test_close_muzzles_on_both_sides_hit_the_same_pool_and_destroy_it(self):
        r=run(shots_scene());self.conserved(r);obj=cube(r);self.assertEqual(obj['status'],'destroyed')
        hits=[e for e in events(r,'world_collider_impact_batch') if e['collider_id']==obj['id']]
        self.assertEqual({p['actor'] for e in hits for p in e['hits']},{'B','C'})
        self.assertEqual(sum(D(e['applied_hp_damage']) for e in hits),4000)
        self.assertTrue([f for f in r['projectile_flights'] if f['actor']=='B' and 'origin_constraint' in f])
        before=D(obj['removed_at_ms'])
        self.assertFalse([e for e in events(r,'projectile_body_collision') if e['actor'] in ('B','C') and D(e['time_ms'])<before])
        self.assertTrue([e for e in events(r,'projectile_body_collision') if D(e['time_ms'])>before])
        self.assertTrue(all(not e['character_recovery_credit'] for e in events(r,'world_collider_damaged')))

    def test_actual_qard_contact_and_blast_damage_shell_without_reaching_occupant(self):
        s=scene(2200);add(s,'C',[0,-23],character='1E1',team='A');s['action_selection']['C']['start_ms']=700
        r=run(s);ledger=self.conserved(r);obj=cube(r)
        self.assertGreater(4000-D(obj['hp']),0);self.assertEqual(ledger.amount(target='B'),0)
        hits=[p for e in events(r,'world_collider_impact_batch') for p in e['hits']]
        self.assertEqual({p['component'] for p in hits},{'projectile','delayed_blast'})

    def test_actual_heat_hits_roof_while_protecting_enclosed_body(self):
        s=scene(3500);add(s,'C',[0,-23],character='1E1',team='A')
        s['action_selection']['C'].update(abilities=['4'],start_ms=700)
        r=run(s);ledger=self.conserved(r);self.assertEqual(ledger.amount(target='B'),0)
        self.assertLess(D(cube(r)['hp']),4000);self.assertEqual(cube(r)['status'],'active')
        self.assertTrue(events(r,'beam_deployed','C'))

    def test_prison_appearing_during_a_live_beam_stops_exposure_and_retains_body_heat(self):
        s=scene(2000);add(s,'C',[0,-23],character='1E1',team='A')
        s['action_selection']['C'].update(abilities=['4'],start_ms=0)
        r=run(s);ledger=self.conserved(r);at=D(formed(r)[0]['at_ms'])
        leave=next(e for e in events(r,'heat_exposure_left') if e['target']=='B')
        self.assertEqual(D(leave['time_ms']),at);self.assertGreater(ledger.amount(target='B'),0)
        self.assertLess(D(cube(r)['hp']),4000)
        self.assertTrue([e for e in r['effect_instances'] if e['target']=='B' and e['target_kind']=='actor'])

    def test_two_actual_beams_destroy_roof_and_expose_body_in_the_same_live_field(self):
        s=scene(4500)
        for name,xy in (('C',[0,-23]),('D',[-2,-20])):
            add(s,name,xy,character='1E1',team='A');s['action_selection'][name].update(abilities=['4'],start_ms=700)
        r=run(s);ledger=self.conserved(r);obj=cube(r);self.assertEqual(obj['status'],'destroyed')
        enter=next(e for e in events(r,'heat_exposure_entered') if e['target']=='B')
        self.assertEqual(D(enter['time_ms']),D(obj['removed_at_ms']));self.assertEqual(D(enter['q_seconds']),0)
        self.assertGreater(ledger.amount(target='B'),0)

    def test_ice_binding_keeps_its_selected_cover_transparent_policy_through_prison(self):
        s=scene(1800);add(s,'C',[0,-24],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['2'],start_ms=700)
        r=run(s);self.assertEqual(self.conserved(r).amount(target='B'),0)
        self.assertEqual([(b['target'],b['kind']) for b in r['binding_instances']],[('B','lower_body')])
        self.assertLess(D(cube(r)['hp']),4000)

    def test_marking_projectile_damages_material_without_marking_occupant(self):
        s=scene(1800);add(s,'C',[0,-24],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['1'],start_ms=700)
        r=run(s);self.assertEqual(self.conserved(r).amount(target='B'),0)
        self.assertFalse(r['binding_marks']);self.assertFalse(r['binding_instances'])
        self.assertLess(D(cube(r)['hp']),4000)

    def test_enclosed_character_can_cast_an_existing_remote_beam_outside_material(self):
        s=scene(2000);s['encounter']['participants']['B']['character']='1E1'
        s['action_selection']['B'].update(abilities=['4'],start_ms=700,reload_when_empty=False)
        r=run(s);ledger=self.conserved(r);self.assertTrue(events(r,'beam_deployed','B'))
        self.assertGreater(ledger.amount(target='A'),0);self.assertEqual(D(r['metrics']['B']['dyspnea_paid']),0)
        self.assertEqual(D(cube(r)['hp']),4000)

    def test_pause_field_affects_weapon_work_without_refreshing_construct_lifetime(self):
        s=scene(5500);s['action_selection']['B'].update(abilities=['2'],start_ms=700,reload_when_empty=False)
        r=run(s);self.conserved(r);self.assertEqual(len(r['cooldown_pause_volumes']),1)
        self.assertGreater(D(r['final_states']['A']['ability_ready_at_ms']['4']),9320)
        self.assertEqual(D(cube(r)['expires_at_ms'])-D(formed(r)[0]['at_ms']),12000)

    def test_all_six_typed_damage_families_share_one_pool_and_clip_at_zero(self):
        families=('blunt','slash','qard','heat','constriction','tear')
        def damage(w):
            obj=next(o for o in w.collider_system.registry.objects.values() if 'prison' in o.identity.tags)
            for family in families:w.collider_system.damage(obj.identity.id,700,source='typed_prison_object_probe',damage_type=family)
        r=run(scene(700),operations=((600,damage),));self.assertEqual(self.conserved(r).amount(),0)
        e=events(r,'world_collider_damaged');self.assertEqual([x['damage_type'] for x in e],list(families))
        self.assertEqual(sum(D(x['applied']) for x in e),4000);self.assertEqual(D(e[-1]['overkill']),200)
        self.assertEqual(cube(r)['status'],'destroyed')

    def test_nearby_wall_intersecting_body_is_included_without_translation(self):
        s=scene(700);add(s,'C',['11.1',-20]);r=run(s);self.conserved(r)
        self.assertEqual(formed(r)[0]['placement']['occupants'],['B','C'])
        self.assertGreater(formed(r)[0]['placement']['iterations'],1)
        self.assertEqual(D(r['final_states']['B']['position_m'][0]),10)
        self.assertEqual(D(r['final_states']['C']['position_m'][0]),D('11.1'))

    def test_actual_grapple_partners_fit_and_continue_their_existing_hold(self):
        r=run(held_scene());self.conserved(r)
        self.assertEqual(formed(r)[0]['placement']['occupants'],['B','C'])
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertTrue(r['controlled_damage_streams']);self.assertTrue(r['grapple_links'])

    def test_joint_heavy_knock_hits_shell_and_collision_exhaustion_releases_hold(self):
        # Verify the actual paired hit and first shared material response.
        # The longer crowded continuation reaches the separately documented
        # moving-body support guard; its ordinary scenario/failure is retained.
        s=held_scene(1320);add(s,'D',['9.5','-20.45'],character='3E5',team='A')
        s['encounter']['participants']['D']['facing']='+x';s['action_selection']['D'].update(abilities=['4'],start_ms=1000)
        r=run(s);self.conserved(r);assessment=r['knock_impulses'][0]['assessment']
        self.assertEqual(assessment['actors'],['B','C']);self.assertEqual(D(assessment['maximum_hp_sum']),28140)
        hold=r['grapple_holds'][0];self.assertEqual(hold['end_reason'],'controller_exhausted')
        first=next(e for e in events(r,'body_contact') if e['second']==cube(r)['id'])
        self.assertGreater(D(first['time_ms']),D(r['knock_impulses'][0]['started_at_ms']))
        self.assertEqual(D(first['time_ms']),D(hold['ended_at_ms']))
        self.assertLess(len(events(r,'body_contact')),100)

    def test_prone_get_up_and_crouch_remain_native_actions_inside_cube(self):
        for down in (False,True):
            s=scene(1800);s['encounter']['participants']['B']['initial_state']['knocked_down']=down
            if not down:command(s,'B',700,'crouch');command(s,'B',1000,'stand')
            with self.subTest(down=down):
                r=run(s);self.conserved(r);self.assertEqual(len(formed(r)),1)
                if down:self.assertEqual(r['metrics']['B']['get_ups_completed'],1)
                else:self.assertEqual(r['metrics']['B']['crouches_completed'],1)
                self.assertFalse(r['final_states']['B']['knocked_down'])

    def test_jump_hits_actual_roof_then_lands_without_escape_or_binding(self):
        s=scene(1800);command(s,'B',600,'jump');r=run(s);self.conserved(r)
        self.assertEqual(r['metrics']['B']['jumps_started'],1);self.assertEqual(r['metrics']['B']['landings'],1)
        self.assertTrue(events(r,'body_contact'));self.assertFalse(r['binding_instances'])
        self.assertEqual(D(r['final_states']['B']['locomotion']['feet_z_m']),0)

    def test_raised_prison_support_expires_and_causes_real_fall_and_landing(self):
        s=scene(13500);s['spatial_interventions']=[force(0,'B',[0,0,'3.2'])]
        r=run(s);self.conserved(r);obj=cube(r)
        self.assertEqual(obj['status'],'expired');self.assertEqual(D(obj['removed_at_ms']),D(obj['expires_at_ms']))
        landed=events(r,'jump_landed','B');self.assertGreaterEqual(len(landed),2)
        self.assertEqual(landed[0]['support_id'],obj['id']);self.assertEqual(landed[-1]['support_id'],'ground')
        self.assertEqual(D(r['final_states']['B']['locomotion']['feet_z_m']),0)
        self.assertFalse(events(r,'jump_takeoff','B'))

    def test_released_source_death_does_not_cancel_flight_or_construct(self):
        for early in (True,False):
            s=scene();s['encounter']['participants']['A']['initial_state']['hp']=1
            if early:s['action_selection']['B']['start_ms']=200
            else:
                add(s,'C',[-15,-20],team='B');s['encounter']['participants']['C']['facing']='+x'
                s['action_selection']['C']['start_ms']=600
            r=run(s);self.conserved(r);self.assertTrue(events(r,'character_died','A'))
            self.assertEqual(len(formed(r)),1);self.assertEqual(cube(r)['status'],'active')

    def test_source_death_before_payment_cancels_cast_without_dyspnea_or_cube(self):
        s=scene();s['encounter']['participants']['A']['initial_state']['hp']=1;s['action_selection']['B']['start_ms']=0
        r=run(s);self.conserved(r);self.assertFalse(events(r,'projectile_released','A'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0);self.assertFalse(formed(r))

    def test_target_dying_before_release_does_not_form_at_its_old_location(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['hp']=1
        add(s,'C',[1,-22],team='A');s['action_selection']['C']['start_ms']=100
        r=run(s);self.conserved(r);self.assertFalse(formed(r));self.assertFalse(events(r,'projectile_body_collision','A'))
        self.assertTrue(events(r,'projectile_terrain_collision','A'))

    def test_same_wave_lethal_hit_rejects_formation_after_hp_and_death(self):
        s=scene(1000);s['encounter']['participants']['B']['initial_state']['hp']=1
        # Mirrored actual muzzle positions give identical flight geometry and
        # release times without overlapping the two source bodies.
        s['encounter']['participants']['A']['position_m']=[0,'-20.4']
        add(s,'C',[0,'-19.2'],character='1E3',team='A')
        s['encounter']['participants']['C']['facing']='+x'
        s['action_selection']['C'].update(abilities=['1'],start_ms=0)
        # This calibrated simultaneous-geometry contract uses explicit perfect
        # aim; independent current dispersion intentionally breaks that tie.
        cfg=rules();cfg.pop('projectile_accuracy')
        r=configured_run(s,rules=cfg);self.conserved(r)
        self.assertTrue(events(r,'character_died','B'))
        self.assertEqual(len(events(r,'impact_batch_resolved')[0]['hits']),2)
        self.assertFalse(formed(r));self.assertEqual(r['contact_construct_hits'][0]['status'],'recipient_life_ended')

    def test_released_source_life_stays_pinned_after_real_death_and_native_restoration(self):
        s=scene(2600,distance=30);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=350
        profiles=deepcopy(PROFILES);profiles['1E3']['timing_profiles']['4']['projectile_speed_mps']=20
        restored=[]
        def restore(w):
            restored.append(w.life_cycles.revive('A',expected_generation=1,hp=8140,source='released_prison_source_restoration_probe'))
        r=run(s,profiles=profiles,operations=((700,restore),));self.conserved(r)
        self.assertEqual(restored,[True]);self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(cube(r)['source_life_generation'],1)
        self.assertEqual(formed(r)[0]['packet']['source_life_generation'],1)

    def test_invalid_explicit_source_life_rejects_before_registry_or_logs_change(self):
        checked=[]
        def invalid(w):
            before=w.collider_system.registry.record();count=len(w.event_log.records())
            for generation in (0,99,True):
                with self.subTest(generation=generation),self.assertRaises(ValueError):
                    w.collider_system.spawn((Cuboid('panel',(20,20,1),(1,1,2)),),source='invalid_source_life_probe',
                        hp=4000,owner='A',ability='4',action_id=999,source_life_generation=generation)
                self.assertEqual(w.collider_system.registry.record(),before);self.assertEqual(len(w.event_log.records()),count)
            checked.append(True)
        run(scene(20),operations=((10,invalid),));self.assertTrue(checked)

    def test_native_climb_meets_the_new_shell_and_interrupts_on_physical_contact(self):
        s=scene(2200,distance='8.6')
        s['initial_colliders']=[wall('climb_block',x=10,hp=2000,size=('1.8',)*3,z='.9',climbable=True)]
        climb(s,actor='B',time=200,target='climb_block')
        r=run(s);self.conserved(r);self.assertTrue(formed(r))
        self.assertEqual(r['metrics']['B']['climbs_started'],1)
        self.assertEqual(r['metrics']['B']['climb_interruptions'],1)
        self.assertTrue(events(r,'body_contact'))

    def test_actual_target_death_and_revival_preserve_one_existing_physical_prison(self):
        r=run(revival_scene());self.conserved(r)
        self.assertEqual(r['metrics']['B']['revivals_completed'],1)
        self.assertEqual(len(formed(r)),1);self.assertEqual(cube(r)['status'],'active')
        self.assertEqual(r['final_states']['B']['life_generation'],2)

    def test_released_copies_have_independent_shared_face_hp_and_expiry(self):
        def copy(w):w.projectile_system.copy('projectile:1',source='explicit_prison_copy_probe',offset_m=(0,0,0))
        r=run(scene(1000),operations=((350,copy),));self.conserved(r)
        self.assertEqual(len(formed(r)),2);self.assertNotEqual(formed(r)[0]['collider_id'],formed(r)[1]['collider_id'])
        self.assertTrue(all(D(cube(r,i)['hp'])==4000 for i in range(2)))
        self.assertEqual(cube(r,0)['expires_at_ms'],cube(r,1)['expires_at_ms'])

    def test_repeated_callback_cannot_create_a_second_cube(self):
        def repeat(w):
            row=next(iter(w.contact_constructs.hits.values()));w.contact_constructs.queue(row['packet'])
            w.contact_constructs.process({'hit_id':row['id']})
        r=run(scene(700),operations=((600,repeat),));self.conserved(r);self.assertEqual(len(formed(r)),1)

    def test_definition_and_target_effects_are_pinned_at_release(self):
        def mutate(w):
            a=w.fighters['A'].profile['abilities']['4'];a['contact_construct'].update(hp=1,duration_ms=1,minimum_inner_side_m=100)
            a['target_effects'].update(disorientation=9999,instability=9999)
        r=run(scene(700),operations=((350,mutate),));self.conserved(r)
        obj=cube(r);self.assertEqual(D(obj['hp']),4000);self.assertEqual(D(obj['expires_at_ms'])-D(formed(r)[0]['at_ms']),12000)
        self.assertLess(D(r['final_states']['B']['disorientation']),100)

    def test_later_cast_hits_existing_shell_instead_of_refreshing_its_clock(self):
        r=run(scene(12800));self.conserved(r);self.assertEqual(len(formed(r)),1)
        self.assertEqual(cube(r)['status'],'expired');self.assertEqual(len(events(r,'projectile_released','A')),2)
        self.assertTrue(events(r,'construct_projectile_blocked'))

    def test_selected_modes_dimensions_and_ownership_validate_before_combat(self):
        for key,value in (('hp',0),('duration_ms',-1),('clearance_m',True),('wall_thickness_m','NaN')):
            p=deepcopy(PROFILES);p['1E3']['abilities']['4']['contact_construct'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):run(scene(1),profiles=p)
        for mode in ('contact_constructs','hand_reach','world_colliders'):
            cfg=rules();cfg.pop(mode)
            with self.subTest(mode=mode),self.assertRaises(UnsupportedMechanicError):configured_run(scene(1),rules=cfg)
        cfg=rules();cfg['action_ownership']['actions'].pop('construct_projectile')
        with self.assertRaisesRegex(ValueError,'action requirements'):configured_run(scene(1),rules=cfg)

    def test_precision_observation_and_participant_order_preserve_construct_and_contacts(self):
        s=shots_scene(2200);a=run(s)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17);self.conserved(a);self.conserved(b)
        self.assertEqual(formed(a)[0]['placement'],formed(b)[0]['placement'])
        self.assertEqual(formed(a)[0]['at_ms'],formed(b)[0]['at_ms'])
        for n,state in a['final_states'].items():
            for key in ('hp','armor','shield','dyspnea'):
                self.assertAlmostEqual(D(state[key]),D(b['final_states'][n][key]),places=18)


if __name__=='__main__':unittest.main()
