"""Real continuous sweeps: thin contacts, true misses and original flight data."""
from dataclasses import replace
from fractions import Fraction as F
from math import cos, sin, pi
import unittest

from combat_sim.angular_contacts import box_path_contact, rotating_curve_contact
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.gravity import ProjectileTrajectory
from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.moving_gravity_collisions import moving_curve_contact
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid, boxes_overlap
from tests.test_angular_paths import path


def independent_overlap(time, target, *, rate=600):
    """Independent binary64 polygon SAT, not the production box helpers."""
    angle = time*rate*pi/180
    c, s = cos(angle), sin(angle)
    first = [(c*y+s*x, s*y-c*x) for x in (-.05, .05) for y in (.5, 1.5)]
    low, high = target.bounds
    second = [(float(x), float(y)) for x in (low[0], high[0]) for y in (low[1], high[1])]
    for axis in ((c, s), (s, -c), (1, 0), (0, 1)):
        a = [sum(x*y for x, y in zip(point, axis)) for point in first]
        b = [sum(x*y for x, y in zip(point, axis)) for point in second]
        if max(a) < min(b) or max(b) < min(a):
            return False
    return True


class AngularBoxContactTests(unittest.TestCase):
    def test_initial_overlap_and_zero_length_miss_have_no_extrapolated_motion(self):
        p = path()
        same = box_path_contact(p, p.at_time(0), 0, 0)
        self.assertEqual((same.time_lower_s, same.time_upper_s), (0, 0))
        self.assertIsNone(box_path_contact(p, Cuboid('far', (10, 10, 10), (1, 1, 1)), 0, 0))

    def test_mid_arc_hit_is_found_despite_both_endpoint_boxes_missing(self):
        p, target = path(), Cuboid('target', (1, 1, 1), ('.1', '.1', '.1'))
        self.assertFalse(boxes_overlap(p.at_time(0), target))
        self.assertFalse(boxes_overlap(p.at_time(F('.15')), target))
        contact = box_path_contact(p, target, 0, F('.15'))
        self.assertLessEqual(contact.time_upper_s-contact.time_lower_s, F(1, 10**12))
        self.assertTrue(boxes_overlap(contact.first_box, contact.second_box))
        self.assertGreater(contact.time_lower_s, F('.06'))
        self.assertLess(contact.time_upper_s, F('.075'))

    def test_entry_bracket_agrees_with_independent_polygon_reference(self):
        target = Cuboid('target', (1, 1, 1), ('.1', '.1', '.1'))
        contact = box_path_contact(path(), target, 0, F('.15'))
        low, high = 0., .075
        for _ in range(60):
            middle = (low+high)/2
            if independent_overlap(middle, target):
                high = middle
            else:
                low = middle
        self.assertLessEqual(float(contact.time_lower_s), high+1e-15)
        self.assertGreaterEqual(float(contact.time_upper_s), low-1e-15)

    def test_thin_obstacle_between_regular_observations_is_not_skipped(self):
        p = path(box=Cuboid('thin_arm', (0, 1, 1), ('.0001', 1, '.1')))
        # Exact rational rotation puts the target on the arm near 35.5 degrees;
        # contact lasts far less than a millisecond, away from a fixed tick.
        frame = YawFrame.from_half_angle_tangent(F(8, 25))
        point = frame.to_world_point((0, F(7, 5), 1))
        target = Cuboid('thin_target', point, ('.0001', '.0001', '.1'))
        self.assertFalse(any(boxes_overlap(p.at_time(F(i, 1000)), target) for i in range(0, 151, 10)))
        contact = box_path_contact(p, target, 0, F('.15'))
        self.assertIsNotNone(contact)
        self.assertTrue(boxes_overlap(contact.first_box, target))

    def test_aabb_corner_overlap_does_not_become_a_box_contact(self):
        frame = YawFrame.from_degrees(37)
        first = path(rate=0, frame=frame, box=Cuboid('long', (0, 0, 1), ('.1', 2, '.1')))
        second = OrientedCuboid('parallel', frame.to_world_point(('.2', 0, 1)), ('.1', 2, '.1'), frame)
        low, high = first.at_time(0).bounds
        broad_first = Cuboid('broad', tuple((a+b)/2 for a, b in zip(low, high)), tuple(b-a for a, b in zip(low, high)))
        self.assertTrue(boxes_overlap(broad_first, second))
        self.assertIsNone(box_path_contact(first, second, 0, F('.15')))

    def test_two_rotating_paths_use_both_trajectories(self):
        first = path(box=Cuboid('first', (0, 0, 1), ('.1', 3, '.1')))
        second = path(reference=(2, 2, 0), rate=-600,
                      frame=YawFrame(0, 1), box=Cuboid('second', (0, 0, 1), ('.1', 3, '.1')))
        self.assertFalse(boxes_overlap(first.at_time(0), second.at_time(0)))
        self.assertFalse(boxes_overlap(first.at_time(F('.15')), second.at_time(F('.15'))))
        contact = box_path_contact(first, second, 0, F('.15'))
        self.assertIsNotNone(contact)
        self.assertTrue(boxes_overlap(contact.first_box, contact.second_box))
        self.assertNotEqual(contact.second_box.frame, second.at_time(0).frame)

    def test_pose_expansion_and_reference_acceleration_compose_with_rotation(self):
        first = path(velocity=(0, 1, 0), acceleration=(0, 2, 0),
                     size_rate_mps=(1, 0, 0), size_acceleration_mps2=(2, 0, 0))
        target = Cuboid('target', (1, 1, 1), ('.1', '.1', '.1'))
        contact = box_path_contact(first, target, 0, F('.15'))
        self.assertTrue(boxes_overlap(contact.first_box, target))
        self.assertGreater(contact.first_box.size_m[0], F('.1'))

    def test_whole_and_split_intervals_enclose_the_same_entry(self):
        p, target = path(), Cuboid('target', (1, 1, 1), ('.1', '.1', '.1'))
        full = box_path_contact(p, target, 0, F('.15'))
        self.assertIsNone(box_path_contact(p, target, 0, F('.017')))
        suffix = box_path_contact(p, target, F('.017'), F('.15'))
        self.assertLessEqual(abs(full.time_upper_s-suffix.time_upper_s), F(2, 10**12))

    def test_search_is_symmetric_under_participant_order(self):
        p, target = path(), Cuboid('target', (1, 1, 1), ('.1', '.1', '.1'))
        a, b = box_path_contact(p, target, 0, F('.15')), box_path_contact(target, p, 0, F('.15'))
        self.assertEqual((a.time_lower_s, a.time_upper_s), (b.time_lower_s, b.time_upper_s))
        self.assertEqual(a.first_box, b.second_box)

    def test_global_rotation_and_translation_preserve_entry_time(self):
        original = path()
        target = Cuboid('target', (1, 1, 1), ('.1', '.1', '.1'))
        before = box_path_contact(original, target, 0, F('.15'))
        frame = YawFrame(F(3, 5), F(4, 5))
        # A standard XY rotation differs from the body's right/forward map.
        rotate = lambda p: (frame.cosine*p[0]-frame.sine*p[1],
                            frame.sine*p[0]+frame.cosine*p[1], p[2])
        shift = (3, -7, 4)
        after_path = replace(original, reference=replace(original.reference, reference_m=shift),
                             yaw=replace(original.yaw, initial_frame=frame))
        centre = tuple(a+b for a, b in zip(rotate(target.centre_m), shift))
        # Axis-aligned world size order becomes body's (right,forward,up).
        after_target = OrientedCuboid('target', centre, target.size_m, frame)
        after = box_path_contact(after_path, after_target, 0, F('.15'))
        self.assertLess(abs(before.time_upper_s-after.time_upper_s), F(2, 10**12))

    def test_real_contact_point_moves_while_reference_stays_stationary(self):
        p, target = path(), Cuboid('target', (1, 1, 1), ('.1', '.1', '.1'))
        contact = box_path_contact(p, target, 0, F('.15'))
        self.assertEqual(p.reference.velocity(contact.time_upper_s*1000), (0, 0, 0))
        self.assertGreater(sum(v*v for v in p.centre_state(contact.time_upper_s).velocity_mps), 100)

    def test_unresolved_near_tangent_clearance_is_not_reported_as_miss(self):
        # Every corner lies on radius .5. The wall is strictly outside that
        # circle, but 1e-30 clearance cannot be resolved by this coarse lease.
        p = path(box=Cuboid('square', (0, 0, 0), ('.6', '.8', '.1')))
        wall = Cuboid('near', (F('.55')+F(1, 10**30), 0, 0), ('.1', '.1', '.1'))
        with self.assertRaisesRegex(UnsupportedMechanicError, 'unresolved angular'):
            box_path_contact(p, wall, 0, F('.15'), time_tolerance_s=F(1, 10**6))

    def test_budget_exhaustion_is_explicit_and_never_a_silent_miss(self):
        with self.assertRaisesRegex(UnsupportedMechanicError, 'budget exhausted'):
            box_path_contact(path(), Cuboid('target', (1, 1, 1), ('.1', '.1', '.1')),
                             0, F('.15'), node_limit=1)

    def test_invalid_controls_or_extrapolated_paths_fail(self):
        p, target = path(), Cuboid('target', (1, 1, 1), ('.1', '.1', '.1'))
        for begin, end in ((-.01, .1), (0, .151), (.1, .09), (False, .1)):
            with self.subTest(begin=begin, end=end), self.assertRaises(ValueError):
                box_path_contact(p, target, begin, end)
        for kwargs in ({'time_tolerance_s': 0}, {'node_limit': 0}, {'node_limit': True}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                box_path_contact(p, target, 0, F('.15'), **kwargs)


class AngularProjectileContactTests(unittest.TestCase):
    def test_existing_curved_contact_entry_point_accepts_rotating_box_path(self):
        flight = ProjectileTrajectory((1, 1, 1), (0, 0, 0), .15, gravity_mps2=0)
        p = path()
        self.assertFalse(p.at_time(0).intersects_sphere((1, 1, 1), '.02'))
        self.assertFalse(p.at_time(F('.15')).intersects_sphere((1, 1, 1), '.02'))
        actual = moving_curve_contact(flight, p, '.02', 0, .15)
        direct = rotating_curve_contact(flight, p, '.02', 0, .15)
        self.assertEqual(actual, direct)
        self.assertLessEqual(actual.time_upper_s-actual.time_lower_s, 1e-12)
        self.assertEqual(actual.centre_m, (1, 1, 1))
        self.assertEqual((actual.distance_lower_m, actual.distance_upper_m), (0, 0))

    def test_real_gravity_deceleration_and_original_arc_distance_are_retained(self):
        flight = PersistentProjectileTrajectory((0, 0, 1), (100, 0, .5), .1, deceleration_mps2=300)
        p = path(end=F('.1'), reference=(5, 0, 1), velocity=(1, 0, 0), acceleration=(2, 0, 0),
                 box=Cuboid('body', (0, 0, 0), ('.5', '.3', '.7')))
        original = flight.states
        contact = moving_curve_contact(flight, p, '.02', 0, .1)
        self.assertIsNotNone(contact)
        self.assertIs(flight.states, original)
        self.assertEqual(contact.centre_m, flight.at(contact.time_upper_s).position_m)
        self.assertEqual(contact.distance_lower_m, flight.at(contact.time_lower_s).distance_m)
        self.assertEqual(contact.distance_upper_m, flight.at(contact.time_upper_s).distance_m)
        shape = p.at_time(contact.time_upper_s)
        closest = tuple(map(float, shape.closest_point(contact.centre_m)))
        self.assertEqual(contact.surface_point_m, closest)
        self.assertNotEqual(contact.distance_upper_m, 100*contact.time_upper_s)

    def test_stationary_noncardinal_box_true_rounded_corner_miss_is_pruned(self):
        frame = YawFrame.from_degrees(37)
        p = path(end=F('.04'), rate=0, frame=frame, reference=(1, 1, 1),
                 box=Cuboid('box', (0, 0, 0), (2, 2, 2)))
        origin = tuple(map(float, frame.to_world_point((-2, F('-1.019'), F('-1.019')), (1, 1, 1))))
        velocity = tuple(map(float, frame.to_world_vector((100, 0, 0))))
        flight = ProjectileTrajectory(origin, velocity, .04, gravity_mps2=0)
        self.assertIsNone(moving_curve_contact(flight, p, '.02', 0, .04))

    def test_noncardinal_empty_aabb_corner_miss_is_pruned_during_actual_rotation(self):
        p = path(end=F('.1'), rate=5, frame=YawFrame.from_degrees(37),
                 box=Cuboid('long', (0, 0, 1), ('.1', 2, '.1')))
        centre = p.yaw.initial_frame.to_world_point(('.3', 0, 1))
        flight = ProjectileTrajectory(tuple(map(float, centre)), (0, 0, 0), .1, gravity_mps2=0)
        self.assertIsNone(moving_curve_contact(flight, p, '.02', 0, .1))

    def test_split_queries_do_not_reanchor_rotation_or_reintegrate_flight(self):
        flight = ProjectileTrajectory((1, 1, 1), (0, 0, 0), .15, gravity_mps2=0)
        p = path()
        full = moving_curve_contact(flight, p, '.02', 0, .15)
        self.assertIsNone(moving_curve_contact(flight, p, '.02', 0, .017))
        suffix = moving_curve_contact(flight, p, '.02', .017, .15)
        self.assertLess(abs(full.time_upper_s-suffix.time_upper_s), 2e-12)
        for a, b in zip(full.surface_point_m, suffix.surface_point_m):
            self.assertLess(abs(a-b), 1e-10)

    def test_instantaneous_overlap_retains_absolute_flight_clock(self):
        p = path()
        centre = tuple(map(float, p.at_time(F('.075')).centre_m))
        flight = ProjectileTrajectory(centre, (0, 0, 0), .15, gravity_mps2=0)
        contact = moving_curve_contact(flight, p, '.02', .075, .075)
        self.assertEqual((contact.time_lower_s, contact.time_upper_s), (.075, .075))
        self.assertEqual(contact.centre_m, centre)

    def test_saved_path_rejects_a_second_set_of_pose_or_translation_drivers(self):
        flight = ProjectileTrajectory((1, 1, 1), (0, 0, 0), .15, gravity_mps2=0)
        for kwargs in ({'box_velocity': (1, 0, 0)}, {'box_acceleration': (0, 1, 0)},
                       {'box_size_rate_mps': (1, 0, 0)}, {'box_size_acceleration_mps2': (0, 1, 0)}):
            with self.subTest(kwargs=kwargs), self.assertRaisesRegex(ValueError, 'already owns'):
                moving_curve_contact(flight, path(), '.02', 0, .15, **kwargs)

    def test_extrapolated_flight_or_yaw_lease_and_invalid_controls_fail(self):
        flight = ProjectileTrajectory((1, 1, 1), (0, 0, 0), .15, gravity_mps2=0)
        for begin, end in ((-.01, .1), (0, .151), (.1, .09), (True, .1)):
            with self.subTest(begin=begin, end=end), self.assertRaises(ValueError):
                moving_curve_contact(flight, path(), '.02', begin, end)
        with self.assertRaises(ValueError):
            moving_curve_contact(flight, path(end=F('.1')), '.02', 0, .15)
        for kwargs in ({'time_tolerance_s': 0}, {'clearance_tolerance_m': 0}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                moving_curve_contact(flight, path(), '.02', 0, .15, **kwargs)

    def test_precision_and_participant_order_do_not_change_contact_outcome(self):
        p = path()
        flight = ProjectileTrajectory((1, 1, 1), (0, 0, 0), .15, gravity_mps2=0)
        a = moving_curve_contact(flight, p, '.02', 0, .15)
        b = moving_curve_contact(flight, replace(p, yaw=replace(p.yaw, precision=80)), '.02', 0, .15)
        self.assertEqual(a, b)

    def test_later_absolute_path_interval_keeps_original_flight_distance(self):
        flight = ProjectileTrajectory((0, 0, 1), (100, 0, 0), 1.1, gravity_mps2=0)
        p = path(begin=1, end=F('1.1'), reference=(105, 0, 1), velocity=(1, 0, 0),
                 box=Cuboid('late_body', (0, 0, 0), ('.5', '.3', '.7')))
        contact = moving_curve_contact(flight, p, '.02', 1, 1.1)
        self.assertGreater(contact.time_lower_s, 1)
        self.assertGreater(contact.distance_lower_m, 100)
        self.assertEqual(contact.centre_m, flight.at(contact.time_upper_s).position_m)

    def test_rational_lease_cannot_be_silently_extended_by_float_clock_rounding(self):
        flight = ProjectileTrajectory((0, 0, 1), (100, 0, 0), 1, gravity_mps2=0)
        p = path(begin=F(1, 3), end=F(2, 3))
        with self.assertRaisesRegex(ValueError, 'outside'):
            rotating_curve_contact(flight, p, '.02', F(1, 3), F(2, 3))


if __name__ == '__main__':
    unittest.main()
