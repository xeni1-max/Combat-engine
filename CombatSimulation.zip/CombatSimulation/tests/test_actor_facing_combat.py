"""Native fixed-heading actions; probes are explicitly labelled API interventions."""
from copy import deepcopy
from decimal import Context,Decimal as D,ROUND_UP,Inexact,getcontext,localcontext
from fractions import Fraction as F
import json,unittest

from combat_sim.orientation import YawFrame
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from tests.test_equilibrium_combat import scene as base_scene,run
from tests.test_mobile_combat import events,command,PROFILES


def scene(duration=1000,character='1E2'):
    s=base_scene(duration,character=character);s['id']='fixed_actor_yaw'
    s['action_selection']['A']['start_ms']=100000
    return s


def oriented(s,angle=37):
    """Rotate explicit scene geometry about (0,-20); leave the finite floor fixed."""
    s=deepcopy(s);rotation=YawFrame.from_degrees(F(angle)+90)
    def point(p):
        x,y,*z=p;v=rotation.to_world_vector((F(x),F(y)+20,0))
        return [str(D(v[0].numerator)/D(v[0].denominator)),
            str(D(v[1].numerator)/D(v[1].denominator)-20),*z]
    for a in s['encounter']['participants'].values():
        a['position_m']=point(a['position_m'])
        a['facing']={'yaw_degrees':angle+(180 if a['facing']=='-x' else 0)}
        if 'movement_direction' in a:
            x,y=a['movement_direction'];v=rotation.to_world_vector((x,y,0));a['movement_direction']=[str(D(q.numerator)/D(q.denominator)) for q in v[:2]]
    for obj in s.get('initial_colliders',[]):
        for part in obj['parts']:
            part['centre_m']=point(part['centre_m']);part['yaw_degrees']=F(part.get('yaw_degrees',0))+angle
            part['yaw_degrees']=str(part['yaw_degrees'])
    for config in s['action_selection'].values():
        for target in config.get('ability_targets',{}).values():target['point_m']=point(target['point_m'])
    return s


def selected_cases():
    from tests.test_blocking_combat import scene as block_scene
    from tests.test_charge_grapple_combat import scene as charge_scene,panel
    from tests.test_body_leaps_combat import scene as kick_scene
    from tests.test_component_melee_combat import scene as slash_scene
    from tests.test_segment_fields_combat import scene as fence_scene
    from tests.test_portals_combat import scene as portal_scene,use
    cases={}
    s=cases['walk']=scene();command(s,'A',0,'walk')
    s=cases['gun']=scene(500);s['encounter']['participants']['B']['position_m']=[5,-20]
    s['action_selection']['A']['start_ms']=0
    cases['block']=block_scene(400,held=True,distance=5)
    cases['slash']=slash_scene(250)
    cases['charge']=charge_scene(1200)
    s=cases['charge_wall']=charge_scene(1300);panel(s,'hand_wall',2)
    cases['kick']=kick_scene()
    cases['fence']=fence_scene(1000,explicit=False)
    cases['fence_axis']=fence_scene(500,axis='x')
    s=cases['beam']=scene(1200,'1E1');s['encounter']['participants']['B']['position_m']=[10,-20]
    s['action_selection']['A'].update(abilities=['4'],start_ms=0,reload_when_empty=False)
    s=cases['portal']=portal_scene();use(s)
    return {n:oriented(s) for n,s in cases.items()}


class ActorFacingCombatTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def conserved(self,r,*,external_losses=None):
        json.dumps(r);damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        external_losses=external_losses or {}
        for n,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=n)
            self.assertLess(abs(supplied-external_losses.get(n,0)-D(r['final_states'][n]['hp'])-damage.amount(target=n)),D('1e-8'))
        return damage

    def test_all_six_source_characters_have_real_fixed_yaw_geometry(self):
        for name in PROFILES:
            with self.subTest(character=name):
                r=run(oriented(scene(100,name)));self.conserved(r)
                self.assertEqual(len(r['body_geometry']['A']['parts']),6)
                self.assertTrue(all(p['shape']=='oriented_cuboid' for p in r['body_geometry']['A']['parts']))
                self.assertIn('yaw_frame',r['final_states']['A']['facing'])

    def test_walk_defaults_to_heading_with_analytic_start_transition_distance(self):
        r=run(selected_cases()['walk']);self.conserved(r);f=YawFrame.from_degrees(37)
        x,y=map(D,r['final_states']['A']['position_m']);expected=D('1.94')
        self.assertLess(abs(x-expected*D(f.cosine.numerator)/D(f.cosine.denominator)),D('1e-35'))
        self.assertLess(abs(y+20-expected*D(f.sine.numerator)/D(f.sine.denominator)),D('1e-35'))

    def test_explicit_world_drive_stays_independent_of_body_heading(self):
        s=oriented(scene());s['encounter']['participants']['A']['movement_direction']=[1,0];command(s,'A',0,'walk')
        r=run(s);self.conserved(r)
        self.assertEqual(tuple(map(D,r['final_states']['A']['position_m'])),(D('1.94'),-20))

    def test_crouch_and_stand_keep_actual_feet_and_heading(self):
        s=oriented(scene(600));command(s,'A',0,'crouch');command(s,'A',300,'stand')
        r=run(s,interval=25);self.conserved(r)
        self.assertEqual(r['metrics']['A']['crouches_completed'],1);self.assertEqual(r['metrics']['A']['stands_completed'],1)
        self.assertTrue(all(D(p['states']['A']['locomotion']['feet_z_m'])==0 for p in r['curve']))

    def test_get_up_completes_for_every_rotated_source_scale(self):
        for name in PROFILES:
            with self.subTest(character=name):
                s=scene(600,name);s['encounter']['participants']['A']['initial_state']['knocked_down']=True
                r=run(oriented(s));self.conserved(r)
                self.assertFalse(r['final_states']['A']['knocked_down']);self.assertEqual(r['metrics']['A']['get_ups_completed'],1)
                self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)

    def test_actual_gun_uses_rotated_start_hand_and_hits_an_oriented_body(self):
        r=run(selected_cases()['gun']);damage=self.conserved(r);flight=r['projectile_flights'][0]
        hand=PROFILES['1E2']['abilities']['1']['hand_positions_m']['start']['left']
        expected=YawFrame.from_degrees(37).to_world_point(hand,(0,-20,'.875'))
        self.assertTrue(all(abs(F(x)-y)<F(1,10**35) for x,y in zip(flight['origin_m'][:2],expected[:2])))
        baseline=scene(500);baseline['encounter']['participants']['B']['position_m']=[5,-20]
        baseline['action_selection']['A']['start_ms']=0
        original=run(baseline);self.conserved(original)
        self.assertEqual(D(flight['origin_m'][2]),D(original['projectile_flights'][0]['origin_m'][2]))
        self.assertGreater(damage.amount(target='B'),0);self.assertEqual(flight['collision_kind'],'body')

    def test_real_block_has_local_dimensions_and_intercepts_incoming_gunfire(self):
        r=run(selected_cases()['block']);self.conserved(r);layers=r['block_layers']
        self.assertTrue(layers);self.assertTrue(all(l['shape']=='oriented_cuboid' for l in layers))
        self.assertTrue(events(r,'block_layer_damage'));self.assertEqual(D(r['final_states']['A']['hp']),PROFILES['2E4']['max_hp'])

    def test_actual_slash_contacts_the_rotated_target_without_changing_its_output(self):
        from tests.test_component_melee_combat import scene as slash_scene
        first=run(slash_scene(250));other=run(selected_cases()['slash'])
        self.conserved(first);self.conserved(other)
        self.assertEqual(D(first['final_states']['B']['hp']),D(other['final_states']['B']['hp']))
        self.assertTrue(events(other,'bleeding_started'))

    def test_real_charge_follows_heading_and_captures_its_actual_front(self):
        r=run(selected_cases()['charge']);self.conserved(r)
        self.assertTrue(r['grapple_holds']);self.assertEqual(r['grapple_holds'][0]['target'],'B')
        self.assertTrue(r['grapple_links']);self.assertTrue(all(p['facing'].get('yaw_frame') for w in r['body_contact_waves'] for p in w['after'].values()))

    def test_real_charge_hand_fractures_the_rotated_wall(self):
        r=run(selected_cases()['charge_wall']);self.conserved(r)
        self.assertEqual(r['world_collider_states']['hand_wall']['status'],'destroyed')
        self.assertTrue(events(r,'charge_hand_wall_resolved'))

    def test_falling_foot_contact_keeps_its_source_blunt_output(self):
        r=run(selected_cases()['kick']);damage=self.conserved(r)
        self.assertEqual(damage.amount(target='B'),D('562.5'))
        self.assertEqual(len(events(r,'owned_contact_committed','A')),1)

    def test_implicit_fence_preserves_five_panels_and_body_lateral_direction(self):
        r=run(selected_cases()['fence']);damage=self.conserved(r);field=r['segment_fields'][0]
        self.assertEqual(field['axis'],'body_lateral');self.assertEqual(len(field['panel_ids']),5)
        self.assertGreater(damage.amount(target='B'),0);self.assertTrue(r['binding_instances'])
        f=YawFrame(**field['yaw_frame']);centres=[]
        for key in field['panel_ids']:
            part=r['world_collider_states'][key]['parts'][0];self.assertEqual(part['shape'],'oriented_cuboid')
            centres.append(f.to_local_point(part['centre_m'],field['location_m']))
        self.assertLess(max(abs(p[1]) for p in centres),F(1,10**35))

    def test_explicit_world_fence_axis_is_retained(self):
        r=run(selected_cases()['fence_axis']);self.conserved(r)
        self.assertEqual(r['segment_fields'][0]['axis'],'x')
        self.assertTrue(all('shape' not in r['world_collider_states'][key]['parts'][0] for key in r['segment_fields'][0]['panel_ids']))

    def test_actual_beam_exposes_an_oriented_body_through_shared_field_cells(self):
        r=run(selected_cases()['beam']);damage=self.conserved(r)
        self.assertTrue(events(r,'beam_deployed'));self.assertGreater(damage.amount(target='B'),0)

    def test_real_portal_transport_preserves_the_fixed_actor_frame(self):
        r=run(selected_cases()['portal']);self.conserved(r)
        self.assertEqual(r['portal_uses'][0]['status'],'used');self.assertEqual(r['initial_states']['A']['facing'],r['final_states']['A']['facing'])

    def test_native_body_contact_with_different_frames_completes_without_penetration(self):
        s=scene(1600);s['encounter']['participants']['B']['position_m']=['2.5',-20];command(s,'A',0,'walk')
        r=run(oriented(s));self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertEqual(D(r['run_until_ms']),1600)

    def test_jump_keeps_its_horizontal_heading_and_existing_landing_debt(self):
        s=scene(1200);command(s,'A',0,'walk');command(s,'A',200,'jump')
        r=run(oriented(s));self.conserved(r)
        self.assertEqual(len(events(r,'jump_takeoff','A')),1);self.assertEqual(len(events(r,'jump_landed','A')),1)
        self.assertEqual(r['metrics']['A']['jumps_started'],1)
        p=tuple(map(F,r['final_states']['A']['position_m']));f=YawFrame.from_degrees(37)
        self.assertLess(abs((p[0]*f.sine-(p[1]+20)*f.cosine)),F(1,10**35))

    def test_climb_preserves_actor_frame_on_a_rotated_material(self):
        from tests.test_climb_combat import climb
        from tests.test_world_colliders_combat import platform
        s=scene(1000);s['encounter']['participants']['A']['position_m']=['4.7',-20]
        obj=platform('ledge');obj['parts'][0]['centre_m']=[6,-20,'.9'];s['initial_colliders']=[obj]
        climb(s,actor='A',time=0,target='ledge')
        r=run(oriented(s));self.conserved(r)
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertEqual(r['final_states']['A']['facing'],r['initial_states']['A']['facing'])
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),D('1.8'))

    def test_mixed_yaw_body_support_uses_real_footprints(self):
        from tests.test_grapple_links_combat import force
        s=oriented(scene(500));s['encounter']['participants']['B']['facing']={'yaw_degrees':-13}
        s['spatial_interventions']=[force(0,'B',reference=[0,-20,'2.625'])]
        r=run(s);self.conserved(r)
        self.assertEqual(D(r['final_states']['B']['locomotion']['feet_z_m']),D('1.75'))
        self.assertTrue(any(row['status']=='active' for row in r['body_support_contacts']))
        self.assertFalse(events(r,'jump_takeoff'));self.assertEqual(D(r['metrics']['B']['dyspnea_paid']),0)

    def test_labelled_restoration_keeps_yaw_and_the_old_detached_block_frame(self):
        from tests.test_blocking_combat import scene as block_scene
        s=block_scene(500,held=True);s['action_selection']['B']['start_ms']=100000;s=oriented(s)
        def die(w):
            a=w.fighters['A'];w.log('actor_facing_external_loss',actor='A',amount=a.hp);a.hp=D(0);w.finish_team_deaths()
        def restore(w):
            self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='actor_facing_restoration_probe'))
        r=run(s,operations=((100,die),(200,restore)))
        self.conserved(r,external_losses={'A':D(r['initial_states']['A']['hp'])})
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(r['initial_states']['A']['facing'],r['final_states']['A']['facing'])
        old=next(l for l in r['block_layers'] if l['source_life_generation']==1)
        self.assertFalse(old['attached']);self.assertEqual(old['yaw_frame'],r['initial_states']['A']['facing']['yaw_frame'])

    def test_restoration_does_not_treat_an_empty_enclosing_corner_as_solid(self):
        from tests.test_world_colliders_combat import wall
        s=oriented(scene(500));obj=wall('corner',x='.23',z='1.1',hp=2000,size=('.04',)*3)
        obj['parts'][0]['centre_m'][1]='-19.75';s['initial_colliders']=[obj]
        def die(w):
            a=w.fighters['A'];w.log('actor_facing_external_loss',actor='A',amount=a.hp);a.hp=D(0);w.finish_team_deaths()
        restored=[]
        def restore(w):restored.append(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='actor_facing_corner_restoration_probe'))
        r=run(s,operations=((100,die),(200,restore)))
        self.assertEqual(restored,[True]);self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.conserved(r,external_losses={'A':D(r['initial_states']['A']['hp'])})

    def test_restoration_uses_the_same_finite_floor_contact_band_for_both_shape_types(self):
        from tests.test_constructor_context import arguments
        profiles,inputs=arguments()
        for s in (scene(),oriented(scene())):
            with self.subTest(facing=s['encounter']['participants']['A']['facing']):
                w=SharedEncounter(s,profiles,**inputs)
                w.set_body_reference('A',(0,-20,D('.875')-D('1e-30')))
                w.fighters['A'].hp=D(0);w.finish_team_deaths()
                self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='floor_contact_band_probe'))

    def test_transport_accepts_actual_floor_contact_within_its_declared_band(self):
        from tests.test_constructor_context import arguments
        from combat_sim.spatial_transitions import SpatialChange
        profiles,inputs=arguments();w=SharedEncounter(oriented(scene()),profiles,**inputs)
        z=D('.875')-D('1e-30')
        plan=w.spatial_transitions.prepare_transport((SpatialChange('A',1,reference_m=(1,-20,z)),),source='floor_contact_band_probe')
        w.spatial_transitions.commit(plan)
        self.assertEqual(w.spatial_transitions.reference('A'),(1,-20,z))

    def test_transport_still_rejects_real_sheet_crossing_atomically(self):
        from tests.test_constructor_context import arguments
        from combat_sim.spatial_transitions import SpatialChange
        profiles,inputs=arguments();w=SharedEncounter(oriented(scene()),profiles,**inputs);before=w.states()
        with self.assertRaisesRegex(ValueError,'crosses the finite ground'):
            w.spatial_transitions.prepare_transport((SpatialChange('A',1,reference_m=(1,-20,'.874')),),source='floor_crossing_probe')
        self.assertEqual(w.states(),before)

    def test_direct_constructor_owns_noncardinal_heading_precision(self):
        from tests.test_constructor_context import arguments
        profiles,inputs=arguments();s=selected_cases()['gun']
        expected=SharedEncounter(s,profiles,precision=50,**inputs).run()
        with localcontext(Context(prec=28,rounding=ROUND_UP)):
            getcontext().traps[Inexact]=True
            self.assertEqual(SharedEncounter(s,profiles,precision=50,**inputs).run(),expected)

    def test_unimplemented_turn_command_is_still_an_explicit_boundary(self):
        s=oriented(scene());s['movement_script']=[{'actor':'A','at_ms':0,'action':'turn'}]
        with self.assertRaisesRegex(UnsupportedMechanicError,'movement command'):run(s)


if __name__=='__main__':unittest.main()
