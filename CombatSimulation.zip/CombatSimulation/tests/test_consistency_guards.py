import json
import unittest
from copy import deepcopy
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction
from pathlib import Path

from combat_sim.engine import run_scenario
from combat_sim.mechanics.dyspnea import DyspneaContext, advance_continuous_action_dyspnea
from combat_sim.mechanics.status import apply_status, decay_status
from combat_sim.mechanics.timing import impact_time_from_activation
from combat_sim.models import UnsupportedMechanicError, fraction_record


ROOT = Path(__file__).resolve().parents[1]
CHARACTERS = json.loads((ROOT / "data/characters.json").read_text())["characters"]
SCENARIO = json.loads((ROOT / "scenarios/one_blunt_impact.json").read_text())


class ConsistencyGuardTests(unittest.TestCase):
    def test_timing_only_defender_profile_is_rejected_explicitly(self):
        # 1E3 now has its primary combat stats imported. Keep this guard about
        # an explicitly incomplete input, rather than a stale roster omission.
        profiles=deepcopy(CHARACTERS)
        profiles['1E3']={'timing_profiles':deepcopy(CHARACTERS['1E3']['timing_profiles'])}
        scenario = deepcopy(SCENARIO)
        target = scenario["encounter"]["initial_states"].pop("1E1")
        target.update(hp=20000, armor=350)
        scenario["encounter"]["initial_states"]["1E3"] = target
        scenario["action_sequence"][0]["target"] = "1E3"
        with self.assertRaisesRegex(UnsupportedMechanicError, "defender data.*1E3"):
            run_scenario(scenario, profiles)

    def test_unsupported_initial_status_is_rejected_instead_of_discarded(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["3E5"]["disorientation"] = 80
        with self.assertRaisesRegex(UnsupportedMechanicError, "disorientation"):
            run_scenario(scenario, CHARACTERS)

    def test_unsupported_action_status_is_rejected_instead_of_discarded(self):
        scenario = deepcopy(SCENARIO)
        scenario["action_sequence"][0]["disorientation_at_gathering_start"] = 80
        with self.assertRaisesRegex(UnsupportedMechanicError, "disorientation_at_gathering_start"):
            run_scenario(scenario, CHARACTERS)

    def test_status_arithmetic_has_fixed_precision_and_rounding(self):
        expected = Decimal("255.8639544836367369325407919063226113655")
        for precision, rounding in ((10, ROUND_FLOOR), (28, ROUND_CEILING), (60, ROUND_FLOOR)):
            with self.subTest(precision=precision, rounding=rounding), localcontext() as context:
                context.prec = precision
                context.rounding = rounding
                self.assertEqual(apply_status(0, 300, 8140, 150, 0), expected)
                self.assertEqual(context.prec, precision)

    def test_status_decay_preserves_its_defined_precision(self):
        value = Decimal("255.8639544836367369325407919063226113655")
        expected = Decimal("254.8639544836367369325407919063226113655")
        with localcontext() as context:
            context.prec = 10
            self.assertEqual(decay_status(value, 1), expected)

    def test_fraction_display_is_independent_of_ambient_precision(self):
        for precision in (10, 60):
            with self.subTest(precision=precision), localcontext() as context:
                context.prec = precision
                result = fraction_record(Fraction(1, 7))
                self.assertEqual(result["exact"], "1/7")
                self.assertEqual(result["decimal_approx"], "0.1428571428571428571428571429")

    def test_small_timing_fraction_is_not_lost_by_ambient_rounding(self):
        profile = {"gathering_ms": "0.0000000001", "active_ms": 180, "impact_timing": "middle_of_active"}
        for precision, rounding in ((10, ROUND_FLOOR), (60, ROUND_CEILING)):
            with self.subTest(precision=precision), localcontext() as context:
                context.prec = precision
                context.rounding = rounding
                impact, calculation = impact_time_from_activation(0, profile)
                self.assertEqual(impact, 91)
                self.assertEqual(calculation["active_end_ms"], 181)

    def test_continuous_dyspnea_is_independent_of_ambient_rounding(self):
        results = []
        for precision, rounding in ((10, ROUND_FLOOR), (60, ROUND_CEILING)):
            with localcontext() as context:
                context.prec = precision
                context.rounding = rounding
                results.append(advance_continuous_action_dyspnea(
                    50, 2, 1000, context=DyspneaContext("sprinting"),
                ).after)
        self.assertEqual(results[0], results[1])


if __name__ == "__main__":
    unittest.main()
