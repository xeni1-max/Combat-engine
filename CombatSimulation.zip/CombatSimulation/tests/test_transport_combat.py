"""Labelled shared API transport contracts before actual portal delivery."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.grapple_links import LinkCommand
from combat_sim.spatial_transitions import SpatialChange, StaleSpatialPlan
from tests.test_equilibrium_combat import scene, run
from tests.test_mobile_combat import command, events
from tests.test_world_colliders_combat import wall
from tests.test_grapple_links_combat import force


def transport(w,delta=(10,0,0),name='A'):
    ref=w.spatial_transitions.reference(name)
    plan=w.spatial_transitions.prepare_transport((SpatialChange(name,w.fighters[name].life_generation,
        reference_m=tuple(p+D(d) for p,d in zip(ref,delta))),),source='transport_api_probe')
    return w.spatial_transitions.commit(plan)


def link(w):
    p=w.grapple_links.prepare(LinkCommand('attach','transport_probe_link','A','B',1,1,3000),source='transport_api_probe')
    w.grapple_links.commit(p)


class TransportCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def equivalent(self,a,b,*,translated=('A',),delta=(10,0,0)):
        for name in a['final_states']:
            x,y=a['final_states'][name],b['final_states'][name]
            for key in ('hp','armor','shield','dyspnea','disorientation','instability'):
                self.assertLess(abs(D(x[key])-D(y[key])),D('1e-8'),(name,key))
            for i,(p,q) in enumerate(zip(x['body_origin_m'],y['body_origin_m'])):
                expected=D(delta[i]) if name in translated else D(0)
                self.assertLess(abs(D(q)-D(p)-expected),D('1e-8'),(name,'position',i))
            for p,q in zip(x['locomotion']['velocity_mps'],y['locomotion']['velocity_mps']):
                self.assertLess(abs(D(q)-D(p)),D('1e-8'),(name,'velocity'))

    def test_stable_walking_preserves_drive_instead_of_turning_it_into_imposed_motion(self):
        s=scene(800);command(s,'A',0,'walk')
        a=run(s);b=run(s,operations=((100,transport),))
        self.equivalent(a,b)
        self.assertEqual(b['final_states']['A']['locomotion']['mode'],'walking')
        self.assertFalse(events(b,'controlled_action_cancelled','A'))

    def test_mid_walk_active_keeps_phase_clock_and_acceleration(self):
        s=scene(500);command(s,'A',0,'walk')
        a=run(s);b=run(s,operations=((30,transport),))
        self.equivalent(a,b)
        self.assertEqual([e['time_ms'] for e in events(a,'movement_active_completed')],
            [e['time_ms'] for e in events(b,'movement_active_completed')])
        self.assertFalse(events(b,'controlled_action_cancelled','A'))

    def test_mid_running_transition_preserves_status_driven_acceleration_and_cost(self):
        s=scene(700);command(s,'A',0,'run')
        a=run(s);b=run(s,operations=((150,transport),))
        self.equivalent(a,b)
        self.assertEqual(b['final_states']['A']['locomotion']['mode'],'running')
        self.assertEqual(a['metrics']['A']['dyspnea_paid'],b['metrics']['A']['dyspnea_paid'])

    def test_jump_flight_and_already_owed_landing_survive_transport_once(self):
        s=scene(1200);command(s,'A',0,'jump')
        a=run(s);b=run(s,operations=((250,transport),))
        self.equivalent(a,b)
        self.assertEqual(a['metrics']['A']['jumps_started'],b['metrics']['A']['jumps_started'])
        self.assertEqual(a['metrics']['A']['landings'],b['metrics']['A']['landings'])
        self.assertEqual(a['metrics']['A']['dyspnea_paid'],b['metrics']['A']['dyspnea_paid'])
        self.assertFalse(events(b,'controlled_action_cancelled','A'))

    def test_pose_active_keeps_its_timing_and_morph_after_transport(self):
        s=scene(400);command(s,'A',0,'crouch')
        a=run(s);b=run(s,operations=((75,transport),))
        self.equivalent(a,b)
        self.assertEqual(a['final_states']['A']['locomotion']['crouch_fraction'],b['final_states']['A']['locomotion']['crouch_fraction'])
        self.assertFalse(events(b,'controlled_action_cancelled','A'))

    def test_blocked_exit_does_not_cancel_current_motion_or_partially_move(self):
        s=scene(500);command(s,'A',0,'walk')
        def blocked(w):
            a=w.fighters['A'];before=(deepcopy(w.states()),deepcopy(w.motion),a.body_action().revision)
            with self.assertRaises(ValueError):
                w.spatial_transitions.prepare_transport((SpatialChange('A',1,reference_m=w.spatial_transitions.reference('B')),),source='blocked_transport_probe')
            self.assertEqual((w.states(),w.motion,a.body_action().revision),before)
            self.assertFalse(w.spatial_transitions.records)
        self.equivalent(run(s),run(s,operations=((30,blocked),)),translated=())

    def test_relocation_does_not_sweep_intervening_walls(self):
        s=scene(500);s['initial_colliders']=[wall('middle',x=5,hp=2000)]
        r=run(s,operations=((100,transport),))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),10)
        self.assertEqual(D(r['world_collider_states']['middle']['hp']),2000)
        self.assertFalse(events(r,'body_contact'))

    def test_full_grapple_group_translates_once_and_retains_independent_motor_inputs(self):
        s=scene(700);s['encounter']['participants']['B']['position_m']=[0,-18]
        command(s,'A',0,'walk')
        a=run(s,operations=((0,link),))
        def move(w):
            before=tuple(w.motion[n]['speed'] for n in ('A','B'))
            row=transport(w)
            self.assertEqual([b['actor'] for b in row['bodies']],['A','B'])
            self.assertEqual(tuple(w.motion[n]['speed'] for n in ('A','B')),before)
        b=run(s,operations=((0,link),(200,move)))
        self.equivalent(a,b,translated=('A','B'))
        self.assertEqual(b['grapple_links'][0]['status'],'active')

    def test_fixed_tether_rejects_escape_without_releasing_it(self):
        def attach(w):
            anchor=w.terrain_anchors.below('A',2)
            w.distance_constraints.attach_fixed('A',anchor,maximum_m=2,expires_at_ms=2000,
                source='transport_fixed_limit_probe',expected_life=1)
        def reject(w):
            before=w.spatial_transitions.reference('A')
            with self.assertRaises(ValueError):transport(w)
            self.assertEqual(w.spatial_transitions.reference('A'),before)
            self.assertEqual(w.distance_constraints.rows['distance:1']['status'],'active')
        r=run(scene(300),operations=((0,attach),(100,reject)))
        self.assertFalse(r['spatial_transitions'])

    def test_legal_tethered_transport_keeps_remote_endpoint_and_distance_row(self):
        s=scene(300);s['encounter']['participants']['B']['position_m']=['1.1',-20]
        def attach(w):w.distance_constraints.attach('A','B',maximum_m=2.5,expires_at_ms=2000,
            source='transport_pair_limit_probe',expected_lives={'A':1,'B':1})
        r=run(s,operations=((0,attach),(100,lambda w:transport(w,('.5',0,0)))))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('.5'))
        self.assertEqual(D(r['final_states']['B']['position_m'][0]),D('1.1'))
        self.assertEqual(r['distance_constraints'][0]['status'],'active')

    def test_transport_to_air_uses_native_fall_and_contact_without_a_paid_jump(self):
        r=run(scene(1000),operations=((100,lambda w:transport(w,(0,0,'1.8'))),))
        self.assertEqual(r['metrics']['A']['jumps_started'],0)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])
        self.assertTrue(events(r,'body_contact'))
        self.assertFalse(events(r,'jump_takeoff'))

    def test_crouched_exit_uses_actual_pose_and_later_stand_checks_new_clearance(self):
        s=scene(800);command(s,'A',0,'crouch');command(s,'A',500,'stand')
        s['initial_colliders']=[wall('ceiling',x=10,hp=None,z='1.45',size=(2,2,'.1'))]
        r=run(s,operations=((300,transport),))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),10)
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'crouched')
        self.assertTrue(events(r,'stand_rejected'))

    def test_transport_rejects_velocity_replacement_and_stale_plans(self):
        saved=[]
        def prepare(w):
            ref=w.spatial_transitions.reference('A')
            with self.assertRaises(ValueError):w.spatial_transitions.prepare_transport((SpatialChange('A',1,
                reference_m=(10,-20,ref[2]),velocity_mps=(2,0,0)),),source='invalid_transport_probe')
            saved.append(w.spatial_transitions.prepare_transport((SpatialChange('A',1,reference_m=(10,-20,ref[2])),),source='stale_transport_probe'))
        def stale(w):
            with self.assertRaises(StaleSpatialPlan):w.spatial_transitions.commit(saved[0])
        r=run(scene(200),operations=((0,prepare),(100,stale)))
        self.assertFalse(r['spatial_transitions'])

    def test_same_clock_new_distance_constraint_invalidates_prepared_transport(self):
        for kind in ('fixed','moving'):
            with self.subTest(kind=kind):
                s=scene(200);s['encounter']['participants']['B']['position_m']=['1.1',-20]
                def prepare_attach_commit(w):
                    ref=w.spatial_transitions.reference('A')
                    plan=w.spatial_transitions.prepare_transport((SpatialChange('A',1,
                        reference_m=(10,ref[1],ref[2])),),source='stale_transport_distance_probe')
                    if kind=='fixed':
                        w.distance_constraints.attach_fixed('A',w.terrain_anchors.below('A',2),maximum_m=2,
                            expires_at_ms=2000,source='late_fixed_limit_probe',expected_life=1)
                    else:w.distance_constraints.attach('A','B',maximum_m=2,expires_at_ms=2000,
                        source='late_moving_limit_probe',expected_lives={'A':1,'B':1})
                    with self.assertRaises(StaleSpatialPlan):w.spatial_transitions.commit(plan)
                r=run(s,operations=((100,prepare_attach_commit),))
                self.assertFalse(r['spatial_transitions'])
                self.assertEqual(r['distance_constraints'][0]['status'],'active')
                self.assertEqual(D(r['final_states']['A']['position_m'][0]),0)

    def test_actual_released_knock_velocity_is_preserved_through_transport(self):
        from tests.test_knock_motion_combat import scene as heavy_scene
        s=heavy_scene(700)
        a=run(s);b=run(s,operations=((400,lambda w:transport(w,name='B')),))
        self.equivalent(a,b,translated=('B',))
        self.assertEqual(a['knock_impulses'][0]['status'],b['knock_impulses'][0]['status'])

    def test_stacked_grapple_group_uses_all_prospective_supports_together(self):
        s=scene(300)
        def stack(w):
            w.spatial_transitions.apply((SpatialChange('A',1,reference_m=(30,-20,'2.625')),),source='transport_stack_api_probe')
            link(w)
        r=run(s,operations=((0,stack),(100,transport)))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),40)
        self.assertEqual(D(r['final_states']['B']['position_m'][0]),40)
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'B')
        self.assertEqual(r['final_states']['B']['locomotion']['support_id'],'ground')
        self.assertFalse(events(r,'world_support_lost'));self.assertFalse(events(r,'body_contact'))

    def test_departing_carrier_does_not_teleport_an_unlinked_supported_body(self):
        s=scene(1000)
        def stack(w):w.spatial_transitions.apply((SpatialChange('A',1,reference_m=(30,-20,'2.625')),),source='transport_support_api_probe')
        r=run(s,operations=((0,stack),(100,lambda w:transport(w,name='B'))))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),30)
        self.assertEqual(D(r['final_states']['B']['position_m'][0]),40)
        self.assertTrue(events(r,'world_support_lost','A'))
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'ground')

    def test_exact_tether_limit_is_legal_without_numerical_escape_release(self):
        s=scene(300);s['encounter']['participants']['B']['position_m']=['1.1',-20]
        def attach(w):w.distance_constraints.attach('A','B',maximum_m=2,expires_at_ms=2000,
            source='transport_exact_limit_api_probe',expected_lives={'A':1,'B':1})
        r=run(s,operations=((0,attach),(100,lambda w:transport(w,('3.1',0,0)))))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('3.1'))
        self.assertEqual(r['distance_constraints'][0]['status'],'active')

    def test_actual_dash_landing_debt_and_flight_survive_transport(self):
        from tests.test_body_dashes_combat import scene as dash_scene
        s=dash_scene(1000);a=run(s);b=run(s,operations=((250,transport),))
        self.equivalent(a,b)
        self.assertEqual(a['metrics']['A']['dyspnea_paid'],b['metrics']['A']['dyspnea_paid'])
        self.assertEqual([e['time_ms'] for e in events(a,'body_launch_landed')],
            [e['time_ms'] for e in events(b,'body_launch_landed')])

    def test_exit_touching_wall_resolves_real_inward_contact_at_transport_clock(self):
        s=scene(100);command(s,'A',0,'walk')
        s['initial_colliders']=[wall('exit_face',x='10.35',hp=None,size=('.4',2,2))]
        # At100ms the body centre is.14m. Destination body front is10.29m;
        # choose the translation putting that front on the wall's10.15m face.
        r=run(s,operations=((100,lambda w:transport(w,('9.86',0,0))),))
        contact=events(r,'body_contact')[0]
        self.assertEqual(D(contact['time_ms']),100)
        self.assertEqual(tuple(map(D,r['final_states']['A']['locomotion']['velocity_mps'])),(0,0,0))


