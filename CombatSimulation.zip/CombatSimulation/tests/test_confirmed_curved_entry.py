"""Ordinary entries need actual confirmation; uncertain grazes retain their guard."""
from math import hypot
import unittest

from combat_sim.gravity_collisions import first_contact
from combat_sim.moving_gravity_collisions import moving_curve_contact
from combat_sim.mechanics.gravity import ProjectileTrajectory
from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
from combat_sim.hitboxes import Cuboid
from combat_sim.models import UnsupportedMechanicError


class ConfirmedCurvedEntryTests(unittest.TestCase):
    def flight(self,**kw):
        return PersistentProjectileTrajectory((-.15,-23.8,.6950575),
            (56.04682523854737,21.143595201716856,3.4207839197567123),.74,**kw)

    def wall(self):return Cuboid('west',('8.95',-20,'.9'),('.1','2.2','2.2'))

    def test_actual_prison_entry_has_a_confirmed_point_within_the_original_time_budget(self):
        p=self.flight();box=self.wall();begin=.14563636363636365;end=.19376470588235295
        with self.assertRaisesRegex(UnsupportedMechanicError,'unresolved'):
            moving_curve_contact(p,box,.02,begin,end)
        hit=moving_curve_contact(p,box,.02,begin,end,confirm_near_entry=True)
        expected=(8.9-.02-p.origin[0])/p.velocity[0]
        self.assertLessEqual(hit.time_lower_s,expected);self.assertGreaterEqual(hit.time_upper_s,expected)
        self.assertLessEqual(hit.time_upper_s-hit.time_lower_s,1e-12)
        self.assertGreaterEqual(hit.centre_m[0]+.02,8.9)

    def test_confirmatory_query_never_crosses_the_supplied_physical_interval(self):
        p=self.flight()
        with self.assertRaisesRegex(UnsupportedMechanicError,'unresolved'):
            moving_curve_contact(p,self.wall(),.02,.14563636363636365,.16111528104520403,confirm_near_entry=True)

    def test_genuine_clearance_ambiguity_is_never_declared_a_hit_or_miss(self):
        p=ProjectileTrajectory((-1,-.02000000001,1),(100,0,0),.04,gravity_mps2=0)
        box=Cuboid('box',(1,1,1),(2,2,2))
        with self.assertRaisesRegex(UnsupportedMechanicError,'unresolved'):
            first_contact(p,[box],.02,confirm_near_entry=True)

    def test_relative_motion_and_resizing_keep_the_actual_contact_surface(self):
        p=self.flight();box=self.wall();begin=.14563636363636365;end=.19376470588235295
        hit=moving_curve_contact(p,box,.02,begin,end,box_velocity=(1,0,0),
            box_size_rate_mps=(.2,0,0),confirm_near_entry=True)
        expected=(8.9-.02-p.origin[0]-.9*begin)/(p.velocity[0]-.9)
        self.assertLessEqual(hit.time_lower_s,expected);self.assertGreaterEqual(hit.time_upper_s,expected)
        self.assertLessEqual(hit.time_upper_s-hit.time_lower_s,1e-12)
        self.assertAlmostEqual(hit.surface_point_m[0],8.9+.9*(hit.time_upper_s-begin),places=12)

    def test_an_earlier_other_collider_still_wins(self):
        p=self.flight(max_step_s=.74);early=Cuboid('early',(1,-23.4,.8),('.1',1,1))
        hit=first_contact(p,[self.wall(),early],.02,confirm_near_entry=True)
        self.assertEqual(hit.object_id,'early')

    def test_confirmed_mode_does_not_invent_a_simultaneous_scene_priority(self):
        p=self.flight();other=Cuboid('other',self.wall().centre_m,self.wall().size_m)
        with self.assertRaisesRegex(UnsupportedMechanicError,'priority'):
            first_contact(p,[self.wall(),other],.02,confirm_near_entry=True)

    def test_refinement_selection_is_explicit_and_boolean(self):
        with self.assertRaises(ValueError):first_contact(self.flight(),[self.wall()],.02,confirm_near_entry='yes')
