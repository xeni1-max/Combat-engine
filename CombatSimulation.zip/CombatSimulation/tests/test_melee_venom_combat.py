"""Authored thrust/venom/replacement phases use the shared combat world.

Restrictions, life transitions and property changes are labelled engineering
probes. Ordinary scenarios exercise real casts, scripts, collision and damage.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
import unittest

from combat_sim.analysis import summarize
from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_motion_boundary_combat import CURRENT, scene as base_scene
from tests.test_world_colliders_combat import wall


def scene(horizon=1500,*,distance='1.1'):
    s=base_scene(horizon,(0,-20))
    s['encounter']['participants']['A']['character']='2E4'
    s['encounter']['participants']['B']['position_m']=[distance,-20]
    s['action_selection']['A'].update(start_ms=0,reload_when_empty=False)
    return s


def run(s,*,operations=(),profiles=PROFILES,interval=100,precision=50,effects=CURRENT):
    class Fixture(SharedEncounter):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            for when,op in operations:self.push(when,'fixture_melee',op)

        def _process(self,kind,p):
            if kind!='fixture_melee':return super()._process(kind,p)
            actor=self.fighters[p.get('actor','A')]
            if p['op']=='restriction':
                self.apply_action_restriction(actor.id,source='fixture:function_block',
                    functions=p.get('functions',['upper_body']),until_ms=D(p['until']))
            elif p['op']=='status':
                self.apply_target_status_additions(actor.id,{'disorientation':D(p.get('O',0)),
                    'instability':D(p.get('U',0))},actor.armor)
            elif p['op']=='armor':
                actor.armor=D(p['value']);self.thermal_recovery.invalidate(actor.id)
            elif p['op']=='kill':
                self.log('fixture_hp_zero',actor=actor.id,hp_before=actor.hp,damage_credit=False)
                actor.hp=D(0)
            elif p['op']=='revive':
                ok=self.life_cycles.revive(actor.id,expected_generation=p.get('generation',1),
                    hp=p.get('hp',5000),source='fixture:melee_life_restoration')
                self.log('fixture_life_result',actor=actor.id,success=ok)
            else:raise ValueError('Unknown melee fixture')

    with localcontext(Context(prec=precision)):
        return Fixture(s,profiles,precision=precision,sample_interval_ms=interval,
            body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,
            combat_locomotion_definition=effects,jump_definition=JUMP,climb_definition=CLIMB,
            projectile_physics_definition=PHYSICS).run()


def attached(r):return [e['effect'] for e in events(r,'blade_attached')]
def history(r):return DamageLedger.from_record(r['applied_hp_history'])


class MeleeVenomCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_base_thrust_has_real_midpoint_contact_power_statuses_and_one_payment(self):
        r=run(scene(300));hit=events(r,'impact_batch_resolved')[0]
        self.assertEqual(D(hit['time_ms']),230)
        self.assertEqual(D(hit['applied_hp_damage']),D('412.5'))
        self.assertAlmostEqual(D(hit['applied_armor_loss']),D(26429)/3080,places=35)
        self.assertEqual(events(r,'melee_contact')[0]['hit_parts'],['torso'])
        self.assertNotIn('projectile_id',hit['hits'][0])
        self.assertEqual(r['metrics']['A']['projectiles_released'],0)
        self.assertFalse(r['projectile_flights'])
        self.assertEqual(json.loads(json.dumps(r)),r)
        power=r['released_attack_power'][0]
        self.assertEqual(D(power['components']['strike']['output']),440)
        status=events(r,'self_status_applied','A')[0]
        self.assertEqual(status['additions'],{'disorientation':'150','instability':'150'})
        payments=events(r,'dyspnea_paid','A')
        self.assertEqual(len(payments),1)
        self.assertEqual((D(payments[0]['time_ms']),D(payments[0]['amount'])),(140,9))

    def test_replacement_timeline_is_impact_plus_600_then_250_active(self):
        r=run(scene())
        self.assertEqual([D(e['time_ms']) for e in events(r,'melee_contact')],[230,1310])
        self.assertEqual(D(events(r,'replacement_blade_available')[0]['time_ms']),830)
        self.assertEqual(D(events(r,'blade_grab_started')[0]['time_ms']),830)
        self.assertEqual(D(events(r,'blade_equipped')[0]['time_ms']),1080)
        self.assertEqual([D(e['time_ms']) for e in events(r,'ability_started','A')],[0,1080])
        self.assertEqual(len(events(r,'dyspnea_paid','A')),2)
        self.assertEqual(r['metrics']['A']['blade_grabs_completed'],1)

    def test_one_wound_reproduces_exact_legacy_total_while_target_walks_away(self):
        s=scene(8300);s['encounter']['participants']['B']['movement_direction']=[1,0]
        command(s,'B',400,'walk');r=run(s)
        self.assertEqual(len(attached(r)),1)
        self.assertTrue(events(r,'melee_missed'))
        self.assertAlmostEqual(D(r['final_states']['B']['hp']),D(191227)/28,places=30)
        self.assertAlmostEqual(D(r['final_states']['B']['armor']),D(435571)/3080,places=30)
        ledger=history(r)
        venom=sum((e.amount for e in ledger.entries if e.contribution.kind=='venom'),D(0))
        bleed=sum((e.amount for e in ledger.entries if e.contribution.kind=='bleeding'),D(0))
        self.assertAlmostEqual(venom,D(5997)/7,places=30)
        self.assertAlmostEqual(bleed,D('41.25'),places=30)
        self.assertEqual(D(events(r,'venom_blade_detached')[0]['time_ms']),1230)

    def test_continuous_venom_and_bleeding_locate_death_between_scheduled_events(self):
        s=scene(1000);s['encounter']['participants']['B']['initial_state']['hp']=500
        baseline=run(s,interval=None)
        death=D(events(baseline,'character_died','B')[0]['time_ms'])
        self.assertGreater(death,230);self.assertLess(death,830)
        t=(death-230)/1000
        venom=(D(17991)/28)*D(2)/3*t*t.sqrt()
        bleed=D('412.5')*(8*t-t*t/2)/320
        self.assertLess(abs(venom+bleed-D('87.5')),D('1e-20'))
        self.assertLess(abs(history(baseline).amount(target='B')-500),D('1e-20'))
        effect=next(e for e in baseline['effect_instances'] if e['kind']=='venom')
        self.assertEqual(effect['end_reason'],'target_life_ended')
        self.assertEqual(D(effect['ended_at_ms']),death)
        observed=run(s,interval=37,precision=80)
        self.assertLess(abs(D(events(observed,'character_died','B')[0]['time_ms'])-death),D('1e-20'))

    def test_attachment_moves_with_the_wounded_body_then_freezes_at_detachment(self):
        s=scene(1000);s['encounter']['participants']['B']['movement_direction']=[1,0]
        command(s,'B',400,'walk');r=run(s,interval=None)
        effect=next(e for e in r['effect_instances'] if e['kind']=='venom')
        contact=events(r,'melee_contact')[0]
        displacement=D(r['final_states']['B']['position_m'][0])-D('1.1')
        self.assertGreater(displacement,0)
        self.assertEqual(effect['attached'],True)
        self.assertAlmostEqual(D(effect['attachment_position_m'][0])-D(contact['location_m'][0]),displacement,places=30)
        s['encounter']['duration_ms']=1500;r=run(s,interval=None)
        effect=next(e for e in r['effect_instances'] if e['kind']=='venom')
        self.assertFalse(effect['attached'])
        self.assertEqual(effect['attachment_position_m'],events(r,'venom_blade_detached')[0]['attachment_position_m'])
        self.assertTrue(any(e.contribution.kind=='venom' and e.begin>=1230 for e in history(r).entries))

    def test_full_shield_has_zero_wound_delivery_without_a_zero_denominator(self):
        s=scene(300);s['encounter']['participants']['B']['initial_state']['shield']=1000
        r=run(s)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(D(r['final_states']['B']['armor']),150)
        self.assertEqual(D(r['metrics']['B']['shield_damage_received']),440)
        self.assertEqual(D(attached(r)[0]['delivery']),0)
        self.assertFalse(events(r,'bleeding_started'))
        self.assertEqual(history(r).amount(actor='A'),0)
        self.assertEqual(r['metrics']['A']['replacement_blades_summoned'],1)

    def test_partial_shield_snapshots_only_overflow_and_pre_hit_armor(self):
        s=scene(300);s['encounter']['participants']['B']['initial_state']['shield']=200
        r=run(s);e=attached(r)[0]
        self.assertEqual(D(e['damage_after_shield']),240)
        self.assertEqual(D(e['armor_snapshot']),150)
        expected=(D(240)**2-D(110)**2)/D(240)**2
        self.assertAlmostEqual(D(e['delivery']),expected,places=40)
        self.assertLess(D(r['final_states']['B']['armor']),150)

    def test_intrinsic_power_uses_instability_before_its_own_new_150(self):
        s=scene(300);s['encounter']['participants']['A']['initial_state']['instability']=1000
        r=run(s);power=r['released_attack_power'][0]
        self.assertEqual(D(power['instability_at_release']),770)
        self.assertEqual(D(power['components']['strike']['output']),363)
        self.assertEqual(D(attached(r)[0]['damage_after_shield']),363)

    def test_moving_out_of_the_locked_location_misses_and_retains_the_held_blade(self):
        s=scene(300,distance='.9');s['encounter']['participants']['B']['movement_direction']=[1,0]
        command(s,'B',0,'walk');r=run(s)
        self.assertEqual(len(events(r,'melee_missed')),1)
        self.assertFalse(attached(r));self.assertFalse(events(r,'self_status_applied','A'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),9)
        self.assertEqual(len(r['blade_items']),1)
        self.assertEqual(r['blade_items'][0]['status'],'held')

    def test_first_other_body_intercepts_including_friendly_fire(self):
        s=scene(300)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(team='A',position_m=['.65',-20])
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s)
        self.assertEqual(events(r,'melee_contact')[0]['target'],'C')
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertGreater(history(r).amount(actor='A'),0)
        self.assertEqual(history(r).amount(actor='A',eligible_only=True),0)

    def test_body_solid_blocks_the_blade_and_takes_raw_slash_without_actor_credit(self):
        s=scene(300);s['initial_colliders']=[wall(x='.65',hp=1000,size=('.1',2,2),z=1,
            blocking={'projectiles':False,'bodies':True,'areas':False})]
        r=run(s)
        self.assertEqual(events(r,'melee_contact')[0]['target'],'gate')
        self.assertEqual(D(r['world_collider_states']['gate']['hp']),560)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertFalse(attached(r));self.assertEqual(history(r).amount(),0)

    def test_projectile_only_barrier_does_not_block_the_declared_body_solid_melee_query(self):
        s=scene(300);s['initial_colliders']=[wall(x='.65',hp=1000,size=('.1',2,2),z=1,
            blocking={'projectiles':True,'bodies':False,'areas':False})]
        r=run(s)
        self.assertEqual(events(r,'melee_contact')[0]['target'],'B')
        self.assertEqual(D(r['world_collider_states']['gate']['hp']),1000)

    def test_two_simultaneous_thrusts_share_shield_and_armor_snapshots(self):
        s=scene(300);s['encounter']['participants']['A']['position_m']=[0,'-20.4']
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[0,'-19.6']
        s['action_selection']['C']=deepcopy(s['action_selection']['A'])
        s['encounter']['participants']['B']['initial_state']['shield']=600
        r=run(s);hit=next(e for e in events(r,'impact_batch_resolved') if e['target']=='B')
        self.assertEqual(len(hit['hits']),2)
        self.assertEqual([D(p['shield_absorbed']) for p in hit['hits']],[300,300])
        self.assertEqual(len(attached(r)),2)
        self.assertTrue(all(D(e['armor_snapshot'])==150 and D(e['damage_after_shield'])==140 for e in attached(r)))

    def test_real_gunfire_extends_thrust_preparation_and_melee_interrupts_sustained_gun_control(self):
        s=scene(1500);s['action_selection']['B']['start_ms']=0
        r=run(s)
        self.assertTrue(events(r,'gathering_extended','A'))
        self.assertGreater(D(events(r,'melee_contact')[0]['time_ms']),230)
        self.assertGreaterEqual(r['metrics']['B']['projectiles_released'],2)
        self.assertTrue(any(e['control']['actor']=='B' and e['control']['end_reason']=='instability'
            for e in events(r,'sustained_control_ended')))
        self.assertGreater(history(r).amount(actor='A'),0)
        self.assertGreater(history(r).amount(actor='B'),0)

    def test_upper_restriction_cancels_only_grab_and_a_new_grab_waits_for_expiry(self):
        r=run(scene(1500),operations=[(900,{'op':'restriction','until':1200})])
        self.assertEqual([D(e['time_ms']) for e in events(r,'blade_grab_started')],[830,1200])
        self.assertEqual([D(e['time_ms']) for e in events(r,'blade_equipped')],[1450])
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)
        self.assertGreater(history(r).amount(actor='A'),412.5)

    def test_lower_restriction_does_not_cancel_the_independent_hand_grab(self):
        r=run(scene(1200),operations=[(900,{'op':'restriction','until':1200,'functions':['lower_body']})])
        self.assertEqual([D(e['time_ms']) for e in events(r,'blade_equipped')],[1080])
        self.assertFalse(events(r,'controlled_action_cancelled','A'))

    def test_incoming_disorientation_extends_zero_base_grab_gathering(self):
        r=run(scene(1500),operations=[(800,{'op':'status','O':300}),(850,{'op':'status','O':100})])
        self.assertEqual(D(events(r,'replacement_blade_available')[0]['time_ms']),830)
        self.assertEqual(D(events(r,'blade_grab_started')[0]['time_ms']),1200)
        self.assertEqual(D(events(r,'blade_equipped')[0]['time_ms']),1450)

    def test_source_death_cancels_grab_but_preserves_summon_and_target_venom(self):
        r=run(scene(1700),operations=[(900,{'op':'kill'}),(1100,{'op':'revive'})])
        self.assertEqual([D(e['time_ms']) for e in events(r,'blade_grab_started')],[830,1100])
        self.assertEqual([D(e['time_ms']) for e in events(r,'blade_equipped')],[1350])
        self.assertEqual(events(r,'blade_equipped')[0]['life_generation'],2)
        self.assertEqual(events(r,'blade_equipped')[0]['blade']['source_life_generation'],1)
        ledger=history(r)
        self.assertTrue(any(e.contribution.kind=='venom' and e.begin>=900 and e.end<=1100 for e in ledger.entries))
        self.assertEqual([e['source_life_generation'] for e in attached(r)],[1,2])

    def test_summon_becomes_available_while_owner_is_dead_then_new_life_grabs_it(self):
        r=run(scene(1400),operations=[(400,{'op':'kill'}),(1000,{'op':'revive'})])
        self.assertEqual(D(events(r,'replacement_blade_available')[0]['time_ms']),830)
        self.assertEqual(D(events(r,'blade_grab_started')[0]['time_ms']),1000)
        self.assertEqual(D(events(r,'blade_equipped')[0]['time_ms']),1250)

    def test_death_before_payment_or_impact_does_not_create_a_blade_or_phantom_hit(self):
        for death,restoration,horizon,paid in ((100,150,250,0),(200,300,350,9)):
            r=run(scene(horizon),operations=[(death,{'op':'kill'}),(restoration,{'op':'revive'})])
            self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),paid)
            self.assertFalse(events(r,'melee_contact'));self.assertFalse(attached(r))
            self.assertEqual(len(r['blade_items']),1)

    def test_target_death_retires_old_venom_and_a_later_strike_binds_new_life(self):
        s=scene(1500);s['encounter']['participants']['B']['initial_state']['hp']=1
        r=run(s,operations=[(500,{'op':'revive','actor':'B'})])
        self.assertEqual([e['target_life_generation'] for e in attached(r)],[1,2])
        old=next(e for e in r['effect_instances'] if e['kind']=='venom' and e['target_life_generation']==1)
        self.assertEqual(old['end_reason'],'target_life_ended')
        ledger=history(r)
        self.assertEqual(ledger.amount(target='B',target_life_generation=1),1)
        self.assertFalse(any(e.target=='B' and e.target_life_generation==2 and e.end<D(1310) for e in ledger.entries))

    def test_cooldown_pause_does_not_pause_replacement_or_toxin_clocks(self):
        s=scene(2300);s['action_selection']['B'].update(abilities=['2'],start_ms=0)
        r=run(s)
        self.assertTrue(r['cooldown_pause_volumes'])
        self.assertEqual(D(events(r,'blade_grab_started')[0]['time_ms']),830)
        self.assertEqual(D(events(r,'blade_equipped')[0]['time_ms']),1080)
        self.assertEqual(D(events(r,'venom_blade_detached')[0]['time_ms']),1230)

    def test_summoned_blade_follows_owner_before_grabbing(self):
        s=scene(700);s['encounter']['participants']['A']['movement_direction']=[0,1]
        command(s,'A',400,'walk');r=run(s)
        blade=next(i for i in r['blade_items'] if i['status']=='summoning')
        self.assertEqual(D(blade['ready_at_ms']),830)
        self.assertGreater(dec(blade['position_m'][1]),D('-20.2'))
        self.assertAlmostEqual(dec(blade['position_m'][1]),dec(r['final_states']['A']['position_m'][1])-D('.2'),places=25)

    def test_automatic_grab_can_overlap_constant_sprint_without_unlocking_attacks(self):
        s=scene(1200);s['encounter']['participants']['A']['movement_direction']=[0,1]
        command(s,'A',400,'sprint');r=run(s)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'sprinting')
        self.assertEqual(D(r['final_states']['A']['locomotion']['nominal_speed_mps']),14)
        self.assertEqual(D(events(r,'blade_grab_started')[0]['time_ms']),830)
        self.assertEqual(D(events(r,'blade_equipped')[0]['time_ms']),1080)
        self.assertEqual(len(events(r,'ability_started','A')),1)

    def test_posture_and_weapon_use_independent_actions_and_actual_lowered_hand_geometry(self):
        s=scene(400,distance='.9');command(s,'A',0,'crouch');r=run(s)
        contact=events(r,'melee_contact')[0]
        frame=next(a for a in r['melee_attacks'] if a['attack_id']==contact['attack_id'])
        self.assertEqual(D(frame['origin_m'][2]),D('.375'))
        self.assertTrue(events(r,'crouch_completed','A'))
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'crouched')

    def test_two_attachments_keep_their_own_pre_hit_armor_and_do_not_follow_later_armor_changes(self):
        r=run(scene(),operations=[(900,{'op':'armor','actor':'B','value':0})])
        first,second=attached(r)
        self.assertEqual(D(first['armor_snapshot']),150)
        self.assertEqual(D(first['delivery']),D('0.9375'))
        self.assertEqual(D(second['armor_snapshot']),0)
        self.assertEqual(D(second['delivery']),1)
        self.assertEqual(D(next(e for e in r['effect_instances'] if e['id']==first['id'])['delivery']),D('0.9375'))

    def test_existing_2e4_basics_use_running_8_jump_4_and_sprint_14(self):
        s=scene(3000,distance=100);s['action_selection']['A']['start_ms']=100000
        command(s,'A',0,'run');command(s,'A',1000,'jump');command(s,'A',2000,'sprint')
        r=run(s)
        self.assertEqual(D(events(r,'jump_takeoff','A')[0]['velocity_mps'][2]),4)
        self.assertEqual(D(r['final_states']['A']['locomotion']['nominal_speed_mps']),14)

    def test_live_toxin_resistance_tracks_real_matured_shield_debt(self):
        s=scene(21230,distance=30)
        s['encounter']['participants']['A']['position_m']=[29,-20]
        s['action_selection']['A']['start_ms']=20000
        s['encounter']['participants']['B'].update(character='2E4',initial_state={'shield':300})
        s['encounter']['participants']['C']={'character':'1E2','team':'A','position_m':[30,-50],
            'facing':'+x','initial_state':{'shield':0}}
        s['action_selection']['C']=deepcopy(s['action_selection']['B']);s['action_selection']['C']['start_ms']=0
        profiles=deepcopy(PROFILES);profiles['1E2']['abilities']['1']['weapon_cooldown_ms']=100000
        r=run(s,profiles=profiles)
        effect=attached(r)[0];strike=next(e for e in events(r,'impact_batch_resolved') if e['hits'][0].get('attack_id'))
        self.assertEqual(D(effect['start']),20230)
        remaining=D(300)-D(strike['state_before']['shield'])
        b=remaining/400
        delivery=D(effect['delivery']);tp=D(700)
        growing=delivery/tp*((tp*tp-10*D(36)**2)*D(2)/3*b**D('1.5')
            -D(2880)*D(2)/5*b**D('2.5')-D(160)*D(2)/7*b**D('3.5'))
        steady=delivery*(tp*tp-10*(D(36)+remaining/100)**2)/tp
        expected=growing+D(2)/3*steady*(1-b**D('1.5'))
        ledger=history(r)
        actual=sum((e.amount for e in ledger.entries if e.contribution.effect_id==effect['id']),D(0))
        self.assertLess(abs(actual-expected),D('1e-8'))
        self.assertTrue(any(p['inputs'].get('curve_kind')=='venom_live_resistance_v1'
            for e in events(r,'continuous_damage_resolved') for p in e['components']))

    def test_venom_works_with_live_fluid_heat_shield_recovery(self):
        s=scene(21600,distance=30)
        s['encounter']['participants']['A']['character']='1E1'
        s['action_selection']['A'].update(abilities=['4'],start_ms=0)
        s['encounter']['participants']['B'].update(character='2E4',initial_state={'shield':4000})
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(team='A',position_m=[29,-20],facing='+x',initial_state={'shield':0})
        s['action_selection']['C']=deepcopy(s['action_selection']['B']);s['action_selection']['C']['start_ms']=20770
        profiles=deepcopy(PROFILES);profiles['2E4']['resistances']['heat']=2000
        baseline=run(s,profiles=profiles,interval=None)
        other=run(s,profiles=profiles,interval=137,precision=80)
        self.assertTrue(events(baseline,'thermal_recovery_activated'))
        self.assertTrue(attached(baseline))
        self.assertGreater(sum((e.amount for e in history(baseline).entries if e.contribution.kind=='venom'),D(0)),0)
        self.assertLess(abs(D(baseline['final_states']['B']['hp'])-D(other['final_states']['B']['hp'])),D('1e-8'))

    def test_precision_observations_and_actor_order_keep_contact_and_replacement_cadence(self):
        s=scene(2300);baseline=run(s,interval=None)
        for precision,interval in ((50,37),(80,113)):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,precision=precision,interval=interval)
            for kind in ('melee_contact','blade_grab_started','blade_equipped'):
                self.assertEqual([e['time_ms'] for e in events(r,kind)],[e['time_ms'] for e in events(baseline,kind)])
            self.assertLess(abs(D(r['final_states']['B']['hp'])-D(baseline['final_states']['B']['hp'])),D('1e-20'))
            self.assertEqual(len(summarize(r)['participants']),2)

    def test_unknown_melee_mode_rejects_before_simulation(self):
        bad=deepcopy(CURRENT);bad['melee']={'mode':'unknown'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'Timed melee'):run(scene(),effects=bad)

    def test_unsupported_melee_geometry_or_replacement_rules_are_not_silently_ignored(self):
        for section,key,value in (('melee_geometry','aim','track_target'),
                ('melee_geometry','blocking','projectile_solids'),('replacement_blade','grab_delay_anchor','active_end'),
                ('replacement_blade','dyspnea',{'kind':'action','base_value':1})):
            with self.subTest(section=section,key=key):
                profiles=deepcopy(PROFILES);profiles['2E4']['abilities']['1'][section][key]=value
                with self.assertRaisesRegex(UnsupportedMechanicError,'Unsupported melee'):
                    run(scene(),profiles=profiles)


if __name__=='__main__':unittest.main()
