"""Actual 1E1 swap, stock, poison carriers and their shared combat interactions."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from tests.test_equilibrium_combat import scene as base_scene,run
from tests.test_mobile_combat import PROFILES,command,events
from tests.test_impact_bindings_combat import add
from tests.test_world_colliders_combat import wall


def scene(duration=3000,*,target=30,shield=0):
    s=base_scene(duration,character='1E1');s['id']='actual_1e1_launcher'
    s['encounter']['participants']['B']['position_m']=[target,-20]
    s['encounter']['participants']['B']['initial_state']['shield']=shield
    s['action_selection']['A'].update(abilities=['Ultimate','1'],start_ms=0,reload_when_empty=False)
    return s


def world_target(s,point=(30,-20,0)):
    s['action_selection']['A']['ability_targets']={'1':{'kind':'world_point','point_m':list(point)}}


def empty_scene(duration=16000):
    s=scene(duration,target=100);world_target(s);return s


def revival_scene():
    s=scene(4100);s['encounter']['participants']['B']['character']='2E4'
    s['encounter']['participants']['B']['initial_state']['hp']=300
    add(s,'C',['28.9',-20],character='1E2',team='A');s['encounter']['participants']['C']['initial_state']['hp']=500
    s['action_selection']['B'].update(abilities=['1'],start_ms=0,reload_when_empty=False)
    return s


class LauncherCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=70));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for n,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=n)
            self.assertLess(abs(supplied-D(r['final_states'][n]['hp'])-ledger.amount(target=n)),D('1e-8'))
        return ledger

    def test_actual_swap_uses_source_active_cost_and_successful_equip_cooldown(self):
        r=run(scene(600));row=r['weapon_swaps'][0]
        self.assertEqual(D(row['completed_at_ms'])-D(row['active_at_ms']),400)
        paid=next(e for e in events(r,'dyspnea_paid','A') if e['ability']=='Ultimate')
        self.assertEqual((D(paid['base_value']),D(paid['amount'])),(D('2.5'),D('6.25')))
        self.assertEqual(paid['phase'],'active_start')
        clock=next(e for e in events(r,'cooldown_started','A') if e['ability']=='Ultimate')
        self.assertEqual(clock['time_ms'],row['completed_at_ms'])
        self.assertEqual(D(clock['clock']['remaining_work_ms']),65000)
        self.assertEqual(r['weapon_inventories']['A']['rounds'],10);self.conserved(r)

    def test_actual_grenade_has_one_firing_payment_and_chemical_payload_without_direct_hp_hit(self):
        r=run(scene(1500,shield=4000));p=r['projectile_flights'][0]
        firing=[e for e in events(r,'dyspnea_paid','A') if e['ability']=='1'];self.assertEqual(len(firing),1)
        self.assertEqual(firing[0]['phase'],'active_firing_end');self.assertEqual(D(firing[0]['base_value']),D('3.5'))
        before=D(firing[0]['before']);self.assertEqual(D(firing[0]['amount']),(D('3.5')+before/100)**2)
        self.assertEqual(p['contact_payload']['poison'],{'radius_m':5,'toxicity':1200,'duration_ms':8000})
        self.assertEqual(p['definition_snapshot']['execution_model'],'poison_projectile')
        self.assertEqual(p['definition_snapshot']['effort_source_ability'],'Ultimate')
        self.assertEqual(r['released_attack_power'][0]['category'],'intrinsic_momentary')
        self.assertEqual(D(r['released_attack_power'][0]['components']['projectile']['output']),0)
        self.assertEqual(D(r['metrics']['B']['direct_hp_damage_received']),0)
        self.assertEqual(D(r['final_states']['B']['shield']),4000);self.assertEqual(D(r['final_states']['B']['armor']),150)
        self.assertLess(D(r['final_states']['B']['hp']),8140);self.assertFalse(events(r,'delayed_blast'));self.conserved(r)

    def test_intrinsic_sustained_swap_and_released_chemistry_do_not_gain_extrinsic_interrupts(self):
        s=scene(1500);s['encounter']['participants']['A']['initial_state']['instability']=800
        r=run(s);self.assertEqual(r['weapon_swaps'][0]['status'],'completed')
        self.assertLess(D(r['weapon_swaps'][0]['completed_at_ms']),800)
        self.assertEqual(r['projectile_flights'][0]['contact_payload']['poison']['toxicity'],1200)
        self.assertFalse([c for c in r['sustained_controls'] if c['actor']=='A']);self.conserved(r)

    def test_death_before_swap_payment_grants_no_mode_stock_cost_or_cooldown(self):
        s=scene(500);s['encounter']['participants']['A']['initial_state'].update(hp=1,disorientation=1000)
        s['action_selection']['B']['start_ms']=0;r=run(s)
        self.assertFalse(r['final_states']['A']['alive']);self.assertEqual(r['weapon_inventories']['A']['mode'],'main')
        self.assertEqual(r['weapon_swaps'][0]['status'],'cancelled')
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)
        self.assertFalse([e for e in events(r,'cooldown_started','A') if e['ability']=='Ultimate']);self.conserved(r)

    def test_death_during_paid_swap_keeps_cost_but_grants_no_ammunition(self):
        s=scene(600);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=0;r=run(s)
        self.assertFalse(r['final_states']['A']['alive']);self.assertEqual(r['weapon_inventories']['A']['rounds'],0)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('6.25'))
        self.assertFalse([e for e in events(r,'cooldown_started','A') if e['ability']=='Ultimate']);self.conserved(r)

    def test_death_before_firing_end_spends_no_round_or_firing_cost(self):
        s=scene(1200);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=600;r=run(s)
        self.assertFalse(r['final_states']['A']['alive']);self.assertEqual(r['weapon_inventories']['A']['rounds'],10)
        self.assertFalse(events(r,'projectile_released','A'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('6.25'));self.conserved(r)

    def test_released_grenade_and_cloud_survive_source_death(self):
        s=scene(2000);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=900;r=run(s)
        death=D(events(r,'character_died','A')[0]['time_ms']);burst=events(r,'poison_grenade_detonated','A')[0]
        self.assertGreater(D(burst['time_ms']),death);self.assertEqual(burst['source_life_generation'],1)
        self.assertLess(D(r['final_states']['B']['hp']),8140);self.assertEqual(r['weapon_inventories']['A']['rounds'],9);self.conserved(r)

    def test_ten_rounds_return_through_the_same_paid_swap_before_main_fire(self):
        r=run(empty_scene());self.assertEqual(len(events(r,'launcher_round_consumed')),10)
        swaps=r['weapon_swaps'];self.assertEqual([s['to_mode'] for s in swaps],['launcher','main'])
        self.assertEqual(D(swaps[1]['completed_at_ms'])-D(swaps[1]['active_at_ms']),400)
        self.assertEqual(r['weapon_inventories']['A']['mode'],'main');self.assertNotIn('1',r['final_states']['A']['ammo'])
        p=r['projectile_flights'];self.assertEqual([f['definition_snapshot']['execution_model'] for f in p[:10]],['poison_projectile']*10)
        self.assertEqual(p[10]['definition_snapshot']['execution_model'],'projectile_delayed_area')
        self.assertGreaterEqual(D(p[10]['released_at_ms']),D(p[9]['released_at_ms'])+1150)
        self.assertEqual(len([e for e in events(r,'cooldown_started','A') if e['ability']=='Ultimate']),1);self.conserved(r)

    def test_last_grenade_remains_poison_after_return_to_main_weapon(self):
        r=run(empty_scene());last=r['projectile_flights'][9];returned=D(r['weapon_swaps'][1]['completed_at_ms'])
        burst=next(e for e in events(r,'poison_grenade_detonated') if e['projectile_id']==last['id'])
        self.assertGreater(D(burst['time_ms']),returned)
        self.assertFalse([e for e in events(r,'delayed_blast') if e['projectile_id']==last['id']]);self.conserved(r)

    def test_qard_released_before_equip_keeps_original_damage_and_delayed_blast(self):
        s=scene(2500,target=100);s['action_selection']['A']['abilities']=['1','Ultimate'];r=run(s)
        first=r['projectile_flights'][0];self.assertEqual(first['definition_snapshot']['execution_model'],'projectile_delayed_area')
        burst=next(e for e in events(r,'delayed_blast') if e['projectile_id']==first['id'])
        self.assertGreater(D(burst['time_ms']),D(r['weapon_swaps'][0]['completed_at_ms']))
        self.assertGreater(D(r['metrics']['B']['direct_hp_damage_received']),0);self.conserved(r)

    def test_physical_function_loss_cancels_swap_without_free_stock(self):
        def block(w):w.apply_action_restriction('A',source='launcher_control_api_probe',functions=['upper_body'],until_ms=2000)
        r=run(scene(800),operations=((100,block),))
        self.assertEqual(r['weapon_swaps'][0]['status'],'cancelled');self.assertEqual(r['weapon_inventories']['A']['rounds'],0)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('6.25'));self.conserved(r)

    def test_cancelled_empty_return_does_not_refill_or_allow_free_main_fire(self):
        def block(w):w.apply_action_restriction('A',source='launcher_return_api_probe',functions=['upper_body'],until_ms=20000)
        s=empty_scene();s['action_selection']['A']['reload_when_empty']=True
        r=run(s,operations=((14100,block),))
        self.assertEqual(r['weapon_inventories']['A']['mode'],'launcher');self.assertEqual(r['weapon_inventories']['A']['rounds'],0)
        self.assertEqual(r['weapon_swaps'][-1]['status'],'cancelled')
        self.assertEqual(len(r['projectile_flights']),10);self.assertFalse(events(r,'reload_requested','A'));self.conserved(r)

    def test_finite_terrain_intercepts_without_unlisted_material_hp_damage(self):
        s=scene(2000);s['initial_colliders']=[wall('cover',x=6,z=1,hp=2000,size=('.2',4,2))]
        r=run(s);self.assertEqual(D(r['world_collider_states']['cover']['hp']),2000)
        self.assertEqual(r['projectile_flights'][0]['status'],'collided');self.assertTrue(events(r,'poison_grenade_detonated'))
        self.assertEqual(D(r['final_states']['B']['hp']),8140);self.conserved(r)

    def test_explicit_friendly_shot_exposes_source_and_teammate_without_enemy_credit(self):
        s=scene(1600,target=2);s['encounter']['participants']['B']['team']='A';world_target(s,(2,-20,1))
        r=run(s);self.assertEqual({e['target'] for e in r['poison_exposures']},{'A','B'})
        ledger=self.conserved(r);self.assertGreater(ledger.amount(actor='A'),0);self.assertEqual(ledger.amount(actor='A',eligible_only=True),0)

    def test_no_enemy_utility_equip_still_works_without_inventing_a_shot(self):
        s=scene(1000);s['encounter']['participants']['B']['team']='A';r=run(s)
        self.assertEqual(r['weapon_inventories']['A']['rounds'],10);self.assertFalse(events(r,'projectile_released','A'));self.conserved(r)

    def test_lower_body_leap_and_weapon_swap_keep_independent_owners(self):
        s=scene(1400);s['action_selection']['A']['abilities']=['Ultimate','3','1'];r=run(s)
        starts=events(r,'ability_started','A');self.assertEqual([(e['ability'],D(e['time_ms'])) for e in starts[:2]],[('Ultimate',D(0)),('3',D(0))])
        self.assertTrue(r['body_leaps']);self.assertEqual(r['weapon_swaps'][0]['status'],'completed');self.conserved(r)

    def test_actual_beam_persists_while_launcher_firing_uses_released_poison(self):
        s=scene(3500);s['encounter']['participants']['B']['character']='2E4'
        s['encounter']['participants']['B']['initial_state']['shield']=4000
        s['action_selection']['A']['abilities']=['Ultimate','4','1'];r=run(s)
        beam=events(r,'beam_deployed','A')[0];grenade=events(r,'projectile_released','A')[0]
        self.assertLess(D(grenade['time_ms']),D(beam['leave_ms']));self.assertTrue(events(r,'poison_grenade_detonated'))
        self.assertLess(D(r['final_states']['B']['shield']),4000);self.assertLess(D(r['final_states']['B']['hp']),9080);self.conserved(r)

    def test_first_collision_on_block_creates_gas_without_spending_block_hp(self):
        s=scene(1800);s['encounter']['participants']['B']['character']='2E4'
        s['action_selection']['B'].update(abilities=['basic_8'],held_blocks=['basic_8'],start_ms=1100,reload_when_empty=False)
        r=run(s)
        self.assertTrue(any(e.get('block_layer_id') for e in events(r,'projectile_body_collision')))
        self.assertTrue(events(r,'poison_grenade_detonated'));self.assertTrue(all(D(b['hp'])==800 for b in r['block_layers']))
        self.assertLess(D(r['final_states']['B']['hp']),9080);self.conserved(r)

    def test_actual_duplication_field_copies_released_chemistry_without_another_round(self):
        s=scene(1600);world_target(s);add(s,'C',[0,-30],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['Ultimate'],start_ms=0,reload_when_empty=False,
            ability_targets={'Ultimate':{'kind':'world_point','point_m':[15,-20,1]}})
        r=run(s);self.assertEqual(len(events(r,'launcher_round_consumed')),1)
        self.assertEqual(len(r['poison_grenade_bursts']),2)
        self.assertEqual({f['definition_snapshot']['execution_model'] for f in r['projectile_flights']},{'poison_projectile'})
        self.assertEqual({e['toxicity'] for e in r['poison_volumes']},{'1200'});self.conserved(r)

    def test_actual_gas_death_can_trigger_earned_2e4_revival_with_a_fresh_life(self):
        r=run(revival_scene());restored=events(r,'life_restored','B')[0];death=events(r,'character_died','B')[0]
        self.assertEqual(D(restored['time_ms'])-D(death['time_ms']),2000)
        self.assertEqual(r['revival_attempts'][0]['status'],'completed')
        self.assertEqual({e['target_life_generation'] for e in r['poison_exposures'] if e['target']=='B'},{1,2});self.conserved(r)

    def test_ultimate_can_re_equip_after_real_cooldown_without_stacking_old_stock(self):
        s=scene(66000);s['action_selection']['A']['abilities']=['Ultimate'];r=run(s)
        self.assertEqual(len(r['weapon_swaps']),2);self.assertEqual(r['weapon_inventories']['A']['rounds'],10)
        first,second=r['weapon_swaps'];self.assertGreaterEqual(D(second['selected_at_ms'])-D(first['completed_at_ms']),65000)
        self.conserved(r)

    def test_unreachable_ballistic_target_produces_physical_miss_for_both_carriers(self):
        for character,abilities in (('1E1',['Ultimate','1']),('1E2',['Ultimate'])):
            s=scene(4500);s['encounter']['participants']['A'].update(character=character,position_m=[-230,230])
            s['encounter']['participants']['B']['position_m']=[230,-230]
            s['action_selection']['A']['abilities']=abilities;r=run(s)
            first=r['projectile_flights'][0];self.assertEqual(first['aim_solver']['range_limited_aim']['rule'],'algebraically_unreachable_target_range_proxy')
            self.assertEqual(D(r['final_states']['B']['hp']),8140);self.conserved(r)

    def test_precision_observation_order_and_ambient_context_keep_actual_cast_outcomes(self):
        s=scene(3000);a=run(s,interval=100)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        with localcontext(Context(prec=28)):b=run(s,interval=17,precision=80)
        self.assertEqual(a['weapon_inventories'],b['weapon_inventories'])
        self.assertEqual(len(a['poison_grenade_bursts']),len(b['poison_grenade_bursts']))
        for n in a['final_states']:self.assertLess(abs(D(a['final_states'][n]['hp'])-D(b['final_states'][n]['hp'])),D('1e-8'))
        self.conserved(a);self.conserved(b)

    def test_capacity_wait_does_not_overdraw_or_grant_free_stock(self):
        s=scene(1400);s['encounter']['participants']['A']['initial_state']['dyspnea']=100
        s['action_selection']['A']['abilities']=['Ultimate']
        r=run(s);self.assertGreater(D(r['weapon_swaps'][0]['selected_at_ms']),0)
        self.assertEqual(r['weapon_swaps'][0]['status'],'completed')
        self.assertTrue(all(D(e['after'])<=100 for e in events(r,'dyspnea_paid','A')))
        self.assertEqual(len([e for e in events(r,'dyspnea_paid','A') if e['ability']=='Ultimate']),1);self.conserved(r)

    def test_restored_source_retains_loaded_inventory_after_cancelled_firing(self):
        s=scene(2000);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=600
        def restore(w):self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='launcher_inventory_life_probe'))
        r=run(s,operations=((1200,restore),));birth=events(r,'life_restored','A')[0]
        self.assertEqual(birth['state']['weapon_inventory']['rounds'],10);self.assertEqual(len(r['weapon_swaps']),1)
        self.assertTrue(any(f['actor']=='A' and f['source_life_generation']==2 for f in r['projectile_flights']))
        self.conserved(r)

    def test_restored_source_does_not_reinterpret_its_old_released_cloud(self):
        s=scene(2200);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=900
        def restore(w):self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='launcher_released_life_probe'))
        r=run(s,operations=((1400,restore),));self.assertEqual(len(r['actor_lives']['A']),2)
        self.assertEqual(r['poison_volumes'][0]['source_life_generation'],1)
        self.assertEqual(r['poison_grenade_bursts'][0]['source_life_generation'],1);self.conserved(r)

    def test_native_pause_field_freezes_both_ultimate_and_weapon_cooldown_work(self):
        s=scene(6500);world_target(s)
        s['action_selection']['B'].update(abilities=['2'],start_ms=0,reload_when_empty=False)
        r=run(s);shots=events(r,'projectile_released','A');self.assertGreaterEqual(len(shots),2)
        self.assertGreater(D(shots[1]['time_ms'])-D(shots[0]['time_ms']),1470)
        first=D(r['weapon_swaps'][0]['completed_at_ms']);remaining=D(r['final_states']['A']['cooldown_clocks']['Ultimate']['remaining_work_ms'])
        self.assertGreater(remaining,65000-(6500-first));self.conserved(r)

    def test_observation_horizon_does_not_finish_an_uncompleted_swap(self):
        r=run(scene(400));self.assertEqual(r['weapon_swaps'][0]['status'],'active')
        self.assertEqual(r['weapon_inventories']['A']['mode'],'main');self.assertEqual(r['weapon_inventories']['A']['rounds'],0)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('6.25'));self.assertFalse(events(r,'projectile_released','A'));self.conserved(r)

    def test_two_real_casters_have_separate_inventory_cooldown_and_chemical_sources(self):
        s=scene(1700);add(s,'C',[0,-30],character='1E1',team='A')
        s['action_selection']['C'].update(abilities=['Ultimate','1'],start_ms=0,reload_when_empty=False)
        r=run(s);self.assertEqual(set(r['weapon_inventories']),{'A','C'})
        self.assertEqual([r['weapon_inventories'][n]['rounds'] for n in ('A','C')],[9,9])
        self.assertEqual({v['actor'] for v in r['poison_volumes']},{'A','C'});self.conserved(r)

    def test_ready_re_equip_replaces_empty_launcher_without_forced_back_and_forth(self):
        s=empty_scene(66600)
        def block(w):w.apply_action_restriction('A',source='launcher_ready_return_probe',functions=['upper_body'],until_ms=66000)
        r=run(s,operations=((14021,block),))
        self.assertEqual([row['to_mode'] for row in r['weapon_swaps']],['launcher','launcher'])
        self.assertEqual(r['weapon_inventories']['A']['rounds'],10);self.conserved(r)


if __name__=='__main__':unittest.main()
