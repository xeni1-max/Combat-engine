"""Actual 1E2 fence through owned summon, material/contact, binding and HP paths."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.binding import escape_work
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from tests.test_motion_boundary_combat import scene as base_scene
from tests.test_binding_combat import run as configured_run,control
from tests.test_equilibrium_combat import rules
from tests.test_mobile_combat import command,events,PROFILES
from tests.test_grapple_links_combat import force


def scene(duration=1000,*,target=(30,-20),point=(30,-20,0),axis='y',explicit=True):
    s=base_scene(duration,(0,-20));s['id']='actual_1e2_fence'
    s['encounter']['participants']['B']['position_m']=list(target)
    s['action_selection']['A'].update(abilities=['5'],start_ms=0,reload_when_empty=False)
    if explicit:s['action_selection']['A']['ability_targets']={'5':{'kind':'world_point','point_m':list(point),'axis':axis}}
    return s


def run(s,**kw):return configured_run(s,rules=rules(),**kw)


class SegmentFieldCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-ledger.amount(target=name)),D('1e-8'))
        return ledger

    def test_actual_five_source_panels_summon_at300_without_dyspnea(self):
        r=run(scene());f=r['segment_fields'][0]
        self.assertEqual((D(f['deployed_at_ms']),D(f['expiry_ms'])),(300,6300))
        self.assertEqual(len(f['panel_ids']),5)
        self.assertFalse(events(r,'dyspnea_paid','A'))
        self.assertFalse(events(r,'self_status_applied','A'))
        self.assertEqual(D(events(r,'cooldown_started','A')[0]['time_ms']),0)
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['5']),9000)
        self.assertEqual({e.contribution.kind for e in self.conserved(r).entries},{'electrocution'})
        self.assertLess(abs(D(r['final_states']['B']['hp'])-D('7599.6875')),D('1e-8'))

    def test_source_dimensions_and_material_immunities_are_independent_per_panel(self):
        r=run(scene());f=r['segment_fields'][0]
        objects=r['world_collider_states']
        # The registry's canonical result is a map, independent of contact rows.
        for key in f['panel_ids']:
            obj=objects[key];p=obj['parts'][0]
            self.assertEqual((D(obj['hp']),D(obj['max_hp'])),(1500,1500))
            self.assertEqual({*obj['damage_immunities']},{'toxin','electrocution'})
            size=[D(b)-D(a) for a,b in zip(p['minimum_m'],p['maximum_m'])]
            self.assertEqual(size,[D('.1'),D(4),D('1.5')])
            self.assertEqual(obj['blocking'],{'projectiles':True,'bodies':False,'areas':False})

    def test_seam_contact_does_not_double_damage_or_binding(self):
        r=run(scene(target=(30,-18)));self.conserved(r)
        self.assertEqual(len(r['segment_field_contacts']),1)
        self.assertEqual(len(r['binding_instances']),1)
        self.assertEqual(len(r['released_damage_streams']),1)
        self.assertLess(abs(D(r['final_states']['B']['hp'])-D('7599.6875')),D('1e-8'))

    def test_no_enemy_world_target_and_friendly_fire_use_actual_bodies(self):
        s=scene();s['encounter']['participants']['B']['team']='A'
        r=run(s);self.conserved(r)
        self.assertIsNone(events(r,'ability_started','A')[0]['target'])
        self.assertEqual(len(r['binding_instances']),1)
        self.assertLess(D(r['final_states']['B']['hp']),8140)

    def test_default_target_location_and_axis_are_frozen_at_selection(self):
        s=scene(explicit=False);command(s,'B',0,'walk')
        r=run(s);self.conserved(r);f=r['segment_fields'][0]
        self.assertEqual(list(map(D,f['location_m'])),[30,-20,0])
        self.assertEqual(f['axis'],'y')

    def test_caster_can_be_electrocuted_by_its_own_screen(self):
        r=run(scene(point=(0,-20,0)));ledger=self.conserved(r)
        self.assertLess(abs(ledger.amount(actor='A',target='A')-D('540.3125')),D('1e-8'))
        self.assertEqual(r['binding_instances'][0]['target'],'A')
        self.assertEqual(D(r['damage_credit_totals']['A']['eligible_hp_dealt']),0)

    def test_personal_shield_absorbs_pressure_while_body_contact_still_binds(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['shield']=1000
        r=run(s);self.conserved(r)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(D(r['final_states']['B']['shield']),440)
        self.assertEqual(r['binding_instances'][0]['kind'],'lower_body')

    def test_common_break_releases_binding_without_instant_rebind_or_immunity(self):
        s=scene(2500);control(s,400,command='break_binding')
        r=run(s);self.conserved(r);binding=r['binding_instances'][0]
        self.assertEqual(len(r['binding_instances']),1)
        self.assertEqual(binding['end_reason'],'break_escaped')
        expected=D(400)+escape_work(2,8140)*50
        self.assertLess(abs(D(binding['ended_at_ms'])-expected),D('1e-8'))
        self.assertLess(abs(D(r['final_states']['B']['hp'])-(8140-D('771.875')*D('2.2'))),D('1e-8'))

    def test_fence_expiry_releases_binding_and_does_not_leave_electrical_residual(self):
        r=run(scene(7000));self.conserved(r)
        self.assertEqual(r['segment_fields'][0]['end_reason'],'field_expired')
        self.assertEqual(D(r['segment_field_contacts'][0]['ended_at_ms']),6300)
        self.assertLess(abs(D(r['final_states']['B']['hp'])-(8140-D('771.875')*6)),D('1e-8'))

    def test_two_independent_fences_stack_but_each_still_has_five_parts(self):
        s=scene();s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[0,-25]
        s['action_selection']['C']=deepcopy(s['action_selection']['A'])
        r=run(s);self.conserved(r)
        self.assertEqual(len(r['segment_fields']),2);self.assertEqual(len(r['binding_instances']),2)
        self.assertLess(abs(D(r['final_states']['B']['hp'])-(8140-D('771.875')*D('1.4'))),D('1e-8'))

    def test_walking_body_contacts_and_freezes_at_the_actual_screen_face(self):
        s=scene(1800,target=(28,-20));s['encounter']['participants']['B']['facing']='+x';command(s,'B',0,'walk')
        r=run(s);self.conserved(r);c=r['segment_field_contacts'][0]
        self.assertLess(abs(D(c['applied_at_ms'])-930),D('1e-8'))
        self.assertLess(abs(D(r['final_states']['B']['position_m'][0])-D('29.8')),D('1e-8'))
        self.assertEqual(c['status'],'active')
        self.assertEqual(r['binding_instances'][0]['status'],'active')
        self.assertLess(abs(D(r['final_states']['B']['hp'])-(8140-D('771.875')*D('.87'))),D('1e-8'))

    def test_accelerating_body_contacts_during_the_walking_transition(self):
        s=scene(700,target=('29.79',-20));s['encounter']['participants']['B']['facing']='+x'
        command(s,'B',400,'walk');r=run(s);self.conserved(r)
        c=r['segment_field_contacts'][0]
        self.assertLess(abs(D(c['applied_at_ms'])-(400+D(600).sqrt())),D('1e-8'))
        self.assertEqual(len(r['segment_field_contacts']),1)
        self.assertLess(abs(D(r['final_states']['B']['position_m'][0])-D('29.8')),D('1e-8'))
        self.assertEqual(c['status'],'active')

    def test_lower_binding_keeps_independent_actual_gunfire_available(self):
        s=scene(1300);s['action_selection']['B']['start_ms']=500
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'projectile_released','B'))
        self.assertLess(D(r['final_states']['A']['hp']),8140)
        self.assertEqual(r['binding_instances'][0]['status'],'active')

    def test_summoning_composes_with_independent_walking(self):
        s=scene();command(s,'A',0,'walk');r=run(s);self.conserved(r)
        self.assertEqual(D(r['segment_fields'][0]['deployed_at_ms']),300)
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),1)
        self.assertTrue(events(r,'movement_active_completed','A'))

    def test_axis_x_changes_actual_panel_geometry(self):
        r=run(scene(point=(30,-20,0),axis='x'));self.conserved(r)
        f=r['segment_fields'][0]
        for key in f['panel_ids']:
            part=r['world_collider_states'][key]['parts'][0]
            self.assertEqual([D(b)-D(a) for a,b in zip(part['minimum_m'],part['maximum_m'])],[D(4),D('.1'),D('1.5')])

    def test_exiting_and_reentering_by_imposed_displacement_starts_a_new_episode(self):
        s=scene(1200);s['spatial_interventions']=[force(600,'B',reference=[31,-20,'.875']),force(900,'B',reference=[30,-20,'.875'])]
        r=run(s);self.conserved(r)
        self.assertEqual(len(r['segment_field_contacts']),2);self.assertEqual(len(r['binding_instances']),2)
        self.assertEqual(D(r['segment_field_contacts'][0]['ended_at_ms']),600)
        self.assertEqual(D(r['segment_field_contacts'][1]['applied_at_ms']),900)
        self.assertLess(abs(D(r['final_states']['B']['hp'])-(8140-D('771.875')*D('.6'))),D('1e-8'))

    def test_one_destroyed_seam_panel_preserves_episode_and_break_progress(self):
        s=scene(1600,target=(30,-18));control(s,400,command='break_binding')
        def destroy(w,index):
            key=w.segment_fields.fields['segment-field:1']['panel_ids'][index]
            w.collider_system.damage(key,1500,source='field_material_probe',damage_type='blunt')
        r=run(s,operations=((1000,lambda w:destroy(w,2)),(1300,lambda w:destroy(w,3))))
        self.conserved(r);c=r['segment_field_contacts'][0];b=r['binding_instances'][0]
        self.assertEqual(len(r['segment_field_contacts']),1);self.assertEqual(len(r['binding_instances']),1)
        self.assertEqual(D(c['ended_at_ms']),1300)
        self.assertEqual(b['end_reason'],'break_escaped')
        self.assertLess(abs(D(b['ended_at_ms'])-(400+escape_work(2,8140)*50)),D('1e-8'))
        self.assertLess(abs(D(r['final_states']['B']['hp'])-(8140-D('771.875'))),D('1e-8'))

    def test_material_immunities_and_accepted_damage_families_use_shared_api(self):
        def damage(w):
            key=w.segment_fields.fields['segment-field:1']['panel_ids'][2]
            for kind in ('toxin','electrocution'):
                self.assertEqual(w.collider_system.damage(key,2000,source='field_material_probe',damage_type=kind),0)
            for kind in ('blunt','slash','qard','heat','constriction','tear'):
                self.assertEqual(w.collider_system.damage(key,1,source='field_material_probe',damage_type=kind),1)
        r=run(scene(),operations=((500,damage),));self.conserved(r)
        key=r['segment_fields'][0]['panel_ids'][2]
        self.assertEqual(D(r['world_collider_states'][key]['hp']),1494)
        self.assertEqual(len(events(r,'world_collider_damage_ignored')),2)

    def test_real_gun_destroys_one_panel_then_reaches_body_behind_the_gap(self):
        s=scene(3000);s['action_selection']['A'].update(abilities=['1'],start_ms=500)
        s['action_selection']['A'].pop('ability_targets')
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[0,-24]
        s['action_selection']['C']=deepcopy(scene(point=(20,-20,0))['action_selection']['A'])
        r=run(s);self.conserved(r);keys=r['segment_fields'][0]['panel_ids']
        self.assertEqual(sum(r['world_collider_states'][key]['status']=='destroyed' for key in keys),1)
        self.assertLess(D(r['final_states']['B']['hp']),8140)
        self.assertTrue(events(r,'world_collider_impact_batch'))

    def test_actual_beam_destroys_all_panels_and_ends_contact_on_the_hp_boundary(self):
        s=scene(3500);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(character='1E1',position_m=[29,-18])
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['4'],start_ms=0,reload_when_empty=False)
        r=run(s);ledger=self.conserved(r);f=r['segment_fields'][0];c=r['segment_field_contacts'][0]
        self.assertEqual(f['end_reason'],'all_panels_removed')
        self.assertEqual(c['ended_at_ms'],f['ended_at_ms'])
        self.assertLess(D(f['ended_at_ms']),3000)
        self.assertTrue(all(r['world_collider_states'][key]['status']=='destroyed' for key in f['panel_ids']))
        self.assertTrue(any(e.contribution.kind=='heat' for e in ledger.entries))
        self.assertTrue(any(e.contribution.kind=='electrocution' for e in ledger.entries))

    def test_death_before_release_cancels_summon_and_after_release_keeps_it(self):
        for fire_at,expected in ((0,False),(400,True)):
            with self.subTest(fire_at=fire_at):
                s=scene();s['encounter']['participants']['A']['initial_state']['hp']=1
                s['encounter']['participants']['B']['position_m']=[2,-20]
                s['action_selection']['B']['start_ms']=fire_at
                r=run(s);self.conserved(r)
                self.assertFalse(r['final_states']['A']['alive'])
                self.assertEqual(bool(r['segment_fields']),expected)
                if expected:self.assertEqual(r['segment_fields'][0]['status'],'active')

    def test_recipient_restoration_inside_surviving_field_is_a_new_life_episode(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['hp']=100
        def restore(w):
            self.assertTrue(w.life_cycles.revive('B',expected_generation=1,hp=500,source='field_life_probe'))
        r=run(s,operations=((600,restore),));self.conserved(r)
        self.assertEqual([c['target_life_generation'] for c in r['segment_field_contacts']],[1,2])
        self.assertEqual([b['target_life_generation'] for b in r['binding_instances']],[1,2])
        self.assertLess(abs(D(r['final_states']['B']['hp'])-D('191.25')),D('1e-8'))

    def test_invalid_field_geometry_and_target_axis_reject_before_actions(self):
        for key,value in (('segments',True),('hp',0),('height_m',-1),('binding',None)):
            p=deepcopy(PROFILES);p['1E2']['abilities']['5']['contact_field'][key]=value
            with self.subTest(key=key),self.assertRaises((ValueError,UnsupportedMechanicError)):run(scene(),profiles=p)
        s=scene();s['action_selection']['A']['ability_targets']['5']['axis']='diagonal'
        with self.assertRaises(ValueError):run(s)
        for key in ('segment_fields','released_rate_damage'):
            cfg=rules();cfg.pop(key)
            with self.subTest(missing_rule=key),self.assertRaises(UnsupportedMechanicError):configured_run(scene(),rules=cfg)

    def test_source_restored_inside_its_old_field_keeps_original_release_attribution(self):
        s=scene(point=(0,-20,0));s['encounter']['participants']['A']['initial_state']['hp']=100
        def restore(w):self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=500,source='field_life_probe'))
        r=run(s,operations=((600,restore),));ledger=self.conserved(r)
        self.assertEqual(r['segment_fields'][0]['source_life_generation'],1)
        self.assertEqual([c['target_life_generation'] for c in r['segment_field_contacts']],[1,2])
        self.assertTrue(all(e.contribution.source.life_generation==1 for e in ledger.entries))
        self.assertLess(abs(D(r['final_states']['A']['hp'])-D('191.25')),D('1e-8'))

    def test_actual_qard_mark_and_blast_damage_multiple_independent_panels(self):
        s=scene(1600);s['encounter']['participants']['A']['character']='1E1'
        s['action_selection']['A'].update(abilities=['1'],start_ms=500)
        s['action_selection']['A'].pop('ability_targets')
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(character='1E2',team='A',position_m=[0,-24],facing='+x')
        s['action_selection']['C']=deepcopy(scene(point=(20,-20,0))['action_selection']['A'])
        r=run(s);self.conserved(r);keys=r['segment_fields'][0]['panel_ids']
        hp=[D(r['world_collider_states'][key]['hp']) for key in keys]
        self.assertEqual((hp[0],hp[4]),(1500,1500))
        self.assertLess(hp[2],hp[1]);self.assertLess(hp[1],1500);self.assertEqual(hp[1],hp[3])
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(D(r['damage_credit_totals']['A']['eligible_hp_dealt']),0)

    def test_control_loss_before_deployment_cancels_only_unreleased_work(self):
        def restrict(w):w.apply_action_restriction('A',source='field_control_probe',functions=['upper_body'],until_ms=1500)
        before=run(scene(),operations=((100,restrict),));self.conserved(before)
        self.assertFalse(before['segment_fields'])
        after=run(scene(),operations=((500,restrict),));self.conserved(after)
        self.assertEqual(after['segment_fields'][0]['status'],'active')
        self.assertLess(abs(D(after['final_states']['B']['hp'])-D('7599.6875')),D('1e-8'))

    def test_completed_summon_frees_its_hand_for_existing_independent_pause_area(self):
        s=scene();s['action_selection']['A']['abilities']=['5','2']
        r=run(s);self.conserved(r)
        self.assertEqual(D(r['segment_fields'][0]['deployed_at_ms']),300)
        self.assertEqual(len(r['cooldown_pause_volumes']),1)
        self.assertEqual(D(events(r,'cooldown_pause_deployed')[0]['time_ms']),500)

    def test_falling_body_enters_at_finite_height_and_binding_does_not_remove_gravity(self):
        s=scene();s['spatial_interventions']=[force(0,'B',reference=[30,-20,'3.475'])]
        r=run(s);self.conserved(r);c=r['segment_field_contacts'][0]
        expected=1000*(D('2.2')/D('9.81')).sqrt()
        self.assertLess(abs(D(c['applied_at_ms'])-expected),D('1e-8'))
        self.assertEqual(len(r['segment_field_contacts']),1)
        self.assertTrue(r['final_states']['B']['locomotion']['grounded'])

    def test_real_break_then_walking_leaves_contact_and_ends_damage(self):
        s=scene(4000,target=(32,-20));command(s,'B',0,'walk');control(s,1000,command='break_binding')
        command(s,'B',2000,'walk');r=run(s,interval=100);self.conserved(r)
        c=r['segment_field_contacts'][0]
        self.assertEqual(len(r['segment_field_contacts']),1)
        self.assertLess(abs(D(c['applied_at_ms'])-930),D('1e-8'))
        self.assertLess(abs(D(c['ended_at_ms'])-2230),D('1e-8'))
        self.assertEqual(r['binding_instances'][0]['end_reason'],'break_escaped')
        self.assertLess(abs(D(r['final_states']['B']['hp'])-D('7136.5625')),D('1e-8'))

    def test_horizon_at_deployment_closes_contact_without_prepaying_future_damage(self):
        r=run(scene(300));self.conserved(r)
        self.assertEqual(len(r['binding_instances']),1)
        self.assertEqual(len(r['released_damage_streams']),1)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_actual_fence_and_break_converge_across_order_precision_and_observation_controls(self):
        outcomes=[]
        for precision,interval,reverse in ((50,None,False),(50,137,False),(80,17,True)):
            s=scene(2500);control(s,400,command='break_binding')
            if reverse:s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
            r=run(s,precision=precision,interval=interval);self.conserved(r)
            outcomes.append((D(r['final_states']['B']['hp']),D(r['binding_instances'][0]['ended_at_ms'])))
        for row in outcomes[1:]:
            for a,b in zip(row,outcomes[0]):self.assertLess(abs(a-b),D('1e-8'))

    def test_box_contact_fields_also_work_in_the_existing_straight_ground_world(self):
        from combat_sim.mobile_combat import MOBILE_SCOPE
        from combat_sim.shared_engine import run_shared_scenario
        from tests.test_aim_combat import inputs
        cfg=rules();cfg.pop('impact_bindings');cfg.pop('contact_constructs')
        s=scene();s['scope']=dict(MOBILE_SCOPE);kw=inputs(cfg);profiles=kw.pop('profiles')
        kw['projectile_physics_definition']=None
        r=run_shared_scenario(s,profiles,**kw);self.conserved(r)
        self.assertEqual(len(r['segment_fields']),1)
        self.assertLess(abs(D(r['final_states']['B']['hp'])-D('7599.6875')),D('1e-8'))


if __name__=='__main__':unittest.main()
