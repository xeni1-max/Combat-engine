"""Authored 2000-HP walls on real shared damage and collision paths.

The gun, Qard, punch and beam tests cast existing abilities. Typed damage
probes prepare the object API for constriction/tear and future charge damage;
they do not claim that any current grab can target a building.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from combat_sim.terrain import terrain_colliders
from combat_sim.world_colliders import ColliderRegistry
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, command, events, read
from tests.test_world_colliders_combat import CURRENT


ARENA=read('data/terrain/destructible_arena.json')
GUN_SCENE=read('scenarios/destructible_wall_gun.json')
WALLS=('wall_1','wall_2','wall_3')


def scene(duration=1000,*,character='1E2',ability='1',start=0):
    s=deepcopy(GUN_SCENE);s['encounter']['duration_ms']=duration
    s['encounter']['participants']['A']['character']=character
    s['action_selection']['A'].update(abilities=[ability],reload_when_empty=character=='1E2',start_ms=start)
    return s


def encounter(s,*,operations=(),precision=50,interval=None,terrain=ARENA,effects=CURRENT):
    class Fixture(SharedEncounter):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            for time,payload in operations:self.push(time,'wall_damage_probe',payload)

        def _process(self,kind,payload):
            if kind!='wall_damage_probe':return super()._process(kind,payload)
            if payload.get('op')=='copy':
                shot=next(f for f in self.projectile_flights.values() if f['actor']=='A')
                for index in range(payload['count']):
                    self.projectile_system.copy(shot['id'],source='simultaneous_area_probe:'+str(index),offset_m=(0,0,0))
                return
            applied=self.collider_system.damage(payload['id'],payload['amount'],source='typed_object_damage_probe',
                damage_type=payload['damage_type'])
            self.log('wall_damage_probe_receipt',collider_id=payload['id'],applied=applied)

    return Fixture(s,PROFILES,precision=precision,sample_interval_ms=interval,body_definition=BODY,
        terrain_definition=terrain,movement_definition=MOVEMENT,combat_locomotion_definition=effects,
        projectile_physics_definition=PHYSICS,jump_definition=JUMP,climb_definition=CLIMB)


def run(s,**kwargs):
    precision=kwargs.get('precision',50)
    with localcontext(Context(prec=precision)):return encounter(s,**kwargs).run()


class WallTerrainTests(unittest.TestCase):
    def test_three_wall_panels_rest_on_ground_with_original_cubes_unchanged(self):
        old=read('data/terrain/stationary_arena.json')
        self.assertEqual(ARENA['obstacles'][:3],old['obstacles'])
        boxes=terrain_colliders(ARENA)
        self.assertEqual(set(boxes),{'ground','cube_1','cube_2','cube_3',*WALLS})
        for name in WALLS:
            box=boxes[name][0]
            self.assertEqual(box.bounds[0][2],0);self.assertEqual(box.bounds[1][2],3)
            item=next(x for x in ARENA['obstacles'] if x['id']==name)
            self.assertEqual(item['hp'],2000);self.assertEqual(item['tags'],['wall'])

    def test_nonpositive_or_nonfinite_terrain_hp_is_rejected(self):
        for hp in (0,-1,True,'NaN','Infinity'):
            t=deepcopy(ARENA);t['obstacles'][-1]['hp']=hp
            with self.subTest(hp=hp),self.assertRaises(ValueError):terrain_colliders(t)

    def test_mixed_dimensions_and_invalid_tags_are_rejected(self):
        for field,value in (('side_length_m',3),('size_m',[0,8,3]),('tags',['wall','wall']),('tags','wall')):
            t=deepcopy(ARENA);t['obstacles'][-1][field]=value
            with self.subTest(field=field,value=value),self.assertRaises(ValueError):terrain_colliders(t)

    def test_damageable_terrain_requires_current_mutable_world_rules(self):
        old=deepcopy(CURRENT);old.pop('world_colliders')
        with self.assertRaisesRegex(UnsupportedMechanicError,'explicit current'):
            run(scene(1),effects=old)

    def test_wall_tags_are_canonical_and_legacy_records_are_unchanged(self):
        registry=ColliderRegistry();part=Cuboid('panel',(0,0,1),(1,1,2))
        old=registry.add([part],time=0,source='probe')
        self.assertNotIn('tags',old.record())
        obj=registry.add([part],time=0,source='probe',tags=['wall','destructible'],hp=2000)
        self.assertEqual(obj.identity.tags,('destructible','wall'))
        self.assertEqual(obj.record()['tags'],['destructible','wall'])
        before=registry.record()
        with self.assertRaises(ValueError):registry.add([part],time=0,source='probe',tags=['wall','wall'])
        self.assertEqual(registry.record(),before)


class WallCombatTests(unittest.TestCase):
    def test_arena_import_has_one_2000_hp_pool_per_wall_and_permanent_ground(self):
        r=run(scene(1))
        for name in WALLS:
            obj=r['world_collider_states'][name]
            self.assertEqual((obj['hp'],obj['max_hp'],obj['status']),('2000','2000','active'))
            self.assertEqual(obj['tags'],['wall'])
            self.assertEqual(obj['blocking'],{'projectiles':True,'bodies':True,'areas':False})
        for name in ('ground','cube_1','cube_2','cube_3'):
            self.assertIsNone(r['world_collider_states'][name]['hp'])
        self.assertTrue(r['world_collider_states']['ground']['permanent'])

    def test_each_requested_damage_family_can_destroy_a_wall_at_exactly_2000(self):
        for family in ('blunt','slash','qard','heat','constriction','tear','constriction_tear'):
            operations=[(10,{'id':'wall_1','amount':1999,'damage_type':family}),
                (20,{'id':'wall_1','amount':1,'damage_type':family}),
                (30,{'id':'wall_1','amount':100,'damage_type':family})]
            with self.subTest(family=family):
                r=run(scene(40,start=100000),operations=operations)
                damage=events(r,'world_collider_damaged')
                self.assertEqual([x['hp_after'] for x in damage],['1','0'])
                self.assertEqual([x['damage_type'] for x in damage],[family,family])
                self.assertEqual([x['applied'] for x in events(r,'wall_damage_probe_receipt')],['1999','1','0'])
                self.assertEqual(len(events(r,'world_collider_removed')),1)
                self.assertTrue(all(not x['character_recovery_credit'] for x in damage))
                self.assertEqual(r['world_collider_states']['wall_1']['status'],'destroyed')

    def test_mixed_damage_shares_hp_and_clips_overkill_without_character_credit(self):
        operations=[(10+i,{'id':'wall_1','amount':amount,'damage_type':kind})
            for i,(kind,amount) in enumerate((('blunt',100),('slash',200),('qard',300),
                ('heat',400),('constriction',500),('tear',600)))]
        r=run(scene(30,start=100000),operations=operations)
        receipts=events(r,'world_collider_damaged')
        self.assertEqual(sum(D(x['applied']) for x in receipts),2000)
        self.assertEqual(receipts[-1]['overkill'],'100')
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertEqual(r['applied_hp_history']['entries'],[])
        self.assertEqual(r['world_collider_states']['wall_2']['hp'],'2000')

    def test_invalid_typed_damage_rejects_before_hp_or_events_change(self):
        with localcontext(Context(prec=50)):
            w=encounter(scene(1));before=w.collider_system.registry.record();count=len(w.event_log.records())
            for kind,amount in (('poisonous',100),([],100),('tear',-1),('heat','NaN')):
                with self.subTest(kind=kind,amount=amount),self.assertRaises(ValueError):
                    w.collider_system.damage('wall_1',amount,source='validation_probe',damage_type=kind)
                self.assertEqual(w.collider_system.registry.record(),before)
                self.assertEqual(len(w.event_log.records()),count)

    def test_real_gunfire_destroys_2000_hp_wall_and_later_shots_hit_opponent(self):
        r=run(deepcopy(GUN_SCENE))
        batches=events(r,'world_collider_impact_batch')
        self.assertTrue(batches);self.assertTrue(all(x['collider_id']=='wall_1' for x in batches))
        self.assertEqual(sum(D(x['applied_hp_damage']) for x in batches),2000)
        destroyed=events(r,'world_collider_removed')[0]
        self.assertTrue(all(p['damage_type']=='slash' for x in batches for p in x['hits']))
        contacts=events(r,'projectile_body_collision');self.assertTrue(contacts)
        self.assertTrue(all(D(x['time_ms'])>D(destroyed['time_ms']) for x in contacts))
        self.assertEqual(r['world_collider_states']['wall_1']['status'],'destroyed')
        self.assertLess(D(r['final_states']['B']['hp']),8140)

    def test_real_qard_contact_damages_wall_and_marks_actual_surface(self):
        r=run(scene(1600,character='1E1'))
        batch=events(r,'world_collider_impact_batch')[0]
        self.assertEqual(batch['collider_id'],'wall_1')
        self.assertEqual(batch['hits'][0]['damage_type'],'qard')
        self.assertGreater(D(batch['applied_hp_damage']),0)
        hit=events(r,'projectile_terrain_collision')[0]
        self.assertEqual(hit['target'],'wall_1')
        self.assertEqual(events(r,'delayed_blast')[0]['location_m'],hit['location_m'])

    def test_qard_delayed_blast_also_consumes_the_same_wall_hp_pool(self):
        r=run(scene(1600,character='1E1'))
        batches=events(r,'world_collider_impact_batch')
        self.assertEqual(len(batches),2)
        self.assertEqual(batches[0]['hits'][0]['component'],'projectile')
        self.assertEqual(batches[1]['hits'][0]['component'],'delayed_blast')
        self.assertEqual(batches[1]['applied_hp_damage'],batches[0]['applied_hp_damage'])
        self.assertEqual(events(r,'delayed_blast')[0]['collider_recipients'],['wall_1'])
        self.assertEqual(D(r['world_collider_states']['wall_1']['hp']),
            2000-sum(D(x['applied_hp_damage']) for x in batches))

    def test_qard_blast_hits_nearby_wall_without_direct_wall_contact(self):
        s=scene(1600,character='1E1');s['encounter']['participants']['B']['position_m']=[10,-8]
        r=run(s);self.assertTrue(events(r,'projectile_body_collision'))
        self.assertFalse(events(r,'projectile_terrain_collision'))
        self.assertEqual(events(r,'delayed_blast')[0]['collider_recipients'],['wall_1'])
        batches=events(r,'world_collider_impact_batch');self.assertEqual(len(batches),1)
        self.assertEqual(batches[0]['hits'][0]['component'],'delayed_blast')
        self.assertGreater(D(batches[0]['applied_hp_damage']),0)

    def test_area_damage_is_once_per_object_across_overlapping_parts(self):
        s=scene(1600,character='1E1')
        s['initial_colliders']=[{'id':'compound_wall','source':'area_overlap_probe','hp':2000,
            'duration_ms':None,'climbable':False,'tags':['wall'],
            'blocking':{'projectiles':True,'bodies':True,'areas':False},
            'parts':[{'part':name,'centre_m':[12,-5,'1.5'],'size_m':[1,1,3]} for name in ('first','overlap')]}]
        r=run(s);batches=events(r,'world_collider_impact_batch')
        wall_batch=next(x for x in batches if x['collider_id']=='wall_1' and x['hits'][0]['component']=='delayed_blast')
        compound=[x for x in batches if x['collider_id']=='compound_wall']
        self.assertEqual(len(compound),1);self.assertEqual(len(compound[0]['hits']),1)
        self.assertEqual(compound[0]['applied_hp_damage'],wall_batch['applied_hp_damage'])

    def test_destroyed_wall_is_not_selected_again_by_its_later_blast(self):
        s=scene(1600,character='1E1');base=run(s)
        at=(D(events(base,'projectile_terrain_collision')[0]['time_ms'])+D(events(base,'delayed_blast')[0]['time_ms']))/2
        r=run(s,operations=[(at,{'id':'wall_1','amount':2000,'damage_type':'tear'})])
        self.assertEqual(events(r,'delayed_blast')[0]['collider_recipients'],[])
        self.assertEqual(len(events(r,'world_collider_impact_batch')),1)
        self.assertEqual(len(events(r,'world_collider_removed')),1)

    def test_simultaneous_blasts_share_hp_and_clip_overkill_once(self):
        s=scene(1600,character='1E1');base=run(s)
        at=(D(events(base,'projectile_released')[0]['time_ms'])+D(events(base,'projectile_terrain_collision')[0]['time_ms']))/2
        r=run(s,operations=[(at,{'op':'copy','count':2})]);batches=events(r,'world_collider_impact_batch')
        self.assertEqual(len(batches),2)
        self.assertEqual([len(x['hits']) for x in batches],[3,3])
        self.assertEqual(sum(D(x['applied_hp_damage']) for x in batches),2000)
        self.assertEqual(len(events(r,'world_collider_removed')),1)
        self.assertEqual(r['world_collider_states']['wall_1']['status'],'destroyed')
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_real_heavy_punch_hits_wall_without_transmitting_knock_to_a_character(self):
        s=scene(600,character='3E5',ability='4')
        s['encounter']['participants']['A']['position_m']=[11,-8]
        s['encounter']['participants']['B']['position_m']=[14,-8]
        r=run(s);batch=events(r,'world_collider_impact_batch')[0]
        self.assertEqual(batch['collider_id'],'wall_1')
        self.assertEqual(batch['hits'][0]['damage_type'],'blunt')
        self.assertEqual(D(batch['applied_hp_damage']),600)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertFalse(events(r,'knock_applied'))

    def test_real_beam_burns_wall_at_continuous_zero_hp_boundary(self):
        s=scene(3000,character='1E1',ability='4')
        s['encounter']['participants']['B']['position_m']=[14,-8]
        r=run(s)
        self.assertEqual(events(r,'beam_deployed')[0]['collider_recipients'],['wall_1'])
        removed=events(r,'world_collider_removed')[0]
        with localcontext(Context(prec=50)):
            expected=D(292)+1000*(D(2000)/600)**(D(2)/3)
        self.assertAlmostEqual(D(removed['time_ms']),expected,places=20)
        entries=events(r,'world_collider_continuous_damage')
        self.assertAlmostEqual(sum(D(x['applied_hp_damage']) for x in entries),2000,places=20)
        self.assertEqual(r['world_collider_states']['wall_1']['status'],'destroyed')

    def test_intact_wall_stops_body_and_destroyed_wall_reopens_movement(self):
        s=scene(1500,start=100000)
        s['encounter']['participants']['A']['position_m']=[10,-8]
        command(s,'A',0,'walk')
        stopped=run(s)
        self.assertTrue(any(x['second']=='wall_1' for x in events(stopped,'body_contact')))
        operation=(100,{'id':'wall_1','amount':2000,'damage_type':'tear'})
        passed=run(s,operations=[operation])
        self.assertFalse(events(passed,'body_contact'))
        self.assertGreater(D(passed['final_states']['A']['position_m'][0]),D('12.2'))

    def test_precision_observation_and_actor_order_preserve_wall_destruction(self):
        s=scene(3000,character='1E1',ability='4')
        s['encounter']['participants']['B']['position_m']=[14,-8]
        a=run(s);s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        self.assertAlmostEqual(D(events(a,'world_collider_removed')[0]['time_ms']),
            D(events(b,'world_collider_removed')[0]['time_ms']),places=20)
        self.assertEqual(a['world_collider_states']['wall_1']['status'],b['world_collider_states']['wall_1']['status'])


if __name__=='__main__':unittest.main()
