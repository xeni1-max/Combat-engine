"""Crouch body geometry and sprint transitions use the real shared timeline."""
from copy import deepcopy
from decimal import Decimal as D, localcontext
import json
from pathlib import Path
import unittest

from combat_sim.engine import run_scenario
from combat_sim.shared_engine import SharedEncounter, run_shared_scenario
from combat_sim.hitboxes import Cuboid
from tests.collider_fixtures import add_fixture_collider
from combat_sim.models import UnsupportedMechanicError

ROOT=Path(__file__).resolve().parents[1]
load=lambda name:json.loads((ROOT/name).read_text())
SCENARIO=load('scenarios/scripted_crouch_sprint_geometry.json')
PROFILES=load('data/characters.json')['characters']
OPTIONS={k:load(f) for k,f in [('body_definition','data/body_hitboxes.json'),
    ('terrain_definition','data/terrain/stationary_arena.json'),('movement_definition','data/movement/walk_run.json'),
    ('jump_definition','data/movement/jump.json')]}

def run(s=SCENARIO,**kwargs):return run_shared_scenario(s,PROFILES,**OPTIONS,**kwargs)
def events(r,kind):return [e for e in r['events'] if e['type']==kind]
def at(r,time,name='A_1E1'):
    return next(p['states'][name] for p in reversed(r['curve']) if D(p['time_ms'])==D(time))

class SharedCrouchSprintTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.result=run()

    def test_public_engine_runs_crouch_and_sprint(self):
        self.assertEqual(run_scenario(SCENARIO,PROFILES,**OPTIONS),self.result)
        for state in self.result['final_states'].values():
            self.assertEqual(state['locomotion']['mode'],'standing')
            self.assertEqual(state['locomotion']['posture'],'standing')
            self.assertLess(abs(D(state['position_m'][0])-D('33.0934558179345469477301631676252904454620161835496')),D('1e-25'))

    def test_sprint_speed_duration_and_integrated_distance(self):
        starts=[e for e in events(self.result,'sprint_transition_started') if e['actor']=='A_1E1']
        self.assertEqual([D(e['active_ms']) for e in starts],[200,200])
        self.assertEqual([D(e['to_speed_mps']) for e in starts],[D('11.2'),D('6.4')])
        self.assertEqual(D(at(self.result,2200)['position_m'][0]),D('9.77'))
        self.assertEqual(at(self.result,2200)['locomotion']['mode'],'sprinting')
        self.assertEqual(D(at(self.result,3500)['position_m'][0]),D('24.33'))
        self.assertEqual(D(at(self.result,3700)['position_m'][0]),D('26.09'))

    def test_crouch_endpoint_height_origin_and_feet(self):
        state=at(self.result,4650)
        self.assertEqual(state['locomotion']['posture'],'crouched')
        self.assertEqual(D(state['locomotion']['body_height_m']),D('1.35'))
        self.assertEqual(D(state['body_origin_m'][2]),D('.675'))
        self.assertEqual(D(state['locomotion']['feet_z_m']),0)
        self.assertEqual(D(state['locomotion']['hand_world_positions_m']['right'][2]),D('.375'))

    def test_mid_crouch_moves_body_centre_but_not_feet(self):
        r=run(sample_interval_ms=1525)
        state=at(r,4575)
        self.assertEqual(D(state['locomotion']['crouch_fraction']),D('.5'))
        self.assertEqual(D(state['locomotion']['body_height_m']),D('1.55'))
        self.assertEqual(D(state['body_origin_m'][2]),D('.775'))
        self.assertEqual(D(state['locomotion']['feet_velocity_mps'][2]),0)
        self.assertLess(abs(D(state['locomotion']['velocity_mps'][2])+D(4)/3),D('1e-25'))
        self.assertEqual(D(state['locomotion']['hand_world_positions_m']['right'][2]),D('.575'))

    def test_stand_restores_geometry_and_hands(self):
        state=at(self.result,5150)
        self.assertEqual(D(state['locomotion']['body_height_m']),D('1.75'))
        self.assertEqual(D(state['body_origin_m'][2]),D('.875'))
        self.assertEqual(D(state['locomotion']['hand_world_positions_m']['right'][2]),D('.775'))
        for name,final in self.result['final_states'].items():
            for hand,point in final['hands_m'].items():
                self.assertEqual(list(map(D,point)),list(map(D,self.result['initial_states'][name]['hands_m'][hand])))

    def test_walking_continues_during_pose_active(self):
        before=at(self.result,6000);after=at(self.result,6150)
        self.assertEqual(D(after['position_m'][0])-D(before['position_m'][0]),D('.3'))
        self.assertEqual(after['locomotion']['mode'],'walking')
        self.assertEqual(D(after['locomotion']['speed_mps']),2)

    def test_crouched_jump_preserves_pose_and_lands_on_feet(self):
        apex=next(e for e in events(self.result,'jump_apex') if e['actor']=='A_1E1')
        state=at(self.result,apex['time_ms'])
        self.assertEqual(D(state['locomotion']['body_height_m']),D('1.35'))
        self.assertLess(abs(D(state['locomotion']['feet_z_m'])-D(512)/981),D('1e-25'))
        self.assertLess(abs(D(state['body_origin_m'][2])-D('.675')-D(512)/981),D('1e-25'))
        landing=next(e for e in events(self.result,'jump_landed') if e['actor']=='A_1E1')
        state=at(self.result,landing['time_ms'])
        self.assertEqual(D(state['locomotion']['feet_z_m']),0)
        self.assertEqual(state['locomotion']['posture'],'crouched')

    def test_sprint_stop_uses_current_speed_and_special_slide(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=3200
        s['movement_script']=[{'actor':n,'at_ms':t,'action':a} for t,a in [(0,'walk'),(1000,'run'),(2000,'sprint'),(2500,'stop')]
            for n in s['encounter']['participants']]
        r=run(s)
        for e in events(r,'special_stop_started'):
            self.assertEqual(D(e['original_speed_mps']),D('11.2'))
            self.assertEqual(D(e['slide_duration_ms']),336)
        for state in r['final_states'].values():
            self.assertEqual(D(state['locomotion']['speed_mps']),0)

    def test_effects_are_explicitly_excluded(self):
        for name,state in self.result['final_states'].items():
            for key in ('hp','armor','shield','disorientation','instability','dyspnea'):
                self.assertEqual(state[key],self.result['initial_states'][name][key])
        sprint=OPTIONS['movement_definition']['sprint']
        self.assertFalse(sprint['attacks_allowed'])
        for profile in sprint['characters'].values():self.assertEqual(profile['base_continuous_dyspnea_per_second'],2)

    def test_unsupported_sprint_handoffs_are_not_invented(self):
        for action in ('sprint','jump'):
            s=deepcopy(SCENARIO)
            if action=='sprint':s['movement_script']=[{'actor':'A_1E1','at_ms':0,'action':'sprint'}]
            else:
                s['movement_script']=[i for i in s['movement_script'] if i['at_ms']<=2000]
                s['movement_script'].append({'actor':'A_1E1','at_ms':2500,'action':'jump'})
            with self.assertRaises(UnsupportedMechanicError):run(s)

    def test_standing_clearance_rejects_blocked_expansion(self):
        self.clearance_fixture(D('1.5'),should_stand=False)

    def test_exact_fit_ceiling_allows_standing(self):
        self.clearance_fixture(D('1.75'),should_stand=True)

    def clearance_fixture(self,ceiling_bottom,should_stand):
        # Explicit test-only overhead collider, introduced after crouching.
        # Production arena cubes still rest on ground and are not changed.
        class FixtureEncounter(SharedEncounter):
            def _process(self,kind,p):
                super()._process(kind,p)
                if kind=='movement_pose_completed' and p['actor']=='A_1E1' and self.motion['A_1E1']['crouch_fraction']==1:
                    add_fixture_collider(self,'overhead_test_fixture',(Cuboid('overhead_test_fixture',
                        [0,-20,ceiling_bottom+D('.125')],[2,2,'.25']),))
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=600
        s['movement_script']=[{'actor':'A_1E1','at_ms':0,'action':'crouch'},
                              {'actor':'A_1E1','at_ms':300,'action':'stand'}]
        with localcontext() as c:
            c.prec=50
            r=FixtureEncounter(s,PROFILES,**OPTIONS).run()
        state=r['final_states']['A_1E1']
        self.assertEqual(state['locomotion']['posture'],'standing' if should_stand else 'crouched')
        self.assertEqual(len(events(r,'stand_rejected')),0 if should_stand else 1)

    def test_precision_and_observations_preserve_new_features(self):
        event_types=('movement_','posture_','crouch_','stand_','sprint_','special_stop_','jump_')
        cadence=lambda r:[e for e in r['events'] if e['type'].startswith(event_types)]
        a=cadence(self.result)
        for trial in (run(precision=80),run(sample_interval_ms=137),run(sample_interval_ms=None)):
            b=cadence(trial)
            self.assertEqual([(e['type'],e.get('actor')) for e in a],[(e['type'],e.get('actor')) for e in b])
            for x,y in zip(a,b):self.assertLess(abs(D(x['time_ms'])-D(y['time_ms'])),D('1e-35'))
            for name,state in trial['final_states'].items():
                reference=self.result['final_states'][name]
                for x,y in zip(state['body_origin_m'],reference['body_origin_m']):self.assertLess(abs(D(x)-D(y)),D('1e-35'))
                for hand,point in state['hands_m'].items():
                    for x,y in zip(point,reference['hands_m'][hand]):self.assertLess(abs(D(x)-D(y)),D('1e-35'))

    def test_previous_climb_traces_remain_unchanged(self):
        folder=ROOT/'results/climbing-active-start'
        opts={k:json.loads((folder/f).read_text()) for k,f in [('body_definition','body_hitboxes.json'),
            ('terrain_definition','terrain.json'),('movement_definition','movement.json'),
            ('jump_definition','jump.json'),('climb_definition','climb.json')]}
        profiles=json.loads((folder/'characters.json').read_text())['characters']
        for scenario,result in [('scenario.json','run.json'),('standing_scenario.json','standing_run.json')]:
            actual=run_shared_scenario(json.loads((folder/scenario).read_text()),profiles,**opts)
            self.assertEqual(actual,json.loads((folder/result).read_text()))

    def test_posture_and_ground_pace_are_independent(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=4300
        s['movement_script']=[{'actor':n,'at_ms':t,'action':a} for t,a in
            [(0,'walk'),(1000,'run'),(2000,'sprint'),(2500,'crouch'),(3000,'run'),(3500,'stand'),(4000,'stop')]
            for n in s['encounter']['participants']]
        r=run(s)
        crouched=at(r,2650)
        self.assertEqual(crouched['locomotion']['posture'],'crouched')
        self.assertEqual(crouched['locomotion']['mode'],'sprinting')
        self.assertEqual(D(crouched['locomotion']['speed_mps']),D('11.2'))
        self.assertEqual(at(r,3650)['locomotion']['mode'],'running')
        self.assertEqual(at(r,3650)['locomotion']['posture'],'standing')
