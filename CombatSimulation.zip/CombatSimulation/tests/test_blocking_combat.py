"""Real authored attacks meet Block on the common clock and geometry.

Ordinary tests use the public API. Explicit life/restriction probes use only
existing engine transitions, labelled as engineering controls, not abilities.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.battle_models import decimal_value as dec
from combat_sim.shared_engine import SharedEncounter, run_shared_scenario
from combat_sim.models import UnsupportedMechanicError
from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_motion_boundary_combat import CURRENT, scene as base_scene


def scene(duration=300, *, character='2E4', held=False, basic='basic_8', distance=30):
    s=base_scene(duration,(0,-20));s['id']='shared_block_test'
    s['encounter']['participants']['A']['character']=character
    s['encounter']['participants']['B']['position_m']=[distance,-20]
    s['action_selection']['A'].update(abilities=[basic],start_ms=0,reload_when_empty=False)
    s['action_selection']['B']['start_ms']=0
    if held:s['action_selection']['A']['held_blocks']=[basic]
    return s


def shooters(s,number=2):
    s['encounter']['participants']['B']['position_m'][1]=D('-20.6')
    c=deepcopy(s['encounter']['participants']['B']);c['position_m'][1]=D('-19.4')
    s['encounter']['participants']['C']=c
    s['action_selection']['C']=deepcopy(s['action_selection']['B'])
    return s


def run(s, *, operations=(), rules=CURRENT, profiles=PROFILES, interval=None, precision=50):
    args=dict(precision=precision,sample_interval_ms=interval,body_definition=BODY,
        terrain_definition=TERRAIN,movement_definition=MOVEMENT,combat_locomotion_definition=rules,
        jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS)
    if s['scope']!=GRAVITY_MOBILE_SCOPE:args.pop('projectile_physics_definition')
    if not operations:return run_shared_scenario(s,profiles,**args)

    class Probe(SharedEncounter):
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw)
            for time,p in operations:self.push(time,'fixture_block',p)

        def _process(self,kind,p):
            if kind!='fixture_block':return super()._process(kind,p)
            a=self.fighters[p.get('actor','A')]
            if p['op']=='kill':
                self.log('fixture_hp_zero',actor=a.id,hp_before=a.hp,damage_credit=False);a.hp=D(0)
            elif p['op']=='revive':
                ok=self.life_cycles.revive(a.id,expected_generation=p.get('generation',1),
                    hp=p.get('hp',1000),source='fixture:block_life_restoration')
                self.log('fixture_life_result',actor=a.id,success=ok)
            elif p['op']=='restriction':
                self.apply_action_restriction(a.id,source='fixture:block_function',
                    functions=p['functions'],until_ms=D(p.get('until',10000)))
            elif p['op']=='inspect':
                self.log('fixture_block_state',actor=a.id,resistance=self.blocking.resistance(a),
                    layers=[self.blocking.record(l) for l in self.blocking.layers.values()],
                    pool=self.blocking.pools[a.id].record(self.time))
            else:raise ValueError('Unknown Block probe')

    with localcontext(Context(prec=precision)):return Probe(s,profiles,**args).run()


def hits(r,target='A'):
    return [e for e in events(r,'impact_batch_resolved') if e['target']==target]


class BlockingCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_real_front_gun_contact_spends_block_without_hp_or_shield_debt(self):
        r=run(scene(149));h=hits(r)[0]
        self.assertGreater(D(h['hits'][0]['block_absorbed']),400)
        self.assertEqual(D(h['applied_hp_damage']),0);self.assertEqual(D(h['applied_shield_damage']),0)
        self.assertEqual(D(r['final_states']['A']['hp']),9080)
        self.assertEqual(r['shield_loss_history'],[])
        self.assertEqual(DamageLedger.from_record(r['applied_hp_history']).amount(),0)
        self.assertEqual(HealingHistory.from_run(r).amount(),0)
        self.assertFalse(events(r,'bleeding_started'))
        self.assertEqual(D(h['block_status_resistance']),100)
        self.assertTrue(all(D(v)==0 for v in h['status_additions'].values()))

    def test_rear_fire_reaches_body_before_forward_surface(self):
        s=scene(149,distance=-30);s['encounter']['participants']['B']['facing']='+x'
        r=run(s);h=hits(r)[0]
        self.assertNotIn('block_layer_id',h['hits'][0]);self.assertGreater(D(h['applied_hp_damage']),0)
        self.assertEqual(D(r['block_layers'][0]['hp']),800)

    def test_simultaneous_break_splits_guard_before_regenerative_shield_and_armor(self):
        s=shooters(scene(149));s['encounter']['participants']['A']['initial_state'].update(shield=20,armor=20)
        r=run(s);h=hits(r)[0];self.assertEqual(len(h['hits']),2)
        self.assertEqual([D(p['block_absorbed']) for p in h['hits']],[400,400])
        self.assertEqual(D(h['block_status_resistance']),100)
        self.assertEqual(r['block_layers'][0]['status'],'broken')
        self.assertEqual(D(h['applied_shield_damage']),20);self.assertGreater(D(h['applied_hp_damage']),0)
        self.assertEqual([D(p['shield_absorbed']) for p in h['hits']],[10,10])
        self.assertEqual(h['hits'][0]['nominal_hp_damage'],h['hits'][1]['nominal_hp_damage'])
        self.assertEqual(h['hits'][0]['calculated_armor_loss'],h['hits'][1]['calculated_armor_loss'])
        self.assertTrue(all(D(v)==0 for v in h['status_additions'].values()))
        self.assertAlmostEqual(sum(D(x['amount']) for x in r['shield_loss_history']),20,places=25)

    def test_held_two_layers_share_break_without_harming_the_body(self):
        r=run(shooters(scene(149,held=True)));h=hits(r)[0]
        self.assertEqual(len(r['block_layers']),2);self.assertEqual(D(h['block_status_resistance']),600)
        self.assertEqual(r['block_layers'][0]['status'],'broken')
        self.assertGreater(D(r['block_layers'][1]['hp']),700)
        self.assertEqual(D(h['applied_hp_damage']),0)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),4)
        self.assertEqual(r['block_charge_pools']['A']['available'],2)

    def test_3e5_held_form_uses_authored_cost_and_lifetimes_while_walking(self):
        s=scene(600,character='3E5',held=True);command(s,'A',0,'walk')
        r=run(s)
        self.assertEqual([(D(l['created_at_ms']),D(l['expires_at_ms'])) for l in r['block_layers']],
            [(0,250),(100,350),(350,600),(450,700)])
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('1.14'))
        self.assertEqual(r['block_charge_pools']['A']['available'],0)
        self.assertEqual(len(events(r,'block_charges_spent')),2)

    def test_real_melee_is_intercepted_without_bleed_or_blade_attachment(self):
        s=scene(299,distance='1.1');s['encounter']['participants']['B']['character']='2E4'
        r=run(s);h=hits(r)[0]
        self.assertEqual(D(h['time_ms']),230)
        self.assertEqual(D(h['hits'][0]['block_absorbed']),440)
        self.assertEqual(D(h['applied_hp_damage']),0)
        self.assertFalse(events(r,'blade_attached'));self.assertFalse(events(r,'bleeding_started'))
        self.assertEqual(len(events(r,'replacement_blade_summoning')),1)

    def test_real_melee_overflow_adds_biological_effects_to_torso_after_block(self):
        s=scene(299,distance='1.1');s['action_selection']['A']['start_ms']=150
        s['encounter']['participants']['A']['initial_state']['armor']=40
        s['encounter']['participants']['B']['character']='2E4'
        shooters(s)
        r=run(s);h=hits(r)[0]
        self.assertEqual(len(h['hits']),2);self.assertEqual(D(r['block_layers'][0]['hp']),0)
        self.assertGreater(D(h['applied_hp_damage']),0)
        self.assertEqual(len(events(r,'blade_attached')),2)
        self.assertTrue(all(e['effect']['target_part']=='torso' for e in events(r,'blade_attached')))
        self.assertEqual(len(events(r,'bleeding_started')),2)

    def test_expired_geometry_remains_at_its_actual_terminal_position(self):
        s=scene(1000);s['action_selection']['B']['start_ms']=100000;command(s,'A',0,'walk')
        r=run(s);first=r['block_layers'][0]
        self.assertEqual(first['status'],'expired');self.assertEqual(D(first['ended_at_ms']),250)
        self.assertEqual(D(first['centre_m'][0]),D('.84'))
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),D('1.9'))

    def test_block_and_right_hand_thrust_are_independently_owned_and_execute(self):
        s=scene(299,distance='1.1');s['action_selection']['A']['abilities']=['basic_8','1']
        s['encounter']['participants']['B']['character']='2E4'
        r=run(s)
        self.assertTrue(events(r,'block_layer_summoned'));self.assertTrue(events(r,'melee_contact','A'))
        self.assertEqual(D(events(r,'melee_contact','A')[0]['time_ms']),230)
        overlapping=[p for x in r['curve'] for p in [x['states']['A']] if len(p['owned_actions'])>1]
        self.assertTrue(overlapping)

    def test_serial_recharge_never_restarts_when_later_charges_are_spent(self):
        s=scene(9200);s['action_selection']['B']['start_ms']=100000;r=run(s)
        self.assertEqual([D(e['time_ms']) for e in events(r,'block_charges_spent')], [0,150,300,450,4500,9000])

    def test_current_2e4_block_and_dodge_preserve_costs_with_independent_stock(self):
        s=scene(700);s['action_selection']['B']['start_ms']=100000
        from tests.test_equilibrium_combat import rules
        current=rules()
        a=run(s,rules=current);s['action_selection']['A']['abilities']=['basic_9'];b=run(s,rules=current)
        self.assertEqual(D(events(a,'dyspnea_paid','A')[0]['base_value']),2)
        self.assertEqual(dec(events(b,'dyspnea_paid','A')[0]['base_value']),D('3.5'))
        self.assertFalse(b['block_layers']);self.assertTrue(b['dodge_actions'])
        s['action_selection']['A']['abilities']=['basic_8','basic_9'];c=run(s,rules=current)
        self.assertEqual(len(events(c,'block_charges_spent')),4)
        self.assertEqual(c['block_charge_pools']['A']['available'],0)
        self.assertEqual(len(events(c,'dodge_charges_spent')),4)
        self.assertEqual(c['dodge_charge_pools']['A']['basic_9']['available'],0)
        self.assertEqual(set(c['final_states']['A']['cooldown_clocks']),{'basic_block','basic_9','5','2'})

    def test_restriction_cancels_pending_held_release_but_not_released_layer(self):
        r=run(scene(200,held=True),operations=[(50,{'op':'restriction','functions':['upper_body']}),
            (51,{'op':'inspect'})])
        self.assertEqual(len(r['block_layers']),1)
        self.assertEqual(r['block_charge_pools']['A']['available'],2)
        self.assertEqual(D(events(r,'fixture_block_state')[0]['resistance']),100)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),4)
        self.assertGreater(D(r['metrics']['A']['block_damage_received']),400)

    def test_lower_body_or_attack_restriction_does_not_cancel_held_defense(self):
        for function in ('lower_body','attack'):
            with self.subTest(function=function):
                r=run(scene(149,held=True),operations=[(50,{'op':'restriction','functions':[function]})])
                self.assertEqual(len(r['block_layers']),2)
                self.assertFalse(events(r,'controlled_action_cancelled'))

    def test_death_before_activation_pays_no_effort_and_spends_no_charge(self):
        s=scene(149);s['encounter']['participants']['A']['initial_state']['disorientation']=200
        r=run(s,operations=[(50,{'op':'kill'})])
        self.assertFalse(r['block_layers']);self.assertEqual(r['block_charge_pools']['A']['available'],4)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_old_life_shield_survives_death_without_a_stale_second_release(self):
        r=run(scene(200,held=True),operations=[(50,{'op':'kill'})])
        self.assertEqual(len(r['block_layers']),1);layer=r['block_layers'][0]
        self.assertFalse(layer['attached']);self.assertEqual(layer['status'],'active')
        self.assertGreater(D(r['metrics']['A']['block_damage_received']),400)
        self.assertFalse(DamageLedger.from_record(r['applied_hp_history']).entries)
        self.assertEqual(r['block_charge_pools']['A']['clock']['state'],'stopped')

    def test_restored_actor_does_not_inherit_old_surface_status_or_overflow(self):
        s=shooters(scene(200,held=True))
        r=run(s,operations=[(50,{'op':'kill'}),(75,{'op':'revive'}),(76,{'op':'inspect'})])
        self.assertEqual(len([l for l in r['block_layers'] if l['source_life_generation']==1]),1)
        old=next(l for l in r['block_layers'] if l['source_life_generation']==1)
        self.assertEqual(old['status'],'broken')
        self.assertEqual(D(r['final_states']['A']['hp']),1000)
        self.assertTrue(all(D(v)==0 for v in hits(r)[0]['status_additions'].values()))
        self.assertEqual(D(events(r,'fixture_block_state')[0]['resistance']),500)
        self.assertFalse(DamageLedger.from_record(r['applied_hp_history']).entries)

    def test_observation_precision_and_actor_order_preserve_break_and_hp(self):
        s=shooters(scene(700,held=True));baseline=run(s)
        for precision,interval in ((50,17),(50,100),(80,137)):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,interval=interval,precision=precision)
            for name in r['final_states']:
                for key in ('hp','shield','armor','dyspnea'):
                    self.assertLess(abs(D(r['final_states'][name][key])-D(baseline['final_states'][name][key])),D('1e-8'))
            self.assertEqual([(e['time_ms'],e['absorbed']) for e in events(r,'block_layer_damage')],
                [(e['time_ms'],e['absorbed']) for e in events(baseline,'block_layer_damage')])

    def test_unknown_block_mode_and_missing_dependencies_reject(self):
        for key in ('life_cycles','effort_rules'):
            rules=deepcopy(CURRENT);rules.pop(key);rules.pop('melee',None)
            if key=='life_cycles':rules.pop('death_revival');rules.pop('hp_recovery')
            with self.subTest(key=key),self.assertRaises(UnsupportedMechanicError):run(scene(),rules=rules)
        rules=deepcopy(CURRENT);rules['blocking']={'mode':'unknown'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'Block requires'):run(scene(),rules=rules)

    def test_delayed_area_bypasses_live_block_and_does_not_reuse_a_contact_layer(self):
        for guard_start in (0,1100):
            s=scene(1300);s['encounter']['participants']['B']['character']='1E1'
            s['action_selection']['B']['abilities']=['1'];s['action_selection']['A']['start_ms']=guard_start
            with self.subTest(guard_start=guard_start):
                r=run(s);blast=next(h for h in hits(r) if h['hits'][0]['component']=='delayed_blast')
                self.assertNotIn('block_layer_id',blast['hits'][0]);self.assertGreater(D(blast['applied_hp_damage']),300)
                if guard_start:
                    self.assertEqual(D(blast['block_status_resistance']),100)
                    self.assertEqual(D(r['metrics']['A']['block_damage_received']),0)
                else:
                    first=hits(r)[0];self.assertIn('block_layer_id',first['hits'][0])
                    self.assertEqual(D(first['applied_hp_damage']),0)
                    self.assertEqual(D(blast['time_ms'])-D(first['time_ms']),500)

    def test_real_beam_damages_hp_while_forward_layers_retain_their_hp(self):
        s=scene(1000);s['encounter']['participants']['B']['character']='1E1'
        s['action_selection']['B']['abilities']=['4'];s['action_selection']['A']['start_ms']=500
        r=run(s)
        self.assertLess(D(r['final_states']['A']['hp']),9000)
        self.assertTrue(events(r,'heat_started'));self.assertFalse(events(r,'block_layer_damage'))
        self.assertTrue(all(D(l['hp'])==800 for l in r['block_layers']))
        self.assertGreater(DamageLedger.from_record(r['applied_hp_history']).amount(target='A'),0)

    def test_held_bonus_tracks_surviving_layers_and_control(self):
        s=scene(350,held=True);s['action_selection']['B']['start_ms']=100000
        r=run(s,operations=[(t,{'op':'inspect'}) for t in (1,101,251,350)])
        self.assertEqual([D(e['resistance']) for e in events(r,'fixture_block_state')],[500,600,500,0])

    def test_actual_overlapping_pause_areas_stop_recharge_without_revoking_stock(self):
        for overlap in (False,True):
            s=scene(9000);s['action_selection']['B']['abilities']=['2']
            if overlap:
                c=deepcopy(s['encounter']['participants']['B']);c['position_m'][1]=-19
                s['encounter']['participants']['C']=c
                s['action_selection']['C']=deepcopy(s['action_selection']['B'])
                s['action_selection']['C']['start_ms']=400
            with self.subTest(overlap=overlap):
                r=run(s);casts=[D(e['time_ms']) for e in events(r,'block_charges_spent')]
                self.assertEqual(casts,[0,150,300,450,8900 if overlap else 8500])
                entered=[e for e in events(r,'cooldown_pause_entered') if e['target']=='A']
                left=[e for e in events(r,'cooldown_pause_left') if e['target']=='A']
                self.assertEqual(len(entered),2 if overlap else 1)
                self.assertEqual(len(left),len(entered))

    def test_dead_gap_freezes_charge_work_and_resume_preserves_the_remainder(self):
        s=scene(5100,held=True);s['action_selection']['B']['start_ms']=100000
        r=run(s,operations=[(50,{'op':'kill'}),(5075,{'op':'revive'}),
            (5075,{'op':'restriction','functions':['upper_body']})])
        pool=r['block_charge_pools']['A']
        self.assertEqual(pool['available'],2);self.assertEqual(D(pool['next_charge_at_ms']),9525)
        self.assertEqual(D(pool['clock']['remaining_work_ms']),8925)
        self.assertEqual(pool['clock']['state'],'running')

    def test_frozen_surface_uses_zero_velocity_when_restored_holder_walks(self):
        s=scene(249,held=True);s['action_selection']['B']['start_ms']=100;command(s,'A',100,'walk')
        r=run(s,operations=[(50,{'op':'kill'}),(75,{'op':'revive'}),
            (75,{'op':'restriction','functions':['upper_body']})])
        self.assertEqual(len(r['block_layers']),1)
        self.assertEqual(D(r['block_layers'][0]['centre_m'][0]),D('.4'))
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),D('.2'))
        self.assertEqual(D(hits(r)[0]['hits'][0]['location_m'][0]),D('.41'))
        self.assertLess(abs(D(hits(r)[0]['hits'][0]['projectile_centre_m'][0])-D('.43')),D('1e-5'))
        self.assertEqual(D(r['final_states']['A']['hp']),1000)

    def test_crouching_moves_the_shield_with_upper_body_and_remains_json_serializable(self):
        import json
        s=scene(149);s['action_selection']['B']['start_ms']=100000;command(s,'A',0,'crouch')
        r=run(s);body=r['final_states']['A'];layer=r['block_layers'][0]
        self.assertLess(D(layer['centre_m'][2]),D('.875'))
        self.assertAlmostEqual(D(layer['centre_m'][2]),D(body['body_origin_m'][2])-
            D(body['locomotion']['crouch_drop_m'])/2,places=30)
        self.assertEqual(json.loads(json.dumps(r)),r)

    def test_actual_cube_collision_uses_live_block_status_bonus_without_larger_body(self):
        s=scene(230);s['encounter']['participants']['A']['position_m']=[4.6,0]
        s['action_selection']['B']['start_ms']=100000;command(s,'A',0,'walk')
        guarded=run(s);s['action_selection']['A'].update(abilities=['1'],start_ms=100000);plain=run(s)
        self.assertEqual(events(guarded,'body_contact')[0]['time_ms'],events(plain,'body_contact')[0]['time_ms'])
        self.assertEqual(D(events(guarded,'body_contact')[0]['time_ms']),205)
        self.assertEqual(D(events(guarded,'target_status_applied')[0]['additions']['instability']),0)
        self.assertGreater(D(events(plain,'target_status_applied')[0]['additions']['instability']),70)

    def test_3e5_basic_jump_and_climb_execute_in_the_same_block_world(self):
        s=scene(300,character='3E5',held=True);s['action_selection']['B']['start_ms']=100000
        command(s,'A',0,'jump');r=run(s)
        self.assertGreater(D(r['final_states']['A']['body_origin_m'][2]),D('1.4'))
        self.assertTrue(any(D(l['centre_m'][2])>D('.875') for l in r['block_layers']))
        s=scene(800,character='3E5');s['encounter']['participants']['A']['position_m']=[4.6,0]
        s['action_selection']['B']['start_ms']=100000
        s['movement_script']=[{'actor':'A','at_ms':0,'action':'climb','target':'cube_1'}]
        r=run(s)
        self.assertAlmostEqual(D(r['final_states']['A']['body_origin_m'][2]),D('2.71875'),places=20)
        self.assertTrue(r['block_layers'])

    def test_straight_projectiles_also_intercept_attached_block_surfaces(self):
        from combat_sim.mobile_combat import MOBILE_SCOPE
        s=scene(149);s['scope']=dict(MOBILE_SCOPE)
        r=run_shared_scenario(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
            movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
            jump_definition=JUMP,climb_definition=CLIMB)
        self.assertTrue(hits(r)[0]['hits'][0]['block_layer_id'])
        self.assertEqual(D(hits(r)[0]['applied_hp_damage']),0)

    def test_real_rear_lethal_hit_leaves_a_surface_for_an_already_fired_front_shot(self):
        s=scene(249,distance=-30);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['B']['facing']='+x'
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(position_m=[30,-20],facing='-x')
        s['action_selection']['C']=deepcopy(s['action_selection']['B']);s['action_selection']['C']['start_ms']=20
        r=run(s)
        self.assertEqual(D(r['final_states']['A']['hp']),0)
        death=D(events(r,'character_died','A')[0]['time_ms'])
        self.assertGreater(D(events(r,'block_layer_damage')[0]['time_ms']),death)
        self.assertFalse(r['block_layers'][0]['attached'])
        self.assertEqual(DamageLedger.from_record(r['applied_hp_history']).amount(target='A'),1)

    def test_friendly_projectile_uses_the_same_physical_interception(self):
        s=scene(149,distance=-30);s['action_selection']['B']['start_ms']=100000
        s['encounter']['participants']['D']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['D'].update(team='A',position_m=[30,-20],facing='-x')
        s['action_selection']['D']=deepcopy(s['action_selection']['B']);s['action_selection']['D']['start_ms']=0
        r=run(s);p=hits(r)[0]['hits'][0]
        self.assertEqual(p['actor'],'D');self.assertEqual(p['aim_target'],'B')
        self.assertGreater(D(p['block_absorbed']),400)
        self.assertEqual(D(r['final_states']['A']['hp']),9080)
        self.assertEqual(DamageLedger.from_record(r['applied_hp_history']).amount(),0)

    def test_expiry_at_exact_linear_projectile_contact_wins_without_consuming_it(self):
        # Labelled numerical profile variant: level muzzle makes the exact
        # 250 ms contact analytically constructible. No damage/timing values change.
        from combat_sim.mobile_combat import MOBILE_SCOPE
        from combat_sim.mechanics.recovery import hand_recovery
        p=deepcopy(PROFILES);gun=p['1E2']['abilities']['1'];gun['hand_positions_m']['start']['left'][2]='.275'
        recovery,_=hand_recovery(p['1E2']['initial_hand_positions_m'],gun['hand_positions_m']['start'],p['1E2']['recovery_value'])
        travel=(D(250)-recovery-40)/1000
        distance=900*travel-150*travel*travel+D('.73')
        s=scene(251,distance=str(distance));s['scope']=dict(MOBILE_SCOPE)
        for interval in (None,17,100,250):
            with self.subTest(interval=interval):
                r=run(s,profiles=p,interval=interval,operations=[(1,{'op':'restriction','functions':['upper_body']})])
                self.assertFalse(events(r,'block_layer_damage'))
                self.assertGreater(D(hits(r)[0]['time_ms']),250)
                self.assertGreater(D(hits(r)[0]['applied_hp_damage']),0)


if __name__=='__main__':unittest.main()
