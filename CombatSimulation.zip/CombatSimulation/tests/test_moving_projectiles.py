"""Continuous contacts with translating, accelerating targets and true corners."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.moving_projectiles import earliest_moving_sphere_contact
from combat_sim.terrain import RectangularGround


ZERO = (0, 0, 0)


class MovingProjectileTests(unittest.TestCase):
    def setUp(self):
        self.box = Cuboid('torso', ZERO, (2, 2, 2))

    def contact(self, origin=(-5, 0, 0), velocity=(10, 0, 0), acceleration=ZERO,
                radius='0.1', box=None, box_velocity=ZERO,
                box_acceleration=ZERO, duration_s=1, precision=50):
        return earliest_moving_sphere_contact(origin, velocity, acceleration,
            radius, self.box if box is None else box, box_velocity,
            box_acceleration, duration_s, precision)

    def assertTime(self, contact, expected, tolerance='1e-39'):
        self.assertIsNotNone(contact)
        self.assertLessEqual(abs(contact.time_s-D(expected)), D(tolerance))
        self.assertLessEqual(contact.time_upper_s-contact.time_lower_s, D(tolerance))

    def test_stationary_target_matches_existing_straight_sphere(self):
        for origin in ((-5, 0, 0), (-5, '1.05', '1.05')):
            with self.subTest(origin=origin):
                previous = self.box.swept_sphere_contact(origin, (5, *origin[1:]), F(1, 10))
                result = self.contact(origin=origin)
                self.assertTime(result, previous.parameter)
                for actual, expected in zip(result.centre_m, previous.centre_m):
                    self.assertLess(abs(actual-expected), D('1e-39'))

    def test_target_moving_away_delays_contact(self):
        result = self.contact(box_velocity=(2, 0, 0))
        self.assertTime(result, '0.4875')
        self.assertLess(abs(result.centre_m[0]-D('-0.125')), D('1e-39'))
        self.assertLess(abs(result.closest_box_point_m[0]-D('-0.025')), D('1e-39'))

    def test_crossing_target_hit_between_interval_endpoints(self):
        result = self.contact(origin=ZERO, box=Cuboid('crossing', (5, 3, 0), (1, 1, 1)),
                              box_velocity=(0, -6, 0))
        self.assertTime(result, '0.44')
        self.assertEqual(result.part, 'crossing')

    def test_equal_velocity_with_separation_remains_miss(self):
        self.assertIsNone(self.contact(box_velocity=(10, 0, 0), duration_s=100))

    def test_projectile_acceleration_and_body_acceleration_are_relative(self):
        with localcontext() as context:
            context.prec = 60
            expected = D('0.39').sqrt()
        first = self.contact(velocity=ZERO, acceleration=(20, 0, 0))
        second = self.contact(velocity=ZERO, box_acceleration=(-20, 0, 0))
        self.assertTime(first, expected)
        self.assertTime(second, expected)
        self.assertLessEqual(first.time_lower_s, expected)
        self.assertGreaterEqual(first.time_upper_s, expected)

    def test_parabola_can_hit_and_leave_before_interval_end(self):
        result = self.contact(origin=(-4, 0, 0), velocity=(8, 0, 0),
                              acceleration=(-8, 0, 0), duration_s=2)
        with localcontext() as context:
            context.prec = 60
            expected = 1-D('0.275').sqrt()
        self.assertTime(result, expected)

    def test_repeated_root_face_tangency_is_contact(self):
        result = self.contact(origin=(-2, 0, 0), velocity=(2, 0, 0),
                              acceleration=(-2, 0, 0), radius=0, duration_s=2)
        self.assertTime(result, 1)

    def test_corner_tangency_is_contact(self):
        # z=1.1 puts the path exactly one radius above the cube. It first
        # touches at the edge x=-1, even though it never enters the solid.
        result = self.contact(origin=(-5, 1, '1.1'))
        self.assertTime(result, '0.4')

    def test_expanded_aabb_corner_false_positive_is_rejected(self):
        self.assertIsNone(self.contact(origin=(-5, '1.09', '1.09')))

    def test_quartic_corner_contact(self):
        # Relative centre: (-3+t², 1+1/20*t, 0). Contact is with the rounded
        # corner, not the cuboid expanded independently on each axis.
        result = self.contact(origin=(-3, 1, 0), velocity=(0, '0.05', 0),
                              acceleration=(2, 0, 0), radius='0.2', duration_s=2)
        self.assertIsNotNone(result)
        with localcontext() as context:
            context.prec = 60
            t = result.time_s
            residual = (t*t-2)**2+(t/20)**2-D('0.04')
            self.assertLess(abs(residual), D('1e-39'))
            self.assertLess(t, D(2).sqrt())

    def test_initial_overlap_and_initial_touch_are_time_zero(self):
        for origin in (ZERO, (-1, 0, 0), ('-1.1', 0, 0)):
            with self.subTest(origin=origin):
                self.assertTime(self.contact(origin=origin, velocity=(-10, 0, 0)), 0)

    def test_closed_interval_includes_endpoint_and_zero_duration(self):
        self.assertTime(self.contact(duration_s='0.39'), '0.39')
        self.assertIsNone(self.contact(duration_s='0.389999999999999999999999999999'))
        self.assertIsNone(self.contact(duration_s=0))
        self.assertTime(self.contact(origin=ZERO, duration_s=0), 0)

    def test_galilean_translation_preserves_time_and_shifts_world_contact(self):
        first = self.contact()
        second = self.contact(origin=(95, 50, -10), velocity=(13, 4, 5),
            box=Cuboid('translated', (100, 50, -10), (2, 2, 2)), box_velocity=(3, 4, 5))
        self.assertEqual(first.time_s, second.time_s)
        for base, shifted, offset, speed in zip(first.centre_m, second.centre_m,
                                               (100, 50, -10), (3, 4, 5)):
            self.assertLess(abs(shifted-base-D(offset)-D(speed)*first.time_s), D('1e-39'))

    def test_decimal_context_independence_and_precision_refinement(self):
        kwargs = dict(origin=(-5, '1.05', '1.05'))
        ordinary = self.contact(**kwargs)
        with localcontext() as context:
            context.prec = 4
            low_context = self.contact(**kwargs)
        refined = self.contact(**kwargs, precision=80)
        self.assertEqual(ordinary, low_context)
        self.assertLess(abs(ordinary.time_s-refined.time_s), D('1e-39'))

    def test_invalid_inputs_are_rejected(self):
        cases = ({'origin': (0, 0)}, {'velocity': (1, 2, 3, 4)},
                 {'acceleration': (0, 'NaN', 0)}, {'radius': -1},
                 {'duration_s': -1}, {'duration_s': 'Infinity'},
                 {'box_velocity': None}, {'box_acceleration': (True, 0, 0)},
                 {'precision': 39}, {'precision': True})
        for kwargs in cases:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                self.contact(**kwargs)

    def test_downward_contact_with_finite_zero_thickness_ground(self):
        ground = RectangularGround('ground', (-2, -2, 0), (2, 2, 0))
        result = self.contact(origin=(0, 0, 2), velocity=(0, 0, -4), box=ground)
        self.assertTime(result, '0.475')
        self.assertEqual(result.part, 'ground')
        self.assertEqual(result.closest_box_point_m, (D(0), D(0), D(0)))

    def test_sphere_beyond_finite_ground_edge_misses(self):
        ground = RectangularGround('ground', (-2, -2, 0), (2, 2, 0))
        self.assertIsNone(self.contact(origin=('2.11', 0, 2),
            velocity=(0, 0, -4), box=ground))

    def test_finite_ground_edge_has_rounded_sphere_contact(self):
        ground = RectangularGround('ground', (-2, -2, 0), (2, 2, 0))
        result = self.contact(origin=('2.06', 0, 2), velocity=(0, 0, -4), box=ground)
        self.assertTime(result, '0.48')
        self.assertEqual(result.closest_box_point_m, (D(2), D(0), D(0)))

    def test_ground_contact_can_be_approached_from_below(self):
        ground = RectangularGround('ground', (-2, -2, 0), (2, 2, 0))
        result = self.contact(origin=(0, 0, -2), velocity=(0, 0, 4), box=ground)
        self.assertTime(result, '0.475')

    def test_quadratic_interval_split_preserves_contact(self):
        original = self.contact(acceleration=(-2, 0, 0), box_acceleration=(1, 0, 0))
        split = F(1, 5)
        shifted_box = Cuboid('shifted', (split*split/2, 0, 0), (2, 2, 2))
        later = self.contact(origin=(-5+10*split-split*split, 0, 0),
            velocity=(10-2*split, 0, 0), acceleration=(-2, 0, 0),
            box=shifted_box, box_velocity=(split, 0, 0), box_acceleration=(1, 0, 0),
            duration_s=1-split)
        with localcontext() as context:
            context.prec = 60
            self.assertLess(abs(original.time_s-(later.time_s+D('0.2'))), D('1e-39'))
