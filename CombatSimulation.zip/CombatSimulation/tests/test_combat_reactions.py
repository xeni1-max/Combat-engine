"""Automatic counters use real Block, geometry, damage and life transitions.

Clock/life/restriction probes are labelled engineering controls, not character
abilities. Ordinary combat cases use unchanged current character definitions.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.status import mitigate_status
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from tests.test_blocking_combat import scene as block_scene,run,events,shooters
from tests.test_mobile_combat import BODY,MOVEMENT,PROFILES,TERRAIN,command
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_motion_boundary_combat import CURRENT
from tests.test_world_colliders_combat import wall


def scene(duration=300):
    s=block_scene(duration,distance='1.1');s['id']='automatic_counter_test'
    s['encounter']['participants']['B']['character']='2E4'
    return s


def counter_hits(r):
    return [e for e in events(r,'impact_batch_resolved') if any(p['component']=='reaction' for p in e['hits'])]


def engine(s):
    return SharedEncounter(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
        movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
        jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS)


class CombatReactionTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for actor,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=actor)
            self.assertLess(abs(supplied-D(r['final_states'][actor]['hp'])-ledger.amount(target=actor)),D('1e-8'))
        return ledger

    def test_real_block_releases_authored_power_statuses_and_post_armor_damage(self):
        r=run(scene());f=r['reaction_emissions'][0];h=counter_hits(r)[0]
        self.assertEqual(D(f['created_at_ms']),230);self.assertEqual(f['ability'],'2')
        self.assertEqual(D(h['applied_hp_damage']),D('445.55'))
        self.assertEqual(D(h['pre_hit_armor']),165)
        self.assertEqual(D(h['status_additions']['disorientation']),
            mitigate_status(800,9080,165,0))
        self.assertEqual(D(h['status_additions']['instability']),D(h['status_additions']['disorientation']))
        self.assertEqual(r['reaction_charge_pools']['A']['2']['available'],0)
        self.assertEqual(D(r['reaction_charge_pools']['A']['2']['next_charge_at_ms']),9230)
        power=next(p for p in r['released_attack_power'] if p.get('attack_id')==f['id'])
        self.assertEqual(power['category'],'extrinsic_momentary')
        self.assertEqual(D(power['components']['reaction']['output']),500)
        self.assertFalse(events(r,'bleeding_started'));self.assertFalse(events(r,'blade_attached'))
        self.assertEqual(self.conserved(r).amount(actor='A'),D('445.55'))

    def test_counter_acquires_no_hand_and_adds_no_extra_dyspnea(self):
        s=scene();r=run(s);old=deepcopy(CURRENT);old.pop('combat_reactions');baseline=run(s,rules=old)
        self.assertEqual(r['metrics']['A']['dyspnea_paid'],baseline['metrics']['A']['dyspnea_paid'])
        self.assertFalse([e for e in events(r,'dyspnea_paid') if e['ability']=='2'])
        self.assertFalse(events(r,'combat_reaction_released')[0]['acquires_resources'])
        def controls(result):
            values=deepcopy(result['final_states']['A']['owned_actions'])
            for row in values:row['action'].pop('id')
            return values
        self.assertEqual(controls(r),controls(baseline))

    def test_zero_output_contact_does_not_count_as_successful_absorption(self):
        s=block_scene(700);s['encounter']['participants']['B']['character']='1E1'
        s['encounter']['participants']['B']['initial_state']['instability']=10000
        r=run(s)
        contact=events(r,'impact_batch_resolved')[0]['hits'][0]
        self.assertIn('block_layer_id',contact);self.assertEqual(D(contact['block_absorbed']),0)
        self.assertFalse(r['combat_signals']);self.assertFalse(r['reaction_emissions'])
        self.assertEqual(r['reaction_charge_pools']['A']['2']['available'],1)

    def test_passive_regenerative_shield_absorption_does_not_trigger_a_counter(self):
        s=block_scene(149);s['encounter']['participants']['A']['initial_state']['shield']=4000
        s['action_selection']['A'].update(abilities=['1'],start_ms=100000)
        r=run(s)
        self.assertGreater(D(events(r,'impact_batch_resolved')[0]['applied_shield_damage']),400)
        self.assertFalse(r['combat_signals']);self.assertFalse(r['reaction_emissions'])

    def test_shared_block_does_not_give_3e5_a_new_counter_ability(self):
        s=scene();s['encounter']['participants']['A']['character']='3E5'
        r=run(s)
        self.assertTrue(r['combat_signals']);self.assertFalse(r['reaction_emissions'])
        self.assertNotIn('A',r['reaction_charge_pools'])

    def test_extrinsic_reaction_retains_its_power_while_source_is_unstable(self):
        s=scene();s['encounter']['participants']['A']['initial_state']['instability']=3000
        r=run(s);frame=r['reaction_emissions'][0]
        power=next(p for p in r['released_attack_power'] if p.get('attack_id')==frame['id'])
        self.assertGreater(D(power['instability_at_release']),2000)
        self.assertEqual(D(power['components']['reaction']['output']),500)

    def test_full_regenerative_shield_absorbs_hp_damage_without_cancelling_statuses(self):
        s=scene();s['encounter']['participants']['B']['initial_state']['shield']=500
        r=run(s);h=counter_hits(r)[0]
        self.assertEqual(D(h['applied_shield_damage']),500);self.assertEqual(D(h['applied_hp_damage']),0)
        self.assertEqual(D(h['applied_armor_loss']),0)
        self.assertGreater(D(h['status_additions']['instability']),750)
        self.assertEqual(len(r['reaction_emissions']),1)
        self.assertEqual(r['reaction_charge_pools']['B']['2']['available'],1)

    def test_counter_healing_uses_real_incoming_hp_funding_from_the_parent_batch(self):
        s=scene(230);s['action_selection']['A']['start_ms']=150
        s['encounter']['participants']['A']['initial_state']['armor']=40
        s['encounter']['participants']['B']['position_m']=['1.1','-19.7']
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m'][1]='-20.5'
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s);ledger=self.conserved(r)
        self.assertEqual(ledger.amount(target='A'),80)
        self.assertEqual(ledger.amount(actor='A'),D('445.55'))
        self.assertEqual(HealingHistory.from_run(r).amount(actor='A'),72)
        self.assertEqual(D(r['final_states']['A']['hp']),9072)

    def test_multiple_packets_and_layers_commit_one_signal_and_spend_one_charge(self):
        r=run(shooters(block_scene(149,held=True)))
        self.assertEqual(len(r['combat_signals']),1);s=r['combat_signals'][0]
        self.assertEqual(len(s['layer_ids']),2);self.assertEqual(len(s['incoming_ids']),2)
        self.assertEqual(len(r['reaction_emissions']),1)
        self.assertEqual(r['reaction_charge_pools']['A']['2']['available'],0)
        self.assertEqual(D(s['absorbed']),D(r['metrics']['A']['block_damage_received']))

    def test_line_reaches_every_body_including_a_friend_without_first_body_occlusion(self):
        s=scene()
        for name,x,team in [('C','3.5','A'),('D','5.16','B')]:
            s['encounter']['participants'][name]={'character':'1E2','team':team,'position_m':[x,-20],
                'facing':'-x','initial_state':{'shield':0}}
            s['action_selection'][name]=dict(s['action_selection']['B'],start_ms=100000)
        r=run(s);f=r['reaction_emissions'][0]
        self.assertEqual([p['target'] for p in f['recipients']],['B','C','D'])
        ledger=self.conserved(r)
        self.assertGreater(ledger.amount(actor='A',target='C'),0)
        self.assertEqual(ledger.amount(actor='A',target='C',eligible_only=True),0)
        self.assertGreater(ledger.amount(actor='A',target='D',eligible_only=True),0)

    def test_line_range_ends_without_target_seeking_or_backward_hits(self):
        s=scene()
        for name,x in [('C','5.19'),('D','-2')]:
            s['encounter']['participants'][name]={'character':'1E2','team':'B','position_m':[x,-20],
                'facing':'-x','initial_state':{'shield':0}}
            s['action_selection'][name]=dict(s['action_selection']['B'],start_ms=100000)
        r=run(s);self.assertEqual([p['target'] for p in r['reaction_emissions'][0]['recipients']],['B'])

    def test_existing_cube_protects_a_body_behind_it(self):
        s=scene();s['encounter']['participants']['A']['position_m']=[4,0]
        s['encounter']['participants']['B']['position_m']=['4.9',0]
        s['encounter']['participants']['C']={'character':'1E2','team':'B','position_m':[8,0],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=100000)
        r=run(s);self.assertEqual(r['reaction_emissions'][0]['solid_blocker'],'cube_1')
        self.assertEqual([p['target'] for p in r['reaction_emissions'][0]['recipients']],['B','cube_1'])
        self.assertEqual(self.conserved(r).amount(target='C'),0)

    def test_breaking_damageable_cover_keeps_its_pre_batch_occlusion(self):
        s=scene();s['initial_colliders']=[wall('wall',x=2,hp=400)]
        s['encounter']['participants']['C']={'character':'1E2','team':'B','position_m':['3.5',-20],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=100000)
        r=run(s);self.assertEqual(r['world_collider_states']['wall']['status'],'destroyed')
        self.assertEqual(self.conserved(r).amount(target='C'),0)
        self.assertFalse(any(e.target=='wall' for e in DamageLedger.from_record(r['applied_hp_history']).entries))

    def test_two_ready_defenders_release_before_either_counter_is_applied(self):
        s=scene(249)
        for name in ('A','B'):s['action_selection'][name]['abilities']=['basic_8','1']
        r=run(s);self.assertEqual(len(r['reaction_emissions']),2)
        self.assertEqual({f['actor'] for f in r['reaction_emissions']},{'A','B'})
        self.assertTrue(all(f['reaction_depth']==1 for f in r['reaction_emissions']))
        self.assertEqual(sum(d['outcome']=='no_charge' for s in r['combat_signals'] for d in s['decisions']),2)
        self.assertTrue(all(D(v['hp'])==9080 for v in r['final_states'].values()))
        release_indices=[i for i,e in enumerate(r['events']) if e['type']=='combat_reaction_released']
        first_damage=next(i for i,e in enumerate(r['events']) if e['type']=='impact_batch_resolved' and
            any(p['component']=='reaction' for p in e['hits']))
        self.assertTrue(all(i<first_damage for i in release_indices))

    def test_released_counter_damage_survives_mutual_death_and_funds_real_revival(self):
        s=scene(249)
        for name in ('A','B'):
            s['encounter']['participants'][name]['initial_state'].update(hp=1,armor=0)
            s['action_selection'][name]['abilities']=['1','basic_8'];command(s,name,150,'walk')
            # Engineering setup: one actual guard at 150 ms. Concurrent free
            # hands would otherwise summon guards at both 0 and 150 ms.
            s.setdefault('initial_restrictions',[]).append({'target':name,
                'source':'fixture:single_guard_before_counter','functions':['hand:left'],'duration_ms':150})
        r=run(s);self.assertEqual(len(r['reaction_emissions']),2)
        self.assertTrue(all(D(v['hp'])==0 for v in r['final_states'].values()))
        ledger=self.conserved(r)
        for name in ('A','B'):
            self.assertEqual(ledger.amount(actor=name,eligible_only=True),1)
            attempt=next(a for a in r['revival_attempts'] if a['actor']==name)
            self.assertEqual(D(attempt['restoration_hp']),1)
        self.assertEqual(HealingHistory.from_run(r).amount(),0)

    def test_a_lethal_original_batch_cancels_reaction_before_spending(self):
        s=shooters(block_scene(149));s['encounter']['participants']['A']['initial_state'].update(hp=1,armor=20)
        r=run(s);self.assertFalse(r['reaction_emissions'])
        self.assertEqual(r['reaction_charge_pools']['A']['2']['available'],1)
        self.assertEqual(r['combat_signals'][0]['decisions'][0]['outcome'],'owner_dead')
        self.assertEqual(self.conserved(r).amount(actor='A'),0)

    def test_empty_stock_discards_subsequent_block_signals(self):
        r=run(block_scene(700,held=True))
        self.assertEqual(len(r['reaction_emissions']),1)
        self.assertTrue(any(d['outcome']=='no_charge' for s in r['combat_signals'] for d in s['decisions']))

    def test_real_later_block_refills_the_counter_after_nine_seconds_of_work(self):
        s=block_scene(9600,held=True);s['encounter']['participants']['A']['initial_state']['shield']=4000
        r=run(s);times=[D(f['created_at_ms']) for f in r['reaction_emissions']]
        self.assertEqual(len(times),2);self.assertGreaterEqual(times[1]-times[0],9000)
        self.assertEqual(D(r['reaction_charge_pools']['A']['2']['next_charge_at_ms']),times[1]+9000)
        self.conserved(r)

    def test_ready_stock_fires_inside_actual_overlapping_pause_areas(self):
        s=scene(4700)
        for name,y,start in [('C',-19,0),('D',-21,400)]:
            s['encounter']['participants'][name]={'character':'1E2','team':'B','position_m':[30,y],
                'facing':'-x','initial_state':{'shield':0}}
            s['action_selection'][name]=dict(s['action_selection']['B'],abilities=['2'],start_ms=start)
        r=run(s);self.assertEqual(D(r['reaction_emissions'][0]['created_at_ms']),230)
        self.assertEqual(D(r['reaction_charge_pools']['A']['2']['next_charge_at_ms']),13600)
        spent=events(r,'reaction_charge_spent')[0]
        self.assertTrue(spent['pool']['clock']['pause_sources'])
        self.conserved(r)

    def test_old_life_frozen_block_cannot_spend_a_restored_actors_charge(self):
        r=run(block_scene(200,held=True),operations=[(50,{'op':'kill'}),(75,{'op':'revive'})])
        self.assertFalse(r['reaction_emissions'])
        self.assertEqual(r['reaction_charge_pools']['A']['2']['available'],1)
        self.assertEqual(r['combat_signals'][0]['decisions'][0]['outcome'],'source_life_retired')

    def test_deployed_guard_can_react_after_upper_body_control_is_cancelled(self):
        r=run(scene(),operations=[(50,{'op':'restriction','functions':['upper_body']})])
        self.assertEqual(len(r['reaction_emissions']),1)
        self.assertEqual(D(counter_hits(r)[0]['applied_hp_damage']),D('445.55'))

    def test_signal_dispatch_is_once_only_and_does_not_spend_again(self):
        with localcontext(Context(prec=50)):
            e=engine(scene());r=e.run();before=deepcopy(e.reactions.pools[('A','2')].record(e.time))
            e.reactions.process({'signal_id':r['combat_signals'][0]['id']})
            self.assertEqual(len(e.reactions.emissions),1)
            self.assertEqual(e.reactions.pools[('A','2')].record(e.time),before)

    def test_empty_signal_is_not_replayed_when_stock_later_becomes_ready(self):
        class QuietAfterFirstHit(SharedEncounter):
            def _process(self,kind,p):
                if kind!='fixture_no_more_attacks':return super()._process(kind,p)
                self.apply_action_restriction('B',source='fixture:quiet_after_first_hit',
                    functions=['upper_body'],until_ms=D(100000))
        with localcontext(Context(prec=50)):
            e=QuietAfterFirstHit(scene(9500),PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
                jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS)
            # Explicit engineering stock preset, not an authored cost/action.
            e.reactions.pools[('A','2')].spend(0)
            e.initial=e.states()
            e.push(321,'fixture_no_more_attacks',{})
            r=e.run()
        self.assertFalse(r['reaction_emissions'])
        self.assertEqual(r['reaction_charge_pools']['A']['2']['available'],1)
        self.assertEqual(r['combat_signals'][0]['decisions'][0]['outcome'],'no_charge')

    def test_dead_gap_freezes_counter_work_instead_of_resetting_or_refilling_it(self):
        r=run(block_scene(2600,held=True),operations=[(500,{'op':'kill'}),(2500,{'op':'revive'})])
        first=D(r['reaction_emissions'][0]['created_at_ms'])
        self.assertEqual(len(r['reaction_emissions']),1)
        self.assertEqual(D(r['reaction_charge_pools']['A']['2']['next_charge_at_ms']),first+11000)
        self.assertEqual(r['final_states']['A']['life_generation'],2)

    def test_piercing_line_hits_old_surface_and_restored_body_as_distinct_receivers(self):
        s=scene(249)
        s['encounter']['participants']['R']={'character':'2E4','team':'B','position_m':['3.5',-20],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['R']=dict(s['action_selection']['A'])
        r=run(s,operations=[(50,{'op':'kill','actor':'R'}),(75,{'op':'revive','actor':'R'}),
            (75,{'op':'restriction','actor':'R','functions':['upper_body']})])
        packets=[p for p in r['reaction_emissions'][0]['recipients'] if p['target']=='R']
        self.assertEqual([p['target_life_generation'] for p in packets],[1,2])
        self.assertEqual(D(r['final_states']['R']['hp']),D('554.45'))
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        self.assertEqual(ledger.amount(target='R',target_life_generation=1),0)
        self.assertEqual(ledger.amount(target='R',target_life_generation=2),D('445.55'))
        self.assertEqual(r['reaction_charge_pools']['R']['2']['available'],1)

    def test_observation_precision_and_participant_order_preserve_causal_outcomes(self):
        s=scene(249)
        for name in ('A','B'):s['action_selection'][name]['abilities']=['basic_8','1']
        baseline=run(s)
        for precision,interval in ((50,17),(50,100),(80,137)):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,precision=precision,interval=interval)
            self.assertEqual([(f['actor'],f['created_at_ms'],f['reaction_depth']) for f in r['reaction_emissions']],
                [(f['actor'],f['created_at_ms'],f['reaction_depth']) for f in baseline['reaction_emissions']])
            for name in ('A','B'):
                for field in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertLess(abs(D(r['final_states'][name][field])-D(baseline['final_states'][name][field])),D('1e-8'))
            self.conserved(r)

    def test_automatic_selection_unknown_modes_and_malformed_definitions_reject(self):
        s=scene();s['action_selection']['A']['abilities']=['2']
        with self.assertRaisesRegex(UnsupportedMechanicError,'automatic'):run(s)
        rules=deepcopy(CURRENT);rules['combat_reactions']={'mode':'unknown'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'Combat reactions'):run(scene(),rules=rules)
        p=deepcopy(PROFILES);p['2E4']['automatic_abilities']['2']['execution_model']='unknown'
        with self.assertRaisesRegex(UnsupportedMechanicError,'automatic ability controller'):run(scene(),profiles=p)
        for key,value in [('maximum_charges',0),('maximum_charges',True),('charge_gain_interval_ms',0)]:
            p=deepcopy(PROFILES);p['2E4']['automatic_abilities']['2'][key]=value
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):run(scene(),profiles=p)


if __name__=='__main__':unittest.main()
