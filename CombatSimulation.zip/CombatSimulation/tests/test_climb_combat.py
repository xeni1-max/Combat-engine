"""Approved climb paths, actions, resources and live combat on one clock."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.hitboxes import Cuboid
from tests.collider_fixtures import add_fixture_collider
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from tests.test_airborne_combat import JUMP, run as air_run
from tests.test_mobile_combat import BODY, EFFECTS, MOVEMENT, PROFILES, TERRAIN, command, events, read
from tests.test_sprint_combat import PHYSICS, scenario


CLIMB = read('data/movement/combat_climb.json')


def scene(horizon=900, **kwargs):
    s = scenario(horizon,**kwargs)
    s['encounter']['participants']['A']['position_m'] = ['4.6',0]
    return s


def climb(s,actor='A',time=0,target='cube_1'):
    s['movement_script'].append({'actor':actor,'at_ms':time,'action':'climb','target':target})


def run(s,**kwargs):
    return air_run(s,climb_definition=CLIMB,**kwargs)


class ClimbCombatTests(unittest.TestCase):
    def test_standing_climb_uses_approved_path_and_successful_start_payment(self):
        s = scene(450);climb(s)
        r = run(s,sample_interval_ms=None)
        start = events(r,'climb_active_started','A')[0]
        self.assertEqual((D(start['time_ms']),D(start['active_end_ms'])),(150,450))
        self.assertEqual(D(start['top_reached_at_ms']),D('318.75'))
        self.assertEqual(D(start['path_length_m']),D('3.2'))
        self.assertAlmostEqual(D(start['path_speed_mps']),D(32)/3,places=25)
        self.assertEqual(start['self_effects'],{'disorientation':'80','instability':'250'})
        payment = events(r,'dyspnea_paid','A')[0]
        self.assertEqual((D(payment['time_ms']),D(payment['amount'])),(150,D('12.25')))
        self.assertEqual(tuple(map(D,r['final_states']['A']['body_origin_m'])),(6,0,D('2.675')))
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'cube_1')
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertFalse(events(r,'body_contact'))
        self.assertEqual(r['initial_states']['A']['hands_m'],r['final_states']['A']['hands_m'])

    def test_vertical_segment_has_true_height_velocity_and_blocks_resource_recovery(self):
        s = scene(225);climb(s)
        r = run(s,sample_interval_ms=None);f = r['final_states']['A']
        self.assertAlmostEqual(D(f['body_origin_m'][2]),D('1.675'),places=30)
        self.assertEqual(D(f['locomotion']['feet_z_m']),D('.8'))
        self.assertFalse(f['locomotion']['grounded'])
        self.assertAlmostEqual(D(f['locomotion']['velocity_mps'][2]),D(32)/3,places=25)
        self.assertEqual(D(f['dyspnea']),D('12.25'))
        self.assertEqual((D(f['disorientation']),D(f['instability'])),(5,175))

    def test_walking_enters_range_during_gathering(self):
        s = scene();s['encounter']['participants']['A']['position_m']=[4,0]
        command(s,'A',0,'walk');climb(s,time=200)
        r = run(s)
        request = events(r,'climb_requested','A')[0]
        checked = events(r,'climb_range_checked','A')[0]
        self.assertGreater(D(request['origin_surface_distance_squared_m2']),D('.25'))
        self.assertEqual(D(checked['time_ms']),350)
        self.assertEqual(D(checked['origin_m'][0]),D('4.64'))
        self.assertTrue(checked['allowed'])
        self.assertEqual(D(events(r,'climb_completed','A')[0]['time_ms']),650)

    def test_walking_out_of_range_fails_once_without_cost_or_invented_contact(self):
        s = scene();s['encounter']['participants']['A']['position_m']=['7.1',0]
        command(s,'A',0,'walk');climb(s,time=100)
        r = run(s)
        checked = events(r,'climb_range_checked','A')
        self.assertEqual(len(checked),1)
        self.assertFalse(checked[0]['allowed'])
        self.assertEqual(D(checked[0]['origin_m'][0]),D('7.54'))
        self.assertFalse(events(r,'dyspnea_paid','A'))
        self.assertFalse(events(r,'body_contact'))
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'walking')

    def test_failed_range_does_not_automatically_retry_on_later_contact(self):
        s = scene(1100);s['encounter']['participants']['A']['position_m']=[3,0]
        command(s,'A',0,'walk');climb(s,time=100)
        r = run(s)
        self.assertEqual(len(events(r,'climb_range_checked','A')),1)
        self.assertFalse(events(r,'climb_active_started','A'))
        self.assertTrue(events(r,'body_contact'))
        self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),D('4.95'),places=25)

    def test_nonclimbable_and_unknown_targets_reject_without_blocking_later_intents(self):
        s = scene(300)
        climb(s,target='cube_2');climb(s,target='missing');command(s,'A',0,'walk')
        r = run(s)
        self.assertEqual([e['reason'] for e in events(r,'climb_rejected','A')],
                         ['target_not_climbable','unknown_climb_target'])
        self.assertFalse(events(r,'dyspnea_paid','A'))
        self.assertTrue(events(r,'movement_active_started','A'))

    def test_physical_contact_preserves_climb_gathering_and_extends_it(self):
        s = scene(850);command(s,'A',0,'walk');climb(s,time=100)
        r = run(s)
        contact = events(r,'body_contact')[0]
        start = events(r,'climb_active_started','A')[0]
        self.assertEqual(D(contact['time_ms']),205)
        self.assertGreater(D(start['time_ms']),250)
        self.assertTrue(events(r,'gathering_extended','A'))
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)

    def test_running_modifiers_apply_without_slowing_the_prescribed_path(self):
        s = scene(900);s['encounter']['participants']['A']['position_m']=['4.6',-2]
        s['encounter']['participants']['A']['movement_direction']=[0,1]
        command(s,'A',0,'run');climb(s,time=300)
        r = run(s)
        start = events(r,'climb_active_started','A')[0]
        self.assertEqual(D(start['time_ms']),480)
        self.assertEqual(start['self_effects'],{'disorientation':'96.0','instability':'300.0'})
        self.assertEqual(D(start['active_end_ms'])-D(start['time_ms']),300)
        self.assertEqual(tuple(map(D,r['final_states']['A']['position_m'])),(6,0))

    def test_gun_hit_during_gathering_uses_shared_extension_and_pre_hit_defenses(self):
        s = scene(800,target=(-30,0));s['action_selection']['B']['start_ms']=0;climb(s)
        r = run(s)
        self.assertEqual(D(events(r,'climb_active_started','A')[0]['time_ms']),216)
        self.assertEqual(len(events(r,'gathering_extended','A')),1)
        self.assertLess(D(r['final_states']['A']['hp']),8140)

    def test_live_gun_hit_tracks_the_climbing_body_and_does_not_cancel_active(self):
        s = scene(700,target=(-30,0));s['action_selection']['B']['start_ms']=170;climb(s)
        r = run(s)
        hit = events(r,'projectile_body_collision')[0]
        self.assertEqual(hit['hit_parts'],['left_leg'])
        self.assertGreater(D(hit['time_ms']),D('318.75'))
        self.assertLess(D(hit['time_ms']),450)
        self.assertEqual(D(events(r,'climb_completed','A')[0]['time_ms']),450)
        self.assertFalse(events(r,'climb_interrupted','A'))

    def test_weapons_wait_for_climb_then_release_from_raised_hand_origin(self):
        s = scene(900,fire_at=0,target=(-30,0));climb(s)
        r = run(s)
        shot = events(r,'projectile_released','A')[0]
        self.assertGreater(D(shot['time_ms']),450)
        self.assertEqual(D(shot['origin_m'][2]),D('2.825'))
        self.assertTrue(events(r,'projectile_body_collision','A'))

    def test_crouched_request_stands_through_existing_paid_transition_first(self):
        s = scene(1100);command(s,'A',0,'crouch');climb(s,time=200)
        r = run(s)
        stand = events(r,'stand_completed','A')[0]
        requested = events(r,'climb_requested','A')[0]
        self.assertEqual(stand['time_ms'],requested['time_ms'])
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'standing')

    def test_sprint_request_uses_existing_run_exit_and_stops_sprint_effort(self):
        s = scene(1600);s['encounter']['participants']['A']['position_m']=['4.6',-8]
        s['encounter']['participants']['A']['movement_direction']=[0,1]
        command(s,'A',0,'sprint');climb(s,time=700)
        r = run(s)
        start = events(r,'climb_active_started','A')[0]
        exit_run = [e for e in events(r,'movement_active_completed','A') if e['action']=='run' and D(e['time_ms'])>700][0]
        self.assertLess(D(exit_run['time_ms']),D(start['time_ms']))
        self.assertTrue(all(D(e['interval_end_ms'])<=D(exit_run['time_ms'])
                            for e in events(r,'sprint_dyspnea_gained','A')))
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)

    def test_jump_after_climb_lands_on_the_same_raised_support(self):
        s = scene(1500);climb(s);command(s,'A',500,'jump')
        r = run(s)
        landing = events(r,'jump_landed','A')[0]
        self.assertEqual(landing['support_id'],'cube_1')
        self.assertAlmostEqual(D(landing['time_ms']),D(600)+D(640000)/981,places=23)
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),D('1.8'))

    def test_death_before_successful_start_pays_nothing(self):
        s = scene(500,target=(-30,0));s['action_selection']['B']['start_ms']=0
        s['encounter']['participants']['A']['initial_state']['hp']=1;climb(s)
        r = run(s)
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertFalse(events(r,'dyspnea_paid','A'))
        self.assertFalse(events(r,'climb_active_started','A'))

    def test_death_during_climb_freezes_body_and_invalidates_completion(self):
        s = scene(1000,target=(-30,0));s['action_selection']['B']['start_ms']=170
        s['encounter']['participants']['A']['initial_state']['hp']=1;climb(s)
        r = run(s)
        death = events(r,'character_died','A')[0]
        self.assertEqual(death['state']['body_origin_m'],r['final_states']['A']['body_origin_m'])
        self.assertFalse(events(r,'climb_completed','A'))
        self.assertEqual(events(r,'climb_interrupted','A')[0]['reason'],'death')
        self.assertEqual(r['metrics']['A']['climb_interruptions'],1)
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])

    def test_other_body_on_top_interrupts_climb_and_lands_on_real_support(self):
        s = scene(1500,target=('7.4',0));climb(s,time=500);climb(s,actor='B')
        r = run(s,sample_interval_ms=None)
        self.assertEqual(r['metrics']['B']['climbs_completed'],1)
        self.assertEqual(r['metrics']['A']['climbs_completed'],0)
        self.assertEqual(len(events(r,'climb_interrupted','A')),1)
        self.assertTrue(events(r,'body_contact'))
        self.assertEqual(events(r,'jump_landed','A')[0]['support_id'],'cube_1')
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_ceiling_interrupts_path_then_shared_gravity_returns_to_floor(self):
        s = scene(1100);climb(s)
        class CeilingEncounter(SharedEncounter):
            def __init__(self,*args,**kwargs):
                super().__init__(*args,**kwargs)
                add_fixture_collider(self,'ceiling',(Cuboid('ceiling',[4.6,0,'2.9'],[1,2,'.2']),))
        with localcontext(Context(prec=50)):
            r = CeilingEncounter(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=EFFECTS,
                jump_definition=JUMP,climb_definition=CLIMB,projectile_physics_definition=PHYSICS).run()
        interrupted = events(r,'climb_interrupted','A')[0]
        contact = events(r,'body_contact')[0]
        self.assertEqual(contact['second'],'ceiling')
        self.assertAlmostEqual(D(interrupted['time_ms']),D('248.4375'),places=25)
        self.assertFalse(events(r,'climb_completed','A'))
        self.assertEqual(events(r,'jump_landed','A')[0]['self_effects'],{'disorientation':'0','instability':'0'})
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)

    def test_exact_overhead_fit_at_path_corner_is_not_an_impact(self):
        s = scene(800);climb(s)
        class ExactCeilingEncounter(SharedEncounter):
            def __init__(self,*args,**kwargs):
                super().__init__(*args,**kwargs)
                add_fixture_collider(self,'ceiling',(Cuboid('ceiling',[6,0,'3.65'],[4,2,'.2']),))
        for precision,interval in ((50,37),(80,None)):
            with self.subTest(precision=precision),localcontext(Context(prec=precision)):
                r = ExactCeilingEncounter(s,PROFILES,precision=precision,sample_interval_ms=interval,
                    body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,
                    combat_locomotion_definition=EFFECTS,jump_definition=JUMP,
                    climb_definition=CLIMB,projectile_physics_definition=PHYSICS).run()
                self.assertEqual(r['metrics']['A']['climbs_completed'],1)
                self.assertFalse(events(r,'climb_interrupted','A'))
                self.assertFalse(events(r,'body_contact'))

    def test_unaffordable_climb_waits_for_ground_recovery_before_gathering(self):
        s = scene(1600);s['encounter']['participants']['A']['initial_state']['dyspnea']=100;climb(s)
        r = run(s)
        request = events(r,'climb_requested','A')[0]
        payment = events(r,'dyspnea_paid','A')[0]
        self.assertGreater(D(request['time_ms']),0)
        self.assertEqual(D(payment['time_ms']),D(request['time_ms'])+150)
        before = D(payment['before'])
        self.assertAlmostEqual(D(payment['amount']),(D('3.5')+before/100)**2,places=24)
        self.assertLessEqual(D(payment['after']),100)
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)

    def test_observations_precision_and_actor_order_do_not_change_climb_outcome(self):
        s = scene(1000,target=(-30,0));s['action_selection']['B']['start_ms']=170;climb(s)
        reference = run(s,sample_interval_ms=None)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        for precision,interval in ((50,37),(80,113)):
            actual = run(s,precision=precision,sample_interval_ms=interval)
            self.assertEqual([e['time_ms'] for e in events(actual,'climb_completed')],
                             [e['time_ms'] for e in events(reference,'climb_completed')])
            for name in ('A','B'):
                for key in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertLessEqual(abs(D(actual['final_states'][name][key])-D(reference['final_states'][name][key])),D('1e-7'))

    def test_definition_validation_and_missing_flight_rules(self):
        s = scene();climb(s)
        legacy = deepcopy(EFFECTS);legacy.pop('world')
        with self.assertRaisesRegex(ValueError,'flight rules'):
            air_run(s,climb_definition=CLIMB,jump=None,effects=legacy)
        self.assertEqual(air_run(s,climb_definition=CLIMB,jump=None)['metrics']['A']['climbs_completed'],1)
        with self.assertRaises(UnsupportedMechanicError):
            air_run(s,climb_definition=read('data/movement/climb.json'))
        for field,value in (('activation_check','continuously'),('payment_timing','request'),('interruption','ignore_solids')):
            definition = deepcopy(CLIMB);definition[field]=value
            with self.subTest(field=field),self.assertRaises(UnsupportedMechanicError):
                air_run(s,climb_definition=definition)


if __name__=='__main__':
    unittest.main()
