"""Fixed points are constants, not simulated characters or massive nodes."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import json,unittest

from combat_sim.mechanics.distance_projection import FixedPoint,FixedDistance,MaximumDistance,project_distances
from combat_sim.mechanics.distance_path import build_distance_path
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality
from combat_sim.mechanics.constraint_response import path_force_coefficients


class FixedDistanceTests(unittest.TestCase):
    def test_radial_stop_and_inward_freedom_use_only_the_real_body(self):
        edge=FixedDistance('A',FixedPoint('ground',(0,0,0)),10)
        for requested,expected in (((4,0,0),(0,0,0)),((-4,0,0),(-4,0,0))):
            r=project_distances((VelocityNode('A',requested,8140,150),),{'A':(10,0,0)},1,(edge,))
            self.assertEqual(dict(r.exact_velocities),{'A':expected})
            self.assertEqual(tuple(n for n,_ in r.linear_projection.weights),('A',))

    def test_finite_answer_matches_independent_ball_projection(self):
        with localcontext(Context(prec=60)):
            r=project_distances((VelocityNode('A',(3,4,0),8140,150),),{'A':(10,0,0)},'.5',
                (FixedDistance('A',FixedPoint('ground',(0,0,0)),10),))
            scale=D(10)/(D('11.5')**2+4).sqrt()
            expected=((D('11.5')*scale-10)*2,4*scale,D(0))
            self.assertTrue(all(abs(x-y)<D('1e-10') for x,y in zip(dict(r.velocities)['A'],expected)))

    def test_whole_path_certificate_keeps_anchor_out_of_dynamic_pieces(self):
        point=FixedPoint('ground',(0,0,0))
        r=build_distance_path((VelocityNode('A',(0,4,0),8140,150),),{'A':(10,0,0)},0,5,
            (FixedDistance('A',point,10),))
        self.assertEqual(r.fixed_points,(('ground',(0,0,0)),));self.assertEqual([n for n,_ in r.pieces],['A'])
        p=dict(r.pieces)['A']
        for i in range(65):self.assertLessEqual(sum(x*x for x in p.position(F(5*i,64))),100)
        self.assertTrue(all(c<=0 for c in r.bernstein_certificate[0][3]))
        json.dumps(r.record())

    def test_joint_fixed_pair_and_grapple_constraints_remain_exact(self):
        nodes=(VelocityNode('A',(4,0,0),8140,150),VelocityNode('B',(4,0,0),20000,350))
        refs={'A':(10,0,0),'B':(11,0,0)}
        r=project_distances(nodes,refs,1,(FixedDistance('A',FixedPoint('ground',(0,0,0)),10),MaximumDistance('A','B',1)),
            equalities=(VelocityEquality('A','B'),))
        self.assertEqual(dict(r.exact_velocities),{'A':(0,0,0),'B':(0,0,0)})

    def test_tangent_fixed_balls_can_have_only_one_feasible_position(self):
        edges=(FixedDistance('A',FixedPoint('left',(-5,0,0)),5),FixedDistance('A',FixedPoint('right',(5,0,0)),5))
        r=build_distance_path((VelocityNode('A',(1,4,0),8140,150),),{'A':(0,0,0)},0,5,edges)
        self.assertEqual(dict(r.pieces)['A'].position(5),(0,0,0))
        self.assertEqual(dict(r.pieces)['A'].velocity(5),(0,0,0))

    def test_force_transport_has_no_anchor_recipient(self):
        r=build_distance_path((VelocityNode('A',(3,4,0),8140,150),),{'A':(10,0,0)},0,5,
            (FixedDistance('A',FixedPoint('ground',(0,0,0)),10),))
        response=path_force_coefficients(r,{'A':(3,4,0)})
        self.assertEqual(set(response),{'A'})

    def test_input_order_and_duplicate_anchor_limits_do_not_change_velocity(self):
        nodes=(VelocityNode('A',(4,3,0),8140,150),)
        refs={'A':(0,0,0)}
        edges=(FixedDistance('A',FixedPoint('left',(-5,0,0)),5),FixedDistance('A',FixedPoint('right',(5,0,0)),6))
        a=project_distances(nodes,refs,1,edges);b=project_distances(nodes,refs,1,tuple(reversed(edges))+edges)
        self.assertEqual(a,b)

    def test_fixed_identity_validation_does_not_admit_fake_bodies(self):
        node=(VelocityNode('A',(0,0,0),8140,150),);refs={'A':(0,0,0)}
        for edges in ((FixedDistance('missing',FixedPoint('g',(0,0,0)),1),),
                (FixedDistance('A',FixedPoint('same',(0,0,0)),1),FixedDistance('A',FixedPoint('same',(1,0,0)),1))):
            with self.assertRaises(ValueError):project_distances(node,refs,1,edges)


if __name__=='__main__':unittest.main()
