"""Oriented inputs to the existing projectile and body contact APIs.

These are fixed-frame geometry contracts. They do not claim that the shared
world already advances turning bodies or accepts arbitrary actor facing.
"""
from decimal import Context,Decimal as D,ROUND_UP,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.moving_projectiles import earliest_moving_sphere_contact
from combat_sim.movement_contacts import first_box_contact
from combat_sim.terrain import RectangularGround
from tests.test_oriented_geometry import polygon_intersection,area

ZERO=(0,0,0)


class OrientedContactTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=70));context.__enter__();self.addCleanup(context.__exit__,None,None,None)
        self.frame=YawFrame(F(3,5),F(4,5));self.origin=(100,-30,4)
        self.box=OrientedCuboid('torso',self.origin,(2,2,2),self.frame)

    def point(self,p):return self.frame.to_world_point(p,self.origin)
    def vector(self,p):return self.frame.to_world_vector(p)

    def hit(self,origin=(-5,0,0),velocity=(10,0,0),acceleration=ZERO,*,radius='.1',box=None,
            box_velocity=ZERO,box_acceleration=ZERO,duration=1,precision=50,**kw):
        return earliest_moving_sphere_contact(self.point(origin),self.vector(velocity),self.vector(acceleration),radius,
            self.box if box is None else box,self.vector(box_velocity),self.vector(box_acceleration),duration,precision,**kw)

    def near(self,actual,expected,tolerance='1e-38'):
        self.assertLessEqual(abs(D(actual)-D(expected)),D(tolerance))

    def test_face_contact_retains_analytic_time_and_world_receiver_point(self):
        hit=self.hit();self.near(hit.time_s,'.39')
        for a,b in zip(hit.centre_m,self.point(('-1.1',0,0))):self.near(a,D(b.numerator)/D(b.denominator))
        for a,b in zip(hit.closest_box_point_m,self.point((-1,0,0))):self.near(a,D(b.numerator)/D(b.denominator))

    def test_moving_target_uses_world_velocity_without_rotating_it_twice(self):
        hit=self.hit(box_velocity=(2,0,0));self.near(hit.time_s,'.4875')
        for a,b in zip(hit.closest_box_point_m,self.point(('-.025',0,0))):self.near(a,D(b.numerator)/D(b.denominator))

    def test_acceleration_roots_keep_outward_bounds(self):
        hit=self.hit(velocity=ZERO,acceleration=(20,0,0));expected=D('.39').sqrt()
        self.near(hit.time_s,expected);self.assertLessEqual(hit.time_lower_s,expected)
        self.assertGreaterEqual(hit.time_upper_s,expected)

    def test_relative_body_acceleration_has_same_contact_time(self):
        a=self.hit(velocity=ZERO,acceleration=(20,0,0))
        b=self.hit(velocity=ZERO,box_acceleration=(-20,0,0));self.assertEqual(a.time_s,b.time_s)

    def test_quartic_corner_has_the_actual_sphere_distance(self):
        hit=self.hit(origin=(-3,1,0),velocity=(0,'.05',0),acceleration=(2,0,0),radius='.2',duration=2)
        t=hit.time_s;self.assertLess(abs((t*t-2)**2+(t/20)**2-D('.04')),D('1e-38'))
        distance=sum((a-b)**2 for a,b in zip(hit.centre_m,hit.closest_box_point_m))
        self.near(distance,'.04')

    def test_rotated_corner_tangency_is_closed_contact(self):
        hit=self.hit(origin=(-5,1,'1.1'));self.near(hit.time_s,'.4')

    def test_initial_overlap_and_zero_duration_are_preserved(self):
        self.assertEqual(self.hit(origin=ZERO,duration=0).time_s,0)
        self.assertIsNone(self.hit(duration=0))

    def test_accelerated_local_size_growth_uses_shape_axes(self):
        hit=self.hit(origin=(-2,0,0),velocity=ZERO,radius=0,duration=2,box_size_acceleration_mps2=(4,0,0))
        self.near(hit.time_s,1)

    def test_local_size_rate_is_not_a_world_axis_dimension(self):
        box=OrientedCuboid('growing',self.origin,(1,2,2),self.frame)
        hit=self.hit(origin=(-3,0,0),velocity=(2,0,0),box=box,radius=0,box_size_rate_mps=(2,0,0))
        self.near(hit.time_s,D(5)/6)

    def test_straight_and_accelerated_api_agree_for_linear_path(self):
        hit=self.hit();static=self.box.swept_sphere_contact(self.point((-5,0,0)),self.point((5,0,0)),'.1')
        self.near(hit.time_s,static.parameter)
        for a,b in zip(hit.closest_box_point_m,static.closest_box_point_m):self.near(a,b)

    def test_sphere_path_through_enclosing_corner_is_a_true_miss(self):
        box=OrientedCuboid('thin',ZERO,(4,'.2',2),self.frame)
        self.assertIsNone(earliest_moving_sphere_contact(('1.6','1.2',-3),(0,0,6),ZERO,'.01',box,ZERO,ZERO,1))

    def test_world_contact_coordinates_ignore_caller_rounding_context(self):
        a=self.hit()
        with localcontext(Context(prec=4,rounding=ROUND_UP)):b=self.hit()
        self.assertEqual(a,b)

    def test_precision_refinement_preserves_oriented_contact(self):
        a=self.hit(origin=(-5,'1.05','1.05'));b=self.hit(origin=(-5,'1.05','1.05'),precision=80)
        self.near(a.time_s,b.time_s)
        for x,y in zip(a.centre_m,b.centre_m):self.near(x,y)

    def test_refined_degree_frames_agree_for_one_fixed_world_ray(self):
        first=OrientedCuboid('shape',ZERO,(4,'.2',2),YawFrame.from_degrees(37,precision=50))
        second=OrientedCuboid('shape',ZERO,(4,'.2',2),YawFrame.from_degrees(37,precision=80))
        a=earliest_moving_sphere_contact((-5,0,0),(10,0,0),ZERO,'.02',first,ZERO,ZERO,1,50)
        b=earliest_moving_sphere_contact((-5,0,0),(10,0,0),ZERO,'.02',second,ZERO,ZERO,1,80)
        self.assertIsNotNone(a);self.assertIsNotNone(b);self.near(a.time_s,b.time_s)

    def test_invalid_oriented_projectile_inputs_still_reject(self):
        for changes in ({'radius':-1},{'duration':-1},{'precision':True},{'box_size_rate_mps':(-10,0,0)},
                {'velocity':(1,2)},{'radius':True}):
            with self.subTest(changes=changes),self.assertRaises(ValueError):self.hit(**changes)

    def translated_pair(self):
        a=OrientedCuboid('a',self.point((0,0,0)),(1,1,2),self.frame)
        b=OrientedCuboid('b',self.point((3,0,0)),(1,1,2),self.frame)
        return a,b

    def test_body_translation_and_acceleration_retain_analytic_entry(self):
        a,b=self.translated_pair()
        self.near(first_box_contact(a,b,self.vector((2,0,0)),ZERO,2),1)
        self.near(first_box_contact(a,b,ZERO,self.vector((4,0,0)),2),1)

    def test_body_initial_tangent_separation_and_approach_remain_distinct(self):
        a,_=self.translated_pair();b=OrientedCuboid('b',self.point((1,0,0)),(1,1,2),self.frame)
        self.assertIsNone(first_box_contact(a,b,self.vector((-1,0,0)),ZERO,1))
        self.assertIsNone(first_box_contact(a,b,self.vector((0,1,0)),ZERO,1))
        self.near(first_box_contact(a,b,self.vector((1,0,0)),ZERO,1),0)

    def test_body_aabb_overlap_does_not_become_a_solid_collision(self):
        a=OrientedCuboid('thin',ZERO,(4,'.2',2),self.frame)
        b=Cuboid('small',('1.6','1.2',0),('.05',)*3)
        self.assertIsNone(first_box_contact(a,b,ZERO,ZERO,1))

    def test_mixed_orientation_body_entry_matches_independent_polygon_bisection(self):
        for tangent in (F(1,3),F(-1,2),F(3,4)):
            first=OrientedCuboid('a',(5,3,0),(2,'.4',2),self.frame)
            second=OrientedCuboid('b',ZERO,(1,'1.7',2),YawFrame.from_half_angle_tangent(tangent))
            hit=first_box_contact(first,second,(-5,-3,0),ZERO,1)
            self.assertIsNotNone(hit);low,high=F(0),F(1)
            for _ in range(100):
                t=(low+high)/2
                moved=OrientedCuboid('a',(5*(1-t),3*(1-t),0),first.size_m,first.frame)
                if area(polygon_intersection(moved,second))>0:high=t
                else:low=t
            self.near(hit,(D(low.numerator)/D(low.denominator)+D(high.numerator)/D(high.denominator))/2,'1e-28')

    def test_resizing_body_contact_uses_local_dimensions(self):
        a,b=self.translated_pair()
        hit=first_box_contact(a,b,self.vector((1,0,0)),ZERO,2,left_size_rate_mps=(2,0,0))
        self.near(hit,1)

    def test_quadratic_body_size_growth_composes_with_projected_motion(self):
        a,b=self.translated_pair()
        hit=first_box_contact(a,b,ZERO,ZERO,2,left_size_acceleration_mps2=(8,0,0))
        self.near(hit,1)

    def test_rotated_body_can_land_on_finite_ground(self):
        ground=RectangularGround('ground',(-2,-2,0),(2,2,0))
        body=OrientedCuboid('body',('2.05','2.05',1),(4,'.2','.5'),self.frame)
        self.near(first_box_contact(body,ground,(0,0,-1),ZERO,1,allow_flat_static_right=True),'.75')

    def test_finite_ground_rejects_false_enclosing_footprint_landing(self):
        ground=RectangularGround('ground',(-2,-2,0),(2,2,0))
        body=OrientedCuboid('body',('2.3','2.3',1),(4,'.2','.5'),self.frame)
        self.assertIsNone(first_box_contact(body,ground,(0,0,-1),ZERO,1,allow_flat_static_right=True))

    def test_oriented_body_sizes_must_remain_positive(self):
        a,b=self.translated_pair()
        with self.assertRaises(ValueError):first_box_contact(a,b,ZERO,ZERO,1,left_size_rate_mps=(-2,0,0))

