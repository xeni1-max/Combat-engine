"""Basic jump lifecycle, physical contacts and combat on the shared clock."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.mechanics.status import mitigate_status
from combat_sim.models import UnsupportedMechanicError
from tests.test_mobile_combat import command, events, read
from tests.test_sprint_combat import exhaustion_reference, run as combat_run, scenario


JUMP = read('data/movement/combat_jump.json')


def run(s, *, jump=JUMP, **kwargs):
    return combat_run(s, jump_definition=jump, **kwargs)


class AirborneCombatTests(unittest.TestCase):
    def test_standing_jump_pays_at_takeoff_and_retains_hand_pose(self):
        s = scenario(700, target=(100, -20))
        command(s, 'A', 0, 'jump')
        result = run(s)
        takeoff = events(result, 'jump_takeoff', 'A')[0]
        payment = events(result, 'dyspnea_paid', 'A')[0]
        self.assertEqual(D(takeoff['time_ms']), 100)
        self.assertEqual(tuple(map(D, takeoff['velocity_mps'])), (0, 0, D('3.2')))
        self.assertEqual(takeoff['self_effects'], {'disorientation': '80', 'instability': '80'})
        self.assertEqual((D(payment['time_ms']), D(payment['amount'])), (100, D('2.25')))
        initial = result['curve'][0]['states']['A']
        final = result['final_states']['A']
        self.assertEqual(final['hands_m'], initial['hands_m'])
        self.assertEqual(D(final['dyspnea']), D('2.25'))
        self.assertFalse(final['locomotion']['grounded'])
        self.assertFalse(events(result, 'recovery_started', 'A'))

    def test_active_ends_before_flight_and_height_follows_gravity(self):
        s = scenario(500, target=(100, -20))
        command(s, 'A', 0, 'jump')
        result = run(s)
        completed = events(result, 'jump_active_completed', 'A')[0]
        self.assertEqual(D(completed['time_ms']), 250)
        self.assertTrue(completed['airborne'])
        elapsed = D('.4')
        expected = D('3.2')*elapsed-D('9.81')*elapsed*elapsed/2
        final = result['final_states']['A']
        self.assertAlmostEqual(D(final['locomotion']['height_above_ground_m']), expected, places=30)
        self.assertAlmostEqual(D(final['locomotion']['velocity_mps'][2]), D('3.2')-D('9.81')*elapsed, places=30)
        self.assertIsNone(final['current_action'])

    def test_landing_combines_self_penalties_and_resisted_physical_contact_once(self):
        s = scenario(1100, target=(100, -20))
        command(s, 'A', 0, 'jump')
        result = run(s, sample_interval_ms=None)
        lands = events(result, 'jump_landed', 'A')
        contacts = events(result, 'body_contact')
        self.assertEqual((len(lands), len(contacts)), (1, 1))
        with localcontext(Context(prec=60)):
            expected_time = D(100)+D(640000)/981
            physical = mitigate_status(192, 8140, 150, 0)
        self.assertAlmostEqual(D(lands[0]['time_ms']), expected_time, places=35)
        self.assertEqual(D(contacts[0]['raw_status']), 192)
        applied = [e for e in events(result, 'target_status_applied')
                   if e['target'] == 'A' and e['time_ms'] == lands[0]['time_ms']]
        self.assertEqual(len(applied), 1)
        self.assertAlmostEqual(D(applied[0]['additions']['disorientation']), physical+100, places=24)
        self.assertAlmostEqual(D(applied[0]['additions']['instability']), physical+120, places=24)
        self.assertEqual(D(result['final_states']['A']['body_origin_m'][2]), D('.875'))
        self.assertTrue(result['final_states']['A']['locomotion']['grounded'])

    def test_running_jump_retains_actual_horizontal_speed_before_self_instability(self):
        s = scenario(700, target=(100, -20))
        command(s, 'A', 0, 'run')
        command(s, 'A', 300, 'jump')
        result = run(s)
        takeoff = events(result, 'jump_takeoff', 'A')[0]
        self.assertEqual(D(takeoff['time_ms']), 420)
        self.assertEqual(tuple(map(D, takeoff['velocity_mps'])), (D('6.4'), 0, D('3.2')))
        self.assertEqual(D(takeoff['self_effects']['instability']), 96)
        samples = [p['states']['A'] for p in result['curve'] if 420 < D(p['time_ms']) <= 700]
        self.assertTrue(samples)
        self.assertTrue(all(D(p['locomotion']['velocity_mps'][0]) == D('6.4') for p in samples))

    def test_weapons_can_start_and_release_after_active_while_airborne(self):
        s = scenario(650, fire_at=0, target=(200, -20))
        command(s, 'A', 0, 'jump')
        result = run(s)
        release = events(result, 'projectile_released', 'A')[0]
        self.assertGreater(D(release['time_ms']), 250)
        self.assertLess(D(release['time_ms']), 752)
        self.assertGreater(D(str(release['origin_m'][2])), D('.875'))
        self.assertTrue(events(result, 'projectile_body_collision', 'A'))

    def test_shot_intersects_the_actual_airborne_body_region(self):
        s = scenario(450, fire_at=0, target=(200, -20))
        baseline = run(s)
        command(s, 'B', 0, 'jump')
        result = run(s)
        ground_hit = events(baseline, 'projectile_body_collision')[0]
        air_hit = events(result, 'projectile_body_collision')[0]
        self.assertIn('torso', ground_hit['hit_parts'])
        self.assertIn('left_leg', air_hit['hit_parts'])
        self.assertNotIn('torso', air_hit['hit_parts'])
        self.assertLess(D(result['final_states']['B']['hp']), 8140)

    def test_airborne_horizontal_motion_can_make_unled_projectile_miss(self):
        s = scenario(1500, fire_at=600, target=(100, -20))
        s['encounter']['participants']['B']['movement_direction'] = [0, 1]
        command(s, 'B', 0, 'run')
        command(s, 'B', 400, 'jump')
        result = run(s)
        takeoff = events(result, 'jump_takeoff', 'B')[0]
        release = events(result, 'projectile_released', 'A')[0]
        self.assertLess(D(takeoff['time_ms']), D(release['time_ms']))
        self.assertFalse(events(result, 'projectile_body_collision'))
        self.assertEqual(D(result['final_states']['B']['hp']), 8140)

    def test_wall_contact_removes_horizontal_motion_and_preserves_vertical_flight(self):
        s = scenario(1200, target=(100, -20))
        s['encounter']['participants']['A']['position_m'] = [3, 0]
        command(s, 'A', 0, 'run')
        command(s, 'A', 250, 'jump')
        result = run(s, sample_interval_ms=50)
        contacts = events(result, 'body_contact')
        self.assertEqual([e['second'] for e in contacts], ['cube_1', 'ground'])
        self.assertAlmostEqual(D(contacts[0]['time_ms']), D('410.475'), places=20)
        after_wall = next(p['states']['A'] for p in result['curve'] if D(p['time_ms']) == 450)
        self.assertEqual(D(after_wall['locomotion']['velocity_mps'][0]), 0)
        self.assertGreater(D(after_wall['locomotion']['velocity_mps'][2]), 0)
        self.assertFalse(after_wall['locomotion']['grounded'])
        with localcontext(Context(prec=60)):
            expected_landing = D(370)+D(640000)/981
        self.assertAlmostEqual(D(events(result, 'jump_landed', 'A')[0]['time_ms']), expected_landing, places=35)
        self.assertAlmostEqual(D(result['final_states']['A']['position_m'][0]), D('4.95'), places=25)

    def test_oblique_body_contact_preserves_ground_support_without_resting_reimpacts(self):
        s = scenario(1300, target=(6, -20))
        command(s, 'A', 0, 'run')
        command(s, 'B', 0, 'run')
        command(s, 'A', 250, 'jump')
        result = run(s, sample_interval_ms=50)
        contacts = events(result, 'body_contact')
        self.assertEqual([(e['first'], e['second']) for e in contacts], [('A', 'B'), ('A', 'ground')])
        self.assertAlmostEqual(D(contacts[0]['time_ms']), D('551.1'), places=25)
        self.assertTrue(all(D(p['states']['B']['body_origin_m'][2]) == D('.875')
                            for p in result['curve']))
        self.assertTrue(all(D(p['states']['B']['locomotion']['velocity_mps'][2]) == 0
                            for p in result['curve']))
        for actor in ('A', 'B'):
            final = result['final_states'][actor]
            self.assertTrue(final['locomotion']['grounded'])
            self.assertEqual(D(final['locomotion']['speed_mps']), 0)

    def test_ground_intents_wait_for_landing_without_blocking_airborne_weapon(self):
        s = scenario(1000, fire_at=0, target=(200, -20))
        command(s, 'A', 0, 'jump')
        command(s, 'A', 300, 'run')
        result = run(s)
        self.assertTrue(events(result, 'projectile_released', 'A'))
        landing = D(events(result, 'jump_landed', 'A')[0]['time_ms'])
        starts = events(result, 'movement_active_started', 'A')
        self.assertTrue(starts)
        self.assertTrue(all(D(e['time_ms']) >= landing for e in starts))

    def test_body_contact_can_lift_walker_without_charging_a_jump(self):
        s = scenario(1250, target=(4, '-20.3'))
        s['encounter']['participants']['B']['movement_direction'] = [1, '.2']
        command(s, 'A', 0, 'run')
        command(s, 'A', 250, 'jump')
        command(s, 'B', 0, 'walk')
        result = run(s, sample_interval_ms=25)
        airborne = next(p['states']['B'] for p in result['curve'] if D(p['time_ms']) == 1000)
        self.assertFalse(airborne['locomotion']['grounded'])
        self.assertGreater(D(airborne['locomotion']['height_above_ground_m']), 0)
        landing = events(result, 'jump_landed', 'B')
        self.assertEqual(len(landing), 1)
        self.assertEqual(landing[0]['self_effects'], {'disorientation': '0', 'instability': '0'})
        self.assertFalse(events(result, 'jump_takeoff', 'B'))
        self.assertFalse(events(result, 'dyspnea_paid', 'B'))
        self.assertEqual(result['metrics']['B']['jumps_started'], 0)
        self.assertTrue(result['final_states']['B']['locomotion']['grounded'])
        # Physical contact evolves independently of observation boundaries and
        # does not turn incidental upward velocity into a paid jump ability.
        alternate = run(s, precision=80, sample_interval_ms=None)
        self.assertAlmostEqual(D(events(alternate, 'jump_landed', 'B')[0]['time_ms']),
                               D(landing[0]['time_ms']), places=30)
        for name in ('A', 'B'):
            for actual, expected in zip(alternate['final_states'][name]['body_origin_m'],
                                        result['final_states'][name]['body_origin_m']):
                self.assertAlmostEqual(D(actual), D(expected), places=30)

    def test_incidentally_airborne_sprint_exhaustion_waits_to_stop_on_ground(self):
        s = scenario(1400, target=(-3, '-20.3'))
        s['encounter']['participants']['B']['movement_direction'] = [1, '-.03']
        s['encounter']['participants']['B']['initial_state']['dyspnea'] = '89.8'
        command(s, 'A', 0, 'run')
        command(s, 'A', 250, 'jump')
        command(s, 'B', 0, 'sprint')
        for precision, interval in ((50, 20), (80, None)):
            with self.subTest(precision=precision, interval=interval):
                result = run(s, precision=precision, sample_interval_ms=interval)
                contact = next(e for e in events(result, 'body_contact') if e['second'] == 'B')
                exhausted = events(result, 'maximum_dyspnea_trigger', 'B')
                landed = events(result, 'jump_landed', 'B')
                stopped = events(result, 'special_stop_started', 'B')
                self.assertEqual((len(exhausted), len(landed), len(stopped)), (1, 1, 1))
                cap = D(exhausted[0]['time_ms'])
                self.assertAlmostEqual(cap, exhaustion_reference('89.8'), places=30)
                self.assertLess(D(contact['time_ms']), cap)
                self.assertLess(cap, D(landed[0]['time_ms']))
                self.assertEqual(D(exhausted[0]['added_disorientation']), 240)
                self.assertEqual(stopped[0]['time_ms'], landed[0]['time_ms'])
                self.assertTrue(all(D(e['interval_end_ms']) <= cap
                                    for e in events(result, 'sprint_dyspnea_gained', 'B')))
                self.assertEqual(result['metrics']['B']['jumps_started'], 0)
                self.assertTrue(result['final_states']['B']['locomotion']['grounded'])
                self.assertEqual(result['final_states']['B']['locomotion']['mode'], 'standing')

    def test_queued_stop_starts_only_after_running_jump_lands(self):
        s = scenario(1400, target=(100, -20))
        command(s, 'A', 0, 'run')
        command(s, 'A', 300, 'jump')
        command(s, 'A', 500, 'stop')
        result = run(s)
        landing = events(result, 'jump_landed', 'A')[0]
        stop = events(result, 'special_stop_started', 'A')[0]
        self.assertEqual(D(stop['time_ms']), D(landing['time_ms']))
        self.assertEqual(D(result['final_states']['A']['locomotion']['speed_mps']), 0)

    def test_incoming_disorientation_extends_jump_gathering(self):
        s = scenario(500, target=(30, -20))
        s['action_selection']['B']['start_ms'] = 0
        command(s, 'A', 100, 'jump')
        result = run(s)
        request = events(result, 'jump_requested', 'A')[0]
        takeoff = events(result, 'jump_takeoff', 'A')[0]
        self.assertEqual(D(request['active_start_ms']), 200)
        self.assertEqual(D(takeoff['time_ms']), 266)
        self.assertEqual(len(events(result, 'gathering_extended', 'A')), 1)
        self.assertEqual(len(events(result, 'jump_takeoff', 'A')), 1)

    def test_death_before_takeoff_cancels_jump_without_payment(self):
        s = scenario(500, target=(30, -20))
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        s['action_selection']['B']['start_ms'] = 0
        command(s, 'A', 100, 'jump')
        result = run(s)
        self.assertTrue(events(result, 'jump_requested', 'A'))
        self.assertFalse(events(result, 'jump_takeoff', 'A'))
        self.assertFalse(events(result, 'dyspnea_paid', 'A'))
        self.assertFalse(result['final_states']['A']['alive'])

    def test_airborne_death_freezes_body_but_released_round_survives(self):
        s = scenario(900, fire_at=0, target=(200, -20))
        s['action_selection']['B']['start_ms'] = 220
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        command(s, 'A', 0, 'jump')
        command(s, 'A', 700, 'run')
        result = run(s)
        release = events(result, 'projectile_released', 'A')[0]
        death = events(result, 'character_died', 'A')[0]
        hit = events(result, 'projectile_body_collision', 'A')[0]
        self.assertLess(D(release['time_ms']), D(death['time_ms']))
        self.assertLess(D(death['time_ms']), D(hit['time_ms']))
        self.assertEqual(release['projectile_id'], hit['projectile_id'])
        self.assertFalse(events(result, 'jump_landed', 'A'))
        self.assertEqual(tuple(map(D, death['state']['body_origin_m'])),
                         tuple(map(D, result['final_states']['A']['body_origin_m'])))
        self.assertGreater(D(result['final_states']['A']['body_origin_m'][2]), D('.875'))
        self.assertIsNone(result['final_states']['A']['current_action'])
        self.assertTrue(events(result, 'movement_intent_rejected', 'A'))

    def test_sprint_jump_exits_to_run_before_takeoff(self):
        s = scenario(1600, target=(100, -20))
        command(s, 'A', 0, 'sprint')
        command(s, 'A', 600, 'jump')
        result = run(s)
        takeoff = events(result, 'jump_takeoff', 'A')[0]
        exits = [e for e in events(result, 'movement_active_started', 'A')
                 if e['action'] == 'run' and D(e['time_ms']) >= 600]
        self.assertEqual(len(exits), 1)
        self.assertLessEqual(D(exits[0]['active_end_ms']), D(takeoff['time_ms']))
        self.assertEqual(D(takeoff['velocity_mps'][0]), D('6.4'))

    def test_observations_precision_and_actor_order_preserve_outcomes(self):
        s = scenario(1400, fire_at=0, target=(100, -20))
        command(s, 'A', 0, 'jump')
        command(s, 'A', 400, 'run')
        baseline = run(s, sample_interval_ms=None)
        s['encounter']['participants'] = dict(reversed(list(s['encounter']['participants'].items())))
        for precision, interval in ((50, 37), (80, 113)):
            actual = run(s, precision=precision, sample_interval_ms=interval)
            self.assertEqual(len(events(actual, 'jump_landed')), len(events(baseline, 'jump_landed')))
            self.assertEqual(len(events(actual, 'projectile_body_collision')), len(events(baseline, 'projectile_body_collision')))
            for name in ('A', 'B'):
                final, expected = actual['final_states'][name], baseline['final_states'][name]
                for field in ('hp', 'armor', 'shield', 'dyspnea', 'disorientation', 'instability'):
                    self.assertLessEqual(abs(D(final[field])-D(expected[field])), D('1e-7'))
                for x, y in zip(final['body_origin_m'], expected['body_origin_m']):
                    self.assertLessEqual(abs(D(x)-D(y)), D('1e-9'))

    def test_jump_requires_its_explicit_supported_definition(self):
        s = scenario()
        command(s, 'A', 0, 'jump')
        with self.assertRaises(UnsupportedMechanicError):
            run(s, jump=None)
        for field, value in (('air_control', 'free_steering'), ('takeoff_timing', 'active_end'),
                             ('hands', 'invented_jump_pose')):
            definition = deepcopy(JUMP)
            definition[field] = value
            with self.subTest(field=field), self.assertRaises(UnsupportedMechanicError):
                run(s, jump=definition)

    def test_body_and_projectile_gravity_must_agree(self):
        definition = deepcopy(JUMP)
        definition['gravity_mps2'] = '10'
        with self.assertRaisesRegex(ValueError, 'gravity must agree'):
            run(scenario(), jump=definition)

    def test_unaffordable_jump_waits_for_ground_recovery_before_gathering(self):
        s = scenario(600, target=(100, -20))
        s['encounter']['participants']['A']['initial_state']['dyspnea'] = 100
        command(s, 'A', 0, 'jump')
        result = run(s)
        request = events(result, 'jump_requested', 'A')[0]
        payment = events(result, 'dyspnea_paid', 'A')[0]
        self.assertEqual(D(request['time_ms']), 199)
        self.assertEqual(D(payment['time_ms']), 299)
        self.assertEqual(D(payment['before']), D('94.03'))
        self.assertEqual(D(payment['after']), D('99.98506409'))
        self.assertEqual(D(result['final_states']['A']['dyspnea']), D(payment['after']))
        self.assertTrue(all(0 <= D(p['states']['A']['dyspnea']) <= 100 for p in result['curve']))


if __name__ == '__main__':
    unittest.main()
