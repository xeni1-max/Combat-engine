"""Current-input native interactions for authored1E5/3E5 body proportions."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from tests.test_grappling_gun import scene as base_scene,run
from tests.test_binding_combat import run as probe_run
from tests.test_equilibrium_combat import rules
from tests.test_mobile_combat import PROFILES,command,events
from tests.test_climb_combat import climb
from tests.test_world_colliders_combat import wall
from tests.test_grapple_links_combat import force
from tests.test_1e2_precision_projectile import scene as shot_scene

HEIGHT={'1E1':D('1.75'),'1E2':D('1.75'),'1E3':D('1.75'),'1E5':D('2.275'),'2E4':D('1.75'),'3E5':D('1.8375')}


def scene(duration=1200,character='1E5'):
    s=base_scene(duration);s['id']='character_geometry';s['initial_colliders']=[]
    a=s['encounter']['participants']['A'];a['character']=character
    a['initial_state'].update(hp=PROFILES[character]['max_hp'],armor=PROFILES[character]['base_armor'])
    config=s['action_selection']['A'];config.update(abilities=['1'],start_ms=100000)
    config.pop('ability_targets')
    return s


def area_scene(ability='1'):
    s=scene(1500 if ability=='1' else 2500,'1E1')
    s['action_selection']['A'].update(abilities=[ability],start_ms=0)
    target=s['encounter']['participants']['B'];target.update(character='1E5',team='B',position_m=[5,-15.5 if ability=='1' else -12.5])
    target['initial_state'].update(hp=20000,armor=350)
    s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
    s['encounter']['participants']['C'].update(character='1E2',position_m=[5,-20])
    s['encounter']['participants']['C']['initial_state'].update(
        hp=PROFILES['1E2']['max_hp'],armor=PROFILES['1E2']['base_armor'])
    s['action_selection']['C']=deepcopy(s['action_selection']['B'])
    return s


class CharacterGeometryCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            total=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(total-D(r['final_states'][name]['hp'])-damage.amount(target=name)),D('1e-8'))
        return damage

    def test_all_six_current_profiles_place_correct_standing_bodies_on_ground(self):
        for character,height in HEIGHT.items():
            with self.subTest(character=character):
                r=run(scene(1,character));a=r['initial_states']['A']
                self.assertEqual(D(a['locomotion']['body_height_m']),height)
                self.assertEqual(D(a['body_origin_m'][2]),height/2)
                self.assertEqual(D(a['locomotion']['feet_z_m']),0)
                self.assertEqual(r['character_geometry']['actors']['A']['profile'],character)

    def test_mixed_roster_has_no_global_template_leak(self):
        s=scene(1)
        for i,character in enumerate(HEIGHT):
            name='C'+str(i);a=deepcopy(s['encounter']['participants']['A'])
            a.update(character=character,position_m=[10,i*5])
            a['initial_state'].update(hp=PROFILES[character]['max_hp'],armor=PROFILES[character]['base_armor'])
            s['encounter']['participants'][name]=a;s['action_selection'][name]=deepcopy(s['action_selection']['A'])
        r=run(s)
        for name,state in r['initial_states'].items():self.assertEqual(D(state['locomotion']['body_height_m']),HEIGHT[state['character']])

    def test_current_crouch_and_balance_combine_scaled_pose_coefficients(self):
        s=scene(100);command(s,'A',0,'crouch');r=run(s);a=r['final_states']['A'];m=a['locomotion']
        q=D(m['balance_fraction']);c=D(m['crouch_fraction']);effective=min(c,1-q)
        self.assertGreater(q,0);self.assertLess(abs(c-D(2)/3),D('1e-35'))
        self.assertLess(abs(D(m['nominal_crouch_drop_m'])-D('.52')*c),D('1e-35'))
        leg=next(b for b in r['body_geometry']['A']['parts'] if b['part']=='left_leg')
        self.assertLess(abs(D(leg['size_m'][2])-(D('1.04')-D('.72')*q-D('.52')*effective)),D('1e-35'))
        self.assertEqual(D(m['feet_z_m']),0);self.conserved(r)

    def test_authored_hand_offsets_remain_metres_and_follow_own_pose(self):
        s=scene(300);command(s,'A',0,'crouch');r=run(s);a=r['final_states']['A'];m=a['locomotion']
        q=D(m['balance_fraction']);effective=min(D(m['crouch_fraction']),1-q)
        for hand,raw in PROFILES['1E5']['initial_hand_positions_m'].items():
            x,y,z=map(D,map(str,raw));actual=list(map(D,m['hand_world_positions_m'][hand]))
            expected_z=D('1.1375')+z+q*(-D('1.1375')+D('.24')+z*D('.48')/D('2.275')-z)-D('.52')*effective
            self.assertLess(abs(actual[0]-(D(a['position_m'][0])+y)),D('1e-35'))
            self.assertLess(abs(actual[1]-(D(a['position_m'][1])-x)),D('1e-35'))
            self.assertLess(abs(actual[2]-expected_z),D('1e-35'))

    def test_all_six_actual_jumps_keep_feet_and_source_takeoff_speed(self):
        for character in HEIGHT:
            with self.subTest(character=character):
                s=scene(1500,character);command(s,'A',0,'jump');r=run(s)
                up=D(events(r,'jump_takeoff','A')[0]['velocity_mps'][2])
                expected={'1E1':D('3.2'),'1E2':D('3.2'),'1E3':D('3.2'),'1E5':D('3.5'),'2E4':D(4),'3E5':D(4)}
                self.assertEqual(up,expected[character])
                self.assertEqual(len(events(r,'jump_landed','A')),1)
                self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0);self.conserved(r)

    def test_both_scaled_characters_climb_with_their_own_foot_offset(self):
        for character in ('1E5','3E5'):
            with self.subTest(character=character):
                s=scene(1000,character);s['encounter']['participants']['A']['position_m']=['4.8',0]
                climb(s,actor='A',time=0,target='cube_1');r=run(s)
                self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),D('1.8'))
                self.assertEqual(D(r['final_states']['A']['body_origin_m'][2]),D('1.8')+HEIGHT[character]/2)
                self.conserved(r)

    def test_real_head_shots_aim_at_actual_scaled_head_centres(self):
        for character,z in (('1E5','2.1125'),('3E5','1.70625')):
            with self.subTest(character=character):
                s=shot_scene(part='head');b=s['encounter']['participants']['B'];b['character']=character
                b['initial_state'].update(hp=PROFILES[character]['max_hp'],armor=PROFILES[character]['base_armor'])
                r=run(s);flight=r['projectile_flights'][0]
                self.assertEqual(D(flight['aim_point_m'][2]),D(z))
                packet=next(e for e in events(r,'impact_batch_resolved') if e['target']=='B')['hits'][0]
                self.assertEqual(packet['hit_parts'],['head']);self.assertEqual(packet['power_component'],'projectile:head')
                self.conserved(r)

    def test_actual_qard_area_hits_larger_body_at_edge_once(self):
        s=area_scene();r=run(s);blast=events(r,'delayed_blast')[0]
        self.assertIn('B',blast['recipients']);self.assertEqual(blast['recipients'].count('B'),1)
        self.assertGreater(self.conserved(r).amount(target='B'),0)
        reference=deepcopy(PROFILES);reference['1E5'].pop('body_scale_xyz')
        control=run(s,profiles=reference)
        self.assertNotIn('B',events(control,'delayed_blast')[0]['recipients'])

    def test_actual_beam_uses_larger_width_for_exposure(self):
        s=area_scene('4');r=run(s);self.assertGreater(self.conserved(r).amount(target='B'),0)
        reference=deepcopy(PROFILES);reference['1E5'].pop('body_scale_xyz')
        control=run(s,profiles=reference);self.assertEqual(self.conserved(control).amount(target='B'),0)

    def test_scaled_body_under_cover_blocks_get_up_without_cost(self):
        s=scene(900);s['encounter']['participants']['A']['initial_state']['knocked_down']=True
        s['initial_colliders']=[wall('roof',x=0,hp=None,size=(6,6,'.2'),z='2.1')]
        r=run(s);self.assertFalse(events(r,'get_up_started','A'));self.assertTrue(r['final_states']['A']['knocked_down'])
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0);self.conserved(r)

    def test_removing_low_cover_wakes_real_scaled_get_up(self):
        s=scene(1000);s['encounter']['participants']['A']['initial_state']['knocked_down']=True
        s['initial_colliders']=[wall('roof',x=0,hp=None,size=(6,6,'.2'),z='2.1')]
        r=probe_run(s,rules=rules(),operations=((200,lambda w:w.collider_system.remove('roof',reason='body_scale_clearance_probe')),))
        self.assertEqual(D(events(r,'get_up_started','A')[0]['time_ms']),200)
        self.assertEqual(D(events(r,'get_up_completed','A')[0]['time_ms']),600)
        self.assertEqual(D(r['final_states']['A']['locomotion']['body_height_m']),D('2.275'));self.conserved(r)

    def test_scaled_dash_external_ground_destination_retains_landing(self):
        s=scene(500);s['encounter']['participants']['B']['team']='B'
        s['action_selection']['A'].update(abilities=['3'],start_ms=0)
        s['spatial_interventions']=[force(200,'A',(0,0,0),reference=(-5,-20,'1.1375'))]
        r=run(s);self.assertEqual(D(events(r,'body_launch_landed','A')[0]['time_ms']),200)
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0);self.conserved(r)

    def test_old_common_centre_is_rejected_for_new_scaled_ground_placement(self):
        s=scene(500);s['spatial_interventions']=[force(200,'A',(0,0,0),reference=(-5,-20,'.875'))]
        r=run(s);change=events(r,'spatial_intervention_processed')[0]['intervention']
        self.assertEqual(change['status'],'rejected');self.assertIn('below the ground',change['reason'])

    def test_physical_size_stays_frozen_if_a_profile_is_edited_mid_run(self):
        def edit(w):w.fighters['A'].profile['body_scale_xyz']=['9','9','9']
        r=probe_run(scene(500),rules=rules(),operations=((100,edit),))
        self.assertEqual(D(r['final_states']['A']['locomotion']['body_height_m']),D('2.275'))

    def test_scaled_bodies_rest_on_each_others_actual_head_height(self):
        # Initial stacking is an engineering placement, not a new ability.
        for upper,lower in (('1E5','3E5'),('3E5','1E5')):
            with self.subTest(upper=upper,lower=lower):
                s=scene(300,upper);b=s['encounter']['participants']['B']
                b.update(character=lower,position_m=[10,-20])
                b['initial_state'].update(hp=PROFILES[lower]['max_hp'],armor=PROFILES[lower]['base_armor'])
                reference=HEIGHT[lower]+HEIGHT[upper]/2
                s['spatial_interventions']=[force(0,'A',reference=[10,-20,str(reference)])]
                r=run(s);a=r['final_states']['A'];self.conserved(r)
                self.assertTrue(a['locomotion']['grounded']);self.assertEqual(a['locomotion']['support_id'],'B')
                self.assertEqual(D(a['locomotion']['feet_z_m']),HEIGHT[lower])
                self.assertEqual(D(a['locomotion']['body_height_m']),HEIGHT[upper])
                self.assertTrue(any(c['upper']=='A' and c['lower']=='B' and c['lower_part']=='head'
                    for c in r['body_support_contacts']))

    def test_actual_gun_death_and_engineering_restoration_retain_scaled_geometry(self):
        # Exercise the shared life interface; this does not grant a revive kit.
        for character in ('1E5','3E5'):
            with self.subTest(character=character):
                s=scene(400,character);s['encounter']['participants']['A']['initial_state']['hp']=1
                s['encounter']['participants']['B'].update(team='B',position_m=[2,-20])
                s['action_selection']['B'].update(abilities=['1'],start_ms=0,reload_when_empty=False)
                restored=[]
                def restore(w):
                    before=tuple(w.world_bodies['A'])
                    restored.append(w.life_cycles.revive('A',expected_generation=1,hp=500,
                        source='scaled_geometry_restoration_probe'))
                    # Restoration retains the actual dead pose. A partially
                    # fallen body must not silently reset to standing.
                    self.assertEqual(tuple(w.world_bodies['A']),before)
                r=probe_run(s,rules=rules(),operations=((400,restore),));self.conserved(r)
                a=r['final_states']['A'];self.assertEqual(restored,[True])
                self.assertEqual(a['life_generation'],2);self.assertGreater(D(a['hp']),0)
                self.assertEqual(D(r['character_geometry']['actors']['A']['standing_size_xyz_m'][2]),HEIGHT[character])
                self.assertEqual(D(a['locomotion']['body_height_m']),HEIGHT[character])
                self.assertEqual(D(a['locomotion']['feet_z_m']),0)
                self.assertEqual(len(events(r,'life_restored','A')),1)

    def test_source_sizes_do_not_scale_ability_costs_or_cooldowns(self):
        s=scene(1200);s['encounter']['participants']['B']['team']='B'
        s['action_selection']['A'].update(abilities=['3'],start_ms=0);r=run(s)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('6.25'))
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),5340)
        self.assertEqual(D(r['body_dash_launches'][0]['nominal_range_m']),D('13.5'));self.conserved(r)

    def test_precision_observations_and_actor_order_preserve_scaled_get_up(self):
        s=scene(600);s['encounter']['participants']['A']['initial_state']['knocked_down']=True
        a=run(s);other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        b=run(other,precision=80,interval=17)
        for name in a['final_states']:
            for field in ('hp','armor','shield','dyspnea','disorientation','instability'):
                self.assertLess(abs(D(a['final_states'][name][field])-D(b['final_states'][name][field])),D('1e-8'))
        self.assertEqual(events(a,'get_up_completed','A')[0]['time_ms'],events(b,'get_up_completed','A')[0]['time_ms'])
        self.conserved(a);self.conserved(b)

    def test_actual_chain_between_unequal_heights_does_not_reapply_running_velocity(self):
        s=scene(4200,'3E5');s['encounter']['participants']['A']['movement_direction']=[-1,0]
        s['encounter']['participants']['B'].update(team='B',position_m=[10,-20])
        s['action_selection']['A'].update(abilities=['2'],start_ms=0,reload_when_empty=False)
        command(s,'A',900,'run');r=run(s);self.conserved(r)
        self.assertTrue(r['distance_constraints']);self.assertTrue(events(r,'distance_response_started'))
        # There is one 8 m/s motor and no horizontal launch. Its repeated
        # constraint leases must not create hundreds of m/s of free speed.
        for sample in r['curve']:
            for state in sample['states'].values():
                self.assertLess(abs(D(state['locomotion']['velocity_mps'][0])),D(9))
        self.assertEqual(r['stop_reason']['kind'],'observation_horizon_reached')
