from fractions import Fraction
import unittest
from combat_sim.mechanics.projectile_damage import damage_after_distance


class RangeDamageTests(unittest.TestCase):
    def test_continuous_loss_at_representative_distances(self):
        for distance, expected in ((0,437),(10,Fraction(869,2)),(20,432),(100,412),(1350,Fraction(199,2))):
            self.assertEqual(damage_after_distance(437,distance,5,20),expected)

    def test_fractional_distance_and_decimal_input_are_exact(self):
        self.assertEqual(damage_after_distance(437,'0.1',5,20),Fraction(17479,40))
        self.assertEqual(damage_after_distance(437,Fraction(1,3),5,20),Fraction(5243,12))

    def test_zero_floor_and_different_data_driven_rates(self):
        self.assertEqual(damage_after_distance(437,1748,5,20),0)
        self.assertEqual(damage_after_distance(437,2000,5,20),0)
        self.assertEqual(damage_after_distance(100,10,2,5),96)
        self.assertEqual(damage_after_distance(100,10,0,5),100)

    def test_invalid_inputs(self):
        for args in ((-1,0,5,20),(437,-1,5,20),(437,0,-1,20),(437,0,5,0)):
            with self.subTest(args=args),self.assertRaises(ValueError): damage_after_distance(*args)
