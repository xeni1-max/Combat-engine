"""Pure compound collider identity, HP, expiry and blocking geometry."""
from decimal import Decimal as D
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.terrain import RectangularGround
from combat_sim.world_colliders import ColliderPolicy, ColliderRegistry, segment_crosses_interior


def box(name='wall',centre=(0,0,1),size=(1,1,2)):return Cuboid(name,centre,size)


class ColliderRegistryTests(unittest.TestCase):
    def test_compound_parts_share_one_identity_and_hp_pool(self):
        registry=ColliderRegistry()
        obj=registry.add([box('left',(-1,0,1)),box('right',(1,0,1))],time=0,source='prison_geometry_probe',hp=4000)
        self.assertEqual(len(obj.parts),2)
        self.assertEqual(obj.hp,D(4000))
        self.assertEqual(len(registry.active()),1)
        self.assertEqual(registry.damage(obj.identity.id,437,time=100),437)
        self.assertEqual(obj.hp,3563)

    def test_hp_damage_keeps_collision_predictions_valid_until_destruction(self):
        registry=ColliderRegistry()
        obj=registry.add([box()],time=0,source='probe',hp=500)
        payload=registry.contact_fields(obj.identity.id)
        epoch=registry.epoch
        registry.damage(obj.identity.id,100,time=1)
        self.assertEqual(obj.revision,1)
        self.assertEqual(registry.epoch,epoch)
        self.assertTrue(registry.contact_live(payload,'projectiles',1))
        self.assertEqual(registry.damage(obj.identity.id,900,time=2),400)
        self.assertFalse(registry.contact_live(payload,'projectiles',2))
        self.assertEqual(obj.status,'destroyed')
        self.assertEqual(obj.hp,0)
        self.assertEqual(obj.max_hp,500)
        self.assertEqual(registry.damage(obj.identity.id,100,time=3),0)

    def test_indestructible_ground_rejects_removal_and_remains_unchanged(self):
        registry=ColliderRegistry()
        obj=registry.add([box()],time=0,source='ground',entity_id='ground',permanent=True)
        before=registry.record()
        self.assertEqual(registry.damage('ground',999999,time=1),0)
        with self.assertRaises(ValueError):registry.remove('ground',time=1,reason='probe')
        with self.assertRaises(ValueError):registry.set_expiry('ground',time=1,expires_at_ms=2)
        with self.assertRaises(ValueError):registry.reshape('ground',time=1,parts=[box(centre=(0,0,2))])
        self.assertEqual(registry.record(),before)

    def test_expiry_is_half_open_and_refresh_does_not_change_collision_revision(self):
        registry=ColliderRegistry()
        obj=registry.add([box()],time=0,source='probe',expires_at_ms=100)
        payload=registry.contact_fields(obj.identity.id)
        self.assertTrue(registry.contact_live(payload,'bodies',D('99.9')))
        self.assertFalse(registry.contact_live(payload,'bodies',100))
        self.assertTrue(registry.set_expiry(obj.identity.id,time=50,expires_at_ms=200))
        self.assertEqual(obj.expiry_revision,1)
        self.assertEqual(obj.collision_revision,0)
        self.assertTrue(registry.contact_live(payload,'bodies',100))
        self.assertFalse(registry.set_expiry(obj.identity.id,time=200,expires_at_ms=300))

    def test_geometry_and_policy_changes_invalidate_contact_revision(self):
        registry=ColliderRegistry()
        obj=registry.add([box()],time=0,source='probe')
        payload=registry.contact_fields(obj.identity.id)
        registry.reshape(obj.identity.id,parts=[box(centre=(1,0,1))],time=1)
        self.assertFalse(registry.contact_live(payload,'projectiles',1))
        registry.reshape(obj.identity.id,policy=ColliderPolicy(projectiles=False,bodies=True,areas=True),time=2)
        self.assertFalse(registry.active('projectiles'))
        self.assertEqual(set(registry.active('bodies')),{obj.identity.id})
        self.assertEqual(set(registry.active('areas')),{obj.identity.id})

    def test_continuous_left_interval_receives_damage_before_expiry_but_point_hit_does_not(self):
        registry=ColliderRegistry()
        obj=registry.add([box()],time=0,source='probe',hp=100,expires_at_ms=10)
        self.assertEqual(registry.damage(obj.identity.id,60,time=10),0)
        self.assertEqual(registry.damage(obj.identity.id,60,time=10,interval_begin_ms=0),60)
        self.assertEqual(obj.hp,40)
        registry.remove(obj.identity.id,time=10,reason='lifetime_expired',status='expired')
        self.assertEqual(registry.damage(obj.identity.id,40,time=10,interval_begin_ms=0),0)

    def test_continuous_interval_validation_precedes_mutation(self):
        registry=ColliderRegistry()
        obj=registry.add([box()],time=10,source='probe',hp=100,expires_at_ms=20)
        before=registry.record()
        for begin in (9,20,21):
            with self.assertRaises(ValueError):registry.damage(obj.identity.id,100,time=20,interval_begin_ms=begin)
        self.assertEqual(registry.record(),before)

    def test_ids_never_reuse_terminal_names_or_actor_names(self):
        registry=ColliderRegistry({'A','collider:1'})
        obj=registry.add([box()],time=0,source='probe')
        self.assertEqual(obj.identity.id,'collider:2')
        registry.remove(obj.identity.id,time=1,reason='finished')
        with self.assertRaises(ValueError):registry.add([box()],time=2,source='probe',entity_id=obj.identity.id)
        with self.assertRaises(ValueError):registry.add([box()],time=2,source='probe',entity_id='A')

    def test_records_and_geometry_do_not_alias_input_containers(self):
        registry=ColliderRegistry()
        parts=[box()]
        obj=registry.add(parts,time=0,source='probe',hp=4000)
        saved=registry.record()
        parts.clear()
        registry.damage(obj.identity.id,100,time=1)
        self.assertEqual(saved[obj.identity.id]['hp'],'4000')
        self.assertEqual(len(obj.parts),1)
        with self.assertRaises(AttributeError):obj.identity.source='changed'

    def test_bad_mutation_is_atomic_and_cannot_predate_creation(self):
        registry=ColliderRegistry()
        obj=registry.add([box()],time=10,source='probe',hp=10)
        before=registry.record();epoch=registry.epoch
        for time in (-1,0,float('nan'),True):
            with self.assertRaises(ValueError):registry.remove(obj.identity.id,time=time,reason='invalid')
        with self.assertRaises(ValueError):registry.reshape(obj.identity.id,time=20,policy=False)
        with self.assertRaises(ValueError):registry.set_expiry(obj.identity.id,time=20,expires_at_ms=19)
        self.assertEqual(registry.record(),before)
        self.assertEqual(registry.epoch,epoch)

    def test_invalid_hp_parts_flags_or_attribution_fail_before_registration(self):
        registry=ColliderRegistry()
        for fields in ({'hp':0},{'hp':True},{'hp':float('inf')},{'expires_at_ms':0},
                {'climbable':1},{'owner':'A'},{'action_id':1},{'permanent':True,'hp':10}):
            with self.assertRaises(ValueError):registry.add([box()],time=0,source='probe',**fields)
        for parts in ([],[box(),box()],[box('a'),box('b')]):
            with self.assertRaises(ValueError):registry.add(parts,time=0,source='probe',climbable=True)
        with self.assertRaises(ValueError):
            registry.add([RectangularGround('flat',(-1,-1,0),(1,1,0))],time=0,source='probe')
        self.assertEqual(registry.record(),{})
        self.assertEqual(registry.epoch,0)

    def test_policy_requires_three_explicit_boolean_channels(self):
        for value in ({},{'projectiles':True,'bodies':True,'areas':1}):
            with self.assertRaises(ValueError):ColliderPolicy.from_definition(value)


class SegmentCoverTests(unittest.TestCase):
    def test_wall_blocks_crossing_in_either_direction(self):
        self.assertTrue(segment_crosses_interior((-2,0,1),(2,0,1),box()))
        self.assertTrue(segment_crosses_interior((2,0,1),(-2,0,1),box()))

    def test_outward_surface_origin_does_not_block_its_own_explosion(self):
        self.assertFalse(segment_crosses_interior((-.5,0,1),(-2,0,1),box()))
        self.assertTrue(segment_crosses_interior((-.5,0,1),(2,0,1),box()))

    def test_tangent_touch_and_zero_length_are_not_cover(self):
        self.assertFalse(segment_crosses_interior((-2,.5,1),(2,.5,1),box()))
        self.assertFalse(segment_crosses_interior((0,0,1),(0,0,1),box()))
        with self.assertRaises(ValueError):segment_crosses_interior((0,0),(1,1),box())

    def test_same_side_and_disjoint_height_remain_visible(self):
        self.assertFalse(segment_crosses_interior((-2,0,1),(-1,0,1),box()))
        self.assertFalse(segment_crosses_interior((-2,0,3),(2,0,3),box()))
