"""Actual source Aim input, owned phases, movement and physical shot dispersion."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.shared_engine import SharedEncounter,run_shared_scenario
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.accuracy import disk_sample
from tests.test_equilibrium_combat import scene as base_scene,rules
from tests.test_mobile_combat import BODY,TERRAIN,MOVEMENT,PROFILES,command,events
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_grapple_break_combat import control


def scene(duration=1200,*,fire=False,target=30,aim=True,seed=0):
    s=base_scene(duration);s['id']='actual_aim_and_accuracy';s['random_seed']=seed
    s['encounter']['participants']['B']['position_m']=[target,-20]
    if fire:s['action_selection']['A']['start_ms']=0
    if aim:control(s,0,'A','aim_on')
    return s


def inputs(cfg=None,profiles=PROFILES):
    return dict(profiles=profiles,body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,
        combat_locomotion_definition=rules() if cfg is None else cfg,projectile_physics_definition=PHYSICS,
        jump_definition=JUMP,climb_definition=CLIMB)


def engine(s,*,operations=(),precision=50,cfg=None,profiles=PROFILES,interval=100):
    class Probe(SharedEncounter):
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw)
            for time,payload in operations:self.push(D(time),'aim_probe',payload)
        def _process(self,kind,p):
            if kind!='aim_probe':return super()._process(kind,p)
            if p['op']=='restrict':return self.apply_action_restriction(p['actor'],source='labelled_aim_restriction_probe',
                functions=p['functions'],until_ms=self.time+D(p['duration']))
            if p['op']=='restore':return self.life_cycles.revive(p['actor'],expected_generation=1,hp=5000,source='labelled_aim_restoration_probe')
            if p['op']=='copy':
                parent=next(f for f in self.projectile_flights.values() if f['actor']=='A')
                return self.projectile_system.copy(parent['id'],source='labelled_aim_copy_probe',offset_m=(0,0,0))
            raise AssertionError(p)
    kw=inputs(cfg,profiles);values=kw.pop('profiles')
    return Probe(s,values,precision=precision,sample_interval_ms=interval,**kw)


def run(s,**kw):
    with localcontext(Context(prec=kw.get('precision',50))):return engine(s,**kw).run()


class AimCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for n,lives in r['actor_lives'].items():
            supplied=sum((D(x['initial_hp']) for x in lives),D(0))+heals.amount(actor=n)
            self.assertLess(abs(supplied-D(r['final_states'][n]['hp'])-ledger.amount(target=n)),D('1e-8'))
        return ledger

    def test_toggle_uses_real_recovery_and_exact_160ms_active_without_cost(self):
        r=run(scene(300));start=events(r,'active_started','A')[0];end=events(r,'aim_toggled','A')[0]
        self.assertEqual(D(start['time_ms']),71);self.assertEqual(D(end['time_ms'])-D(start['time_ms']),160)
        self.assertTrue(r['aim_states']['A']['aiming']);self.assertFalse(events(r,'dyspnea_paid','A'))
        self.assertEqual(D(r['final_states']['A']['disorientation']),0)

    def test_disorientation_gathering_precedes_toggle_active(self):
        s=scene(700);s['encounter']['participants']['A']['initial_state']['disorientation']=300
        r=run(s);start=events(r,'active_started','A')[0]
        self.assertEqual(D(start['time_ms']),300);self.assertEqual(D(events(r,'aim_toggled','A')[0]['time_ms']),460)

    def test_completed_aim_affects_real_gunfire_and_keeps_recoil_accuracy(self):
        r=run(scene(fire=True));rows=r['projectile_accuracy_releases']
        self.assertEqual(len(rows),3)
        self.assertTrue(all(x['aiming'] and D(x['disorientation'])==115 and D(x['total_radius_cm_per_100m'])==D('117.4') for x in rows))
        self.assertEqual(D(rows[0]['released_at_ms']),271)
        self.assertEqual(len(r['projectile_flights']),3);self.assertTrue(events(r,'impact_batch_resolved'));self.conserved(r)

    def test_unaimed_real_shots_add_only_the_authored_10cm_penalty(self):
        r=run(scene(900,fire=True,aim=False));row=r['projectile_accuracy_releases'][0]
        self.assertFalse(row['aiming']);self.assertEqual(D(row['total_radius_cm_per_100m']),D('127.4'))
        self.assertNotEqual(row['actual_velocity_mps'],row['ideal_velocity_mps']);self.conserved(r)

    def test_aimed_and_unaimed_experiments_share_the_same_shot_sample(self):
        a=run(scene(400,fire=True));b=run(scene(200,fire=True,aim=False))
        self.assertEqual(a['projectile_accuracy_releases'][0]['disk_sample'],b['projectile_accuracy_releases'][0]['disk_sample'])

    def test_duplicate_on_and_completed_noop_do_not_repeat_active(self):
        s=scene(600);control(s,100,'A','aim_on');control(s,400,'A','aim_on');r=run(s)
        self.assertEqual(len(events(r,'aim_toggled','A')),1)
        self.assertEqual([x['result']['status'] for x in r['combat_control_commands']],['queued','duplicate','unchanged'])

    def test_off_reverses_the_mode_through_a_second_full_active(self):
        s=scene(800);control(s,400,'A','aim_off');r=run(s)
        self.assertEqual([(D(x['time_ms']),x['aiming']) for x in events(r,'aim_toggled','A')],[(D(231),True),(D(560),False)])
        self.assertFalse(r['aim_states']['A']['aiming'])

    def test_contrary_input_cancels_uncommitted_toggle_without_a_free_enable(self):
        s=scene(400);control(s,100,'A','aim_off');r=run(s)
        self.assertFalse(r['aim_states']['A']['aiming']);self.assertFalse(events(r,'aim_toggled','A'))
        self.assertEqual(len(events(r,'controlled_action_cancelled','A')),1)

    def test_toggle_twice_cancels_a_pending_enable(self):
        s=scene(400,aim=False);control(s,0,'A','toggle_aim');control(s,100,'A','toggle_aim');r=run(s)
        self.assertFalse(r['aim_states']['A']['aiming']);self.assertFalse(r['pending_aim_controls'])

    def test_running_clears_completed_aim_without_blocking_locomotion(self):
        s=scene(900);command(s,'A',400,'run');r=run(s)
        self.assertFalse(r['aim_states']['A']['aiming']);self.assertTrue(events(r,'aim_cleared','A'))
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),0)

    def test_running_during_active_cancels_uncommitted_focus(self):
        s=scene(700);command(s,'A',0,'run');r=run(s)
        active=next(e for e in events(r,'active_started','A') if e.get('ability')=='basic_8')
        cancelled=next(e for e in events(r,'controlled_action_cancelled','A') if e['reason']=='aim_running')
        self.assertGreater(D(cancelled['time_ms']),D(active['time_ms']))
        self.assertLess(D(cancelled['time_ms']),D(active['active_end_ms']))
        self.assertFalse(r['aim_states']['A']['aiming']);self.assertFalse(events(r,'aim_toggled','A'))
        self.assertFalse(r['pending_aim_controls'])

    def test_aim_on_while_running_rejects_and_does_not_silently_queue_for_later(self):
        s=scene(900,aim=False);command(s,'A',0,'run');control(s,400,'A','aim_on');r=run(s)
        self.assertEqual(r['combat_control_commands'][0]['result']['reason'],'aim_unavailable_while_running')
        self.assertFalse(r['pending_aim_controls']);self.assertFalse(events(r,'aim_toggle_started','A'))

    def test_walk_and_crouch_keep_independent_aim_control(self):
        s=scene(1000);command(s,'A',400,'walk');command(s,'A',600,'crouch');r=run(s)
        self.assertTrue(r['aim_states']['A']['aiming']);self.assertGreater(D(r['final_states']['A']['position_m'][0]),0)
        self.assertEqual(D(r['final_states']['A']['locomotion']['crouch_fraction']),1)

    def test_real_running_fire_uses_20percent_total_spread_multiplier(self):
        s=scene(1200,fire=True,aim=False);command(s,'A',0,'run');r=run(s)
        rows=[x for x in r['projectile_accuracy_releases'] if x['running']];self.assertTrue(rows)
        for x in rows:self.assertEqual(D(x['total_radius_cm_per_100m']),(D('12.4')+D(x['disorientation']))*D('1.2'))
        self.conserved(r)

    def test_hand_restriction_cancels_toggle_at_its_real_phase(self):
        r=run(scene(500),operations=[('100',{'op':'restrict','actor':'A','functions':['hand:left'],'duration':300})])
        self.assertFalse(events(r,'aim_toggled','A'));self.assertFalse(r['pending_aim_controls'])
        self.assertFalse(r['aim_states']['A']['aiming'])

    def test_restriction_before_request_delays_hands_instead_of_enabling_early(self):
        s=scene(800);s['initial_restrictions']=[{'target':'A','source':'labelled_initial_hand_restriction','functions':['hand:left'],'duration_ms':300}]
        r=run(s);self.assertEqual(D(events(r,'aim_toggled','A')[0]['time_ms']),531)

    def test_actual_gun_death_cancels_pending_toggle_and_new_life_does_not_inherit_it(self):
        s=scene(1200,target=4);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=0;control(s,400,'A','aim_on');control(s,600,'A','aim_on',expected_life_generation=2)
        r=run(s,operations=[('300',{'op':'restore','actor':'A'})])
        self.assertEqual(len(r['actor_lives']['A']),2)
        self.assertEqual(r['combat_control_commands'][1]['result']['reason'],'actor_life_ended')
        self.assertTrue(r['aim_states']['A']['aiming']);self.assertEqual(r['aim_states']['A']['life_generation'],2)
        self.assertTrue(all(D(e['time_ms'])>300 for e in events(r,'aim_toggled','A')));self.conserved(r)

    def test_explicit_seed_changes_real_trajectory_without_changing_shot_cost(self):
        a=run(scene(400,fire=True,seed=0));b=run(scene(400,fire=True,seed=1))
        self.assertNotEqual(a['projectile_accuracy_releases'][0]['actual_velocity_mps'],b['projectile_accuracy_releases'][0]['actual_velocity_mps'])
        self.assertEqual(a['metrics']['A']['dyspnea_paid'],b['metrics']['A']['dyspnea_paid'])

    def test_precision_observation_and_reversed_participants_keep_shot_samples_and_hits(self):
        s=scene(1100,fire=True);a=run(s);s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        self.assertEqual([x['disk_sample'] for x in a['projectile_accuracy_releases']],[x['disk_sample'] for x in b['projectile_accuracy_releases']])
        self.assertEqual(a['metrics']['A']['hits_resolved'],b['metrics']['A']['hits_resolved'])
        for n in a['final_states']:
            self.assertLess(abs(D(a['final_states'][n]['hp'])-D(b['final_states'][n]['hp'])),D('1e-8'))

    def test_frozen_rules_keep_the_previous_perfect_aim_and_no_accuracy_schema(self):
        s=scene(500,fire=True,aim=False);s.pop('random_seed');cfg=rules();cfg.pop('projectile_accuracy');cfg['action_ownership']['actions'].pop('aim_toggle')
        r=run(s,cfg=cfg)
        self.assertNotIn('aim_states',r);self.assertNotIn('projectile_accuracy_releases',r)
        self.assertTrue(all('accuracy' not in f for f in r['projectile_flights']))

    def test_unrelated_allied_actions_do_not_change_the_original_shot_sample(self):
        s=scene(400,fire=True);a=run(s)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[-100,-200]
        s['action_selection']['C']=deepcopy(s['action_selection']['A'])
        b=run(s);first=lambda r:next(x for x in r['projectile_accuracy_releases'] if x['actor']=='A')
        self.assertEqual(first(a)['disk_sample'],first(b)['disk_sample'])
        self.assertEqual(first(a)['actual_velocity_mps'],first(b)['actual_velocity_mps'])
        self.assertNotEqual(first(a)['action_id'],first(b)['action_id'])

    def test_cancelling_unreleased_fire_does_not_consume_a_sample_or_ammo(self):
        r=run(scene(600,fire=True),operations=[('240',{'op':'restrict','actor':'A','functions':['attack'],'duration':200})])
        self.assertEqual([x['ordinal'] for x in r['projectile_accuracy_releases']],[1])
        self.assertEqual(r['final_states']['A']['ammo']['1'],10)
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)

    def test_projectile_copy_keeps_original_accuracy_without_spending_a_shot_sample(self):
        s=scene(700,fire=True,target=100);control(s,300,'A','aim_off')
        r=run(s,operations=[('272',{'op':'copy'})]);children=[f for f in r['projectile_flights'] if f['parent_projectile_id'] is not None]
        self.assertEqual(len(children),1);parent=next(f for f in r['projectile_flights'] if f['id']==children[0]['parent_projectile_id'])
        self.assertEqual(parent['accuracy'],children[0]['accuracy'])
        self.assertEqual([x['ordinal'] for x in r['projectile_accuracy_releases']],[1,2])
        self.assertTrue(parent['accuracy']['aiming']);self.assertFalse(r['aim_states']['A']['aiming'])
        self.conserved(r)

    def test_shared_accuracy_also_changes_actual_qard_launch_without_inventing_base_spread(self):
        s=scene(900,fire=True,aim=False);s['encounter']['participants']['A']['character']='1E1'
        s['action_selection']['A']['reload_when_empty']=False;r=run(s)
        rows=[x for x in r['projectile_accuracy_releases'] if x['actor']=='A'];self.assertTrue(rows)
        for row in rows:
            self.assertEqual(D(row['base_radius_cm_per_100m']),0)
            self.assertEqual(D(row['total_radius_cm_per_100m']),D(row['disorientation']))
        self.assertTrue(any(D(row['disorientation'])>0 for row in rows));self.conserved(r)

    def test_straight_projectiles_use_the_same_owned_release_cone(self):
        from combat_sim.mobile_combat import MOBILE_SCOPE
        cfg=rules();cfg.pop('impact_bindings');cfg.pop('contact_constructs')
        s=scene(400,fire=True);s['scope']=dict(MOBILE_SCOPE);kw=inputs(cfg);profiles=kw.pop('profiles');kw['projectile_physics_definition']=None
        r=run_shared_scenario(s,profiles,**kw);row=r['projectile_accuracy_releases'][0]
        self.assertTrue(row['aiming']);self.assertNotEqual(row['actual_velocity_mps'],row['ideal_velocity_mps'])
        self.assertIn('direction',r['projectile_flights'][0]);self.conserved(r)

    def test_real_aimed_gunfire_destroys_the_same_2000hp_wall_pool(self):
        from tests.test_mobile_combat import read
        s=scene(3100,fire=True);s['terrain_profile']='destructible_arena'
        for a in s['encounter']['participants'].values():a['position_m'][1]=-8
        kw=inputs();profiles=kw.pop('profiles');kw['terrain_definition']=read('data/terrain/destructible_arena.json')
        r=run_shared_scenario(s,profiles,**kw)
        self.assertEqual(r['world_collider_states']['wall_1']['status'],'destroyed')
        losses=[e for e in events(r,'world_collider_damaged') if e['collider_id']=='wall_1']
        self.assertEqual(sum(D(e['applied']) for e in losses),2000)
        self.assertTrue(all(not e['character_recovery_credit'] for e in losses));self.conserved(r)

    def test_invalid_actor_seed_selectors_and_profiles_reject_before_combat(self):
        for seed in (-1,True,'1'):
            with self.subTest(seed=seed),self.assertRaises(ValueError):engine(scene(seed=seed))
        s=scene();s['control_script'][0]['link_id']='grapple:fake'
        with self.assertRaises(ValueError):engine(s)
        s=scene();s['encounter']['participants']['A']['character']='1E1'
        with self.assertRaises(ValueError):engine(s)
        profiles=deepcopy(PROFILES);profiles['1E2']['abilities']['1']['projectile_accuracy']['base_radius_cm_per_100m']=-1
        with self.assertRaises(ValueError):engine(scene(),profiles=profiles)
