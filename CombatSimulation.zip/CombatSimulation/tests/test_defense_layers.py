"""Simultaneous snapshots, selective routing and exact damage conservation."""
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.defense_layers import DefenseLayer, allocate_layers


class DefenseLayerTests(unittest.TestCase):
    def test_one_break_allocates_incoming_damage_ratio(self):
        a=allocate_layers((600,300),(DefenseLayer('guard',800,(0,1)),))
        self.assertEqual(a.absorbed,(F(1600,3),F(800,3)))
        self.assertEqual(a.overflow,(F(200,3),F(100,3)))

    def test_two_layers_precede_the_remainder(self):
        a=allocate_layers((1800,900),(DefenseLayer('outer',800,(0,1)),DefenseLayer('inner',800,(0,1))))
        self.assertEqual(a.absorbed,(F(3200,3),F(1600,3)))
        self.assertEqual(a.overflow,(F(2200,3),F(1100,3)))
        self.assertEqual([sum(s) for _,s in a.layer_shares],[800,800])

    def test_back_and_area_packets_do_not_spend_forward_layers(self):
        a=allocate_layers((400,900,600),(DefenseLayer('front',800,(0,2)),))
        self.assertEqual(a.absorbed,(320,0,480));self.assertEqual(a.overflow,(80,900,120))

    def test_packet_order_does_not_change_the_physical_shares(self):
        a=allocate_layers((300,700),(DefenseLayer('a',450,(0,1)),DefenseLayer('b',400,(0,1))))
        b=allocate_layers((700,300),(DefenseLayer('a',450,(0,1)),DefenseLayer('b',400,(0,1))))
        self.assertEqual(a.absorbed,tuple(reversed(b.absorbed)))
        self.assertEqual(a.overflow,tuple(reversed(b.overflow)))

    def test_selective_overlaps_follow_layer_order(self):
        a=allocate_layers((600,600,600),(DefenseLayer('a',800,(0,1)),DefenseLayer('b',800,(1,2))))
        self.assertEqual(a.overflow,(200,0,0))
        self.assertEqual(a.layer_shares,(('a',(400,400,0)),('b',(0,200,600))))

    def test_exact_break_and_zero_damage_have_no_phantom_overflow(self):
        for raw in ((800,0),(0,0)):
            a=allocate_layers(raw,(DefenseLayer('a',800,(0,1)),))
            self.assertEqual(a.overflow,(0,0));self.assertEqual(a.absorbed,raw)

    def test_no_layers_and_empty_eligibility_preserve_damage(self):
        for layers in ((),(DefenseLayer('unused',800,()),)):
            a=allocate_layers((10,20),layers);self.assertEqual(a.overflow,(10,20));self.assertEqual(a.absorbed,(0,0))
        self.assertEqual(allocate_layers((),()).overflow,())

    def test_total_per_packet_and_per_layer_conserve(self):
        for raw in ((F(1,3),F(8,7),0),(810,317,91),(800,800,801)):
            layers=(DefenseLayer('a',800,(0,2)),DefenseLayer('b',800,(0,1,2)))
            a=allocate_layers(raw,layers)
            self.assertEqual(tuple(x+y for x,y in zip(a.absorbed,a.overflow)),raw)
            for i in range(len(raw)):self.assertEqual(sum(s[i] for _,s in a.layer_shares),a.absorbed[i])
            self.assertTrue(all(sum(s)<=800 for _,s in a.layer_shares))

    def test_invalid_layer_identity_capacity_and_membership_reject(self):
        for layer in (DefenseLayer('',800,(0,)),DefenseLayer('a',-1,(0,)),
                DefenseLayer('a',800,(0,0)),DefenseLayer('a',800,(2,)),DefenseLayer('a',800,(True,))):
            with self.subTest(layer=layer),self.assertRaises(ValueError):allocate_layers((1,2),(layer,))
        with self.assertRaises(ValueError):allocate_layers((1,), (DefenseLayer('a',1,(0,)),)*2)
        with self.assertRaises(ValueError):allocate_layers((-1,),())


if __name__=='__main__':unittest.main()
