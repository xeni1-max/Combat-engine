"""Vertical plane contact geometry, independent of combat action scheduling."""
from decimal import Decimal as D, localcontext
from fractions import Fraction
import unittest

from combat_sim.airborne_geometry import first_downward_plane_contact as contact


class AirborneGeometryTests(unittest.TestCase):
    def test_author_jump_returns_at_640_over_981_seconds(self):
        self.assertEqual(contact(0, '3.2', '9.81', 1), D(640) / D(981))

    def test_upward_launch_ignores_zero_root(self):
        self.assertIsNone(contact(0, '3.2', '9.81', '.1'))
        self.assertIsNone(contact(0, '3.2', '9.81', 0))

    def test_rest_or_downward_motion_on_plane_contacts_immediately(self):
        for velocity in (0, -1, '-3.2'):
            for duration in (0, 1):
                with self.subTest(velocity=velocity, duration=duration):
                    self.assertEqual(contact(0, velocity, '9.81', duration), D(0))

    def test_elevated_fall_from_rest(self):
        self.assertEqual(contact(1, 0, 2, 2), D(1))
        self.assertEqual(contact('4.905', 0, '9.81', 2), D(1))

    def test_downward_initial_velocity(self):
        self.assertEqual(contact(3, -2, 2, 2), D(1))

    def test_upward_motion_above_lower_plane_uses_descending_crossing(self):
        self.assertEqual(contact(3, 2, 2, 4), D(3))

    def test_closed_horizon_includes_exact_contact(self):
        self.assertEqual(contact(3, -2, 2, 1), D(1))
        self.assertIsNone(contact(3, -2, 2, '.9999999999999999999999999999'))
        self.assertIsNone(contact(1, 0, 2, 0))

    def test_large_downward_speed_preserves_small_positive_contact(self):
        # The direct root (v + sqrt(v*v + 2*g*h)) / g rounds to zero here.
        with localcontext() as context:
            context.prec = 28
            self.assertEqual(contact(1, '-1e100', 1, 1), D('1e-100'))

    def test_large_upward_speed_has_positive_return(self):
        self.assertEqual(contact(0, '1e100', 1, '2e100'), D('2e100'))

    def test_tiny_negative_height_only_is_clamped(self):
        for height in ('-1e-25', '-1e-26'):
            with self.subTest(height=height):
                self.assertEqual(contact(height, -1, 2, 0), D(0))
                self.assertEqual(contact(height, 1, 2, 1), D(1))
        with self.assertRaises(ValueError):
            contact('-1.000000000000000000000000001e-25', 0, 2, 1)
        self.assertGreater(contact('1e-26', 0, 2, 1), 0)

    def test_fraction_input_stays_decimal(self):
        result = contact(Fraction(3), Fraction(-2), Fraction(2), Fraction(2))
        self.assertIsInstance(result, D)
        self.assertEqual(result, D(1))

    def test_invalid_input_is_rejected_even_for_immediate_contact(self):
        for index in range(4):
            for value in ('NaN', 'sNaN', 'Infinity', '-Infinity', 'invalid', None):
                args = [0, 0, 2, 1]
                args[index] = value
                with self.subTest(index=index, value=value), self.assertRaises(ValueError):
                    contact(*args)
        for args in ((-1, 0, 2, 1), (0, 0, 0, 1), (0, 0, -2, 1), (0, 0, 2, -1)):
            with self.subTest(args=args), self.assertRaises(ValueError):
                contact(*args)
