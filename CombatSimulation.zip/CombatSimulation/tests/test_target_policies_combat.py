"""Real shots, utilities and life transitions through replaceable target policies."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import json
from pathlib import Path
import unittest
from combat_sim.shared_engine import SharedEncounter
from combat_sim.models import UnsupportedMechanicError
from tests.test_equilibrium_combat import scene as base
from tests.test_mobile_combat import events,read
from tests.test_world_colliders_combat import wall

ROOT=Path(__file__).resolve().parents[1]
def inputs():
    return {'profiles':read('data/characters.json')['characters'],'body_definition':read('data/body_hitboxes.json'),
        'terrain_definition':read('data/terrain/stationary_arena.json'),'movement_definition':read('data/movement/walk_run.json'),
        'combat_locomotion_definition':read('data/movement/combat_locomotion.json'),
        'projectile_physics_definition':read('data/physics/projectile_gravity.json'),
        'jump_definition':read('data/movement/combat_jump.json'),'climb_definition':read('data/movement/combat_climb.json')}

def scene(duration=250,mode='lowest_hp_enemy'):
    s=base(duration);s['id']='target_policy_combat'
    s['encounter']['participants']['B']['position_m']=[5,-20]
    s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
    s['encounter']['participants']['C'].update(position_m=[10,-18],initial_state={'shield':0,'hp':500})
    s['action_selection']['C']=deepcopy(s['action_selection']['B'])
    s['action_selection']['A'].update(start_ms=0,target=mode)
    return s

def run(s,*,precision=50,interval=100,replacements=None):
    with localcontext(Context(prec=28)):
        engine=SharedEncounter(s,precision=precision,sample_interval_ms=interval,**inputs())
        engine.target_policies.update(replacements or {})
        return engine.run()

def release_targets(r,actor='A'):
    return [e['target'] for e in events(r,'ability_started',actor) if e['ability']=='1']


class TargetPolicyCombatTests(unittest.TestCase):
    def test_lowest_hp_and_nearest_hit_different_actual_bodies(self):
        low=run(scene());near=run(scene(mode='nearest_living_enemy'))
        self.assertEqual(events(low,'projectile_body_collision','A')[0]['target'],'C')
        self.assertEqual(events(near,'projectile_body_collision','A')[0]['target'],'B')
        self.assertLess(D(low['final_states']['C']['hp']),500)
        self.assertEqual(D(low['final_states']['B']['hp']),8140)

    def test_only_new_policy_emits_linked_selection_provenance(self):
        low=run(scene());near=run(scene(mode='nearest_living_enemy'))
        e=events(low,'target_policy_selected','A')[0];action=events(low,'ability_started','A')[0]
        self.assertEqual((e['policy'],e['selected_enemy'],e['action_target']),('lowest_hp_enemy','C','C'))
        self.assertEqual(e['action_id'],action['action_id'])
        self.assertEqual([row['actor'] for row in e['candidates']],['B','C'])
        self.assertFalse(events(near,'target_policy_selected'))

    def test_actors_choose_their_policies_independently(self):
        s=scene();s['encounter']['participants']['D']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['D']['position_m']=[0,-25]
        s['action_selection']['D']=dict(s['action_selection']['A'],target='nearest_living_enemy')
        r=run(s)
        self.assertEqual(release_targets(r,'A'),['C']);self.assertEqual(release_targets(r,'D'),['B'])

    def test_killing_the_weak_target_retargets_the_next_legal_attack(self):
        s=scene(550);s['encounter']['participants']['C']['initial_state']['hp']=1
        r=run(s);self.assertFalse(r['final_states']['C']['alive'])
        self.assertEqual(release_targets(r),['C','B'])
        self.assertEqual([e['target'] for e in events(r,'projectile_body_collision','A')],['C','B'])

    def test_exact_hp_and_distance_ties_use_identity_across_insertion_order(self):
        s=scene();s['encounter']['participants']['B'].update(position_m=[5,-22],initial_state={'shield':0,'hp':500})
        s['encounter']['participants']['C']['position_m']=[5,-18]
        a=run(s);s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        for r in (a,b):self.assertEqual(release_targets(r),['B'])
        for n in a['final_states']:
            self.assertLess(abs(D(a['final_states'][n]['hp'])-D(b['final_states'][n]['hp'])),D('1e-8'))

    def test_self_targeted_dodge_remains_legal_without_enemies(self):
        s=scene(160);s['encounter']['participants']['A']['character']='2E4'
        for a in s['encounter']['participants'].values():a['team']='A'
        s['action_selection']['A']['abilities']=['basic_9']
        r=run(s);self.assertTrue(events(r,'dodge_completed','A'))
        e=events(r,'target_policy_selected','A')[0]
        self.assertIsNone(e['selected_enemy']);self.assertEqual(e['action_target'],'A');self.assertEqual(e['candidates'],[])

    def test_explicit_world_hook_remains_legal_without_enemies(self):
        s=read('scenarios/1e2_grappling_gun.json');s['action_selection']['A']['target']='lowest_hp_enemy'
        r=run(s);self.assertEqual(r['grappling_hooks'][0]['end_reason'],'body_contact')
        self.assertTrue(events(r,'grappling_hook_arrival_contact','A'))
        self.assertIsNone(events(r,'target_policy_selected','A')[0]['selected_enemy'])

    def test_released_qard_keeps_its_old_path_after_someone_else_kills_the_target(self):
        s=scene(750);s['encounter']['participants']['A']['character']='1E1'
        s['action_selection']['A']['reload_when_empty']=False
        s['encounter']['participants']['C'].update(position_m=[30,-16],initial_state={'shield':0,'hp':1})
        s['encounter']['participants']['D']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['D'].update(team='A',position_m=[30,-14],facing='-x')
        s['action_selection']['D']=dict(s['action_selection']['B'],start_ms=300)
        block=wall('past_target',x=35,z=1,size=('.2',4,2),hp=None);block['parts'][0]['centre_m'][1]='-15.3'
        s['initial_colliders']=[block]
        r=run(s);dead=events(r,'character_died','C')[0];released=events(r,'projectile_released','A')[0]
        self.assertLess(D(released['time_ms']),D(dead['time_ms']))
        self.assertFalse([e for e in events(r,'projectile_body_collision','A') if e['target']=='B'])
        self.assertTrue([e for e in r['events'] if e.get('actor')=='A' and e.get('collider_id')=='past_target'])

    def test_lowest_hp_does_not_bypass_payment_readiness(self):
        s=scene(450);s['encounter']['participants']['A']['initial_state']['dyspnea']=100
        r=run(s);self.assertTrue(events(r,'policy_wait','A'))
        self.assertGreater(D(events(r,'ability_started','A')[0]['time_ms']),0)
        for event in events(r,'dyspnea_paid','A'):self.assertLessEqual(D(event['after']),100)

    def test_api_policy_replacement_uses_the_same_legal_action_path(self):
        class PreferB:
            name='prefer_b'
            def choose(self,actor,participants):return 'B'
        r=run(scene(),replacements={'A':PreferB()})
        self.assertEqual(events(r,'projectile_body_collision','A')[0]['target'],'B')
        self.assertEqual(events(r,'target_policy_selected','A')[0]['policy'],'prefer_b')

    def test_api_policy_cannot_select_a_friendly_or_mutate_live_state(self):
        class Friendly:
            name='friendly'
            def choose(self,actor,participants):return actor
        with self.assertRaisesRegex(ValueError,'ineligible'):run(scene(),replacements={'A':Friendly()})
        class Mutate:
            name='mutate'
            def choose(self,actor,participants):participants[actor]['hp']=0
        with self.assertRaises(TypeError):run(scene(),replacements={'A':Mutate()})

    def test_unknown_scenario_target_policy_rejects_during_construction(self):
        with self.assertRaisesRegex(UnsupportedMechanicError,'target policy'):run(scene(mode='unknown'))
