"""Continuous box contact boundaries, independent of combat or observations."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.volume_geometry import box_cells


def moving(centre=(0,0,0),size=(1,1,1),velocity=(0,0,0),acceleration=(0,0,0),rate=(0,0,0),size_accel=None):
    row=(Cuboid('body',centre,size),velocity,acceleration,rate)
    return row if size_accel is None else (*row,size_accel)


class BoxVolumeTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_stationary_closed_contact_and_clear_gap(self):
        panel=Cuboid('panel',(1,0,0),(1,4,4))
        self.assertEqual(box_cells([panel],[moving()],1),[(D(0),True)])
        self.assertEqual(box_cells([panel],[moving(centre=('-0.001',0,0))],1),[(D(0),False)])

    def test_linear_entry_and_exit_are_geometric_roots(self):
        panel=Cuboid('panel',(3,0,0),(1,4,4))
        cells=box_cells([panel],[moving(velocity=(2,0,0))],3)
        self.assertEqual([state for _,state in cells],[False,True,False])
        for (time,_),expected in zip(cells,(0,1,2)):
            self.assertLess(abs(time-D(expected)),D('1e-40'))

    def test_vertical_clearance_is_finite(self):
        panel=Cuboid('panel',(0,0,'0.75'),('.1',4,'1.5'))
        self.assertFalse(box_cells([panel],[moving(centre=(0,0,2),size=('.2','.2','.2'))],1)[0][1])
        self.assertTrue(box_cells([panel],[moving(centre=(0,0,'1.6'),size=('.2','.2','.2'))],1)[0][1])

    def test_quadratic_translation_has_two_contact_intervals(self):
        panel=Cuboid('panel',(2,0,0),(1,4,4))
        cells=box_cells([panel],[moving(velocity=(4,0,0),acceleration=(-2,0,0))],4)
        self.assertEqual([v for _,v in cells],[False,True,False,True,False])
        expected=(D(0),2-D(3).sqrt(),1,3,2+D(3).sqrt())
        for (actual,_),target in zip(cells,expected):self.assertLess(abs(actual-target),D('1e-40'))

    def test_isolated_quadratic_tangency_has_no_exposure_cell(self):
        panel=Cuboid('panel',(3,0,0),(1,4,4))
        self.assertEqual(box_cells([panel],[moving(velocity=(4,0,0),acceleration=(-4,0,0))],2),[(D(0),False)])

    def test_multiple_parts_and_panel_seams_are_one_union(self):
        a=Cuboid('a',(0,-1,0),(1,2,2));b=Cuboid('b',(0,1,0),(1,2,2))
        self.assertEqual(box_cells([a,b],[moving(centre=(0,-2,0),velocity=(0,2,0))],2),[(D(0),True)])
        self.assertEqual(box_cells([a,b],[moving(),moving(size=(2,2,2))],1),[(D(0),True)])

    def test_affine_pose_shrink_leaves_contact_at_the_actual_face(self):
        roof=Cuboid('roof',(0,0,2),(4,4,'.2'))
        cells=box_cells([roof],[moving(centre=(0,0,1),size=(1,1,2),velocity=(0,0,'-.5'),rate=(0,0,-1))],1)
        self.assertEqual([v for _,v in cells],[True,False])
        self.assertLess(abs(cells[1][0]-D('.1')),D('1e-40'))

    def test_quadratic_size_cannot_become_negative_inside_the_query(self):
        with self.assertRaises(ValueError):
            box_cells([Cuboid('p',(0,0,0),(1,1,1))],[moving(rate=(0,0,-8),size_accel=(0,0,8))],2)

    def test_affine_size_cannot_become_negative_at_the_endpoint(self):
        with self.assertRaises(ValueError):
            box_cells([], [moving(rate=(0,0,-2))], 1)

    def test_empty_material_and_zero_duration_have_explicit_membership(self):
        self.assertEqual(box_cells([], [moving()], 1),[(D(0),False)])
        self.assertEqual(box_cells([Cuboid('p',(0,0,0),(1,1,1))],[moving()],0),[(D(0),True)])
        with self.assertRaises(ValueError):box_cells([],[],-1)

    def test_precision_and_motion_shape_validation(self):
        for precision in (0,39,True):
            with self.assertRaises(ValueError):box_cells([],[],1,precision=precision)
        with self.assertRaises(ValueError):box_cells([],[(Cuboid('p',(0,0,0),(1,1,1)),)],1)


if __name__=='__main__':unittest.main()
