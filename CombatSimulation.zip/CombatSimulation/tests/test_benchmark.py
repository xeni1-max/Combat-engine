"""Documented formulas/cadences and independent precision checks for the benchmark."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext,ROUND_HALF_EVEN,ROUND_FLOOR,ROUND_CEILING
from fractions import Fraction
import json
from pathlib import Path
import unittest
from combat_sim.benchmark import run_benchmark_case,ABILITIES,_Run,root_curve_integral,dec
from combat_sim.mechanics import blunt,poison,slash
from combat_sim.models import UnsupportedMechanicError

ROOT=Path(__file__).resolve().parents[1]
PROFILES=json.loads((ROOT/'data/characters.json').read_text())['characters']


def events(run,kind):return [e for e in run['events'] if e['type']==kind]


class BenchmarkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runs={(a,t,s):run_benchmark_case(PROFILES,a,t,s) for a in ABILITIES for t in ('1E1','3E5','1E5') for s in (False,True)}

    def test_canonical_1e5_defender_is_imported(self):
        p=PROFILES['1E5']
        self.assertEqual((p['max_hp'],p['base_armor'],p['resistances']['heat'],p['resistances']['toxin'],p['resistances']['qard']),(20000,350,50,150,175))

    def test_qard_cadence_and_known_exact_totals(self):
        run=self.runs['1E1_1','1E1',False]
        self.assertEqual([int(e['time_ms']) for e in events(run,'projectile_released')],[320+1470*i for i in range(7)])
        self.assertEqual(run['metrics']['hits_resolved'],14)
        self.assertEqual(D(run['metrics']['hp_damage']),5600)
        self.assertEqual(D(run['metrics']['final_armor']),150)
        shield=self.runs['1E1_1','1E1',True]
        self.assertEqual(D(shield['metrics']['hp_damage']),2000)
        self.assertEqual(D(shield['metrics']['shield_damage']),4000)

    def test_blunt_alternates_and_gathering_uses_remaining_self_status(self):
        run=self.runs['3E5_1bc','1E1',False]
        self.assertEqual([e['component'] for e in events(run,'ability_started')[:4]],['b','c','b','c'])
        self.assertEqual([int(e['time_ms']) for e in events(run,'impact_resolved')[:4]],[230,610,990,1370])
        self.assertEqual(events(run,'ability_started')[1]['timing']['effective_gathering_ms'],200)
        self.assertEqual(D(events(run,'impact_resolved')[0]['nominal_hp']),225)
        self.assertEqual(run['metrics']['hits_resolved'],26)

    def test_blade_replacement_pipeline(self):
        run=self.runs['2E4_1','1E5',True]
        self.assertEqual([int(e['time_ms']) for e in events(run,'impact_resolved')],[230+1080*i for i in range(10)])
        self.assertEqual(int(events(run,'blade_grab_started')[0]['time_ms']),830)
        self.assertEqual(int(events(run,'blade_grab_completed')[0]['time_ms']),1080)
        self.assertEqual([D(e['damage_left_after_shield']) for e in events(run,'impact_resolved')], [D(0)]*9+[D(400)])

    def test_venom_freezes_each_pre_hit_snapshot_and_bleeds_are_independent(self):
        run=self.runs['2E4_1','1E5',False]
        applications=[e['effect'] for e in events(run,'continuous_effect_started') if e['effect']['kind']=='venom']
        hits=events(run,'impact_resolved')
        self.assertEqual(applications[0]['source']['pre_hit_armor'],'350')
        self.assertEqual(applications[1]['source']['pre_hit_armor'],hits[1]['pre_hit_armor'])
        self.assertNotEqual(applications[0]['source']['pre_hit_armor'],applications[1]['source']['pre_hit_armor'])
        self.assertEqual(events(run,'bleeding_started')[0]['basis_y'],hits[0]['nominal_hp'])

    def test_gun_magazine_reload_and_projectile_boundary(self):
        run=self.runs['1E2_1','1E5',True]
        releases=[int(e['time_ms']) for e in events(run,'projectile_released')]
        self.assertEqual(releases[:12],[40+400*i for i in range(11)]+[5995])
        self.assertEqual(releases[-1],9995)
        self.assertEqual(run['metrics']['hits_resolved'],21) # Last bullet arrives at 10007 ms.
        self.assertEqual(run['metrics']['reloads_requested'],2)
        self.assertTrue(run['metrics']['reloading'])
        self.assertEqual(int(events(run,'reload_completed')[0]['time_ms']),5955)

    def test_single_shot_formulas_match_exact_helpers(self):
        with localcontext(Context(prec=50,rounding=ROUND_HALF_EVEN)):
            for target in ('1E1','3E5','1E5'):
                for shielded in (False,True):
                    gun=events(self.runs['1E2_1',target,shielded],'impact_resolved')[0]
                    raw=Fraction(869,2);a=PROFILES[target]['base_armor'];shield=4000 if shielded else 0
                    exact=slash.calculate_impact(raw,a,18,shield)
                    self.assertLess(abs(D(gun['nominal_hp'])-dec(exact.hp_damage)),D('1e-43'))
                    hit=events(self.runs['3E5_1bc',target,shielded],'impact_resolved')[0]
                    expected=blunt.post_mitigation_damage(300,a) if not shielded else Fraction(0)
                    self.assertLess(abs(D(hit['nominal_hp'])-dec(expected)),D('1e-43'))

    def test_heat_shield_breaks_in_residual_and_does_not_transfer_to_hp(self):
        run=self.runs['1E1_4','1E1',True]
        self.assertEqual([int(e['time_ms']) for e in events(run,'heat_started')],[180,9180])
        boundary=events(run,'shield_broken_during_heat')[0]['time_bracket']
        self.assertGreater(D(boundary['lower_ms']),3180)
        self.assertLess(D(boundary['upper_ms']),4680)
        self.assertEqual(len(events(run,'shield_residual_terminated')),1)
        with localcontext(Context(prec=50)):
            expected=D(2)/3*875*D('.82')*D('.82').sqrt()
            self.assertLess(abs(D(run['metrics']['hp_damage'])-expected),D('1e-40'))
        self.assertEqual(D(run['metrics']['shield_damage']),4000)

    def test_heat_symmetry_from_documented_defenses(self):
        # 250²+250² = 350²+50²; both coefficients are identical, despite different HP.
        for shield in (False,True):
            self.assertLess(abs(D(self.runs['1E1_4','3E5',shield]['metrics']['hp_damage'])-D(self.runs['1E1_4','1E5',shield]['metrics']['hp_damage'])),D('1e-40'))

    def test_heat_hp_exposure_starts_at_zero_after_active_shield_break(self):
        # Synthetic shield amount tests the confirmed general rule; canonical benchmark starts at 4000.
        with localcontext(Context(prec=50,rounding=ROUND_HALF_EVEN)):
            trial=_Run(PROFILES,'1E1_4','1E1',True,5000,10,50);trial.shield=trial.initial_shield=D(500)
            run=trial.run();t=(D(3)*500/(2*900))**(D(2)/3)
            hp_duration=3-t;expected=875*hp_duration*hp_duration.sqrt()
            self.assertLess(abs(D(run['metrics']['hp_damage'])-expected),D('1e-22'))
            self.assertEqual(len(events(run,'hp_heat_exposure_started')),1)
            self.assertEqual(events(run,'hp_heat_exposure_started')[0]['exposure_seconds'],'0')

    def test_gas_bypasses_shields_and_each_grenade_keeps_its_clock(self):
        for target in ('1E1','3E5','1E5'):
            bare=self.runs['1E1_Ultimate',target,False];shield=self.runs['1E1_Ultimate',target,True]
            self.assertEqual(bare['metrics']['hp_damage'],shield['metrics']['hp_damage'])
            self.assertEqual(bare['metrics']['hp_zero_time'],shield['metrics']['hp_zero_time'])
            self.assertEqual(D(shield['metrics']['final_shield']),4000)
            self.assertEqual(D(shield['metrics']['shield_damage']),0)
            applications=[e['effect'] for e in events(shield,'continuous_effect_started')]
            self.assertGreater(len(applications),1)
            self.assertEqual(D(applications[0]['leave'])-D(applications[0]['start']),8000)
            self.assertEqual(D(applications[0]['expiry'])-D(applications[0]['leave']),8000)
            self.assertEqual(D(applications[1]['start'])-D(applications[0]['start']),1470)

    def test_poison_first_interval_matches_exact_curve_helper(self):
        with localcontext(Context(prec=50,rounding=ROUND_HALF_EVEN)):
            run=self.runs['1E1_Ultimate','1E1',True]
            first=events(run,'continuous_interval')[0]
            interval=(D(first['interval_end_ms'])-D(first['interval_start_ms']))/1000
            expected=poison.poison_damage_between(1200,40,0,Fraction(interval),Fraction(interval)).decimal_approximation()
            self.assertLess(abs(D(first['nominal_hp_by_effect']['poison'])-expected),D('1e-43'))

    def test_observation_stops_at_hp_zero_without_negative_hp_or_future_damage(self):
        for run in self.runs.values():
            m=run['metrics'];hp=D(run['initial_state']['hp'])
            self.assertGreaterEqual(D(m['final_hp']),0);self.assertGreaterEqual(D(m['final_shield']),0);self.assertGreaterEqual(D(m['final_armor']),0)
            self.assertLessEqual(D(m['hp_damage']),hp)
            if m['hp_zero_time']:
                self.assertEqual(D(m['hp_damage']),hp)
                self.assertEqual(D(m['final_hp']),0)
                lower=D(m['hp_zero_time']['lower_ms']);upper=D(m['hp_zero_time']['upper_ms'])
                self.assertLessEqual(upper-lower,D('1e-25'))
                self.assertTrue(all(D(e['time_ms'])<=upper for e in run['events']))
                self.assertEqual(D(run['curve'][-1]['hp_damage']),hp)

    def test_no_regeneration_is_eligible_in_ten_seconds(self):
        for run in self.runs.values():
            self.assertEqual(run['metrics']['shield_regenerated'],'0')
            for loss in run['shield_loss_history']:
                key='eligible_at_ms' if loss['kind']=='impact' else 'eligible_interval_start_ms'
                self.assertGreaterEqual(D(loss[key]),20000)

    def test_fifty_vs_eighty_digits_agree_for_every_case(self):
        with localcontext(Context(prec=90)):
            for key,low in self.runs.items():
                high=run_benchmark_case(PROFILES,*key,precision=80)
                with self.subTest(case=key):
                    for metric in ('hp_damage','shield_damage','final_hp','final_armor','final_shield'):
                        self.assertLess(abs(D(low['metrics'][metric])-D(high['metrics'][metric])),D('1e-20'))
                    for metric in ('activations_started','hits_resolved','projectiles_released','ammo_remaining'):
                        self.assertEqual(low['metrics'][metric],high['metrics'][metric])
                    a=low['metrics']['hp_zero_time'];b=high['metrics']['hp_zero_time']
                    self.assertEqual(a is None,b is None)
                    if a:self.assertLess(abs(D(a['upper_ms'])-D(b['upper_ms'])),D('1e-20'))

    def test_determinism_context_and_input_immutability(self):
        before=deepcopy(PROFILES);expected=self.runs['2E4_1','1E1',True]
        for precision,rounding in ((6,ROUND_FLOOR),(80,ROUND_CEILING)):
            with localcontext() as ctx:
                ctx.prec,ctx.rounding=precision,rounding
                self.assertEqual(run_benchmark_case(PROFILES,'2E4_1','1E1',True),expected)
        self.assertEqual(PROFILES,before)

    def test_limits_reject_unsupported_windows_or_unknown_abilities(self):
        with self.assertRaises(UnsupportedMechanicError):run_benchmark_case(PROFILES,'1E1_4','1E1',True,duration_ms=20000)
        with self.assertRaises(ValueError):run_benchmark_case(PROFILES,'unknown','1E1',False)

    def test_measurement_sampling_does_not_quantize_continuous_damage(self):
        with localcontext(Context(prec=70)):
            for ability,target,shielded in [('1E1_4','1E1',True),('2E4_1','3E5',False),('1E1_Ultimate','1E5',True)]:
                base=self.runs[ability,target,shielded]
                alternate=run_benchmark_case(PROFILES,ability,target,shielded,sample_interval_ms=137)
                for key in ('hp_damage','shield_damage','final_hp','final_armor','final_shield'):
                    self.assertLess(abs(D(base['metrics'][key])-D(alternate['metrics'][key])),D('1e-20'))
                if base['metrics']['hp_zero_time']:
                    self.assertLess(abs(D(base['metrics']['hp_zero_time']['upper_ms'])-D(alternate['metrics']['hp_zero_time']['upper_ms'])),D('1e-20'))
