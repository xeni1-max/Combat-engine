"""Independent analytic checks and convergence tests for isolated gravity."""
from math import hypot, sqrt
import unittest

from combat_sim.mechanics.gravity import ProjectileTrajectory, GRAVITY_MPS2
from combat_sim.models import UnsupportedMechanicError


class GravityMotionTests(unittest.TestCase):
    def test_horizontal_qard_has_analytic_fall_and_unchanged_horizontal_speed(self):
        s=ProjectileTrajectory([0,0,2],[100,0,0],.3).at(.3)
        self.assertAlmostEqual(s.position_m[0],30)
        self.assertAlmostEqual(s.position_m[2],2-9.81*.3**2/2)
        self.assertAlmostEqual(s.velocity_mps[2],-9.81*.3)
        self.assertEqual(s.velocity_mps[0],100)
        self.assertGreater(s.distance_m,30)

    def test_vertical_distance_counts_both_sides_of_apex(self):
        t=20/GRAVITY_MPS2
        s=ProjectileTrajectory([0,0,2],[0,0,10],t).at(t)
        self.assertAlmostEqual(s.position_m[2],2)
        self.assertAlmostEqual(s.distance_m,100/GRAVITY_MPS2)

    def test_drop_from_rest(self):
        s=ProjectileTrajectory([0,0,10],[0,0,0],1).at(1)
        self.assertAlmostEqual(s.distance_m,4.905)
        self.assertAlmostEqual(s.position_m[2],5.095)

    def test_arc_length_matches_independent_simpson_speed_integral(self):
        v=(30,40,20);t=1.4;n=2000;h=t/n
        speed=lambda i:hypot(v[0],v[1],v[2]-9.81*i*h)
        reference=h/3*(speed(0)+speed(n)+4*sum(speed(i) for i in range(1,n,2))+2*sum(speed(i) for i in range(2,n,2)))
        result=ProjectileTrajectory([0,0,3],v,t).at(t)
        self.assertAlmostEqual(result.distance_m,reference,places=10)

    def test_no_gravity_deceleration_matches_straight_line_closed_form(self):
        t=.7;speed=900;d=300
        s=ProjectileTrajectory([1,2,3],[540,720,0],t,deceleration_mps2=d,gravity_mps2=0).at(t)
        length=speed*t-d*t*t/2
        self.assertAlmostEqual(s.distance_m,length,places=9)
        self.assertAlmostEqual(s.position_m[0],1+.6*length,places=9)
        self.assertAlmostEqual(s.position_m[1],2+.8*length,places=9)
        self.assertAlmostEqual(s.speed_mps,speed-d*t,places=9)

    def test_downward_deceleration_and_gravity_have_opposite_signs(self):
        s=ProjectileTrajectory([0,0,100],[0,0,-900],.5,deceleration_mps2=300).at(.5)
        self.assertAlmostEqual(s.velocity_mps[2],-900+(300-9.81)*.5,places=9)
        self.assertAlmostEqual(s.position_m[2],100-900*.5+(300-9.81)*.5**2/2,places=9)

    def test_upward_deceleration_adds_to_downward_gravity(self):
        s=ProjectileTrajectory([0,0,0],[0,0,900],.5,deceleration_mps2=300).at(.5)
        self.assertAlmostEqual(s.velocity_mps[2],900-(300+9.81)*.5,places=9)

    def test_horizontal_gun_deceleration_turns_with_velocity(self):
        s=ProjectileTrajectory([0,0,2],[900,0,0],.8,deceleration_mps2=300).at(.8)
        self.assertGreater(s.velocity_mps[0],900-300*.8)
        self.assertGreater(s.velocity_mps[2],-9.81*.8)
        self.assertLess(s.velocity_mps[2],0)

    def test_tighter_solver_preserves_oblique_gun_motion(self):
        args=([1,-2,20],[600,500,-300],1)
        a=ProjectileTrajectory(*args,deceleration_mps2=300).at(1)
        b=ProjectileTrajectory(*args,deceleration_mps2=300,max_step_s=.001,relative_tolerance=1e-13,absolute_tolerance=1e-14).at(1)
        for x,y in zip((*a.position_m,*a.velocity_mps,a.distance_m),(*b.position_m,*b.velocity_mps,b.distance_m)):
            self.assertAlmostEqual(x,y,places=8)

    def test_mechanical_energy_loss_matches_deceleration_work(self):
        v=(600,500,100);origin=(0,0,50)
        s=ProjectileTrajectory(origin,v,1,deceleration_mps2=300).at(1)
        initial=hypot(*v)**2/2+9.81*origin[2]
        final=s.speed_mps**2/2+9.81*s.position_m[2]
        self.assertAlmostEqual(initial-final,300*s.distance_m,places=6)

    def test_intermediate_queries_do_not_change_final_trajectory(self):
        p=ProjectileTrajectory([0,0,2],[900,0,0],.5,deceleration_mps2=300)
        end=p.at(.5)
        for t in (.0137,.137,.241,.499):p.at(t)
        self.assertEqual(end,p.at(.5))
        self.assertEqual(p.at(0).position_m,(0,0,2))

    def test_zero_duration_and_explicit_horizon(self):
        p=ProjectileTrajectory([0,0,1],[100,0,0],0)
        self.assertEqual(p.at(0).distance_m,0)
        with self.assertRaises(ValueError):p.at(.1)

    def test_undefined_stop_region_is_rejected(self):
        with self.assertRaisesRegex(UnsupportedMechanicError,'zero-speed'):
            ProjectileTrajectory([0,0,2],[900,0,0],3,deceleration_mps2=300)

    def test_bad_inputs_fail(self):
        for kwargs in ({'duration_s':-1},{'duration_s':float('nan')},{'duration_s':1,'deceleration_mps2':-1},
                       {'duration_s':1,'max_step_s':0},{'duration_s':1,'relative_tolerance':0}):
            with self.assertRaises(ValueError):ProjectileTrajectory([0,0,0],[100,0,0],**kwargs)
