"""Static terrain interception and areas share the existing combat timeline."""
from copy import deepcopy
from decimal import Decimal as D
import json
from pathlib import Path
import unittest

from combat_sim.shared_engine import run_shared_scenario
from combat_sim.team_rules import TERRAIN_SCOPE
from combat_sim.models import UnsupportedMechanicError
from test_body_collisions import duel, events, BODY, PROFILES

ROOT=Path(__file__).resolve().parents[1]
TERRAIN=json.loads((ROOT/'data/terrain/stationary_arena.json').read_text())
SCENARIO=json.loads((ROOT/'scenarios/stationary_2v2_terrain.json').read_text())

def scene(horizon=1200,ability='1'):
    s=duel(horizon,ability)
    s['scope']=deepcopy(TERRAIN_SCOPE)
    s['terrain_profile']=TERRAIN['id']
    return s

def run(s,profiles=PROFILES,terrain=TERRAIN):
    return run_shared_scenario(s,profiles,body_definition=BODY,terrain_definition=terrain)

class TerrainIntegrationTests(unittest.TestCase):
    def test_qard_stops_at_cube_and_marks_actual_face(self):
        r=run(scene())
        contact=events(r,'projectile_terrain_collision')[0]
        self.assertEqual(contact['target'],'cube_1')
        self.assertLess(abs(D(contact['location_m'][0])-D('5.1')),D('1e-40'))
        blast=events(r,'delayed_blast')[0]
        self.assertEqual(D(blast['time_ms'])-D(contact['time_ms']),500)
        self.assertEqual(blast['location_m'],contact['location_m'])
        self.assertFalse(events(r,'projectile_body_collision'))
        self.assertEqual(D(r['final_states']['gunner']['hp']),8140)

    def test_gun_stops_without_qard_mark(self):
        s=scene(800)
        s['encounter']['participants']['caster']['character']='1E2'
        s['action_selection']['caster']['reload_when_empty']=True
        r=run(s)
        self.assertTrue(events(r,'projectile_terrain_collision'))
        self.assertFalse(events(r,'delayed_blast'))
        self.assertEqual(D(r['final_states']['gunner']['hp']),8140)

    def test_blast_reaches_body_behind_cube_at_full_strength(self):
        s=scene()
        s['encounter']['participants']['gunner']['position_m']=[8,0]
        r=run(s)
        self.assertEqual(events(r,'delayed_blast')[0]['recipients'],['gunner'])
        self.assertEqual(D(r['final_states']['gunner']['hp']),7740)

    def test_beam_ignores_obstacle(self):
        r=run(scene(1000,'4'))
        self.assertEqual(events(r,'beam_deployed')[0]['recipients'],['gunner'])
        self.assertLess(D(r['final_states']['gunner']['hp']),8140)

    def test_floor_remains_a_candidate_after_body_contact(self):
        p=deepcopy(PROFILES)
        p['1E1']['abilities']['1']['hand_positions_m']['start']['right'][2]=1
        t=deepcopy(TERRAIN)
        t['obstacles']=[]
        r=run(scene(2000),p,t)
        flight=r['projectile_flights'][0]
        floor=next(c for c in flight['candidates'] if c['target']=='ground')
        self.assertEqual(D(floor['location_m'][2]),0)
        self.assertLess(abs(D(floor['projectile_centre_m'][2])-D('.02')),D('1e-40'))
        self.assertGreater(D(floor['distance_m']),D(flight['candidates'][0]['distance_m']))

    def test_projectile_continues_to_ground_after_target_dies(self):
        s=scene(3000)
        s['encounter']['participants']['gunner']['initial_state']['hp']=1
        s['encounter']['participants']['ally']={'character':'1E2','team':'A','position_m':[0,1],'facing':'+x'}
        s['action_selection']['ally']={'kind':'priority_when_ready','target':'nearest_living_enemy',
            'abilities':['1'],'reload_when_empty':True,'start_ms':300}
        p=deepcopy(PROFILES)
        p['1E1']['abilities']['1']['hand_positions_m']['start']['right'][2]=1
        t=deepcopy(TERRAIN);t['obstacles']=[]
        r=run(s,p,t)
        contact=next(e for e in events(r,'projectile_terrain_collision') if e['actor']=='caster')
        self.assertEqual(contact['target'],'ground')
        self.assertEqual(D(contact['location_m'][2]),0)
        blast=next(e for e in events(r,'delayed_blast') if e['actor']=='caster')
        self.assertEqual(D(blast['time_ms'])-D(contact['time_ms']),500)
        release=next(e for e in events(r,'projectile_released') if e['actor']=='caster')
        self.assertLess(D(r['final_states']['gunner']['died_at_ms']),D(release['time_ms']))

    def test_inputs_must_be_explicit_and_consistent(self):
        with self.assertRaises(UnsupportedMechanicError):
            run_shared_scenario(scene(),PROFILES,body_definition=BODY)
        s=scene();s['terrain_profile']='unknown'
        with self.assertRaises(ValueError):run(s)
        s=scene();s['encounter']['ground_z_m']=1
        with self.assertRaises(ValueError):run(s)
        with self.assertRaises(UnsupportedMechanicError):run(duel())

    def test_previous_body_trace_with_corrected_initial_hand_snapshot(self):
        from tests.historical_assertions import with_correct_initial_hands
        folder=ROOT/'results/stationary-2v2-hitboxes'
        profiles=json.loads((folder/'characters.json').read_text())['characters']
        actual=run_shared_scenario(json.loads((folder/'scenario.json').read_text()),
            profiles,
            body_definition=json.loads((folder/'body_hitboxes.json').read_text()))
        self.assertEqual(actual,with_correct_initial_hands(json.loads((folder/'run.json').read_text()),profiles))

    def test_complete_terrain_encounter(self):
        r=run(SCENARIO)
        self.assertEqual(r['surviving_teams'],['A'])
        self.assertEqual(set(r['terrain_geometry']),{'ground','cube_1','cube_2','cube_3'})
        self.assertEqual(D(r['final_states']['B_1E1']['died_at_ms']),15264)
        self.assertEqual(D(r['final_states']['B_1E2']['died_at_ms']),10104)
        self.assertEqual(D(r['final_states']['A_1E2']['hp']),8140)
