"""Entity flights, copying and safe owner contact on the real shared timeline.

Copy/vertical-launch fixtures invoke shared APIs at explicit boundaries. They
probe future authored interactions; they do not claim 1E3/2E4 ability casts.

These numerical/phase contracts select the pre-equilibrium rules explicitly.
Current selected-rule interactions are covered in test_equilibrium_interactions.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events, read, scenario
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS

CURRENT=read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json')


def one_shot_profiles(*,speed=900,acceleration=-300,owner='ignore',inside=False):
    profiles=deepcopy(PROFILES)
    p=profiles['1E2']
    p['timing_profiles']['1'].update(projectile_speed_mps=speed,projectile_acceleration_mps2=acceleration)
    p['abilities']['1']['weapon_cooldown_ms']=100000
    p['abilities']['1']['projectile_geometry']['contact_policy']={
        'owner':owner,'other_bodies':'ignore' if owner!='ignore' else 'impact',
        'terrain':'ignore' if owner!='ignore' else 'impact'}
    if inside:
        p['abilities']['1']['hand_positions_m']['start']['left']=[0,0,0]
    return profiles


def run(s,*,profiles=None,operations=(),vertical_owner=False,effects=CURRENT,precision=50,sample_interval_ms=None):
    class Fixture(SharedEncounter):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            for when,operation in operations:
                self.push(when,'fixture_projectile',operation,priority=2)

        def _process(self,kind,payload):
            if kind=='fixture_projectile':
                if payload.get('noop'):
                    self.log('fixture_noop')
                    return
                shots=[f for f in self.projectile_flights.values() if f['actor']=='A']
                entity_id=shots[-1 if payload.get('child') else 0]['id']
                if payload.get('remove'):
                    self.projectiles.terminal(self.projectile_flights[entity_id],'removed')
                    self.gravity_deferred_contacts.pop(entity_id,None) if self.gravity_mode else None
                    self.log('fixture_projectile_removed',projectile_id=entity_id)
                else:
                    copied=self.projectile_system.copy(entity_id,source=payload['source'],offset_m=payload['offset'])
                    self.log('fixture_copy_result',projectile_id=entity_id,result=copied)
                return
            return super()._process(kind,payload)

        def release_body_projectile(self,actor,action,ability,timing):
            if not vertical_owner:
                return super().release_body_projectile(actor,action,ability,timing)
            # A trajectory probe emitted through an actual gun action. Override
            # only launch geometry to exercise departure and return to its owner.
            origin=actor.body_origin_m
            velocity=(0.,0.,5.)
            controls={key:float(self.physics[key]) for key in
                ('gravity_mps2','max_step_s','relative_tolerance','absolute_tolerance')}
            trajectory=PersistentProjectileTrajectory(origin,velocity,float((self.horizon-self.time)/1000),**controls)
            flight=self.projectile_system.create(actor,action,ability,{
                'aim_target':action.target,'released_at_ms':self.time,'trajectory_started_at_ms':self.time,
                'distance_offset_m':D(0),'origin_m':origin,'aim_point_m':origin,'radius_m':D('.02'),
                'initial_speed_mps':D(5),'initial_velocity_mps':velocity,'acceleration_mps2':D(0),'status':'in_flight'})
            self.gravity_trajectories[flight['id']]=trajectory
            self.projectile_system.initialize_owner(flight)
            self.log('projectile_released',**self.projectiles.link(flight),origin_m=origin,initial_velocity_mps=velocity)

    if profiles is None:profiles=one_shot_profiles()
    with localcontext(Context(prec=precision)):
        return Fixture(s,profiles,precision=precision,sample_interval_ms=sample_interval_ms,
            body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,
            combat_locomotion_definition=effects,projectile_physics_definition=PHYSICS if s['scope']==GRAVITY_MOBILE_SCOPE else None,
            jump_definition=JUMP,climb_definition=CLIMB).run()


class ProjectileEntityCombatTests(unittest.TestCase):
    def test_current_flight_id_is_independent_of_the_action_that_released_it(self):
        s=scenario(500,fire_at=0,target=(200,-20));command(s,'A',0,'run')
        r=run(s)
        release=events(r,'projectile_released','A')[0]
        flight=r['projectile_flights'][0]
        self.assertNotEqual(release['action_id'],release['projectile_id'])
        self.assertEqual(flight['id'],release['projectile_id'])
        self.assertEqual(flight['action_id'],release['action_id'])
        self.assertEqual((flight['actor'],flight['ability']),('A','1'))

    def test_two_copied_flights_hit_independently_with_one_payment_and_round(self):
        s=scenario(650,fire_at=0,target=(200,-20));command(s,'A',0,'run')
        baseline=run(s)
        # The run transition interrupts initial firing; copy the actual resumed
        # release rather than assuming the historical pre-effort timestamp.
        copied_at=D(events(baseline,'projectile_released','A')[0]['time_ms'])+10
        r=run(s,operations=[(copied_at,{'source':'field:1','offset':[0,0,0]})])
        flights=r['projectile_flights']
        self.assertEqual(len(flights),2)
        self.assertEqual(len({f['id'] for f in flights}),2)
        self.assertEqual(len({f['action_id'] for f in flights}),1)
        batches=events(r,'impact_batch_resolved')
        self.assertEqual(len(batches),1)
        self.assertEqual(len(batches[0]['hits']),2)
        self.assertEqual({p['projectile_id'] for p in batches[0]['hits']},{f['id'] for f in flights})
        self.assertEqual(r['final_states']['A']['ammo'],baseline['final_states']['A']['ammo'])
        self.assertEqual(r['metrics']['A']['dyspnea_paid'],baseline['metrics']['A']['dyspnea_paid'])
        self.assertLess(D(r['final_states']['B']['hp']),D(baseline['final_states']['B']['hp']))

    def test_copy_preserves_distance_falloff_instead_of_resetting_it_at_creation(self):
        s=scenario(650,fire_at=0,target=(200,-20))
        r=run(s,operations=[(200,{'source':'field:1','offset':[0,0,0]})])
        copy=events(r,'projectile_copied')[0]
        self.assertGreater(D(copy['retained_traveled_distance_m']),70)
        hits=events(r,'impact_batch_resolved')[0]['hits']
        self.assertLess(abs(D(hits[0]['distance_m'])-D(hits[1]['distance_m'])),D('1e-25'))
        for hit in hits:
            self.assertLess(abs(D(hit['incoming'])-(D(437)-D('.25')*D(hit['distance_m']))),D('1e-25'))

    def test_same_source_cannot_recursively_duplicate_parent_or_descendant(self):
        operations=[(200,{'source':'field:1','offset':[0,3,0]}),
            (201,{'source':'field:1','offset':[0,3,0]}),
            (202,{'source':'field:1','offset':[0,3,0],'child':True}),
            (203,{'source':'field:2','offset':[0,3,0],'child':True})]
        r=run(scenario(400,fire_at=0,target=(200,-20)),operations=operations)
        self.assertEqual([e['result'] is None for e in events(r,'fixture_copy_result')],[False,True,True,False])
        self.assertEqual(len(r['projectile_flights']),3)
        roots={f['root_projectile_id'] for f in r['projectile_flights']}
        self.assertEqual(len(roots),1)
        self.assertEqual(r['projectile_flights'][0]['duplication_sources'],['field:1'])
        self.assertEqual(r['projectile_flights'][-1]['duplication_sources'],['field:1','field:2'])

    def test_parent_contact_does_not_cancel_a_missed_child_or_its_own_stop_event(self):
        r=run(scenario(3400,fire_at=0,target=(200,-20)),operations=[(200,{'source':'field:1','offset':[0,3,0]})])
        parent,child=r['projectile_flights']
        self.assertEqual((parent['status'],child['status']),('collided','stopped'))
        stopped=events(r,'projectile_stopped')
        self.assertEqual([e['projectile_id'] for e in stopped],[child['id']])
        self.assertFalse(any(e['type']=='projectile_stopped' for e in r['pending_events']))

    def test_removing_parent_after_copy_does_not_remove_or_reattribute_child(self):
        r=run(scenario(650,fire_at=0,target=(200,-20)),operations=[
            (200,{'source':'field:1','offset':[0,0,0]}),(220,{'remove':True})])
        parent,child=r['projectile_flights']
        self.assertEqual((parent['status'],child['status']),('removed','collided'))
        hits=events(r,'impact_batch_resolved')
        self.assertEqual(len(hits),1)
        self.assertEqual(hits[0]['hits'][0]['projectile_id'],child['id'])
        self.assertEqual(hits[0]['hits'][0]['action_id'],parent['action_id'])

    def test_gravity_copy_preserves_momentum_distance_and_independent_hit(self):
        s=scenario(650,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        r=run(s,operations=[(200,{'source':'field:1','offset':[0,0,0]})])
        self.assertEqual(len(r['projectile_flights']),2)
        hits=events(r,'projectile_body_collision')
        self.assertEqual(len(hits),2)
        self.assertEqual(len({e['projectile_id'] for e in hits}),2)
        self.assertLessEqual(abs(D(hits[0]['distance_m'])-D(hits[1]['distance_m'])),D('1e-7'))
        copy=events(r,'projectile_copied')[0]
        self.assertGreater(D(copy['retained_traveled_distance_m']),70)

    def test_owner_can_catch_and_consume_a_slow_projectile_after_release(self):
        s=scenario(1200,fire_at=0,target=(100,-20));command(s,'A',0,'run')
        p=one_shot_profiles(speed=1,acceleration=0,owner='consume_after_separation')
        r=run(s,profiles=p)
        consumed=events(r,'projectile_owner_consumed')
        self.assertEqual(len(consumed),1)
        self.assertEqual(consumed[0]['target'],'A')
        self.assertGreater(D(consumed[0]['time_ms']),D(events(r,'projectile_released')[0]['time_ms']))
        self.assertEqual(D(r['final_states']['A']['hp']),8140)
        self.assertFalse(events(r,'impact_batch_resolved'))
        self.assertEqual(r['projectile_flights'][0]['status'],'consumed')

    def test_nonimmune_owner_contact_can_apply_normal_impact_with_source_attribution(self):
        s=scenario(1200,fire_at=0,target=(100,-20));command(s,'A',0,'run')
        r=run(s,profiles=one_shot_profiles(speed=1,acceleration=0,owner='impact_after_separation'))
        hit=events(r,'impact_batch_resolved')[0]
        self.assertEqual((hit['target'],hit['hits'][0]['actor']),('A','A'))
        self.assertLess(D(r['final_states']['A']['hp']),8140)
        self.assertEqual(D(r['final_states']['B']['hp']),8140)

    def test_birth_inside_owner_is_immune_until_whole_body_exit_then_catchable(self):
        s=scenario(1500,fire_at=0,target=(100,-20));command(s,'A',500,'walk')
        r=run(s,profiles=one_shot_profiles(speed=1,acceleration=0,owner='consume_after_separation',inside=True))
        release=events(r,'projectile_released')[0]
        clearance=events(r,'projectile_owner_cleared')[0]
        consumed=events(r,'projectile_owner_consumed')[0]
        self.assertLess(D(release['time_ms']),D(clearance['time_ms']))
        self.assertLess(D(clearance['time_ms']),D(consumed['time_ms']))
        self.assertEqual(len(events(r,'projectile_owner_cleared')),1)
        self.assertEqual(len(events(r,'projectile_owner_consumed')),1)

    def test_ballistic_exit_and_return_do_not_depend_on_observation_boundaries(self):
        s=scenario(1400,fire_at=0,target=(100,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        p=one_shot_profiles(owner='consume_after_separation',inside=True)
        baseline=run(s,profiles=p,vertical_owner=True)
        self.assertTrue(events(baseline,'projectile_owner_cleared'))
        self.assertTrue(events(baseline,'projectile_owner_consumed'))
        for precision,interval in ((50,37),(80,113)):
            r=run(s,profiles=p,vertical_owner=True,precision=precision,sample_interval_ms=interval)
            for kind in ('projectile_owner_cleared','projectile_owner_consumed'):
                self.assertEqual(events(r,kind)[0]['time_ms'],events(baseline,kind)[0]['time_ms'])

    def test_copying_cannot_use_ambiguous_legacy_trace_ids(self):
        effects=deepcopy(CURRENT);effects.pop('projectile_entities')
        with self.assertRaisesRegex(UnsupportedMechanicError,'current moving entity rules'):
            run(scenario(400,fire_at=0),effects=effects,operations=[(200,{'source':'field:1','offset':[0,0,0]})])

    def test_copy_contact_outcome_is_stable_under_precision_samples_and_actor_order(self):
        s=scenario(650,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        op=[(200,{'source':'field:1','offset':[0,0,0]})]
        baseline=run(s,operations=op)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        for precision,interval in ((50,37),(80,113)):
            r=run(s,operations=op,precision=precision,sample_interval_ms=interval)
            self.assertEqual([(e['projectile_id'],e['time_ms']) for e in events(r,'projectile_body_collision')],
                [(e['projectile_id'],e['time_ms']) for e in events(baseline,'projectile_body_collision')])
            for name in ('A','B'):
                for field in ('hp','armor','shield','dyspnea'):
                    self.assertLess(abs(D(r['final_states'][name][field])-D(baseline['final_states'][name][field])),D('1e-7'))

    def test_quantized_owner_exit_keeps_its_confirmation_across_subquantum_boundaries(self):
        s=scenario(1400,fire_at=0,target=(100,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        p=one_shot_profiles(owner='consume_after_separation',inside=True)
        baseline=run(s,profiles=p,vertical_owner=True)
        clear=events(baseline,'projectile_owner_cleared')[0]
        release=D(events(baseline,'projectile_released')[0]['time_ms'])
        confirmed=release+dec(clear['separation_bracket_s'][1])*1000
        rounded=D(clear['time_ms'])
        self.assertLess(confirmed,rounded)
        boundaries=[(confirmed+(rounded-confirmed)*fraction,{'noop':True}) for fraction in (D('.3'),D('.7'))]
        r=run(s,profiles=p,vertical_owner=True,operations=boundaries)
        for kind in ('projectile_owner_cleared','projectile_owner_consumed'):
            self.assertEqual(events(r,kind)[0]['time_ms'],events(baseline,kind)[0]['time_ms'])

    def test_bad_contact_policy_is_rejected_before_any_weapon_action_executes(self):
        p=one_shot_profiles()
        p['1E2']['abilities']['1']['projectile_geometry']['contact_policy']['owner']='always'
        with self.assertRaisesRegex(UnsupportedMechanicError,'contact policy'):
            run(scenario(400,fire_at=0),profiles=p)

    def test_numerically_inert_shot_cannot_be_copied_before_its_rounded_stop_event(self):
        s=scenario(4000,fire_at=0,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        p=one_shot_profiles()
        p['1E2']['abilities']['1']['projectile_geometry']['contact_policy']={
            'owner':'ignore','other_bodies':'ignore','terrain':'ignore'}
        baseline=run(s,profiles=p)
        flight=baseline['projectile_flights'][0]
        confirmed=D(flight['trajectory_started_at_ms'])+dec(flight['stopping_time_bracket_s'][1])*1000
        rounded=D(flight['stops_at_ms'])
        r=run(s,profiles=p,operations=[((confirmed+rounded)/2,{'source':'field:1','offset':[0,0,0]})])
        self.assertEqual(len(r['projectile_flights']),1)
        self.assertIsNone(events(r,'fixture_copy_result')[0]['result'])
        self.assertEqual(r['projectile_flights'][0]['duplication_sources'],[])

    def test_ballistic_apex_is_still_an_active_projectile_that_can_be_copied(self):
        s=scenario(1400,fire_at=0,target=(100,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        p=one_shot_profiles(owner='consume_after_separation',inside=True)
        baseline=run(s,profiles=p,vertical_owner=True)
        release=D(events(baseline,'projectile_released')[0]['time_ms'])
        apex=release+D(5)/D('9.81')*1000
        r=run(s,profiles=p,vertical_owner=True,operations=[(apex,{'source':'field:1','offset':[0,0,0]})])
        self.assertEqual(len(events(r,'projectile_copied')),1)
        self.assertEqual(len(events(r,'projectile_owner_consumed')),2)

    def test_copied_flights_keep_traveling_and_damage_attribution_after_owner_death(self):
        s=scenario(650,fire_at=50,target=(200,-20));s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['action_selection']['B']['start_ms']=0
        s['encounter']['participants']['A']['initial_state']['hp']=1
        r=run(s,operations=[(250,{'source':'field:1','offset':[0,0,0]})])
        death=D(events(r,'character_died','A')[0]['time_ms'])
        hits=events(r,'projectile_body_collision','A')
        self.assertEqual(len(hits),2)
        self.assertTrue(all(D(hit['time_ms'])>death for hit in hits))
        self.assertEqual(len({hit['action_id'] for hit in hits}),1)
        self.assertLess(D(r['final_states']['B']['hp']),8140)
