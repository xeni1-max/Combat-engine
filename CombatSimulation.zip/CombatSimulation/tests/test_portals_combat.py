"""Actual 1E3 portal casting/use plus labelled shared-API life/constraint probes."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from tests.test_equilibrium_combat import scene as base_scene, run, rules
from tests.test_binding_combat import run as configured_run, attach
from tests.test_mobile_combat import read, command, events, PROFILES
from tests.test_impact_bindings_combat import add
from tests.test_world_colliders_combat import wall


def scene(duration=1000, target=(10,-20,0)):
    s=base_scene(duration,character='1E3');s['id']='actual_portal_pair'
    s['action_selection']['A'].update(abilities=['3'],start_ms=0,reload_when_empty=False)
    if target is not None:s['action_selection']['A']['ability_targets']={'3':{'kind':'world_point','point_m':list(target)}}
    return s


def use(s,time=350,actor='A',**kw):
    s.setdefault('control_script',[]).append({'actor':actor,'at_ms':time,'command':'use_portal',**kw})


def pair(r):return r['portal_pairs'][0]


class PortalCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        json.dumps(r);damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-damage.amount(target=name)),D('1e-8'))
        return damage

    def test_actual_source_active_cooldown_and_no_activation_cost(self):
        r=run(scene());self.conserved(r);p=pair(r)
        self.assertEqual((D(p['deployed_at_ms']),D(p['expiry_ms'])),(300,8300))
        self.assertEqual(p['definition'],{'maximum_m':10,'duration_ms':8000,'reuse_ms':2000,'use_radius_m':'0.5'})
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),12000)
        self.assertFalse(events(r,'dyspnea_paid','A'));self.assertFalse(events(r,'self_status_applied','A'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_public_walking_reuse_and_return_keep_offset_and_pace(self):
        r=run(read('scenarios/1e3_portals.json'));self.conserved(r)
        self.assertEqual([u['status'] for u in r['portal_uses']],['used','used','rejected','used'])
        self.assertEqual(r['portal_uses'][2]['reason'],'reuse_not_ready')
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('-.44'))
        self.assertEqual(D(r['final_states']['B']['position_m'][0]),D('14.64'))
        self.assertEqual(tuple(map(D,r['final_states']['B']['locomotion']['velocity_mps'])),(2,0,0))

    def test_exact_reuse_boundary_and_failed_use_do_not_restart_work(self):
        s=scene(2400)
        for t in (350,2349,2350):use(s,t)
        r=run(s);self.conserved(r)
        self.assertEqual([u['status'] for u in r['portal_uses']],['used','rejected','used'])
        self.assertEqual(D(r['portal_uses'][1]['ready_at_ms']['A']),2350)
        self.assertEqual(len(events(r,'portal_reuse_started')),2)
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),0)

    def test_each_user_has_independent_reuse_and_enemy_cannot_activate(self):
        s=scene(600);add(s,'C',['-.4',-20],team='A')
        use(s,350);command(s,'A',350,'walk');use(s,600,'C');use(s,400,'B')
        r=run(s);self.conserved(r)
        by={u['actor']:u for u in r['portal_uses']}
        self.assertEqual(by['A']['status'],'used');self.assertEqual(by['C']['status'],'used')
        self.assertEqual(by['B']['reason'],'no_nearby_allied_portal')
        self.assertEqual({x['actor'] for x in r['portal_reuse_clocks']},{'A','C'})

    def test_nearby_range_is_inclusive_and_preserves_entry_offset(self):
        s=scene();add(s,'C',['-.5',-20],team='A');use(s,350,'C')
        r=run(s);self.assertEqual(r['portal_uses'][0]['status'],'used')
        self.assertEqual(D(r['final_states']['C']['position_m'][0]),D('9.5'))
        s['encounter']['participants']['C']['position_m'][0]='-.500001'
        r=run(s);self.assertEqual(r['portal_uses'][0]['reason'],'no_nearby_allied_portal')
        self.assertEqual(r['portal_reuse_clocks'],[])

    def test_default_target_clamps_to_ten_metres_and_freezes_at_selection(self):
        s=scene(target=None);command(s,'B',0,'walk');r=run(s)
        for a,b in zip(map(D,pair(r)['endpoints_m'][1]),(10,-20,0)):
            self.assertLess(abs(a-b),D('1e-45'))
        self.assertNotEqual(D(r['final_states']['B']['position_m'][0]),30)

    def test_diagonal_default_target_rounds_inside_declared_range(self):
        s=scene(target=None);s['encounter']['participants']['B']['position_m']=[30,-7]
        for precision in (50,80):
            r=run(s,precision=precision);points=pair(r)['endpoints_m']
            self.assertLessEqual(sum((D(b)-D(a))**2 for a,b in zip(*points)),D(100)+D('1e-45'))
            self.assertGreater(sum((D(b)-D(a))**2 for a,b in zip(*points)),D('99.999999999'))

    def test_moving_caster_releases_at_current_feet_with_frozen_target(self):
        s=scene();command(s,'A',0,'walk');use(s);r=run(s);self.conserved(r)
        self.assertEqual(tuple(map(D,pair(r)['endpoints_m'][0])),(D('.54'),-20,0))
        self.assertEqual(tuple(map(D,pair(r)['endpoints_m'][1])),(10,-20,0))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('11.4'))
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'walking')

    def test_release_rechecks_range_without_refunding_cast_cooldown(self):
        s=scene();s['encounter']['participants']['A']['movement_direction']=[-1,0]
        command(s,'A',0,'walk');r=run(s)
        self.assertEqual(r['portal_pairs'],[])
        self.assertEqual(r['portal_deployments'][0]['reason'],'target_out_of_range_at_release')
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),12000)

    def test_explicit_out_of_range_target_is_not_silently_clamped(self):
        r=run(scene(target=('10.000001',-20,0)))
        self.assertEqual(r['portal_pairs'],[]);self.assertEqual(r['portal_deployments'][0]['status'],'rejected')

    def test_only_allies_are_required_with_explicit_world_target(self):
        s=scene()
        for p in s['encounter']['participants'].values():p['team']='A'
        use(s);r=run(s);self.assertEqual(r['portal_uses'][0]['status'],'used')

    def test_two_casts_have_source_timing_and_independent_pair_lifetimes(self):
        r=run(scene(12300));self.conserved(r)
        self.assertEqual([D(p['deployed_at_ms']) for p in r['portal_pairs']],[300,12300])
        self.assertEqual([p['status'] for p in r['portal_pairs']],['expired','active'])
        self.assertEqual([D(e['time_ms']) for e in events(r,'ability_started','A')],[0,12000])

    def test_expiry_wins_same_clock_use_and_retires_environmental_clocks(self):
        s=scene(8300);use(s);use(s,8300);r=run(s)
        self.assertEqual(r['portal_uses'][-1]['reason'],'no_nearby_allied_portal')
        self.assertEqual(pair(r)['status'],'expired')
        self.assertTrue(all(x['status']=='ended' and x['end_reason']=='pair_expired' for x in r['portal_reuse_clocks']))
        self.assertFalse(any(k.startswith('portal-use:') for k in r['final_states']['A']['cooldown_clocks']))

    def test_blocked_exit_fails_atomically_then_newly_clear_exit_can_be_used(self):
        s=scene();s['initial_colliders']=[wall('exit_wall',x=10,hp=2000)]
        use(s,350);use(s,500)
        def clear(w):w.collider_system.remove('exit_wall',reason='portal_exit_api_probe')
        r=run(s,operations=((450,clear),));self.conserved(r)
        self.assertEqual([u['status'] for u in r['portal_uses']],['rejected','used'])
        self.assertEqual(r['portal_uses'][0]['reason'],'exit_unavailable')
        self.assertEqual(len(events(r,'portal_reuse_started')),1)
        self.assertEqual(D(r['portal_reuse_clocks'][0]['clock']['ready_at_ms']),2500)

    def test_invalid_exit_does_not_silently_choose_a_farther_pair(self):
        s=scene();add(s,'C',[0,-21],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['3'],start_ms=0,reload_when_empty=False,
            ability_targets={'3':{'kind':'world_point','point_m':[0,-21,0]}})
        s['initial_colliders']=[wall('exit_wall',x=10,hp=2000)];use(s)
        r=run(s);self.assertEqual(len(r['portal_pairs']),2)
        self.assertEqual(r['portal_uses'][0]['reason'],'exit_unavailable')
        self.assertEqual(r['spatial_transitions'],[])

    def test_coincident_endpoints_are_noop_without_interrupt_or_reuse_cost(self):
        s=scene(target=(0,-20,0));use(s);r=run(s)
        self.assertEqual(r['portal_uses'][0]['status'],'unchanged')
        self.assertEqual(r['portal_reuse_clocks'],[]);self.assertFalse(r['spatial_transitions'])

    def test_explicit_identity_and_unknown_identity_have_deterministic_results(self):
        s=scene();use(s,350,portal_id='missing');use(s,400,portal_id='portal-pair:1')
        r=run(s);self.assertEqual([x['status'] for x in r['portal_uses']],['rejected','used'])
        self.assertEqual(r['portal_uses'][1]['requested_portal_id'],'portal-pair:1')

    def test_whole_body_binding_denies_use_but_lower_body_binding_travels(self):
        for kind,expected in (('whole_body','rejected'),('lower_body','used'),('upper_body','used')):
            s=scene();use(s)
            def bind(w):attach(w,kind=kind,target='A',duration=2000)
            r=run(s,operations=((320,bind),));self.conserved(r)
            self.assertEqual(r['portal_uses'][0]['status'],expected)
            self.assertEqual(r['binding_instances'][0]['status'],'active')

    def test_death_during_cast_cancels_deployment_but_released_pair_survives(self):
        def die(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        before=run(scene(),operations=((250,die),));self.assertFalse(before['portal_pairs'])
        s=scene();add(s,'C',['-.4',-20],team='A');use(s,600,'C')
        after=run(s,operations=((400,die),));self.assertEqual(after['portal_uses'][0]['status'],'used')
        self.assertEqual(pair(after)['source_life_generation'],1);self.assertEqual(pair(after)['status'],'active')

    def test_restored_user_gets_fresh_life_clock_and_stale_script_cannot_use_it(self):
        s=scene();use(s);use(s,600);use(s,650,expected_life_generation=2)
        def die(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        restored=[]
        def restore(w):restored.append(w.life_cycles.revive('A',expected_generation=1,hp=8140,source='portal_user_life_api_probe'))
        r=run(s,operations=((400,die),(500,restore)))
        self.assertEqual(restored,[True]);self.assertEqual([x['status'] for x in r['portal_uses']],['used','ignored','used'])
        self.assertEqual([x['life_generation'] for x in r['portal_reuse_clocks']],[1,2])
        self.assertEqual(r['portal_reuse_clocks'][0]['end_reason'],'user_life_ended')
        self.assertEqual(pair(r)['source_life_generation'],1)

    def test_real_pause_area_pauses_existing_and_new_user_reuse_work(self):
        s=scene(4000,target=(6,-20,0));add(s,'C',[10,-25],character='1E2',team='B')
        s['action_selection']['C'].update(abilities=['2'],start_ms=0,reload_when_empty=False)
        use(s,350);use(s,2350);use(s,4000)
        r=run(s);self.conserved(r)
        self.assertTrue(r['cooldown_pause_volumes'])
        self.assertEqual(r['portal_uses'][0]['status'],'used')
        self.assertEqual(r['portal_uses'][1]['reason'],'reuse_not_ready')
        self.assertTrue(r['portal_reuse_clocks'][0]['clock']['pause_sources'])
        self.assertIsNone(r['portal_reuse_clocks'][0]['clock']['ready_at_ms'])

    def test_reuse_clock_started_before_pause_area_keeps_remaining_work(self):
        s=scene(3000);add(s,'C',[10,-25],character='1E2',team='B')
        s['action_selection']['C'].update(abilities=['2'],start_ms=500,reload_when_empty=False)
        use(s,350);use(s,2350);r=run(s);self.conserved(r)
        clock=r['portal_reuse_clocks'][0]['clock']
        self.assertEqual(r['portal_uses'][1]['reason'],'reuse_not_ready')
        self.assertEqual(D(clock['remaining_work_ms']),1650)
        self.assertTrue(clock['pause_sources'])

    def test_air_destination_uses_gravity_and_native_landing(self):
        s=scene(1600,target=(8,-20,2));use(s);r=run(s);self.conserved(r)
        self.assertEqual(r['portal_uses'][0]['status'],'used');self.assertFalse(events(r,'jump_takeoff'))
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'ground')
        self.assertTrue(events(r,'jump_landed','A'));self.assertEqual(r['metrics']['A']['jumps_started'],0)

    def test_existing_weapon_and_summon_can_overlap_and_old_shot_stays_world_space(self):
        s=scene(1200);s['action_selection']['A']['abilities']=['3','1'];use(s,350)
        r=run(s);self.conserved(r)
        self.assertEqual({e['ability'] for e in events(r,'ability_started','A') if D(e['time_ms'])==0},{'3','1'})
        self.assertLess(D(events(r,'projectile_released','A')[0]['origin_m'][0]),1)
        self.assertEqual(len(r['projectile_flights']),1)
        self.assertTrue(events(r,'projectile_body_collision','A'))

    def test_bad_control_fields_and_definitions_reject_before_simulation(self):
        for extra in ({'portal_id':''},{'link_id':'x'},{'binding_id':'x'}):
            s=scene();use(s,**extra)
            with self.assertRaises(ValueError):run(s)
        cfg=rules();cfg.pop('portals')
        with self.assertRaises(UnsupportedMechanicError):configured_run(scene(),rules=cfg)
        for key,value in (('duration_ms',0),('maximum_m','NaN')):
            profiles=deepcopy(PROFILES);profiles['1E3']['abilities']['3']['portal_pair'][key]=value
            with self.assertRaises((ValueError,UnsupportedMechanicError)):configured_run(scene(),rules=rules(),profiles=profiles)

    def test_actual_grab_carries_enemy_and_keeps_hold_damage_and_effort(self):
        from tests.test_grapple_casts_combat import scene as grab_scene
        s=grab_scene(1000);add(s,'C',['-.4',-20],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['3'],start_ms=0,reload_when_empty=False,
            ability_targets={'3':{'kind':'world_point','point_m':['9.6',-20,0]}})
        base=run(s);use(s);r=run(s);self.conserved(r)
        self.assertEqual(r['portal_uses'][0]['transported_actors'],['A','B'])
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertEqual({x['actor'] for x in r['portal_reuse_clocks']},{'A','B'})
        for name in ('A','B'):
            self.assertEqual(r['final_states'][name]['hp'],base['final_states'][name]['hp'])
            self.assertEqual(r['final_states'][name]['dyspnea'],base['final_states'][name]['dyspnea'])
            self.assertEqual(D(r['final_states'][name]['position_m'][0])-D(base['final_states'][name]['position_m'][0]),10)

    def test_actual_climb_is_interrupted_at_use_and_retains_physical_velocity(self):
        from tests.test_climb_combat import climb
        s=base_scene(500);s['encounter']['participants']['A']['position_m']=['4.6',0]
        add(s,'C',['4.2',0],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['3'],start_ms=0,reload_when_empty=False,
            ability_targets={'3':{'kind':'world_point','point_m':['14.2',0,0]}})
        climb(s,time=200);use(s,375);r=run(s);self.conserved(r)
        self.assertEqual(r['portal_uses'][0]['status'],'used')
        self.assertEqual(events(r,'climb_interrupted','A')[0]['reason'],'transported_from_climb')
        self.assertFalse(events(r,'climb_completed','A'))
        self.assertAlmostEqual(D(r['final_states']['A']['locomotion']['velocity_mps'][2]),D(32)/3-D('9.81')*D('.125'),places=35)

    def test_actual_heat_exit_ends_exposure_without_deleting_released_beam(self):
        s=scene(1000);s['encounter']['participants']['B']['character']='1E1'
        s['action_selection']['B'].update(abilities=['4'],start_ms=0,reload_when_empty=False)
        use(s,500);r=run(s);self.conserved(r)
        left=next(e for e in events(r,'heat_exposure_left') if e['target']=='A')
        self.assertEqual(D(left['time_ms']),500)
        self.assertTrue(any(v['active'] for v in r['volume_instances']))
        self.assertLess(D(r['final_states']['A']['hp']),8140)

    def test_actual_electrical_screen_exit_ends_contact_at_use_clock(self):
        s=scene();s['action_selection']['B'].update(abilities=['5'],start_ms=0,reload_when_empty=False,
            ability_targets={'5':{'kind':'world_point','point_m':[0,-20,0],'axis':'y'}})
        use(s);r=run(s);self.conserved(r)
        self.assertEqual(r['portal_uses'][0]['status'],'used')
        contact=next(x for x in r['segment_field_contacts'] if x['target']=='A')
        self.assertEqual(D(contact['ended_at_ms']),350)
        self.assertEqual(r['segment_fields'][0]['status'],'active')
        self.assertLess(D(r['final_states']['A']['hp']),8140)

    def test_same_clock_users_compete_for_destination_without_partial_overlap(self):
        s=scene();add(s,'C',['-.4',-20],team='A');use(s);use(s,350,'C')
        r=run(s);self.conserved(r)
        # Offsets retain the same legal separation; both destinations are free.
        self.assertEqual([x['status'] for x in r['portal_uses']],['used','used'])
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),10)
        self.assertEqual(D(r['final_states']['C']['position_m'][0]),D('9.6'))

    def test_two_allied_pairs_have_independent_user_reuse_work(self):
        s=scene();add(s,'C',['-.4',-20],character='1E3',team='A')
        s['action_selection']['C'].update(abilities=['3'],start_ms=0,reload_when_empty=False,
            ability_targets={'3':{'kind':'world_point','point_m':['9.6',-20,0]}})
        use(s,350,portal_id='portal-pair:1');use(s,400,portal_id='portal-pair:2')
        r=run(s);self.conserved(r)
        self.assertEqual([u['status'] for u in r['portal_uses']],['used','used'])
        self.assertEqual({x['portal_id'] for x in r['portal_reuse_clocks']},{'portal-pair:1','portal-pair:2'})
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),0)


    def test_precision_order_observations_and_ambient_context_preserve_motion(self):
        s=read('scenarios/1e3_portals.json');base=run(s)
        other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        with localcontext(Context(prec=28)):r=run(other,precision=80,interval=17)
        self.conserved(r)
        self.assertEqual(r['portal_uses'],base['portal_uses'])
        for name in base['final_states']:
            for key in ('hp','dyspnea','disorientation','instability'):
                self.assertLess(abs(D(base['final_states'][name][key])-D(r['final_states'][name][key])),D('1e-8'))
            for a,b in zip(base['final_states'][name]['body_origin_m'],r['final_states'][name]['body_origin_m']):
                self.assertLess(abs(D(a)-D(b)),D('1e-8'))

