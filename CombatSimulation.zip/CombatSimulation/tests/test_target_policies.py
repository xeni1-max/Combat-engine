"""Pure target-policy contract: exact ordering, immutable inputs and legal IDs."""
from copy import deepcopy
from decimal import Context,localcontext
from fractions import Fraction as F
import unittest
from combat_sim.models import UnsupportedMechanicError
from combat_sim.stationary_geometry import nearest_living_enemy
from combat_sim.target_policies import (NearestLivingEnemy,LowestHPEnemy,make_target_policy,
    target_snapshot,select_enemy,describe_selection)


def states():
    return {'A':{'team':'A','hp':'100','position_m':[0,0],'private':{'resource':50}},
        'B':{'team':'B','hp':'80','position_m':[2,0]},
        'C':{'team':'B','hp':'20','position_m':[5,0]},
        'ally':{'team':'A','hp':'1','position_m':[1,0]},
        'dead':{'team':'B','hp':'0','position_m':[0,0]}}


class TargetPolicyTests(unittest.TestCase):
    def test_nearest_delegates_the_established_exact_choice(self):
        for precision in (28,80):
            with localcontext(Context(prec=precision)):
                s=states();s['B']['position_m']=[F(1,3),F(1,7)]
                for source in (s,dict(reversed(list(s.items())))):
                    self.assertEqual(NearestLivingEnemy().choose('A',target_snapshot(source)),nearest_living_enemy('A',source))

    def test_lowest_current_hp_can_choose_a_farther_living_enemy(self):
        self.assertEqual(LowestHPEnemy().choose('A',target_snapshot(states())),'C')

    def test_hp_then_exact_distance_then_identity_break_ties(self):
        s=states();s['B']['hp']='20';self.assertEqual(LowestHPEnemy().choose('A',target_snapshot(s)),'B')
        s['B']['position_m']=[-5,0]
        for source in (s,dict(reversed(list(s.items())))):
            self.assertEqual(LowestHPEnemy().choose('A',target_snapshot(source)),'B')

    def test_dead_source_and_world_without_enemies_return_none(self):
        for policy in (NearestLivingEnemy(),LowestHPEnemy()):
            s=states();s['A']['hp']='0';self.assertIsNone(policy.choose('A',target_snapshot(s)))
            s=states()
            for row in s.values():row['team']='A'
            self.assertIsNone(policy.choose('A',target_snapshot(s)))

    def test_snapshot_copies_only_immutable_required_state(self):
        s=states();copy=target_snapshot(s)
        self.assertEqual(set(copy['A']),{'team','hp','position_m'})
        with self.assertRaises(TypeError):copy['A']['hp']=0
        with self.assertRaises(TypeError):copy['A']['position_m'][0]=1
        with self.assertRaises(TypeError):copy['new']={}
        s['A']['position_m'][0]=99;s['A']['hp']='0'
        self.assertEqual(copy['A']['position_m'],(0,0));self.assertEqual(copy['A']['hp'],100)

    def test_unknown_policy_names_reject_explicitly(self):
        for value in (None,[],{},'unknown'):
            with self.subTest(value=value),self.assertRaises(UnsupportedMechanicError):make_target_policy(value)
        self.assertIsInstance(make_target_policy('lowest_hp_enemy'),LowestHPEnemy)

    def test_replacement_policy_cannot_return_an_illegal_enemy(self):
        class Invalid:
            name='invalid'
            def __init__(self,answer):self.answer=answer
            def choose(self,actor,participants):return self.answer
        for answer in ('A','ally','dead','missing',[],42):
            with self.subTest(answer=answer),self.assertRaisesRegex(ValueError,'ineligible'):
                select_enemy(Invalid(answer),'A',target_snapshot(states()))

    def test_replacement_policy_receives_a_snapshot_and_names_its_choice(self):
        class PreferB:
            name='prefer_b'
            def choose(self,actor,participants):return 'B'
        snapshot=target_snapshot(states());policy=PreferB();target=select_enemy(policy,'A',snapshot)
        record=describe_selection(policy,'A',snapshot,target)
        self.assertEqual((record['policy'],record['selected_enemy']),('prefer_b','B'))
        self.assertEqual([row['actor'] for row in record['candidates']],['B','C'])
        self.assertEqual(record['candidates'][0]['horizontal_distance_squared_m2'],'4')

    def test_malformed_replacement_policy_rejects_before_selection(self):
        for policy in (object(),type('Wrong',(),{'name':42,'choose':lambda *a:None})()):
            with self.assertRaisesRegex(ValueError,'name and choose'):select_enemy(policy,'A',target_snapshot(states()))


    def test_mutable_team_identity_is_rejected_at_the_snapshot_boundary(self):
        s=states();s['A']['team']=['A']
        with self.assertRaisesRegex(ValueError,'team identities'):target_snapshot(s)

    def test_chooser_cannot_change_eligibility_by_mutating_a_raw_api_input(self):
        class RewriteFriend:
            name='rewrites_friend'
            def choose(self,actor,participants):
                participants['ally']['team']='B'
                return 'ally'
        with self.assertRaisesRegex(ValueError,'ineligible'):
            select_enemy(RewriteFriend(),'A',states())
