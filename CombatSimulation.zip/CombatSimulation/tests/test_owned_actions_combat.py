"""Real shared combat overlap, selective restrictions and phase ownership.
These numerical/phase contracts select the pre-equilibrium rules explicitly.
Current selected-rule interactions are covered in test_equilibrium_interactions.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from combat_sim.shared_engine import SharedEncounter
from combat_sim.models import UnsupportedMechanicError
from combat_sim.battle_models import BattleAction
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events, read
from tests.test_sprint_combat import PHYSICS, run as old_run, scenario

CURRENT=read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json')


def run(s,**kwargs):
    return old_run(s,effects=CURRENT,jump_definition=JUMP,climb_definition=CLIMB,**kwargs)


def initial_block(s,functions,until,source='1E3.initial-freeze'):
    s.setdefault('initial_restrictions',[]).append({'target':'A','source':source,
        'functions':functions,'duration_ms':until})


def run_with_blocks(s,blocks,*,precision=50,sample_interval_ms=50):
    class RestrictionFixture(SharedEncounter):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            for time,source,functions,until in blocks:
                self.push(D(time),'fixture_restriction',{'source':source,'functions':functions,'until':until},2)
        def _process(self,kind,payload):
            if kind=='fixture_restriction':
                self.apply_action_restriction('A',source=payload['source'],functions=payload['functions'],until_ms=payload['until'])
                return
            return super()._process(kind,payload)
    with localcontext(Context(prec=precision)):
        return RestrictionFixture(s,PROFILES,precision=precision,sample_interval_ms=sample_interval_ms,
            body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,
            combat_locomotion_definition=CURRENT,projectile_physics_definition=PHYSICS,
            jump_definition=JUMP,climb_definition=CLIMB).run()


class OwnedCombatTests(unittest.TestCase):
    def test_jump_and_gun_share_clock_with_separate_action_instances_and_costs(self):
        s=scenario(650,fire_at=100,target=(200,-20));command(s,'A',0,'jump')
        r=run(s)
        self.assertEqual(D(events(r,'jump_takeoff','A')[0]['time_ms']),100)
        first=events(r,'projectile_released','A')[0]
        # Jump U80 at takeoff delays gun admission until180. Its hand Recovery
        # still overlaps jump Active; firing finishes after the jump gesture.
        self.assertEqual(D(first['time_ms']),291)
        gun=events(r,'ability_started','A')[0]
        self.assertEqual(D(gun['time_ms']),180)
        self.assertLess(D(gun['time_ms']),D(events(r,'jump_active_completed','A')[0]['time_ms']))
        self.assertEqual(max(len(p['states']['A']['owned_actions']) for p in r['curve']),2)
        payments=events(r,'dyspnea_paid','A')
        self.assertEqual(len({(p['action_id'],p['phase']) for p in payments}),len(payments))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),sum((D(p['amount']) for p in payments),D(0)))

    def test_run_transition_can_overlap_weapon_recovery_after_instability_interrupts(self):
        s=scenario(500,fire_at=0,target=(100,-20));command(s,'A',0,'run')
        r=run(s)
        release=D(events(r,'projectile_released','A')[0]['time_ms'])
        run_start=[e for e in events(r,'movement_active_started','A') if e['action']=='run'][0]
        self.assertLess(D(run_start['time_ms']),release)
        resumed=events(r,'ability_started','A')[-1]
        self.assertEqual(D(resumed['time_ms']),156)
        self.assertLess(D(resumed['time_ms']),D(run_start['active_end_ms']))
        self.assertGreater(release,D(run_start['active_end_ms']))
        self.assertEqual([e['action']['kind'] for e in events(r,'controlled_action_cancelled','A')],['slash_projectile'])
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'running')

    def test_crouch_instability_interrupts_gun_and_resumed_release_uses_lowered_hand(self):
        s=scenario(300,fire_at=0,target=(100,-20));command(s,'A',0,'crouch')
        r=run(s)
        shot=events(r,'projectile_released','A')[0]
        self.assertEqual(D(shot['time_ms']),191)
        self.assertEqual(D(shot['origin_m'][2]),D('.625'))
        self.assertEqual(events(r,'controlled_action_cancelled','A')[0]['reason'],'sustained_control_instability')
        self.assertEqual(r['metrics']['A']['crouches_completed'],1)

    def test_upper_freeze_allows_lower_locomotion_and_unblocks_attacks_at_expiry(self):
        s=scenario(650,fire_at=0);initial_block(s,['upper_body'],350)
        command(s,'A',0,'walk')
        r=run(s)
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),1)
        self.assertGreaterEqual(D(events(r,'projectile_released','A')[0]['time_ms']),350)
        self.assertEqual(D(events(r,'movement_active_started','A')[0]['time_ms']),0)

    def test_lower_freeze_allows_attacks_and_lower_intent_waits_until_expiry(self):
        s=scenario(650,fire_at=0);initial_block(s,['lower_body'],350)
        command(s,'A',0,'walk')
        r=run(s)
        self.assertEqual(D(events(r,'projectile_released','A')[0]['time_ms']),111)
        self.assertEqual(D(events(r,'movement_active_started','A')[0]['time_ms']),350)
        # .54 m from the ordinary start/running interval, minus the complete
        # triangular U135/200 speed penalty from the second shot (491–626 ms).
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('.54')-D(135)**2/400000)

    def test_overlapping_sources_and_refresh_do_not_release_functions_early(self):
        s=scenario(800,fire_at=0)
        initial_block(s,['upper_body'],200,'ice-one');initial_block(s,['upper_body'],400,'ice-two')
        r=run_with_blocks(s,[(150,'ice-one',['upper_body'],500)])
        shot=D(events(r,'projectile_released','A')[0]['time_ms'])
        self.assertEqual(shot,611)
        expired=events(r,'action_restriction_expired','A')
        self.assertEqual([(e['source'],D(e['time_ms'])) for e in expired],[('ice-two',D(400)),('ice-one',D(500))])

    def test_upper_restriction_cancels_only_weapon_and_retains_jump(self):
        s=scenario(700,fire_at=0,target=(200,-20));command(s,'A',0,'jump')
        r=run_with_blocks(s,[(90,'upper-ice',['upper_body'],400)])
        cancelled=events(r,'controlled_action_cancelled','A')
        self.assertEqual([e['action']['kind'] for e in cancelled],['slash_projectile'])
        self.assertEqual(D(events(r,'jump_takeoff','A')[0]['time_ms']),100)
        self.assertEqual(D(events(r,'jump_active_completed','A')[0]['time_ms']),250)
        self.assertEqual(D(events(r,'projectile_released','A')[0]['time_ms']),440)
        cancelled_id=cancelled[0]['action_id']
        self.assertFalse([e for e in events(r,'dyspnea_paid','A') if e['action_id']==cancelled_id])

    def test_lower_restriction_cancels_only_gathering_jump_and_weapon_finishes(self):
        s=scenario(650,fire_at=0);command(s,'A',0,'jump')
        r=run_with_blocks(s,[(90,'lower-ice',['lower_body'],400)])
        self.assertEqual([e['action']['kind'] for e in events(r,'controlled_action_cancelled','A')],['basic_jump'])
        self.assertFalse(events(r,'jump_takeoff','A'))
        self.assertEqual(D(events(r,'projectile_released','A')[0]['time_ms']),111)
        self.assertFalse([e for e in events(r,'dyspnea_paid','A') if e['ability']=='jump'])

    def test_lower_restriction_after_takeoff_cancels_control_but_not_physical_flight(self):
        s=scenario(1100,fire_at=100);command(s,'A',0,'jump')
        r=run_with_blocks(s,[(150,'lower-ice',['lower_body'],900)])
        self.assertFalse(events(r,'jump_active_completed','A'))
        landing=events(r,'jump_landed','A')[0]
        self.assertAlmostEqual(D(landing['time_ms']),D(100)+D(640000)/981,places=23)
        self.assertTrue(events(r,'projectile_released','A'))
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_physical_contact_interrupts_sustained_weapon_and_retains_body_collision_state(self):
        s=scenario(1200,fire_at=300,target=(-30,0));s['encounter']['participants']['A']['position_m']=[3,0]
        command(s,'A',0,'run')
        r=run(s)
        contact=D(events(r,'body_contact')[0]['time_ms'])
        shot=D(events(r,'projectile_released','A')[0]['time_ms'])
        self.assertLess(contact,shot)
        cancelled=events(r,'controlled_action_cancelled','A')
        self.assertEqual([e['action']['kind'] for e in cancelled],['slash_projectile'])
        self.assertEqual(D(cancelled[0]['time_ms']),contact)
        self.assertEqual(cancelled[0]['reason'],'sustained_control_instability')
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('4.95'))

    def test_death_cancels_all_owned_actions_and_invalidates_their_events(self):
        s=scenario(700,fire_at=0,target=(30,-20));command(s,'A',0,'jump')
        s['encounter']['participants']['A']['initial_state'].update(hp=1,disorientation=300)
        s['action_selection']['B']['start_ms']=0
        r=run(s)
        death=events(r,'character_died','A')[0]
        self.assertEqual(len(death['cancelled_actions']),2)
        self.assertEqual(r['final_states']['A']['owned_actions'],[])
        self.assertFalse(events(r,'projectile_released','A'))
        self.assertFalse(events(r,'jump_takeoff','A'))

    def test_requirement_blocked_noop_does_not_starve_later_legal_movement(self):
        s=scenario(500);initial_block(s,['upper_body'],1000)
        command(s,'A',0,'stand');command(s,'A',0,'walk')
        r=run(s)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'walking')
        self.assertEqual(len(events(r,'posture_command_no_change','A')),1)

    def test_observations_precision_and_actor_order_preserve_overlap_outcome(self):
        s=scenario(1500,fire_at=0,target=(100,-20));command(s,'A',0,'run');command(s,'A',300,'jump')
        baseline=run(s,sample_interval_ms=None)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        for precision,interval in ((50,37),(80,113)):
            actual=run(s,precision=precision,sample_interval_ms=interval)
            self.assertEqual(len(events(actual,'projectile_released','A')),len(events(baseline,'projectile_released','A')))
            for actor in ('A','B'):
                for key in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertLessEqual(abs(D(actual['final_states'][actor][key])-D(baseline['final_states'][actor][key])),D('1e-7'))

    def test_invalid_requirement_data_and_unknown_function_fail_explicitly(self):
        s=scenario(200)
        initial_block(s,['not_a_body_function'],150)
        with self.assertRaisesRegex(ValueError,'Unknown required'):
            run(s)
        bad=deepcopy(CURRENT);del bad['action_ownership']['actions']['reload']
        with self.assertRaisesRegex(ValueError,'Missing current'):
            old_run(scenario(200),effects=bad)

    def test_self_disorientation_from_one_action_extends_another_gathering(self):
        s=scenario(650,fire_at=0,target=(200,-20));command(s,'A',0,'jump')
        r=run(s)
        extension=[e for e in events(r,'gathering_extended','A')
                   if e.get('source')=='parallel_action_self_disorientation'][0]
        self.assertEqual((D(extension['time_ms']),D(extension['old_active_start_ms']),
                          D(extension['added_disorientation']),D(extension['new_active_start_ms'])),
                         (91,100,135,235))
        self.assertEqual(D(events(r,'jump_takeoff','A')[0]['time_ms']),235)
        self.assertEqual(D(events(r,'projectile_released','A')[0]['time_ms']),111)
        self.assertNotEqual(extension['action_id'],extension['cause_action_id'])

    def test_incoming_disorientation_extends_all_gatherings_but_is_added_once(self):
        s=scenario(700,fire_at=0,target=(30,-20));command(s,'A',0,'jump')
        s['encounter']['participants']['A']['initial_state']['disorientation']=300
        s['action_selection']['B']['start_ms']=0
        r=run(s)
        impact=[e for e in events(r,'impact_batch_resolved') if e['target']=='A'][0]
        extensions=[e for e in events(r,'gathering_extended','A') if e['time_ms']==impact['time_ms']]
        self.assertEqual(len(extensions),2)
        self.assertEqual(len({e['action_id'] for e in extensions}),2)
        with localcontext(Context(prec=80)):
            expected=D(impact['state_before']['disorientation'])+D(impact['status_additions']['disorientation'])
        self.assertEqual(D(impact['state_after']['disorientation']),expected)

    def test_actual_delayed_weapon_payment_keeps_other_action_out_of_its_capacity(self):
        s=scenario(650,fire_at=0,target=(200,-20));s['encounter']['participants']['A']['initial_state']['dyspnea']=90
        command(s,'A',50,'jump')
        r=run(s,sample_interval_ms=37)
        first=events(r,'projectile_released','A')[0]
        request=events(r,'jump_requested','A')[0]
        self.assertGreater(D(request['time_ms']),D(first['time_ms']))
        payments=events(r,'dyspnea_paid','A')
        self.assertEqual([e['ability'] for e in payments],['1','jump'])
        for point in r['curve']:
            f=point['states']['A'];reserved=sum((D(a['reserved_dyspnea_capacity']) for a in f['owned_actions']),D(0))
            self.assertLessEqual(D(f['dyspnea'])+reserved,D(100)+D('1e-30'))

    def test_jump_can_overlap_the_actual_empty_magazine_reload(self):
        s=scenario(6500,fire_at=0,target=(100,-20))
        baseline=run(s,sample_interval_ms=None)
        reload=events(baseline,'reload_requested','A')[0]
        command(s,'A',int(D(reload['time_ms']))+50,'jump')
        r=run(s,sample_interval_ms=37)
        together=[p for p in r['curve'] if {'reload','basic_jump'}<=
            {a['action']['kind'] for a in p['states']['A']['owned_actions']}]
        self.assertTrue(together)
        self.assertGreaterEqual(r['metrics']['A']['reloads_completed'],1)
        self.assertEqual(r['metrics']['A']['jumps_started'],1)
        payments=events(r,'dyspnea_paid','A')
        self.assertEqual(len(payments),len({(e['action_id'],e['phase']) for e in payments}))

    def test_sprint_hand_requirements_and_attack_prohibition_remain_enforced(self):
        s=scenario(1200,fire_at=0,target=(100,-20))
        command(s,'A',0,'sprint');command(s,'A',600,'run')
        r=run(s)
        entry=[e for e in events(r,'movement_active_started','A') if e['action']=='sprint'][0]
        exit=[e for e in events(r,'movement_active_completed','A') if e['action']=='run' and D(e['time_ms'])>600][0]
        shots=[D(e['time_ms']) for e in events(r,'projectile_released','A')]
        self.assertTrue(any(t<D(entry['time_ms']) for t in shots))
        self.assertFalse(any(D(entry['time_ms'])<=t<D(exit['time_ms']) for t in shots))
        self.assertTrue(any(t>D(exit['time_ms']) for t in shots))

    def test_continuous_sprint_exhaustion_cancels_unpaid_posture_reservation(self):
        s=scenario(1500)
        s['encounter']['participants']['A']['initial_state'].update(dyspnea=90,disorientation=1000)
        command(s,'A',0,'sprint');command(s,'A',450,'crouch')
        r=run(s,sample_interval_ms=37)
        self.assertEqual(len(events(r,'maximum_dyspnea_trigger','A')),1)
        self.assertTrue(events(r,'posture_requested','A'))
        self.assertFalse(events(r,'posture_transition_started','A'))
        self.assertFalse([p for p in events(r,'dyspnea_paid','A') if p['ability']=='crouch'])
        self.assertEqual(r['final_states']['A']['owned_actions'],[])
        self.assertEqual(D(r['final_states']['A']['dyspnea']),100)

    def test_released_projectile_survives_owned_action_death_cleanup(self):
        s=scenario(1000,fire_at=0,target=(200,-20));command(s,'A',450,'jump')
        s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=200
        r=run(s)
        death=events(r,'character_died','A')[0]
        later=[e for e in events(r,'projectile_body_collision','A') if D(e['time_ms'])>D(death['time_ms'])]
        self.assertTrue(later)
        released={e['projectile_id']:D(e['time_ms']) for e in events(r,'projectile_released','A')}
        self.assertTrue(all(released[e['projectile_id']]<D(death['time_ms']) for e in later))

    def test_cli_owned_action_prefix_is_independent_of_a_future_jump(self):
        root=Path(__file__).resolve().parents[1];prefixes=[]
        with tempfile.TemporaryDirectory(prefix='owned-prefix-') as directory:
            for future in (False,True):
                s=scenario(1600,target=(4,'-19.5'));s['encounter']['participants']['A']['movement_direction']=[1,'.2']
                command(s,'A',0,'run');command(s,'B',0,'crouch')
                if future:command(s,'B',1500,'jump')
                path=Path(directory)/(str(future)+'.json');path.write_text(json.dumps(s))
                r=json.loads(subprocess.check_output([sys.executable,'-B','-m','combat_sim','run',str(path)],cwd=root,text=True,timeout=20))
                prefixes.append([p for p in r['curve'] if D(p['time_ms'])<=1000])
        self.assertEqual(prefixes[0],prefixes[1])

    def test_owned_costs_keep_the_existing_payment_anchor_validation(self):
        s=scenario(250,fire_at=0)
        profiles=deepcopy(PROFILES)
        profiles['1E2']['abilities']['1']['dyspnea']['capacity_check_timing']='active_start'
        with self.assertRaisesRegex(UnsupportedMechanicError,'Separate capacity-check'):
            SharedEncounter(s,profiles,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
                projectile_physics_definition=PHYSICS,jump_definition=JUMP,climb_definition=CLIMB).run()

    def test_stand_is_not_a_noop_while_crouch_is_still_gathering(self):
        s=scenario(550);s['encounter']['participants']['A']['initial_state']['disorientation']=200
        command(s,'A',0,'crouch');command(s,'A',50,'stand')
        r=run(s)
        self.assertEqual(r['metrics']['A']['crouches_completed'],1)
        self.assertEqual(r['metrics']['A']['stands_completed'],1)
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'standing')
        self.assertFalse(events(r,'posture_command_no_change','A'))

    def test_sprint_request_waits_for_an_in_progress_exit_instead_of_disappearing(self):
        s=scenario(1100)
        for time,action in ((0,'sprint'),(600,'run'),(650,'sprint')):command(s,'A',time,action)
        r=run(s)
        entries=[e for e in events(r,'movement_active_started','A') if e['action']=='sprint']
        self.assertEqual([D(e['time_ms']) for e in entries],[210,800])
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'sprinting')

    def test_stop_waits_for_climb_instead_of_changing_its_active_mode(self):
        s=scenario(650);s['encounter']['participants']['A']['position_m']=['4.6',0]
        s['movement_script'].append({'actor':'A','at_ms':0,'action':'climb','target':'cube_1'})
        command(s,'A',200,'stop')
        r=run(s)
        during=next(p['states']['A'] for p in r['curve'] if D(p['time_ms'])==300)
        self.assertEqual(during['locomotion']['mode'],'climbing')
        noops=[e for e in events(r,'movement_command_no_change','A') if e['action']=='stop']
        self.assertEqual([D(e['time_ms']) for e in noops],[450])
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)

    def test_action_cannot_be_acquired_or_bound_by_a_different_actor(self):
        engine=SharedEncounter(scenario(200),PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
            movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,
            projectile_physics_definition=PHYSICS,jump_definition=JUMP,climb_definition=CLIMB)
        actor=engine.fighters['A']
        foreign=BattleAction(999,'B','A','1','slash_projectile',D(0),D(0),D(40))
        with self.assertRaisesRegex(ValueError,'different actor'):
            actor.current=foreign
        with self.assertRaisesRegex(ValueError,'another actor'):
            with actor.using_action(foreign):pass
        self.assertEqual(actor.live_actions(),())
        self.assertEqual(actor.action_registry.reserved(),0)
