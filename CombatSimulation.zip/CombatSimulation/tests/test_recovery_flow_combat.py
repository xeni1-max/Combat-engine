"""Current-world recovery consumes analytic flow plans from actual combat losses.

These retain the independent recovery prerequisite checks; simultaneous incoming
heat/regeneration is covered by the separate coupling interaction tests.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from tests.test_mobile_combat import BODY,MOVEMENT,PROFILES,TERRAIN,events,scenario
from tests.test_spatial_heat_combat import beam_scene
from tests.test_world_colliders_combat import CURRENT,run
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB


def heat_history_scene():
    s=beam_scene(35000)
    s['encounter']['participants']['A']['initial_state']['hp']=1
    s['encounter']['participants']['B']['initial_state']['shield']=4000
    s['action_selection']['B']['start_ms']=500
    return s


class RecoveryFlowCombatTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=60));context.__enter__()
        self.addCleanup(context.__exit__,None,None,None)

    def test_real_heat_history_recovers_without_reviving_its_caster(self):
        r=run(heat_history_scene())
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertEqual(D(r['final_states']['B']['hp']),8140)
        self.assertAlmostEqual(D(r['final_states']['B']['shield']),4000,places=22)
        self.assertAlmostEqual(D(r['shield_regenerated_total']),4000,places=22)
        self.assertTrue(all('recovery_flow' in e for e in events(r,'shield_regenerated')))
        first=events(r,'shield_regenerated')[0]['recovery_flow']
        positive=[p for p in first['pieces'] if D(p['curve']['constant_per_second']) or p['curve']['terms']]
        self.assertGreaterEqual(D(positive[0]['begin_ms']),20292)
        self.assertTrue(any(p['curve']['terms'] for p in positive))
        self.assertTrue(any(D(p['curve']['constant_per_second'])==400 for p in positive))

    def test_real_gun_losses_recover_through_shared_capacity(self):
        s=scenario(35000,fire_at=0)
        s['action_selection']['A']['reload_when_empty']=False
        s['encounter']['participants']['B']['initial_state']['shield']=4000
        r=run(s)
        self.assertEqual(r['metrics']['A']['projectiles_released'],11)
        self.assertLess(D(r['final_states']['B']['hp']),8140)
        self.assertAlmostEqual(D(r['final_states']['B']['shield']),4000,places=22)
        self.assertTrue(events(r,'shield_regenerated'))
        for event in events(r,'shield_regenerated'):
            self.assertAlmostEqual(D(event['amount']),D(event['recovery_flow']['total']),places=30)

    def test_live_history_preview_does_not_mutate_world_or_resources(self):
        class PreviewFixture(SharedEncounter):
            def __init__(self,*args,**kwargs):
                super().__init__(*args,**kwargs);self.push(1000,'preview_recovery',{})
            def _process(self,kind,payload):
                if kind!='preview_recovery':return super()._process(kind,payload)
                before=self.states();recovery=self.shield_recovery['B'];work=recovery.recovered
                p=recovery.plan(self.time,D(35000))
                if self.states()!=before or recovery.recovered!=work:raise AssertionError('Preview mutated combat')
                self.log('recovery_preview',target='B',plan=p.record())
        s=beam_scene(1000);s['encounter']['participants']['B']['initial_state']['shield']=4000
        with localcontext(Context(prec=50)):
            r=PreviewFixture(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,combat_locomotion_definition=CURRENT,sample_interval_ms=None,
                jump_definition=JUMP,climb_definition=CLIMB).run()
        control=run(s)
        self.assertEqual(r['final_states'],control['final_states'])
        self.assertEqual(r['metrics'],control['metrics'])
        preview=events(r,'recovery_preview')[0]['plan']
        lost=4000-D(r['final_states']['B']['shield'])
        self.assertAlmostEqual(D(preview['total']),lost,places=22)

    def test_precision_and_observations_preserve_actual_recovery(self):
        s=heat_history_scene();baseline=run(s)
        for precision,interval in ((50,113),(80,37)):
            with self.subTest(precision=precision,interval=interval):
                r=run(s,precision=precision,interval=interval)
                self.assertAlmostEqual(D(r['final_states']['B']['shield']),D(baseline['final_states']['B']['shield']),places=21)
                self.assertAlmostEqual(D(r['shield_regenerated_total']),D(baseline['shield_regenerated_total']),places=21)
                self.assertEqual(r['final_states']['B']['hp'],baseline['final_states']['B']['hp'])

    def test_explicit_historical_service_model_retains_same_intended_math(self):
        legacy=deepcopy(CURRENT);legacy.pop('shield_recovery');legacy.pop('heat_shield_coupling')
        for mode in ('binding_effects','grapple_break','grapple_casts','controlled_damage','continuous_effort'):legacy.pop(mode,None)
        s=heat_history_scene();current=run(s);previous=run(s,effects=legacy)
        for actor in ('A','B'):
            for key in ('hp','shield','armor','dyspnea'):
                self.assertAlmostEqual(D(current['final_states'][actor][key]),D(previous['final_states'][actor][key]),places=21)
        self.assertTrue(all('recovery_flow' not in e for e in events(previous,'shield_regenerated')))

    def test_unknown_flow_model_rejects_before_any_action(self):
        definition=deepcopy(CURRENT);definition['shield_recovery']={'mode':'unknown'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'Analytic shield recovery flow'):
            run(beam_scene(),effects=definition)


if __name__=='__main__':unittest.main()
