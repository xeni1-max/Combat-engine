"""Persistent distance API on real bodies, controls, forces and shared queries.
These numerical/phase contracts select the pre-equilibrium rules explicitly.
Current selected-rule interactions are covered in test_equilibrium_interactions.
"""
from decimal import Context,Decimal as D,localcontext
import unittest
import json

from tests.test_binding_combat import run,read,scene as binding_scene
from tests.test_saved_body_paths_combat import scene
from tests.test_grapple_links_combat import force,pos,vel
from tests.test_mobile_combat import events,command
from copy import deepcopy
from math import sin,cos
from fractions import Fraction as F
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.mechanics.exact_ratio import read_ratio
from tests.test_knock_motion_combat import scene as heavy_scene
from tests.test_world_colliders_combat import wall
from tests.test_climb_combat import climb
from tests.test_spatial_heat_combat import beam_scene
from tests.test_cooldown_fields_combat import marking_scene
from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE


def rules(step=5):
    cfg=read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json')
    cfg['distance_constraints']={'mode':'persistent_distance_v1','maximum_step_ms':step,'position_inset_m':'1e-30',
        'maximum_relative_step_fraction':'0.001'}
    return cfg


def attach(w,*,length=30,expires=1000,first='A',second='B'):
    return w.distance_constraints.attach(first,second,maximum_m=length,expires_at_ms=expires,
        source='engineering:distance_probe',expected_lives={n:w.fighters[n].life_generation for n in (first,second)})


class PersistentDistanceCombatTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=60));context.__enter__();self.addCleanup(context.__exit__,None,None,None)

    def radial(self,*,interval=None,expires=1000):
        s=scene(300);s['spatial_interventions']=[force(0,'A',[-2,0,0])]
        return run(s,rules=rules(),interval=interval,operations=((0,lambda w:attach(w,expires=expires)),))

    def test_live_radial_constraint_transfers_inertia_without_repeated_weight_division(self):
        r=self.radial()
        self.assertLess(abs(vel(r,'A')[0]-vel(r,'B')[0]),D('1e-20'))
        self.assertLess(vel(r,'B')[0],D('-.5'))
        self.assertLess(abs(pos(r,'B')[0]-30-pos(r,'A')[0]),D('1e-20'))
        self.assertGreater(r['distance_path_steps_planned'],0)
        self.assertEqual(r['distance_constraints'][0]['status'],'active')
        self.assertTrue(events(r,'distance_response_started'))
        plan=r['last_committed_distance_plan'];self.assertIsNotNone(plan);json.dumps(r)
        pieces={n:BodyPathPiece.from_record(p) for n,p in plan['pieces'].items()}
        for row in plan['bernstein_certificate']:
            self.assertTrue(all(read_ratio(c)<=0 for c in row['distance_squared_minus_limit_squared']))
            a,b=pieces[row['first']],pieces[row['second']];limit=read_ratio(row['maximum_m'])
            for i in range(9):
                t=a.begin_ms+(a.end_ms-a.begin_ms)*F(i,8)
                self.assertLessEqual(sum((y-x)**2 for x,y in zip(a.position(t),b.position(t))),limit*limit)

    def test_expiry_preserves_transmitted_momentum(self):
        r=self.radial(expires=150)
        self.assertEqual(r['distance_constraints'][0]['end_reason'],'expired')
        self.assertLess(vel(r,'B')[0],D('-.5'))
        self.assertLess(abs(vel(r,'A')[0]-vel(r,'B')[0]),D('1e-20'))

    def test_observations_do_not_create_physics_knots_or_change_motion(self):
        a=self.radial();b=self.radial(interval=17)
        self.assertEqual(a['distance_path_steps_planned'],b['distance_path_steps_planned'])
        for n in 'AB':
            self.assertTrue(all(abs(x-y)<D('1e-20') for x,y in zip(pos(a,n),pos(b,n))))
            self.assertTrue(all(abs(x-y)<D('1e-20') for x,y in zip(vel(a,n),vel(b,n))))

    def test_slack_does_not_pull_before_actual_outward_crossing(self):
        s=scene(250);s['spatial_interventions']=[force(0,'A',[-2,0,0])]
        def before(w):
            self.assertEqual(w.fighters['B'].position_m[0],30)
            self.assertEqual(w.mobile_motion('B')[0],(0,0,0))
            self.assertEqual(w.distance_constraints.planned_steps,0)
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,length='30.2')),(50,before)))
        self.assertLess(pos(r,'B')[0],30);self.assertTrue(r['distance_path_steps_planned'])

    def test_invalid_attachment_cannot_partially_mutate_world(self):
        def probe(w):
            before=len(w.queue)
            with self.assertRaises(ValueError):attach(w,length=1)
            self.assertFalse(w.distance_constraints.rows);self.assertEqual(len(w.queue),before)
        run(scene(10),rules=rules(),operations=((0,probe),))

    def curved(self,*,step=5,interval=None,precision=50):
        s=scene(500);s['encounter']['participants']['B']['character']='1E2'
        s['spatial_interventions']=[force(0,'B',[0,4,0])]
        return run(s,rules=rules(step),interval=interval,precision=precision,operations=((0,lambda w:attach(w)),))

    def test_curved_tangent_motion_stays_bounded_and_keeps_shared_query_coefficients(self):
        r=self.curved(interval=17)
        self.assertGreater(pos(r,'B')[1],D('-18.1'))
        for sample in r['curve']:
            states=sample['states']
            a=tuple(map(D,states['A']['body_origin_m']));b=tuple(map(D,states['B']['body_origin_m']))
            self.assertLessEqual(sum((y-x)**2 for x,y in zip(a,b)),900+D('1e-18'))
        self.assertLess(vel(r,'B')[0],0);self.assertGreater(vel(r,'A')[0],0)

    def test_curved_observation_and_precision_controls_agree(self):
        a=self.curved();b=self.curved(interval=17,precision=80)
        self.assertEqual(a['distance_path_steps_planned'],b['distance_path_steps_planned'])
        for name in 'AB':
            self.assertTrue(all(abs(x-y)<D('1e-12') for x,y in zip(pos(a,name),pos(b,name))))
            self.assertTrue(all(abs(x-y)<D('1e-10') for x,y in zip(vel(a,name),vel(b,name))))

    def test_inertial_curve_converges_under_step_refinement(self):
        errors=[]
        expected=(15-15*cos(2/30),-19-15*sin(2/30),15+15*cos(2/30),-19+15*sin(2/30))
        for step in (5,'2.5','1.25'):
            r=self.curved(step=step)
            actual=(*pos(r,'A')[:2],*pos(r,'B')[:2])
            errors.append(sum((float(a)-b)**2 for a,b in zip(actual,expected))**.5)
        self.assertLess(errors[1],errors[0]*.7);self.assertLess(errors[2],errors[1]*.7)
        self.assertLess(errors[0],.002)

    def heavy(self,*,tangent=False,duration=1000,operations=()):
        s=heavy_scene(duration)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=(['1.1',10] if tangent else ['-28.9',-20])
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        return run(s,rules=rules(),operations=((0,lambda w:attach(w,first='B',second='C',expires=2000)),)+operations)

    def test_real_heavy_punch_transmits_its_component_and_expires_once(self):
        r=self.heavy();row=r['knock_impulses'][0]
        self.assertEqual({c['actor'] for c in row['retired_components']},{'B','C'})
        self.assertEqual(row['end_reason'],'duration_expired')
        self.assertTrue(all(abs(v)<D('1e-18') for n in 'BC' for v in vel(r,n)))
        self.assertLess(abs(pos(r,'B')[0]-D('1.1')-pos(r,'C')[0]-D('28.9')),D('1e-18'))

    def test_curved_real_knock_expiry_leaves_no_large_phantom_velocity(self):
        r=self.heavy(tangent=True);self.assertEqual(r['knock_impulses'][0]['end_reason'],'duration_expired')
        self.assertEqual({c['actor'] for c in r['knock_impulses'][0]['retired_components']},{'B','C'})
        self.assertLess(max(sum(v*v for v in vel(r,n)).sqrt() for n in 'BC'),D('.01'))

    def test_ground_air_tension_uses_real_floor_contacts_and_landing(self):
        s=scene(1800);s['spatial_interventions']=[force(0,'B',[0,0,4],reference=[30,-20,5])]
        r=run(s,rules=rules(),interval=37,operations=((0,lambda w:attach(w,length='30.3',expires=2500)),))
        self.assertGreater(r['distance_path_steps_planned'],0)
        self.assertTrue(all(r['final_states'][n]['locomotion']['grounded'] for n in 'AB'))
        self.assertTrue(events(r,'jump_landed'))
        for sample in r['curve']:
            a,b=(tuple(map(D,sample['states'][n]['body_origin_m'])) for n in 'AB')
            self.assertGreaterEqual(min(a[2],b[2]),D('.875')-D('1e-20'))
            self.assertLessEqual(sum((y-x)**2 for x,y in zip(a,b)),D('30.3')**2+D('1e-18'))

    def test_real_gunfire_uses_moving_constrained_body_queries(self):
        s=scene(700);s['action_selection']['A']['start_ms']=0
        s['spatial_interventions']=[force(0,'B',[0,4,0])]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        self.assertGreater(r['distance_path_steps_planned'],0)
        self.assertTrue(events(r,'projectile_released'));self.assertTrue(events(r,'impact_batch_resolved'))
        self.assertGreater(D(r['metrics']['A']['hits_resolved']),0)

    def test_death_retires_the_constraint_and_revival_inherits_none(self):
        s=scene(400);s['spatial_interventions']=[force(0,'A',[-2,0,0])]
        def kill(w):w.fighters['A'].hp=D(0);w.finish_team_deaths()
        def revive(w):self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='engineering:distance_life'))
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),(100,kill),(200,revive)))
        self.assertEqual(r['distance_constraints'][0]['end_reason'],'endpoint_life_ended')
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertFalse(r['final_states']['A']['locomotion'].get('motion_driver')=='transmitted_inertia')

    def test_external_relocation_past_length_releases_without_snapping_partner(self):
        s=scene(300);s['spatial_interventions']=[force(100,'A',reference=[-10,-20,'.875'])]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        self.assertEqual(r['distance_constraints'][0]['end_reason'],'external_separation')
        self.assertEqual(pos(r,'B')[0],30)

    def test_wall_stops_the_taut_pair_but_only_actual_contact_gets_statuses(self):
        s=scene(800);s['spatial_interventions']=[force(0,'A',[-2,0,0])]
        s['initial_colliders']=[wall('follower_wall',x='29.4',size=('.2',4,4),hp=None)]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        collisions=[e for e in events(r,'body_contact') if e['second']=='follower_wall']
        self.assertTrue(collisions);self.assertEqual({e['first'] for e in collisions},{'B'})
        self.assertEqual(D(r['metrics']['A']['collision_stops']),0)
        self.assertGreater(D(r['metrics']['B']['collision_stops']),0)
        self.assertTrue(all(abs(v)<D('1e-18') for n in 'AB' for v in vel(r,n)))

    def test_wall_contact_can_leave_the_chain_slack_instead_of_rigidly_stopping_both(self):
        s=scene(800);s['spatial_interventions']=[force(0,'A',[-2,0,0])]
        s['initial_colliders']=[wall('leader_wall',x='-.6',size=('.2',4,4),hp=None)]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        self.assertLess(abs(vel(r,'A')[0]),D('1e-18'));self.assertLess(vel(r,'B')[0],D('-.5'))
        self.assertLess(pos(r,'B')[0]-pos(r,'A')[0],30)
        self.assertEqual(D(r['metrics']['B']['collision_stops']),0)

    def test_contact_resolved_while_slack_is_retained_when_tension_first_activates(self):
        s=scene(800)
        s['spatial_interventions']=[force(0,'B',[-2,0,0]),force(200,'A',[-4,0,0])]
        s['initial_colliders']=[wall('slack_wall',x='29.4',size=('.2',4,4),hp=None)]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        contacts=[e for e in events(r,'body_contact') if e['second']=='slack_wall']
        self.assertEqual(len(contacts),1)
        self.assertEqual(D(r['metrics']['B']['collision_stops']),1)
        self.assertEqual(D(r['metrics']['A']['collision_stops']),0)
        self.assertTrue(all(abs(v)<D('1e-18') for n in 'AB' for v in vel(r,n)))

    def test_body_contact_joins_the_joint_response_without_extra_collision_recipients(self):
        s=scene(1100);s['spatial_interventions']=[force(0,'A',[-2,0,0])]
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=['28.9',-20]
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,expires=2000)),))
        self.assertTrue([e for e in events(r,'body_contact') if {e['first'],e['second']}=={'B','C'}])
        self.assertEqual(D(r['metrics']['A']['collision_stops']),0)
        self.assertTrue(all(D(r['metrics'][n]['collision_stops'])>0 for n in 'BC'))
        self.assertLess(vel(r,'C')[0],0)
        self.assertLess(max(vel(r,n)[0] for n in 'ABC')-min(vel(r,n)[0] for n in 'ABC'),D('1e-18'))

    def test_inward_motion_does_not_drag_the_other_endpoint(self):
        s=scene(300);s['spatial_interventions']=[force(0,'A',[2,0,0])]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        self.assertEqual(vel(r,'A'),(2,0,0));self.assertEqual(vel(r,'B'),(0,0,0))
        self.assertEqual(r['distance_path_steps_planned'],0)

    def test_ground_drives_remain_independent_and_resume_after_expiry(self):
        s=scene(500);s['encounter']['participants']['A']['movement_direction']=[-1,0]
        s['encounter']['participants']['B']['movement_direction']=[1,0]
        command(s,'A',0,'run');command(s,'B',0,'run')
        def before(w):self.assertTrue(all(abs(w.mobile_motion(n)[0][0])<D('1e-18') for n in 'AB'))
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,expires=300)),(250,before)))
        self.assertEqual(vel(r,'A')[0],D('-6.4'));self.assertEqual(vel(r,'B')[0],D('6.4'))
        self.assertTrue(all(r['final_states'][n]['locomotion']['mode']=='running' for n in 'AB'))

    def test_crouch_changes_pose_without_consuming_reference_distance(self):
        s=scene(300);command(s,'A',0,'crouch')
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        self.assertEqual(pos(r,'A')[2],D('.675'));self.assertEqual(pos(r,'B')[2],D('.875'))
        self.assertEqual((pos(r,'A')[0],pos(r,'B')[0]),(0,30));self.assertEqual(r['distance_path_steps_planned'],0)

    def test_unrelated_taut_pair_cannot_interrupt_a_compatible_climb(self):
        s=scene(500);s['encounter']['participants']['A']['position_m']=['4.6',0];climb(s)
        for name,x in (('C',-20),('D',10)):
            s['encounter']['participants'][name]=deepcopy(s['encounter']['participants']['B'])
            s['encounter']['participants'][name]['position_m']=[x,-40]
            s['action_selection'][name]=deepcopy(s['action_selection']['B'])
        s['spatial_interventions']=[force(0,'D',[0,4,0])]
        def links(w):
            attach(w,length=100);attach(w,first='C',second='D')
        r=run(s,rules=rules(),operations=((0,links),))
        self.assertEqual(len([e for e in events(r,'climb_completed') if e['actor']=='A']),1)
        self.assertEqual(pos(r,'A'),(6,0,D('2.675')))

    def test_tether_preempts_incompatible_climb_before_displacement_and_preserves_motion(self):
        s=scene(500);s['encounter']['participants']['A']['position_m']=['4.6',0]
        s['encounter']['participants']['B']['position_m']=['4.6',-30];climb(s)
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        redirect=events(r,'climb_constraint_redirected');self.assertTrue(redirect)
        self.assertFalse(events(r,'climb_attachment_lost'));self.assertFalse(events(r,'climb_completed'))
        self.assertEqual(tuple(map(D,redirect[0]['reference_m'])),(D('4.6'),D(0),D('.875')))
        self.assertEqual(pos(r,'A')[0],D('4.6'))
        self.assertGreater(vel(r,'A')[2],0)

    def test_transmitted_ground_inertia_can_use_the_actual_special_stop(self):
        s=scene(300);s['spatial_interventions']=[force(0,'A',[-2,0,0])];command(s,'B',150,'stop')
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,expires=100)),))
        stopped=[e for e in events(r,'special_stop_started') if e['actor']=='B']
        self.assertEqual(len(stopped),1);self.assertEqual(D(stopped[0]['original_speed_mps']),1)
        self.assertEqual(vel(r,'B'),(0,0,0))

    def test_a_slack_neighbour_is_activated_on_the_coupled_path(self):
        s=scene(250);s['spatial_interventions']=[force(0,'A',[-3,0,0])]
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=['60.2',-20]
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        def links(w):attach(w);attach(w,first='B',second='C',length='30.3')
        def before(w):
            self.assertLess(abs(w.fighters['C'].position_m[0]-D('60.2')),D('1e-20'))
            self.assertTrue(all(abs(v)<D('1e-20') for v in w.mobile_motion('C')[0]))
        r=run(s,rules=rules(),operations=((0,links),(50,before)))
        self.assertTrue(all(abs(vel(r,n)[0]+1)<D('1e-18') for n in 'ABC'))
        self.assertLess(pos(r,'C')[0],D('60.2'))

    def test_duplicate_independent_distances_do_not_duplicate_motion(self):
        s=scene(300);s['spatial_interventions']=[force(0,'A',[-2,0,0])]
        def links(w):attach(w,expires=100);attach(w,expires=200)
        r=run(s,rules=rules(),operations=((0,links),))
        self.assertEqual(len(r['distance_constraints']),2)
        self.assertTrue(all(row['end_reason']=='expired' for row in r['distance_constraints']))
        self.assertEqual(vel(r,'A')[0],-1);self.assertEqual(vel(r,'B')[0],-1)

    def test_real_hold_keeps_grapple_resistance_and_joins_distance_sharing_once(self):
        s=heavy_scene(1000)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(character='1E5',position_m=['2.2',-20],facing='-x')
        s['action_selection']['C']=dict(s['action_selection']['A'],abilities=['2'])
        s['encounter']['participants']['D']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['D']['position_m']=['-28.9',-20]
        s['action_selection']['D']=deepcopy(s['action_selection']['B'])
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,first='B',second='D',expires=2000)),))
        knock=r['knock_impulses'][0]
        self.assertEqual(knock['assessment']['actors'],['B','C'])
        self.assertEqual(D(knock['assessment']['maximum_hp_sum']),29080)
        self.assertEqual({c['actor'] for c in knock['retired_components']},{'B','C','D'})
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertTrue(all(abs(v)<D('1e-18') for n in 'BCD' for v in vel(r,n)))

    def test_actual_beam_exposure_leaves_on_the_constrained_path(self):
        s=beam_scene(1500);s['scope']=dict(GRAVITY_MOBILE_SCOPE)
        s['action_selection']['B']['start_ms']=100000;s['spatial_interventions']=[force(0,'B',[0,10,0])]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,expires=2000)),))
        deployed=events(r,'beam_deployed')[0];left=[e for e in events(r,'heat_exposure_left') if e['target']=='B']
        self.assertTrue(left);self.assertTrue(D(deployed['time_ms'])<D(left[0]['time_ms'])<1500)
        self.assertTrue(r['volume_instances'][0]['active']);self.assertEqual(r['volume_instances'][0]['eligible_targets'],[])
        self.assertGreater(D(r['metrics']['B']['continuous_hp_damage_received']),0)

    def test_actual_pause_field_exits_and_resumes_work_on_the_constrained_path(self):
        s=marking_scene(1400);s['spatial_interventions']=[force(0,'B',[0,10,0])]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,expires=2000)),))
        left=[e for e in events(r,'cooldown_pause_left') if e['target']=='B']
        self.assertTrue(left);self.assertLess(D(left[0]['time_ms']),1400)
        self.assertTrue(any(D(e['time_ms'])>D(left[0]['time_ms']) for e in events(r,'projectile_released') if e['actor']=='B'))
        self.assertEqual(r['final_states']['B']['cooldown_clocks']['1']['pause_sources'],[])

    def test_actual_upper_freeze_does_not_cancel_independent_distance_motion(self):
        s=binding_scene(4000,breaking=False);s['spatial_interventions']=[force(0,'B',[0,1,0])]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,length=10,expires=5000)),))
        self.assertEqual(r['binding_instances'][0]['kind'],'upper_body')
        self.assertIsNone(r['binding_instances'][0].get('ended_at_ms'))
        self.assertEqual(r['distance_constraints'][0]['status'],'active')
        self.assertGreater(sum(v*v for v in vel(r,'B')).sqrt(),D('.1'))

    def test_actual_moving_block_uses_the_shared_path_and_intercepts_gunfire(self):
        s=scene(700);s['encounter']['participants']['B']['character']='2E4'
        s['action_selection']['A']['start_ms']=0
        s['action_selection']['B'].update(abilities=['basic_8'],held_blocks=['basic_8'],start_ms=0)
        s['spatial_interventions']=[force(0,'B',[0,4,0])]
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w)),))
        self.assertGreater(r['distance_path_steps_planned'],0)
        self.assertTrue(events(r,'block_layer_summoned'))
        self.assertGreater(sum(D(e['absorbed']) for e in events(r,'block_layer_damage')),0)

    def test_quiescent_imposed_metadata_does_not_change_ground_resistance(self):
        s=scene(300);s['encounter']['participants']['B']['movement_direction']=[1,0];command(s,'B',0,'run')
        def setup(w):
            w.motion['A']['imposed_velocity']=(D(0),)*3
            attach(w)
        r=run(s,rules=rules(),operations=((0,setup),))
        self.assertLess(abs(vel(r,'A')[0]-D('3.2')),D('1e-18'))
        self.assertLess(abs(vel(r,'B')[0]-D('3.2')),D('1e-18'))
        self.assertTrue(all(abs(D(r['final_states'][n]['locomotion']['speed_mps'])-D('3.2'))<D('1e-18') for n in 'AB'))

    def test_jump_retains_transmitted_horizontal_inertia_after_landing(self):
        s=scene(1100);s['spatial_interventions']=[force(0,'A',[-2,0,0])];command(s,'B',150,'jump')
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,expires=100)),))
        self.assertEqual(len([e for e in events(r,'jump_landed') if e['actor']=='B']),1)
        self.assertTrue(r['final_states']['B']['locomotion']['grounded'])
        self.assertLess(abs(vel(r,'B')[0]+1),D('1e-18'))

    def test_redirected_actual_dash_keeps_its_paid_landing_effects(self):
        s=scene(1400);s['encounter']['participants']['A']['character']='2E4'
        s['action_selection']['A'].update(abilities=['3'],start_ms=0)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=[-30,-20]
        s['encounter']['participants']['C']['team']='A';s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s,rules=rules(),operations=((0,lambda w:attach(w,first='A',second='C',expires=2000)),))
        self.assertTrue(events(r,'distance_ground_drive_retired'))
        self.assertEqual(len([e for e in events(r,'body_launch_landed') if e['actor']=='A']),1)
        self.assertGreater(D(r['metrics']['A']['dyspnea_paid']),0)


if __name__=='__main__':unittest.main()
