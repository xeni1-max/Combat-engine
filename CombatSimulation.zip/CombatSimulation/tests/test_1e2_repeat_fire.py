"""Shielded slash delivery, individual bleeds, finite fire decisions and weapon resources."""
from copy import deepcopy
from decimal import Decimal,localcontext,ROUND_FLOOR,ROUND_CEILING
from fractions import Fraction
import json
from pathlib import Path
import unittest

from combat_sim.actions import RepeatFirePolicy
from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario
from combat_sim.mechanics import slash
from combat_sim.models import UnsupportedMechanicError

ROOT=Path(__file__).resolve().parents[1]
CHARACTERS=json.loads((ROOT/'data/characters.json').read_text())['characters']
BASE=json.loads((ROOT/'scenarios/1e2_slash_projectile.json').read_text())


def scenario(count=1,shield=0,ammo=11):
    s=deepcopy(BASE)
    s['encounter']['initial_states']['2E4']['shield']=shield
    s['encounter']['weapon_initial_state']={'ammo':ammo}
    if count!=1:
        s['action_sequence'][0].update(kind='repeat_fire',shot_count=count,reload_when_empty=True)
    return s


def events(run,kind): return [e for e in run['events'] if e['type']==kind]


class RepeatedGunfireTests(unittest.TestCase):
    def test_fully_shielded_hit_creates_no_bleed_or_armor_loss(self):
        run=run_scenario(scenario(shield=4000),CHARACTERS); summary=summarize(run)
        self.assertEqual(summary['shield_damage']['exact'],'412')
        self.assertEqual(summary['hp_damage']['exact'],'0')
        self.assertEqual(summary['armor_lost']['exact'],'0')
        self.assertEqual(summary['final_shield']['exact'],'3588')
        self.assertEqual(events(run,'bleeding_started'),[])
        self.assertEqual(events(run,'continuous_damage_resolved'),[])
        self.assertEqual(summary['damage_by_effect']['bleeding']['exact'],'0')
        self.assertEqual(len(events(run,'status_applied')),4) # Target effects still pass shields.
        self.assertEqual(run['final_weapon_state']['ammo'],10)

    def test_exact_shield_depletion_creates_no_bleed(self):
        run=run_scenario(scenario(shield=412),CHARACTERS)
        self.assertEqual(summarize(run)['final_shield']['exact'],'0')
        self.assertEqual(summarize(run)['hp_damage']['exact'],'0')
        self.assertEqual(events(run,'bleeding_started'),[])

    def test_user_example_100_damage_against_50_shield(self):
        characters=deepcopy(CHARACTERS); a=characters['1E2']['abilities']['1']
        a['pre_mitigation_damage']=100; a['range_falloff']['damage_loss']=0
        s=scenario(shield=50); s['encounter']['initial_states']['2E4']['armor']=0
        run=run_scenario(s,characters); hit=events(run,'impact_resolved')[0]
        self.assertEqual(hit['damage_calculation']['shield_handling']['damage_to_shield']['exact'],'50')
        self.assertEqual(hit['damage_calculation']['formula_inputs']['d_left_after_shield'],'50')
        self.assertEqual(hit['damage_calculation']['outputs']['y']['exact'],'50')
        self.assertEqual(summarize(run)['damage_by_effect']['bleeding']['exact'],'5')
        self.assertEqual(summarize(run)['hp_damage']['exact'],'55')

    def test_partial_overflow_uses_armor_and_piercing_only_after_shield(self):
        run=run_scenario(scenario(shield=50),CHARACTERS)
        expected=slash.calculate_impact(412,165,18,50)
        summary=summarize(run)
        self.assertEqual(Fraction(summary['direct_hp_damage']['exact']),expected.hp_damage)
        self.assertEqual(Fraction(summary['damage_by_effect']['bleeding']['exact']),expected.hp_damage/10)
        self.assertEqual(Fraction(summary['armor_lost']['exact']),expected.armor_loss)
        self.assertEqual(summary['shield_damage']['exact'],'50')

    def test_overflow_fully_mitigated_by_armor_creates_no_bleed(self):
        run=run_scenario(scenario(shield=400),CHARACTERS)
        self.assertEqual(summarize(run)['hp_damage']['exact'],'0')
        self.assertEqual(events(run,'bleeding_started'),[])
        self.assertEqual(events(run,'impact_resolved')[0]['damage_calculation']['formula_inputs']['d_left_after_shield'],'12')

    def test_two_shots_fire_when_ready(self):
        run=run_scenario(scenario(count=2),CHARACTERS)
        self.assertEqual([e['time_ms'] for e in events(run,'ability_started')],[0,400])
        self.assertEqual([e['time_ms'] for e in events(run,'projectile_released')],[40,440])
        self.assertEqual([e['time_ms'] for e in events(run,'impact_resolved')],[154,554])
        self.assertEqual(run['final_weapon_state']['ammo'],9)
        self.assertEqual(run['shots_released'],2)
        self.assertEqual(run['reload_count'],0)

    def test_successive_hits_recalculate_current_armor_and_freeze_each_bleed_basis(self):
        run=run_scenario(scenario(count=2),CHARACTERS)
        hits=events(run,'impact_resolved'); bleeds=events(run,'bleeding_started')
        first=slash.calculate_impact(412,165,18,0)
        second=slash.calculate_impact(412,165-first.armor_loss,18,0)
        self.assertEqual(Fraction(hits[1]['damage_calculation']['formula_inputs']['a_pre_impact']),165-first.armor_loss)
        self.assertEqual([Fraction(b['bleed_basis_y']['exact']) for b in bleeds],[first.hp_damage,second.hp_damage])
        self.assertEqual(Fraction(summarize(run)['damage_by_effect']['bleeding']['exact']),(first.hp_damage+second.hp_damage)/10)
        self.assertEqual([e['time_ms'] for e in events(run,'bleeding_expired')],[8154,8554])

    def test_overlapping_bleed_intervals_sum_independent_integrals(self):
        run=run_scenario(scenario(count=2),CHARACTERS)
        overlapping=[e for e in events(run,'continuous_damage_resolved') if len(e['components']['bleeding']['instances'])==2]
        self.assertTrue(overlapping)
        for e in overlapping:
            pieces=e['components']['bleeding']['instances']
            self.assertEqual(sum(Fraction(p['amount']['exact']) for p in pieces),Fraction(e['applied_hp_damage']['exact']))
            for piece in pieces:
                self.assertEqual(Fraction(piece['amount']['exact']),slash.bleeding_damage_between(Fraction(piece['y']),Fraction(piece['tb_start_seconds']),Fraction(piece['tb_end_seconds'])))

    def test_shield_breaking_shot_and_later_shot_have_different_delivery(self):
        run=run_scenario(scenario(count=3,shield=800),CHARACTERS)
        hits=events(run,'impact_resolved')
        self.assertEqual([h['damage_calculation']['shield_handling']['damage_to_shield']['exact'] for h in hits],['412','388','0'])
        self.assertEqual([h['damage_calculation']['shield_handling']['damage_left_after_shield']['exact'] for h in hits],['0','24','412'])
        self.assertEqual(len(events(run,'bleeding_started')),1)
        self.assertEqual(events(run,'bleeding_started')[0]['bleed_id'],3)

    def test_per_hit_regeneration_delays_remain_separate(self):
        run=run_scenario(scenario(count=2,shield=4000),CHARACTERS)
        cohorts=run['pending_shield_regeneration']
        self.assertEqual([p['loss_at_ms'] for p in cohorts],[154,554])
        self.assertEqual([p['eligible_at_ms'] for p in cohorts],[20154,20554])
        self.assertEqual([p['remaining']['exact'] for p in cohorts],['412','412'])

    def test_delayed_shared_regeneration_only_restores_actual_losses(self):
        s=scenario(count=2,shield=1000); s['run_until_ms']=23000
        run=run_scenario(s,CHARACTERS); summary=summarize(run)
        self.assertEqual(summary['shield_damage']['exact'],'824')
        self.assertEqual(summary['shield_regenerated_total']['exact'],'824')
        self.assertEqual(summary['final_shield']['exact'],'1000')
        self.assertEqual(run['pending_shield_regeneration'],[])
        self.assertTrue(all(Fraction(e['time_ms'] if isinstance(e['time_ms'],int) else e['time_ms']['exact'])>=20154 for e in events(run,'shield_regenerated')))

    def test_existing_hp_bleeding_continues_while_shield_regenerates(self):
        # Synthetic shorter delay isolates the confirmed interaction; game data remains 20 s.
        characters=deepcopy(CHARACTERS); characters['2E4']['shield_regeneration']['delay_ms']=1000
        s=scenario(shield=50); s['run_until_ms']=9000
        run=run_scenario(s,characters); summary=summarize(run)
        y=slash.calculate_impact(412,165,18,50).hp_damage
        self.assertEqual(Fraction(summary['damage_by_effect']['bleeding']['exact']),y/10)
        self.assertEqual(summary['final_shield']['exact'],'50')
        self.assertEqual(summary['shield_regenerated_total']['exact'],'50')
        self.assertTrue(any(Fraction(e['state_changes']['shield_before']['exact'])>0 for e in events(run,'continuous_damage_resolved')))

    def test_ammo_stops_fire_when_policy_declines_reload(self):
        s=scenario(count=3,ammo=2); s['action_sequence'][0]['reload_when_empty']=False
        run=run_scenario(s,CHARACTERS)
        self.assertEqual(run['shots_released'],2)
        self.assertEqual(run['final_weapon_state']['ammo'],0)
        self.assertEqual(run['reload_count'],0)
        self.assertFalse(run['final_weapon_state']['can_fire_weapon'])
        self.assertIn('empty',run['outcome'])

    def test_magazine_exhaustion_without_further_requested_shots_does_not_force_reload(self):
        run=run_scenario(scenario(count=11,shield=4000),CHARACTERS)
        self.assertEqual(run['shots_released'],11)
        self.assertEqual(run['final_weapon_state']['ammo'],0)
        self.assertEqual(run['reload_count'],0)
        self.assertEqual(len(events(run,'projectile_released')),11)
        self.assertEqual(len(events(run,'bleeding_started')),1)

    def test_repeated_shots_still_obey_current_disorientation(self):
        s=scenario(count=2); s['encounter']['initial_states']['1E2']['disorientation']=80
        run=run_scenario(s,CHARACTERS)
        self.assertEqual([e['time_ms'] for e in events(run,'projectile_released')],[120,520])
        self.assertEqual([e['time_ms'] for e in events(run,'impact_resolved')],[234,634])

    def test_extreme_armor_and_status_floors_remain_nonnegative(self):
        s=scenario(count=2); s['encounter']['initial_states']['2E4']['armor']=10000
        run=run_scenario(s,CHARACTERS); summary=summarize(run)
        self.assertEqual(summary['hp_damage']['exact'],'0')
        self.assertEqual(summary['armor_lost']['exact'],'0')
        self.assertEqual(events(run,'bleeding_started'),[])

    def test_repeat_replay_decimal_context_and_inputs_unchanged(self):
        s=scenario(count=3,shield=800); c=deepcopy(CHARACTERS); before=deepcopy(s)
        expected=run_scenario(s,c)
        for precision,rounding in ((8,ROUND_FLOOR),(60,ROUND_CEILING)):
            with localcontext() as ctx:
                ctx.prec,ctx.rounding=precision,rounding
                self.assertEqual(run_scenario(s,c),expected)
                self.assertEqual(summarize(run_scenario(s,c)),summarize(expected))
        self.assertEqual(s,before); self.assertEqual(c,CHARACTERS)
        times=[Fraction(e['time_ms']) if isinstance(e['time_ms'],int) else Fraction(e['time_ms']['exact']) for e in expected['events']]
        self.assertEqual(times,sorted(times))

    def test_invalid_weapon_policy_fields_and_values_rejected(self):
        for field,value in [('shot_count',0),('shot_count',True),('reload_when_empty','yes')]:
            s=scenario(count=2); s['action_sequence'][0][field]=value
            with self.subTest(field=field),self.assertRaises(ValueError): run_scenario(s,CHARACTERS)
        for ammo in (-1,12,True,'11'):
            s=scenario(); s['encounter']['weapon_initial_state']['ammo']=ammo
            with self.subTest(ammo=ammo),self.assertRaises(ValueError): run_scenario(s,CHARACTERS)

    def test_policy_is_separate_from_mechanics(self):
        policy=RepeatFirePolicy(3,reload_when_empty=True)
        self.assertEqual(policy.choose(0,11),'fire')
        self.assertEqual(policy.choose(2,0),'reload')
        self.assertIsNone(policy.choose(3,0))
        self.assertIsNone(RepeatFirePolicy(3,reload_when_empty=False).choose(2,0))

    def test_lethal_sequences_and_truncated_plans_rejected(self):
        s=scenario(count=3); s['encounter']['initial_states']['2E4']['hp']=500
        with self.assertRaisesRegex(UnsupportedMechanicError,'nonlethal'): run_scenario(s,CHARACTERS)
        s=scenario(count=2); s['run_until_ms']=8154
        with self.assertRaisesRegex(ValueError,'eight seconds'): run_scenario(s,CHARACTERS)

    def test_reload_rejects_a_missing_confirmed_gathering_rule(self):
        s=scenario(count=12,shield=4000)
        characters=deepcopy(CHARACTERS); characters['1E2']['abilities']['1'].pop('reload_gathering_rule',None)
        with self.assertRaisesRegex(UnsupportedMechanicError,'Reload Gathering'):
            run_scenario(s,characters)

    def test_twelve_shots_consume_magazine_reload_then_fire_again(self):
        run=run_scenario(scenario(count=12,shield=4000),CHARACTERS)
        self.assertEqual([e['time_ms'] for e in events(run,'projectile_released')],[40+400*i for i in range(11)]+[5995])
        self.assertEqual(run['shots_released'],12)
        self.assertEqual(run['reload_count'],1)
        self.assertEqual(run['final_weapon_state']['ammo'],10)
        self.assertEqual(run['final_weapon_state']['reload_phase'],'none')
        self.assertEqual(events(run,'reload_completed')[0]['ammo_before'],0)
        self.assertEqual(events(run,'reload_completed')[0]['ammo_after'],11)

    def test_reload_gathering_includes_current_disorientation(self):
        run=run_scenario(scenario(count=12,shield=4000),CHARACTERS)
        requested=events(run,'reload_requested')[0]
        self.assertEqual(requested['time_ms'],4040)
        self.assertEqual(requested['timing_calculation']['effective_gathering_ms'],115)
        self.assertEqual(requested['active_starts_at_ms'],4155)
        self.assertEqual(requested['active_ends_at_ms'],5955)
        self.assertEqual(events(run,'reload_active_started')[0]['time_ms'],4155)
        self.assertEqual(events(run,'reload_completed')[0]['time_ms'],5955)

    def test_reload_overlaps_automatic_weapon_cooldown(self):
        run=run_scenario(scenario(count=12,shield=4000),CHARACTERS)
        cooldowns=events(run,'weapon_cooldown_completed')
        self.assertEqual(cooldowns[10]['time_ms'],4400)
        self.assertEqual(cooldowns[10]['weapon_state']['reload_phase'],'active')
        self.assertFalse(cooldowns[10]['weapon_ready'])
        self.assertLess(events(run,'reload_active_started')[0]['time_ms'],4400)

    def test_first_reload_from_initially_empty_weapon(self):
        s=scenario(ammo=0); s['action_sequence'][0].update(kind='repeat_fire',shot_count=1,reload_when_empty=True)
        run=run_scenario(s,CHARACTERS)
        self.assertEqual(events(run,'reload_active_started')[0]['time_ms'],0)
        self.assertEqual(events(run,'reload_completed')[0]['time_ms'],1800)
        self.assertEqual(events(run,'projectile_released')[0]['time_ms'],1840)
        self.assertEqual(run['final_weapon_state']['ammo'],10)

    def test_initial_disorientation_applies_before_empty_reload_and_then_decays(self):
        s=scenario(ammo=0); s['action_sequence'][0].update(kind='repeat_fire',shot_count=1,reload_when_empty=True)
        s['encounter']['initial_states']['1E2']['disorientation']=80
        run=run_scenario(s,CHARACTERS)
        self.assertEqual(events(run,'reload_active_started')[0]['time_ms'],80)
        self.assertEqual(events(run,'reload_completed')[0]['time_ms'],1880)
        self.assertEqual(events(run,'projectile_released')[0]['time_ms'],1920)

    def test_cooldown_still_limits_next_shot_if_synthetic_reload_finishes_early(self):
        # Synthetic short Active checks the two independent gates; canonical reload is 1800 ms.
        characters=deepcopy(CHARACTERS); characters['1E2']['abilities']['1']['reload_active_ms']=100
        s=scenario(count=2,ammo=1)
        run=run_scenario(s,characters)
        self.assertEqual(events(run,'reload_completed')[0]['time_ms'],255) # request40 + O115 + Active100
        self.assertEqual([e['time_ms'] for e in events(run,'projectile_released')],[40,440])
        self.assertEqual(run['final_weapon_state']['ammo'],10)

    def test_multiple_magazines_and_overlapping_bleeds(self):
        s=scenario(count=23,shield=4000); s['encounter']['initial_states']['2E4']['armor']=0
        run=run_scenario(s,CHARACTERS)
        self.assertEqual(run['shots_released'],23)
        self.assertEqual(run['reload_count'],2)
        self.assertEqual(run['final_weapon_state']['ammo'],10)
        self.assertEqual([e['time_ms'] for e in events(run,'reload_requested')],[4040,9995])
        self.assertEqual([e['time_ms'] for e in events(run,'reload_completed')],[5955,11910])
        self.assertEqual(events(run,'projectile_released')[-1]['time_ms'],11950)
        self.assertEqual(run['active_continuous_effects_final'],[])
        self.assertGreater(Fraction(summarize(run)['final_hp']['exact']),0)

    def test_reload_and_repeated_fire_replay_are_context_independent(self):
        s=scenario(count=12,shield=4000); expected=run_scenario(s,CHARACTERS)
        for precision,rounding in ((8,ROUND_FLOOR),(60,ROUND_CEILING)):
            with localcontext() as ctx:
                ctx.prec,ctx.rounding=precision,rounding
                self.assertEqual(run_scenario(s,CHARACTERS),expected)

    def test_partial_reload_and_unknown_reload_mode_rejected(self):
        s=scenario(count=12,shield=4000); s['run_until_ms']=5000
        with self.assertRaisesRegex(ValueError,'reload'): run_scenario(s,CHARACTERS)
        characters=deepcopy(CHARACTERS); characters['1E2']['abilities']['1']['reload_gathering_rule']='unknown'
        with self.assertRaisesRegex(UnsupportedMechanicError,'Reload Gathering'): run_scenario(scenario(count=12,shield=4000),characters)

    def test_exploding_exact_armor_fractions_raise_a_clear_scope_error(self):
        with self.assertRaisesRegex(UnsupportedMechanicError,'arithmetic budget'):
            run_scenario(scenario(count=23,shield=4000),CHARACTERS)
