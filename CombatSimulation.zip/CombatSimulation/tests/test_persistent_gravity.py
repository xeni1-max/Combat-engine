"""Persistent paths, safe numerical stopping and independent physics checks."""
from math import hypot, isfinite
import unittest

from combat_sim.mechanics.gravity import ProjectileTrajectory
from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
from combat_sim.models import UnsupportedMechanicError


class PersistentGravityTests(unittest.TestCase):
    def test_short_interval_matches_existing_integrator(self):
        args = ((1, -2, 20), (600, 500, -300), 1.)
        old = ProjectileTrajectory(*args, deceleration_mps2=300)
        new = PersistentProjectileTrajectory(*args, deceleration_mps2=300)
        self.assertIsNone(new.stopping_time_s)
        self.assertEqual(old.states, new.states)
        for time in (0., .0137, .249, .7, 1.):
            self.assertEqual(old.at(time), new.at(time))

    def test_full_gun_horizon_stops_and_remains_inert(self):
        path = PersistentProjectileTrajectory((0, 0, 2), (900, 0, 0), 5, deceleration_mps2=300)
        self.assertIsNotNone(path.stopping_time_s)
        self.assertGreater(path.stopping_time_s, 900/(300+9.81))
        self.assertLess(path.stopping_time_s, 900/(300-9.81))
        low, high = path.stopping_time_bracket_s
        self.assertLessEqual(high-low, 1.000001e-9)
        self.assertEqual(high, path.stopping_time_s)
        self.assertEqual(path.at(5).velocity_mps, (0., 0., 0.))
        for time in (path.stopping_time_s, 4., 5.):
            state = path.at(time)
            self.assertEqual(state.position_m, path.stopping_state.position_m)
            self.assertEqual(state.distance_m, path.stopping_state.distance_m)
        self.assertGreater(path.stopping_state.distance_m, 1300)
        self.assertEqual(path.duration, 5)
        self.assertEqual(path.times[-1], 5)
        for state in path.states:
            self.assertTrue(all(isfinite(v) for v in
                                (state.time_s, *state.position_m, *state.velocity_mps, state.distance_m)))
        self.assertTrue(all(a < b for a, b in zip(path.times, path.times[1:])))
        self.assertTrue(all(a.distance_m <= b.distance_m for a, b in zip(path.states, path.states[1:])))

    def test_no_gravity_stop_matches_independent_straight_line_reference(self):
        path = PersistentProjectileTrajectory((1, 2, 3), (540, 720, 0), 5,
                                             deceleration_mps2=300, gravity_mps2=0)
        reference = (900-path.speed_floor)/300
        self.assertLessEqual(abs(path.stopping_time_s-reference), 1.1e-9)
        distance = (900**2-path.speed_floor**2)/(2*300)
        self.assertAlmostEqual(path.at(5).distance_m, distance, places=8)
        self.assertAlmostEqual(path.at(5).position_m[0], 1+.6*distance, places=8)
        self.assertAlmostEqual(path.at(5).position_m[1], 2+.8*distance, places=8)

    def test_downward_stop_matches_gravity_adjusted_reference(self):
        path = PersistentProjectileTrajectory((0, 0, 100), (0, 0, -900), 5, deceleration_mps2=300)
        effective = 300-9.81
        expected_time = (900-path.speed_floor)/effective
        expected_distance = (900**2-path.speed_floor**2)/(2*effective)
        self.assertLessEqual(abs(path.stopping_time_s-expected_time), 1.1e-9)
        self.assertAlmostEqual(path.at(5).distance_m, expected_distance, places=8)
        self.assertAlmostEqual(path.at(5).position_m[2], 100-expected_distance, places=8)

    def test_work_energy_and_tighter_full_path_converge(self):
        origin, velocity = (1, -2, 50), (600, 500, 100)
        normal = PersistentProjectileTrajectory(origin, velocity, 5, deceleration_mps2=300)
        tight = PersistentProjectileTrajectory(origin, velocity, 5, deceleration_mps2=300,
            max_step_s=.002, relative_tolerance=1e-13, absolute_tolerance=1e-14,
            stop_time_tolerance_s=1e-11)
        initial_energy = hypot(*velocity)**2/2+9.81*origin[2]
        for path in (normal, tight):
            final = path.at(5)
            energy_loss = initial_energy-(final.speed_mps**2/2+9.81*final.position_m[2])
            self.assertLess(abs(energy_loss-300*final.distance_m), 1e-5)
        self.assertLess(abs(normal.stopping_time_s-tight.stopping_time_s), 2e-8)
        for left, right in zip((*normal.at(5).position_m, normal.at(5).distance_m),
                               (*tight.at(5).position_m, tight.at(5).distance_m)):
            self.assertLess(abs(left-right), 1e-7)

    def test_queries_do_not_change_precomputed_states_or_stop(self):
        path = PersistentProjectileTrajectory((0, 0, 2), (900, 0, 0), 5, deceleration_mps2=300)
        original = (path.states, path.times, path.stopping_time_s, path.stopping_time_bracket_s)
        expected = {t: path.at(t) for t in (.0137, .137, 1.3, 2.999, 4., 5.)}
        for step in (.1, .137):
            time = 0.
            while time < 5:
                path.at(time)
                time += step
        for time, state in reversed(tuple(expected.items())):
            self.assertEqual(path.at(time), state)
        self.assertEqual(original, (path.states, path.times, path.stopping_time_s, path.stopping_time_bracket_s))

    def test_undecelerated_trajectory_keeps_analytic_apex_and_fall(self):
        old = ProjectileTrajectory((0, 0, 2), (0, 0, 10), 5)
        new = PersistentProjectileTrajectory((0, 0, 2), (0, 0, 10), 5)
        self.assertIsNone(new.stopping_time_s)
        self.assertEqual(new.states, old.states)
        for time in (0., 10/9.81, 2., 5.):
            self.assertEqual(new.at(time), old.at(time))
        self.assertLess(new.at(5).velocity_mps[2], 0)

    def test_initial_speed_at_floor_is_inert_without_integration(self):
        for speed in (0., 1e-7, 1e-6):
            path = PersistentProjectileTrajectory((1, 2, 3), (speed, 0, 0), 5, deceleration_mps2=300)
            self.assertEqual(path.stopping_time_s, 0.)
            self.assertEqual(path.at(5).position_m, (1., 2., 3.))
            self.assertEqual(path.at(5).distance_m, 0.)
            self.assertEqual(path.at(0).velocity_mps, (0., 0., 0.))

    def test_zero_duration_preserves_moving_initial_state(self):
        path = PersistentProjectileTrajectory((0, 0, 2), (900, 0, 0), 0, deceleration_mps2=300)
        self.assertEqual(len(path.states), 1)
        self.assertEqual(path.at(0).velocity_mps, (900., 0., 0.))
        self.assertIsNone(path.stopping_time_s)

    def test_positive_deceleration_at_or_below_gravity_is_explicitly_rejected(self):
        for deceleration in (1, 9.81):
            with self.assertRaisesRegex(UnsupportedMechanicError, 'greater than gravity'):
                PersistentProjectileTrajectory((0, 0, 2), (900, 0, 0), 5,
                                               deceleration_mps2=deceleration)

    def test_malformed_inputs_fail(self):
        for origin, velocity in (((0, 0), (900, 0, 0)), ((0, 0, 0), (float('nan'), 0, 0)),
                                 ((True, 0, 0), (900, 0, 0)), (None, (900, 0, 0))):
            with self.subTest(origin=origin, velocity=velocity), self.assertRaises(ValueError):
                PersistentProjectileTrajectory(origin, velocity, 5, deceleration_mps2=300)
        for field, value in (('duration_s', -1), ('duration_s', float('inf')),
                             ('deceleration_mps2', -1), ('gravity_mps2', -1),
                             ('max_step_s', 0), ('relative_tolerance', 0),
                             ('absolute_tolerance', float('nan')), ('speed_floor_mps', 0),
                             ('stop_time_tolerance_s', 0), ('max_step_s', True)):
            options = {'duration_s': 5, 'deceleration_mps2': 300, field: value}
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                PersistentProjectileTrajectory((0, 0, 0), (900, 0, 0), **options)
        path = PersistentProjectileTrajectory((0, 0, 2), (900, 0, 0), 5, deceleration_mps2=300)
        for time in (-1, 6, float('nan'), True):
            with self.subTest(time=time), self.assertRaises(ValueError):
                path.at(time)


if __name__ == '__main__':
    unittest.main()
