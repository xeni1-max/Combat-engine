"""Saved reference prefixes across real actions, queries and life transitions.
These numerical/phase contracts select the pre-equilibrium rules explicitly.
Current selected-rule interactions are covered in test_equilibrium_interactions.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import json
import unittest
from unittest.mock import patch

from combat_sim.mobile_combat import MovingCombatRules
from combat_sim.shared_engine import SharedEncounter
from combat_sim.spatial_transitions import SpatialChange
from tests.test_binding_combat import run,read,BODY,TERRAIN,MOVEMENT,JUMP,CLIMB,PHYSICS,PROFILES
from tests.test_gravity_mobile_combat import scenario
from tests.test_mobile_combat import command,events
from tests.test_grapple_links_combat import force,pos,vel
from tests.test_conditional_melee_combat import incoming
from tests.test_climb_combat import climb


def scene(duration=1000):return scenario(duration,fire_at=100000)
def engine(s,*,interval=None,cls=SharedEncounter):
    return cls(s,PROFILES,sample_interval_ms=interval,body_definition=BODY,terrain_definition=TERRAIN,
        movement_definition=MOVEMENT,jump_definition=JUMP,climb_definition=CLIMB,
        projectile_physics_definition=PHYSICS,combat_locomotion_definition=read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json'))


class SavedBodyPathCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_actual_ballistic_flight_reuses_one_frame_across_observation_prefixes(self):
        frames=[]
        class Observer(SharedEncounter):
            def sample(self,label):
                if label=='scheduled_observation':frames.append(self.body_paths.ensure())
                return super().sample(label)
        s=scene(600);s['spatial_interventions']=[force(0,'A',[2,3,4])]
        r=engine(s,interval=37,cls=Observer).run()
        self.assertGreater(len(frames),10);self.assertTrue(all(f is frames[0] for f in frames))
        self.assertEqual(pos(r,'A'),(D('1.2'),D('-18.2'),D('1.5092')))
        self.assertEqual(vel(r,'A'),(2,3,D('-1.886')))
        self.assertIsInstance(json.dumps(r),str)

    def test_observation_timers_do_not_shorten_a_path_but_new_semantic_timers_do(self):
        w=engine(scene(1000));p=w.body_paths.ensure();before=dict(p.pieces)['A']
        w.push(37,'sample',{},priority=99)
        self.assertIs(w.body_paths.ensure(),p)
        w.push(100,'fixture_future_semantic',{},priority=4)
        after=w.body_paths.ensure();self.assertEqual(after.end_ms,100);self.assertEqual(after.begin_ms,p.begin_ms)
        self.assertEqual(dict(after.pieces)['A'].position(75),before.position(75))

    def test_same_time_incoming_instability_changes_motion_before_the_batch_finishes(self):
        s=scene(700);command(s,'A',0,'run')
        def status(w):
            self.assertEqual(w.mobile_motion('A')[0][0],D('6.4'))
            w.apply_target_status_additions('A',{'disorientation':D(0),'instability':D(100)},w.fighters['A'].armor)
            self.assertEqual(w.mobile_motion('A')[0][0],D('5.9'))
            self.assertEqual(w.mobile_motion('A')[1][0],5)
            self.assertEqual(D(w.fighters['A'].locomotion['velocity_mps'][0]),D('5.9'))
        r=run(s,operations=((500,status),));self.assertEqual(vel(r,'A')[0],D('6.4'))

    def test_advancement_uses_the_new_reference_writer_without_legacy_position_writes(self):
        s=scene(1400);command(s,'A',0,'walk');command(s,'A',500,'jump')
        with patch.object(MovingCombatRules,'advance_mobile_geometry',side_effect=AssertionError('legacy body writer used')):
            r=run(s)
        self.assertTrue(events(r,'jump_takeoff'));self.assertTrue(events(r,'jump_landed'))

    def test_crouching_deforms_boxes_without_moving_the_upright_reference(self):
        s=scene(300);command(s,'A',0,'crouch');r=run(s)
        p=r['current_body_path_pieces']['A']
        self.assertEqual(F(p['reference_m'][2]),F(7,8))
        self.assertEqual(pos(r,'A')[2],D('.675'));self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)

    def test_canonical_climb_corner_and_endpoint_survive_observation_partitioning(self):
        s=scene(500);s['encounter']['participants']['A']['position_m']=['4.6',0];climb(s)
        baseline=run(s);other=run(s,precision=80,interval=17)
        self.assertEqual(pos(baseline,'A'),(6,0,D('2.675')));self.assertEqual(pos(other,'A'),pos(baseline,'A'))
        self.assertEqual(len(events(other,'climb_completed')),1)

    def test_path_readout_owns_precision_even_for_a_low_precision_caller(self):
        w=engine(scene(200));w.spatial_transitions.apply((SpatialChange('A',1,velocity_mps=(F(1,3),F(2,7),F(3,11))),),source='fixture:path_precision')
        with localcontext(Context(prec=7)):a=w.mobile_motion('A')
        with localcontext(Context(prec=90)):b=w.mobile_motion('A')
        self.assertEqual(a,b)

    def test_death_and_revival_cannot_reuse_an_old_life_prefix(self):
        s=scene(500);saved={}
        def kill(w):
            saved['old']=w.body_paths.ensure();w.fighters['A'].hp=D(0);w.finish_team_deaths()
        def revive(w):
            self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=1000,source='fixture:path_life'))
            self.assertIsNot(w.body_paths.ensure(),saved['old'])
        r=run(s,operations=((100,kill),(300,revive)))
        self.assertEqual(r['current_body_path_pieces']['A']['life_generation'],2)

    def test_queries_and_prefix_advance_use_the_same_motion_coefficients(self):
        def probe(w):
            frame=w.body_paths.ensure(future=True);piece=dict(frame.pieces)['A'];v,a=w.mobile_motion('A')
            bv,ba,offset,size=w.blocking.kinematics('A','torso',w.time)
            self.assertEqual((bv,ba),(v,a));self.assertEqual(offset,(0,0,0));self.assertEqual(size,(0,0,0))
            seconds=D('.025');pred=tuple(D(x.numerator)/D(x.denominator)+q*seconds+z*seconds*seconds/2
                for x,q,z in zip(piece.reference_m,v,a))
            expected=tuple(D(x.numerator)/D(x.denominator) for x in piece.position(w.time+25))
            self.assertEqual(pred,expected);self.assertIs(w.body_paths.ensure(),frame)
        s=scene(100);s['spatial_interventions']=[force(0,'A',[2,3,4])]
        run(s,operations=((1,probe),))

    def test_real_interactions_retain_legacy_physical_results(self):
        legacy=read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json');legacy.pop('body_paths')
        scenes=[]
        s=scene(1200);command(s,'A',0,'walk');command(s,'A',400,'run');scenes.append(s)
        s=scene(1200);command(s,'A',0,'jump');scenes.append(s)
        s=scene(900);command(s,'A',0,'crouch');command(s,'A',500,'stand');scenes.append(s)
        scenes.append(incoming(4500,held=True))
        for s in scenes:
            new=run(s);old=run(s,rules=legacy)
            for name in new['final_states']:
                for field in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertLess(abs(D(new['final_states'][name][field])-D(old['final_states'][name][field])),D('1e-8'))
                for a,b in zip(pos(new,name),pos(old,name)):self.assertLess(abs(a-b),D('1e-18'))
                for a,b in zip(vel(new,name),vel(old,name)):self.assertLess(abs(a-b),D('1e-18'))
