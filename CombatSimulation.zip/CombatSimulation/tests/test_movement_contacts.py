"""Analytic continuous rigid cuboid sweep, independent of response rules."""
from decimal import Decimal as D
import unittest
from combat_sim.hitboxes import Cuboid
from combat_sim.movement_contacts import first_box_contact

class MovementContactTests(unittest.TestCase):
    def setUp(self):
        self.a=Cuboid('a',[0,0,1],[1,1,2]);self.b=Cuboid('b',[3,0,1],[1,1,2])
    def test_constant_velocity_contact(self):
        self.assertEqual(first_box_contact(self.a,self.b,[2,0,0],[0,0,0],2),1)
    def test_acceleration_contact(self):
        self.assertEqual(first_box_contact(self.a,self.b,[0,0,0],[4,0,0],2),1)
    def test_short_horizon_miss(self):
        self.assertIsNone(first_box_contact(self.a,self.b,[2,0,0],[0,0,0],D('.5')))
    def test_lateral_miss(self):
        other=Cuboid('b',[3,3,1],[1,1,2])
        self.assertIsNone(first_box_contact(self.a,other,[20,0,0],[0,0,0],1))
    def test_initial_touch_can_separate(self):
        other=Cuboid('b',[1,0,1],[1,1,2])
        self.assertIsNone(first_box_contact(self.a,other,[-1,0,0],[0,0,0],1))
    def test_initial_touch_can_move_tangentially(self):
        other=Cuboid('b',[1,0,1],[1,1,2])
        self.assertIsNone(first_box_contact(self.a,other,[0,1,0],[0,0,0],1))
    def test_initial_touch_approaching_stops_at_zero(self):
        other=Cuboid('b',[1,0,1],[1,1,2])
        self.assertEqual(first_box_contact(self.a,other,[1,0,0],[0,0,0],1),0)

    def test_growing_box_contact_uses_size_rate(self):
        body=Cuboid('body',[0,0,1],[1,1,2])
        ceiling=Cuboid('ceiling',[0,0,'3.25'],[3,3,'.5'])
        hit=first_box_contact(body,ceiling,[0,0,1],[0,0,0],1,left_size_rate_mps=(0,0,2))
        self.assertEqual(hit,D('.5'))

    def test_growing_leg_keeps_its_foot_on_ground_without_collision(self):
        body=Cuboid('leg',[0,0,1],[1,1,2])
        floor=Cuboid('floor',[0,0,'-.05'],[3,3,'.1'])
        self.assertIsNone(first_box_contact(body,floor,[0,0,1],[0,0,0],1,left_size_rate_mps=(0,0,2)))

    def test_invalid_size_evolution_is_rejected(self):
        with self.assertRaises(ValueError):
            first_box_contact(self.a,self.b,[0,0,0],[0,0,0],1,left_size_rate_mps=(-2,0,0))
