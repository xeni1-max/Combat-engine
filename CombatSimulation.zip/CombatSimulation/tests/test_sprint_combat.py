"""Existing sprint transitions, continuous effort and shared combat interactions."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.mobile_combat import MOBILE_SCOPE
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter, run_shared_scenario
from tests.test_gravity_mobile_combat import PHYSICS, scenario
from tests.test_mobile_combat import BODY, EFFECTS, MOVEMENT, PROFILES, TERRAIN, command, events


def run(s, *, effects=EFFECTS, **kwargs):
    return run_shared_scenario(s, PROFILES, body_definition=BODY,
        terrain_definition=TERRAIN, movement_definition=MOVEMENT,
        combat_locomotion_definition=effects,
        projectile_physics_definition=None if s['scope'] == MOBILE_SCOPE else PHYSICS,
        **kwargs)


def continuous_reference(initial, elapsed_ms):
    """Independent closed form for dD/dt=(2+D/100)^2 without recovery."""
    with localcontext(Context(prec=70)):
        x = D(2)+D(initial)/100
        return 100*(x/(1-x*D(elapsed_ms)/100000)-2)


def sprint_entry_resource(initial=D(0)):
    with localcontext(Context(prec=70)):
        after_run = initial+(D('.5')+initial/100)**2
        return after_run+(D('.5')+after_run/100)**2


def exhaustion_reference(initial):
    with localcontext(Context(prec=70)):
        start = sprint_entry_resource(D(initial))
        return D(210)+100000*(1/(2+start/100)-D(1)/3)


class SprintCombatTests(unittest.TestCase):
    def test_standing_sprint_uses_existing_transitions_and_instability_motion(self):
        s = scenario(1000, target=(100, -20))
        command(s, 'A', 0, 'sprint')
        r = run(s)
        starts = events(r, 'movement_active_started', 'A')
        self.assertEqual([(e['action'], D(e['time_ms'])) for e in starts],
                         [('walk', D(0)), ('run', D(60)), ('sprint', D(210))])
        sprint = starts[-1]
        self.assertEqual(D(sprint['active_end_ms'])-D(sprint['time_ms']), 200)
        self.assertEqual(sprint['self_effects'], {'disorientation': '120.0', 'instability': '120.0'})
        final = r['final_states']['A']
        self.assertEqual(final['locomotion']['mode'], 'sprinting')
        self.assertEqual(D(final['locomotion']['speed_mps']), D('11.2'))
        # .06 walking +(.63-.02304) running + (1.76-.036) sprint
        # transition + .59*11.2 steady sprint.
        self.assertAlmostEqual(D(final['position_m'][0]), D('8.99896'), places=25)
        self.assertEqual(final['hands_m'], EFFECTS['sprint']['hand_positions_m']['1E2'])

    def test_continuous_cost_starts_at_active_and_uses_nonlinear_rate(self):
        s = scenario(1000, target=(100, -20))
        command(s, 'A', 0, 'sprint')
        r = run(s)
        expected = continuous_reference(sprint_entry_resource(), 790)
        self.assertAlmostEqual(D(r['final_states']['A']['dyspnea']), expected, places=40)
        samples = {D(p['time_ms']): p['states']['A'] for p in r['curve']}
        self.assertEqual(D(samples[D(200)]['dyspnea']), D('.25'))
        self.assertTrue(all(D(e['interval_start_ms']) >= 210
                            for e in events(r, 'sprint_dyspnea_gained', 'A')))
        self.assertFalse(events(r, 'dyspnea_recovered', 'A'))

    def test_sprint_to_walk_stages_paid_run_exit_then_walk(self):
        s = scenario(1400, target=(100, -20))
        command(s, 'A', 0, 'sprint')
        command(s, 'A', 1000, 'walk')
        r = run(s)
        starts = events(r, 'movement_active_started', 'A')
        self.assertEqual([(e['action'], D(e['time_ms'])) for e in starts],
                         [('walk', D(0)), ('run', D(60)), ('sprint', D(210)),
                          ('run', D(1000)), ('walk', D(1200))])
        self.assertEqual(D(starts[-2]['active_end_ms']), 1200)
        self.assertEqual(D(starts[-2]['self_effects']['instability']), 120)
        exit_payment = next(e for e in events(r, 'dyspnea_paid', 'A') if D(e['time_ms']) == 1000)
        before = continuous_reference(sprint_entry_resource(), 790)
        expected = (D('.5')+before/100)**2
        self.assertAlmostEqual(D(exit_payment['amount']), expected, places=25)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'], 'walking')
        self.assertEqual(D(r['final_states']['A']['locomotion']['speed_mps']), 2)

    def test_special_stop_ends_continuous_effort_at_active_start(self):
        s = scenario(1300, target=(100, -20))
        command(s, 'A', 0, 'sprint')
        command(s, 'A', 1000, 'stop')
        r = run(s)
        stop = events(r, 'special_stop_started', 'A')[0]
        self.assertEqual(D(stop['time_ms']), 1000)
        self.assertEqual(D(stop['original_speed_mps']), D('11.2'))
        self.assertEqual(D(stop['slide_duration_ms']), 336)
        self.assertAlmostEqual(D(r['final_states']['A']['dyspnea']),
                               continuous_reference(sprint_entry_resource(), 790), places=40)
        self.assertTrue(all(D(e['interval_end_ms']) <= 1000
                            for e in events(r, 'sprint_dyspnea_gained', 'A')))

    def test_hand_recovery_before_sprint_retains_running_motion(self):
        s = scenario(750, fire_at=0, target=(100, -20))
        command(s, 'A', 120, 'sprint')
        r = run(s)
        requested = events(r, 'sprint_transition_requested', 'A')[0]
        # Firing left hand(0,.30,.15) to authored(-.20,.15,-.10),
        # distance sqrt(.125); running Recovery240 gives ceil84.8528=85ms.
        self.assertEqual(D(requested['time_ms']), 330)
        self.assertEqual(D(requested['recovery_ms']), 85)
        sprint = next(e for e in events(r, 'movement_active_started', 'A') if e['action'] == 'sprint')
        self.assertEqual(D(sprint['time_ms']), 415)
        prior = next(e['state'] for e in events(r, 'movement_active_completed', 'A') if e['action'] == 'run')
        after_recovery = next(p['states']['A'] for p in r['curve'] if D(p['time_ms']) == 415)
        self.assertAlmostEqual(D(after_recovery['position_m'][0])-D(prior['position_m'][0]), D('.544'), places=25)
        self.assertEqual(len(events(r, 'projectile_released', 'A')), 1)

    def test_sprint_blocks_attacks_and_resumes_after_stop(self):
        s = scenario(1800, fire_at=0, target=(100, -20))
        command(s, 'A', 0, 'sprint')
        command(s, 'A', 1000, 'stop')
        r = run(s)
        stop_end = next(e for e in events(r, 'movement_active_completed', 'A') if e['action'] == 'stop')
        attacks = events(r, 'ability_started', 'A')
        self.assertTrue(attacks)
        self.assertTrue(all(D(e['time_ms']) >= D(stop_end['time_ms']) for e in attacks))
        self.assertTrue(events(r, 'projectile_released', 'A'))

    def test_reload_is_also_blocked_until_sprint_ends(self):
        s = scenario(2000, fire_at=0, target=(100, -20))
        command(s, 'A', 0, 'sprint')
        command(s, 'A', 1000, 'stop')
        with localcontext(Context(prec=50)):
            engine = SharedEncounter(s, PROFILES, body_definition=BODY, terrain_definition=TERRAIN,
                movement_definition=MOVEMENT, combat_locomotion_definition=EFFECTS,
                projectile_physics_definition=PHYSICS)
            # Start from a valid empty-magazine combat state; the public scenario
            # format does not yet expose an initial-ammo field.
            engine.fighters['A'].ammo['1'] = 0
            r = engine.run()
        stop_end = next(e for e in events(r, 'movement_active_completed', 'A') if e['action'] == 'stop')
        reloads = events(r, 'reload_requested', 'A')
        self.assertTrue(reloads)
        self.assertTrue(all(D(e['time_ms']) >= D(stop_end['time_ms']) for e in reloads))

    def test_exhaustion_occurs_at_analytic_boundary_once_then_free_stop(self):
        s = scenario(1500, target=(100, -20))
        s['encounter']['participants']['A']['initial_state']['dyspnea'] = 90
        command(s, 'A', 0, 'sprint')
        r = run(s, sample_interval_ms=None)
        triggers = events(r, 'maximum_dyspnea_trigger', 'A')
        self.assertEqual(len(triggers), 1)
        trigger = triggers[0]
        self.assertAlmostEqual(D(trigger['time_ms']), exhaustion_reference(90), places=35)
        self.assertEqual(D(trigger['added_disorientation']), 240)
        stops = events(r, 'special_stop_started', 'A')
        self.assertEqual(len(stops), 1)
        self.assertEqual(stops[0]['time_ms'], trigger['time_ms'])
        self.assertFalse(any(e['ability'] == 'stop' for e in events(r, 'dyspnea_paid', 'A')))
        self.assertEqual(r['final_states']['A']['locomotion']['mode'], 'standing')
        self.assertEqual(r['metrics']['A']['sprint_exhaustions'], 1)

    def test_exhaustion_cancels_an_incomplete_entry_transition(self):
        s = scenario(900, target=(100, -20))
        s['encounter']['participants']['A']['initial_state']['dyspnea'] = 95
        command(s, 'A', 0, 'sprint')
        r = run(s, sample_interval_ms=None)
        sprint = next(e for e in events(r, 'movement_active_started', 'A') if e['action'] == 'sprint')
        trigger = events(r, 'maximum_dyspnea_trigger', 'A')[0]
        self.assertGreater(D(trigger['time_ms']), D(sprint['time_ms']))
        self.assertLess(D(trigger['time_ms']), D(sprint['active_end_ms']))
        self.assertFalse(any(e['action'] == 'sprint' for e in events(r, 'movement_active_completed', 'A')))
        self.assertEqual(len(events(r, 'special_stop_started', 'A')), 1)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'], 'standing')

    def test_unaffordable_paid_exit_uses_free_stop_without_waiting(self):
        s = scenario(1200, target=(100, -20))
        s['encounter']['participants']['A']['initial_state']['dyspnea'] = 90
        command(s, 'A', 0, 'sprint')
        command(s, 'A', 700, 'run')
        r = run(s)
        fallback = events(r, 'sprint_exit_fallback', 'A')
        self.assertEqual(len(fallback), 1)
        self.assertEqual(D(fallback[0]['time_ms']), 700)
        self.assertEqual(D(events(r, 'special_stop_started', 'A')[0]['time_ms']), 700)
        self.assertFalse(events(r, 'maximum_dyspnea_trigger', 'A'))
        self.assertEqual(r['final_states']['A']['locomotion']['mode'], 'standing')

    def test_full_collision_ends_effort_and_wakes_blocked_attack_policy(self):
        s = scenario(2000, fire_at=0, target=(30, 0))
        s['encounter']['participants']['A']['position_m'] = [0, 0]
        command(s, 'A', 0, 'sprint')
        r = run(s, sample_interval_ms=None)
        contacts = events(r, 'body_contact')
        self.assertEqual(len(contacts), 1)
        collision_time = D(contacts[0]['time_ms'])
        self.assertGreater(collision_time, 410)
        attacks = events(r, 'ability_started', 'A')
        self.assertTrue(attacks)
        self.assertEqual(D(attacks[0]['time_ms']), collision_time)
        self.assertTrue(all(D(e['interval_end_ms']) <= collision_time
                            for e in events(r, 'sprint_dyspnea_gained', 'A')))
        self.assertEqual(r['final_states']['A']['locomotion']['mode'], 'standing')

    def test_death_ends_effort_and_rejects_future_motion(self):
        s = scenario(1300, target=(30, -20))
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        s['action_selection']['B']['start_ms'] = 500
        command(s, 'A', 0, 'sprint')
        command(s, 'A', 1000, 'run')
        r = run(s)
        death = events(r, 'character_died', 'A')[0]
        final = r['final_states']['A']
        self.assertFalse(final['alive'])
        self.assertEqual(final['dyspnea'], death['state']['dyspnea'])
        self.assertEqual(final['position_m'], death['state']['position_m'])
        self.assertTrue(all(D(e['interval_end_ms']) <= D(death['time_ms'])
                            for e in events(r, 'sprint_dyspnea_gained', 'A')))
        self.assertTrue(events(r, 'movement_intent_rejected', 'A'))

    def test_exhaustion_is_independent_of_observations_and_combat_precision(self):
        s = scenario(1500, target=(100, -20))
        s['encounter']['participants']['A']['initial_state']['dyspnea'] = 90
        command(s, 'A', 0, 'sprint')
        base = run(s, sample_interval_ms=None)
        for precision, interval in ((50, 37), (80, 113)):
            r = run(s, precision=precision, sample_interval_ms=interval)
            self.assertAlmostEqual(D(events(r, 'maximum_dyspnea_trigger')[0]['time_ms']),
                                   D(events(base, 'maximum_dyspnea_trigger')[0]['time_ms']), places=35)
            for field in ('dyspnea', 'disorientation', 'instability'):
                self.assertAlmostEqual(D(r['final_states']['A'][field]),
                                       D(base['final_states']['A'][field]), places=30)
            self.assertAlmostEqual(D(r['final_states']['A']['position_m'][0]),
                                   D(base['final_states']['A']['position_m'][0]), places=25)

    def test_old_combat_definition_does_not_silently_enable_sprint(self):
        s = scenario(1000)
        command(s, 'A', 0, 'sprint')
        old = deepcopy(EFFECTS)
        old.pop('sprint')
        with self.assertRaises(UnsupportedMechanicError):
            run(s, effects=old)

    def test_sprint_also_uses_shared_straight_projectile_scope(self):
        s = scenario(1000, target=(100, -20))
        s['scope'] = dict(MOBILE_SCOPE)
        command(s, 'A', 0, 'sprint')
        r = run(s)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'], 'sprinting')
        self.assertAlmostEqual(D(r['final_states']['A']['dyspnea']),
                               continuous_reference(sprint_entry_resource(), 790), places=40)

    def test_glancing_contact_preserves_stop_and_does_not_resume_sprint_effort(self):
        # The slide reaches cube1's x face while retaining tangential y motion.
        # With initialD90 the old sprint cap falls inside the stopping interval;
        # restoring the old sprint mode/anchor caused a zero-time loop there.
        for initial in (0, 90):
            for precision, interval in ((50, None), (80, 113)):
                with self.subTest(initial=initial, precision=precision, interval=interval):
                    s = scenario(1400, target=(30, 20))
                    actor = s['encounter']['participants']['A']
                    actor.update(position_m=[0, -4.6], movement_direction=[1, 1])
                    actor['initial_state']['dyspnea'] = initial
                    command(s, 'A', 0, 'sprint')
                    command(s, 'A', 800, 'stop')
                    r = run(s, precision=precision, sample_interval_ms=interval)
                    stop = events(r, 'special_stop_started', 'A')[0]
                    contacts = events(r, 'body_contact')
                    self.assertEqual(len(contacts), 1)
                    contact_time = D(contacts[0]['time_ms'])
                    self.assertGreater(contact_time, 800)
                    self.assertLess(contact_time, 1136)
                    self.assertEqual(D(stop['slide_duration_ms']), 336)
                    completed = [e for e in events(r, 'movement_active_completed', 'A')
                                 if e['action'] == 'stop']
                    self.assertEqual(len(completed), 1)
                    self.assertEqual(D(completed[0]['time_ms']), 1136)
                    self.assertFalse(events(r, 'movement_active_cancelled', 'A'))
                    self.assertFalse(events(r, 'maximum_dyspnea_trigger', 'A'))
                    gains = events(r, 'sprint_dyspnea_gained', 'A')
                    self.assertTrue(gains)
                    self.assertTrue(all(D(e['interval_end_ms']) <= 800 for e in gains))
                    self.assertAlmostEqual(D(gains[-1]['after']),
                        continuous_reference(sprint_entry_resource(D(initial)), 590), places=35)
                    final = r['final_states']['A']
                    self.assertEqual(final['locomotion']['mode'], 'standing')
                    self.assertEqual(D(final['locomotion']['speed_mps']), 0)
                    self.assertAlmostEqual(D(final['position_m'][0]), D('4.95'), places=25)
                    self.assertGreater(D(final['position_m'][1]), D('.35'))
                    self.assertLess(D(final['position_m'][1]), D('.65'))


if __name__ == '__main__':
    unittest.main()
