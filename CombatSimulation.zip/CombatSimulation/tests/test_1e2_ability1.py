"""One confirmed unshielded shot; full bleed, automatic independent weapon cycle."""
from copy import deepcopy
from decimal import Decimal, localcontext, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
import json
from pathlib import Path
import unittest

from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario
from combat_sim.models import UnsupportedMechanicError

ROOT=Path(__file__).resolve().parents[1]
CHARACTERS=json.loads((ROOT/'data/characters.json').read_text())['characters']
SCENARIO=json.loads((ROOT/'scenarios/1e2_slash_projectile.json').read_text())


def event(run,kind): return next(e for e in run['events'] if e['type']==kind)


class SlashProjectileTests(unittest.TestCase):
    def test_known_damage_and_armor_results(self):
        r=summarize(run_scenario(SCENARIO,CHARACTERS))
        # d=437-100/4=412; y=(412²-(165-18)²)/412.
        self.assertEqual(r['raw_damage']['exact'],'412')
        self.assertEqual(r['direct_hp_damage']['exact'],'148135/412')
        self.assertEqual(r['damage_by_effect']['bleeding']['exact'],'29627/824')
        self.assertEqual(set(r['damage_by_effect']),{'bleeding'})
        self.assertEqual(r['hp_damage']['exact'],'325897/824')
        self.assertEqual(r['final_hp']['exact'],'7156023/824')
        self.assertEqual(r['armor_lost']['exact'],'4573147/576800')
        self.assertEqual(r['final_armor']['exact'],'90598853/576800')
        self.assertEqual(r['excess_hp_damage']['exact'],'0')

    def test_zero_gathering_release_travel_and_cooldown_times(self):
        run=run_scenario(SCENARIO,CHARACTERS)
        expected={'ability_started':0,'self_effect_triggered':20,'projectile_released':40,
                  'weapon_cooldown_started':40,'impact_resolved':154,'weapon_cooldown_completed':400,'bleeding_expired':8154}
        for kind,time in expected.items(): self.assertEqual(event(run,kind)['time_ms'],time)
        timing=event(run,'impact_resolved')['timing_calculation']
        self.assertEqual(timing['effective_gathering_ms'],0)
        self.assertEqual(timing['travel_time_ms'],114)
        self.assertEqual(run['run_until_ms'],8154)

    def test_midpoint_self_effects_unmitigated_and_decay(self):
        characters=deepcopy(CHARACTERS); characters['1E2']['status_resistance']=100000
        run=run_scenario(SCENARIO,characters)
        effects=[e for e in run['events'] if e['type']=='status_applied' and e['origin']=='self']
        self.assertEqual(len(effects),2)
        self.assertTrue(all(e['time_ms']==20 and Decimal(e['after']['decimal'])==135 and not e['mitigation_applied'] for e in effects))
        release=event(run,'projectile_released')['actor_state']
        self.assertEqual(Decimal(release['disorientation']['decimal']),115)
        self.assertEqual(Decimal(release['instability']['decimal']),115)

    def test_target_effects_use_pre_hit_armor(self):
        run=run_scenario(SCENARIO,CHARACTERS)
        effects=[e for e in run['events'] if e['type']=='status_applied' and e['origin']=='projectile_target']
        self.assertEqual(len(effects),2)
        self.assertTrue(all(e['inputs']['a']=='165' and e['time_ms']==154 for e in effects))
        self.assertEqual(event(run,'impact_resolved')['state_changes']['armor_after_impact']['exact'],'90598853/576800')

    def test_bleed_integrates_at_intermediate_cooldown_boundary(self):
        run=run_scenario(SCENARIO,CHARACTERS)
        intervals=[e for e in run['events'] if e['type']=='continuous_damage_resolved']
        self.assertEqual([(e['interval_start_ms'],e['interval_end_ms']) for e in intervals],[(154,400),(400,8154)])
        y=Fraction(148135,412); t=Fraction(246,1000)
        self.assertEqual(Fraction(intervals[0]['applied_hp_damage']['exact']),y*(8*t-t*t/2)/320)
        self.assertEqual(sum(Fraction(e['applied_hp_damage']['exact']) for e in intervals),y/10)
        self.assertTrue(all('not a damage tick' in e['damage_payment'] for e in intervals))

    def test_automatic_cooldown_does_not_wait_for_character_statuses(self):
        scenario=deepcopy(SCENARIO); scenario['encounter']['initial_states']['1E2']['instability']=1000
        run=run_scenario(scenario,CHARACTERS)
        cooldown=event(run,'weapon_cooldown_completed')
        self.assertEqual(cooldown['time_ms'],400)
        self.assertTrue(cooldown['weapon_ready'])
        self.assertFalse(cooldown['blocks_other_actions'])
        self.assertGreater(Decimal(cooldown['actor_state']['instability']['decimal']),0)
        self.assertEqual(summarize(run)['hp_damage']['exact'],'325897/824')
        self.assertEqual(run['weapon_cycle']['ready_at_ms'],400)

    def test_initial_disorientation_adds_to_zero_base_gathering(self):
        scenario=deepcopy(SCENARIO); scenario['encounter']['initial_states']['1E2']['disorientation']=80
        run=run_scenario(scenario,CHARACTERS)
        self.assertEqual(event(run,'self_effect_triggered')['time_ms'],100)
        self.assertEqual(event(run,'projectile_released')['time_ms'],120)
        self.assertEqual(event(run,'impact_resolved')['time_ms'],234)
        self.assertEqual(event(run,'weapon_cooldown_completed')['time_ms'],480)
        self.assertEqual(summarize(run)['hp_damage']['exact'],'325897/824')

    def test_delayed_start_samples_current_disorientation(self):
        scenario=deepcopy(SCENARIO); scenario['action_sequence'][0]['action_start_ms']=100
        scenario['encounter']['initial_states']['1E2']['disorientation']=80
        run=run_scenario(scenario,CHARACTERS)
        self.assertEqual(event(run,'projectile_released')['time_ms'],140)
        self.assertEqual(event(run,'impact_resolved')['time_ms'],254)

    def test_zero_distance_causal_order(self):
        scenario=deepcopy(SCENARIO); scenario['action_sequence'][0]['target_distance_m']=0
        run=run_scenario(scenario,CHARACTERS)
        self.assertEqual(event(run,'impact_resolved')['time_ms'],40)
        self.assertEqual(summarize(run)['raw_damage']['exact'],'437')
        types=[e['type'] for e in run['events']]
        self.assertLess(types.index('projectile_released'),types.index('impact_resolved'))
        self.assertLess(types.index('impact_resolved'),types.index('bleeding_started'))

    def test_damage_uses_distance_not_rounded_travel_time(self):
        scenario=deepcopy(SCENARIO); scenario['action_sequence'][0]['target_distance_m']='0.1'
        run=run_scenario(scenario,CHARACTERS)
        self.assertEqual(event(run,'impact_resolved')['time_ms'],41)
        self.assertEqual(summarize(run)['raw_damage']['exact'],'17479/40')

    def test_far_projectile_arrives_after_automatic_cooldown(self):
        scenario=deepcopy(SCENARIO); scenario['action_sequence'][0]['target_distance_m']=1000
        run=run_scenario(scenario,CHARACTERS)
        self.assertGreater(event(run,'impact_resolved')['time_ms'],400)
        self.assertEqual(event(run,'weapon_cooldown_completed')['time_ms'],400)
        self.assertEqual(summarize(run)['raw_damage']['exact'],'187')

    def test_maximum_reachable_distance_and_unreachable_distance(self):
        scenario=deepcopy(SCENARIO); scenario['action_sequence'][0]['target_distance_m']=1350
        run=run_scenario(scenario,CHARACTERS)
        self.assertEqual(event(run,'impact_resolved')['time_ms'],3040)
        scenario['action_sequence'][0]['target_distance_m']='1350.001'
        with self.assertRaisesRegex(UnsupportedMechanicError,'reachable'): run_scenario(scenario,CHARACTERS)

    def test_armor_floor_and_complete_mitigation(self):
        for armor in (0,1000):
            scenario=deepcopy(SCENARIO); scenario['encounter']['initial_states']['2E4']['armor']=armor
            result=summarize(run_scenario(scenario,CHARACTERS))
            if armor==0:
                self.assertEqual(result['direct_hp_damage']['exact'],'412')
                self.assertEqual(result['armor_lost']['exact'],'0')
                self.assertEqual(result['final_armor']['exact'],'0')
            else:
                self.assertEqual(result['hp_damage']['exact'],'0')
                self.assertEqual(result['damage_by_effect']['bleeding']['exact'],'0')

    def test_synthetic_timing_data_changes_remain_data_driven(self):
        characters=deepcopy(CHARACTERS); characters['1E2']['abilities']['1']['weapon_cooldown_ms']=9000
        run=run_scenario(SCENARIO,characters)
        self.assertEqual(event(run,'bleeding_expired')['time_ms'],8154)
        self.assertEqual(event(run,'weapon_cooldown_completed')['time_ms'],9040)
        self.assertEqual(run['run_until_ms'],9040)
        self.assertEqual(summarize(run)['hp_damage']['exact'],'325897/824')

    def test_replay_context_independence_and_no_input_mutation(self):
        scenario,characters=deepcopy(SCENARIO),deepcopy(CHARACTERS)
        expected=run_scenario(scenario,characters)
        for precision,rounding in ((8,ROUND_FLOOR),(60,ROUND_CEILING)):
            with localcontext() as ctx:
                ctx.prec,ctx.rounding=precision,rounding
                self.assertEqual(run_scenario(scenario,characters),expected)
        self.assertEqual(scenario,SCENARIO); self.assertEqual(characters,CHARACTERS)
        times=[e['time_ms'] for e in expected['events']]; self.assertEqual(times,sorted(times))

    def test_death_partial_runs_and_multiple_explicit_shots_rejected(self):
        for kind in ('death','partial','repeat','movement','missing_distance','unconfirmed_hit','extra_field'):
            scenario=deepcopy(SCENARIO)
            if kind=='death': scenario['encounter']['initial_states']['2E4']['hp']=395
            if kind=='partial': scenario['run_until_ms']=400
            if kind=='repeat': scenario['action_sequence'].append(deepcopy(scenario['action_sequence'][0]))
            if kind=='movement': scenario['encounter']['movement']='running'
            if kind=='missing_distance': scenario['action_sequence'][0].pop('target_distance_m')
            if kind=='unconfirmed_hit': scenario['action_sequence'][0]['hit_confirmed']=False
            if kind=='extra_field': scenario['action_sequence'][0]['ammo']=11
            with self.subTest(kind=kind),self.assertRaises((UnsupportedMechanicError,ValueError)): run_scenario(scenario,CHARACTERS)

    def test_unsupported_rule_modes_rejected(self):
        for field,value in (('target_status_armor_snapshot','after_loss'),('damage_category','intrinsic'),('damage_payment','ticks')):
            characters=deepcopy(CHARACTERS); characters['1E2']['abilities']['1'][field]=value
            with self.subTest(field=field),self.assertRaises(UnsupportedMechanicError): run_scenario(SCENARIO,characters)
        characters=deepcopy(CHARACTERS); characters['1E2']['abilities']['1']['weapon_cooldown_behavior']['blocks_other_actions']=True
        with self.assertRaises(UnsupportedMechanicError): run_scenario(SCENARIO,characters)

    def test_missing_profile_data_rejected(self):
        characters=deepcopy(CHARACTERS); characters['1E2'].pop('max_hp')
        with self.assertRaisesRegex(UnsupportedMechanicError,'defender'): run_scenario(SCENARIO,characters)
