"""Known values from the author's revised primary character documents.

These checks verify imported definitions, not full execution of their effects.
"""

import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CHARACTERS = json.loads((ROOT / "data/characters.json").read_text())["characters"]


class RevisedDefinitionTests(unittest.TestCase):
    def test_1e5_revised_bleeding_is_a_fixed_multiplier(self):
        a=CHARACTERS['1E5']['documented_abilities']['4']
        self.assertEqual(a['bleeding_multiplier'],2)
        self.assertEqual(a['dyspnea']['kind'],'none')
        self.assertEqual(a['implementation_status'],'shared_passive_attack_modifier')

    def test_1e5_revised_ultimate_enhances_piercing_without_old_arm_costs(self):
        a=CHARACTERS['1E5']['documented_abilities']['Ultimate']
        self.assertEqual((a['ability_1_additional_piercing'],a['effect_duration_ms'],a['active_ms'],a['cooldown_ms']),
            (80,15000,320,65000))
        self.assertEqual(a['dyspnea']['kind'],'none')
        self.assertNotIn('extra_arms',a);self.assertNotIn('self_effects',a)

    def test_2e4_revised_armor_enhancement_removes_old_projectile_definition(self):
        a=CHARACTERS['2E4']['documented_abilities']['4']
        self.assertEqual((a['additional_armor_loss'],a['active_ms'],a['cooldown_ms']),(20,200,9000))
        self.assertNotIn('projectile_release',a);self.assertNotIn('triggered_attack',a)
        self.assertEqual(a['implementation_status'],'shared_attack_modifier')

    def test_2e4_revised_ultimate_ignores_shielding_instead_of_extending_attachment(self):
        a=CHARACTERS['2E4']['documented_abilities']['Ultimate']
        self.assertEqual((a['ability_1_shielding_ignored'],a['effect_duration_ms'],a['active_ms'],a['cooldown_ms']),
            (4000,10000,400,60000))
        self.assertNotIn('blade_attachment_ms',a)
        self.assertEqual(a['effort_phases']['activation']['category'],'extrinsic_momentary')

    def test_revised_projectile_self_effect_values(self):
        for character, ability, disorientation, instability in (
            ("1E1", "1", 140, 140), ("1E1", "2", 160, 160),
            ("1E1", "Ultimate", 140, 140),
            ("1E2", "Ultimate", 150, 190),
            ("1E3", "1", 120, 120), ("1E3", "2", 160, 180),
            ("1E3", "4", 120, 120),
        ):
            with self.subTest(character=character, ability=ability):
                effects = CHARACTERS[character]["documented_abilities"][ability]["self_effects"]
                self.assertEqual(len(effects), 1)
                self.assertEqual(effects[0]["disorientation"], disorientation)
                self.assertEqual(effects[0]["instability"], instability)
                self.assertEqual(effects[0]["application_timing"], "middle_of_active")
                self.assertIn("source", effects[0])

    def test_1e5_shared_impact_values_are_150_and_history_is_separate(self):
        effects = CHARACTERS["1E5"]["documented_abilities"]["1"]["shared_component_effects"]
        self.assertEqual(effects["self_disorientation_on_impact"], 150)
        self.assertEqual(effects["self_instability_on_impact"], 150)
        self.assertNotIn("self_disorientation_on_swing", effects)
        self.assertNotIn("self_instability_on_swing", effects)
        self.assertEqual(effects["last_confirmed_timing_reference"]["value"], 80)
        self.assertIn("Historical", effects["last_confirmed_timing_reference"]["status"])

    def test_2e4_thrust_self_effects_are_on_impact_and_cost_is_recorded(self):
        ability = CHARACTERS["2E4"]["documented_abilities"]["1"]
        self.assertEqual(ability["self_disorientation_on_impact"], 150)
        self.assertEqual(ability["self_instability_on_impact"], 150)
        self.assertNotIn("self_disorientation_on_thrust", ability)
        self.assertNotIn("self_instability_on_thrust", ability)
        self.assertEqual(ability["listed_dyspnea_value"], 3)

    def test_3e5_shared_punch_effects_are_150_on_impact(self):
        effects = CHARACTERS["3E5"]["documented_abilities"]["1"]["shared_b_c_effects"]
        self.assertEqual(effects["self_disorientation_on_impact"], 150)
        self.assertEqual(effects["self_instability_on_impact"], 150)
        self.assertNotIn("self_disorientation_on_punch", effects)
        self.assertNotIn("self_instability_on_punch", effects)

    def test_revised_leap_self_effects(self):
        for character, values in (
            ("1E1", [(150, 150), (170, 190)]),
            ("3E5", [(150, 150), (180, 220)]),
        ):
            with self.subTest(character=character):
                effects = CHARACTERS[character]["documented_abilities"]["3"]["self_effects"]
                self.assertEqual(
                    [(effect["disorientation"], effect["instability"]) for effect in effects],
                    values,
                )


if __name__ == "__main__":
    unittest.main()
