"""Owned stream probes with actual heat, healing, life and shield machinery.

These exercise the shared API without claiming an authored grapple grab.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from tests.test_continuous_effort_combat import world,owner
from tests.test_motion_boundary_combat import scene
from tests.test_mobile_combat import events


class ControlledDamageCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=50));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def build(self,duration=1000,*,shield=0,hp=None,character='1E2',interval=None):
        s=scene(duration,(0,-20));s['encounter']['participants']['A']['character']='1E5'
        s['encounter']['participants']['B']['character']=character
        s['encounter']['participants']['B']['initial_state']['shield']=shield
        if hp is not None:s['encounter']['participants']['B']['initial_state']['hp']=hp
        w=world(s,interval=interval);a=owner(w,until=duration)
        stream=w.controlled_damage.start(w.fighters['A'],a,'B',base_dps=900,until_ms=1000)
        return w,stream

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-ledger.amount(target=name)),D('1e-8'))
        return ledger

    def test_real_shared_hp_commit_uses_the_constriction_rate_without_bleed(self):
        w,stream=self.build();r=w.run();ledger=self.conserved(r)
        self.assertLess(abs(ledger.amount(actor='A')-D('743.75')),D('1e-9'))
        self.assertFalse(events(r,'bleeding_started'));self.assertEqual(stream.ended_at_ms,1000)
        self.assertEqual({e.contribution.kind for e in ledger.entries},{'constriction_tear'})

    def test_positive_shield_and_depletion_share_one_layer_timeline(self):
        w,stream=self.build(shield=100);r=w.run();ledger=self.conserved(r)
        self.assertEqual(D(r['final_states']['B']['shield']),0)
        self.assertLess(abs(D(r['metrics']['B']['shield_damage_received'])-100),D('1e-9'))
        self.assertLess(abs(ledger.amount(actor='A')-D('743.75')*D(8)/9),D('1e-8'))

    def test_regeneration_intercepts_pressure_at_zero_stock_before_armor(self):
        w,stream=self.build();w.shield_recovery['B'].add_impact(D(-20000),D(4000))
        r=w.run();ledger=self.conserved(r)
        # Existing shared recovery is 400/s; overflow is 500/s, post armor 218.75/s.
        self.assertLess(abs(ledger.amount(actor='A')-D('218.75')),D('1e-8'))
        self.assertLess(abs(D(r['metrics']['B']['shield_damage_received'])-400),D('1e-8'))
        self.assertEqual(D(r['final_states']['B']['shield']),0)

    def test_source_instability_recovers_during_the_stream(self):
        w,stream=self.build();w.fighters['A'].instability=D(80)
        r=w.run();ledger=self.conserved(r)
        ramp=D('71.2')-D(25)*150**2/(4*250)*(D(900)/880).ln()
        expected=ramp+D('743.75')*D('.92')
        self.assertLess(abs(ledger.amount(actor='A')-expected),D('1e-8'))

    def test_actual_beam_and_controlled_damage_mix_at_one_personal_shield(self):
        outcomes=[]
        for interval in (None,100,137):
            w,stream=self.build(shield=1000,interval=interval)
            # This world already exists, so add the ordinary beam caster in its input before construction.
            s=deepcopy(w.scenario);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
            s['encounter']['participants']['C'].update(character='1E1',position_m=[29,-18])
            s['action_selection']['C']=dict(s['action_selection']['A'],abilities=['4'],start_ms=0)
            w=world(s,interval=interval);a=owner(w)
            w.controlled_damage.start(w.fighters['A'],a,'B',base_dps=900,until_ms=1000)
            r=w.run();ledger=self.conserved(r)
            self.assertTrue(r['volume_instances'][0]['active']);self.assertEqual(D(r['final_states']['B']['shield']),0)
            self.assertTrue(any(e.contribution.kind=='heat' for e in ledger.entries))
            self.assertTrue(any(e.contribution.kind=='constriction_tear' for e in ledger.entries))
            outcomes.append(D(r['final_states']['B']['hp']))
        for hp in outcomes[1:]:self.assertLess(abs(hp-outcomes[0]),D('1e-8'))

    def test_actual_healing_and_revival_use_the_new_clipped_hp_history(self):
        w,stream=self.build(duration=3500,hp=500,character='2E4')
        # Put the real thrust target within its existing reach and enable its policy.
        s=deepcopy(w.scenario);s['encounter']['participants']['B']['position_m']=['1.1',-20]
        s['action_selection']['B']['start_ms']=0
        w=world(s);a=owner(w,until=3500);stream=w.controlled_damage.start(w.fighters['A'],a,'B',base_dps=900,until_ms=1000)
        r=w.run();ledger=self.conserved(r)
        self.assertTrue(events(r,'life_restored'));self.assertGreaterEqual(r['final_states']['B']['life_generation'],2)
        self.assertIsNotNone(stream.ended_at_ms);self.assertLess(stream.ended_at_ms,D(1000))
        self.assertTrue(any(e.contribution.kind=='constriction_tear' and e.target_life_generation==1 for e in ledger.entries))
        self.assertFalse(any(e.contribution.kind=='constriction_tear' and e.target_life_generation==2 for e in ledger.entries))


if __name__=='__main__':unittest.main()
