"""Current-source hook and explicit-world-target interactions on native physics.

Ordinary cases use public API inputs. Operations are labelled engineering
probes of lifetime, transfer, copying and displacement; no ability is invented.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.body_launch import directed_launch
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.spatial_transitions import SpatialChange
from tests.test_1e2_precision_projectile import scene as base_scene,run
from tests.test_binding_combat import run as probe_run
from tests.test_equilibrium_combat import rules
from tests.test_mobile_combat import command,events,PROFILES
from tests.test_world_colliders_combat import wall
from tests.test_grapple_links_combat import force
from tests.test_continuous_effort_combat import owner


def scene(duration=1800,*,ability='3',x=8,height='1.2',surface=True,no_enemy=True):
    s=base_scene(duration,distance=30);s['id']='actual_grappling_gun'
    s['encounter']['participants']['B']['position_m']=[30,-30]
    if no_enemy:s['encounter']['participants']['B']['team']='A'
    config=s['action_selection']['A'];config.update(abilities=[ability],reload_when_empty=False)
    config.pop('aim_part',None)
    target={'kind':'surface' if surface else 'world_point','point_m':[str(D(x)-D('.1')),-20,height]}
    if surface:target.update(collider_id='hookwall',part='panel')
    config['ability_targets']={ability:target}
    s['initial_colliders']=[wall('hookwall',x=x,hp=2000)]
    return s


def probe(s,operations):return probe_run(s,rules=rules(),operations=operations)


def beam_scene():
    s=scene(4000,no_enemy=False)
    s['action_selection']['A']['start_ms']=1873
    s['encounter']['participants']['B']['position_m']=[8,-17]
    c=deepcopy(s['encounter']['participants']['A']);c.update(character='1E1',position_m=[20,-30])
    s['encounter']['participants']['C']=c
    s['action_selection']['C']={'kind':'priority_when_ready','target':'nearest_living_enemy',
        'abilities':['4'],'reload_when_empty':False,'start_ms':0}
    return s


class DirectedLaunchTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_velocity_norm_and_independent_ballistic_endpoint(self):
        for target in ((10,4,3),(0,0,30),(0,0,-8),(10,0,-8)):
            with self.subTest(target=target):
                result=directed_launch((0,0,0),target,'25.6','9.81',precision=80)
                t=result.flight_time_ms/1000;v=result.velocity_mps
                actual=(v[0]*t,v[1]*t,v[2]*t-D('9.81')*t*t/2)
                self.assertTrue(all(abs(x-D(y))<D('1e-65') for x,y in zip(actual,target)))
                self.assertLess(abs(sum(x*x for x in v)-D('25.6')**2),D('1e-65'))

    def test_fast_arc_is_the_smaller_time_root(self):
        result=directed_launch((0,0,0),(30,0,0),'25.6','9.81',precision=80)
        b=D('25.6')**2;disc=b*b-D('9.81')**2*900
        slow=(2*(b+disc.sqrt())/D('9.81')**2).sqrt()
        self.assertLess(result.flight_time_ms/1000,slow)

    def test_caller_context_does_not_change_owned_precision(self):
        with localcontext(Context(prec=9)):a=directed_launch((0,0,0),(8,-2,1),'25.6','9.81')
        with localcontext(Context(prec=90)):b=directed_launch((0,0,0),(8,-2,1),'25.6','9.81')
        self.assertEqual(a,b)

    def test_invalid_and_unreachable_inputs_reject(self):
        for speed,g,target in ((True,10,(1,0,0)),(0,10,(1,0,0)),(20,0,(1,0,0)),(20,10,(1,0,'NaN'))):
            with self.subTest(values=(speed,g,target)),self.assertRaises(ValueError):directed_launch((0,0,0),target,speed,g)
        for target in ((0,0,0),(100,0,0),(0,0,40)):
            with self.subTest(target=target),self.assertRaises(UnsupportedMechanicError):directed_launch((0,0,0),target,20,10)


class GrapplingGunTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        damage=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            initial=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=name)
            self.assertLess(abs(initial-D(r['final_states'][name]['hp'])-damage.amount(target=name)),D('1e-8'))
        return damage

    def test_current_source_launch_phases_pay_twice_and_contact_once(self):
        r=run(scene());hook=r['grappling_hooks'][0];paid=events(r,'dyspnea_paid','A')
        self.assertEqual([e['phase'] for e in paid],['active_firing_end','active_start'])
        self.assertEqual(D(paid[0]['time_ms']),291)
        for e in paid:self.assertLess(abs(D(e['amount'])-(D('1.5')+D(e['before'])/100)**2),D('1e-35'))
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['3']),12291)
        self.assertEqual(D(events(r,'self_status_applied','A')[0]['time_ms']),261)
        self.assertEqual(hook['end_reason'],'body_contact');self.assertLess(D(hook['ended_at_ms']),D(hook['nominal_arrival_ms']))
        self.assertLess(abs(sum(D(v)**2 for v in hook['launch_velocity_mps'])-D('25.6')**2),D('1e-35'))
        arrived=events(r,'body_launch_contact','A');self.assertEqual(len(arrived),1)
        self.assertEqual(arrived[0]['self_effects'],{'disorientation':'305','instability':'355'})
        self.assertFalse(r['final_states']['A']['ammo'].get('3'));self.assertFalse(events(r,'reload_requested','A'))
        self.assertEqual(self.conserved(r).amount(),0);self.assertEqual(D(r['world_collider_states']['hookwall']['hp']),2000)

    def test_launch_owns_hands_and_locomotion_until_real_contact(self):
        r=run(scene(700));a=r['final_states']['A'];self.assertFalse(a['locomotion']['grounded'])
        self.assertGreater(D(a['position_m'][0]),0)
        resources=set(a['owned_actions'][0]['occupies'])
        self.assertEqual(resources,{'hand:left','hand:right','weapon:3','locomotion'})
        self.assertFalse(events(r,'body_launch_contact','A'));self.conserved(r)

    def test_native_contact_projects_on_actual_face_and_retires_anchor(self):
        r=run(scene());anchor=r['terrain_anchors'][0]
        self.assertEqual((anchor['collider_id'],anchor['part']),('hookwall','panel'))
        self.assertEqual(D(anchor['position_m'][0]),D('7.9'))
        self.assertEqual(anchor['status'],'ended');self.assertEqual(anchor['end_reason'],'body_contact')
        self.assertTrue(all(x['status']=='ended' for x in r['distance_constraints']))

    def test_world_point_uses_same_actual_hook_contact(self):
        r=run(scene(surface=False));self.assertEqual(r['grappling_hooks'][0]['end_reason'],'body_contact')
        self.assertEqual(events(r,'ability_started','A')[0]['target_snapshot']['kind'],'world_point')

    def test_real_ground_hook_downward_launch_has_one_native_contact(self):
        s=scene(surface=False);s['action_selection']['A']['ability_targets']['3']['point_m']=[2,-20,0]
        r=run(s);hook=r['grappling_hooks'][0]
        self.assertLess(D(hook['launch_velocity_mps'][2]),0)
        self.assertEqual(len(events(r,'body_launch_contact','A')),1)
        self.assertEqual(r['terrain_anchors'][0]['collider_id'],'ground');self.conserved(r)

    def test_real_overhead_hook_uses_native_ceiling_contact(self):
        s=scene(3200,surface=False);s['action_selection']['A']['ability_targets']['3']['point_m']=[0,-20,30]
        s['initial_colliders']=[wall('ceiling',x=0,hp=2000,size=(6,6,'.2'),z='30.1')]
        r=run(s);hook=r['grappling_hooks'][0]
        self.assertEqual(hook['end_reason'],'body_contact');self.assertEqual(len(events(r,'body_launch_contact','A')),1)
        self.assertGreater(D(hook['launch_velocity_mps'][2]),20)
        self.assertEqual(r['terrain_anchors'][0]['collider_id'],'ceiling');self.conserved(r)

    def test_actual_beam_breaks_the_anchor_during_flight_and_inertia_continues(self):
        r=run(beam_scene());hook=r['grappling_hooks'][0]
        self.assertEqual(hook['end_reason'],'hook_anchor_destroyed')
        self.assertEqual(r['world_collider_states']['hookwall']['status'],'destroyed')
        self.assertLess(D(hook['launched_at_ms']),D(hook['ended_at_ms']))
        self.assertLess(abs(D(hook['ended_at_ms'])-D(r['world_collider_states']['hookwall']['removed_at_ms'])),D('1e-20'))
        arrival=events(r,'body_launch_contact','A');self.assertEqual(len(arrival),1)
        self.assertGreater(D(arrival[0]['time_ms']),D(hook['ended_at_ms']));self.conserved(r)

    def test_an_existing_damage_shot_targets_world_surface_without_enemy(self):
        r=run(scene(400,ability='4'));flight=r['projectile_flights'][0]
        self.assertIsNone(flight['aim_target']);self.assertEqual(flight['collision_target'],'hookwall')
        self.assertLess(D(r['world_collider_states']['hookwall']['hp']),2000)
        self.assertEqual(set(r['final_states']),{'A','B'});self.conserved(r)

    def test_friendly_body_intercepts_hook_without_damage_or_launch(self):
        s=scene();s['encounter']['participants']['B']['position_m']=[5,-20];r=run(s)
        self.assertEqual(r['projectile_flights'][0]['collision_target'],'B')
        self.assertEqual(r['grappling_hooks'][0]['end_reason'],'hook_requires_solid_surface')
        self.assertFalse(events(r,'grappling_hook_launched'));self.assertNotIn('terrain_anchors',r)
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1);self.assertEqual(self.conserved(r).amount(),0)

    def test_real_block_stops_hook_without_an_owner_attachment(self):
        s=scene(no_enemy=False);b=s['encounter']['participants']['B'];b.update(character='2E4',position_m=[5,-20])
        s['action_selection']['B'].update(abilities=['basic_8'],start_ms=0,reload_when_empty=False)
        r=run(s);contacts=events(r,'projectile_body_collision','A')
        self.assertTrue(any('block_layer_id' in e for e in contacts));self.assertFalse(events(r,'grappling_hook_launched'))
        self.assertEqual(self.conserved(r).amount(),0)

    def test_actual_moving_source_range_rejects_distant_surface(self):
        r=run(scene(x=40));self.assertFalse(events(r,'grappling_hook_launched'))
        self.assertEqual(r['projectile_flights'][0]['terminal_reason'],'maximum_anchor_distance')
        self.assertTrue(events(r,'projectile_range_ended'));self.assertFalse(r['final_states']['A']['owned_actions'])

    def test_walking_can_bring_an_initially_distant_hook_within_rope_length(self):
        s=scene(2800,x=32);command(s,'A',0,'walk');r=run(s)
        self.assertTrue(events(r,'grappling_hook_launched'));self.assertEqual(len(events(r,'dyspnea_paid','A')),2)
        self.conserved(r)

    def test_anchor_removal_interrupts_control_but_keeps_owed_contact_effects(self):
        r=probe(scene(),((600,lambda w:w.collider_system.remove('hookwall',reason='hook_anchor_probe')),))
        hook=r['grappling_hooks'][0];self.assertEqual(hook['end_reason'],'hook_anchor_removed')
        self.assertEqual(len(events(r,'body_launch_contact','A')),1)
        self.assertGreater(D(events(r,'body_launch_contact','A')[0]['time_ms']),600)
        self.assertTrue(all(x['status']=='ended' for x in r['distance_constraints']));self.conserved(r)

    def test_removed_surface_intent_does_not_fabricate_an_anchor(self):
        r=probe(scene(),((200,lambda w:w.collider_system.remove('hookwall',reason='old_aim_probe')),))
        self.assertEqual(len(events(r,'projectile_released','A')),1)
        # With the wall gone this ballistic carrier later really hits ground.
        # That is a valid new receiver, not an anchor at its old wall intent.
        self.assertEqual(r['projectile_flights'][0]['collision_target'],'ground')
        self.assertTrue(all(a['collider_id']=='ground' for a in r['terrain_anchors']))

    def test_target_intent_is_frozen_before_later_policy_mutation(self):
        def change(w):w.scripted_targets.targets[('A','3')]['point_m']=(D(0),D(100),D(100))
        r=probe(scene(),((100,change),));self.assertEqual(r['projectile_flights'][0]['aim_point_m'],['7.9','-20','1.2'])
        self.assertEqual(r['grappling_hooks'][0]['end_reason'],'body_contact')

    def test_actual_incoming_gun_death_before_release_has_no_debit(self):
        s=scene(no_enemy=False);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=0;r=run(s)
        self.assertFalse(events(r,'projectile_released','A'));self.assertFalse(events(r,'dyspnea_paid','A'))
        self.assertFalse(r['final_states']['A']['alive']);self.conserved(r)

    def test_actual_incoming_gun_death_after_release_does_not_erase_carrier(self):
        s=scene(no_enemy=False);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=200;r=run(s)
        self.assertEqual(len(events(r,'projectile_released','A')),1);self.assertFalse(events(r,'grappling_hook_launched'))
        flight=next(f for f in r['projectile_flights'] if f['actor']=='A')
        self.assertEqual(flight['collision_target'],'hookwall');self.assertEqual(len(events(r,'dyspnea_paid','A')),1)
        self.conserved(r)

    def test_actual_incoming_gun_death_after_launch_retires_old_contact_obligation(self):
        s=scene(no_enemy=False);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=400;r=run(s)
        self.assertTrue(events(r,'grappling_hook_launched'));self.assertFalse(r['final_states']['A']['alive'])
        self.assertFalse(events(r,'body_launch_contact','A'));self.conserved(r)

    def test_upper_restriction_before_payment_cancels_firing(self):
        def restrict(w):w.apply_action_restriction('A',source='hook:upper_probe',functions=['upper_body'],until_ms=2000)
        r=probe(scene(),((250,restrict),));self.assertFalse(events(r,'projectile_released','A'))
        self.assertFalse(events(r,'dyspnea_paid','A'))

    def test_upper_restriction_after_release_keeps_carrier_without_launch(self):
        def restrict(w):w.apply_action_restriction('A',source='hook:upper_probe',functions=['upper_body'],until_ms=2000)
        r=probe(scene(),((350,restrict),));self.assertEqual(len(events(r,'dyspnea_paid','A')),1)
        self.assertEqual(r['projectile_flights'][0]['collision_target'],'hookwall');self.assertFalse(events(r,'grappling_hook_launched'))

    def test_upper_restriction_after_launch_does_not_erase_impact_obligation(self):
        def restrict(w):w.apply_action_restriction('A',source='hook:upper_probe',functions=['upper_body'],until_ms=2000)
        r=probe(scene(),((600,restrict),));self.assertEqual(len(events(r,'body_launch_contact','A')),1)
        self.assertEqual(len(events(r,'dyspnea_paid','A')),2);self.conserved(r)

    def test_real_jump_owns_locomotion_and_can_reject_launch_transfer(self):
        s=scene();command(s,'A',400,'jump');r=run(s)
        self.assertEqual(r['grappling_hooks'][0]['end_reason'],'launch_requirements_unavailable')
        self.assertFalse(events(r,'grappling_hook_launched'));self.assertTrue(events(r,'jump_takeoff','A'))
        self.assertEqual(len([e for e in events(r,'dyspnea_paid','A') if e['ability']=='3']),1)

    def test_fixed_filling_can_exhaust_capacity_before_launch(self):
        def fill(w):w.continuous_effort.start(w.fighters['A'],owner(w),tag='hook:fill_probe',kind='fill',base=2000,until_ms=600)
        r=probe(scene(),((330,fill),));self.assertEqual(r['grappling_hooks'][0]['end_reason'],'launch_requirements_unavailable')
        self.assertFalse(events(r,'grappling_hook_launched'));self.assertEqual(len(events(r,'dyspnea_paid','A')),1)

    def test_copied_hook_can_continue_one_owned_launch_only_once(self):
        def copy(w):w.projectile_system.copy(next(iter(w.projectile_flights)),source='hook:copy_probe',offset_m=(0,0,0))
        r=probe(scene(),((350,copy),));self.assertEqual(len(r['projectile_flights']),2)
        self.assertEqual(len(events(r,'grappling_hook_launched')),1);self.assertEqual(len(events(r,'dyspnea_paid','A')),2)
        self.assertEqual(len(events(r,'body_launch_contact','A')),1);self.conserved(r)

    def test_released_launch_payload_survives_later_profile_edits(self):
        def edit(w):
            a=w.fighters['A'].profile['abilities']['3'];a['hook']['launch_speed_multiplier']=100
            a['hook']['launch_dyspnea']['base_value']=99;a['hook']['arrival_self_effects']['instability']=9999
        r=probe(scene(),((350,edit),));launch=events(r,'grappling_hook_launched')[0]
        self.assertLess(abs(sum(D(v)**2 for v in launch['launch_velocity_mps'])-D('25.6')**2),D('1e-35'))
        self.assertEqual(events(r,'body_launch_contact','A')[0]['self_effects']['instability'],'355')

    def test_external_velocity_change_keeps_life_bound_contact_effects(self):
        s=scene();s['spatial_interventions']=[force(600,'A',velocity=(0,0,-2))]
        r=run(s);self.assertEqual(len(events(r,'body_launch_contact','A')),1)
        self.assertEqual(r['grappling_hooks'][0]['end_reason'],'external_velocity');self.conserved(r)

    def test_actual_jump_landing_obligation_survives_midair_hook_launch(self):
        s=scene();command(s,'A',0,'jump');r=run(s)
        self.assertTrue(events(r,'grappling_hook_launched'));self.assertEqual(len(events(r,'body_launch_contact','A')),1)
        self.assertEqual(len(events(r,'jump_landed','A')),1);self.conserved(r)

    def test_owned_contact_obligations_accumulate_in_a_later_voluntary_launch(self):
        # Labelled body API probe: use the actual existing source ability's
        # values, without adding a selectable character action.
        def relaunch(w):
            a=w.fighters['A'];w.launch_body(a,(0,0,2),allow_nonupward=True,
                contact_effects=(a.life_generation,'3',99999,D(305),D(355)))
        r=probe(scene(2200),((600,relaunch),));receipts=events(r,'body_launch_contact','A')
        self.assertEqual({e['action_id'] for e in receipts},{1,99999});self.assertEqual(len(receipts),2)

    def test_invalid_explicit_targets_and_launch_rules_reject_at_startup(self):
        for update in ({'kind':'surface','point_m':[8,-20,1],'collider_id':'hookwall','part':'panel'},
                {'kind':'world_point','point_m':[0,0,True]}, {'kind':'world_point','point_m':[0,0,'NaN']},
                {'kind':'surface','point_m':[0,0,0],'collider_id':'missing','part':'panel'}):
            s=scene();s['action_selection']['A']['ability_targets']['3']=update
            with self.subTest(update=update),self.assertRaises(ValueError):run(s)
        for key,value in (('maximum_m',-1),('launch_speed_multiplier',0)):
            p=deepcopy(PROFILES);p['1E2']['abilities']['3']['hook'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):run(scene(),profiles=p)

    def test_numerical_observation_and_actor_order_controls_preserve_real_launch(self):
        s=scene();a=run(s)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        for actor in a['final_states']:
            for field in ('hp','armor','shield','dyspnea','disorientation','instability'):
                self.assertLess(abs(D(a['final_states'][actor][field])-D(b['final_states'][actor][field])),D('1e-8'))
        self.assertEqual(a['grappling_hooks'][0]['end_reason'],b['grappling_hooks'][0]['end_reason'])
        self.assertEqual(a['projectile_flights'][0]['collided_at_ms'],b['projectile_flights'][0]['collided_at_ms'])
        self.conserved(a);self.conserved(b)
