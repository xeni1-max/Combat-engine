"""Ordinary deployed fields interact with the actual shared native turn owner."""
from copy import deepcopy
from decimal import Decimal as D
import unittest

from combat_sim.shared_engine import run_shared_scenario
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from tests.test_mobile_combat import read,events,PROFILES,command
from tests.test_actor_facing_combat import scene
from tests.test_native_turns import turn
from tests.test_world_colliders_combat import wall


def run(s,*,precision=70,interval=None):
    return run_shared_scenario(s,PROFILES,precision=precision,sample_interval_ms=interval,
        body_definition=read('data/body_hitboxes.json'),terrain_definition=read('data/terrain/stationary_arena.json'),
        movement_definition=read('data/movement/walk_run.json'),combat_locomotion_definition=read('data/movement/combat_locomotion.json'),
        projectile_physics_definition=read('data/physics/projectile_gravity.json'),
        jump_definition=read('data/movement/combat_jump.json'),climb_definition=read('data/movement/combat_climb.json'))


def third(s,x):
    s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
    s['encounter']['participants']['C'].update(position_m=[x,-20],facing='+x')
    s['action_selection']['C']=deepcopy(s['action_selection']['B'])
    s['action_selection']['C']['start_ms']=100000


def beam(cover=False):
    s=scene(1200,'1E1');s['id']='turning_beam_cover' if cover else 'turning_beam_edge'
    s['action_selection']['A'].update(abilities=['4'],start_ms=0,reload_when_empty=False)
    third(s,32 if cover else '37.25');turn(s,360,400,'C')
    if cover:s['initial_colliders']=[wall('roof',x=32,z=3,hp=None,size=('.6',2,'.2'),
        blocking={'projectiles':True,'bodies':True,'areas':True})]
    return s


def pause():
    s=scene(1200);s['id']='turning_pause_edge';s['action_selection']['A'].update(abilities=['2'],start_ms=0)
    third(s,'38.25');s['action_selection']['C']['start_ms']=0;turn(s,360,400,'C')
    return s


def fence():
    s=scene(1100);s['id']='turning_fence_edge';s['action_selection']['A'].update(abilities=['5'],start_ms=0)
    s['action_selection']['A']['ability_targets']={'5':{'kind':'world_point','point_m':[30,-20,0],'axis':'y'}}
    s['encounter']['participants']['B'].update(position_m=['30.3',-20],facing='+x')
    turn(s,360,400,'B');return s


def gas():
    from tests.test_launcher_combat import scene as launch
    s=launch(2200,shield=4000);s['id']='turning_released_gas_edge'
    third(s,'35.1');turn(s,360,1400,'C');return s


class TurningFieldTests(unittest.TestCase):
    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-ledger.amount(target=name)),D('1e-8'))

    def test_beam_exposure_enters_and_leaves_as_stationary_body_turns(self):
        r=run(beam());self.conserved(r)
        entered=[e for e in events(r,'heat_exposure_entered') if e['target']=='C']
        left=[e for e in events(r,'heat_exposure_left') if e['target']=='C']
        self.assertEqual(len(entered),2);self.assertEqual(len(left),2)
        self.assertTrue(events(r,'turn_completed','C'));self.assertLess(D(r['final_states']['C']['hp']),8140)

    def test_turning_under_real_cover_changes_heat_without_moving_reference(self):
        r=run(beam(True));self.conserved(r)
        entered=[e for e in events(r,'heat_exposure_entered') if e['target']=='C']
        self.assertEqual(len(entered),2);self.assertGreater(D(entered[0]['time_ms']),400)
        self.assertEqual(tuple(map(D,r['final_states']['C']['position_m'])),(32,-20))
        self.assertEqual(r['world_collider_states']['roof']['status'],'active')

    def test_pause_field_uses_actual_turning_body_union(self):
        r=run(pause());self.conserved(r)
        entered=[e for e in events(r,'cooldown_pause_entered') if e['target']=='C']
        left=[e for e in events(r,'cooldown_pause_left') if e['target']=='C']
        self.assertEqual(len(entered),2);self.assertEqual(len(left),2)
        self.assertTrue(events(r,'turn_completed','C'))

    def test_fence_turn_contact_applies_one_binding_and_interrupts_turn(self):
        r=run(fence());self.conserved(r)
        self.assertEqual(len(r['segment_field_contacts']),1);self.assertEqual(len(r['binding_instances']),1)
        self.assertEqual(len(r['released_damage_streams']),1)
        self.assertTrue(events(r,'turn_cancelled','B'));self.assertLess(D(r['final_states']['B']['hp']),8140)

    def test_actual_launcher_gas_uses_turning_sphere_membership(self):
        r=run(gas());self.conserved(r)
        self.assertTrue(events(r,'poison_grenade_detonated'))
        entered=[e for e in events(r,'poison_exposure_entered') if e['target']=='C']
        self.assertTrue(entered);self.assertLess(D(r['final_states']['C']['hp']),8140)
        self.assertTrue(events(r,'turn_completed','C'))

    def test_source_death_leaves_deployed_beam_and_turning_recipient_independent(self):
        s=beam();s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=400
        r=run(s);self.conserved(r)
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertTrue(events(r,'turn_completed','C'));self.assertLess(D(r['final_states']['C']['hp']),8140)
        self.assertEqual(r['volume_instances'][0]['source_life_generation'],1)
        self.assertTrue(r['volume_instances'][0]['active'])

    def test_walking_and_turning_share_one_reference_through_beam_entry(self):
        s=beam();s['encounter']['participants']['C']['movement_direction']=[-1,0]
        command(s,'C',500,'walk');r=run(s);self.conserved(r)
        self.assertTrue(events(r,'turn_completed','C'))
        self.assertLess(D(r['final_states']['C']['position_m'][0]),D('37.25'))
        self.assertTrue([e for e in events(r,'heat_exposure_entered') if e['target']=='C'])

    def test_crouch_pose_and_turn_keep_field_geometry_on_the_same_phase_knots(self):
        s=beam();command(s,'C',350,'crouch');r=run(s);self.conserved(r)
        self.assertEqual(r['metrics']['C']['crouches_completed'],1)
        self.assertTrue(events(r,'turn_completed','C'))
        self.assertEqual(D(r['final_states']['C']['locomotion']['feet_z_m']),0)
        self.assertLess(D(r['final_states']['C']['hp']),8140)

    def test_overlapping_pause_sources_keep_one_work_clock(self):
        s=pause();third_actor=deepcopy(s['encounter']['participants']['A'])
        third_actor['position_m']=[0,-24];s['encounter']['participants']['D']=third_actor
        s['action_selection']['D']=deepcopy(s['action_selection']['A'])
        r=run(s);self.conserved(r)
        self.assertEqual(len(r['cooldown_pause_volumes']),2)
        for kind in ('cooldown_pause_entered','cooldown_pause_left'):
            rows=[e for e in events(r,kind) if e['target']=='C']
            self.assertEqual(len(rows),4)
        self.assertTrue(events(r,'projectile_released','C'))


if __name__=='__main__':unittest.main()
