"""Native link/turn interactions plus labelled public distance attachments."""
from copy import deepcopy
from dataclasses import replace
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.angular_paths import RotatingBoxPath,YawArc
from combat_sim.angular_resting import contact_departure
from combat_sim.box_motion import touching_normals
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.knockback import KnockbackBody,resist_knockback
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import projected_size
from combat_sim.shared_engine import SharedEncounter
from tests.test_mobile_combat import read,PROFILES,command,events
from tests.test_actor_facing_combat import scene
from tests.test_native_turns import turn
from tests.test_grapple_links_combat import force,attach as rigid_attach
from tests.test_world_colliders_combat import wall

EPS=F('1e-20')
INPUTS={'body_definition':'data/body_hitboxes.json','terrain_definition':'data/terrain/stationary_arena.json',
 'movement_definition':'data/movement/walk_run.json','combat_locomotion_definition':'data/movement/combat_locomotion.json',
 'projectile_physics_definition':'data/physics/projectile_gravity.json','jump_definition':'data/movement/combat_jump.json',
 'climb_definition':'data/movement/combat_climb.json'}


def run(s,*,operations=(),precision=70,interval=None):
    class Probe(SharedEncounter):
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw)
            for i,op in enumerate(operations):self.push(op['at_ms'],'turn_link_engineering',{'index':i},priority=4)
        def _process(self,kind,p):
            if kind!='turn_link_engineering':return super()._process(kind,p)
            op=operations[p['index']]
            if op['kind']!='distance':raise ValueError('Unknown labelled link probe')
            first,second=op.get('first','A'),op.get('second','B')
            self.distance_constraints.attach(first,second,maximum_m=op['length'],expires_at_ms=op.get('expiry',self.horizon+100),
                source='engineering:turn_link_probe',expected_lives={n:self.fighters[n].life_generation for n in (first,second)})
            self.log('turn_link_engineering_attachment',operation=deepcopy(op))
    with localcontext(Context(prec=precision)):
        return Probe(s,PROFILES,precision=precision,sample_interval_ms=interval,
            **{key:read(path) for key,path in INPUTS.items()}).run()


def hold():
    from tests.test_grapple_casts_combat import scene as grab
    s=grab(900);s['id']='turning_actual_hold';turn(s,90,400);return s


def charge():
    from tests.test_charge_grapple_combat import scene as grab
    s=grab(1400);s['id']='turning_charge_hold';turn(s,90,700);return s


def chain():
    from tests.test_chain_cast_combat import scene as cast
    s=cast(1800,distance=19);s['id']='turning_actual_chain'
    s['encounter']['participants']['B']['movement_direction']=[1,0]
    command(s,'B',1000,'run');turn(s,360,1300,'B');return s


def fixed():
    from tests.test_ground_chain_combat import scene as cast
    s=cast(2800);s['id']='turning_actual_fixed_chain'
    s['encounter']['participants']['B']['movement_direction']=[1,0]
    command(s,'B',900,'run');turn(s,360,2200,'B');return s


def cached_return():
    s=scene(300);s['id']='turning_contact_departure_and_return'
    s['encounter']['participants']['A']['facing']={'yaw_degrees':'88.5'}
    with localcontext(Context(prec=90)):
        frame=YawFrame.from_degrees('88.5',precision=80)
        reach=D('.35')*D(frame.sine.numerator)/D(frame.sine.denominator)+D('.05')*D(frame.cosine.numerator)/D(frame.cosine.denominator)
        x=str(reach+D('.01')+D('.05'))
    s['initial_colliders']=[wall('contact_wall',x=x,size=('.1',4,3),hp=None)]
    s['spatial_interventions']=[force(0,'A',[1,0,0]),force(105,'B',[1,0,0])]
    turn(s,3,100)
    return s,[dict(at_ms=0,kind='distance',length=30)]


def tangent():
    s=scene(250);s['id']='turning_taut_tangent'
    s['spatial_interventions']=[force(0,'B',[0,4,0])];turn(s,90,0,'B')
    return s,[dict(at_ms=0,kind='distance',length=30)]


def pressure():
    s,ops=cached_return();s['id']='turning_cached_pressure_contact';turn(s,3,140)
    return s,ops


def rigid_wall():
    s=scene(250);s['id']='turning_rigid_wall'
    s['encounter']['participants']['B']['position_m']=[0,-22]
    s['spatial_interventions']=[rigid_attach(),force(0,'A',[2,0,0])];turn(s,90,0)
    s['initial_colliders']=[wall('held_wall',x='.4',size=('.1',1,3),hp=None)]
    return s


def hook():
    from tests.test_grappling_gun import scene as cast
    s=cast(1200);s['id']='turning_actual_hook';turn(s,90,400);return s


def expiry():
    s,ops=tangent();s['id']='turning_tether_expiry';s['encounter']['duration_ms']=400
    ops[0]['expiry']=125;return s,ops


def knock_hold():
    from tests.test_knock_motion_combat import scene as punch
    s=punch(700);s['id']='turning_held_pair_knock'
    s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
    s['encounter']['participants']['C'].update(character='1E5',position_m=['2.2',-20],facing='-x')
    s['action_selection']['C']=dict(s['action_selection']['A'],abilities=['2'])
    turn(s,90,220,'C');return s


class TurningLinkTests(unittest.TestCase):
    def conserved(self,r):
        damage=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            hp=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=name)
            self.assertLess(abs(hp-D(r['final_states'][name]['hp'])-damage.amount(target=name)),D('1e-8'))

    def test_actual_grab_retains_hold_damage_and_effort_through_owner_turn(self):
        r=run(hold());self.conserved(r)
        self.assertTrue(events(r,'turn_completed','A'));self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertTrue(r['controlled_damage_streams']);self.assertTrue(r['continuous_effort_channels'])
        self.assertFalse(events(r,'body_contact'))

    def test_actual_charge_turn_preserves_joint_translation_and_frozen_motor(self):
        r=run(charge());self.conserved(r)
        self.assertTrue(events(r,'turn_completed','A'));self.assertEqual(r['grapple_holds'][0]['status'],'active')
        a,b=r['final_states']['A'],r['final_states']['B']
        self.assertEqual(a['locomotion']['velocity_mps'],b['locomotion']['velocity_mps'])
        self.assertGreater(D(a['position_m'][0]),5);self.assertEqual(D(a['position_m'][1]),-20)
        offset=r['grapple_links'][0]['reference_offset_m']
        # Pose/balance offsets move body centres independently of the upright
        # link reference. Heading must preserve its world-space XY offset.
        for p,q,d in zip(a['position_m'],b['position_m'],offset):self.assertLess(abs(D(q)-D(p)-D(d)),D('1e-8'))

    def test_actual_chain_runs_taut_while_its_recipient_turns(self):
        r=run(chain());self.conserved(r)
        self.assertTrue(r['binding_instances']);self.assertTrue(r['distance_path_steps_planned'])
        self.assertTrue(events(r,'turn_started','B'));self.assertEqual(r['distance_constraints'][0]['status'],'active')
        a,b=r['final_states']['A'],r['final_states']['B']
        self.assertLessEqual(sum((D(x)-D(y))**2 for x,y in zip(a['body_origin_m'],b['body_origin_m'])),400+D('1e-8'))

    def test_actual_fixed_ground_chain_remains_taut_through_turn(self):
        r=run(fixed());self.conserved(r)
        self.assertTrue(r['distance_constraints']);self.assertTrue(r['distance_path_steps_planned'])
        self.assertTrue(events(r,'turn_started','B'));self.assertEqual(r['distance_constraints'][0]['status'],'active')
        anchor=r['terrain_anchors'][0]['position_m'];point=r['final_states']['B']['body_origin_m']
        self.assertLessEqual(sum((D(x)-D(y))**2 for x,y in zip(anchor,point)),100+D('1e-8'))

    def test_taut_tangent_and_turn_keep_finite_certificates(self):
        s,ops=tangent();r=run(s,operations=ops);self.conserved(r)
        self.assertTrue(r['distance_path_steps_planned']);self.assertTrue(events(r,'turn_started','B'))
        for row in r['last_committed_distance_plan']['bernstein_certificate']:
            self.assertTrue(all(F(x)<=0 for x in row['distance_squared_minus_limit_squared']))

    def test_rotation_departure_between_equal_endpoints_retires_cached_plane(self):
        s,ops=cached_return();r=run(s,operations=ops);self.conserved(r)
        hits=[e for e in events(r,'body_contact') if e['second']=='contact_wall']
        self.assertEqual(len(hits),2);self.assertLess(D(hits[0]['time_ms']),100);self.assertGreater(D(hits[1]['time_ms']),105)
        self.assertGreater(D(hits[1]['raw_status']),0);self.assertTrue(events(r,'turn_completed','A'))

    def test_turn_back_into_cached_wall_keeps_angular_impact_and_stops_tethered_pair(self):
        s,ops=pressure();r=run(s,operations=ops);self.conserved(r)
        hits=events(r,'body_contact');self.assertEqual(len(hits),3)
        self.assertGreater(D(hits[-1]['raw_status']),20)
        self.assertEqual(events(r,'turn_cancelled','A')[0]['reason'],'body_contact')
        for n in ('A','B'):
            self.assertTrue(all(D(v)==0 for v in r['final_states'][n]['locomotion']['velocity_mps']))
        self.assertEqual(r['distance_constraints'][0]['status'],'active')

    def test_angular_wall_impact_transmits_blocked_motion_to_rigid_partner(self):
        r=run(rigid_wall());self.conserved(r)
        hits=events(r,'body_contact');self.assertEqual(len(hits),1)
        self.assertEqual(hits[0]['first'],'A');self.assertGreater(D(hits[0]['raw_status']),100)
        self.assertEqual(events(r,'turn_cancelled','A')[0]['reason'],'body_contact')
        self.assertEqual(r['grapple_links'][0]['status'],'active')
        for n in ('A','B'):
            self.assertTrue(all(D(v)==0 for v in r['final_states'][n]['locomotion']['velocity_mps']))
        self.assertEqual(D(r['metrics']['B']['collision_stops']),0)

    def test_real_hook_launch_keeps_rope_and_paid_contact_lifetimes_during_turn(self):
        r=run(hook());self.conserved(r);row=r['grappling_hooks'][0]
        self.assertLess(D(row['launched_at_ms']),D(events(r,'turn_completed','A')[0]['time_ms']))
        self.assertEqual(row['end_reason'],'body_contact')
        self.assertEqual(r['distance_constraints'][0]['end_reason'],'body_contact')
        self.assertEqual(len([e for e in events(r,'dyspnea_paid','A') if e['ability']=='3']),2)
        self.assertEqual(len([e for e in events(r,'body_contact') if e['second']=='hookwall']),1)
        self.assertTrue(events(r,'jump_landed','A'))

    def test_hook_turn_clearance_and_get_up_match_precision_order_and_observations(self):
        a=run(hook(),precision=50,interval=100);s=hook()
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        for r in (a,b):
            self.conserved(r);self.assertTrue(events(r,'get_up_started','A'))
            self.assertFalse(events(r,'get_up_waiting_for_clearance','A'))
        for k in ('dyspnea','disorientation','instability'):
            self.assertLess(abs(D(a['final_states']['A'][k])-D(b['final_states']['A'][k])),D('1e-8'))
        for x,y in zip(a['final_states']['A']['body_origin_m'],b['final_states']['A']['body_origin_m']):
            self.assertLess(abs(D(x)-D(y)),D('1e-8'))

    def test_real_hook_wall_tangency_allows_get_up_to_finish(self):
        s=hook();s['encounter']['duration_ms']=1600;r=run(s,precision=50);self.conserved(r)
        self.assertEqual(r['metrics']['A']['get_ups_completed'],1)
        self.assertFalse(r['final_states']['A']['knocked_down'])
        self.assertEqual(len([e for e in events(r,'body_contact') if e['second']=='hookwall']),1)

    def test_tether_expiry_does_not_cancel_turn_or_remove_transmitted_inertia(self):
        s,ops=expiry();r=run(s,operations=ops);self.conserved(r)
        row=r['distance_constraints'][0]
        self.assertEqual((row['end_reason'],D(row['ended_at_ms'])),('expired',D(125)))
        self.assertEqual(D(events(r,'turn_completed','B')[0]['time_ms']),310)
        self.assertGreater(D(r['final_states']['A']['locomotion']['velocity_mps'][0]),0)
        self.assertFalse(events(r,'body_contact'))

    def test_turning_charge_hold_still_delivers_its_actual_victim_wall_fracture(self):
        from tests.test_charge_grapple_combat import panel
        s=charge();panel(s,'turning_victim_wall',10)
        r=run(s);self.conserved(r)
        self.assertTrue(r['charge_wall_slams']);self.assertTrue(r['charge_wall_slams'][0]['wall_fractured'])
        self.assertEqual(r['world_collider_states']['turning_victim_wall']['status'],'destroyed')
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertTrue(events(r,'turn_started','A'))

    def test_rigid_group_turn_changes_heading_without_rotating_reference_offset(self):
        s=scene(500);s['encounter']['participants']['B']['position_m']=[0,-22]
        s['spatial_interventions']=[rigid_attach(),force(0,'A',[2,0,0])];turn(s,90,50)
        r=run(s);self.conserved(r)
        self.assertEqual(r['grapple_links'][0]['status'],'active');self.assertTrue(events(r,'turn_completed','A'))
        a,b=r['final_states']['A'],r['final_states']['B']
        self.assertLess(abs(D(a['position_m'][0])-D(b['position_m'][0])),D('1e-8'))
        self.assertEqual(D(b['position_m'][1])-D(a['position_m'][1]),-2)

    def test_actual_heavy_knock_keeps_summed_stats_of_turning_held_pair(self):
        r=run(knock_hold());self.conserved(r);k=r['knock_impulses'][0]
        self.assertEqual(k['assessment']['actors'],['B','C'])
        expected=resist_knockback(15,tuple(KnockbackBody(n,PROFILES[r['initial_states'][n]['character']]['max_hp'],
            D(r['initial_states'][n]['armor'])) for n in ('B','C')),precision=70)
        self.assertEqual(D(k['assessment']['resisted_m']),expected.resisted_m)
        self.assertTrue(events(r,'turn_started','C'))

    def test_precision_reversed_order_and_observations_keep_taut_motion(self):
        s,ops=tangent();a=run(s,operations=ops)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,operations=ops,precision=80,interval=17)
        for n in ('A','B'):
            for x,y in zip(a['final_states'][n]['body_origin_m'],b['final_states'][n]['body_origin_m']):
                self.assertLess(abs(D(x)-D(y)),D('1e-8'))


class RestingContactRegionTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def path(self,*,angle=90,frame=YawFrame(F(4,5),F(3,5)),centre=(0,1,1),reference=(0,0,0),velocity=(0,0,0),acceleration=(0,0,0)):
        return RotatingBoxPath(BodyPathPiece(0,1000,reference,velocity,acceleration),YawArc(0,1,frame,angle,70),Cuboid('part',centre,('.2','.8',1)))

    def test_departing_wall_token_crosses_the_existing_contact_band(self):
        p=self.path();box=p.at_time(0);edge=box.centre_m[0]+projected_size(box,(1,0,0))/2
        wallbox=Cuboid('wall',(edge+F('.1'),0,1),('.2',8,8))
        loss=contact_departure(p,wallbox,(-1,0,0),0,1,distance_epsilon=EPS,precision=70)
        self.assertGreater(loss,0);self.assertLess(loss,F('1e-16'))
        self.assertNotIn((-1,0,0),touching_normals(p.at_time(loss),wallbox,distance_epsilon=EPS))

    def test_ceiling_reaction_lasts_until_real_footprint_loss(self):
        p=self.path(angle=90,frame=YawFrame(),centre=(0,1,F('.5')))
        roof=Cuboid('roof',(1,0,F('1.5')),('.4','.4',1))
        loss=contact_departure(p,roof,(0,0,-1),0,1,distance_epsilon=EPS,precision=70)
        self.assertIsNotNone(loss);self.assertGreater(loss,0);self.assertLess(loss,F('.3'))

    def test_common_translation_and_gravity_do_not_invent_departure(self):
        a=self.path(angle=0,frame=YawFrame(),centre=(0,0,0),velocity=(1,2,0),acceleration=(F('.3'),F('.4'),F('-9.81')))
        b=replace(a,reference=BodyPathPiece(0,1000,(F('.8'),0,0),(1,2,0),(F('.3'),F('.4'),F('-9.81'))))
        self.assertIsNone(contact_departure(a,b,(-1,0,0),0,1,distance_epsilon=EPS,precision=70))

    def test_initial_closed_contact_uses_a_confirmed_departure_clock(self):
        p=self.path(angle=0,frame=YawFrame(),centre=(0,0,0),reference=(-EPS+F('1e-30'),0,0),velocity=(-1,0,0))
        other=Cuboid('wall',(F('.5'),0,0),('.2','.8',1))
        loss=contact_departure(p,other,(-1,0,0),0,F('1e-25'),distance_epsilon=EPS,precision=70)
        self.assertGreater(loss,0);self.assertLess(loss,F('1e-27'))


if __name__=='__main__':unittest.main()
