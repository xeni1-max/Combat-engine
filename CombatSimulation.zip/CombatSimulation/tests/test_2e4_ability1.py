"""One base venomous thrust: no shield, overlap, other actions, or death."""

from copy import deepcopy
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario
from combat_sim import venomous_engine
from combat_sim.models import UnsupportedMechanicError

ROOT = Path(__file__).resolve().parents[1]
CHARACTERS = json.loads((ROOT / "data/characters.json").read_text())["characters"]
SCENARIO = json.loads((ROOT / "scenarios/2e4_venomous_thrust.json").read_text())


class VenomousThrustTests(unittest.TestCase):
    def test_full_damage_breakdown_and_final_state(self):
        run = run_scenario(SCENARIO, CHARACTERS)
        summary = summarize(run)
        # Slash 412.5; bleed 41.25; venom 2*(5997/14); total 36693/28.
        self.assertEqual(summary["direct_hp_damage"]["exact"], "825/2")
        self.assertEqual(summary["damage_by_effect"]["bleeding"]["exact"], "165/4")
        self.assertEqual(summary["damage_by_effect"]["venom"]["exact"], "5997/7")
        self.assertEqual(summary["hp_damage"]["exact"], "36693/28")
        self.assertEqual(summary["nominal_hp_damage"]["exact"], "36693/28")
        self.assertEqual(summary["excess_hp_damage"]["exact"], "0")
        self.assertEqual(summary["final_hp"]["exact"], "191227/28")
        self.assertEqual(summary["armor_lost"]["exact"], "26429/3080")
        self.assertEqual(summary["final_armor"]["exact"], "435571/3080")
        self.assertEqual(summary["impact_count"], 1)

    def test_attachment_exposure_decay_and_bleed_end_times(self):
        run = run_scenario(SCENARIO, CHARACTERS)
        expected = {"impact_resolved": 230, "active_completed": 320,
                    "blade_detached": 1230, "venom_expired": 2230, "bleeding_expired": 8230}
        for kind, time in expected.items():
            self.assertEqual([e["time_ms"] for e in run["events"] if e["type"] == kind], [time])
        self.assertEqual(run["run_until_ms"], 8230)
        self.assertEqual(run["active_continuous_effects_final"], [])

    def test_continuous_intervals_have_exact_analytic_components(self):
        run = run_scenario(SCENARIO, CHARACTERS)
        intervals = [e for e in run["events"] if e["type"] == "continuous_damage_resolved"]
        self.assertEqual([(e["interval_start_ms"], e["interval_end_ms"]) for e in intervals], [(230, 1230), (1230, 2230), (2230, 8230)])
        self.assertEqual([e["components"]["venom"]["amount"]["exact"] for e in intervals], ["5997/14", "5997/14", "0"])
        self.assertEqual([e["components"]["bleeding"]["amount"]["exact"] for e in intervals], ["2475/256", "2145/256", "1485/64"])
        self.assertEqual([e["components"]["venom"]["phase"] for e in intervals], ["growing_exposure", "non_exposure_decay", "inactive"])
        self.assertTrue(all("not a damage tick" in e["damage_payment"] for e in intervals))

    def test_damage_precedes_new_self_instability(self):
        run = run_scenario(SCENARIO, CHARACTERS)
        hit = next(e for e in run["events"] if e["type"] == "impact_resolved")
        self.assertEqual(hit["damage_calculation"]["instability_before_new_self_effect"], "0")
        self.assertEqual(hit["damage_calculation"]["incoming_damage"]["exact"], "440")
        self.assertEqual(hit["damage_calculation"]["outputs"]["y"]["exact"], "825/2")
        self_effects = [e for e in run["events"] if e["type"] == "status_applied" and e["origin"] == "self"]
        self.assertEqual([Decimal(e["after"]["decimal"]) for e in self_effects], [150, 150])
        self.assertTrue(all(run["events"].index(hit) < run["events"].index(e) for e in self_effects))
        active_end = next(e for e in run["events"] if e["type"] == "active_completed")
        self.assertEqual(Decimal(active_end["actor_state"]["disorientation"]["decimal"]), 60)
        self.assertEqual(Decimal(active_end["actor_state"]["instability"]["decimal"]), 60)

    def test_target_status_and_venom_use_pre_hit_armor(self):
        run = run_scenario(SCENARIO, CHARACTERS)
        target_effects = [e for e in run["events"] if e["type"] == "status_applied" and e["target"] == "1E1"]
        self.assertEqual(len(target_effects), 2)
        self.assertTrue(all(e["inputs"]["a"] == "150" for e in target_effects))
        self.assertTrue(all(Decimal(e["after"]["decimal"]) == Decimal("65.8639544836367369325407919063226113655") for e in target_effects))
        attachment = next(e for e in run["events"] if e["type"] == "blade_attached")
        self.assertEqual(attachment["venom_delivery_snapshot"]["a_before_thrust"], "150")
        self.assertEqual(attachment["venom_delivery_snapshot"]["d_after_shield_before_armor"], "440")
        detach = next(e for e in run["events"] if e["type"] == "blade_detached")
        self.assertEqual(Fraction(detach["peak_venom_rate"]["coefficient"]), Fraction(17991, 28))

    def test_later_armor_loss_does_not_recalculate_existing_venom(self):
        # Test instrumentation only: inject armor loss after the initial hit,
        # before venom's exposure/recovery intervals resolve. This does not
        # add an armor-change action or overlapping combat to the public model.
        advance = venomous_engine._advance_statuses

        def advance_with_later_armor_loss(states, start, end, log):
            advance(states, start, end, log)
            if end == 320:
                states["1E1"].armor = Fraction(0)

        with patch.object(venomous_engine, "_advance_statuses", side_effect=advance_with_later_armor_loss):
            run = run_scenario(SCENARIO, CHARACTERS)

        self.assertEqual(run["final_states"]["1E1"]["armor"]["exact"], "0")
        intervals = [e for e in run["events"] if e["type"] == "continuous_damage_resolved"]
        self.assertEqual([e["components"]["venom"]["delivery_snapshot"]["a_before_thrust"] for e in intervals], ["150"] * 3)
        self.assertEqual([e["components"]["venom"]["amount"]["exact"] for e in intervals], ["5997/14", "5997/14", "0"])
        self.assertEqual(sum(Fraction(e["components"]["venom"]["amount"]["exact"]) for e in intervals), Fraction(5997, 7))

    def test_new_application_captures_its_own_starting_armor(self):
        # Separate isolated runs, not a claim that overlapping hits execute.
        first = run_scenario(SCENARIO, CHARACTERS)
        reduced_armor = Fraction(first["final_states"]["1E1"]["armor"]["exact"])
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"]["armor"] = reduced_armor
        second = run_scenario(scenario, CHARACTERS)
        attachment = next(e for e in second["events"] if e["type"] == "blade_attached")
        self.assertEqual(attachment["venom_delivery_snapshot"]["a_before_thrust"], str(reduced_armor))
        self.assertGreater(Fraction(summarize(second)["damage_by_effect"]["venom"]["exact"]), Fraction(5997, 7))
        self.assertEqual(summarize(first)["damage_by_effect"]["venom"]["exact"], "5997/7")

    def test_target_effects_decay_and_self_effects_ignore_resistance(self):
        characters = deepcopy(CHARACTERS)
        characters["2E4"]["status_resistance"] = 100000
        run = run_scenario(SCENARIO, characters)
        self_effects = [e for e in run["events"] if e["type"] == "status_applied" and e["origin"] == "self"]
        self.assertTrue(all(Decimal(e["applied_increment"]["decimal"]) == 150 for e in self_effects))
        for state in run["final_states"].values():
            self.assertEqual(Decimal(state["disorientation"]["decimal"]), 0)
            self.assertEqual(Decimal(state["instability"]["decimal"]), 0)

    def test_comparison_against_3e5(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"].pop("1E1")
        scenario["encounter"]["initial_states"]["3E5"] = {"hp": 11400, "armor": 250, "shield": 0}
        scenario["action_sequence"][0]["target"] = "3E5"
        result = summarize(run_scenario(scenario, CHARACTERS))
        self.assertEqual(result["direct_hp_damage"]["exact"], "7475/22")
        self.assertEqual(result["hp_damage"]["exact"], "3540459/3388")
        self.assertEqual(result["final_hp"]["exact"], "35082741/3388")

    def test_gathering_uses_current_initial_disorientation(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["2E4"]["disorientation"] = 80
        run = run_scenario(scenario, CHARACTERS)
        hit = next(e for e in run["events"] if e["type"] == "impact_resolved")
        self.assertEqual(hit["time_ms"], 310)
        self.assertEqual(hit["timing_calculation"]["effective_gathering_ms"], 220)
        self.assertEqual(run["run_until_ms"], 8310)
        self.assertEqual(summarize(run)["hp_damage"]["exact"], "36693/28")

    def test_replay_and_decimal_context_independence(self):
        scenario, characters = deepcopy(SCENARIO), deepcopy(CHARACTERS)
        expected = run_scenario(scenario, characters)
        for precision, rounding in ((10, ROUND_FLOOR), (60, ROUND_CEILING)):
            with self.subTest(precision=precision), localcontext() as context:
                context.prec, context.rounding = precision, rounding
                run = run_scenario(scenario, characters)
                self.assertEqual(run, expected)
                self.assertEqual(summarize(run)["hp_damage"]["exact"], "36693/28")
        self.assertEqual(scenario, SCENARIO)
        self.assertEqual(characters, CHARACTERS)
        self.assertEqual([e["time_ms"] for e in expected["events"]], sorted(e["time_ms"] for e in expected["events"]))

    def test_shielded_delivery_and_initial_instability_are_explicitly_unsupported(self):
        for shield, instability in ((1, 0), (4000, 0), (0, 1)):
            with self.subTest(shield=shield, instability=instability):
                scenario = deepcopy(SCENARIO)
                scenario["encounter"]["initial_states"]["1E1"]["shield"] = shield
                scenario["encounter"]["initial_states"]["2E4"]["instability"] = instability
                with self.assertRaises(UnsupportedMechanicError):
                    run_scenario(scenario, CHARACTERS)

    def test_nonlethal_scope_does_not_invent_death_timing(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"]["hp"] = 1000
        with self.assertRaisesRegex(UnsupportedMechanicError, "nonlethal"):
            run_scenario(scenario, CHARACTERS)

    def test_complete_effect_scope_rejects_truncated_runs(self):
        scenario = deepcopy(SCENARIO)
        scenario["run_until_ms"] = 2230
        with self.assertRaisesRegex(ValueError, "eight seconds"):
            run_scenario(scenario, CHARACTERS)

    def test_repeated_activations_and_unsupported_inputs_are_rejected(self):
        for kind in ("repeat", "movement", "action", "state"):
            with self.subTest(kind=kind):
                scenario = deepcopy(SCENARIO)
                if kind == "repeat":
                    scenario["action_sequence"].append(deepcopy(scenario["action_sequence"][0]))
                elif kind == "movement":
                    scenario["encounter"]["movement"] = "running"
                elif kind == "action":
                    scenario["action_sequence"][0]["target_distance_m"] = 1
                else:
                    scenario["encounter"]["initial_states"]["2E4"]["dyspnea"] = 0
                with self.assertRaises(UnsupportedMechanicError):
                    run_scenario(scenario, CHARACTERS)

    def test_missing_toxin_resistance_is_not_treated_as_zero(self):
        characters = deepcopy(CHARACTERS)
        characters["1E1"]["resistances"].pop("toxin")
        with self.assertRaisesRegex(UnsupportedMechanicError, "toxin resistance"):
            run_scenario(SCENARIO, characters)

    def test_unsupported_rule_modes_are_not_silently_substituted(self):
        for field, value in (("venom_armor_snapshot", "live_armor"),
                             ("target_status_armor_snapshot", "after_armor_loss"),
                             ("venom_damage_input", "original_damage_before_shields"),
                             ("damage_payment", "ticks")):
            with self.subTest(field=field):
                characters = deepcopy(CHARACTERS)
                characters["2E4"]["abilities"]["1"][field] = value
                with self.assertRaises(UnsupportedMechanicError):
                    run_scenario(SCENARIO, characters)
