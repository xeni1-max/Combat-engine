"""Real attacks connect effort, controlled actions, flights and damage receipts.

The few explicit API operations probe exact phase boundaries or future copying
interactions. Ordinary authored gun/Qard/beam casts supply the damage; fixtures
do not claim a new character ability.

These numerical/phase contracts select the pre-equilibrium rules explicitly.
Current selected-rule interactions are covered in test_equilibrium_interactions.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE, MOBILE_SCOPE
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events, read, scenario
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_world_colliders_combat import wall

CURRENT = read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json')


def scene(horizon=1000, *, a_start=0, b_start=100000, qard=False, gravity=True):
    s = scenario(horizon, fire_at=a_start)
    s['scope'] = dict(GRAVITY_MOBILE_SCOPE if gravity else MOBILE_SCOPE)
    s['action_selection']['B']['start_ms'] = b_start
    if qard:
        s['encounter']['participants']['A']['character'] = '1E1'
        s['action_selection']['A']['reload_when_empty'] = False
    return s


def run(s, *, operations=(), profiles=PROFILES, effects=CURRENT, interval=None, precision=50):
    class Fixture(SharedEncounter):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for when, op in operations:
                self.push(D(when), 'fixture_effort', op, priority=op.get('priority', 2))

        def _process(self, kind, p):
            if kind != 'fixture_effort':
                return super()._process(kind, p)
            target = p.get('target', 'A')
            if p['kind'] == 'status':
                self.apply_target_status_additions(target,
                    {'disorientation': D(p.get('O', 0)), 'instability': D(p.get('U', 0))},
                    self.fighters[target].armor)
            elif p['kind'] == 'copy':
                flight = next(f for f in self.projectile_flights.values() if f['actor'] == target)
                self.projectile_system.copy(flight['id'], source='fixture:copy-field', offset_m=(0, 0, 0))
            elif p['kind'] == 'restrict':
                self.apply_action_restriction(target, source='fixture:upper-freeze', functions=['upper_body'],
                    until_ms=D(p['until']))
            elif p['kind'] == 'defenses':
                self.fighters[target].armor = D(p['armor'])
            elif p['kind'] == 'enqueue_status':
                self.push(D(p['at']), 'fixture_effort', {'kind': 'status', 'target': target, 'U': p['U']}, priority=0)
            else:
                raise ValueError('Unknown effort fixture operation')

    with localcontext(Context(prec=precision)):
        return Fixture(s, profiles, precision=precision, sample_interval_ms=interval,
            body_definition=BODY, terrain_definition=TERRAIN, movement_definition=MOVEMENT,
            combat_locomotion_definition=effects, jump_definition=JUMP, climb_definition=CLIMB,
            projectile_physics_definition=PHYSICS if s['scope'] == GRAVITY_MOBILE_SCOPE else None).run()


def shots(r, actor='A'):
    return [D(e['time_ms']) for e in events(r, 'projectile_released', actor)]


class EffortCombatTests(unittest.TestCase):
    def test_gun_recoil_preserves_shots_and_one_control_across_automatic_readiness(self):
        r = run(scene(1000))
        self.assertEqual(shots(r), [111, 511, 911])
        self.assertFalse(events(r, 'controlled_action_cancelled'))
        self.assertEqual(len(r['sustained_controls']), 1)
        control = r['sustained_controls'][0]
        self.assertEqual(control['action_ids'], control['released_action_ids'])
        self.assertEqual(len(control['action_ids']), 3)
        self.assertTrue(all(D(p['components']['projectile']['output']) == 437 for p in r['released_attack_power']))

    def test_initial_instability_delays_control_until_stable(self):
        s = scene(300)
        s['encounter']['participants']['A']['initial_state']['instability'] = 100
        r = run(s)
        self.assertEqual(shots(r), [211])
        self.assertEqual(D(r['sustained_controls'][0]['started_at_ms']), 100)

    def test_real_incoming_hit_interrupts_unreleased_active_without_payment_or_ammo(self):
        r = run(scene(300, a_start=100, b_start=60))
        cancelled = events(r, 'controlled_action_cancelled', 'A')
        self.assertEqual(len(cancelled), 1)
        self.assertEqual(cancelled[0]['action']['phase'], 'active')
        self.assertEqual(cancelled[0]['reason'], 'sustained_control_instability')
        self.assertFalse(shots(r))
        self.assertFalse(events(r, 'dyspnea_paid', 'A'))
        self.assertEqual(r['final_states']['A']['ammo']['1'], 11)
        self.assertFalse(events(r, 'cooldown_started', 'A'))
        self.assertEqual(r['sustained_controls'][1]['released_action_ids'], [])

    def test_incoming_hit_during_recovery_cancels_and_policy_resumes_after_stability(self):
        r = run(scene(400, a_start=100, b_start=0))
        cancel = events(r, 'controlled_action_cancelled', 'A')[0]
        self.assertEqual(cancel['action']['phase'], 'recovery')
        controls = [c for c in r['sustained_controls'] if c['actor'] == 'A']
        incoming = next(e for e in events(r, 'impact_batch_resolved') if e['target'] == 'A')
        with localcontext(Context(prec=60)):
            stable = D(incoming['time_ms'])+D(incoming['state_after']['instability'])
        self.assertEqual(D(controls[1]['started_at_ms']), stable)
        self.assertEqual(len(shots(r)), 1)
        self.assertGreater(shots(r)[0], stable)

    def test_readiness_interruption_preserves_released_shot_and_existing_bleeding(self):
        r = run(scene(700, b_start=0))
        self.assertEqual(shots(r), [111, 511])
        self.assertTrue(events(r, 'sustained_control_ended'))
        self.assertFalse(events(r, 'controlled_action_cancelled'))
        self.assertTrue(any(e['actor'] == 'A' for e in r['effect_instances']))
        self.assertGreater(D(r['damage_credit_totals']['A']['eligible_hp_dealt']), 0)

    def test_release_at_same_timestamp_as_instability_is_committed(self):
        r = run(scene(200), operations=[(111, {'kind': 'status', 'U': 100})])
        self.assertEqual(shots(r), [111])
        self.assertFalse(events(r, 'controlled_action_cancelled'))
        self.assertEqual(r['sustained_controls'][0]['end_reason'], 'instability')
        self.assertTrue(events(r, 'projectile_body_collision'))

    def test_disorientation_during_active_does_not_invent_instability_interruption(self):
        r = run(scene(200), operations=[(80, {'kind': 'status', 'O': 100})])
        self.assertEqual(shots(r), [111])
        self.assertFalse(events(r, 'sustained_control_ended'))

    def test_movement_instability_interrupts_gun_without_cancelling_body_action(self):
        s = scene(350)
        command(s, 'A', 0, 'run')
        r = run(s)
        cancelled = events(r, 'controlled_action_cancelled', 'A')
        self.assertEqual([e['action']['kind'] for e in cancelled], ['slash_projectile'])
        self.assertEqual(D(cancelled[0]['time_ms']), 60)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'], 'running')
        self.assertGreater(D(r['final_states']['A']['position_m'][0]), 0)
        self.assertTrue(shots(r))

    def test_interruption_preserves_parallel_jump_and_airborne_momentum(self):
        s = scene(350)
        command(s, 'A', 0, 'jump')
        r = run(s, operations=[(80, {'kind': 'status', 'U': 100})])
        self.assertEqual([e['action']['kind'] for e in events(r, 'controlled_action_cancelled')], ['slash_projectile'])
        self.assertTrue(events(r, 'jump_takeoff'))
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
        self.assertGreater(D(r['final_states']['A']['locomotion']['height_above_ground_m']), 0)

    def test_ready_hands_can_fire_from_actual_mid_crouch_pose_once_stable(self):
        s = scene(200)
        command(s, 'A', 0, 'crouch')
        profiles = deepcopy(PROFILES)
        # Start with the actual weapon already held, eliminating only initial
        # hand Recovery. Crouch's own U80 still delays admission until80.
        profiles['1E2']['initial_hand_positions_m'] = deepcopy(profiles['1E2']['abilities']['1']['hand_positions_m']['start'])
        r = run(s, profiles=profiles)
        shot = events(r, 'projectile_released', 'A')[0]
        self.assertEqual(D(shot['time_ms']), 120)
        self.assertEqual(D(shot['origin_m'][2]), D('.705'))
        self.assertEqual(r['metrics']['A']['crouches_completed'], 1)

    def test_resource_reassignment_ends_control_but_allows_momentary_mark(self):
        s = scene(700)
        s['action_selection']['A']['abilities'] = ['1', '2']
        r = run(s)
        self.assertEqual(r['sustained_controls'][0]['end_reason'], 'resources_reassigned')
        self.assertTrue(events(r, 'cooldown_pause_deployed', 'A'))
        self.assertTrue(events(r, 'projectile_body_collision'))

    def test_function_restriction_during_readiness_ends_only_that_control(self):
        r = run(scene(600), operations=[(150, {'kind': 'restrict', 'until': 300})])
        self.assertEqual(r['sustained_controls'][0]['end_reason'], 'function_restricted')
        self.assertEqual(shots(r), [111, 511])
        self.assertFalse(events(r, 'controlled_action_cancelled'))

    def test_empty_magazine_ends_control_and_reload_retains_its_existing_cost(self):
        profiles = deepcopy(PROFILES)
        profiles['1E2']['abilities']['1']['magazine_capacity'] = 1
        r = run(scene(2500), profiles=profiles)
        self.assertEqual(r['sustained_controls'][0]['end_reason'], 'empty_magazine')
        self.assertEqual(len(events(r, 'reload_completed', 'A')), 1)
        self.assertTrue(any(e['action_kind'] == 'reload' and e['base_value'] == .5 for e in events(r, 'dyspnea_paid', 'A')))

    def test_death_before_release_cancels_control_without_retracting_enemy_shot(self):
        s = scene(300, a_start=100, b_start=60)
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        r = run(s)
        control = next(c for c in r['sustained_controls'] if c['actor'] == 'A')
        self.assertEqual(control['end_reason'], 'death')
        self.assertFalse(shots(r))
        self.assertFalse(events(r, 'dyspnea_paid', 'A'))
        self.assertEqual(len(events(r, 'projectile_body_collision')), 1)

    def test_last_enemy_death_ends_idle_control_without_retracting_released_shot(self):
        s = scene(600)
        s['encounter']['participants']['B']['initial_state']['hp'] = 1
        r = run(s)
        self.assertEqual(shots(r), [111])
        self.assertEqual(r['sustained_controls'][0]['end_reason'], 'no_living_enemy')
        self.assertEqual(r['sustained_controls'][0]['ended_at_ms'], r['final_states']['B']['died_at_ms'])
        self.assertEqual(D(r['damage_credit_totals']['A']['eligible_hp_dealt']), 1)

    def test_last_enemy_death_does_not_cancel_already_started_attack_at_original_location(self):
        s = scene(350, a_start=100)
        s['encounter']['participants']['B']['initial_state']['hp'] = 1
        s['encounter']['participants']['C'] = deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m'] = [0, -25]
        s['action_selection']['C'] = deepcopy(s['action_selection']['A'])
        s['action_selection']['C']['start_ms'] = 0
        r = run(s)
        died = D(r['final_states']['B']['died_at_ms'])
        self.assertEqual(shots(r), [211])
        self.assertLess(died, 211)
        self.assertFalse(events(r, 'controlled_action_cancelled', 'A'))
        control = next(c for c in r['sustained_controls'] if c['actor'] == 'A')
        self.assertEqual((D(control['ended_at_ms']), control['end_reason']), (211, 'no_living_enemy'))
        self.assertTrue(events(r, 'dyspnea_paid', 'A'))

    def test_qard_intrinsic_power_is_sampled_at_release_for_both_impacts(self):
        r = run(scene(1300, qard=True))
        power = r['released_attack_power'][0]
        self.assertEqual(power['category'], 'intrinsic_momentary')
        self.assertEqual(D(power['instability_at_release']), 50)
        self.assertEqual(D(power['components']['projectile']['output']), 445)
        hits = [h for e in events(r, 'impact_batch_resolved') for h in e['hits']]
        self.assertEqual([D(h['incoming']) for h in hits], [445, 445])
        self.assertEqual({h['component'] for h in hits}, {'projectile', 'delayed_blast'})
        ledger = DamageLedger.from_record(r['applied_hp_history'])
        self.assertAlmostEqual(ledger.amount(actor='A'), D(8140)-D(r['final_states']['B']['hp']), places=20)

    def test_real_incoming_instability_changes_intrinsic_release_power(self):
        r = run(scene(450, qard=True, b_start=250))
        power = next(p for p in r['released_attack_power'] if p['actor'] == 'A')
        self.assertGreater(D(power['instability_at_release']), 50)
        self.assertLess(D(power['components']['projectile']['output']), 445)
        self.assertFalse(events(r, 'controlled_action_cancelled', 'A'))

    def test_same_phase_status_and_intrinsic_release_ignore_heap_insertion_order(self):
        s = scene(1300, qard=True)
        early = run(s, operations=[(398, {'kind': 'status', 'U': 5000, 'priority': 0})])
        late = run(s, operations=[(397, {'kind': 'enqueue_status', 'at': 398, 'U': 5000})])
        self.assertEqual(early['released_attack_power'], late['released_attack_power'])
        self.assertEqual(D(early['released_attack_power'][0]['instability_at_release']), 50)
        self.assertEqual(early['final_states']['B']['hp'], late['final_states']['B']['hp'])
        self.assertTrue(all(D(e['hits'][0]['incoming']) == 445 for e in events(early, 'impact_batch_resolved')))

    def test_same_phase_instability_does_not_retract_a_due_extrinsic_release(self):
        early = run(scene(200), operations=[(111, {'kind': 'status', 'U': 100, 'priority': 0})])
        late = run(scene(200), operations=[(110, {'kind': 'enqueue_status', 'at': 111, 'U': 100})])
        self.assertEqual(shots(early), [111])
        self.assertEqual(shots(early), shots(late))
        self.assertFalse(events(early, 'controlled_action_cancelled'))
        self.assertEqual(early['final_states']['B']['hp'], late['final_states']['B']['hp'])

    def test_later_caster_instability_does_not_rewrite_released_qard_or_copy(self):
        ops = [(450, {'kind': 'status', 'U': 5000}), (500, {'kind': 'copy'})]
        r = run(scene(1300, qard=True), operations=ops)
        self.assertEqual(len(r['released_attack_power']), 1)
        self.assertEqual(len(events(r, 'projectile_copied')), 1)
        hits = [h for e in events(r, 'impact_batch_resolved') for h in e['hits']]
        self.assertEqual(len(hits), 4)
        self.assertTrue(all(D(h['incoming']) == 445 for h in hits))
        self.assertEqual(len({h['projectile_id'] for h in hits}), 2)
        self.assertEqual(len(events(r, 'dyspnea_paid', 'A')), 1)

    def test_released_qard_and_blast_keep_credit_after_caster_death(self):
        s = scene(1300, qard=True, b_start=500)
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        r = run(s)
        died = D(r['final_states']['A']['died_at_ms'])
        hits = [e for e in events(r, 'impact_batch_resolved') if e['target'] == 'B']
        self.assertEqual(len(hits), 2)
        self.assertTrue(all(D(e['time_ms']) > died for e in hits))
        self.assertTrue(all(D(e['hits'][0]['incoming']) == 445 for e in hits))
        self.assertGreater(D(r['damage_credit_totals']['A']['eligible_hp_dealt']), 0)

    def test_zero_power_qard_still_collides_and_marks_without_damage_or_credit(self):
        r = run(scene(1300, qard=True), operations=[(390, {'kind': 'status', 'U': 5000})])
        self.assertEqual(D(r['released_attack_power'][0]['components']['projectile']['output']), 0)
        self.assertEqual(len(events(r, 'projectile_body_collision')), 1)
        self.assertEqual(len(events(r, 'delayed_blast')), 1)
        self.assertEqual(D(r['final_states']['B']['hp']), 8140)
        self.assertEqual(D(r['damage_credit_totals']['A']['eligible_hp_dealt']), 0)
        self.assertTrue(all(D(e['status_additions']['instability']) > 0 for e in events(r, 'impact_batch_resolved')))

    def test_qard_target_defenses_are_live_at_each_hit(self):
        r = run(scene(1300, qard=True), operations=[(900, {'kind': 'defenses', 'target': 'B', 'armor': 0})])
        hits = events(r, 'impact_batch_resolved')
        self.assertEqual([D(e['pre_hit_armor']) for e in hits], [150, 0])
        self.assertEqual([D(e['hits'][0]['incoming']) for e in hits], [445, 445])
        self.assertGreater(D(hits[1]['applied_hp_damage']), D(hits[0]['applied_hp_damage']))

    def test_qard_cover_damage_uses_the_same_release_snapshot(self):
        s = scene(1300, qard=True)
        s['initial_colliders'] = [wall(hp=500)]
        r = run(s, operations=[(450, {'kind': 'status', 'U': 5000})])
        batch = events(r, 'world_collider_impact_batch')[0]
        self.assertEqual(D(batch['hits'][0]['incoming']), 445)
        self.assertEqual(D(batch['hp_after']), 55)
        self.assertEqual(len(events(r, 'delayed_blast')), 1)
        self.assertFalse(events(r, 'projectile_body_collision'))

    def test_qard_terrain_collision_marks_actual_surface_and_blast_ignores_cover(self):
        s = scene(1200, qard=True)
        s['encounter']['participants']['A']['position_m'] = [0, 0]
        s['encounter']['participants']['B']['position_m'] = [30, 0]
        s['encounter']['participants']['C'] = deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(team='A', position_m=[6.5, 3])
        s['action_selection']['C'] = deepcopy(s['action_selection']['B'])
        r = run(s)
        hit = events(r, 'projectile_terrain_collision')[0]
        blast = events(r, 'delayed_blast')[0]
        self.assertEqual(hit['target'], 'cube_1')
        self.assertEqual(blast['location_m'], hit['location_m'])
        self.assertEqual(blast['recipients'], ['C'])
        self.assertLess(D(r['final_states']['C']['hp']), 8140)
        self.assertGreater(D(r['damage_credit_totals']['A']['applied_hp_dealt']), 0)
        self.assertEqual(D(r['damage_credit_totals']['A']['eligible_hp_dealt']), 0)

    def test_walking_caster_and_target_share_qard_motion_without_global_action_lock(self):
        s = scene(1400, qard=True)
        command(s, 'A', 0, 'walk')
        command(s, 'B', 0, 'walk')
        r = run(s)
        shot = events(r, 'projectile_released', 'A')[0]
        self.assertGreater(D(shot['origin_m'][0]), D('.4'))
        self.assertEqual(len(events(r, 'projectile_body_collision')), 1)
        self.assertEqual(len(events(r, 'delayed_blast')), 1)
        self.assertTrue(all(D(e['hits'][0]['incoming']) == 445 for e in events(r, 'impact_batch_resolved')))
        self.assertTrue(all(r['final_states'][a]['locomotion']['mode'] == 'walking' for a in ('A', 'B')))

    def test_in_flight_qard_does_not_occupy_beam_hands_or_block_heat_and_hp_receipts(self):
        s = scene(2000, qard=True)
        s['action_selection']['A']['abilities'] = ['1', '4']
        r = run(s)
        beam_request = next(e for e in events(r, 'ability_started', 'A') if e['ability'] == '4')
        qard_hit = events(r, 'projectile_body_collision', 'A')[0]
        self.assertLess(D(beam_request['time_ms']), D(qard_hit['time_ms']))
        self.assertTrue(events(r, 'beam_deployed', 'A'))
        ledger = DamageLedger.from_record(r['applied_hp_history'])
        self.assertEqual({e.contribution.kind for e in ledger.entries}, {'qard', 'heat'})
        self.assertAlmostEqual(ledger.amount(actor='A'), D(8140)-D(r['final_states']['B']['hp']), places=20)

    def test_qard_straight_and_gravity_paths_share_effort_but_not_trajectories(self):
        straight, curved = (run(scene(1300, qard=True, gravity=g)) for g in (False, True))
        self.assertEqual(straight['released_attack_power'], curved['released_attack_power'])
        self.assertEqual(len(events(straight, 'delayed_blast')), 1)
        self.assertEqual(len(events(curved, 'delayed_blast')), 1)
        self.assertNotEqual(events(straight, 'projectile_body_collision')[0]['time_ms'],
                            events(curved, 'projectile_body_collision')[0]['time_ms'])

    def test_beam_and_mark_activation_are_not_sustained_controls(self):
        for character, ability in (('1E1', '4'), ('1E2', '2')):
            s = scene(3800, b_start=0)
            s['encounter']['participants']['A']['character'] = character
            s['action_selection']['A'].update(abilities=[ability], reload_when_empty=False)
            r = run(s)
            self.assertFalse([c for c in r['sustained_controls'] if c['actor'] == 'A'])
            self.assertFalse(events(r, 'controlled_action_cancelled', 'A'))
            kind = 'beam_deployed' if ability == '4' else 'cooldown_pause_deployed'
            self.assertEqual(len(events(r, kind, 'A')), 1)
            self.assertEqual(D(r['metrics']['A']['dyspnea_paid']), 0)

    def test_instability_during_remaining_summon_active_preserves_full_independent_beam(self):
        s = scene(5000, qard=True, b_start=400)
        s['action_selection']['A']['abilities'] = ['4']
        r = run(s)
        control = deepcopy(s)
        control['action_selection']['B']['start_ms'] = 100000
        clean = run(control)
        beam = events(r, 'beam_deployed', 'A')[0]
        active_end = next(e for e in events(r, 'active_started', 'A') if e['action_kind'] == 'heat_beam')['active_end_ms']
        incoming = next(e for e in events(r, 'impact_batch_resolved') if e['target'] == 'A')
        self.assertLess(D(beam['time_ms']), D(incoming['time_ms']))
        self.assertLess(D(incoming['time_ms']), D(active_end))
        self.assertAlmostEqual(D(r['final_states']['B']['hp']), D(clean['final_states']['B']['hp']), places=30)
        self.assertFalse(events(r, 'controlled_action_cancelled', 'A'))

    def test_observations_precision_order_and_future_commands_preserve_effort_prefix(self):
        s = scene(1000, a_start=100, b_start=60)
        results = [run(s, interval=None), run(s, interval=17), run(s, precision=80)]
        later = deepcopy(s)
        command(later, 'B', 900, 'walk')
        results.append(run(later, interval=31))
        reverse = deepcopy(s)
        reverse['encounter']['participants'] = dict(reversed(list(reverse['encounter']['participants'].items())))
        reverse['action_selection'] = dict(reversed(list(reverse['action_selection'].items())))
        results.append(run(reverse))
        base = results[0]
        for r in results[1:]:
            self.assertEqual([t for t in shots(r) if t < 850], [t for t in shots(base) if t < 850])
            a = next(c for c in r['sustained_controls'] if c['actor'] == 'A')
            b = next(c for c in base['sustained_controls'] if c['actor'] == 'A')
            self.assertEqual(a['ended_at_ms'], b['ended_at_ms'])
            self.assertEqual(a['end_reason'], b['end_reason'])

    def test_missing_effort_source_and_unsupported_sustained_delivery_reject_early(self):
        for value in (None, 'intrinsic_sustained'):
            p = deepcopy(PROFILES)
            if value is None:
                del p['1E2']['abilities']['1']['effort_phase']
            else:
                p['1E2']['documented_abilities']['1']['effort_phases']['firing_control']['category'] = value
            with self.subTest(value=value), self.assertRaises((ValueError, UnsupportedMechanicError)):
                run(scene(), profiles=p)
        effects = deepcopy(CURRENT)
        effects['effort_rules'] = {'mode': 'unreviewed'}
        with self.assertRaisesRegex(UnsupportedMechanicError, 'Phase effort requires'):
            run(scene(), effects=effects)

    def test_historical_mode_retains_gun_behavior_without_effort_claim(self):
        old = deepcopy(CURRENT)
        for mode in ('binding_effects','grapple_break','grapple_casts','controlled_damage','continuous_effort'):old.pop(mode,None)
        old.pop('attack_modifiers',None)
        old.pop('combat_reactions',None)
        old.pop('blocking',None)
        old.pop('melee',None)
        del old['effort_rules']
        r = run(scene(300, a_start=100, b_start=60), effects=old)
        self.assertEqual(shots(r), [211])
        self.assertNotIn('sustained_controls', r)
        self.assertNotIn('released_attack_power', r)
