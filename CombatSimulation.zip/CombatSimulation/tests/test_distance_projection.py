"""Finite nonlinear distance limits against analytic and degenerate cases."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import json,unittest

from combat_sim.mechanics.distance_projection import MaximumDistance,project_distances,sqrt_bound,feasible_fraction
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality,BlockedDirection
from combat_sim.mechanics.unilateral_velocity import ContactLimit


class DistanceProjectionTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=80));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_slack_and_inward_motion_remain_free(self):
        refs={'A':(0,0,0),'B':(2,0,0)};edge=(MaximumDistance('A','B',2),)
        for a,b in (((0,0,0),(-1,2,0)),((1,0,0),(-1,0,0))):
            nodes=(VelocityNode('A',a,500,0),VelocityNode('B',b,500,0))
            r=project_distances(nodes,refs,'.1',edge)
            self.assertEqual(dict(r.exact_velocities),{'A':a,'B':b})
        nodes=(VelocityNode('A',(-2,0,0),500,0),VelocityNode('B',(2,0,0),500,0))
        r=project_distances(nodes,refs,'.1',(MaximumDistance('A','B',20),))
        self.assertEqual(dict(r.exact_velocities),{'A':(-2,0,0),'B':(2,0,0)})

    def test_near_tangent_roundoff_keeps_common_translation_and_exact_certificate(self):
        nodes=(VelocityNode('A',(-5,0,0),100,0),VelocityNode('B',(-5,'1e-28',0),100,0))
        refs={'A':(0,0,0),'B':(20,0,0)};h=F(1,200)
        r=project_distances(nodes,refs,h,(MaximumDistance('A','B',20),),maximum_rounds=12)
        self.assertIsNotNone(r.anchor_projection)
        values=dict(r.exact_velocities)
        self.assertEqual(values['A'][0],-5);self.assertEqual(values['B'][0],-5)
        end=tuple(b+h*y-a-h*x for a,b,x,y in zip(refs['A'],refs['B'],values['A'],values['B']))
        self.assertLessEqual(sum(x*x for x in end),400)
        self.assertLessEqual(r.objective_upper-r.objective_lower,
            min(dict(r.linear_projection.weights).values())*r.maximum_error_mps**2/2)

    def test_outward_radial_motion_shares_one_common_velocity(self):
        nodes=(VelocityNode('A',(-8,2,0),500,0),VelocityNode('B',(6,2,0),500,0))
        r=project_distances(nodes,{'A':(0,0,0),'B':(2,0,0)},'.1',(MaximumDistance('A','B',2),))
        self.assertEqual(r.exact_velocities,(('A',(-1,2,0)),('B',(-1,2,0))))

    def test_unequal_weight_tangential_response_matches_closed_form_optimum(self):
        nodes=(VelocityNode('A',(-1,2,0),8140,150),VelocityNode('B',(0,6,0),20000,350))
        refs={'A':(0,0,0),'B':(2,0,0)};h=D('.1');length=D(2)
        r=project_distances(nodes,refs,h,(MaximumDistance('A','B',length),),maximum_error_mps='1e-12')
        weights={n:D(w.numerator)/D(w.denominator) for n,w in r.linear_projection.weights}
        free=(D('2.1'),D('.4'),D(0));norm=sum(x*x for x in free).sqrt()
        correction=tuple((x-x*length/norm)/h for x in free)
        decimal=lambda v:D(v.numerator)/D(v.denominator)
        expected={'A':tuple(decimal(v)+weights['B']*c/(weights['A']+weights['B']) for v,c in zip(nodes[0].velocity_mps,correction)),
            'B':tuple(decimal(v)-weights['A']*c/(weights['A']+weights['B']) for v,c in zip(nodes[1].velocity_mps,correction))}
        for name,v in r.velocities:
            self.assertTrue(all(abs(a-b)<D('1e-12') for a,b in zip(v,expected[name])))
        self.assertGreater(r.cut_rounds,0)

    def test_joint_contact_prevents_pairwise_wall_separation(self):
        nodes=(VelocityNode('A',(-8,0,0),500,0),VelocityNode('B',(6,0,0),500,0))
        r=project_distances(nodes,{'A':(-2,0,0),'B':(0,0,0)},'.1',(MaximumDistance('A','B',2),),
            (ContactLimit('B',(-1,0,0)),))
        self.assertEqual(r.exact_velocities,(('A',(0,0,0)),('B',(0,0,0))))

    def test_grapple_equalities_and_multiple_distance_limits_are_solved_together(self):
        nodes=tuple(VelocityNode(n,v,500,0) for n,v in zip('ABC',((-8,2,0),(4,4,0),(8,-2,0))))
        refs={'A':(-2,0,0),'B':(-2,1,0),'C':(0,1,0)}
        edges=(MaximumDistance('B','C',2),MaximumDistance('A','C',3))
        r=project_distances(nodes,refs,'.1',edges,equalities=(VelocityEquality('A','B'),))
        self.assertEqual(dict(r.exact_velocities)['A'],dict(r.exact_velocities)['B'])
        self.check_feasible(r,refs,F(1,10),edges)

    def check_feasible(self,result,refs,seconds,edges):
        velocities=dict(result.exact_velocities)
        for edge in edges:
            end=tuple(F(b)-F(a)+seconds*(vb-va) for a,b,va,vb in
                zip(refs[edge.first],refs[edge.second],velocities[edge.first],velocities[edge.second]))
            self.assertLessEqual(sum(x*x for x in end),edge.maximum_m**2)
        minimum=min(dict(result.linear_projection.weights).values(),default=1)
        self.assertLessEqual(result.objective_upper-result.objective_lower,minimum*result.maximum_error_mps**2/2)

    def test_degenerate_tangent_intersection_returns_its_only_feasible_motion(self):
        nodes=tuple(VelocityNode(n,(0,int(n=='B'),0),500,0) for n in 'ABC')
        blocked=tuple(BlockedDirection(n,tuple(int(i==axis) for i in range(3))) for n in 'AC' for axis in range(3))
        refs={'A':(-1,0,0),'B':(0,0,0),'C':(1,0,0)}
        edges=(MaximumDistance('A','B',1),MaximumDistance('B','C',1))
        r=project_distances(nodes,refs,'.1',edges,blocked=blocked)
        self.assertTrue(all(v==(0,0,0) for _,v in r.exact_velocities));self.check_feasible(r,refs,F(1,10),edges)

    def test_cycles_duplicates_reversal_and_zero_initial_separation(self):
        nodes=tuple(VelocityNode(n,v,500,0) for n,v in zip('ABC',((-2,2,0),(2,2,0),(0,3,0))))
        refs={'A':(-1,0,0),'B':(1,0,0),'C':(0,1,0)}
        edges=(MaximumDistance('A','B',2),MaximumDistance('B','C',2),MaximumDistance('C','A',2))
        r=project_distances(nodes,refs,'.5',edges)
        reversed_edges=tuple(MaximumDistance(e.second,e.first,e.maximum_m) for e in reversed(edges))
        other=project_distances(reversed(nodes),dict(reversed(list(refs.items()))),'.5',reversed_edges+(edges[0],))
        self.assertEqual(r,other);self.check_feasible(r,refs,F(1,2),edges)
        together=project_distances(nodes,dict.fromkeys('ABC',(0,0,0)),'.5',edges)
        self.check_feasible(together,dict.fromkeys('ABC',(0,0,0)),F(1,2),edges)

    def test_precision_ownership_and_direct_json_record(self):
        nodes=(VelocityNode('A',(0,0,0),8140,150),VelocityNode('B',(0,4,0),20000,350))
        args=(nodes,{'A':(0,0,0),'B':(2,0,0)},'.01',(MaximumDistance('A','B',2),))
        with localcontext(Context(prec=7)):a=project_distances(*args)
        with localcontext(Context(prec=90)):b=project_distances(*args)
        self.assertEqual(a,b);json.dumps(a.record())

    def test_checked_square_root_and_feasible_fraction_bounds(self):
        for x in (F(0),F(2),F(1,7),F(10**45,3)):
            low=sqrt_bound(x,50,upper=False);high=sqrt_bound(x,50,upper=True)
            self.assertLessEqual(low*low,x);self.assertGreaterEqual(high*high,x)
        for c,b,a in ((F(-1),F(0),F(2)),(F(0),F(1),F(1)),(F(-2),F(3),F(0)),(F(0),F(-1),F(3))):
            alpha=feasible_fraction(c,b,a,50)
            self.assertTrue(0<=alpha<=1);self.assertLessEqual(a*alpha*alpha+b*alpha+c,0)
        self.assertEqual(feasible_fraction(-2,3,0,50),F(2,3))

    def test_invalid_or_uncertified_steps_fail_explicitly(self):
        nodes=(VelocityNode('A',(0,0,0),500,0),VelocityNode('B',(0,4,0),500,0))
        refs={'A':(0,0,0),'B':(2,0,0)};edges=(MaximumDistance('A','B',2),)
        for seconds in (0,-1,True,'NaN'):
            with self.assertRaises(ValueError):project_distances(nodes,refs,seconds,edges)
        for invalid in ({'A':(0,0,0)},{'A':(0,0,0),'B':(3,0,0)}):
            with self.assertRaises(ValueError):project_distances(nodes,invalid,1,edges)
        with self.assertRaises(ValueError):MaximumDistance('A','A',2)
        with self.assertRaises(ValueError):MaximumDistance('A','B',0)
        with self.assertRaises(ArithmeticError):project_distances(nodes,refs,'.01',edges,maximum_rounds=1)


if __name__=='__main__':unittest.main()
