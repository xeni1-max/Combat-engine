"""Whole-interval bounds, free physics and coupled path constraints."""
from decimal import Context,localcontext
from fractions import Fraction as F
import json,unittest

from combat_sim.mechanics.distance_path import build_distance_path
from combat_sim.mechanics.distance_projection import MaximumDistance
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality
from combat_sim.mechanics.unilateral_velocity import ContactLimit
from combat_sim.mechanics.constraint_response import path_force_coefficients


class DistancePathTests(unittest.TestCase):
    def check_entire_path(self,path,edges):
        pieces=dict(path.pieces);first=path.pieces[0][1]
        for i in range(201):
            time=first.begin_ms+(first.end_ms-first.begin_ms)*F(i,200)
            for edge in edges:
                delta=tuple(b-a for a,b in zip(pieces[edge.first].position(time),pieces[edge.second].position(time)))
                self.assertLessEqual(sum(x*x for x in delta),edge.maximum_m**2,(edge,time))
        self.assertTrue(all(all(c<=0 for c in coefficients) for _,_,_,coefficients in path.bernstein_certificate))

    def test_unconstrained_polynomial_retains_exact_free_acceleration(self):
        nodes=(VelocityNode('A',(2,3,4),500,0),)
        path=build_distance_path(nodes,{'A':(0,0,5)},100,1100,accelerations={'A':(0,0,F(-981,100))})
        p=dict(path.pieces)['A'];self.assertEqual(p.velocity_mps,(2,3,4))
        self.assertEqual(p.acceleration_mps2,(0,0,F(-981,100)));self.assertEqual(path.control_blend,1)
        self.assertEqual(p.position(600),(1,F(3,2),F(4619,800)))

    def test_near_tangent_feasible_anchor_preserves_shared_released_force(self):
        nodes=(VelocityNode('A',(-5,0,0),100,0),VelocityNode('B',(-5,'1e-28',0),100,0))
        edges=(MaximumDistance('A','B',20),)
        path=build_distance_path(nodes,{'A':(0,0,0),'B':(20,0,0)},0,5,edges)
        self.assertIsNotNone(path.endpoint_projection.anchor_projection)
        field={'A':(-5,0,0),'B':(-5,0,0)}
        for velocity,acceleration in path_force_coefficients(path,field).values():
            self.assertEqual(velocity,(-5,0,0));self.assertEqual(acceleration,(0,0,0))
        self.check_entire_path(path,edges)

    def test_equal_gravity_translates_a_taut_pair_without_changing_its_separation(self):
        nodes=(VelocityNode('A',(2,0,1),500,0),VelocityNode('B',(2,0,1),500,0))
        edges=(MaximumDistance('A','B',2),)
        a=dict.fromkeys('AB',(0,0,F(-981,100)))
        path=build_distance_path(nodes,{'A':(0,0,10),'B':(2,0,10)},0,500,edges,accelerations=a)
        self.assertTrue(all(p.acceleration_mps2==a[n] for n,p in path.pieces));self.assertEqual(path.control_blend,1)
        self.check_entire_path(path,edges)

    def test_naive_endpoint_fit_overstretches_but_certified_curve_does_not(self):
        nodes=(VelocityNode('A',(0,0,0),500,0),VelocityNode('B',(0,4,0),500,0))
        refs={'A':(0,0,0),'B':(2,0,0)};edges=(MaximumDistance('A','B',2),)
        path=build_distance_path(nodes,refs,0,10,edges);pieces=dict(path.pieces)
        self.assertTrue(0<path.control_blend<1)
        end={n:p.position(10) for n,p in path.pieces};h=F(1,100);time=h/4
        naive={n:tuple(p+v*time+(q-p-v*h)*(time/h)**2 for p,v,q in zip(refs[n],node.velocity_mps,end[n]))
            for n,node in zip('AB',nodes)}
        relative=tuple(b-a for a,b in zip(naive['A'],naive['B']))
        self.assertGreater(sum(x*x for x in relative),4)
        self.assertGreater(pieces['B'].velocity_mps[1]-pieces['A'].velocity_mps[1],F(3999999,1000000))
        self.assertLess(pieces['B'].acceleration_mps2[0]-pieces['A'].acceleration_mps2[0],0)
        self.check_entire_path(path,edges)

    def test_unequal_gravity_and_tangential_motion_remain_inside(self):
        nodes=(VelocityNode('A',(0,0,0),8140,150),VelocityNode('B',(0,3,0),20000,350))
        edges=(MaximumDistance('A','B',2),)
        path=build_distance_path(nodes,{'A':(0,0,2),'B':(2,0,2)},100,140,edges,
            accelerations={'A':(0,0,0),'B':(0,0,F(-981,100))})
        self.check_entire_path(path,edges)

    def test_grapple_contact_and_tether_cycle_share_one_curve(self):
        nodes=tuple(VelocityNode(n,v,500,0) for n,v in zip('ABCD',((-2,-1,0),(3,-1,0),(3,2,0),(-2,2,0))))
        refs={'A':(-1,-1,0),'B':(1,-1,0),'C':(1,1,0),'D':(-1,1,0)}
        edges=tuple(MaximumDistance(a,b,2) for a,b in (('A','B'),('B','C'),('C','D'),('D','A')))
        contacts=(ContactLimit('A',(-1,0,0)),);equalities=(VelocityEquality('B','C'),)
        path=build_distance_path(nodes,refs,0,20,edges,contacts,equalities)
        pieces=dict(path.pieces)
        self.assertEqual(pieces['B'].velocity_mps,pieces['C'].velocity_mps)
        self.assertEqual(pieces['B'].acceleration_mps2,pieces['C'].acceleration_mps2)
        self.assertGreaterEqual(pieces['A'].position(10)[0],-1)
        self.check_entire_path(path,edges)

    def test_path_slices_order_precision_and_json_remain_coherent(self):
        nodes=(VelocityNode('A',(0,0,0),8140,150),VelocityNode('B',(0,4,0),20000,350))
        refs={'A':[0,0,0],'B':[2,0,0]};edges=(MaximumDistance('A','B',2),)
        with localcontext(Context(prec=7)):a=build_distance_path(nodes,refs,100,110,edges)
        with localcontext(Context(prec=90)):
            b=build_distance_path(reversed(nodes),dict(reversed(list(refs.items()))),100,110,
                (MaximumDistance('B','A',2),))
        self.assertEqual(a,b);refs['A'][0]=99;self.assertEqual(dict(a.pieces)['A'].position(100),(0,0,0))
        for _,p in a.pieces:
            q=p.slice(103,109);self.assertEqual(q.position(107),p.position(107));self.assertEqual(q.velocity(107),p.velocity(107))
        json.dumps(a.record())

    def test_invalid_durations_and_incomplete_accelerations_reject(self):
        n=(VelocityNode('A',(0,0,0),500,0),)
        for begin,end in ((100,100),(100,99),(False,100),(-1,100)):
            with self.assertRaises(ValueError):build_distance_path(n,{'A':(0,0,0)},begin,end)
        with self.assertRaises(ValueError):build_distance_path(n,{'A':(0,0,0)},0,100,accelerations={})


if __name__=='__main__':unittest.main()
