"""Recharge stock is work-based, observation independent and independently paused."""
from decimal import Decimal as D
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.charges import RechargeableCharges
from combat_sim.mechanics.cooldown import CooldownClock


class ChargeTests(unittest.TestCase):
    def test_serial_refill_and_exact_boundaries(self):
        p=RechargeableCharges(4,4500);p.spend(0,4)
        self.assertEqual([p.available(t) for t in (0,4499,4500,9000,13500,18000)], [0,0,1,2,3,4])
        self.assertEqual(p.ready_at(0,2),9000)

    def test_spending_preserves_partial_recharge(self):
        p=RechargeableCharges(4,4500);p.spend(0);p.spend(2000)
        self.assertEqual(p.available(2000),2)
        self.assertEqual(p.record(2000)['next_charge_at_ms'],4500)
        self.assertEqual(p.available(4500),3)
        self.assertEqual(p.available(9000),4)

    def test_idle_full_pool_cannot_bank_work(self):
        p=RechargeableCharges(4,4500);p.spend(90000,4)
        self.assertEqual(p.ready_at(90000),94500)
        self.assertEqual(p.available(90000),0)

    def test_stock_can_be_spent_inside_pause_field(self):
        c=CooldownClock();c.pause(0,'a',True)
        p=RechargeableCharges(4,4500,clock=c);p.spend(100,2)
        self.assertEqual(p.available(99999),2)
        self.assertEqual(p.ready_at(99999,2),D(99999));self.assertIsNone(p.ready_at(99999,3))
        c.pause(100000,'a',False)
        self.assertEqual(p.ready_at(100000,3),104500)

    def test_overlapping_pauses_cannot_resume_early(self):
        p=RechargeableCharges(4,4500);p.spend(0,4)
        p.clock.pause(1000,'a',True);p.clock.pause(2000,'b',True)
        p.clock.pause(3000,'a',False)
        self.assertIsNone(p.ready_at(5000));self.assertEqual(p.available(5000),0)
        p.clock.pause(6000,'b',False)
        self.assertEqual(p.ready_at(6000),9500)

    def test_stop_resume_preserves_work_and_reconciles_sources(self):
        p=RechargeableCharges(4,4500);p.spend(0,4);p.clock.stop(1000)
        before=p.record(1000)
        self.assertIsNone(p.ready_at(10000));self.assertEqual(p.record(10000),before)
        with self.assertRaises(ValueError):p.spend(10000)
        p.clock.resume(11000,pause_sources=('new',));self.assertIsNone(p.ready_at(12000))
        p.clock.pause(13000,'new',False);self.assertEqual(p.ready_at(13000),16500)

    def test_queries_are_pure_and_saved_records_detached(self):
        p=RechargeableCharges(4,4500);p.spend(0,3);revision=p.clock.revision
        self.assertEqual([p.available(t) for t in (9500,100,4500,20000)], [3,1,2,4])
        self.assertEqual(p.clock.revision,revision)
        record=p.record(100);record['clock']['pause_sources'].append('fake')
        self.assertEqual(p.clock.pauses,set())

    def test_fractional_reference_and_refill(self):
        p=RechargeableCharges(2,F(9,4));p.spend(F(1,8),2)
        self.assertEqual(p.ready_at(F(3,8)),D('2.375'))
        p.clock.pause(F(3,8),'x',True);p.clock.pause(F(9,8),'x',False)
        self.assertEqual(p.ready_at(F(9,8)),D('3.125'))

    def test_invalid_requests_are_atomic(self):
        p=RechargeableCharges(4,4500);p.spend(0,3);before=p.record(100)
        for value in (0,-1,True,1.5,2,5):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):p.spend(100,value)
                self.assertEqual(p.record(100),before)
        for value in (0,5,True):
            with self.assertRaises(ValueError):p.ready_at(100,value)

    def test_invalid_definitions_fail(self):
        for cap,period in ((0,4500),(True,4500),(2,0),(2,-1),(2,'NaN')):
            with self.assertRaises(ValueError):RechargeableCharges(cap,period)

    def test_full_stock_and_refill_tie_can_be_spent_before_pause(self):
        p=RechargeableCharges(4,4500);p.spend(0,4)
        p.clock.pause(4500,'a',True)
        self.assertEqual(p.available(4500),1);p.spend(4500)
        self.assertEqual(p.available(4500),0);self.assertIsNone(p.ready_at(9999))

    def test_shared_clock_is_the_only_recharge_authority(self):
        c=CooldownClock();p=RechargeableCharges(4,4500,clock=c);p.spend(0,2)
        self.assertIs(p.clock,c);self.assertEqual(c.remaining(1000),8000)
        self.assertEqual(p.record(1000)['next_charge_at_ms'],4500)


if __name__=='__main__':unittest.main()
