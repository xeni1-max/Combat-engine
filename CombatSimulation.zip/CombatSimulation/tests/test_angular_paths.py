"""Continuous yaw bounds and moving pose/hand derivatives; no turn controller."""
from dataclasses import replace
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import json
import unittest

from combat_sim.angular_paths import YawArc, RotatingBoxPath
from combat_sim.bounded_yaw import bounded_degrees_frame, pi_bounds
from combat_sim.character_geometry import profile_scale, scaled_definition
from combat_sim.hitboxes import Cuboid, standing_cuboids
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.orientation import YawFrame, dot
from combat_sim.prone import prone_morph
from tests.test_mobile_combat import BODY, PROFILES


def path(*, begin=0, end=F(3, 20), rate=600, frame=YawFrame(),
         reference=(0, 0, 0), velocity=(0, 0, 0), acceleration=(0, 0, 0),
         box=None, precision=50, **kwargs):
    return RotatingBoxPath(BodyPathPiece(1000*F(begin), 1000*F(end), reference, velocity, acceleration),
        YawArc(begin, end, frame, rate, precision), box or Cuboid('arm', (0, 1, 1), ('.1', 1, '.1')), **kwargs)


class BoundedYawTests(unittest.TestCase):
    def test_pi_interval_contains_independent_eighty_digit_reference(self):
        digits = '3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628'
        reference = F(digits)
        low, high = pi_bounds(50)
        self.assertLess(low, reference)
        self.assertGreater(high, reference+F(1, 10**78))
        self.assertLess(high-low, F(1, 10**59))

    def test_bounded_frames_agree_with_independent_high_precision_decimal_selector(self):
        for angle in (F(1, 7), 37, 44, 45, 91, 137, 217, -31, F(3600000000000007, 17)):
            with self.subTest(angle=angle):
                actual, error = bounded_degrees_frame(angle, 50)
                reference = YawFrame.from_degrees(angle, precision=100)
                self.assertLessEqual(abs(actual.cosine-reference.cosine), error+F(1, 10**100))
                self.assertLessEqual(abs(actual.sine-reference.sine), error+F(1, 10**100))
                self.assertLess(error, F(1, 10**50))
                self.assertEqual(actual.cosine**2+actual.sine**2, 1)

    def test_cardinal_and_wrapped_signed_angles_are_exact(self):
        for angle, expected in ((0, (1, 0)), (90, (0, 1)), (-90, (0, -1)), (540, (-1, 0)), (360*10**20, (1, 0))):
            self.assertEqual(bounded_degrees_frame(angle), (YawFrame(*expected), 0))
        self.assertEqual(bounded_degrees_frame(-37), bounded_degrees_frame(323))

    def test_selector_does_not_read_or_change_decimal_context(self):
        expected = bounded_degrees_frame(F(373, 11), 80)
        with localcontext(Context(prec=6)) as context:
            context.clear_flags()
            actual = bounded_degrees_frame(F(373, 11), 80)
            self.assertEqual(actual, expected)
            self.assertFalse(any(context.flags.values()))

    def test_invalid_angle_or_precision_is_explicit(self):
        bounded_degrees_frame(0, 50)
        bounded_degrees_frame(1, 50)
        for value in (True, False, None, 'NaN', float('inf'), {}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                bounded_degrees_frame(value)
        for precision in (True, 39, 50.0, '50', []):
            with self.subTest(precision=precision), self.assertRaises(ValueError):
                bounded_degrees_frame(0, precision)


class YawArcTests(unittest.TestCase):
    def test_author_durations_and_signed_end_heading(self):
        for speed, duration in ((0, 150), (2, 230), (F('6.4'), 406), (F('11.2'), 598)):
            arc = YawArc.fixed_speed_turn(100, YawFrame(), -90, speed)
            self.assertEqual((arc.end_s-arc.begin_s)*1000, duration)
            self.assertEqual(arc.frame_at(arc.end_s), YawFrame(0, -1))

    def test_zero_turn_is_an_instantaneous_identity(self):
        initial = YawFrame(F(3, 5), F(4, 5))
        arc = YawArc.fixed_speed_turn(100, initial, 0, 2)
        self.assertEqual(arc.begin_s, arc.end_s)
        self.assertIs(arc.frame_at(F(1, 10)), initial)
        self.assertEqual(arc.angular_speed, 0)
        self.assertEqual(arc.frame_error, 0)

    def test_composed_initial_frame_retains_exact_metric_and_anchor(self):
        initial = YawFrame(F(3, 5), F(4, 5))
        arc = YawArc(1, 2, initial, 90)
        self.assertIs(arc.frame_at(1), initial)
        self.assertEqual(arc.frame_at(2), YawFrame(-F(4, 5), F(3, 5)))
        frame = arc.frame_at(F(13, 10))
        self.assertEqual(dot(frame.forward, frame.right), 0)
        self.assertEqual(dot(frame.forward, frame.forward), 1)

    def test_queries_are_anchored_and_independent_of_observation_order(self):
        arc = YawArc(0, 10, YawFrame(), F(373, 7))
        points = (F(1, 7), F(7, 3), F(9, 2), F(19, 2))
        expected = {t: arc.frame_at(t) for t in points}
        for t in reversed(points):
            self.assertEqual(arc.frame_at(t), expected[t])
        self.assertEqual(arc.record()['rate_degrees_per_second'], '373/7')
        json.dumps(arc.record())

    def test_invalid_intervals_frames_and_extrapolation_fail(self):
        for args in ((-1, 1, YawFrame(), 90), (2, 1, YawFrame(), 90), (0, 1, '+x', 90),
                     (0, 1, YawFrame(), True), (0, 1, YawFrame(), 'NaN')):
            with self.subTest(args=args), self.assertRaises(ValueError):
                YawArc(*args)
        arc = YawArc(1, 2, YawFrame(), 90)
        for value in (0, F('2.0000001'), True):
            with self.assertRaises(ValueError):
                arc.frame_at(value)

    def test_point_velocity_and_centripetal_acceleration_with_stationary_reference(self):
        p = path()
        state, omega = p.centre_state(0), p.yaw.angular_speed
        self.assertEqual(state.position_m, (1, 0, 1))
        self.assertEqual(state.velocity_mps, (0, omega, 0))
        self.assertEqual(state.acceleration_mps2, (-omega*omega, 0, 0))
        self.assertGreater(state.velocity_mps[1], 10)

    def test_local_pose_velocity_has_coriolis_acceleration(self):
        p = path(velocity=(3, 4, 5), acceleration=(1, 2, 3), local_velocity_mps=(0, 2, 0))
        state, omega = p.centre_state(0), p.yaw.angular_speed
        self.assertEqual(state.velocity_mps, (5, 4+omega, 5))
        self.assertEqual(state.acceleration_mps2, (1-omega*omega, 2+4*omega, 3))

    def test_actual_hand_point_uses_the_same_rotation_as_body_attachment(self):
        p = path(reference=(2, -3, 4), velocity=(1, 2, 3))
        for hand in ((F('.05'), F('.25'), F('.1')), (0, F('.30'), F('.15'))):
            state = p.yaw.point_state(F('.075'), p.reference, hand)
            self.assertEqual(state.position_m,
                p.yaw.frame_at(F('.075')).to_world_point(hand, p.reference.position(75)))
            self.assertNotEqual(state.velocity_mps, p.reference.velocity(75))
            self.assertEqual(state.position_error_m[2], 0)

    def test_analytic_derivatives_match_independent_symmetric_differences(self):
        p = path(reference=(1, 2, 3), velocity=(2, -1, 4), acceleration=(1, 3, -2),
                 local_velocity_mps=('.2', '-.1', '.3'), local_acceleration_mps2=(1, 2, 3))
        t, h = F('.07'), F(1, 10**7)
        left, now, right = (p.centre_state(s) for s in (t-h, t, t+h))
        for actual, low, high in zip(now.velocity_mps, left.position_m, right.position_m):
            self.assertLess(abs(actual-(high-low)/(2*h)), F(1, 10**9))
        for actual, low, high in zip(now.acceleration_mps2, left.velocity_mps, right.velocity_mps):
            self.assertLess(abs(actual-(high-low)/(2*h)), F(1, 10**8))

    def test_numerical_point_errors_contain_higher_precision_reference(self):
        low = path(precision=40, local_velocity_mps=(1, 2, 3), local_acceleration_mps2=(4, 5, 6))
        high = replace(low, yaw=replace(low.yaw, precision=100))
        a, b = low.centre_state(F('.07123')), high.centre_state(F('.07123'))
        for field, error in (('position_m', 'position_error_m'), ('velocity_mps', 'velocity_error_mps'),
                             ('acceleration_mps2', 'acceleration_error_mps2')):
            for x, y, bound in zip(getattr(a, field), getattr(b, field), getattr(a, error)):
                self.assertLessEqual(abs(x-y), bound)


class RotatingBoxPathTests(unittest.TestCase):
    def test_resize_and_local_translation_keep_axes_and_shared_reference_distinct(self):
        p = path(reference=(10, 20, 30), velocity=(1, 2, 3), local_velocity_mps=(0, 1, 0), size_rate_mps=(1, 2, 3))
        box = p.at_time(F('.15'))
        self.assertEqual(box.size_m, (F('.25'), F('1.3'), F('.55')))
        self.assertEqual(box.centre_m, (F('10.15'), F('21.45'), F('31.45')))
        self.assertEqual(p.reference.position(150), (F('10.15'), F('20.3'), F('30.45')))

    def test_full_arc_enclosure_contains_midpoint_outside_endpoint_union(self):
        p = path(box=Cuboid('pointed', (0, 2, 1), ('.01', '.01', '.01')))
        first, last, middle = p.at_time(0), p.at_time(F('.15')), p.at_time(F('.075'))
        self.assertFalse(any(box.contains(middle.centre_m) for box in (first, last)))
        self.assertTrue(p.enclosing_interval(0, F('.15')).contains(middle.centre_m))

    def test_multiple_revolutions_cannot_be_replaced_by_equal_endpoints(self):
        p = path(rate=4800)
        self.assertEqual(p.at_time(0), p.at_time(F('.15')))
        enclosure = p.enclosing_interval(0, F('.15'))
        for i in range(33):
            for vertex in p.at_time(F(3*i, 640)).vertices():
                self.assertTrue(enclosure.contains(vertex))

    def test_conservative_enclosures_cover_acceleration_pose_and_resizing(self):
        p = path(reference=(3, 5, 7), velocity=(2, -3, 1), acceleration=(4, 6, -9),
                 local_velocity_mps=(1, 2, -1), local_acceleration_mps2=(3, -4, 5),
                 size_rate_mps=('.2', '-.5', '.3'), size_acceleration_mps2=(1, 2, 3))
        for begin, end in ((0, F('.15')), (F('.031'), F('.109')), (F('.08'), F('.081'))):
            enclosure = p.enclosing_interval(begin, end)
            for i in range(17):
                time = F(begin)+(end-F(begin))*i/16
                self.assertTrue(all(enclosure.contains(vertex) for vertex in p.at_time(time).vertices()))

    def test_projected_bounds_cover_vertices_along_nonunit_noncardinal_axis(self):
        p = path(local_velocity_mps=(1, 2, 3), local_acceleration_mps2=(4, 5, 6))
        axis = (F(2, 7), F(-11, 5), F(3, 13))
        low, high = p.projection_range(axis, 0, F('.15'))
        for i in range(21):
            for vertex in p.at_time(F(3*i, 400)).vertices():
                self.assertLessEqual(low, dot(vertex, axis))
                self.assertLessEqual(dot(vertex, axis), high)

    def test_shrinking_intervals_converge_to_actual_oriented_box(self):
        p = path(frame=YawFrame(F(3, 5), F(4, 5)))
        time, h = F('.075'), F(1, 10**12)
        actual, tight = p.at_time(time), p.enclosing_interval(time-h, time+h)
        self.assertEqual(p.enclosing_interval(time, time), actual)
        for real, enclosed in zip(actual.size_m, tight.size_m):
            self.assertLess(abs(real-enclosed), F(1, 10**9))
        self.assertEqual(tight.frame, actual.frame)

    def test_local_dimensions_must_stay_positive_even_between_endpoints(self):
        # s(t)=.1-4t+40t² is positive at both endpoints, negative at its minimum.
        with self.assertRaisesRegex(ValueError, 'positive'):
            path(end=F('.1'), size_rate_mps=(-4, 0, 0), size_acceleration_mps2=(80, 0, 0))
        with self.assertRaises(ValueError):
            path(size_rate_mps=(-1, 0, 0))

    def test_reference_and_yaw_cannot_have_different_saved_intervals(self):
        p = path()
        with self.assertRaises(ValueError):
            replace(p, reference=replace(p.reference, end_ms=151))
        for key, value in (('local_velocity_mps', (1, 2)), ('size_rate_mps', (True, 0, 0)),
                           ('local_acceleration_mps2', (0, 'NaN', 0))):
            with self.subTest(key=key), self.assertRaises(ValueError):
                replace(p, **{key: value})

    def test_enclosure_and_sample_queries_never_extrapolate(self):
        p = path()
        for begin, end in ((-.01, .1), (.1, .151), (.1, .09), (True, .1)):
            with self.subTest(begin=begin, end=end), self.assertRaises(ValueError):
                p.enclosing_interval(begin, end)
        with self.assertRaises(ValueError):
            p.centre_state(.151)

    def test_all_six_source_scales_preserve_parts_during_true_rotation(self):
        for name, profile in PROFILES.items():
            local = standing_cuboids(scaled_definition(BODY, profile_scale(BODY, profile)))
            self.assertEqual(len(local), 6)
            for part in local:
                with self.subTest(character=name, part=part.part):
                    p = path(box=part, reference=(12, -7, 3))
                    enclosure = p.enclosing_interval(F('.02'), F('.13'))
                    for time in (F('.02'), F('.071'), F('.13')):
                        box = p.at_time(time)
                        self.assertEqual(box.size_m, part.size_m)
                        self.assertTrue(all(enclosure.contains(v) for v in box.vertices()))

    def test_actual_prone_pose_polynomial_composes_with_yaw_without_recentring(self):
        morph = prone_morph(BODY, F(1, 5))
        q, v, a = F(1, 4), F(1, 10), F(1, 5)
        initial = {part.part: part for part in morph.local_parts(q)}
        for part in initial.values():
            world_v, world_a, size_v, size_a = morph.part_derivatives(part.part, q, v, a, YawFrame())
            p = path(box=part, local_velocity_mps=YawFrame().to_local_vector(world_v),
                     local_acceleration_mps2=YawFrame().to_local_vector(world_a), size_rate_mps=size_v,
                     size_acceleration_mps2=size_a)
            for time in (F('.01'), F('.07'), F('.14')):
                local = {box.part: box for box in morph.local_parts(q+v*time+a*time*time/2)}[part.part]
                actual = p.at_time(time)
                self.assertEqual(actual.size_m, local.size_m)
                self.assertEqual(actual.centre_m, p.yaw.frame_at(time).to_world_point(local.centre_m))

    def test_record_preserves_exact_owned_polynomials_and_is_json_data(self):
        p = path(local_velocity_mps=(F(1, 7), 2, 3))
        record = json.loads(json.dumps(p.record()))
        self.assertEqual(record['local_velocity_mps'][0], '1/7')
        self.assertEqual(record['reference'], json.loads(json.dumps(p.reference.record())))
        self.assertEqual(record['yaw'], p.yaw.record())
        self.assertEqual(record['part'], p.part)


if __name__ == '__main__':
    unittest.main()
