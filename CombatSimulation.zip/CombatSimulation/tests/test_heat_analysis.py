"""General-k analytical comparison, separate from authoritative k=2 encounters."""
from decimal import Decimal, localcontext, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
import unittest

from combat_sim.heat_analysis import analyze_heat_curve
from combat_sim.mechanics.heat import full_exposure_and_recovery_damage


class HeatAnalysisTests(unittest.TestCase):
    def assertNear(self, record, value, tolerance='1e-44'):
        with localcontext() as ctx:
            ctx.prec = 60
            self.assertLessEqual(abs(Decimal(record['decimal_approx']) - Decimal(value)), Decimal(tolerance))

    def test_known_cubic_root_curve(self):
        result = analyze_heat_curve(10, 0, 0, 8, 3)
        self.assertNear(result['exposure_damage'], '120')
        self.assertNear(result['residual_damage'], '40')
        self.assertNear(result['total_with_residual'], '160')
        self.assertNear(result['peak_dps'], '20')
        self.assertEqual(result['residual_duration_seconds']['exact'], '8/3')

    def test_known_fourth_root_curve(self):
        result = analyze_heat_curve(10, 0, 0, 16, 4)
        self.assertNear(result['exposure_damage'], '256')
        self.assertNear(result['residual_damage'], '64')
        self.assertNear(result['total_with_residual'], '320')

    def test_k2_matches_existing_exact_encounter_formula(self):
        for armor, resistance, duration in ((0, 0, 3), (165, 165, 3), (250, 250, Fraction(1, 4)), (0, 150, 10)):
            with self.subTest(values=(armor, resistance, duration)):
                result = analyze_heat_curve(900, armor, resistance, duration, 2)
                exact = full_exposure_and_recovery_damage(900, armor, resistance, duration)
                self.assertNear(result['total_with_residual'], str(exact.decimal_approximation()))

    def test_exact_ratios_across_duration_output_defenses(self):
        for k in (2, 3, 4, 10, Fraction(5, 2)):
            for output, armor, resistance in ((10, 0, 0), (10, 6, 8), (900, 165, 165)):
                for duration in (Fraction(1, 4), 1, 3, 10):
                    r = analyze_heat_curve(output, armor, resistance, duration, k)
                    self.assertEqual(Fraction(r['damage_ratios']['residual_over_exposure']['exact']), 1 / Fraction(k))
                    self.assertEqual(Fraction(r['damage_ratios']['residual_over_total']['exact']), 1 / (Fraction(k) + 1))
                    self.assertEqual(Fraction(r['residual_duration_seconds']['exact']), Fraction(duration) / k)

    def test_non_integer_k_is_not_rounded_to_an_integer(self):
        r = analyze_heat_curve(10, 0, 0, 1, Fraction(5, 2))
        self.assertEqual(r['exposure_damage']['coefficient'], '50/7')
        self.assertEqual(r['residual_damage']['coefficient'], '20/7')
        self.assertEqual(r['exposure_damage']['root_order'], '5/2')

    def test_zero_exposure_has_zero_damage_and_undefined_damage_ratio(self):
        r = analyze_heat_curve(10, 0, 0, 0, 2)
        self.assertNear(r['total_with_residual'], '0')
        self.assertIsNone(r['damage_ratios'])
        self.assertEqual(r['residual_duration_seconds']['exact'], '0')

    def test_zero_damage_floor_has_undefined_ratio(self):
        r = analyze_heat_curve(10, 20, 20, 3, 2)
        self.assertNear(r['exposure_damage'], '0')
        self.assertNear(r['residual_damage'], '0')
        self.assertIsNone(r['damage_ratios'])

    def test_no_defenses_gives_shield_coefficient_equal_to_output(self):
        self.assertEqual(analyze_heat_curve(900, 0, 0, 3)['coefficient']['exact'], '900')
        self.assertEqual(analyze_heat_curve(900, 165, 165, 3)['coefficient']['exact'], '3479/4')

    def test_numeric_quadrature_independently_checks_both_phase_integrals(self):
        # Direct midpoint quadrature of DPS, not use of the analytic antiderivative.
        # Root endpoints limit convergence; approximate check is labeled accordingly.
        count = 20000
        for k in (2, 3, 4, 10):
            duration, coefficient = 3.0, 900.0
            ds = duration / count
            exposure = ds * sum(coefficient * ((i + .5) * ds) ** (1 / k) for i in range(count))
            du = duration / k / count
            residual = du * sum(coefficient * (duration - k * ((i + .5) * du)) ** (1 / k) for i in range(count))
            r = analyze_heat_curve(900, 0, 0, 3, k)
            for numerical, key in ((exposure, 'exposure_damage'), (residual, 'residual_damage')):
                analytic = float(r[key]['decimal_approx'])
                self.assertLess(abs(numerical / analytic - 1), 1e-5)

    def test_display_is_independent_of_ambient_decimal_context(self):
        expected = analyze_heat_curve(900, 165, 165, 3, 3)
        for precision, rounding in ((6, ROUND_FLOOR), (70, ROUND_CEILING)):
            with localcontext() as ctx:
                ctx.prec, ctx.rounding = precision, rounding
                self.assertEqual(analyze_heat_curve(900, 165, 165, 3, 3), expected)

    def test_invalid_inputs_rejected(self):
        for args in ((0,0,0,3,2), (-1,0,0,3,2), (10,-1,0,3,2),
                     (10,0,-1,3,2), (10,0,0,-1,2), (10,0,0,3,1)):
            with self.subTest(args=args), self.assertRaises(ValueError):
                analyze_heat_curve(*args)
