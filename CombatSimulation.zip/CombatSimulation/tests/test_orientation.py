"""Metric and heading contracts, including independently bounded angle checks."""
from decimal import Context,Decimal as D,Inexact,Rounded,ROUND_UP,localcontext
from fractions import Fraction as F
import random
import unittest

from combat_sim.orientation import YawFrame,dot,_degrees_frame


def atan_interval(value,terms=75):
    """Alternating exact rational bounds; independent of the trig factory."""
    total=sum(((-1)**i*value**(2*i+1)/F(2*i+1) for i in range(terms)),F(0))
    other=total+(-1)**terms*value**(2*terms+1)/F(2*terms+1)
    return min(total,other),max(total,other)


class OrientationTests(unittest.TestCase):
    def test_cardinal_frames_retain_author_right_forward_up_axes(self):
        for heading,expected in ((0,(2,-1,3)),(90,(1,2,3)),(180,(-2,1,3)),(270,(-1,-2,3))):
            with self.subTest(heading=heading):
                frame=YawFrame.from_degrees(heading)
                self.assertEqual(frame.to_world_vector((1,2,3)),expected)
                self.assertEqual(frame.forward,frame.to_world_vector((0,1,0)))

    def test_half_angle_factory_has_exact_unit_length(self):
        self.assertEqual(YawFrame.from_half_angle_tangent(F(1,2)),YawFrame(F(3,5),F(4,5)))
        for tangent in (0,1,-1,F(7,13),F(1000000)):
            frame=YawFrame.from_half_angle_tangent(tangent)
            self.assertEqual(frame.cosine**2+frame.sine**2,1)

    def test_all_basis_vectors_are_exactly_orthonormal_and_right_handed(self):
        frame=YawFrame(F(5,13),F(12,13));r,f,u=frame.basis
        self.assertEqual((dot(r,r),dot(f,f),dot(u,u)),(1,1,1))
        self.assertEqual((dot(r,f),dot(r,u),dot(f,u)),(0,0,0))
        self.assertEqual(r[0]*f[1]-r[1]*f[0],1)

    def test_vector_inverse_and_metric_are_exact_for_fractional_inputs(self):
        rng=random.Random(13);frame=YawFrame.from_half_angle_tangent(F(7,9))
        for _ in range(100):
            point=tuple(F(rng.randrange(-100,101),rng.randrange(1,11)) for i in range(3))
            actual=frame.to_world_vector(point)
            self.assertEqual(frame.to_local_vector(actual),point)
            self.assertEqual(dot(point,point),dot(actual,actual))

    def test_point_round_trip_preserves_large_origin_and_small_offsets(self):
        f=YawFrame.from_half_angle_tangent(F(13,17));p=(F(1,10**30),F(-1,7),F(2,3));origin=(10**30,-10**25,100)
        self.assertEqual(f.to_local_point(f.to_world_point(p,origin),origin),p)

    def test_vector_transform_is_independent_of_point_origin(self):
        f=YawFrame(F(3,5),F(4,5));origin=(100,-40,7);p=(2,-3,4)
        self.assertEqual(tuple(a-b for a,b in zip(f.to_world_point(p,origin),origin)),f.to_world_vector(p))

    def test_periodic_negative_and_large_degree_inputs_are_canonical(self):
        self.assertEqual(YawFrame.from_degrees('-22.5'),YawFrame.from_degrees('337.5'))
        self.assertEqual(YawFrame.from_degrees(360*10**80+17),YawFrame.from_degrees(17))
        self.assertEqual(YawFrame.from_degrees(0),YawFrame.from_degrees(360))

    def test_degree_frames_preserve_exact_metric_after_angle_approximation(self):
        for heading in ('0.001','12.345','45','89.9','135','225','359.999'):
            with self.subTest(heading=heading):
                f=YawFrame.from_degrees(heading)
                self.assertEqual(f.cosine**2+f.sine**2,1)
                self.assertEqual(dot(f.to_world_vector((7,11,13)),f.to_world_vector((7,11,13))),339)

    def test_degree_fidelity_has_independent_exact_atan_bounds(self):
        a,b=atan_interval(F(1,5));c,d=atan_interval(F(1,239))
        pi_low,pi_high=16*a-4*d,16*b-4*c
        for heading in ('0.125','17.5','45'):
            with self.subTest(heading=heading):
                frame=YawFrame.from_degrees(heading,precision=40)
                low,high=atan_interval(frame.sine/(1+frame.cosine))
                actual_low,actual_high=360*low/pi_high,360*high/pi_low
                tolerance=F(1,10**38);expected=F(heading)
                self.assertGreater(actual_low,expected-tolerance)
                self.assertLess(actual_high,expected+tolerance)

    def test_precision_refinement_stays_below_declared_heading_error(self):
        a=YawFrame.from_degrees('42.321',precision=50);b=YawFrame.from_degrees('42.321',precision=80)
        self.assertLess(abs(a.cosine-b.cosine),F(1,10**48))
        self.assertLess(abs(a.sine-b.sine),F(1,10**48))

    def test_uncached_factory_owns_and_restores_decimal_context(self):
        _degrees_frame.cache_clear()
        with localcontext(Context(prec=4,rounding=ROUND_UP)) as caller:
            caller.traps[Inexact]=True;caller.flags[Rounded]=True
            before=(caller.prec,caller.rounding,dict(caller.traps),dict(caller.flags))
            result=YawFrame.from_degrees('13.2468')
            self.assertEqual((caller.prec,caller.rounding,dict(caller.traps),dict(caller.flags)),before)
        _degrees_frame.cache_clear()
        with localcontext(Context(prec=80)):
            self.assertEqual(result,YawFrame.from_degrees('13.2468'))

    def test_failed_factory_validation_leaves_caller_context_unchanged(self):
        with localcontext(Context(prec=4)) as caller:
            caller.flags[Rounded]=True;before=dict(caller.flags)
            with self.assertRaises(ValueError):YawFrame.from_degrees('NaN')
            self.assertEqual(dict(caller.flags),before)

    def test_record_retains_defining_exact_coefficients(self):
        frame=YawFrame(F(3,5),F(4,5));record=frame.record()
        self.assertEqual(YawFrame(F(record['cosine']),F(record['sine'])),frame)

    def test_invalid_frames_angles_vectors_and_precisions_are_rejected(self):
        for c,s in ((1,1),('.6','.7'),(True,0),('NaN',0)):
            with self.subTest(pair=(c,s)),self.assertRaises(ValueError):YawFrame(c,s)
        for value in (True,'Infinity',None):
            with self.subTest(angle=value),self.assertRaises(ValueError):YawFrame.from_degrees(value)
        for precision in (True,39,50.0,'50'):
            with self.subTest(precision=precision),self.assertRaises(ValueError):YawFrame.from_degrees(1,precision=precision)
        for value in ((1,2),(1,2,True),(1,2,'NaN'),'123',None):
            with self.subTest(vector=value),self.assertRaises(ValueError):YawFrame().to_world_vector(value)

