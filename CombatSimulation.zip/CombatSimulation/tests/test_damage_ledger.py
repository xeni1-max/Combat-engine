"""Applied-loss measures, temporal boundaries and immutable saved histories."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import json
import unittest
from types import SimpleNamespace

from combat_sim.applied_damage import AppliedDamage
from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.damage_ledger import (AffineHeatDose,BleedDose,DamageContribution,DamageLedger,
    PiecewiseDose,QuarticDose,dose_from_record)


def contribution(actor='A',amount=100,*,curve=None,eligible=True,kind='slash',component='projectile'):
    return DamageContribution(EffectSource(actor,'1',1),D(amount),kind,eligible,curve,component=component)


class DamageLedgerTests(unittest.TestCase):
    def test_actual_overkill_is_shared_by_nominal_post_defense_hp(self):
        ledger=DamageLedger();rows=ledger.record_loss('hit','T',100,100,
            (contribution('A',300),contribution('B',100)),100)
        self.assertEqual([e.amount for e in rows],[75,25])
        self.assertEqual(ledger.amount(),100)

    def test_overkill_allocation_is_independent_of_packet_order(self):
        entries=(contribution('B',100),contribution('A',300))
        records=[]
        for values in (entries,tuple(reversed(entries))):
            ledger=DamageLedger();ledger.record_loss('hit','T',0,0,values,100);records.append(ledger.record())
        self.assertEqual(*records)

    def test_point_window_excludes_its_old_boundary_and_includes_now(self):
        ledger=DamageLedger();ledger.record_loss('first','T',0,0,[contribution()],100)
        ledger.record_loss('second','T',10000,10000,[contribution(amount=40)],40)
        self.assertEqual(ledger.amount(end=9999,window_ms=10000),100)
        self.assertEqual(ledger.amount(end=10000,window_ms=10000),40)

    def test_initial_point_is_included_when_window_extends_before_zero(self):
        ledger=DamageLedger();ledger.record_loss('first','T',0,0,[contribution()],100)
        self.assertEqual(ledger.amount(end=0,window_ms=10000),100)

    def test_bleed_window_integrates_actual_decay_instead_of_uniform_total(self):
        curve=BleedDose(1000,0);ledger=DamageLedger()
        ledger.record_loss('bleed','T',0,8000,[contribution(amount=100,curve=curve,kind='bleeding')],100)
        self.assertEqual(ledger.amount(end=8000,window_ms=4000),25)
        self.assertEqual(ledger.amount(end=4000,window_ms=4000),75)

    def test_affine_root_windows_clip_at_cooling_zero(self):
        with localcontext(Context(prec=50)):
            curve=AffineHeatDose(3,4,0,-2);amount=curve.integral(D(0),D(3000))
        ledger=DamageLedger();ledger.record_loss('heat','T',0,3000,[contribution(amount=amount,curve=curve,kind='heat')],amount)
        self.assertEqual(ledger.amount(end=3000,window_ms=1000),0)
        self.assertAlmostEqual(ledger.amount(end=2000,window_ms=1000),D(2)*D(2).sqrt(),places=25)

    def test_dense_prefix_preserves_nonlinear_time_distribution(self):
        curve=QuarticDose(0,1000,0,100,(0,100,0,0))
        ledger=DamageLedger();ledger.record_loss('dense','T',0,1000,[contribution(curve=curve)],100)
        self.assertEqual(ledger.amount(end=500,window_ms=500),25)
        self.assertEqual(ledger.amount(end=1000,window_ms=500),75)

    def test_piecewise_curve_retains_physical_boundaries(self):
        curve=PiecewiseDose(((D(0),D(1000),QuarticDose(0,1000,0,100,(100,0,0,0))),
            (D(1000),D(2000),QuarticDose(1000,2000,0,200,(200,0,0,0)))))
        ledger=DamageLedger();ledger.record_loss('mixed','T',0,2000,[contribution(amount=300,curve=curve)],150)
        self.assertEqual(ledger.amount(end=1500,window_ms=1000),75)
        self.assertEqual(ledger.amount(),150)

    def test_eligibility_filters_credit_without_erasing_friendly_or_self_loss(self):
        ledger=DamageLedger();ledger.record_loss('hit','T',0,0,
            (contribution('A',100,eligible=True),contribution('Friend',50,eligible=False)),150)
        self.assertEqual(ledger.amount(target='T'),150)
        self.assertEqual(ledger.amount(eligible_only=True),100)
        self.assertEqual(ledger.amount(actor='Friend'),50)

    def test_no_initial_deficit_or_idle_time_is_invented(self):
        ledger=DamageLedger();ledger.observe_until(10000)
        self.assertEqual(ledger.amount(target='T',window_ms=8000),0)

    def test_observation_reads_and_output_cannot_mutate_history(self):
        ledger=DamageLedger();ledger.record_loss('hit','T',0,0,[contribution()],100)
        snapshot=ledger.record();snapshot['entries'][0]['actor']='forged';snapshot['receipts'][0]['applied_hp_damage']=0
        self.assertEqual(ledger.amount(actor='A'),100)
        self.assertEqual(ledger.entries[0].contribution.source.actor,'A')

    def test_invalid_or_duplicate_receipt_is_atomic(self):
        ledger=DamageLedger();ledger.record_loss('hit','T',100,100,[contribution()],100);saved=ledger.record()
        for args in (('hit','T',100,100,[contribution()],100),
                     ('past','T',0,99,[contribution()],100),
                     ('too_much','T',100,100,[contribution()],101),
                     ('tiny_without_loss','T',100,100,[contribution(amount=0)],D('1e-45')),
                     ('shape','T',100,1000,[contribution(curve=BleedDose(1000,0))],100)):
            with self.assertRaises((ValueError,ArithmeticError)):ledger.record_loss(*args)
            self.assertEqual(ledger.record(),saved)

    def test_unknown_continuous_shape_is_rejected(self):
        with self.assertRaises(ValueError):contribution(curve={})
        with self.assertRaises(ValueError):dose_from_record({'curve_kind':'unknown'})

    def test_queries_use_owned_precision(self):
        with localcontext(Context(prec=50)):
            curve=AffineHeatDose(1,0,0,1);amount=curve.integral(D(0),D(1000))
        ledger=DamageLedger();ledger.record_loss('root','T',0,1000,[contribution(amount=amount,curve=curve)],amount)
        values=[]
        for precision in (8,28,80):
            with localcontext(Context(prec=precision)):values.append(ledger.amount(end=777,window_ms=333))
        self.assertEqual(values,[values[0]]*3)

    def test_saved_json_roundtrip_preserves_clipped_windows(self):
        curve=QuarticDose(0,1000,0,100,(0,100,0,0));ledger=DamageLedger()
        ledger.record_loss('dense','T',0,1000,[contribution(curve=curve)],50)
        saved=json.loads(json.dumps(ledger.record(),default=str));restored=DamageLedger.from_record(saved)
        for time in (0,100,500,750,1000):
            self.assertEqual(restored.amount(end=time,window_ms=333),ledger.amount(end=time,window_ms=333))

    def test_tampered_saved_curve_or_receipt_cannot_silently_change_credit(self):
        ledger=DamageLedger();ledger.record_loss('hit','T',0,0,[contribution()],100)
        saved=ledger.record();saved['receipts'][0]['applied_hp_damage']=101
        with self.assertRaises(ValueError):DamageLedger.from_record(saved)
        with self.assertRaisesRegex(ValueError,'endpoint'):
            QuarticDose(0,1000,0,100,(0,0,0,0))

    def test_history_cannot_forecast_unobserved_future(self):
        ledger=DamageLedger()
        with self.assertRaises(ValueError):ledger.amount(end=1)
        with self.assertRaises(ValueError):ledger.amount(window_ms=0)

    def test_repeated_attack_identity_cannot_get_credit_with_recomputed_damage(self):
        actor=SimpleNamespace(team='A',profile={'abilities':{'1':{'damage_type':'slash'}}})
        target=SimpleNamespace(team='B')
        world=SimpleNamespace(precision=50,effect_system=SimpleNamespace(enabled=True),
            fighters={'A':actor,'T':target},time=D(0),log=lambda *args,**kwargs:None)
        journal=AppliedDamage(world,{'mode':'applied_hp_v1'})
        packet={'actor':'A','ability':'1','action_id':1,'projectile_id':'projectile:1','component':'projectile'}
        journal.point('T',[packet],[SimpleNamespace(hp_damage=D(100))],D(100))
        with self.assertRaisesRegex(ValueError,'already recorded'):
            journal.point('T',[packet],[SimpleNamespace(hp_damage=D(80))],D(80))
        self.assertEqual(journal.history.amount(actor='A'),100)


if __name__=='__main__':unittest.main()
