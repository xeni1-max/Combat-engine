"""Exact affine certificates and an independent exhaustive-face oracle."""
from decimal import Context,localcontext
from fractions import Fraction as F
from itertools import combinations
import json,random,unittest

from combat_sim.mechanics.affine_velocity import VelocityLimit,project_affine
from combat_sim.mechanics.velocity_projection import VelocityNode,VelocityEquality,BlockedDirection
from combat_sim.mechanics.unilateral_velocity import project_unilateral,TautDistance,ContactLimit
from combat_sim.mechanics.status import body_status_weight


def solve(matrix,rhs):
    # Independent augmented KKT elimination, not the production dual/Gram path.
    rows=[list(map(F,row))+[F(v)] for row,v in zip(matrix,rhs)]
    for j in range(len(rows)):
        pivot=next((i for i in range(j,len(rows)) if rows[i][j]),None)
        if pivot is None:return None
        rows[j],rows[pivot]=rows[pivot],rows[j];scale=rows[j][j]
        rows[j]=[x/scale for x in rows[j]]
        for i in range(len(rows)):
            if i==j:continue
            scale=rows[i][j];rows[i]=[x-scale*y for x,y in zip(rows[i],rows[j])]
    return tuple(row[-1] for row in rows)


def oracle(nodes,limits):
    nodes=tuple(sorted(nodes,key=lambda n:n.identity));size=3*len(nodes)
    offsets={n.identity:3*i for i,n in enumerate(nodes)}
    weights=tuple(F(body_status_weight(n.maximum_hp,n.armor)) for n in nodes for _ in range(3))
    wanted=tuple(x for n in nodes for x in n.velocity_mps);rows=[];bounds=[]
    for limit in limits:
        row=[F(0)]*size
        for n,normal in limit.terms:
            for axis,x in enumerate(normal):row[offsets[n]+axis]+=x
        rows.append(tuple(row));bounds.append(limit.bound)
    best=None
    for count in range(min(size,len(rows))+1):
        for active in combinations(range(len(rows)),count):
            matrix=[tuple((weights[i] if i==j else F(0)) for j in range(size))+tuple(rows[k][i] for k in active)
                for i in range(size)]
            matrix.extend(rows[k]+(F(0),)*count for k in active)
            result=solve(matrix,tuple(w*u for w,u in zip(weights,wanted))+tuple(bounds[k] for k in active))
            if result is None:continue
            value=result[:size]
            if any(x<0 for x in result[size:]):continue
            if any(sum(a*b for a,b in zip(row,value))>bound for row,bound in zip(rows,bounds)):continue
            objective=sum(w*(v-u)**2 for w,v,u in zip(weights,value,wanted))/2
            if best is None or objective<best[0]:best=(objective,value)
    if best is None:raise AssertionError('The exhaustive oracle found no origin-feasible optimum')
    return best[1]


class AffineVelocityTests(unittest.TestCase):
    def test_free_motion_and_finite_nonzero_bounds(self):
        nodes=(VelocityNode('A',(4,-2,3),500,0),)
        r=project_affine(nodes,(VelocityLimit((('A',(1,0,0)),),1),))
        self.assertEqual(dict(r.exact_velocities)['A'],(1,-2,3))
        self.assertEqual(project_affine(nodes).exact_velocities,(('A',(4,-2,3)),))

    def test_tighter_dependent_row_pivots_instead_of_solving_singular_gram(self):
        nodes=(VelocityNode('A',(3,3,0),500,0),)
        limits=(VelocityLimit((('A',(1,0,0)),),2),VelocityLimit((('A',(0,1,0)),),2),
            VelocityLimit((('A',(1,1,0)),),1))
        r=project_affine(nodes,limits)
        self.assertEqual(dict(r.exact_velocities)['A'],(F(1,2),F(1,2),0));self.assertEqual(r.pivots,1)

    def test_parallel_limits_use_the_tightest_normalized_bound(self):
        n=(VelocityNode('A',(5,2,0),500,0),)
        limits=(VelocityLimit((('A',(2,0,0)),),4),VelocityLimit((('A',(1,0,0)),),1),
            VelocityLimit((('A',(3,0,0)),),9))
        r=project_affine(n,limits);self.assertEqual(dict(r.exact_velocities)['A'],(1,2,0));self.assertEqual(len(r.rows),1)

    def test_grapple_equalities_and_blocked_axes_share_the_affine_response(self):
        nodes=(VelocityNode('A',(8,2,3),500,0),VelocityNode('B',(-2,4,5),500,0))
        r=project_affine(nodes,(VelocityLimit((('A',(1,0,0)),),1),),
            (VelocityEquality('A','B'),),(BlockedDirection('B',(0,0,1)),))
        self.assertEqual(r.exact_velocities,(('A',(1,3,0)),('B',(1,3,0))))

    def test_homogeneous_problem_agrees_with_existing_joint_solver(self):
        n=(VelocityNode('A',(-8,2,0),8140,150),VelocityNode('B',(6,3,0),20000,350))
        limits=(VelocityLimit((('A',(-1,0,0)),('B',(1,0,0))),0),VelocityLimit((('B',(-1,0,0)),),0))
        r=project_affine(n,limits);old=project_unilateral(n,(TautDistance('A','B',(1,0,0)),),(ContactLimit('B',(-1,0,0)),))
        self.assertEqual(r.exact_velocities,old.exact_velocities)

    def test_forty_random_problems_match_an_independent_exhaustive_kkt_oracle(self):
        rng=random.Random(7261)
        for case in range(40):
            nodes=tuple(VelocityNode(n,tuple(rng.randrange(-4,5) for _ in range(3)),500*(i+1),10*i)
                for i,n in enumerate('AB'))
            limits=tuple(VelocityLimit(tuple((n,tuple(rng.randrange(-1,2) for _ in range(3))) for n in 'AB'),rng.randrange(5))
                for _ in range(5))
            r=project_affine(nodes,limits)
            self.assertEqual(tuple(x for _,v in r.exact_velocities for x in v),oracle(nodes,limits),case)
            self.assertEqual(r,project_affine(reversed(nodes),reversed(limits)),case)

    def test_weighted_energy_cannot_increase_for_an_origin_feasible_projection(self):
        nodes=(VelocityNode('A',(8,-3,2),8140,150),VelocityNode('B',(-2,5,1),20000,350))
        r=project_affine(nodes,(VelocityLimit((('A',(1,-1,0)),('B',(-1,0,1))),2),))
        weights=dict(r.weights);wanted={n.identity:n.velocity_mps for n in nodes}
        energy=lambda v:sum(weights[n]*sum(x*x for x in v[n]) for n in v)
        self.assertLessEqual(energy(dict(r.exact_velocities)),energy(wanted))

    def test_context_aliasing_and_json_records(self):
        terms=[('A',[1,0,0])];limit=VelocityLimit(terms,1);terms[0][1][0]=99
        nodes=(VelocityNode('A',(3,2,0),8140,150),)
        with localcontext(Context(prec=7)):a=project_affine(nodes,(limit,))
        with localcontext(Context(prec=90)):b=project_affine(nodes,(limit,))
        self.assertEqual(a,b);self.assertEqual(dict(a.exact_velocities)['A'],(1,2,0));json.dumps(a.record())

    def test_redundant_cycles_zero_rows_and_empty_problem(self):
        nodes=tuple(VelocityNode(n,(i,0,0),500,0) for i,n in enumerate('ABC'))
        equalities=(VelocityEquality('A','B'),VelocityEquality('B','C'),VelocityEquality('C','A'))
        r=project_affine(nodes,(VelocityLimit((('A',(0,0,0)),),0),),equalities)
        self.assertTrue(all(v==(1,0,0) for _,v in r.exact_velocities));self.assertEqual(project_affine(()).exact_velocities,())

    def test_invalid_inputs_reject(self):
        nodes=(VelocityNode('A',(0,0,0),500,0),)
        for bound in (-1,True,'NaN'):
            with self.assertRaises(ValueError):VelocityLimit((('A',(1,0,0)),),bound)
        for limits in ((object(),),(VelocityLimit((('missing',(1,0,0)),),0),)):
            with self.assertRaises(ValueError):project_affine(nodes,limits)
        with self.assertRaises(ValueError):project_affine(nodes+nodes)
        with self.assertRaises(ValueError):project_affine(nodes,precision=39)


if __name__=='__main__':unittest.main()
