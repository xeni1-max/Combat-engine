"""Shared posture geometry, action/resource eligibility and live contacts."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.hitboxes import Cuboid
from tests.collider_fixtures import add_fixture_collider
from combat_sim.mobile_combat import MOBILE_SCOPE
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from tests.test_airborne_combat import run as airborne_run
from tests.test_mobile_combat import BODY, EFFECTS, MOVEMENT, PROFILES, TERRAIN, command, events
from tests.test_sprint_combat import PHYSICS, run, scenario


def fixture_run(s, *, ceiling=None, insert_at=150, precision=50):
    """A fixed ceiling enters the scene at an explicit test boundary."""
    class FixtureEncounter(SharedEncounter):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.push(D(insert_at),'test_ceiling',{})

        def _process(self,kind,payload):
            if kind=='test_ceiling':
                add_fixture_collider(self,'test_ceiling',(Cuboid('ceiling',
                    [0,-20,D(ceiling)+D('.125')],[2,2,'.25']),))
                return
            super()._process(kind,payload)

    with localcontext(Context(prec=precision)):
        return FixtureEncounter(s,PROFILES,precision=precision,body_definition=BODY,
            terrain_definition=TERRAIN,movement_definition=MOVEMENT,
            combat_locomotion_definition=EFFECTS,projectile_physics_definition=PHYSICS).run()


class PostureCombatTests(unittest.TestCase):
    def test_midpose_pays_once_and_keeps_feet_and_hands_correct(self):
        s=scenario(75);command(s,'A',0,'crouch')
        r=run(s,sample_interval_ms=None);f=r['final_states']['A']
        self.assertEqual(D(f['dyspnea']),1)
        self.assertEqual((D(f['disorientation']),D(f['instability'])),(5,5))
        self.assertEqual(D(f['body_origin_m'][2]),D('.775'))
        self.assertEqual(D(f['locomotion']['body_height_m']),D('1.55'))
        self.assertEqual(D(f['locomotion']['feet_z_m']),0)
        self.assertEqual(D(f['locomotion']['hand_world_positions_m']['left'][2]),D('.575'))
        self.assertEqual(f['hands_m'],r['initial_states']['A']['hands_m'])
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)

    def test_stand_reverses_geometry_and_uses_documented_symmetric_effects(self):
        s=scenario(350);command(s,'A',0,'crouch');command(s,'A',200,'stand')
        r=run(s)
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'standing')
        starts=events(r,'posture_transition_started','A')
        self.assertEqual([e['self_effects'] for e in starts],
            [{'disorientation':'80','instability':'80'}]*2)
        self.assertEqual(len(events(r,'dyspnea_paid','A')),2)
        self.assertEqual(r['metrics']['A']['stands_completed'],1)

    def test_no_change_does_not_pay_or_block_following_intent(self):
        s=scenario(400)
        for time,action in ((0,'stand'),(0,'crouch'),(200,'crouch'),(200,'walk')):
            command(s,'A',time,action)
        r=run(s)
        self.assertEqual(len(events(r,'posture_command_no_change','A')),2)
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'walking')

    def test_current_disorientation_delays_zero_base_gathering(self):
        s=scenario(175);command(s,'A',0,'crouch')
        s['encounter']['participants']['A']['initial_state']['disorientation']=100
        r=run(s)
        self.assertEqual(D(events(r,'posture_transition_started','A')[0]['time_ms']),100)
        self.assertEqual(D(r['final_states']['A']['locomotion']['crouch_fraction']),D('.5'))

    def test_incoming_disorientation_extends_posture_gathering(self):
        s=scenario(600,fire_at=0,target=(30,-20));command(s,'B',0,'crouch')
        s['encounter']['participants']['B']['initial_state']['disorientation']=300
        r=run(s)
        extension=[e for e in events(r,'gathering_extended') if e['actor']=='B']
        self.assertTrue(extension)
        self.assertGreater(D(events(r,'posture_transition_started','B')[0]['time_ms']),300)

    def test_weapons_wait_for_transition_then_fire_from_lowered_hands(self):
        s=scenario(700,fire_at=0,target=(100,-20));command(s,'A',0,'crouch')
        r=run(s)
        first=events(r,'projectile_released','A')[0]
        self.assertGreater(D(first['time_ms']),150)
        self.assertEqual(D(first['origin_m'][2]),D('.625'))
        self.assertTrue(events(r,'projectile_body_collision'))

    def test_crouch_waits_for_existing_weapon_active(self):
        s=scenario(400,fire_at=0);command(s,'A',100,'crouch')
        r=run(s)
        release=events(r,'projectile_released','A')[0]
        request=events(r,'posture_requested','A')[0]
        self.assertEqual(release['time_ms'],request['time_ms'])
        self.assertEqual(r['metrics']['A']['crouches_completed'],1)

    def test_post_release_crouch_changes_actual_hit_part_in_both_flight_models(self):
        for gravity in (False,True):
            with self.subTest(gravity=gravity):
                s=scenario(450,fire_at=0,target=(200,-20))
                if not gravity:s['scope']=dict(MOBILE_SCOPE)
                baseline=run(s,sample_interval_ms=None)
                command(s,'B',120,'crouch')
                r=run(s,sample_interval_ms=None)
                self.assertEqual(events(baseline,'projectile_body_collision')[0]['hit_parts'],['torso'])
                self.assertEqual(events(r,'projectile_body_collision')[0]['hit_parts'],['head'])
                self.assertEqual(events(r,'projectile_released')[0]['aim_point_m'],
                    events(baseline,'projectile_released')[0]['aim_point_m'])

    def test_projectile_hits_during_live_shape_transition(self):
        s=scenario(450,fire_at=0,target=(200,-20));command(s,'B',250,'crouch')
        r=run(s)
        hit=events(r,'projectile_body_collision')[0]
        self.assertLess(D(hit['time_ms']),400)
        self.assertGreater(D(hit['time_ms']),250)
        self.assertEqual(hit['hit_parts'],['torso'])
        self.assertEqual(r['metrics']['B']['crouches_completed'],1)
        self.assertFalse(events(r,'posture_interrupted'))

    def test_running_posture_retains_pace_and_applies_running_status_factor(self):
        s=scenario(600);command(s,'A',0,'run');command(s,'A',300,'crouch')
        r=run(s)
        start=events(r,'posture_transition_started','A')[0]
        self.assertEqual(D(start['self_effects']['instability']),96)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'running')
        self.assertEqual(D(r['final_states']['A']['locomotion']['speed_mps']),D('6.4'))

    def test_sprinting_posture_reanchors_continuous_resource_payment(self):
        s=scenario(800);command(s,'A',0,'sprint');command(s,'A',500,'crouch')
        a=run(s,sample_interval_ms=None);b=run(s,sample_interval_ms=37,precision=80)
        self.assertEqual(a['final_states']['A']['locomotion']['mode'],'sprinting')
        self.assertEqual(a['final_states']['A']['locomotion']['posture'],'crouched')
        self.assertAlmostEqual(D(a['final_states']['A']['dyspnea']),D(b['final_states']['A']['dyspnea']),places=30)
        payments=events(a,'dyspnea_paid','A')
        self.assertEqual(payments[-1]['action_kind'],'posture')
        before=D(payments[-1]['before'])
        self.assertAlmostEqual(D(payments[-1]['amount']),(1+before/100)**2,places=24)

    def test_crouched_jump_preserves_feet_and_landing_geometry(self):
        s=scenario(1300);command(s,'A',0,'crouch');command(s,'A',250,'jump')
        r=airborne_run(s)
        self.assertEqual(len(events(r,'jump_landed','A')),1)
        self.assertEqual(D(r['final_states']['A']['body_origin_m'][2]),D('.675'))
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'crouched')

    def test_posture_intent_waits_for_landing(self):
        s=scenario(1200);command(s,'A',0,'jump');command(s,'A',300,'crouch')
        r=airborne_run(s)
        self.assertGreaterEqual(D(events(r,'posture_transition_started','A')[0]['time_ms']),
            D(events(r,'jump_landed','A')[0]['time_ms']))

    def test_unaffordable_posture_waits_without_partial_payment(self):
        s=scenario(500);command(s,'A',0,'crouch')
        s['encounter']['participants']['A']['initial_state']['dyspnea']=100
        r=run(s)
        start=D(events(r,'posture_transition_started','A')[0]['time_ms'])
        self.assertGreater(start,0)
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)
        self.assertLessEqual(D(r['final_states']['A']['dyspnea']),100)

    def test_standing_checks_clearance_and_accepts_exact_fit(self):
        for ceiling,posture in (('1.5','crouched'),('1.75','standing')):
            with self.subTest(ceiling=ceiling):
                s=scenario(600);command(s,'A',0,'crouch');command(s,'A',300,'stand')
                r=fixture_run(s,ceiling=ceiling)
                self.assertEqual(r['final_states']['A']['locomotion']['posture'],posture)
                self.assertEqual(r['metrics']['A']['stand_requests_rejected'],int(posture=='crouched'))
                self.assertEqual(len(events(r,'dyspnea_paid','A')),1 if posture=='crouched' else 2)

    def test_new_obstruction_freezes_expansion_and_invalidates_completion(self):
        s=scenario(600);command(s,'A',0,'crouch');command(s,'A',300,'stand')
        for precision in (50,80):
            r=fixture_run(s,ceiling='1.6',insert_at=350,precision=precision)
            self.assertEqual(len(events(r,'posture_interrupted','A')),1)
            self.assertFalse(events(r,'stand_completed','A'))
            self.assertEqual(D(r['final_states']['A']['locomotion']['body_height_m']),D('1.6'))
            self.assertEqual(r['final_states']['A']['locomotion']['posture'],'partial')
            self.assertEqual(D(events(r,'body_contact')[0]['raw_status']),0)

    def test_live_translation_into_arena_cube_freezes_crouch_and_stops_motion(self):
        s=scenario(700);s['encounter']['participants']['A']['position_m']=[3.5,0]
        command(s,'A',0,'run');command(s,'A',250,'crouch')
        r=run(s,sample_interval_ms=None)
        self.assertEqual(len(events(r,'body_contact')),1)
        self.assertEqual(events(r,'body_contact')[0]['second'],'cube_1')
        self.assertEqual(len(events(r,'posture_interrupted','A')),1)
        self.assertFalse(events(r,'crouch_completed','A'))
        self.assertEqual(D(r['final_states']['A']['position_m'][0]),D('4.95'))
        self.assertEqual(D(r['final_states']['A']['locomotion']['speed_mps']),0)
        self.assertGreater(D(events(r,'body_contact')[0]['raw_status']),0)

    def test_partial_pose_can_crouch_again_without_clipping(self):
        s=scenario(700);command(s,'A',0,'crouch');command(s,'A',300,'stand');command(s,'A',500,'crouch')
        r=fixture_run(s,ceiling='1.6',insert_at=350)
        self.assertEqual(r['final_states']['A']['locomotion']['posture'],'crouched')
        self.assertEqual(r['metrics']['A']['crouches_completed'],2)

    def test_death_during_transition_freezes_pose_without_stale_completion(self):
        s=scenario(500,fire_at=0,target=(30,-20));command(s,'B',120,'crouch')
        s['encounter']['participants']['B']['initial_state']['hp']=1
        r=run(s)
        self.assertFalse(r['final_states']['B']['alive'])
        self.assertFalse(events(r,'crouch_completed','B'))
        self.assertEqual(events(r,'posture_interrupted','B')[0]['reason'],'death')
        fraction=D(r['final_states']['B']['locomotion']['crouch_fraction'])
        self.assertGreater(fraction,0);self.assertLess(fraction,1)

    def test_death_during_posture_gathering_does_not_pay(self):
        s=scenario(500,fire_at=0,target=(30,-20));command(s,'B',0,'crouch')
        s['encounter']['participants']['B']['initial_state'].update(hp=1,disorientation=300)
        r=run(s)
        self.assertFalse(r['final_states']['B']['alive'])
        self.assertFalse(events(r,'posture_transition_started','B'))
        self.assertFalse(events(r,'dyspnea_paid','B'))

    def test_sprint_exhaustion_freezes_active_posture_before_free_stop(self):
        s=scenario(1300);command(s,'A',0,'sprint');command(s,'A',900,'crouch')
        s['encounter']['participants']['A']['initial_state']['dyspnea']=90
        # Pick a request shortly before natural exhaustion, while still
        # affordable. The normal continuous sprint boundary interrupts Active.
        s['movement_script'][-1]['at_ms']=450
        r=run(s,sample_interval_ms=None)
        interrupted=events(r,'posture_interrupted','A')
        self.assertEqual(len(interrupted),1)
        self.assertEqual(interrupted[0]['reason'],'sprint_exhaustion')
        self.assertEqual(len(events(r,'maximum_dyspnea_trigger','A')),1)
        self.assertEqual(len(events(r,'special_stop_started','A')),1)
        self.assertFalse(events(r,'crouch_completed','A'))

    def test_posture_payment_reaching_sprint_capacity_triggers_once(self):
        # Test the exact resource boundary using a test-only Db that makes
        # (Db + 96/100)^2 exactly four. Production Db remains one.
        movement=deepcopy(MOVEMENT)
        movement['crouch']['characters']['1E2']['listed_dyspnea_value']='1.04'
        class CapacityEncounter(SharedEncounter):
            def start_combat_posture(self,actor):
                actor.dyspnea=D(96)
                self.motion[actor.id]['sprint_anchor']=(self.time,D(96))
                return super().start_combat_posture(actor)
        s=scenario(1000);command(s,'A',0,'sprint');command(s,'A',500,'crouch')
        with localcontext(Context(prec=50)):
            r=CapacityEncounter(s,PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=movement,combat_locomotion_definition=EFFECTS,
                projectile_physics_definition=PHYSICS).run()
        self.assertEqual(len(events(r,'maximum_dyspnea_trigger','A')),1)
        self.assertEqual(len(events(r,'special_stop_started','A')),1)
        self.assertFalse(events(r,'crouch_completed','A'))
        self.assertEqual(D(events(r,'posture_interrupted','A')[0]['crouch_fraction']),0)

    def test_observations_precision_and_actor_order_preserve_posture_combat(self):
        s=scenario(1200,fire_at=0,target=(100,-20));command(s,'B',120,'crouch');command(s,'B',600,'stand')
        reference=run(s,sample_interval_ms=None)
        reversed_s=deepcopy(s)
        reversed_s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        for trial in (run(s,sample_interval_ms=37),run(s,precision=80),run(reversed_s)):
            for actor in ('A','B'):
                for key in ('hp','armor','dyspnea'):
                    self.assertAlmostEqual(D(reference['final_states'][actor][key]),D(trial['final_states'][actor][key]),places=25)
                self.assertEqual(reference['final_states'][actor]['locomotion']['posture'],
                    trial['final_states'][actor]['locomotion']['posture'])

    def test_historical_definition_requires_explicit_posture_opt_in(self):
        effects=deepcopy(EFFECTS);effects.pop('posture')
        s=scenario(500);command(s,'A',0,'crouch')
        with self.assertRaises(UnsupportedMechanicError):run(s,effects=effects)

    def test_invalid_effect_rule_and_geometry_fail_before_execution(self):
        for field in ('payment_timing','stand_effects','hands'):
            effects=deepcopy(EFFECTS);effects['posture'][field]='unsupported'
            with self.assertRaises(UnsupportedMechanicError):run(scenario(),effects=effects)


if __name__=='__main__':unittest.main()
