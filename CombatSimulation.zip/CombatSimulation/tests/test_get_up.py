"""Get Up source values, exact arithmetic and existing dyspnea integration."""
from copy import deepcopy
from decimal import Decimal, localcontext
from fractions import Fraction as F
import json
from pathlib import Path
import unittest

from combat_sim.mechanics.dyspnea import apply_action_dyspnea_at_phase
from combat_sim.mechanics.get_up import get_up_profile
from combat_sim.models import UnsupportedMechanicError


DEFINITION = json.loads((Path(__file__).resolve().parents[1] /
                         'data/movement/get_up.json').read_text())


class GetUpTests(unittest.TestCase):
    def test_six_documented_character_profiles(self):
        expected = {'1E1': (400, F(3)), '1E2': (400, F(3)),
                    '1E3': (500, F(3)), '1E5': (400, F(12, 5)),
                    '2E4': (300, F(12, 5)), '3E5': (300, F(12, 5))}
        self.assertEqual(set(DEFINITION['characters']), set(expected))
        for character, (duration, cost) in expected.items():
            with self.subTest(character=character):
                profile = get_up_profile(character, DEFINITION)
                self.assertEqual(profile['active_ms'], duration)
                self.assertEqual(profile['gathering_ms'], 0)
                self.assertEqual(profile['dyspnea']['base_value'], cost)

    def test_doubles_base_before_squaring(self):
        for character, expected in (('1E1', F(9)), ('2E4', F(144, 25))):
            rule = get_up_profile(character, DEFINITION)['dyspnea']
            payment = apply_action_dyspnea_at_phase(0, rule, 'active_start')
            self.assertTrue(payment.allowed)
            self.assertEqual(payment.action_value, expected)
            self.assertEqual(payment.after, expected)

    def test_existing_dyspnea_changes_cost(self):
        rule = get_up_profile('1E1', DEFINITION)['dyspnea']
        payment = apply_action_dyspnea_at_phase(50, rule, 'active_start')
        self.assertEqual(payment.action_value, F(49, 4))
        self.assertEqual(payment.after, F(249, 4))

    def test_insufficient_capacity_does_not_pay(self):
        rule = get_up_profile('1E1', DEFINITION)['dyspnea']
        payment = apply_action_dyspnea_at_phase(95, rule, 'active_start')
        self.assertFalse(payment.allowed)
        self.assertEqual(payment.before, payment.after)

    def test_only_active_start_pays(self):
        rule = get_up_profile('1E1', DEFINITION)['dyspnea']
        for phase in ('gathering_start', 'active_end', 'active_firing_end'):
            with self.subTest(phase=phase):
                self.assertIsNone(apply_action_dyspnea_at_phase(0, rule, phase))

    def test_death_before_payment_does_not_pay(self):
        rule = get_up_profile('1E1', DEFINITION)['dyspnea']
        self.assertIsNone(apply_action_dyspnea_at_phase(
            0, rule, 'active_start', cancelled_before_payment=True))

    def test_profiles_do_not_mutate_definition_or_share_outputs(self):
        original = deepcopy(DEFINITION)
        profile = get_up_profile('1E1', DEFINITION)
        profile['dyspnea']['base_value'] = 100
        self.assertEqual(DEFINITION, original)
        self.assertEqual(get_up_profile('1E1', DEFINITION)['dyspnea']['base_value'], 3)

    def test_decimal_context_does_not_change_profiles(self):
        definition = deepcopy(DEFINITION)
        definition['characters']['2E4']['jump_base_dyspnea'] = Decimal('1.2')
        with localcontext() as context:
            context.prec = 2
            profile = get_up_profile('2E4', definition)
        self.assertEqual(profile['dyspnea']['base_value'], F(12, 5))

    def test_unknown_character_is_rejected(self):
        with self.assertRaises(UnsupportedMechanicError):
            get_up_profile('invented', DEFINITION)

    def test_invalid_numeric_inputs_are_rejected(self):
        for key, values in (('recovery_value', (0, -1, True, 'NaN', 'Infinity', None)),
                            ('jump_base_dyspnea', (-1, True, 'NaN', None))):
            for value in values:
                with self.subTest(key=key, value=value):
                    definition = deepcopy(DEFINITION)
                    definition['characters']['1E1'][key] = value
                    with self.assertRaises(ValueError):
                        get_up_profile('1E1', definition)

    def test_incomplete_definition_is_rejected(self):
        for target, key in ((None, 'active_recovery_multiplier'),
                            ('1E1', 'jump_base_dyspnea')):
            definition = deepcopy(DEFINITION)
            del (definition if target is None else definition['characters'][target])[key]
            with self.assertRaises(ValueError):
                get_up_profile('1E1', definition)

    def test_unsupported_phase_configuration_is_rejected(self):
        for key, value in (('gathering_ms', 100), ('physical_recovery_ms', 10),
                            ('capacity_check_timing', 'activation'),
                            ('payment_timing', 'active_end')):
            with self.subTest(key=key):
                definition = deepcopy(DEFINITION)
                definition[key] = value
                with self.assertRaises(UnsupportedMechanicError):
                    get_up_profile('1E1', definition)
