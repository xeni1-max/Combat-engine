"""Actual passive healing shares damage, resources, death and revival.

Ordinary casts are public-API scenarios. Explicit HP/restoration probes reuse
the labelled life-test harness for boundary cases without inventing abilities.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import json
import unittest

from combat_sim.analysis import summarize
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import run_shared_scenario
from tests.test_mobile_combat import BODY,MOVEMENT,PROFILES,TERRAIN,command,events
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_motion_boundary_combat import CURRENT
from tests.test_melee_venom_combat import scene as melee_scene
from tests.test_revival_combat import scene,quiet,run as probe_run
from tests.test_world_colliders_combat import wall


def beam_scene(duration=4500):
    s=scene(duration);s['encounter']['participants']['A']['initial_state']['hp']=100
    s['encounter']['participants']['B']['character']='1E1';s['action_selection']['B']['abilities']=['4']
    return s


def run(s,*,operations=(),rules=CURRENT,profiles=PROFILES,interval=None,precision=50):
    if operations:
        return probe_run(s,operations=operations,effects=rules,profiles=profiles,interval=interval,precision=precision)
    return run_shared_scenario(s,profiles,precision=precision,sample_interval_ms=interval,
        body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,
        combat_locomotion_definition=rules,jump_definition=JUMP,climb_definition=CLIMB,
        projectile_physics_definition=PHYSICS)


def paid(r,name='A',*,generation=None):
    return sum((D(e['applied_healing_hp']) for e in r['healing_history']['entries'] if e['actor']==name
        and (generation is None or e['recipient_life_generation']==generation)),D(0))


class HPRecoveryCombatTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=60));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history'])
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(life['initial_hp']) for life in lives),D(0))+paid(r,name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-ledger.amount(target=name)),D('1e-8'))
        return ledger

    def test_real_gun_and_venom_pay_point_and_continuous_healing_once(self):
        r=run(scene());rows=r['healing_history']['entries']
        self.assertGreater(paid(r),0)
        self.assertTrue(any(e['begin_ms']==e['end_ms'] and D(e['applied_healing_hp'])>0 for e in rows))
        self.assertTrue(any(e['begin_ms']!=e['end_ms'] and D(e['applied_healing_hp'])>0 for e in rows))
        self.assertLess(abs(D(r['metrics']['A']['hp_healed'])-paid(r)),D('1e-20'))
        self.assertFalse(any(e['actor']=='B' for e in rows))
        self.conserved(r)

    def test_real_heat_death_is_delayed_by_continuous_healing(self):
        s=beam_scene();r=run(s);old_rules=deepcopy(CURRENT);old_rules.pop('hp_recovery')
        old=run(s,rules=old_rules)
        death=D(events(r,'character_died','A')[0]['time_ms']);earlier=D(events(old,'character_died','A')[0]['time_ms'])
        self.assertGreater(death,earlier+50)
        self.assertLess(death,earlier+100)
        self.assertGreater(D(r['final_states']['A']['hp']),D(old['final_states']['A']['hp']))
        ledger=self.conserved(r)
        self.assertGreater(ledger.amount(target='A',target_life_generation=1),100)
        self.assertLess(abs(ledger.amount(target='A',target_life_generation=1)-100-paid(r,generation=1)),D('1e-8'))

    def test_two_actual_melee_healers_revive_with_capped_hp_and_keep_conserved_life_history(self):
        s=melee_scene(14000);s['encounter']['participants']['B']['character']='2E4'
        s['action_selection']['B']['start_ms']=0
        r=run(s);ledger=self.conserved(r)
        self.assertGreater(paid(r,'A'),0);self.assertGreater(paid(r,'B'),0)
        for name in ('A','B'):
            self.assertEqual(r['final_states'][name]['life_generation'],2)
            born=events(r,'life_restored',name)[0]
            self.assertEqual(D(born['hp']),9080)
            self.assertEqual(r['revival_states'][name]['charges_remaining'],2)
            self.assertGreater(ledger.amount(target=name,target_life_generation=1),9080)
        other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        alternate=run(other,precision=80,interval=137);self.conserved(alternate)
        for name in ('A','B'):
            self.assertLess(abs(paid(r,name)-paid(alternate,name)),D('1e-8'))
            self.assertLess(abs(D(r['final_states'][name]['hp'])-D(alternate['final_states'][name]['hp'])),D('1e-8'))
            self.assertLess(abs(D(events(r,'life_restored',name)[0]['time_ms'])-
                D(events(alternate,'life_restored',name)[0]['time_ms'])),D('1e-8'))

    def test_no_initial_deficit_or_shield_loss_creates_a_healing_budget(self):
        s=scene(400);s['encounter']['participants']['A']['initial_state'].update(hp=8000,shield=1000)
        r=run(s)
        self.assertEqual(D(r['final_states']['A']['hp']),8000)
        self.assertEqual(paid(r),0)
        self.assertGreater(D(r['metrics']['A']['shield_damage_received']),0)
        self.assertTrue(any(D(e['requested_hp'])>0 for e in r['healing_history']['entries']))

    def test_eligible_outgoing_damage_without_a_wound_discards_its_entitlement(self):
        s=melee_scene(300);s['encounter']['participants']['A']['initial_state']['hp']=8000
        r=run(s)
        self.assertEqual(paid(r),0)
        self.assertEqual(D(r['final_states']['A']['hp']),8000)
        self.assertGreater(D(r['metrics']['A']['healing_entitlement_discarded']),0)

    def test_90_percent_capacity_is_consumed_and_only_new_wounds_add_more(self):
        ops=[(10,{'op':'credit','actor':'B','target':'A','amount':100}),
            (20,{'op':'credit','amount':500}),(30,{'op':'credit','amount':500}),
            (40,{'op':'credit','actor':'B','target':'A','amount':20}),(50,{'op':'credit','amount':500})]
        r=run(quiet(100),operations=ops)
        self.assertEqual([D(e['applied_healing_hp']) for e in r['healing_history']['entries']],[90,0,18])
        self.assertEqual(paid(r),108)
        self.assertEqual(D(r['final_states']['A']['hp']),9068)
        self.conserved(r)

    def test_window_expiry_does_not_restore_spent_funding_or_block_fresh_wounds(self):
        ops=[(10,{'op':'credit','actor':'B','target':'A','amount':100}),
            (20,{'op':'credit','amount':150}),
            (8010,{'op':'credit','amount':200}),
            (8100,{'op':'credit','actor':'B','target':'A','amount':100}),
            (8110,{'op':'credit','amount':500})]
        r=run(quiet(8200),operations=ops)
        self.assertEqual([D(e['applied_healing_hp']) for e in r['healing_history']['entries']],[30,0,90])
        self.assertEqual(paid(r),120)
        self.conserved(r)

    def test_simultaneous_lethal_incoming_hit_cannot_be_undone_by_passive_healing(self):
        ops=[(10,{'op':'credit','amount':500}),(10,{'op':'kill'})]
        r=run(quiet(100),operations=ops)
        self.assertEqual(D(r['final_states']['A']['hp']),0)
        self.assertEqual(paid(r),0)
        self.assertEqual(r['healing_history']['entries'][0]['recipient_life_generation'],1)
        self.assertEqual(r['revival_attempts'][0]['status'],'active')
        self.conserved(r)

    def test_two_healers_use_shared_pre_heal_damage_and_separate_capacity(self):
        s=quiet(100);s['encounter']['participants']['B']['character']='2E4'
        ops=[(10,{'op':'credit','actor':'A','target':'B','amount':100}),
            (10,{'op':'credit','actor':'B','target':'A','amount':100})]
        r=run(s,operations=ops)
        self.assertEqual(paid(r,'A'),20);self.assertEqual(paid(r,'B'),20)
        self.assertEqual(D(r['final_states']['A']['hp']),9000)
        self.assertEqual(D(r['final_states']['B']['hp']),9000)
        self.conserved(r)

    def test_friendly_hp_and_construct_damage_do_not_create_entitlement(self):
        for obstacle in (False,True):
            s=melee_scene(300)
            if obstacle:s['initial_colliders']=[wall(x='.65',hp=1000,size=('.1',2,2),z=1)]
            else:
                s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
                s['encounter']['participants']['C'].update(team='A',position_m=['.65',-20])
                s['action_selection']['C']=deepcopy(s['action_selection']['B'])
            r=run(s,operations=[(100,{'op':'credit','actor':'B','target':'A','amount':100})])
            self.assertEqual(paid(r),0)
            self.assertEqual(D(r['final_states']['A']['hp']),8980)
            self.conserved(r)

    def test_shield_only_outgoing_damage_cannot_fund_passive_healing(self):
        s=scene(1000);s['encounter']['participants']['B']['initial_state']['shield']=1000
        r=run(s)
        self.assertGreater(D(r['metrics']['B']['shield_damage_received']),0)
        self.assertEqual(paid(r),0)
        self.assertEqual(r['revival_states']['A']['charges_remaining'],3)

    def test_old_source_effect_can_heal_its_restored_actor_without_changing_source_life(self):
        r=run(beam_scene());ledger=self.conserved(r);by_id={e.id:e for e in ledger.entries}
        self.assertTrue(any(e['recipient_life_generation']==2 and D(e['applied_healing_hp'])>0
            and any(by_id[k].contribution.source.life_generation==1 for k in e['trigger_loss_ids'])
            for e in r['healing_history']['entries']))
        death=D(events(r,'character_died','A')[0]['time_ms']);birth=D(events(r,'life_restored','A')[0]['time_ms'])
        self.assertTrue(any(D(e['requested_hp'])>0 and D(e['applied_healing_hp'])==0
            and death<=D(e['begin_ms'])<D(e['end_ms'])<=birth for e in r['healing_history']['entries']))

    def test_saved_healing_curves_retain_nonlinear_prefixes(self):
        r=run(beam_scene())
        saved=HealingHistory.from_run(r)
        rows=[e for e in r['healing_history']['entries'] if e['curve_id'] and D(e['applied_healing_hp'])>0]
        self.assertTrue(rows)
        for row in rows:
            curve=saved.curves[row['curve_id']];begin,end=map(D,(row['begin_ms'],row['end_ms']))
            self.assertGreater(curve.integral(begin,end),0)
            actual=D(row['applied_healing_hp'])
            self.assertLess(abs(curve.integral(begin,end)-D(row['curve_basis_hp'])),D('1e-20'))
            self.assertLess(abs(actual-D(row['curve_basis_hp'])),D('1e-8'))

    def test_observations_precision_and_actor_order_do_not_change_continuous_survival(self):
        s=beam_scene();baseline=run(s)
        for precision,interval in ((50,37),(50,100),(80,113)):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,precision=precision,interval=interval)
            self.conserved(r)
            self.assertLess(abs(paid(r)-paid(baseline)),D('1e-8'))
            for name in r['final_states']:
                self.assertLess(abs(D(r['final_states'][name]['hp'])-D(baseline['final_states'][name]['hp'])),D('1e-8'))
            for kind in ('character_died','life_restored'):
                a,b=events(r,kind,'A'),events(baseline,kind,'A')
                self.assertEqual(len(a),len(b))
                for x,y in zip(a,b):self.assertLess(abs(D(x['time_ms'])-D(y['time_ms'])),D('1e-8'))

    def test_body_movement_can_overlap_passive_healing_without_resource_ownership(self):
        s=scene(1000);s['encounter']['participants']['A']['movement_direction']=[0,1]
        command(s,'A',300,'walk');r=run(s)
        self.assertTrue(events(r,'movement_active_started','A'))
        self.assertGreater(paid(r),0)
        self.assertTrue(all(a['action']['kind']!='healing' for point in r['curve'] for a in point['states']['A'].get('owned_actions',[])))
        self.conserved(r)

    def test_moving_healer_leaves_a_real_beam_and_keeps_correct_residual_healing(self):
        s=beam_scene();s['encounter']['participants']['A']['initial_state']['hp']=9080
        s['encounter']['participants']['A']['movement_direction']=[0,1]
        command(s,'A',400,'run')
        baseline=run(s);alternate=run(s,interval=137,precision=80)
        left=[e for e in events(baseline,'heat_exposure_left') if e.get('target')=='A']
        self.assertTrue(left);self.assertLess(D(left[0]['time_ms']),3358)
        self.assertGreater(paid(baseline),0);self.assertTrue(baseline['final_states']['A']['alive'])
        self.assertTrue(any(D(row['begin_ms'])>D(left[0]['time_ms']) and D(row['applied_healing_hp'])>0
            for row in baseline['healing_history']['entries']))
        self.conserved(baseline);self.conserved(alternate)
        self.assertLess(abs(paid(baseline)-paid(alternate)),D('1e-8'))
        for name in baseline['final_states']:
            self.assertLess(abs(D(baseline['final_states'][name]['hp'])-D(alternate['final_states'][name]['hp'])),D('1e-8'))

    def test_summary_and_result_are_json_serializable_with_actual_healing_totals(self):
        r=run(scene());summary=summarize(r)
        self.assertEqual(json.loads(json.dumps(r)),r)
        self.assertGreater(D(summary['participants']['A']['hp_damage_received']),600)
        self.assertEqual(summary['participants']['A']['hp_healed'],r['metrics']['A']['hp_healed'])
        self.conserved(r)

    def test_engineering_defense_variant_combines_two_healers_with_fluid_heat_and_shield_recovery(self):
        # Authored attacks and shield debt; increased heat defense preserves
        # these bodies until the real 20 s recovery boundary is exercised.
        s=melee_scene(21600);s['encounter']['participants']['A']['character']='1E1'
        s['action_selection']['A'].update(abilities=['4'],start_ms=0)
        s['encounter']['participants']['B'].update(character='2E4',position_m=[30,-20],initial_state={'shield':4000})
        s['action_selection']['B']['start_ms']=20770
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(team='A',position_m=[29,-20],facing='+x',initial_state={'shield':0})
        s['action_selection']['C']=deepcopy(s['action_selection']['B']);s['action_selection']['C']['start_ms']=20000
        profiles=deepcopy(PROFILES);profiles['2E4']['resistances']['heat']=2000
        baseline=run(s,profiles=profiles);other=run(s,profiles=profiles,interval=137,precision=80)
        self.assertTrue(events(baseline,'thermal_recovery_activated'))
        self.assertGreater(paid(baseline,'B'),0);self.assertGreater(paid(baseline,'C'),0)
        self.conserved(baseline);self.conserved(other)
        for name in ('B','C'):
            self.assertLess(abs(paid(baseline,name)-paid(other,name)),D('1e-8'))
            self.assertLess(abs(D(baseline['final_states'][name]['hp'])-D(other['final_states'][name]['hp'])),D('1e-8'))

    def test_invalid_mode_dependency_and_passive_fraction_reject(self):
        rules=deepcopy(CURRENT);rules['hp_recovery']={'mode':'unknown'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'HP healing'):run(scene(),rules=rules)
        rules=deepcopy(CURRENT)
        for key in ('life_cycles','death_revival','melee'):rules.pop(key)
        with self.assertRaisesRegex(UnsupportedMechanicError,'HP healing'):run(scene(),rules=rules)
        p=deepcopy(PROFILES);p['2E4']['passive_effects']['basic_10']['fraction']=-1
        with self.assertRaises(ValueError):run(scene(),profiles=p)


if __name__=='__main__':unittest.main()
