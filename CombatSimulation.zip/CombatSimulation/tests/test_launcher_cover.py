"""The instantaneous grenade pulse and released gas have explicit cover rules."""
from decimal import Decimal as D
import unittest

from tests.test_launcher_combat import scene,world_target,run
from tests.test_world_colliders_combat import wall
from tests.test_mobile_combat import events


def covered_scene(blocks_areas=True):
    s=scene(1800,target=8);world_target(s,(8,-20,1))
    s['initial_colliders']=[wall('cover',x=6,z=2,hp=None,size=('.2',8,4),
        blocking={'projectiles':True,'bodies':True,'areas':blocks_areas})]
    return s


class LauncherCoverTests(unittest.TestCase):
    def test_area_cover_blocks_the_once_only_pulse_while_gas_exposes_the_body(self):
        r=run(covered_scene())
        self.assertEqual(len(r['poison_grenade_bursts']),1)
        self.assertNotIn('B',r['poison_grenade_bursts'][0]['recipients'])
        self.assertEqual({p['target'] for p in r['poison_exposures']},{'B'})
        self.assertLess(D(r['final_states']['B']['hp']),8140)
        self.assertFalse([e for e in events(r,'impact_batch_resolved') if e['target']=='B'])

    def test_unblocked_pulse_applies_once_and_has_the_same_independent_chemical_damage(self):
        covered=run(covered_scene());r=run(covered_scene(False))
        self.assertIn('B',r['poison_grenade_bursts'][0]['recipients'])
        hits=[e for e in events(r,'impact_batch_resolved') if e['target']=='B']
        self.assertEqual(len(hits),1)
        self.assertTrue(all(D(hits[0]['status_additions'][k])>0 for k in ('disorientation','instability')))
        self.assertEqual(r['poison_volumes'],covered['poison_volumes'])
        self.assertLess(abs(D(r['final_states']['B']['hp'])-D(covered['final_states']['B']['hp'])),D('1e-8'))


if __name__=='__main__':unittest.main()
