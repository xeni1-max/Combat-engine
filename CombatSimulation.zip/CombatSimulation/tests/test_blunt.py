import unittest
from fractions import Fraction

from combat_sim.mechanics.blunt import (
    armor_reduction,
    post_mitigation_damage,
    raw_armor_reduction,
    raw_post_mitigation_damage,
)


class BluntFormulaTests(unittest.TestCase):
    def test_documented_formulas_for_d300_a150(self):
        self.assertEqual(post_mitigation_damage(300, 150), Fraction(225))
        self.assertEqual(armor_reduction(300, 150), Fraction(159, 28))

    def test_documented_formulas_for_200_damage_overflow(self):
        self.assertEqual(post_mitigation_damage(200, 150), Fraction(175, 2))
        self.assertEqual(armor_reduction(200, 150), Fraction(197, 56))

    def test_zero_armor(self):
        self.assertEqual(post_mitigation_damage(300, 0), Fraction(300))
        self.assertEqual(armor_reduction(300, 0), Fraction(6))

    def test_zero_damage_is_rejected_as_undefined_denominator(self):
        with self.assertRaisesRegex(ValueError, "d=0"):
            post_mitigation_damage(0, 150)
        with self.assertRaisesRegex(ValueError, "d=0"):
            armor_reduction(0, 150)

    def test_negative_damage_and_armor_loss_are_clamped_to_zero(self):
        self.assertEqual(raw_post_mitigation_damage(100, 200), Fraction(-300))
        self.assertEqual(raw_armor_reduction(100, 200), Fraction(-2, 7))
        self.assertEqual(post_mitigation_damage(100, 200), Fraction(0))
        self.assertEqual(armor_reduction(100, 200), Fraction(0))


if __name__ == "__main__":
    unittest.main()
