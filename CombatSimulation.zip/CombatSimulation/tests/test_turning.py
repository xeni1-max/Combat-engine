"""Exact whole-body turn timing at explicit constant movement speeds."""
from fractions import Fraction as F
import unittest
from combat_sim.mechanics.turning import quarter_turn_time_ms, turn_rate_degrees_per_second, fixed_speed_turn_duration_ms, fixed_speed_turn_progress_degrees

class TurnTimingTests(unittest.TestCase):
    def test_stationary_quarter_turn(self):
        self.assertEqual(quarter_turn_time_ms(0),150)
        self.assertEqual(turn_rate_degrees_per_second(0),600)

    def test_walking_quarter_turn(self):
        self.assertEqual(quarter_turn_time_ms(2),230)

    def test_running_quarter_turn(self):
        self.assertEqual(quarter_turn_time_ms('6.4'),406)

    def test_sprinting_quarter_turn(self):
        self.assertEqual(quarter_turn_time_ms('11.2'),598)

    def test_speed_penalty_is_proportional_for_fractional_speeds(self):
        self.assertEqual(quarter_turn_time_ms('1.25'),200)
        self.assertEqual(quarter_turn_time_ms(5),350)

    def test_half_turn_takes_two_quarter_turns(self):
        self.assertEqual(fixed_speed_turn_duration_ms(180,'6.4'),812)

    def test_other_angles_scale_with_the_angular_rate(self):
        self.assertEqual(fixed_speed_turn_duration_ms(45,2),115)
        self.assertEqual(fixed_speed_turn_duration_ms(30,0),50)

    def test_turn_direction_does_not_change_duration(self):
        self.assertEqual(fixed_speed_turn_duration_ms(-90,2),fixed_speed_turn_duration_ms(90,2))

    def test_zero_angle_takes_no_time(self):
        self.assertEqual(fixed_speed_turn_duration_ms(0,'11.2'),0)

    def test_duration_and_angle_are_consistent(self):
        for speed in (0,2,F(32,5),F(56,5)):
            time=fixed_speed_turn_duration_ms(135,speed)
            self.assertEqual(fixed_speed_turn_progress_degrees(time,speed),135)
            self.assertEqual(fixed_speed_turn_progress_degrees(time/2,speed),F(135,2))

    def test_invalid_speed_and_time_are_rejected(self):
        with self.assertRaises(ValueError):quarter_turn_time_ms(-1)
        with self.assertRaises(ValueError):fixed_speed_turn_progress_degrees(-1,0)
