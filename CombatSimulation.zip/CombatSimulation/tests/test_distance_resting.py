"""Finite distance curves must not invent a lift between stationary contacts."""
from decimal import Context,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.distance_path import build_distance_path
from combat_sim.mechanics.distance_projection import MaximumDistance
from combat_sim.mechanics.unilateral_velocity import ContactLimit
from combat_sim.mechanics.velocity_projection import VelocityNode

L=F(3)-F('1e-30');G=F('-9.81');H=F(9,32)


def tangent(*,b_velocity=0,b_acceleration=G):
    return build_distance_path((VelocityNode('A',(0,0,F(32,3)),8140,150),VelocityNode('B',(0,0,b_velocity),8140,150)),
        {'A':(0,0,F('.875')),'B':(0,L,F('.875'))},0,H,(MaximumDistance('A','B',L),),
        (ContactLimit('A',(0,0,-1)),ContactLimit('B',(0,0,-1))),
        accelerations={'A':(0,0,0),'B':(0,0,b_acceleration)},precision=70)


class RestingDistanceCurveTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=80));context.__enter__();self.addCleanup(context.__exit__,None,None,None)

    def certified(self,path):
        for *_,coefficients in path.bernstein_certificate:self.assertTrue(all(x<=0 for x in coefficients))

    def test_stationary_floor_normal_has_no_artificial_midinterval_hop(self):
        path=tangent();self.certified(path);b=dict(path.pieces)['B']
        self.assertEqual(dict(path.initial_projection.exact_velocities)['B'][2],0)
        self.assertEqual(dict(path.endpoint_projection.exact_velocities)['B'][2],0)
        self.assertEqual(b.velocity_mps[2],0);self.assertEqual(b.acceleration_mps2[2],0)
        self.assertEqual(b.position(H/2)[2],F('.875'))
        self.assertGreater(dict(path.pieces)['A'].velocity_mps[2],10)

    def test_real_outgoing_normal_velocity_retains_liftoff(self):
        path=tangent(b_velocity=1);self.certified(path);b=dict(path.pieces)['B']
        self.assertGreater(b.velocity_mps[2],F('.9'));self.assertGreater(b.position(H)[2],F('.875'))

    def test_actual_upward_acceleration_can_open_a_stationary_contact(self):
        nodes=(VelocityNode('A',(0,0,0),8140,150),)
        path=build_distance_path(nodes,{'A':(0,0,F('.875'))},0,H,contacts=(ContactLimit('A',(0,0,-1)),),
            accelerations={'A':(0,0,2)},precision=70)
        a=dict(path.pieces)['A'];self.assertEqual(a.velocity_mps[2],0)
        self.assertEqual(a.acceleration_mps2[2],2);self.assertGreater(a.position(H)[2],F('.875'))

    def test_relative_body_support_normal_stays_closed_without_fake_separation(self):
        nodes=tuple(VelocityNode(n,(0,0,F(32,3) if n=='C' else 0),8140,150) for n in ('A','B','C'))
        refs={'A':(0,0,F('2.625')),'B':(0,0,F('.875')),'C':(0,L,F('2.625'))}
        path=build_distance_path(nodes,refs,0,H,(MaximumDistance('A','C',L),),
            (ContactLimit('A',(0,0,-1),'B'),ContactLimit('B',(0,0,-1))),
            accelerations={'A':(0,0,G),'B':(0,0,G),'C':(0,0,0)},precision=70)
        self.certified(path);pieces=dict(path.pieces)
        for n in ('A','B'):
            self.assertEqual(pieces[n].velocity_mps[2],0);self.assertEqual(pieces[n].acceleration_mps2[2],0)
        self.assertEqual(pieces['A'].position(H/2)[2]-pieces['B'].position(H/2)[2],F('1.75'))


if __name__=='__main__':unittest.main()
