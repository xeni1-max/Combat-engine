"""Remaining-work clock invariants, independent of scripts and world effects."""
from decimal import Decimal as D
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.cooldown import CooldownBook,CooldownClock


class CooldownTests(unittest.TestCase):
    def test_pause_preserves_only_remaining_work(self):
        c=CooldownClock();c.start(100,900)
        self.assertEqual(c.ready_at(200),1000)
        c.pause(300,'field:a',True)
        self.assertEqual(c.remaining(5000),700);self.assertIsNone(c.ready_at(5000))
        c.pause(5300,'field:a',False)
        self.assertEqual(c.ready_at(5300),6000)
        self.assertEqual(c.remaining(6000),0)

    def test_overlapping_sources_do_not_resume_early(self):
        c=CooldownClock();c.start(0,1000)
        c.pause(100,'a',True);c.pause(200,'b',True)
        c.pause(500,'a',False)
        self.assertEqual(c.remaining(700),900);self.assertIsNone(c.ready_at(700))
        c.pause(800,'b',False)
        self.assertEqual(c.ready_at(800),1700)

    def test_ready_clock_can_start_new_work_inside_a_field(self):
        c=CooldownClock();c.pause(0,'a',True)
        self.assertEqual(c.record(100)['state'],'ready')
        c.start(100,900)
        self.assertEqual(c.remaining(9000),900)
        c.pause(9000,'a',False)
        self.assertEqual(c.ready_at(9000),9900)

    def test_repeated_membership_operations_cannot_reset_or_advance_work(self):
        c=CooldownClock();c.start(0,1000)
        c.pause(200,'a',True);record=c.record(200)
        self.assertFalse(c.pause(300,'a',True));self.assertFalse(c.pause(400,'absent',False))
        self.assertEqual(c.record(500),record)
        c.pause(500,'a',False)
        self.assertEqual(c.ready_at(500),1300)

    def test_no_idle_work_is_banked(self):
        c=CooldownClock();c.start(5000,1000)
        self.assertEqual(c.remaining(5000),1000)
        with self.assertRaises(ValueError):c.start(5500,1000)
        self.assertEqual(c.remaining(5500),500)
        c.start(7000,1000);self.assertEqual(c.ready_at(7000),8000)

    def test_exact_ready_and_pause_tie_does_not_revoke_ready_ability(self):
        c=CooldownClock();c.start(0,1000);c.pause(1000,'a',True)
        self.assertEqual(c.remaining(1000),0);self.assertEqual(c.ready_at(1000),1000)
        c.start(1000,1000);self.assertIsNone(c.ready_at(1000))

    def test_stop_freezes_progress_and_rejects_implicit_restart(self):
        c=CooldownClock();c.start(0,1000);c.stop(100)
        self.assertEqual(c.remaining(100000),900);self.assertIsNone(c.ready_at(100000))
        self.assertFalse(c.pause(200,'field',True))
        with self.assertRaises(ValueError):c.start(100000,1000)
        self.assertEqual(c.record(200),c.record(100000))

    def test_queries_and_records_are_detached_from_observation_order(self):
        c=CooldownClock();c.start(0,1000);revision=c.revision
        self.assertEqual([c.remaining(t) for t in (300,100,500)],list(map(D,(700,900,500))))
        self.assertEqual(c.revision,revision)
        record=c.record(300);record['pause_sources'].append('fake')
        self.assertEqual(c.pauses,set())

    def test_fractional_times_keep_exact_work(self):
        c=CooldownClock();c.start(F(1,8),F(9,4));c.pause(F(3,8),'a',True)
        self.assertEqual(c.remaining(1),2)
        c.pause(F(9,8),'a',False)
        self.assertEqual(c.ready_at(2),D('3.125'))

    def test_invalid_mutation_does_not_damage_clock(self):
        c=CooldownClock();c.start(100,1000);record=c.record(100)
        for operation in (lambda:c.pause(50,'a',True),lambda:c.pause(100,'',True),
                          lambda:c.pause(100,'a','yes'),lambda:c.start(100,-1)):
            with self.assertRaises(ValueError):operation()
            self.assertEqual(c.record(100),record)

    def test_book_record_does_not_alias_later_clock_progress(self):
        now=[D(0)];book=CooldownBook(lambda:now[0],('1','2'))
        book.clocks['1'].start(0,1000);saved=book.record()
        now[0]=D(100);book.clocks['1'].pause(100,'a',True)
        self.assertEqual(saved['1']['remaining_work_ms'],1000)
        self.assertEqual(book.record()['1']['remaining_work_ms'],900)


if __name__=='__main__':unittest.main()
