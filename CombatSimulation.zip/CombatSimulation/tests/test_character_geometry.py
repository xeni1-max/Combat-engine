"""Authored relative dimensions and independent local/world geometry checks."""
from copy import deepcopy
from decimal import Context,localcontext
from fractions import Fraction as F
import json
from pathlib import Path
import unittest

from combat_sim.character_geometry import profile_scale,scaled_definition
from combat_sim.hitboxes import standing_cuboids,world_standing_cuboids,combined_bounds
from combat_sim.models import UnsupportedMechanicError
from combat_sim.postures import world_posture_cuboids
from combat_sim.prone import prone_morph

ROOT=Path(__file__).resolve().parents[1]
BODY=json.loads((ROOT/'data/body_hitboxes.json').read_text())
PROFILES=json.loads((ROOT/'data/characters.json').read_text())['characters']


class CharacterGeometryTests(unittest.TestCase):
    def test_source_profile_axes_and_identity_defaults(self):
        self.assertEqual(profile_scale(BODY,PROFILES['1E5']),(F(8,5),F(8,5),F(13,10)))
        self.assertEqual(profile_scale(BODY,PROFILES['3E5']),(F(23,20),F(23,20),F(21,20)))
        for name in ('1E1','1E2','1E3','2E4'):self.assertEqual(profile_scale(BODY,PROFILES[name]),(1,1,1))

    def test_1e5_cuboids_match_independent_authored_dimension_products(self):
        shape=scaled_definition(BODY,profile_scale(BODY,PROFILES['1E5']))
        boxes={b.part:b for b in standing_cuboids(shape)}
        expected={'head':('.4','.4','.325'),'torso':('.8','.48','.91'),
            'left_leg':('.32','.32','1.04'),'right_leg':('.32','.32','1.04'),
            'left_arm':('.16','.16','1.04'),'right_arm':('.16','.16','1.04')}
        for name,size in expected.items():self.assertEqual(boxes[name].size_m,tuple(map(F,size)))
        low,high=combined_bounds(boxes.values())
        self.assertEqual(tuple(b-a for a,b in zip(low,high)),tuple(map(F,('1.12','.48','2.275'))))
        self.assertEqual(low[2],F('-1.1375'));self.assertEqual(high[2],F('1.1375'))
        self.assertEqual(shape['standing_placement']['status'],'scaled_from_confirmed_reference')

    def test_3e5_dimensions_and_ground_offset(self):
        shape=scaled_definition(BODY,profile_scale(BODY,PROFILES['3E5']))
        boxes={b.part:b for b in standing_cuboids(shape)}
        self.assertEqual(boxes['head'].size_m,tuple(map(F,('.2875','.2875','.2625'))))
        self.assertEqual(boxes['torso'].size_m,tuple(map(F,('.575','.345','.735'))))
        low,high=combined_bounds(boxes.values())
        self.assertEqual(tuple(b-a for a,b in zip(low,high)),tuple(map(F,('.805','.345','1.8375'))))
        self.assertEqual(low[2],F('-.91875'))

    def test_both_facings_keep_exact_feet_and_swap_horizontal_axes(self):
        shape=scaled_definition(BODY,profile_scale(BODY,PROFILES['1E5']))
        for facing in ('+x','-x'):
            boxes=world_standing_cuboids(shape,(10,-20,F('6.1375')),facing)
            low,high=combined_bounds(boxes)
            self.assertEqual(low[2],5);self.assertEqual(high[2],F('7.275'))
            self.assertEqual((high[0]-low[0],high[1]-low[1]),(F('.48'),F('1.12')))

    def test_proportional_crouch_keeps_feet_and_only_shortens_legs(self):
        shape=scaled_definition(BODY,profile_scale(BODY,PROFILES['1E5']))
        for fraction,height,leg in ((0,'2.275','1.04'),(F(1,2),'2.015','.78'),(1,'1.755','.52')):
            boxes=world_posture_cuboids(shape,(0,0,F('1.1375')),'+x',fraction,F('.52'))
            low,high=combined_bounds(boxes);parts={b.part:b for b in boxes}
            self.assertEqual(low[2],0);self.assertEqual(high[2],F(height))
            self.assertEqual(parts['left_leg'].size_m[2],F(leg));self.assertEqual(parts['torso'].size_m[2],F('.91'))

    def test_scaled_prone_thickness_follows_authored_depth(self):
        for character,origin,target,height in (('1E5','1.1375','.52','.48'),('3E5','.91875','.42','.345')):
            shape=scaled_definition(BODY,profile_scale(BODY,PROFILES[character]))
            boxes=prone_morph(shape,0,F(target)).world_parts((0,0,F(origin)),'+x',1)
            low,high=combined_bounds(boxes)
            self.assertEqual(low[2],0);self.assertEqual(high[2],F(height))

    def test_reference_input_is_not_mutated_and_decimal_context_is_irrelevant(self):
        previous=deepcopy(BODY)
        with localcontext(Context(prec=9)):a=scaled_definition(BODY,profile_scale(BODY,PROFILES['1E5']))
        with localcontext(Context(prec=90)):b=scaled_definition(BODY,profile_scale(BODY,PROFILES['1E5']))
        self.assertEqual(a,b);self.assertEqual(BODY,previous)

    def test_explicit_legacy_body_definition_keeps_common_proxy(self):
        old=deepcopy(BODY);old.pop('character_geometry')
        self.assertEqual(profile_scale(old,PROFILES['1E5']),(1,1,1))
        self.assertEqual(scaled_definition(old,(1,1,1)),old)

    def test_invalid_scales_and_unknown_modes_reject(self):
        for value in ((0,1,1),(-1,1,1),(True,1,1),(1,1),(1,1,'NaN'),(1,1,'Infinity'),'1,1,1'):
            with self.subTest(value=value),self.assertRaises(ValueError):profile_scale(BODY,{'body_scale_xyz':value})
        wrong=deepcopy(BODY);wrong['character_geometry']={'mode':'unknown'}
        with self.assertRaises(UnsupportedMechanicError):profile_scale(wrong,{})
