"""Native material interactions; imposed placements/links are labelled probes."""
from copy import deepcopy
from decimal import Context,Decimal as D,Inexact,ROUND_UP,getcontext,localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.shared_engine import SharedEncounter
from combat_sim.spatial_transitions import SpatialChange
from tests.test_equilibrium_combat import scene as base_scene,run
from tests.test_binding_combat import run as configured_run
from tests.test_mobile_combat import events,read,command
from tests.test_world_colliders_combat import wall
from tests.test_grapple_links_combat import force,attach


def scene(duration=900):
    s=base_scene(duration);s['id']='oriented_material_combat'
    s['action_selection']['A']['start_ms']=100000
    return s


def angled(name='angled',*,x=2,z='1.5',size=('.2',4,3),hp=2000,angle=45,blocking=None,duration=None):
    item=wall(name,x=x,z=z,size=size,hp=hp,blocking=blocking,duration=duration)
    item['parts'][0]['yaw_degrees']=angle
    return item


def slide_scene(duration=900):
    s=scene(duration);s['initial_colliders']=[angled(hp=None)]
    s['spatial_interventions']=[force(0,'A',[3,0,0])];return s


def beam_scene(kind='clear'):
    s=scene(1200);s['encounter']['participants']['A']['character']='1E1'
    s['encounter']['participants']['B']['position_m']=[10,-20]
    s['action_selection']['A'].update(abilities=['4'],start_ms=0,reload_when_empty=False)
    if kind=='miss':
        obj=angled(x=2,size=(20,'.2',3));obj['parts'][0]['centre_m'][1]=-12
    else:
        obj=angled(x='8.8',z=3,size=(4,'.2','.2'),hp=None,
            blocking={'projectiles':False,'bodies':False,'areas':True})
        obj['parts'][0]['centre_m'][1]='-18.8' if kind=='clear' else -20
        if kind=='blocked':obj['parts'][0]['centre_m'][0]=10
        if kind=='blocked':obj['parts'][0]['size_m'][1]=2
    s['initial_colliders']=[obj];return s


class OrientedWorldCombatTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def conserved(self,r):
        damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for n,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=n)
            self.assertLess(abs(supplied-D(r['final_states'][n]['hp'])-damage.amount(target=n)),D('1e-8'))

    def test_native_oblique_impact_loses_only_the_surface_normal_component(self):
        r=run(slide_scene());self.conserved(r);contacts=events(r,'body_contact')
        self.assertEqual(len(contacts),1);e=contacts[0]
        x=D('1.6')-D('.1')*D(2).sqrt();expected=x/3*1000
        self.assertLess(abs(D(e['time_ms'])-expected),D('1e-30'))
        self.assertLess(abs(D(e['relative_speed_mps'])-3/D(2).sqrt()),D('1e-30'))
        self.assertEqual(tuple(map(D,r['final_states']['A']['locomotion']['velocity_mps'])),(D('1.5'),D('-1.5'),0))
        dt=(900-D(e['time_ms']))/1000;point=r['final_states']['A']['position_m']
        self.assertLess(abs(D(point[0])-x-D('1.5')*dt),D('1e-30'))
        self.assertLess(abs(D(point[1])+20+D('1.5')*dt),D('1e-30'))

    def test_ordinary_walking_contacts_the_same_diagonal_material(self):
        s=scene(1500);s['initial_colliders']=[angled()];command(s,'A',0,'walk')
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertGreater(D(r['final_states']['A']['position_m'][0]),1)

    def test_real_gravity_gunfire_hits_material_at_its_actual_surface(self):
        s=scene(500);s['initial_colliders']=[angled(x=5)];s['action_selection']['A']['start_ms']=0
        r=run(s);self.conserved(r);hits=[e for e in r['events'] if e['type']=='world_collider_damaged' and e['collider_id']=='angled']
        self.assertTrue(hits);self.assertLess(D(r['world_collider_states']['angled']['hp']),2000)
        impacts=[hit for e in events(r,'world_collider_impact_batch') if e.get('collider_id')=='angled' for hit in e['hits']]
        self.assertTrue(impacts)
        frame=YawFrame.from_degrees(135)
        for e in impacts:
            local=frame.to_local_point(e['location_m'],(5,-20,'1.5'))
            self.assertLess(abs(abs(local[0])-F('.1')),F(1,10**8))

    def test_actual_ultimate_damages_a_rotated_compound_material_once(self):
        from tests.test_impact_areas_combat import scene as ultimate_scene
        s=ultimate_scene();obj=angled(x=5)
        extra=deepcopy(obj['parts'][0]);extra['part']='other_panel';extra['centre_m'][2]='4.5'
        obj['parts'].append(extra);s['initial_colliders']=[obj]
        r=run(s);self.conserved(r)
        self.assertEqual(D(r['world_collider_states']['angled']['hp']),1109)
        self.assertEqual(len(r['impact_area_bursts']),1)
        self.assertEqual(r['impact_area_bursts'][0]['recipients'],['A','B'])
        self.assertEqual(len([e for e in events(r,'world_collider_damaged') if e['collider_id']=='angled']),1)

    def test_real_charge_hand_fractures_a_rotated_wall_before_body_contact(self):
        from tests.test_charge_grapple_combat import scene as charge_scene,panel
        s=charge_scene(1300);panel(s,'hand_wall',2)
        s['initial_colliders'][0]['parts'][0]['yaw_degrees']=45
        r=run(s);self.conserved(r)
        self.assertEqual(r['world_collider_states']['hand_wall']['status'],'destroyed')
        contacts=[e for e in events(r,'owned_contact_committed') if e['target']=='hand_wall']
        self.assertEqual(len(contacts),1)
        self.assertTrue(events(r,'charge_hand_wall_resolved'))
        self.assertFalse([e for e in events(r,'body_contact') if e['second']=='hand_wall'])

    def test_spawn_uses_actual_material_and_rejects_penetration_atomically(self):
        from tests.test_constructor_context import arguments
        profiles,inputs=arguments();w=SharedEncounter(scene(100),profiles,**inputs)
        obj=angled(x='1.2');obj['parts'][0]['centre_m'][1]='-18.8'
        w.collider_system.spawn_definition(obj)
        self.assertIn('angled',w.collider_system.registry.objects)
        before=(deepcopy(w.states()),deepcopy(w.collider_system.registry.record()),
            deepcopy(w.event_log.records()),w.collider_system.registry.epoch)
        with self.assertRaisesRegex(ValueError,'penetrate'):
            w.collider_system.spawn_definition(angled('invalid',x=0))
        after=(w.states(),w.collider_system.registry.record(),w.event_log.records(),w.collider_system.registry.epoch)
        self.assertEqual(after,before)

    def test_transport_preflight_allows_false_enclosing_corner_and_rejects_solid(self):
        from tests.test_constructor_context import arguments
        profiles,inputs=arguments();s=scene(100);s['initial_colliders']=[angled(x=10)]
        w=SharedEncounter(s,profiles,**inputs)
        before=(deepcopy(w.states()),deepcopy(w.spatial_transitions.records))
        with self.assertRaisesRegex(ValueError,'overlaps'):
            w.spatial_transitions.prepare_transport((SpatialChange('A',1,reference_m=(10,-20,'.875')),),source='probe:invalid')
        self.assertEqual((w.states(),w.spatial_transitions.records),before)
        plan=w.spatial_transitions.prepare_transport((SpatialChange('A',1,reference_m=('11.2','-18.8','.875')),),source='probe:valid')
        w.spatial_transitions.commit(plan)
        self.assertEqual(w.spatial_transitions.reference('A'),(D('11.2'),D('-18.8'),D('.875')))

    def test_material_yaw_loading_uses_declared_constructor_precision(self):
        from tests.test_constructor_context import arguments
        profiles,inputs=arguments();s=scene(500);s['initial_colliders']=[angled(x=5,angle='37.1234567890123456789')]
        s['action_selection']['A']['start_ms']=0
        with localcontext(Context(prec=80)):
            expected=SharedEncounter(s,profiles,precision=50,**inputs).run()
        for prec in (28,80):
            with self.subTest(caller_precision=prec),localcontext(Context(prec=prec,rounding=ROUND_UP)):
                getcontext().traps[Inexact]=True
                self.assertEqual(SharedEncounter(s,profiles,precision=50,**inputs).run(),expected)

    def test_actual_beam_does_not_damage_a_false_aabb_corner(self):
        r=run(beam_scene('miss'));self.conserved(r)
        self.assertTrue(events(r,'beam_deployed'));self.assertEqual(D(r['world_collider_states']['angled']['hp']),2000)
        self.assertLess(D(r['final_states']['B']['hp']),8140)

    def test_actual_beam_passes_false_aabb_cover_and_obeys_actual_cover(self):
        clear=run(beam_scene());blocked=run(beam_scene('blocked'))
        self.conserved(clear);self.conserved(blocked)
        self.assertLess(D(clear['final_states']['B']['hp']),8140)
        self.assertEqual(D(blocked['final_states']['B']['hp']),8140)

    def test_rigid_link_keeps_common_tangent_motion_and_individual_collision_status(self):
        s=scene(900);s['encounter']['participants']['B']['position_m']=[0,-22]
        obj=angled(size=('.2',8,3),angle=30,hp=None);obj['parts'][0]['centre_m'][1]=-21
        s['initial_colliders']=[obj]
        s['spatial_interventions']=[force(0,'A',[3,0,0]),force(0,'B',[3,0,0]),attach(duration=1000)]
        r=run(s);self.conserved(r);self.assertEqual(r['grapple_links'][0]['status'],'active')
        a,b=(tuple(map(D,r['final_states'][n]['locomotion']['velocity_mps'])) for n in ('A','B'))
        self.assertLess(max(abs(x-y) for x,y in zip(a,b)),D('1e-20'))
        self.assertLess(abs(a[0]*D(3).sqrt()/2+a[1]/2),D('1e-20'))
        self.assertEqual(r['metrics']['B']['collision_stops'],0)

    def test_partial_rotated_top_departure_uses_the_last_real_foot_witness(self):
        s=scene(1600);s['initial_colliders']=[angled(x=20,z='.9',size=(4,'1.8','1.8'))]
        s['spatial_interventions']=[force(0,'A',[2,0,0],reference=[20,-20,'2.675'])]
        r=run(s);self.conserved(r);loss=events(r,'world_support_lost','A')
        self.assertEqual(len(loss),1);expected=(D('.9')*D(2).sqrt()+D('.3'))/2*1000
        self.assertLess(abs(D(loss[0]['time_ms'])-expected),D('1e-15'))
        self.assertTrue(events(r,'jump_landed','A'));self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)
        self.assertEqual(r['metrics']['A']['jumps_started'],0)

    def test_rotated_support_expiry_uses_common_flight_without_jump_payment(self):
        s=scene(600);s['initial_colliders']=[angled(x=20,z='.9',size=(4,'1.8','1.8'),duration=100)]
        s['spatial_interventions']=[force(0,'A',[0,0,0],reference=[20,-20,'2.675'])]
        r=run(s);self.conserved(r);loss=events(r,'world_support_lost','A')
        self.assertEqual([D(e['time_ms']) for e in loss],[100])
        self.assertLess(abs(D(r['final_states']['A']['body_origin_m'][2])-(D('2.675')-D('9.81')/8)),D('1e-25'))
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_geometry_revision_releases_real_support_and_its_owned_anchor(self):
        s=scene(600);s['initial_colliders']=[angled(x=20,z='.9',size=(4,'.2','1.8'),angle=0)]
        s['spatial_interventions']=[force(0,'A',reference=['21.3',-20,'2.675'])]
        def anchor(w):
            candidate=w.terrain_anchors.below('A',5)
            self.assertEqual(candidate.collider_id,'angled')
            w.terrain_anchors.attach(candidate,source='fixture:oriented_support_anchor')
        def turn(w):
            shape=OrientedCuboid('panel',(20,-20,'.9'),(4,'.2','1.8'),YawFrame.from_degrees(135))
            w.collider_system.reshape('angled',parts=(shape,))
        r=run(s,operations=((10,anchor),(100,turn)));self.conserved(r)
        self.assertEqual([D(e['time_ms']) for e in events(r,'world_support_lost','A')],[100])
        self.assertEqual(r['terrain_anchors'][0]['end_reason'],'anchor_geometry_changed')
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])

    def test_actual_grappling_hook_anchors_and_arrives_on_the_oblique_face(self):
        from tests.test_grappling_gun import scene as hook_scene
        from combat_sim.box_motion import on_surface
        s=hook_scene(1800,surface=False);s['initial_colliders'][0]['parts'][0]['yaw_degrees']=45
        r=run(s);self.conserved(r);anchor=r['terrain_anchors'][0]
        self.assertEqual(anchor['collider_id'],'hookwall');self.assertEqual(anchor['end_reason'],'body_contact')
        shape=OrientedCuboid('panel',(8,-20,'1.5'),('.2',4,3),YawFrame.from_degrees(135))
        self.assertTrue(on_surface(shape,tuple(F(p) for p in anchor['exact_position_m'])))
        self.assertEqual(len(events(r,'body_launch_contact','A')),1)
        self.assertTrue(all(d['status']=='ended' for d in r['distance_constraints']))

    def test_actual_heat_destroys_a_rotated_hook_anchor_during_launch(self):
        from tests.test_grappling_gun import beam_scene as hook_beam_scene
        s=hook_beam_scene();s['initial_colliders'][0]['parts'][0]['yaw_degrees']=45
        s['action_selection']['A']['ability_targets']['3']={'kind':'world_point','point_m':['7.9',-20,'1.2']}
        r=run(s);self.conserved(r);hook=r['grappling_hooks'][0]
        self.assertEqual(hook['end_reason'],'hook_anchor_destroyed')
        self.assertEqual(r['world_collider_states']['hookwall']['status'],'destroyed')
        self.assertLess(D(hook['launched_at_ms']),D(hook['ended_at_ms']))
        self.assertLess(abs(D(hook['ended_at_ms'])-D(r['world_collider_states']['hookwall']['removed_at_ms'])),D('1e-20'))
        arrival=events(r,'body_launch_contact','A');self.assertEqual(len(arrival),1)
        self.assertGreater(D(arrival[0]['time_ms']),D(hook['ended_at_ms']))

    def test_records_retain_actual_local_shape_and_exact_frame(self):
        r=run(slide_scene(100));part=r['world_collider_states']['angled']['parts'][0]
        self.assertEqual(part['shape'],'oriented_cuboid');self.assertEqual(tuple(map(D,part['size_m'])),(D('.2'),4,3))
        c,s=(F(part['yaw_frame'][k]) for k in ('cosine','sine'));self.assertEqual(c*c+s*s,1)

    def test_existing_climb_reaches_rotated_cube_top_with_the_same_path_contract(self):
        from tests.test_climb_combat import climb
        s=scene(1000);s['encounter']['participants']['A']['position_m']=['4.3',0]
        obj=angled(x=6,z='.9',size=('1.8',)*3);obj['climbable']=True;obj['parts'][0]['centre_m'][1]=0
        s['initial_colliders']=[obj];climb(s,actor='A',time=0,target='angled')
        r=run(s);self.conserved(r)
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'angled')
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),D('1.8'))

    def test_historical_mode_guards_oriented_material_and_actor_admission(self):
        rules=read('data/movement/combat_locomotion.json');rules['terrain_support']={'mode':'static_faces_v1'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'finite-face'):configured_run(slide_scene(100),rules=rules)
        s=scene(100);s['encounter']['participants']['A']['facing']={'yaw_degrees':37}
        with self.assertRaisesRegex(UnsupportedMechanicError,'fixed actor facing'):configured_run(s,rules=rules)

