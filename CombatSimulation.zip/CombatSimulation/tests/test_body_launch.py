"""Exact nominal dash range and owned-precision launch construction."""
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.body_launch import dash_launch


class BodyLaunchTests(unittest.TestCase):
    def test_range_and_vertical_speed_reuse_the_confirmed_jump_rule(self):
        with localcontext(Context(prec=50)):
            launch=dash_launch('13.5',7,'9.81',(-1,0))
            self.assertEqual(launch.velocity_mps,(D('-18.919285714285714285714285714285714285714285714286'),0,D('3.5')))
            self.assertLess(abs(-launch.velocity_mps[0]*launch.same_height_duration_ms/1000-D('13.5')),D('1e-45'))
            self.assertEqual(launch.nominal_range_m,D('13.5'))

    def test_oblique_range_uses_normalized_horizontal_direction(self):
        with localcontext(Context(prec=50)):
            launch=dash_launch(14,F(32,5),F(981,100),(3,4))
            vx,vy,up=launch.velocity_mps
            self.assertEqual(up,D('3.2'));self.assertEqual(4*vx,3*vy)
            self.assertLess(abs((vx*vx+vy*vy).sqrt()*launch.same_height_duration_ms/1000-14),D('1e-45'))

    def test_caller_context_cannot_change_launch(self):
        with localcontext(Context(prec=9)):a=dash_launch('13.5',7,'9.81',(1,1))
        with localcontext(Context(prec=90)):self.assertEqual(a,dash_launch('13.5',7,'9.81',(1,1)))

    def test_invalid_launch_inputs_reject(self):
        for distance,speed,g,direction in ((0,7,10,(1,0)),(1,0,10,(1,0)),(1,7,0,(1,0)),
                (1,7,10,(0,0)),(1,7,10,(1,0,0)),(True,7,10,(1,0)),(1,7,'NaN',(1,0))):
            with self.subTest(values=(distance,speed,g,direction)):
                with self.assertRaises(ValueError):dash_launch(distance,speed,g,direction)


if __name__=='__main__':unittest.main()
