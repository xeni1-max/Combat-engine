"""Source effort formulas, independent of effect lifetime and dyspnea."""
from decimal import Decimal, localcontext
from dataclasses import FrozenInstanceError
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.effort import output_after_instability
from combat_sim.effort_rules import ReleasedPower


class EffortFormulaTests(unittest.TestCase):
    def test_intrinsic_momentary_loses_u_over_ten(self):
        self.assertEqual(output_after_instability(450, 50, 'intrinsic_momentary'), 445)
        self.assertEqual(output_after_instability(300, F(7, 3), 'intrinsic_momentary'), F(8993, 30))

    def test_intrinsic_sustained_loses_u_over_four_dps(self):
        self.assertEqual(output_after_instability(100, 80, 'intrinsic_sustained'), 80)

    def test_intrinsic_output_floors_at_zero(self):
        self.assertEqual(output_after_instability(450, 5000, 'intrinsic_momentary'), 0)
        self.assertEqual(output_after_instability(100, 400, 'intrinsic_sustained'), 0)

    def test_extrinsic_output_does_not_receive_intrinsic_damage_penalty(self):
        for category in ('extrinsic_momentary', 'extrinsic_sustained'):
            self.assertEqual(output_after_instability(437, 100000, category), 437)

    def test_formula_does_not_depend_on_decimal_observer_precision(self):
        values = []
        for precision in (9, 50, 80):
            with localcontext() as ctx:
                ctx.prec = precision
                values.append(output_after_instability(Decimal('450.123456789'),
                    Decimal('50.987654321'), 'intrinsic_momentary'))
        self.assertEqual(values, [values[0]]*3)

    def test_invalid_category_negative_and_boolean_inputs_rejected(self):
        for base, u, category in ((1, 1, 'projectile'), (-1, 0, 'intrinsic_momentary'),
                (1, -1, 'intrinsic_sustained'), (True, 0, 'extrinsic_momentary'),
                (1, False, 'extrinsic_sustained')):
            with self.subTest(base=base, u=u, category=category), self.assertRaises(ValueError):
                output_after_instability(base, u, category)

    def test_released_power_owns_its_values_and_detaches_inspection_records(self):
        parts = [['projectile', 450, 445], ['delayed_blast', 450, 445]]
        power = ReleasedPower('A', '1', 1, 'projectile:1', 'firing', 'intrinsic_momentary', 398, 50, parts)
        parts[0][2] = 0
        record = power.record()
        record['components']['projectile']['output'] = 0
        self.assertEqual(power.amount('projectile'), 445)
        self.assertEqual(power.amount('delayed_blast'), 445)
        with self.assertRaises(FrozenInstanceError):
            power.instability = 5000
        with self.assertRaises(ValueError):
            power.amount('invented_component')

    def test_invalid_or_duplicate_released_components_are_rejected(self):
        for parts in ([], [('p', 1, 2)], [('p', 1, 1), ('p', 1, 1)], [('p', True, 0)], [('p', 1)]):
            with self.subTest(parts=parts), self.assertRaises(ValueError):
                ReleasedPower('A', '1', 1, 'projectile:1', 'firing', 'intrinsic_momentary', 398, 50, parts)
