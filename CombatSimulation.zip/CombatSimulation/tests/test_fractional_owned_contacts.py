"""Isolated owned-volume geometry: a part's lower face has its own derivatives."""
from decimal import Context,Decimal as D,localcontext
from types import SimpleNamespace as NS
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.battle_models import decimal_value as dec
from combat_sim.owned_contacts import OwnedContacts
from combat_sim.terrain import RectangularGround


def world(*,centre_velocity=-1,size_velocity=-2,centre_acceleration=0,size_acceleration=0,ceiling=False):
    action=NS(id=1,phase='active',life_generation=1,ability_id='3')
    actor=NS(id='A',hp=1,life_generation=1,facing='+x',body_origin_m=(0,0,1),action_by_id=lambda i:action if i==1 else None)
    ground=RectangularGround('floor',(-2,-2,D('-.1')),(2,2,D('-.1')))
    target=Cuboid('ceiling',(0,0,'.55'),(2,2,'.1')) if ceiling else ground
    w=NS(time=D(0),fighters={'A':actor},world_bodies={'A':(Cuboid('right_leg',(0,0,1),('.2','.2',2)),)},
        log=lambda *a,**kw:None,body_terrain_colliders=lambda:{'solid':(target,)},
        mobile_motion=lambda n:((D(0),)*3,(D(0),)*3),
        pose_part_motion=lambda *a:((D(0),D(0),D(centre_velocity)),(D(0),D(0),D(size_velocity))),
        pose_part_acceleration=lambda *a:((D(0),D(0),D(centre_acceleration)),(D(0),D(0),D(size_acceleration))))
    # The shared pose adapter calls this hook on full worlds too.
    w.equilibrium=NS(carries=lambda n:False)
    w.blocking=NS(boxes=lambda n:())
    return w,actor,action


GEOMETRY={'mode':'body_part_box','anchor_part':'right_leg','anchor_fraction':[0,0,'-.5'],
    'centre_offset_m':[0,0,'.05'],'size_xyz_m':['.2','.2','.1']}


class FractionalOwnedContactsTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=70));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_lower_face_box_rests_inside_part_and_does_not_follow_its_centre(self):
        w,a,action=world();system=OwnedContacts(w);row=system.start(a,action,GEOMETRY,None,ordering='down',apply_self_effects=False)
        self.assertEqual(tuple(map(dec,system.box(row).bounds[0])),(D('-.1'),D('-.1'),0))
        self.assertEqual(dec(system.box(row).bounds[1][2]),D('.1'))

    def test_shrinking_part_with_fixed_bottom_does_not_fake_a_floor_collision(self):
        w,a,action=world();system=OwnedContacts(w);system.start(a,action,GEOMETRY,4000)
        self.assertIsNone(system.next_contacts(D(500)))

    def test_accelerating_pose_with_fixed_bottom_does_not_fake_a_floor_collision(self):
        w,a,action=world(centre_velocity=0,size_velocity=0,centre_acceleration=-1,size_acceleration=-2)
        system=OwnedContacts(w);system.start(a,action,GEOMETRY,4000)
        self.assertIsNone(system.next_contacts(D(500)))

    def test_bottom_derivative_includes_both_centre_and_size_rates(self):
        w,a,action=world(centre_velocity=1,size_velocity=-2,ceiling=True)
        system=OwnedContacts(w);system.start(a,action,GEOMETRY,4000)
        self.assertAlmostEqual(system.next_contacts(D(1000))[0],D(200),places=20)

    def test_legacy_centre_anchor_retains_its_distinct_contact_time(self):
        w,a,action=world(size_velocity=0);system=OwnedContacts(w);g=dict(GEOMETRY);g.pop('anchor_fraction');system.start(a,action,g,4000)
        self.assertAlmostEqual(system.next_contacts(D(2000))[0],D(1100),places=20)

    def test_unbounded_clock_still_requires_the_original_control_and_life(self):
        w,a,action=world();system=OwnedContacts(w);row=system.start(a,action,GEOMETRY,None)
        w.time=D(100000);self.assertTrue(system.active(row))
        a.life_generation=2;self.assertFalse(system.active(row));system.settle();self.assertEqual(row['status'],'ended')

    def test_invalid_fraction_or_order_rejects_before_creating_a_volume(self):
        w,a,action=world();system=OwnedContacts(w)
        for f in ([0,0,'-.500001'],[0,0,'NaN'],[0,0]):
            with self.assertRaises(ValueError):system.start(a,action,dict(GEOMETRY,anchor_fraction=f),None)
        with self.assertRaises(ValueError):system.start(a,action,GEOMETRY,None,ordering='sideways')
        self.assertEqual(system.rows,{})
