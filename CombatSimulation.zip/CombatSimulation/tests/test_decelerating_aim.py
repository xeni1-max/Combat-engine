"""Gravity-compensated decelerating aim, independently evaluated in flight."""
from math import atan2, hypot, sqrt
import unittest

from combat_sim.mechanics.aiming import fastest_ballistic_launch
from combat_sim.mechanics.decelerating_aim import short_arc_decelerating_launch
from combat_sim.mechanics.gravity import ProjectileTrajectory
from combat_sim.models import UnsupportedMechanicError


class DeceleratingAimTests(unittest.TestCase):
    def reaches(self, origin, target, speed=900, deceleration=300, gravity=9.81, **controls):
        launch = short_arc_decelerating_launch(origin, target, speed,
            deceleration_mps2=deceleration, gravity_mps2=gravity, **controls)
        state = ProjectileTrajectory(origin, launch.velocity_mps, launch.flight_time_s,
            deceleration_mps2=deceleration, gravity_mps2=gravity,
            max_step_s=.001, relative_tolerance=1e-13, absolute_tolerance=1e-14).at(launch.flight_time_s)
        self.assertLess(hypot(*(a-b for a, b in zip(state.position_m, target))), 1e-7)
        self.assertAlmostEqual(hypot(*launch.velocity_mps), speed, places=9)
        self.assertLessEqual(launch.position_error_m, 1e-7)
        self.assertLessEqual(launch.refinement_error_m, 2.5e-8)
        if deceleration:
            self.assertLess(launch.flight_time_s, speed/(deceleration+gravity))
        return launch

    def test_real_gun_ranges_use_shallow_compensated_arcs(self):
        for distance in (30, 100, 500):
            with self.subTest(distance=distance):
                launch = self.reaches((0, 0, 1), (distance, 0, 1))
                self.assertGreater(launch.velocity_mps[2], 0)
                self.assertLess(atan2(launch.velocity_mps[2], launch.velocity_mps[0]), .02)
                self.assertGreater(launch.flight_time_s, distance/900)
                self.assertEqual(launch.branch, 'continuation_from_fastest_ballistic')

    def test_hand_to_torso_offset_and_non_axis_aligned_aim(self):
        self.reaches((.3, 0, 1.025), (30, 4, 1.15))
        self.reaches((7, -3, 2), (-100, -40, 4))

    def test_uphill_and_downhill_targets(self):
        self.reaches((0, 0, 2), (100, 30, 52))
        self.reaches((0, 0, 52), (100, -30, 2))

    def test_vertical_first_passes(self):
        above = self.reaches((0, 0, 1), (0, 0, 101))
        below = self.reaches((0, 0, 101), (0, 0, 1))
        self.assertGreater(above.velocity_mps[2], 0)
        self.assertLess(below.velocity_mps[2], 0)
        self.assertEqual(above.branch, 'vertical_first_pass')
        self.assertEqual(below.branch, 'vertical_first_pass')

    def test_zero_deceleration_exactly_reuses_fastest_ballistic_solution(self):
        origin, target = (1, 2, 3), (301, -10, 20)
        launch = self.reaches(origin, target, deceleration=0)
        expected = fastest_ballistic_launch(origin, target, 900)
        self.assertEqual(launch.velocity_mps, expected.velocity_mps)
        self.assertEqual(launch.flight_time_s, expected.flight_time_s)
        self.assertEqual(launch.branch, 'fastest_ballistic')
        self.assertIsNone(launch.conservative_horizon_s)

    def test_zero_gravity_matches_closed_form_straight_deceleration(self):
        launch = self.reaches((0, 0, 0), (300, 400, 0), gravity=0)
        expected = 1000/(900+sqrt(900**2-2*300*500))
        self.assertEqual(launch.flight_time_s, expected)
        self.assertEqual(launch.velocity_mps, (540, 720, 0))
        self.assertEqual(launch.branch, 'direct_first_pass')

    def test_deterministic_repeated_solution(self):
        args = ((0, 0, 1), (100, 4, 1.15), 900)
        self.assertEqual(short_arc_decelerating_launch(*args, deceleration_mps2=300),
                         short_arc_decelerating_launch(*args, deceleration_mps2=300))

    def test_tighter_controls_preserve_the_selected_short_arc(self):
        ordinary = self.reaches((0, 0, 1), (500, 40, 30))
        refined = self.reaches((0, 0, 1), (500, 40, 30),
            max_step_s=.002, relative_tolerance=1e-13, absolute_tolerance=1e-14,
            position_tolerance_m=1e-8)
        self.assertAlmostEqual(ordinary.flight_time_s, refined.flight_time_s, places=9)
        for a, b in zip(ordinary.velocity_mps, refined.velocity_mps):
            self.assertAlmostEqual(a, b, places=8)

    def test_tiny_horizontal_distance_does_not_require_a_high_arc(self):
        launch = self.reaches((0, 0, 1), (.000001, 0, 1))
        self.assertAlmostEqual(launch.flight_time_s, 1e-6/900, places=16)

    def test_outside_supported_horizon_is_explicitly_rejected(self):
        with self.assertRaisesRegex(UnsupportedMechanicError, 'supported.*horizon'):
            short_arc_decelerating_launch((0, 0, 0), (2000, 0, 0), 900,
                                          deceleration_mps2=300)

    def test_vertical_target_above_stopping_height_is_rejected(self):
        with self.assertRaises(UnsupportedMechanicError):
            short_arc_decelerating_launch((0, 0, 0), (0, 0, 1500), 900,
                                          deceleration_mps2=300)

    def test_malformed_inputs_are_rejected(self):
        for kwargs in ({'speed_mps': 0}, {'speed_mps': -1}, {'speed_mps': float('nan')},
                       {'deceleration_mps2': -1}, {'deceleration_mps2': float('inf')},
                       {'gravity_mps2': -1}, {'gravity_mps2': True},
                       {'position_tolerance_m': 0}, {'max_step_s': 0},
                       {'relative_tolerance': 0}, {'absolute_tolerance': 0},
                       {'max_iterations': 0}, {'max_iterations': True}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                options = {'speed_mps': 900, 'deceleration_mps2': 300, **kwargs}
                short_arc_decelerating_launch((0, 0, 0), (30, 0, 0), **options)
        with self.assertRaises(ValueError):
            short_arc_decelerating_launch((0, 0), (30, 0, 0), 900, deceleration_mps2=300)
        with self.assertRaises(ValueError):
            short_arc_decelerating_launch((0, 0, 0), (float('nan'), 0, 0), 900,
                                          deceleration_mps2=300)
        with self.assertRaises(UnsupportedMechanicError):
            short_arc_decelerating_launch((0, 0, 0), (0, 0, 0), 900,
                                          deceleration_mps2=300)
