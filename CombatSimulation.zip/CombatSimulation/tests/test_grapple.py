"""Primary-source grapple algebra and its shared status/dyspnea foundations.

These checks do not claim a grapple cast, Break response controller or coupled
body movement. Actual shared-combat regressions check the extracted weight term.
"""
from dataclasses import FrozenInstanceError
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.dyspnea import DyspneaContext, dyspnea_loss_rate
from combat_sim.mechanics.grapple import (BREAK_FILL_PER_SECOND, GrappleState, assess_break,
    break_effort_gain, break_status_base, shared_velocity)
from combat_sim.mechanics.status import body_status_weight


MOTION = {'first_max_hp': 20000, 'first_armor': 350, 'second_max_hp': 8140, 'second_armor': 150}


class GrappleSourceRulesTests(unittest.TestCase):
    def test_adjusted_statuses_lower_controller_capacity(self):
        state = GrappleState(69, 100, 200)
        self.assertEqual(state.exhaustion_limit, 70)
        self.assertFalse(state.exhausted)
        self.assertTrue(GrappleState(70, 100, 200).exhausted)

    def test_unimpaired_full_bar_is_exhausted(self):
        self.assertEqual(GrappleState(99).exhaustion_limit, 100)
        self.assertFalse(GrappleState(99).exhausted)
        self.assertTrue(GrappleState(100).exhausted)

    def test_large_status_total_means_zero_holding_capacity(self):
        self.assertEqual(GrappleState(0, 600, 500).exhaustion_limit, 0)
        self.assertTrue(GrappleState(0, 600, 500).exhausted)

    def test_equal_empty_capacity_meets_unimpaired_escape_comparison(self):
        r = assess_break(GrappleState(40), GrappleState(40))
        self.assertEqual((r.empty_capacity_advantage, r.required_advantage, r.margin), (0, 0, 0))
        self.assertTrue(r.escape_condition_met)

    def test_more_defender_empty_capacity_makes_break_possible(self):
        self.assertTrue(assess_break(GrappleState(60), GrappleState(40)).escape_condition_met)
        self.assertFalse(assess_break(GrappleState(40), GrappleState(60)).escape_condition_met)

    def test_defender_impairment_raises_required_advantage(self):
        r = assess_break(GrappleState(40), GrappleState(40, 100, 100))
        self.assertEqual(r.required_advantage, 20)
        self.assertEqual(r.margin, -20)
        self.assertFalse(r.escape_condition_met)

    def test_attacker_impairment_can_make_a_negative_capacity_advantage_sufficient(self):
        r = assess_break(GrappleState(30, 200, 0), GrappleState(40))
        self.assertEqual((r.empty_capacity_advantage, r.required_advantage, r.margin), (-10, -20, 10))
        self.assertTrue(r.escape_condition_met)

    def test_common_impairment_preserves_escape_difference_but_changes_exhaustion(self):
        a = assess_break(GrappleState(50, 20, 10), GrappleState(40, 60, 30))
        b = assess_break(GrappleState(50, 120, 110), GrappleState(40, 160, 130))
        self.assertEqual((a.margin, a.escape_condition_met), (b.margin, b.escape_condition_met))
        self.assertEqual(a.attacker_exhaustion_limit-b.attacker_exhaustion_limit, 20)

    def test_exact_decimal_statuses_are_not_mitigated_or_rounded_again(self):
        r = assess_break(GrappleState('50.25', '8.5', '1.5'), GrappleState(49))
        self.assertEqual(r.attacker_exhaustion_limit, 99)
        self.assertEqual((r.empty_capacity_advantage, r.required_advantage, r.margin), (F(5, 4), -1, F(9, 4)))

    def test_exhaustion_and_escape_comparison_are_separate_lifecycle_facts(self):
        r = assess_break(GrappleState(70, 100, 200), GrappleState(0))
        self.assertTrue(r.attacker_exhausted)
        self.assertTrue(r.escape_condition_met)
        # No action/event/status side effect is inferred from this calculation.
        self.assertEqual(r.attacker_exhaustion_limit, 70)

    def test_specific_break_filling_is_distinct_from_ordinary_recovery(self):
        self.assertEqual(BREAK_FILL_PER_SECOND, 20)
        self.assertEqual(break_effort_gain(2500), 50)
        self.assertEqual(dyspnea_loss_rate(DyspneaContext('stationary')), 30)
        self.assertEqual(dyspnea_loss_rate(DyspneaContext('running')), 18)
        self.assertEqual(dyspnea_loss_rate(DyspneaContext('stationary', on_grapple_ability=True)), 0)

    def test_break_filling_is_uncapped_and_does_not_invent_status_pauses(self):
        self.assertEqual(break_effort_gain(6000), 120)
        self.assertEqual(break_effort_gain(F(1000, 3)), F(20, 3))
        self.assertEqual(break_effort_gain(1000, rate_per_second=0), 0)
        # The caller owns actual bar caps, Binding's explicit O pause and the
        # grapple response state. None are silently guessed by this formula.

    def test_break_penalties_depend_on_declared_actual_effort(self):
        self.assertEqual(break_status_base(0), 0)
        self.assertEqual(break_status_base('7.5'), F(45, 2))
        self.assertEqual(break_status_base(40), 120)
        self.assertEqual(break_status_base(200), 600)

    def test_state_and_assessment_inspection_are_detached(self):
        a = GrappleState(40)
        r = assess_break(a, GrappleState(40))
        record = r.record()
        record['margin'] = '-1000'
        self.assertEqual(r.margin, 0)
        with self.assertRaises(FrozenInstanceError):
            a.dyspnea = 100

    def test_invalid_status_capacity_effort_and_time_are_rejected(self):
        for args in ((-1,), (101,), (1, -1), (1, 0, -1), (True,), ('NaN',), ('Infinity',)):
            with self.subTest(args=args), self.assertRaises(ValueError):
                GrappleState(*args)
        for function, value in ((break_effort_gain, -1), (break_effort_gain, True),
                                (break_status_base, -1), (break_status_base, 'NaN')):
            with self.subTest(function=function.__name__, value=value), self.assertRaises(ValueError):
                function(value)
        with self.assertRaises(ValueError):
            assess_break({'dyspnea': 40}, GrappleState(40))

    def test_comparisons_ignore_ambient_decimal_precision(self):
        results = []
        for precision in (7, 28, 80):
            with localcontext(Context(prec=precision)):
                results.append(assess_break(GrappleState(D('50.123456789'), D('8.987654321'), D('1.123456789')),
                    GrappleState(F(147, 3), F(4, 3), F(5, 3))))
        self.assertEqual(results, [results[0]]*3)


class GrappleMotionFormulaTests(unittest.TestCase):
    def setUp(self):
        ctx = localcontext(Context(prec=60))
        ctx.__enter__()
        self.addCleanup(ctx.__exit__, None, None, None)

    def test_equal_bodies_average_opposing_velocities(self):
        params = dict(MOTION, first_max_hp=8140, first_armor=150)
        self.assertEqual(shared_velocity(('6.4', 2, -1), ('-6.4', 0, 3), **params), (D(0), D(1), D(1)))

    def test_shared_weight_has_an_exact_integer_power_case(self):
        # 1024^(11/10)=2048; the 2048:1 weighted velocities cancel exactly.
        result = shared_velocity((1, 2, 3), (-2048, -4096, -6144),
            first_max_hp=512000, first_armor=0, second_max_hp=500, second_armor=0)
        self.assertEqual(result, (D(0),)*3)

    def test_actual_roster_pair_matches_independent_90_digit_reference(self):
        result = shared_velocity((7, 0, 0), ('-6.4', 0, 0), **MOTION)
        reference = D('3.29508869406831549350073579218142687373054261431960678265060636413257272182841386231127957')
        self.assertAlmostEqual(result[0], reference, places=37)
        self.assertEqual(result[1:], (D(0), D(0)))

    def test_swapping_participants_preserves_motion(self):
        swapped = {'first_max_hp': 8140, 'first_armor': 150, 'second_max_hp': 20000, 'second_armor': 350}
        self.assertEqual(shared_velocity((7, 2, -1), (-6, 3, 4), **MOTION),
                         shared_velocity((-6, 3, 4), (7, 2, -1), **swapped))

    def test_equal_input_motion_is_preserved(self):
        self.assertEqual(shared_velocity((7, -2, 3), (7, -2, 3), **MOTION), (D(7), D(-2), D(3)))

    def test_motion_is_convex_and_armor_loss_changes_the_current_weight(self):
        result = shared_velocity((7, -2, 3), ('-6.4', 8, -4), **MOTION)
        for value, low, high in zip(result, (D('-6.4'), D(-2), D(-4)), (D(7), D(8), D(3))):
            self.assertLessEqual(low, value)
            self.assertLessEqual(value, high)
        stripped = shared_velocity((7, -2, 3), ('-6.4', 8, -4), **dict(MOTION, first_armor=0))
        self.assertLess(stripped[0], result[0])
        self.assertGreater(stripped[1], result[1])

    def test_coordinate_changes_and_common_motion_offset_commute(self):
        a, b = (7, 2, -1), (-6, 3, 4)
        out = shared_velocity(a, b, **MOTION)
        rotated = shared_velocity((-a[1], a[0], a[2]), (-b[1], b[0], b[2]), **MOTION)
        self.assertEqual(rotated, (-out[1], out[0], out[2]))
        offset = (10, -2, 5)
        shifted = shared_velocity(tuple(x+y for x, y in zip(a, offset)), tuple(x+y for x, y in zip(b, offset)), **MOTION)
        for value, previous, delta in zip(shifted, out, offset):
            self.assertAlmostEqual(value-previous, delta, places=37)

    def test_motion_and_body_weight_ignore_ambient_decimal_precision(self):
        values, weights = [], []
        for precision in (7, 28, 80):
            with localcontext(Context(prec=precision)):
                values.append(shared_velocity((7, 2, -1), ('-6.4', 3, 4), **MOTION))
                weights.append(body_status_weight(20000, 350))
        self.assertEqual(values, [values[0]]*3)
        self.assertEqual(weights, [weights[0]]*3)

    def test_invalid_motion_shape_stats_and_precision_rejected(self):
        for vector in ((1, 2), '123', (1, 2, True), (1, 2, 'NaN'), None):
            with self.subTest(vector=vector), self.assertRaises(ValueError):
                shared_velocity(vector, (0, 0, 0), **MOTION)
        for bad in ({'first_max_hp': 0}, {'first_armor': -1}, {'second_max_hp': True}, {'precision': 20}):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                shared_velocity((0, 0, 0), (0, 0, 0), **dict(MOTION, **bad))
