"""Contact evidence survives event rounding across a scheduler boundary."""
from decimal import Decimal as D, localcontext
import json
from pathlib import Path
from types import SimpleNamespace
import unittest

from combat_sim.gravity_projectile_rules import GravityProjectileRules
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.persistent_gravity import PersistentProjectileTrajectory
from combat_sim.shared_engine import SharedEncounter
from combat_sim.projectile_world import SharedProjectiles
from combat_sim.projectile_entities import ProjectileContactPolicy
from combat_sim.collider_world import SharedColliders
from combat_sim.blocking import Blocking
from tests.test_gravity_mobile_combat import PHYSICS, scenario
from tests.test_mobile_combat import BODY, EFFECTS, MOVEMENT, PROFILES, TERRAIN


class ContactHarness(GravityProjectileRules):
    def __init__(self,owner_policy=None,collider_hp=None):
        self.gravity_mode = True
        self.mobile_mode = self.terrain_mode = True
        definition = json.loads((Path(__file__).resolve().parents[1]/
                                 'data/physics/projectile_gravity.json').read_text())
        self.setup_projectile_physics(definition)
        self.time = D(0)
        self.world_bodies = {}
        self.fighters = {}
        self.blocking=Blocking(self)
        self.scenario={'scope':{}}
        # A deliberately thin obstacle exposes contacts that both enter and
        # exit between adjacent 1 ns event ticks. Zero gravity isolates timing.
        self.terrain_colliders = {'foil': [Cuboid('foil', ['1.0000003', 0, 1], ['1e-7', 2, 2])]}
        self.collider_system=SharedColliders(self)
        self.collider_system.registry.add(self.terrain_colliders['foil'],time=0,source='timing_probe',entity_id='foil',hp=collider_hp)
        self.projectile_system=SharedProjectiles(self)
        self.projectiles=self.projectile_system.registry
        shot=self.projectiles.create(action_id=19,owner='A',ability='1',created_at_ms=0,
            kinematics={'status':'in_flight','aim_target':'B','released_at_ms':D(0),
                'trajectory_started_at_ms':D(0),'distance_offset_m':D(0),'radius_m':D(0)},policy=owner_policy)
        self.shot_id=shot['id']
        self.projectile_flights=self.projectiles.flights
        self.gravity_trajectories[self.shot_id] = PersistentProjectileTrajectory(
            [0, 0, 1], [1000, 0, 0], .002, gravity_mps2=0)


class GravityEventBoundaryTests(unittest.TestCase):
    def test_contact_that_has_already_exited_survives_rounding(self):
        engine = ContactHarness()
        boundary = D('1.0000005')
        self.assertIsNone(engine.next_mobile_projectile_contacts(boundary))
        self.assertIn(engine.shot_id, engine.gravity_deferred_contacts)
        engine.time = boundary  # Shared advance successfully reached the boundary.
        # Geometrically the point has already passed through the thin collider.
        point = engine.mobile_flight_state(engine.projectile_flights[engine.shot_id], boundary)[0]
        self.assertGreater(point[0], D('1.00000035'))
        time, payloads = engine.next_mobile_projectile_contacts(D(2))
        self.assertEqual(time, D('1.000001'))
        self.assertEqual(payloads[0]['target'], 'foil')
        self.assertLess(payloads[0]['trajectory_contact_bracket_s'][1], float(boundary/1000))

    def test_prior_interruption_invalidates_unreached_prediction(self):
        engine = ContactHarness()
        engine.next_mobile_projectile_contacts(D('1.0000005'))
        engine.time = D('.5')  # A different earlier event interrupts advance.
        engine.collider_system.registry.remove('foil',time=engine.time,reason='earlier_event')
        engine.collider_system.sync()
        self.assertIsNone(engine.next_mobile_projectile_contacts(D(2)))
        self.assertEqual(engine.gravity_deferred_contacts, {})

    def test_binary64_endpoint_rounding_does_not_discard_reached_contact(self):
        with localcontext() as context:
            context.prec = 50
            engine = ContactHarness()
            boundary = D(17)/3
            # The contact solver's binary64 interval endpoint rounds slightly
            # above the exact Decimal scheduling boundary. Place a real face
            # at that numerical endpoint so the returned upper witness is it.
            front = D(str(float(boundary/1000)*1000))
            engine.terrain_colliders = {'foil': [Cuboid('foil',
                [front+D('5e-8'), 0, 1], ['1e-7', 2, 2])]}
            engine.collider_system.registry.reshape('foil',parts=engine.terrain_colliders['foil'],time=engine.time)
            engine.gravity_trajectories[engine.shot_id] = PersistentProjectileTrajectory(
                [0, 0, 1], [1000, 0, 0], .01, gravity_mps2=0)
            self.assertIsNone(engine.next_mobile_projectile_contacts(boundary))
            confirmed_at, _, original = engine.gravity_deferred_contacts[engine.shot_id]
            raw_upper_ms = D(str(original['trajectory_contact_bracket_s'][1]))*1000
            self.assertGreater(raw_upper_ms, boundary)
            self.assertEqual(confirmed_at, boundary)
            engine.time = boundary
            time, payloads = engine.next_mobile_projectile_contacts(D(10))
            self.assertEqual(time, D('5.666667'))
            # Preserve the original evidence instead of discarding it and
            # searching again from the rounded starting position.
            self.assertEqual(payloads[0]['trajectory_contact_bracket_s'],
                             original['trajectory_contact_bracket_s'])

    def test_real_release_schedules_inert_stop_after_same_tick_impact(self):
        with localcontext() as context:
            context.prec = 50
            engine = SharedEncounter(scenario(4000, fire_at=0), PROFILES,
                body_definition=BODY, terrain_definition=TERRAIN,
                movement_definition=MOVEMENT, combat_locomotion_definition=EFFECTS,
                projectile_physics_definition=PHYSICS)
            engine.decide_team('A')
            actor = engine.fighters['A']
            action = actor.current
            ability = actor.profile['abilities'][action.ability_id]
            timing = actor.profile['timing_profiles'][ability['timing_profile']]
            # Exercise the production release and shared queue. The test is
            # about event ordering, independent of whether this aimed shot
            # would meet a body earlier in a complete battle.
            engine.release_body_projectile(actor, action, ability, timing)
            stop = next(event for event in engine.queue if event[3] == 'projectile_stopped')
            engine.push(stop[0], 'impact', engine.projectiles.link(next(iter(engine.projectile_flights.values()))))
            same_tick = sorted(event for event in engine.queue if event[0] == stop[0])
            self.assertEqual([event[3] for event in same_tick], ['impact', 'projectile_stopped'])

    def test_terminal_entity_discards_its_previously_confirmed_contact(self):
        engine=ContactHarness()
        boundary=D('1.0000005')
        engine.next_mobile_projectile_contacts(boundary)
        self.assertIn(engine.shot_id,engine.gravity_deferred_contacts)
        engine.time=boundary
        engine.projectiles.terminal(engine.projectile_flights[engine.shot_id],'removed')
        self.assertIsNone(engine.next_mobile_projectile_contacts(D(2)))
        self.assertEqual(engine.gravity_deferred_contacts,{})

    def test_owner_clearance_endpoint_rounding_retains_reached_confirmation(self):
        with localcontext() as context:
            context.prec=50
            engine=ContactHarness(ProjectileContactPolicy(owner='consume_after_separation'))
            boundary=D(17)/3
            front=D(str(float(boundary/1000)*1000))-D('1e-13')
            engine.terrain_colliders={}
            engine.collider_system.registry.remove('foil',time=engine.time,reason='owner_only_probe')
            engine.world_bodies={'A':[Cuboid('torso',[(front-10)/2,0,1],[front+10,2,2])]}
            engine.fighters={'A':SimpleNamespace(hp=1)}
            engine.mobile_motion=lambda name:((D(0),)*3,(D(0),)*3)
            engine.pose_part_motion=lambda name,part,time:((D(0),)*3,(D(0),)*3)
            engine.gravity_trajectories[engine.shot_id]=PersistentProjectileTrajectory(
                [0,0,1],[1000,0,0],.01,gravity_mps2=0)
            self.assertIsNone(engine.next_mobile_projectile_contacts(boundary))
            confirmed,rounded,original=engine.projectile_system.deferred_clearances[engine.shot_id]
            self.assertEqual(confirmed,boundary)
            self.assertGreater(D(str(original['separation_bracket_s'][1]))*1000,boundary)
            engine.time=boundary
            # A later occupancy change cannot undo a separation already reached.
            engine.world_bodies={'A':[Cuboid('torso',[0,0,1],[100,2,2])]}
            time,payloads=engine.next_mobile_projectile_contacts(D(10))
            self.assertEqual(time,rounded)
            self.assertEqual(payloads[0]['projectile_event'],'projectile_owner_cleared')

    def test_removed_collider_invalidates_a_contact_already_confirmed_before_rounding(self):
        engine=ContactHarness()
        boundary=D('1.0000005')
        engine.next_mobile_projectile_contacts(boundary)
        engine.time=boundary
        engine.collider_system.registry.remove('foil',time=boundary,reason='removed_before_resolution')
        engine.collider_system.sync()
        self.assertIsNone(engine.next_mobile_projectile_contacts(D(2)))
        self.assertEqual(engine.gravity_deferred_contacts,{})

    def test_nonlethal_collider_damage_keeps_reached_contact_confirmation_valid(self):
        engine=ContactHarness(collider_hp=100)
        boundary=D('1.0000005')
        engine.next_mobile_projectile_contacts(boundary)
        original=engine.gravity_deferred_contacts[engine.shot_id][2]
        engine.time=boundary
        engine.collider_system.registry.damage('foil',50,time=boundary)
        at,payloads=engine.next_mobile_projectile_contacts(D(2))
        self.assertEqual(at,D('1.000001'))
        self.assertEqual(payloads[0]['trajectory_contact_bracket_s'],original['trajectory_contact_bracket_s'])
