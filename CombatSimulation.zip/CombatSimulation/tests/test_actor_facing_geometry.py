"""Fixed actor pose and attachment contracts, independent of turn control."""
from dataclasses import replace
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
from types import SimpleNamespace
import json,unittest

from combat_sim.facing import parse,record,forward
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.hitboxes import Cuboid,standing_cuboids,world_standing_cuboids,local_to_world_point,combined_bounds
from combat_sim.character_geometry import scaled_definition,profile_scale
from combat_sim.postures import world_posture_cuboids,body_origin_from_bounds
from combat_sim.prone import prone_morph
from combat_sim.owned_contacts import OwnedContacts
from tests.test_mobile_combat import BODY,PROFILES

FRAME=YawFrame(F(3,5),F(4,5))


class ActorFacingGeometryTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def test_explicit_degrees_and_cardinal_legacy_values_remain_distinct_inputs(self):
        self.assertEqual(parse('+x',precision=50),'+x');self.assertEqual(parse('-x',precision=50),'-x')
        self.assertEqual(parse({'yaw_degrees':450},precision=50),YawFrame(0,1))
        self.assertEqual(forward(FRAME),(F(3,5),F(4,5),0))

    def test_malformed_heading_definitions_fail_without_inferred_defaults(self):
        for v in (None,True,{},'+y',{'yaw_degrees':True},{'yaw_degrees':'NaN'},{'yaw_degrees':1,'extra':2}):
            with self.subTest(value=v),self.assertRaises(ValueError):parse(v,precision=50)

    def test_frame_record_retains_exact_selected_metric_and_is_json_data(self):
        r=json.loads(json.dumps(record(FRAME)))['yaw_frame']
        self.assertEqual(F(r['cosine'])**2+F(r['sine'])**2,1)
        self.assertEqual(record('+x'),'+x')

    def test_all_source_scaled_parts_keep_local_dimensions_and_actual_centres(self):
        for n,p in PROFILES.items():
            with self.subTest(character=n):
                definition=scaled_definition(BODY,profile_scale(BODY,p));origin=(12,-7,4)
                local=standing_cuboids(definition);world=world_standing_cuboids(definition,origin,FRAME)
                self.assertEqual(len(world),6)
                for a,b in zip(local,world):
                    self.assertIsInstance(b,OrientedCuboid);self.assertEqual(a.size_m,b.size_m)
                    self.assertEqual(a.centre_m,FRAME.to_local_point(b.centre_m,origin))

    def test_common_point_transform_preserves_explicit_origin_and_inverse(self):
        p=(F(1,7),F(-2,3),F(9,4));origin=(10,20,30)
        self.assertEqual(FRAME.to_local_point(local_to_world_point(p,origin,FRAME),origin),p)
        self.assertEqual(local_to_world_point((1,2,3),(4,5,6),'+x'),(6,4,9))

    def test_crouch_keeps_oriented_parts_and_anchored_feet(self):
        origin=(10,20,F(7,8))
        for q in (0,F(1,2),1):
            boxes=world_posture_cuboids(BODY,origin,FRAME,q,F(2,5))
            self.assertTrue(all(isinstance(b,OrientedCuboid) and b.frame==FRAME for b in boxes))
            self.assertEqual(combined_bounds(boxes)[0][2],0)
            self.assertEqual(body_origin_from_bounds(boxes)[:2],origin[:2])

    def test_prone_body_reference_is_rotation_covariant_despite_an_asymmetric_envelope(self):
        morph=prone_morph(BODY);origin=(12,-9,5)
        for q in (F(1,5),F(3,5),1):
            boxes=morph.world_parts(origin,FRAME,q);low,high=combined_bounds(morph.local_parts(q))
            centre=tuple((a+b)/2 for a,b in zip(low,high))
            self.assertEqual(body_origin_from_bounds(boxes),FRAME.to_world_point(centre,origin))

    def test_prone_crouch_derivatives_match_exact_quadratic_pose_samples(self):
        q,c,v,a,cv,ca=F(2,5),F(1,7),F(1,3),F(1,5),F(1,11),F(1,13)
        morph=prone_morph(BODY,c);h=F(1,10000)
        at=lambda t:{p.part:p for p in replace(morph,crouch_fraction=c+cv*t+ca*t*t/2).world_parts(
            (3,7,11),FRAME,q+v*t+a*t*t/2)}
        minus,now,plus=at(-h),at(0),at(h)
        for name,p in now.items():
            velocities,accelerations,size_v,size_a=morph.part_derivatives(name,q,v,a,FRAME,
                crouch_rate_per_s=cv,crouch_acceleration_per_s2=ca)
            for field,velocity,acceleration in (('centre_m',velocities,accelerations),('size_m',size_v,size_a)):
                x,y,z=(getattr(rows[name],field) for rows in (minus,now,plus))
                self.assertEqual(velocity,tuple((r-l)/(2*h) for l,r in zip(x,z)))
                self.assertEqual(acceleration,tuple((r-2*m+l)/(h*h) for l,m,r in zip(x,y,z)))

    def test_owned_anchor_fraction_and_dimensions_stay_in_the_body_local_frame(self):
        anchor=OrientedCuboid('torso',(10,20,30),('.5','.3','.7'),FRAME)
        w=SimpleNamespace(world_bodies={'A':(anchor,)},fighters={'A':SimpleNamespace(id='A',body_origin_m=(10,20,30))})
        row={'id':'probe','actor':'A','facing':FRAME,'geometry':{'anchor_part':'torso',
            'centre_offset_m':['.1','.2','.3'],'size_xyz_m':['.4','.5','.6'],'anchor_fraction':['.2','-.3','.4']}}
        system=OwnedContacts(w);box=system.box(row)
        expected=FRAME.to_world_point((F('.2'),F('.11'),F('.58')),anchor.centre_m)
        self.assertEqual(box.centre_m,expected);self.assertEqual(box.size_m,(F('.4'),F('.5'),F('.6')))
        self.assertEqual(box.frame,FRAME)

    def test_owned_anchor_rate_transforms_the_local_dimension_derivative(self):
        row={'facing':FRAME,'geometry':{'anchor_fraction':['.2','-.3','.4']}}
        actual=OwnedContacts.anchor_displacement(row,(1,2,3))
        expected=FRAME.to_world_vector((F('.2'),F('-.6'),F('1.2')))
        self.assertEqual(tuple(map(F,actual)),expected)

    def test_owned_forward_order_uses_heading_projection(self):
        frame=YawFrame(0,1);w=SimpleNamespace(fighters={'A':SimpleNamespace(body_origin_m=(0,0,0))})
        system=OwnedContacts(w);row={'actor':'A','facing':frame}
        near=Cuboid('near',(20,2,1),(1,1,1));far=Cuboid('far',(1,10,1),(1,1,1))
        self.assertLess(system.order(row,'near',near),system.order(row,'far',far))


if __name__=='__main__':unittest.main()
