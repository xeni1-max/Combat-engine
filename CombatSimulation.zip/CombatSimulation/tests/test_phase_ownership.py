"""Atomic phase handoff: no global lock, temporary resource gap or lost receipts."""
from decimal import Decimal as D
import unittest

from combat_sim.action_ownership import ActionRegistry,ActionRequirements,ActionConflict
from combat_sim.battle_models import BattleAction,decimal_value as dec


def action(identity,kind='grab'):
    return BattleAction(identity,'A','B','2',kind,D(0),D(100),D(180),phase='active',life_generation=1)


def requirement(*resources,cost=None,phase=None,functions=()):
    return ActionRequirements(frozenset(resources),frozenset(functions),D(cost) if cost is not None else None,phase)


class PhaseOwnershipTests(unittest.TestCase):
    def setup_registry(self,cost=False):
        current=[D(0)];rule=requirement('hand:left','weapon:2',cost=2 if cost else None,phase='active_start' if cost else None)
        registry=ActionRegistry(lambda a:rule,lambda:current[0]);parent=action(1);registry.acquire(parent)
        return registry,parent,current

    def test_grab_tail_and_hold_share_one_atomic_handoff_and_keep_paid_receipt(self):
        registry,parent,d=self.setup_registry(True);payment=registry.payment(1,2,'active_start');d[0]=dec(payment.after)
        hold=action(2,'hold')
        registry.transfer({1:requirement('phase_tail:1')},((hold,requirement('hand:left','weapon:2')),))
        self.assertIs(registry.owner('hand:left'),hold);self.assertIs(registry.owner('phase_tail:1'),parent)
        self.assertEqual(registry.paid_phases[1],{'active_start'});self.assertEqual(registry.reserved(),0)
        self.assertEqual(d[0],4)
        with self.assertRaises(ActionConflict):registry.payment(1,2,'active_start')
        self.assertEqual(registry.unavailable(requirement('hand:right')),(frozenset(),frozenset()))

    def test_invalid_new_owner_leaves_parent_and_cost_state_unchanged(self):
        registry,parent,_=self.setup_registry();other=action(2);registry._acquire(other,requirement('hand:right'))
        before=registry.record();hold=action(3,'hold')
        with self.assertRaises(ActionConflict):
            registry.transfer({1:requirement('phase_tail:1')},((hold,requirement('hand:left','hand:right')),))
        self.assertEqual(registry.record(),before);self.assertIs(registry.owner('hand:left'),parent)

    def test_restriction_on_occupied_hand_prevents_the_entire_handoff(self):
        registry,parent,_=self.setup_registry();registry.blocks['injury']=frozenset({'hand:left'})
        before=registry.record()
        with self.assertRaises(ActionConflict):
            registry.transfer({1:requirement('phase_tail:1')},((action(2),requirement('hand:left')),))
        self.assertEqual(registry.record(),before)

    def test_existing_owners_can_exchange_resources_without_order_dependence(self):
        registry,first,_=self.setup_registry();second=action(2);registry._acquire(second,requirement('hand:right'))
        registry.transfer({2:requirement('hand:left'),1:requirement('hand:right')})
        self.assertIs(registry.owner('hand:left'),second);self.assertIs(registry.owner('hand:right'),first)

    def test_unpaid_cost_cannot_disappear_in_a_resource_change(self):
        registry,parent,_=self.setup_registry(True);before=registry.record()
        with self.assertRaises(ActionConflict):registry.transfer({1:requirement('phase_tail:1')})
        self.assertEqual(registry.record(),before)

    def test_unchanged_unpaid_cost_keeps_an_authoritative_payment_rule(self):
        registry,parent,_=self.setup_registry(True)
        registry.transfer({1:requirement('hand:right',cost=2,phase='active_start')})
        self.assertTrue(registry.payment(1,2,'active_start').allowed)
        self.assertEqual(registry.paid_phases[1],{'active_start'})

    def test_foreign_stale_and_repeated_commits_reject_without_changes(self):
        registry,parent,d=self.setup_registry();other,_,_=self.setup_registry()
        plan=registry.prepare_transfer({1:requirement('hand:right')})
        with self.assertRaises(ActionConflict):other.commit_transfer(plan)
        d[0]=D(1)
        with self.assertRaises(ActionConflict):registry.commit_transfer(plan)
        d[0]=D(0);registry.commit_transfer(plan)
        with self.assertRaises(ActionConflict):registry.commit_transfer(plan)

    def test_changed_new_action_is_not_silently_acquired_from_an_old_plan(self):
        registry,parent,_=self.setup_registry();hold=action(2,'hold')
        plan=registry.prepare_transfer({1:requirement('phase_tail:1')},((hold,requirement('hand:left')),))
        hold.phase='gathering'
        with self.assertRaises(ActionConflict):registry.commit_transfer(plan)
        self.assertNotIn(2,registry.actions)


if __name__=='__main__':unittest.main()
