"""Current public balance/prone rules across the existing kits and native motion.

Real casts supply damage, fields, binding, healing and revival. Explicit
knockdown/restoration/clearance operations are labelled engineering probes.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import json
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.exact_ratio import read_ratio
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import run_shared_scenario
from tests.test_equilibrium_combat import run,scene,rules
from tests.test_mobile_combat import command,events,PROFILES
from tests.test_component_melee_combat import scene as component_scene
from tests.test_grapple_casts_combat import scene as hold_scene
from tests.test_body_dashes_combat import scene as dash_scene
from tests.test_blocking_combat import scene as block_scene
from tests.test_melee_venom_combat import scene as thrust_scene
from tests.test_binding_combat import scene as mark_scene,control
from tests.test_chain_cast_combat import scene as chain_scene,heavy_scene
from tests.test_ground_chain_combat import scene as ground_scene,roof_scene
from tests.test_revival_combat import scene as revival_scene
from tests.test_climb_combat import scene as climb_scene,climb
from tests.test_cooldown_fields_combat import marking_scene
from tests.test_grapple_links_combat import pos,vel,force
from tests.test_world_colliders_combat import wall
from tests.test_binding_combat import run as configured_run,BODY,TERRAIN,MOVEMENT,CLIMB,PHYSICS


def knock(actor):
    def apply(w):w.apply_knockdown(actor,source='explicit_prone_interaction_probe')
    return apply


def selected(duration=1500,character='1E1',ability='1',distance=10):
    s=scene(duration,character=character)
    s['encounter']['participants']['B']['position_m']=[distance,-20]
    s['action_selection']['A'].update(abilities=[ability],reload_when_empty=False,start_ms=0)
    return s


class EquilibriumInteractionTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=70));context.__enter__();self.addCleanup(context.__exit__,None,None,None)

    def conserved(self,r):
        json.dumps(r)
        damage=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        for actor,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=actor)
            self.assertLess(abs(supplied-D(r['final_states'][actor]['hp'])-damage.amount(target=actor)),D('1e-8'))
        return damage

    def test_selected_public_input_enables_balance_and_owned_get_up(self):
        self.assertEqual(rules()['equilibrium'],{'mode':'status_balance_v1'})
        self.assertIn('locomotion',rules()['action_ownership']['actions']['get_up']['occupies'])

    def test_current_rules_require_supplied_jump_values_and_saved_body_paths(self):
        with self.assertRaisesRegex(ValueError,'source basic-jump'):
            run_shared_scenario(scene(),PROFILES,body_definition=BODY,terrain_definition=TERRAIN,
                movement_definition=MOVEMENT,climb_definition=CLIMB,projectile_physics_definition=PHYSICS,
                combat_locomotion_definition=rules())
        cfg=rules();cfg.pop('body_paths')
        with self.assertRaisesRegex(UnsupportedMechanicError,'saved-path'):configured_run(scene(),rules=cfg)
        cfg=rules();cfg['equilibrium']={'mode':'unrecognized'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'status_balance'):configured_run(scene(),rules=cfg)

    def test_actual_block_counter_causes_source_rate_fall_and_paid_get_up(self):
        r=run(block_scene(1300,distance=4));self.conserved(r)
        self.assertTrue(events(r,'combat_reaction_released','A'))
        fall=events(r,'knockdown_applied','B')[0];start=events(r,'get_up_started','B')[0]
        self.assertEqual(fall['source'],'equilibrium');self.assertEqual(fall['time_ms'],start['time_ms'])
        self.assertEqual(r['metrics']['B']['get_ups_completed'],1)
        first=next(e for e in events(r,'impact_batch_resolved') if e['target']=='A')
        self.assertEqual(D(first['applied_hp_damage']),0)
        self.assertGreater(D(first['hits'][0]['block_absorbed']),0)

    def test_real_alternating_arms_passive_and_ultimate_use_current_pose(self):
        r=run(component_scene(1600,('Ultimate','1')));damage=self.conserved(r)
        self.assertEqual({s['component_id'] for s in r['released_attack_modifiers']},{'a','b'})
        grant=r['attack_modifiers'][0];self.assertEqual(D(grant['start_ms']),320)
        for snapshot in r['released_attack_modifiers']:
            expected=80 if D(snapshot['released_at_ms'])>=D(grant['start_ms']) else 0
            self.assertEqual(D(snapshot['values']['additional_piercing']),expected)
        self.assertTrue(events(r,'bleeding_started'));self.assertGreater(damage.amount(actor='A'),0)
        self.assertTrue(all(e['ability']=='1' for e in events(r,'dyspnea_paid','A')))

    def test_released_bleed_survives_explicit_knockdown_of_controller(self):
        r=run(component_scene(1100),operations=((300,knock('A')),));self.conserved(r)
        self.assertTrue(events(r,'bleeding_started'))
        self.assertTrue([e for e in events(r,'continuous_damage_resolved') if D(e['time_ms'])>300])
        self.assertTrue(events(r,'controlled_action_cancelled','A'))
        self.assertTrue(r['final_states']['A']['knocked_down'])

    def test_actual_hold_is_cancelled_by_controller_fall_without_residual_owned_rates(self):
        r=run(hold_scene(1000),operations=((400,knock('A')),));self.conserved(r)
        self.assertEqual(len(r['grapple_holds']),1)
        hold=r['grapple_holds'][0];self.assertEqual(D(hold['ended_at_ms']),400)
        self.assertFalse(r['final_states']['A']['owned_actions'])
        self.assertTrue(all(x['ended_at_ms'] is not None for x in r['controlled_damage_streams']))

    def test_recipient_knockdown_does_not_cancel_another_actors_actual_hold(self):
        r=run(hold_scene(900),operations=((400,knock('B')),));self.conserved(r)
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertTrue(r['final_states']['B']['knocked_down'])

    def test_real_chain_and_common_break_continue_through_explicit_knockdown(self):
        s=chain_scene(4500);control(s,900,'B');r=run(s,operations=((1000,knock('B')),));self.conserved(r)
        b=r['binding_instances'][0];self.assertEqual(b['end_reason'],'break_escaped')
        self.assertFalse([e for e in events(r,'controlled_action_cancelled','B') if e['action']['kind']=='binding_break'])
        self.assertTrue(events(r,'get_up_completed','B'))

    def test_ground_chain_keeps_fixed_anchor_when_recipient_falls_and_gets_up(self):
        r=run(ground_scene(3000),operations=((900,knock('B')),));self.conserved(r)
        self.assertEqual(len(r['terrain_anchors']),1)
        self.assertEqual(r['binding_instances'][0]['status'],'active')
        self.assertTrue(events(r,'get_up_completed','B'))
        self.assertEqual(tuple(map(D,r['terrain_anchors'][0]['position_m'])),(10,-20,0))

    def test_real_mark_freeze_and_escape_retain_native_work_clocks(self):
        r=run(mark_scene(7000));self.conserved(r)
        self.assertEqual(r['binding_instances'][0]['end_reason'],'break_escaped')
        self.assertGreaterEqual(len(events(r,'binding_mark_added')),3)
        self.assertEqual(r['binding_marks'][0]['status'],'consumed')

    def test_real_thrust_replacement_venom_and_healing_share_actual_pose(self):
        s=thrust_scene(1500);s['action_selection']['B']['start_ms']=0
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'blade_attached'));self.assertTrue(events(r,'blade_equipped'))
        self.assertGreater(D(r['metrics']['A']['hp_healed']),0)
        self.assertGreater(D(r['metrics']['B']['continuous_hp_damage_received']),0)

    def test_real_paid_enhancements_remain_autonomous_after_knockdown(self):
        s=thrust_scene(2000);s['action_selection']['A']['abilities']=['4','Ultimate','1']
        r=run(s,operations=((1000,knock('A')),));self.conserved(r)
        self.assertEqual(len(r['attack_modifiers']),2)
        ordinary,ultimate=r['attack_modifiers']
        self.assertEqual(ordinary['end_reason'],'consumed')
        self.assertEqual(ultimate['status'],'active')

    def test_real_deployed_beam_survives_controller_fall(self):
        r=run(selected(2200,ability='4'),operations=((600,knock('A')),));self.conserved(r)
        self.assertTrue(events(r,'beam_deployed'))
        self.assertTrue([e for e in events(r,'continuous_damage_resolved') if D(e['time_ms'])>600])
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),9)

    def test_actual_qard_projectile_and_delayed_blast_survive_controller_fall(self):
        r=run(selected(2300,distance=100),operations=((400,knock('A')),));self.conserved(r)
        self.assertEqual(len([e for e in events(r,'projectile_released') if D(e['time_ms'])<400]),1)
        self.assertTrue(events(r,'projectile_body_collision'));self.assertTrue(events(r,'delayed_blast'))

    def test_actual_released_gun_round_survives_controller_fall(self):
        # Seed 0 disperses past the body; seed 114 deliberately hits it. Both
        # retain the entire released flight after the controller falls.
        for seed in (0,114):
            with self.subTest(seed=seed):
                s=selected(600,character='1E2',distance=100);s['random_seed']=seed
                baseline=run(s);r=run(s,operations=((112,knock('A')),));self.conserved(r)
                self.assertEqual(r['projectile_flights'][0],baseline['projectile_flights'][0])
                if seed==0:self.assertEqual(r['projectile_flights'][0]['status'],'in_flight')
                else:
                    self.assertTrue(events(r,'projectile_body_collision'));self.assertTrue(events(r,'bleeding_started'))
                    self.assertGreater(D(events(r,'projectile_body_collision')[0]['time_ms']),112)

    def test_real_pause_field_keeps_its_clock_when_caster_is_knocked_down(self):
        r=run(marking_scene(5000),operations=((600,knock('A')),));self.conserved(r)
        self.assertEqual((r['cooldown_pause_volumes'][0]['start'],r['cooldown_pause_volumes'][0]['expiry']),('200','4200'))
        self.assertTrue(events(r,'cooldown_pause_left'))

    def test_actual_gun_death_and_paid_revival_preserve_partial_prone_pose_without_old_action(self):
        r=run(revival_scene(2900),operations=((350,knock('A')),));self.conserved(r)
        death=events(r,'character_died','A')[0];birth=events(r,'life_restored','A')[0]
        self.assertEqual(D(birth['time_ms'])-D(death['time_ms']),2000)
        self.assertEqual(death['state']['locomotion']['body_height_m'],birth['state']['locomotion']['body_height_m'])
        self.assertEqual(r['equilibrium_states']['A']['life_generation'],2)
        self.assertEqual(r['metrics']['A']['get_ups_completed'],1)
        self.assertTrue(all(D(e['time_ms'])>=D(birth['time_ms']) for e in events(r,'get_up_started','A')))

    def test_new_life_cannot_complete_the_old_paid_get_up(self):
        s=scene(750,down=True);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=0
        def restore(w):
            self.assertTrue(w.life_cycles.revive('A',expected_generation=1,hp=2000,source='explicit_early_restoration_probe'))
        r=run(s,operations=((200,restore),));self.conserved(r)
        self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_started','A')],[0,200])
        self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_completed','A')],[600])
        self.assertEqual(r['equilibrium_states']['A']['life_generation'],2)

    def test_own_falling_pose_does_not_masquerade_as_external_climb_displacement(self):
        s=climb_scene(700);climb(s);r=run(s);self.conserved(r)
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertFalse(events(r,'climb_interrupted'))
        self.assertEqual(pos(r,'A'),(6,0,D('2.675')))

    def test_imposed_motion_still_interrupts_actual_climb_and_retains_gravity(self):
        s=climb_scene(1300);climb(s);s['spatial_interventions']=[force(220,'A',[-5,0,0])]
        r=run(s);self.conserved(r)
        self.assertEqual(r['metrics']['A']['climb_interruptions'],1)
        self.assertEqual(r['metrics']['A']['climbs_completed'],0)
        self.assertEqual(r['metrics']['A']['landings'],1)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('12.25'))

    def test_actual_anchor_destruction_still_releases_support_and_paid_landing(self):
        r=run(roof_scene(beam=True));self.conserved(r)
        self.assertEqual(r['metrics']['B']['climbs_completed'],1)
        self.assertEqual(r['binding_instances'][0]['end_reason'],'anchor_destroyed')
        self.assertEqual(r['metrics']['B']['landings'],1)

    def test_running_jump_with_simultaneous_partial_fall_uses_one_translation_writer(self):
        s=scene(1500);command(s,'A',0,'run');command(s,'A',350,'jump');r=run(s,interval=17);self.conserved(r)
        self.assertEqual(r['metrics']['A']['jumps_started'],1);self.assertEqual(r['metrics']['A']['landings'],1)
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),6)

    def test_knockdown_in_actual_dash_preserves_trajectory_and_one_landing_receipt(self):
        r=run(dash_scene(),operations=((200,knock('A')),));self.conserved(r)
        self.assertEqual(len(events(r,'body_launch_landed')),1)
        self.assertAlmostEqual(D(events(r,'body_launch_landed')[0]['time_ms']),140+D(7000)/D('9.81'),places=18)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),D('6.25'))

    def test_dash_body_collision_and_blocked_pose_do_not_create_an_event_retry_storm(self):
        s=dash_scene();s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(position_m=[-3,-20],team='A')
        s['action_selection']['C']=deepcopy(s['action_selection']['B']);r=run(s);self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertEqual(len(events(r,'body_launch_landed')),1)
        self.assertLess(r['equilibrium_segments'],1000)
        self.assertEqual(DamageLedger.from_record(r['applied_hp_history']).amount(),0)

    def test_committed_source_intervals_independently_reconstruct_progress(self):
        r=run(scene(2000,o=1000,u=1000));rows=[x for x in r['equilibrium_intervals'] if x['actor']=='A']
        self.assertGreater(len(rows),10)
        for first,second in zip(rows,rows[1:]):
            end=F(first['committed_end_ms']);begin=F(first['begin_ms']);dt=(end-begin)/1000
            self.assertEqual(end,F(second['begin_ms']))
            predicted=read_ratio(first['progress'])+read_ratio(first['velocity_per_s'])*dt+read_ratio(first['acceleration_per_s2'])*dt*dt/2
            self.assertLess(abs(predicted-read_ratio(second['progress'])),F(1,10**35))
            if first['driver']=='equilibrium' and first['kind']=='falling':
                o,u=F(first['source_disorientation']),F(first['source_instability'])
                self.assertEqual(read_ratio(first['velocity_per_s']),(o+u+400)/600)
                self.assertEqual(read_ratio(first['acceleration_per_s2']),-F(10,3))

    def test_actual_heavy_punch_and_hold_keep_summed_grapple_resistance(self):
        r=run(heavy_scene(held=True));self.conserved(r)
        assessment=r['knock_impulses'][0]['assessment']
        self.assertEqual(assessment['actors'],['B','D'])
        self.assertEqual(D(assessment['maximum_hp_sum']),D(PROFILES['1E2']['max_hp'])+D(PROFILES['1E5']['max_hp']))
        self.assertTrue(r['binding_instances']);self.assertEqual(r['grapple_holds'][0]['status'],'active')

    def test_low_capacity_waits_in_prone_pose_then_pays_once(self):
        s=scene(1200,down=True);s['encounter']['participants']['A']['initial_state']['dyspnea']=100
        r=run(s,interval=50);self.conserved(r)
        self.assertTrue(events(r,'get_up_waiting_for_capacity','A'))
        self.assertEqual(r['metrics']['A']['get_ups_started'],1);self.assertEqual(r['metrics']['A']['get_ups_completed'],1)
        start=D(events(r,'get_up_started','A')[0]['time_ms']);self.assertGreater(start,0)
        for point in r['curve']:
            if D(point['time_ms'])<start:self.assertEqual(D(point['states']['A']['locomotion']['body_height_m']),D('.3'))

    def test_standing_clearance_uses_partial_balance_geometry_before_payment(self):
        s=scene(400);command(s,'A',0,'crouch');command(s,'A',150,'stand')
        def cover(w):w.collider_system.spawn_definition(wall('ceiling',x=0,hp=None,z='1.45',size=(4,4,'.1')))
        r=run(s,operations=((149,cover),));self.conserved(r)
        self.assertTrue(events(r,'stand_rejected','A'))
        self.assertEqual(r['metrics']['A']['crouches_completed'],1)
        self.assertEqual(r['metrics']['A']['stands_completed'],0)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),1)

    def test_blocked_dash_contact_pose_is_independent_of_observations(self):
        s=dash_scene(400);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(position_m=[-3,-20],team='A')
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        a=run(s);b=run(s,interval=17,precision=80)
        for name in ('A','C'):
            for x,y in zip(pos(a,name),pos(b,name)):self.assertAlmostEqual(x,y,places=19)
            self.assertAlmostEqual(D(a['equilibrium_states'][name]['progress']),D(b['equilibrium_states'][name]['progress']),places=19)
        self.assertEqual(len(events(a,'body_contact')),len(events(b,'body_contact')))

    def test_actual_counter_fall_is_stable_under_precision_observation_and_actor_order(self):
        s=block_scene(1300,distance=4);a=run(s)
        s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        self.conserved(a);self.conserved(b)
        for kind in ('knockdown_applied','get_up_started','get_up_completed'):
            self.assertAlmostEqual(D(events(a,kind,'B')[0]['time_ms']),D(events(b,kind,'B')[0]['time_ms']),places=23)
        for actor in ('A','B'):
            self.assertEqual(a['metrics'][actor]['get_ups_completed'],b['metrics'][actor]['get_ups_completed'])
            self.assertAlmostEqual(D(a['final_states'][actor]['hp']),D(b['final_states'][actor]['hp']),places=20)


if __name__=='__main__':unittest.main()
