"""Finite ground contacts and the three author-defined terrain cubes."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import json
from pathlib import Path
import unittest

from combat_sim.terrain import RectangularGround,terrain_colliders
from combat_sim.models import UnsupportedMechanicError


ROOT=Path(__file__).resolve().parents[1]
TERRAIN=json.loads((ROOT/'data/terrain/stationary_arena.json').read_text())


class GroundSurfaceTests(unittest.TestCase):
    def setUp(self):
        self.ground=RectangularGround('ground',[-250,-250,0],[250,250,0])

    def test_downward_sphere_contacts_finite_ground_before_its_centre(self):
        contact=self.ground.swept_sphere_contact([0,0,1],[0,0,-1],F(1,50))
        self.assertEqual(contact.parameter,D('.49'))
        self.assertEqual(contact.centre_m,(D(0),D(0),D('.02')))
        self.assertEqual(contact.closest_box_point_m,(D(0),D(0),D(0)))

    def test_ground_does_not_extend_past_its_finite_footprint(self):
        self.assertIsNone(self.ground.swept_sphere_contact([251,0,1],[251,0,-1],F(1,50)))

    def test_open_sides_and_top_create_no_vertical_colliders(self):
        self.assertIsNone(self.ground.swept_sphere_contact([249,0,1],[251,0,1],F(1,50)))
        self.assertIsNone(self.ground.swept_sphere_contact([0,0,199],[0,0,201],F(1,50)))

    def test_spherical_edge_contact_is_not_an_infinite_plane(self):
        contact=self.ground.swept_sphere_contact([250.01,0,1],[250.01,0,-1],F(1,50))
        self.assertIsNotNone(contact)
        self.assertEqual(contact.closest_box_point_m[0],250)
        with localcontext(Context(prec=60)):
            squared=sum((a-b)**2 for a,b in zip(contact.centre_m,contact.closest_box_point_m))
            self.assertLess(abs(squared-D('.0004')),D('1e-45'))

    def test_invalid_rectangles_fail(self):
        for low,high in (([0,0,0],[0,1,0]),([0,0,0],[1,1,1]),([1,0,0],[0,1,0])):
            with self.assertRaises(ValueError):
                RectangularGround('bad',low,high)


class SuppliedCubeTests(unittest.TestCase):
    def test_three_cube_centres_sizes_and_ground_contact(self):
        colliders=terrain_colliders(TERRAIN)
        self.assertEqual(set(colliders),{'ground','cube_1','cube_2','cube_3'})
        for name,x,y in [('cube_1',6,0),('cube_2',2,15),('cube_3',15,15)]:
            box=colliders[name][0]
            self.assertEqual(box.centre_m,(x,y,F(9,10)))
            self.assertEqual(box.size_m,(F(9,5),)*3)
            self.assertEqual(box.bounds[0][2],0)
            self.assertEqual(box.bounds[1][2],F(9,5))

    def test_cube_at_six_metres_blocks_a_torso_height_sphere(self):
        box=terrain_colliders(TERRAIN)['cube_1'][0]
        contact=box.swept_sphere_contact([0,0,1.1],[30,0,1.1],F(1,50))
        self.assertLess(abs(contact.centre_m[0]-D('5.08')),D('1e-45'))
        self.assertEqual(contact.closest_box_point_m[0],D('5.1'))

    def test_unprovided_resistance_or_boundary_rules_are_rejected(self):
        for mode in ('armor','wall'):
            modified=deepcopy(TERRAIN)
            if mode=='armor':
                modified['obstacles'][0]['armor']=1000
            else:
                modified['boundary_behavior']['sides']='solid'
            with self.assertRaises(UnsupportedMechanicError):
                terrain_colliders(modified)

    def test_duplicate_object_ids_or_floating_cubes_fail(self):
        for mode in ('duplicate','floating'):
            modified=deepcopy(TERRAIN)
            if mode=='duplicate':
                modified['obstacles'][0]['id']='ground'
            else:
                modified['obstacles'][0]['centre_m'][2]=2
            with self.assertRaises(ValueError):
                terrain_colliders(modified)
