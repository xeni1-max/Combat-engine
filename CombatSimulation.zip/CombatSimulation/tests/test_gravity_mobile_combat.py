"""Gravity, moving bodies and terrain on the shared combat timeline."""
from copy import deepcopy
from decimal import Decimal as D
from math import dist, hypot
import unittest

from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE, MOBILE_SCOPE
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import run_shared_scenario
from tests.test_mobile_combat import BODY, EFFECTS, MOVEMENT, PROFILES, TERRAIN
from tests.test_mobile_combat import command, events, read, scenario as ground_scenario


PHYSICS = read('data/physics/projectile_gravity.json')


def scenario(*args, **kwargs):
    result = ground_scenario(*args, **kwargs)
    result['scope'] = dict(GRAVITY_MOBILE_SCOPE)
    return result


def run(s, *, physics=PHYSICS, terrain=TERRAIN, **kwargs):
    return run_shared_scenario(s, PROFILES, body_definition=BODY,
        terrain_definition=terrain, movement_definition=MOVEMENT,
        combat_locomotion_definition=EFFECTS,
        projectile_physics_definition=physics, **kwargs)


class GravityMovingCombatTests(unittest.TestCase):
    def test_compensated_shot_hits_running_target(self):
        s = scenario(900, fire_at=500)
        command(s, 'B', 0, 'run')
        result = run(s)
        release = events(result, 'projectile_released')[0]
        hit = events(result, 'projectile_body_collision')[0]
        velocity = release['initial_velocity_mps']
        self.assertAlmostEqual(hypot(*velocity), 900, places=9)
        # Compensated elevation exceeds the straight line to the release-time torso.
        origin, aim = release['origin_m'], release['aim_point_m']
        direct_slope = (float(aim[2])-float(origin[2]))/(float(aim[0])-float(origin[0]))
        self.assertGreater(velocity[2]/velocity[0], direct_slope)
        self.assertLess(release['aim_solver']['position_error_m'], float(PHYSICS['aim_position_tolerance_m']))
        self.assertEqual(hit['target'], 'B')
        self.assertLess(D(hit['distance_m']), 30)
        self.assertLess(D(result['final_states']['B']['hp']), 8140)
        self.assertTrue(events(result, 'bleeding_started'))
        self.assertGreater(D(result['metrics']['A']['dyspnea_paid']), 0)

    def test_lateral_motion_causes_miss_without_predictive_lead(self):
        s = scenario(1500, fire_at=1000, target=(100, -20))
        s['encounter']['participants']['B']['movement_direction'] = [0, 1]
        command(s, 'B', 0, 'run')
        result = run(s)
        self.assertEqual(len(events(result, 'projectile_released')), 1)
        self.assertFalse(events(result, 'projectile_body_collision'))
        self.assertEqual(D(result['final_states']['B']['hp']), 8140)
        s['movement_script'] = []
        self.assertEqual(len(events(run(s), 'projectile_body_collision')), 1)

    def test_motion_start_after_release_changes_hit_to_miss(self):
        s = scenario(450, fire_at=0, target=(200, -20))
        s['encounter']['participants']['B']['movement_direction'] = [0, 1]
        self.assertEqual(len(events(run(s), 'projectile_body_collision')), 1)
        command(s, 'B', 120, 'walk')
        result = run(s)
        release = events(result, 'projectile_released')[0]
        movement = events(result, 'movement_active_started', 'B')[0]
        self.assertLess(D(release['time_ms']), D(movement['time_ms']))
        self.assertFalse(events(result, 'projectile_body_collision'))

    def test_cube_intercepts_before_target(self):
        s = scenario(300, fire_at=0, target=(30, 0))
        s['encounter']['participants']['A']['position_m'] = [0, 0]
        result = run(s)
        contacts = events(result, 'projectile_terrain_collision')
        self.assertEqual(len(contacts), 1)
        self.assertEqual(contacts[0]['target'], 'cube_1')
        self.assertEqual(D(contacts[0]['location_m'][0]), D('5.1'))
        self.assertFalse(events(result, 'projectile_body_collision'))
        self.assertEqual(D(result['final_states']['B']['hp']), 8140)

    def test_missed_round_hits_finite_ground_where_present(self):
        s = scenario(1000, fire_at=0, target=(100, -20))
        s['encounter']['participants']['B']['movement_direction'] = [0, 1]
        command(s, 'B', 0, 'run')
        # This explicit test arena extends the floor; the authored arena remains intact.
        large = deepcopy(TERRAIN)
        large['battlefield_bounds_m']['minimum'][:2] = [-1000, -1000]
        large['battlefield_bounds_m']['maximum'][:2] = [1000, 1000]
        large['ground']['minimum_m'][:2] = [-1000, -1000]
        large['ground']['maximum_m'][:2] = [1000, 1000]
        result = run(s, terrain=large, sample_interval_ms=None)
        contact = events(result, 'projectile_terrain_collision')[0]
        self.assertEqual(contact['target'], 'ground')
        self.assertEqual(D(contact['location_m'][2]), 0)
        self.assertLessEqual(abs(D(contact['projectile_centre_m'][2])-D('.02')), D('1e-7'))
        self.assertGreater(D(contact['location_m'][0]), 250)
        self.assertFalse(events(result, 'projectile_body_collision'))
        self.assertFalse(events(run(s, sample_interval_ms=None), 'projectile_terrain_collision'))

    def test_observation_precision_and_actor_order_preserve_outcomes(self):
        s = scenario(1200, fire_at=500)
        command(s, 'B', 0, 'run')
        command(s, 'B', 900, 'stop')
        baseline = run(s, sample_interval_ms=None)
        s['encounter']['participants'] = dict(reversed(list(s['encounter']['participants'].items())))
        for precision, interval in ((50, 37), (80, 113)):
            result = run(s, precision=precision, sample_interval_ms=interval)
            base_hits = events(baseline, 'projectile_body_collision')
            hits = events(result, 'projectile_body_collision')
            self.assertEqual(len(hits), len(base_hits))
            for hit, base in zip(hits, base_hits):
                self.assertEqual(hit['target'], base['target'])
                self.assertLessEqual(abs(D(hit['time_ms'])-D(base['time_ms'])), D(PHYSICS['event_quantum_ms']))
            for actor in ('A', 'B'):
                actual, expected = result['final_states'][actor], baseline['final_states'][actor]
                for field in ('hp', 'armor', 'shield', 'dyspnea', 'disorientation', 'instability'):
                    self.assertLessEqual(abs(D(actual[field])-D(expected[field])), D('1e-7'))
                for a, b in zip(actual['position_m'], expected['position_m']):
                    self.assertLessEqual(abs(D(a)-D(b)), D('1e-9'))

    def test_released_round_survives_shooter_death(self):
        s = scenario(600, fire_at=50, target=(200, -20))
        s['action_selection']['B']['start_ms'] = 0
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        result = run(s)
        release = events(result, 'projectile_released', 'A')[0]
        death = events(result, 'character_died', 'A')[0]
        hit = events(result, 'projectile_body_collision', 'A')[0]
        self.assertLess(D(release['time_ms']), D(death['time_ms']))
        self.assertLess(D(death['time_ms']), D(hit['time_ms']))
        self.assertEqual(release['projectile_id'], hit['projectile_id'])
        self.assertFalse(result['final_states']['A']['alive'])
        self.assertLess(D(result['final_states']['B']['hp']), 8140)

    def test_falloff_uses_actual_path_instead_of_endpoint_chord(self):
        result = run(scenario(400, fire_at=0, target=(200, -20)))
        release = events(result, 'projectile_released')[0]
        hit = events(result, 'projectile_body_collision')[0]
        chord = dist(tuple(map(float, release['origin_m'])), tuple(map(float, hit['projectile_centre_m'])))
        distance = D(hit['distance_m'])
        self.assertGreater(distance-D(str(chord)), D('1e-5'))
        resolved = events(result, 'impact_batch_resolved')[0]['hits'][0]
        # Authored gun: 437 base damage, continuous loss5 per20m.
        self.assertEqual(D(resolved['incoming']), D(437)-distance/4)

    def test_missed_round_stops_without_creating_impact(self):
        s = scenario(3400, fire_at=0, target=(100, -20))
        s['encounter']['participants']['B']['movement_direction'] = [0, 1]
        command(s, 'B', 0, 'run')
        result = run(s, sample_interval_ms=None)
        stopped = events(result, 'projectile_stopped')[0]
        release = next(e for e in events(result, 'projectile_released')
                       if e['projectile_id'] == stopped['projectile_id'])
        self.assertFalse(stopped['creates_impact'])
        self.assertGreater(D(stopped['time_ms']), D(release['time_ms'])+2900)
        self.assertGreater(D(stopped['traveled_distance_m']), 1300)
        self.assertFalse(any(e['projectile_id'] == stopped['projectile_id']
                             for e in events(result, 'projectile_body_collision')+
                             events(result, 'projectile_terrain_collision')))

    def test_missing_or_wrong_scope_physics_fails_explicitly(self):
        with self.assertRaisesRegex(ValueError, 'explicit projectile physics'):
            run(scenario(), physics=None)
        s = scenario()
        s['scope'] = dict(MOBILE_SCOPE)
        with self.assertRaisesRegex(UnsupportedMechanicError, 'gravity combat scope'):
            run(s)
        s['scope']['projectile_motion'] = 'unknown'
        with self.assertRaises(UnsupportedMechanicError):
            run(s)

    def test_invalid_physics_models_and_controls_are_not_ignored(self):
        for field, value in (('gravity_mps2', 0), ('max_step_s', -1),
                             ('relative_tolerance', 'NaN'), ('speed_floor_mps', True),
                             ('contact_time_tolerance_s', '.001')):
            definition = deepcopy(PHYSICS)
            definition[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                run(scenario(), physics=definition)
        for field, value in (('aim', 'predictive_lead'), ('terminal_rule', 'detonate'),
                             ('deceleration', 'fixed_launch_direction')):
            definition = deepcopy(PHYSICS)
            definition[field] = value
            with self.subTest(field=field), self.assertRaises(UnsupportedMechanicError):
                run(scenario(), physics=definition)


if __name__ == '__main__':
    unittest.main()
