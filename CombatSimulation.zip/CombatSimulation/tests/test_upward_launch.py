"""Gravity-based nominal up-knock height, independent of force-window duration."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import unittest
from combat_sim.mechanics.body_launch import upward_knock_speed


class UpwardLaunchTests(unittest.TestCase):
    def test_speed_reaches_resisted_height_under_gravity(self):
        with localcontext(Context(prec=50)):
            speed=upward_knock_speed('14.7','9.81')
            self.assertLess(abs(speed*speed/(2*D('9.81'))-D('14.7')),D('1e-45'))
            self.assertGreater(speed,16)

    def test_fully_resisted_height_has_no_launch(self):
        self.assertEqual(upward_knock_speed(0,F(981,100)),0)

    def test_caller_context_does_not_change_result(self):
        with localcontext(Context(prec=9)):value=upward_knock_speed('14.7','9.81')
        with localcontext(Context(prec=90)):self.assertEqual(value,upward_knock_speed('14.7','9.81'))

    def test_negative_or_nonfinite_inputs_reject(self):
        for height,gravity in ((-1,10),(1,0),(True,10),(1,'NaN')):
            with self.assertRaises(ValueError):upward_knock_speed(height,gravity)


if __name__=='__main__':unittest.main()
