"""Confirmed 2v2 geometry and simultaneous shield-allocation examples."""
from copy import deepcopy
from decimal import localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.shield import split_damage, split_simultaneous_damage
from combat_sim.mechanics.slash import calculate_impact
from combat_sim.mechanics.simultaneous import DamagePacket, calculate_simultaneous_impacts
from combat_sim.models import UnsupportedMechanicError
from combat_sim.stationary_geometry import (
    distance_metres, nearest_living_enemy, squared_distance, within_radius,
)


class SimultaneousShieldTests(unittest.TestCase):
    def test_unequal_hits_share_shield_in_raw_damage_ratio(self):
        parts = split_simultaneous_damage([200, 100], 150)
        self.assertEqual(parts, ((F(100), F(100)), (F(50), F(50))))
        self.assertEqual(sum(shield for shield, _ in parts), 150)
        self.assertEqual(sum(overflow for _, overflow in parts), 150)

    def test_fractional_allocations_conserve_each_hit_and_shield(self):
        damages = [437, 450, 17]
        parts = split_simultaneous_damage(damages, 400)
        for incoming, (absorbed, overflow) in zip(damages, parts):
            self.assertEqual(absorbed + overflow, incoming)
            self.assertEqual(absorbed / incoming, F(400, 904))
        self.assertEqual(sum(a for a, _ in parts), 400)

    def test_shield_survives_or_breaks_exactly_without_armor_loss(self):
        for shield in (300, 400):
            parts = split_simultaneous_damage([200, 100], shield)
            self.assertEqual(parts, ((F(200), F(0)), (F(100), F(0))))
            for raw, (absorbed, _) in zip((200, 100), parts):
                hit = calculate_impact(raw, 150, 18, absorbed)
                self.assertEqual((hit.hp_damage, hit.armor_loss), (0, 0))

    def test_single_hit_matches_established_shield_rule(self):
        for shield in (0, 100, 437, 500):
            self.assertEqual(split_simultaneous_damage([437], shield), (split_damage(437, shield),))

    def test_reordering_hits_only_reorders_allocations(self):
        forward = split_simultaneous_damage([437, 450], 100)
        reverse = split_simultaneous_damage([450, 437], 100)
        self.assertEqual(forward, reverse[::-1])

    def test_empty_zero_and_invalid_damage(self):
        self.assertEqual(split_simultaneous_damage([], 10), ())
        self.assertEqual(split_simultaneous_damage([0, 0], 0), ((0, 0), (0, 0)))
        for damages, shield in (([-1, 10], 5), ([10], -1)):
            with self.assertRaises(ValueError):
                split_simultaneous_damage(damages, shield)


class SharedDefenseSnapshotTests(unittest.TestCase):
    def test_two_unshielded_slashes_use_original_armor(self):
        packets = [DamagePacket('slash', 437, 18)] * 2
        results = calculate_simultaneous_impacts(packets, 150, 0, 75)
        reference = calculate_impact(437, 150, 18, 0)
        for hit in results:
            self.assertEqual(hit.pre_hit_armor, 150)
            self.assertEqual(hit.hp_damage, reference.hp_damage)
            self.assertEqual(hit.armor_loss, reference.armor_loss)

    def test_mixed_damage_has_proportional_shield_and_common_defenses(self):
        packets = [DamagePacket('qard', 300), DamagePacket('slash', 100)]
        qard, slash = calculate_simultaneous_impacts(packets, 10, 200, 5)
        self.assertEqual((qard.shield_absorbed, slash.shield_absorbed), (150, 50))
        self.assertEqual((qard.hp_damage, slash.hp_damage), (F(448, 3), 48))
        self.assertEqual(qard.armor_loss, 0)
        self.assertGreater(slash.armor_loss, 0)

    def test_batch_calculations_are_permutation_invariant(self):
        packets = [DamagePacket('slash', 437, 18), DamagePacket('qard', 450)]
        forward = calculate_simultaneous_impacts(packets, 150, 500, 75)
        reverse = calculate_simultaneous_impacts(packets[::-1], 150, 500, 75)
        self.assertEqual(forward, reverse[::-1])

    def test_shield_absorption_does_not_generate_hp_or_armor_damage(self):
        results = calculate_simultaneous_impacts(
            [DamagePacket('slash', 437, 18), DamagePacket('qard', 450)], 150, 1000, 75)
        self.assertTrue(all(hit.hp_damage == 0 and hit.armor_loss == 0 for hit in results))

    def test_unknown_damage_or_negative_inputs_fail(self):
        for packet, armor, resistance in ((DamagePacket('heat', 100), 150, 75),
                                          (DamagePacket('slash', 100, -1), 150, 75),
                                          (DamagePacket('qard', 100), -1, 75),
                                          (DamagePacket('qard', 100), 150, -1)):
            with self.assertRaises(ValueError):
                calculate_simultaneous_impacts([packet], armor, 0, resistance)


PARTICIPANTS = {
    'A_1E1': {'team': 'A', 'hp': 8140, 'position_m': [0, 0]},
    'A_1E2': {'team': 'A', 'hp': 8140, 'position_m': [0, 10]},
    'B_1E1': {'team': 'B', 'hp': 8140, 'position_m': [30, 0]},
    'B_1E2': {'team': 'B', 'hp': 8140, 'position_m': [30, 4]},
}


class StationaryGeometryTests(unittest.TestCase):
    def test_requested_initial_target_choices(self):
        self.assertEqual({name: nearest_living_enemy(name, PARTICIPANTS) for name in PARTICIPANTS}, {
            'A_1E1': 'B_1E1', 'A_1E2': 'B_1E2', 'B_1E1': 'A_1E1', 'B_1E2': 'A_1E1',
        })

    def test_dead_enemies_and_teammates_are_excluded(self):
        participants = deepcopy(PARTICIPANTS)
        participants['A_1E1']['hp'] = 0
        self.assertEqual(nearest_living_enemy('B_1E1', participants), 'A_1E2')
        self.assertIsNone(nearest_living_enemy('A_1E1', participants))
        participants['A_1E2']['hp'] = 0
        self.assertIsNone(nearest_living_enemy('B_1E1', participants))

    def test_exact_blast_boundary_and_beam_membership(self):
        self.assertTrue(within_radius([30, 4], [30, 0], 4))
        self.assertTrue(within_radius([30, 0], [30, 4], 4))
        self.assertFalse(within_radius([30, '4.000000000000000000001'], [30, 0], 4))
        for centre in ([30, 0], [30, 4]):
            self.assertTrue(all(within_radius(position, centre, 7) for position in ([30, 0], [30, 4])))
        self.assertFalse(within_radius([0, 10], [0, 0], 7))

    def test_distances_follow_positions_and_fixed_precision(self):
        self.assertEqual(squared_distance([0, 10], [30, 4]), 936)
        self.assertEqual(distance_metres([0, 0], [30, 0]), 30)
        expected = distance_metres([0, 0], [30, 4])
        with localcontext() as context:
            context.prec = 6
            self.assertEqual(distance_metres([0, 0], [30, 4]), expected)

    def test_equal_distance_uses_stable_instance_identity(self):
        participants = deepcopy(PARTICIPANTS)
        participants['B_1E2']['position_m'] = [0, 30]
        self.assertEqual(nearest_living_enemy('A_1E1', participants),'B_1E1')
        reverse=dict(reversed(list(participants.items())))
        self.assertEqual(nearest_living_enemy('A_1E1', reverse),'B_1E1')

    def test_invalid_coordinate_dimensions_and_radius(self):
        with self.assertRaises(ValueError):
            squared_distance([0, 0, 0], [0, 0])
        with self.assertRaises(ValueError):
            within_radius([0, 0], [0, 0], -1)
