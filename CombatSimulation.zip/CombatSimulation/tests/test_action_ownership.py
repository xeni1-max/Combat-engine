"""Resource conflicts, independent function blocks and per-action payments."""
from decimal import Decimal as D
from types import SimpleNamespace
import unittest

from combat_sim.action_ownership import ActionConflict, ActionRegistry, ActionRequirements


class ActionRegistryTests(unittest.TestCase):
    def registry(self,requirements,current=0):
        state={'D':D(current)}
        registry=ActionRegistry(lambda action:requirements[action.id],lambda:state['D'])
        return registry,state

    def test_disjoint_resources_coexist_but_same_hand_conflicts_atomically(self):
        req={1:ActionRequirements({'hand:left'},{'upper_body'}),
             2:ActionRequirements({'locomotion'},{'lower_body'}),
             3:ActionRequirements({'hand:left'},{'upper_body'})}
        r,_=self.registry(req)
        for i in (1,2):r.acquire(SimpleNamespace(id=i))
        with self.assertRaises(ActionConflict):r.acquire(SimpleNamespace(id=3))
        self.assertEqual([a.id for a in r.all()],[1,2])
        self.assertEqual(r.owner('locomotion').id,2)

    def test_required_functions_are_not_exclusive_resources(self):
        req={i:ActionRequirements({f'hand:{i}'},{'upper_body'}) for i in (1,2)}
        r,_=self.registry(req)
        for i in (1,2):r.acquire(SimpleNamespace(id=i))
        affected=r.add_block('upper-freeze',{'upper_body'})
        self.assertEqual([a.id for a in affected],[1,2])

    def test_ambiguous_implicit_access_fails_and_selected_release_is_local(self):
        req={i:ActionRequirements({str(i)},set()) for i in (1,2)}
        r,_=self.registry(req)
        for i in (1,2):r.acquire(SimpleNamespace(id=i))
        with self.assertRaises(ActionConflict):r.selected_or_single()
        with r.select(1):
            self.assertEqual(r.release_selected().id,1)
            self.assertIsNone(r.selected_or_single())
            self.assertIsNone(r.release_selected())
        self.assertEqual(r.selected_or_single().id,2)

    def test_overlapping_block_sources_expire_independently(self):
        req={1:ActionRequirements({'hand'},{'upper_body'})}
        r,_=self.registry(req)
        r.add_block('ice-1',{'upper_body'});r.add_block('ice-2',{'upper_body'})
        r.remove_block('ice-1')
        with self.assertRaises(ActionConflict):r.acquire(SimpleNamespace(id=1))
        r.remove_block('ice-2');r.acquire(SimpleNamespace(id=1))

    def test_payment_bound_prevents_another_action_spending_promised_capacity(self):
        req={1:ActionRequirements({'hands'},{'upper_body'},D(2),'fire_end'),
             2:ActionRequirements({'legs'},{'lower_body'},D('1.5'),'takeoff')}
        r,state=self.registry(req,90)
        r.acquire(SimpleNamespace(id=1))
        self.assertEqual(r.reserved(),9)
        self.assertFalse(r.affordable(D('1.5')))
        with self.assertRaises(ActionConflict):r.acquire(SimpleNamespace(id=2))
        paid=r.payment(1,2,'fire_end');state['D']=D(paid.after.numerator)/paid.after.denominator
        self.assertEqual(state['D'],D('98.41'))
        self.assertEqual(r.reserved(),0)

    def test_each_phase_pays_once_and_wrong_action_phase_is_rejected(self):
        req={1:ActionRequirements({'hands'},{'upper_body'},D(2),'fire_end')}
        r,_=self.registry(req);r.acquire(SimpleNamespace(id=1))
        with self.assertRaises(ActionConflict):r.payment(1,2,'takeoff')
        self.assertTrue(r.payment(1,2,'fire_end').allowed)
        with self.assertRaises(ActionConflict):r.payment(1,2,'fire_end')

    def test_releasing_unpaid_action_releases_only_its_reservation(self):
        req={i:ActionRequirements({str(i)},set(),D(i),'pay') for i in (1,2)}
        r,_=self.registry(req)
        for i in (1,2):r.acquire(SimpleNamespace(id=i))
        self.assertEqual(r.reserved(),13)
        r.release(1)
        self.assertEqual(r.reserved(),9)
        self.assertEqual([a.id for a in r.all()],[2])

    def test_legal_large_cost_can_reserve_all_remaining_capacity(self):
        req={1:ActionRequirements({'body'},set(),D(10),'pay')}
        r,_=self.registry(req);r.acquire(SimpleNamespace(id=1))
        self.assertEqual(r.reserved(),100)
        self.assertTrue(r.payment(1,10,'pay').reached_maximum)

    def test_continuous_gain_can_invalidate_unpaid_phase_without_spending(self):
        req={1:ActionRequirements({'body'},set(),D(1),'pay')}
        r,state=self.registry(req,95);r.acquire(SimpleNamespace(id=1))
        state['D']=D(100)
        payment=r.payment(1,1,'pay')
        self.assertFalse(payment.allowed)
        self.assertEqual(payment.after,100)
        self.assertEqual(r.paid_phases[1],set())
        self.assertEqual(r.reserved(),4)

    def test_requirement_sets_do_not_alias_the_callers_mutable_containers(self):
        resources={'hand:left'};functions={'upper_body'}
        req=ActionRequirements(resources,functions)
        resources.add('locomotion');functions.clear()
        self.assertEqual(req.occupies,{'hand:left'})
        self.assertEqual(req.requires,{'upper_body'})
