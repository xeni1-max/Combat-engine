"""Labelled shared API probes of released, life-bound preparation modifiers.

All sources name an existing creative ability. Actual device delivery is tested
separately in test_impact_areas_combat; these probes isolate phase contracts.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import unittest

from combat_sim.models import UnsupportedMechanicError
from tests.test_equilibrium_combat import scene, rules, run
from tests.test_binding_combat import run as configured_run
from tests.test_mobile_combat import command, events
from tests.test_climb_combat import climb
from tests.test_binding_combat import control


def packet(w, target='B', source='A'):
    return dict(actor=source, ability='Ultimate', action_id=999,
        source_life_generation=w.fighters[source].life_generation,
        target=target, target_life_generation=w.fighters[target].life_generation)


def apply(w, target='B', value=250, duration=6000):
    return w.timed_gathering.create(packet(w, target), addition_ms=value, duration_ms=duration)


def fire_scene(horizon=1000, start=100):
    s = scene(horizon)
    s['action_selection']['B']['start_ms'] = start
    return s


def first_active(r, actor='B'):
    return D(events(r, 'active_started', actor)[0]['time_ms'])


class TimedGatheringCombatTests(unittest.TestCase):
    def setUp(self):
        ctx = localcontext(Context(prec=80)); ctx.__enter__()
        self.addCleanup(ctx.__exit__, None, None, None)

    def test_zero_base_gathering_receives_flat_bonus_without_creating_status(self):
        s = fire_scene(500)
        r = run(s, operations=((50, apply),))
        self.assertEqual(first_active(r), first_active(run(s))+250)
        commit = events(r, 'gathering_modifier_committed')[0]
        self.assertEqual(D(commit['added_ms']), 250)
        sample = next(e for e in events(r, 'gathering_started', 'B'))
        self.assertEqual(D(sample['disorientation_at_start']), 0)
        self.assertFalse(events(r, 'knockdown_applied'))

    def test_hit_during_unfinished_gathering_extends_it_and_invalidates_old_phase(self):
        s = fire_scene(1600)
        s['encounter']['participants']['B']['initial_state']['disorientation'] = 800
        baseline = first_active(run(s))
        r = run(s, operations=((200, apply),))
        self.assertEqual(first_active(r), baseline+250)
        self.assertEqual(len([e for e in events(r, 'active_started', 'B') if e['action_id'] == 1]), 1)

    def test_same_strength_refresh_cannot_repeatedly_delay_one_preparation(self):
        s = fire_scene(1600)
        s['encounter']['participants']['B']['initial_state']['disorientation'] = 800
        r = run(s, operations=((200, apply), (300, apply), (400, apply)))
        self.assertEqual(first_active(r), first_active(run(s))+250)
        self.assertEqual(len([e for e in events(r, 'gathering_modifier_committed') if e['action_id']==1]), 1)
        self.assertEqual(len(r['gathering_modifiers']), 3)

    def test_stronger_instance_adds_only_difference_then_weak_instance_has_own_expiry(self):
        s = fire_scene(2000)
        s['encounter']['participants']['B']['initial_state']['disorientation'] = 800
        r = run(s, operations=((150, lambda w: apply(w, value=250, duration=1000)),
            (200, lambda w: apply(w, value=400, duration=10)), (300, apply)))
        self.assertEqual(first_active(r), first_active(run(s))+400)
        self.assertEqual([D(e['added_ms']) for e in events(r, 'gathering_modifier_committed') if e['action_id']==1], [250,150])
        self.assertEqual(D(r['gathering_modifiers'][1]['ended_at_ms']), 210)

    def test_expiry_during_preparation_does_not_refund_committed_time(self):
        s = fire_scene(600)
        r = run(s, operations=((160, lambda w: apply(w, duration=20)),))
        self.assertEqual(first_active(r), first_active(run(s))+250)
        self.assertEqual(r['gathering_modifiers'][0]['end_reason'], 'expired')
        self.assertEqual(D(r['gathering_modifiers'][0]['ended_at_ms']), 180)

    def test_expiry_before_selection_and_exact_expiry_tie_do_not_affect_later_action(self):
        s = fire_scene(500)
        for duration in (40,50):
            r = run(s, operations=((50, lambda w, d=duration: apply(w, duration=d)),))
            self.assertEqual(first_active(r), first_active(run(s)))
            self.assertFalse(events(r, 'gathering_modifier_committed'))

    def test_reapplication_after_expiry_cannot_charge_same_gathering_again(self):
        s = fire_scene(1600)
        s['encounter']['participants']['B']['initial_state']['disorientation'] = 800
        r = run(s, operations=((150, lambda w: apply(w, duration=10)), (300, apply)))
        self.assertEqual(first_active(r), first_active(run(s))+250)
        self.assertEqual(len([e for e in events(r, 'gathering_modifier_committed') if e['action_id']==1]), 1)

    def test_due_active_and_existing_active_are_not_retroactively_delayed(self):
        s = fire_scene(500)
        baseline=first_active(run(s))
        for at in (baseline,baseline+1):
            r = run(s, operations=((at, apply),))
            self.assertEqual(first_active(r), baseline)
            self.assertFalse([e for e in events(r, 'gathering_modifier_committed') if e['action_id']==1])

    def test_parallel_weapon_and_jump_preparations_each_commit_once(self):
        s = fire_scene(1400)
        s['encounter']['participants']['B']['initial_state']['disorientation'] = 800
        command(s, 'B', 100, 'jump')
        r = run(s, operations=((200, apply), (300, apply)))
        commits = events(r, 'gathering_modifier_committed', 'B')
        self.assertEqual(len(commits), 2)
        self.assertEqual(len({e['action_id'] for e in commits}), 2)
        self.assertTrue(events(r, 'jump_takeoff', 'B'))

    def test_posture_zero_gathering_and_climb_use_shared_modifier(self):
        s = scene(700); command(s, 'B', 100, 'crouch')
        r = run(s, operations=((50, apply),))
        self.assertEqual(D(events(r, 'posture_requested', 'B')[0]['active_start_ms']),350)
        s = scene(900)
        s['encounter']['participants']['B']['position_m'] = ['4.6',0]
        climb(s, 'B', 100)
        r = run(s, operations=((50, apply),))
        self.assertEqual(D(events(r, 'climb_requested', 'B')[0]['active_start_ms']), 500)
        self.assertTrue(events(r, 'climb_active_started', 'B'))

    def test_active_only_walk_is_not_given_an_invented_gathering_phase(self):
        s = scene(500); command(s,'B',100,'walk')
        r = run(s, operations=((50, apply),))
        self.assertEqual(D(events(r, 'movement_active_started', 'B')[0]['time_ms']),100)
        self.assertFalse(events(r, 'gathering_modifier_committed'))

    def test_reload_preserves_active_start_payment_and_receives_preparation_bonus(self):
        s=fire_scene(1600)
        def empty(w):w.fighters['B'].ammo['1']=0
        baseline=run(s,operations=((50,empty),))
        r=run(s,operations=((50,empty),(60,apply)))
        first=lambda x:D(next(e for e in events(x,'active_started','B') if e['action_kind']=='reload')['time_ms'])
        self.assertEqual(first(r),first(baseline)+250)
        payment=next(e for e in events(r,'dyspnea_paid','B') if e['action_kind']=='reload')
        self.assertEqual(D(payment['time_ms']),first(r))
        self.assertEqual(payment['phase'],'active_start')

    def test_aim_uses_the_common_gathering_phase_and_unchanged_active_duration(self):
        s=scene(700);control(s,100,'B','aim_on')
        baseline=run(s)
        r=run(s,operations=((50,apply),))
        done=lambda x:D(events(x,'aim_toggled','B')[0]['time_ms'])
        self.assertEqual(done(r),done(baseline)+250)
        self.assertTrue(r['aim_states']['B']['aiming'])
        self.assertEqual(D(r['metrics']['B']['dyspnea_paid']),0)

    def test_fractional_modifier_strength_is_quantized_once_not_per_refresh(self):
        s=fire_scene(1500)
        s['encounter']['participants']['B']['initial_state']['disorientation']=800
        r=run(s,operations=((200,lambda w:apply(w,value='250.1')),
            (300,lambda w:apply(w,value='250.2')),(400,lambda w:apply(w,value='250.3'))))
        self.assertEqual(first_active(r),first_active(run(s))+251)

    def test_source_death_keeps_effect_recipient_death_ends_it_and_revive_is_clean(self):
        s = scene(500)
        def kill(w, name):
            w.fighters[name].hp=D(0); w.finish_team_deaths()
        def restore(w):
            self.assertTrue(w.life_cycles.revive('B', expected_generation=1, hp=1000, source='timed_modifier_api_probe'))
            self.assertEqual(w.timed_gathering.effective(w.fighters['B']),0)
        r = run(s, operations=((10,apply),(20,lambda w:kill(w,'A')),(30,lambda w:kill(w,'B')),(40,restore)))
        row = r['gathering_modifiers'][0]
        self.assertEqual(D(row['ended_at_ms']),30)
        self.assertEqual(row['end_reason'],'recipient_death')
        self.assertEqual(row['source_life_generation'],1)
        self.assertEqual(r['final_states']['B']['life_generation'],2)

    def test_released_old_source_life_can_apply_but_stale_recipient_cannot(self):
        s = scene(100)
        def probe(w):
            p=packet(w);w.fighters['A'].hp=D(0);w.finish_team_deaths()
            self.assertIsNotNone(w.timed_gathering.create(p,addition_ms=250,duration_ms=10))
            w.fighters['B'].hp=D(0);w.finish_team_deaths()
            self.assertIsNone(w.timed_gathering.create(p,addition_ms=250,duration_ms=10))
        run(s,operations=((10,probe),))

    def test_api_rejects_missing_rules_unknown_sources_lives_and_invalid_numbers(self):
        def check(w):
            for field,value in (('actor','missing'),('ability','new_ability'),('action_id',True),('source_life_generation',99)):
                p=packet(w);p[field]=value
                with self.assertRaises(ValueError):w.timed_gathering.create(p,addition_ms=250,duration_ms=10)
            for value in (-1,0,'NaN','Infinity',True):
                with self.assertRaises(ValueError):apply(w,value=value)
            for duration in (-1,0,'NaN','Infinity',True):
                with self.assertRaises(ValueError):apply(w,duration=duration)
        run(scene(100),operations=((10,check),))
        cfg=rules();cfg.pop('timed_gathering')
        with self.assertRaises(UnsupportedMechanicError):
            configured_run(scene(100),rules=cfg,operations=((10,apply),))
