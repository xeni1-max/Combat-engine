"""Controlled heat lifecycle and exact continuously accumulated damage."""
from copy import deepcopy
from decimal import localcontext, ROUND_FLOOR, ROUND_CEILING
from fractions import Fraction
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from combat_sim import heat_engine
from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario
from combat_sim.exact import ExactAmount, ExactRootProduct, amount_from_record
from combat_sim.models import UnsupportedMechanicError

ROOT = Path(__file__).resolve().parents[1]
CHARACTERS = json.loads((ROOT / 'data/characters.json').read_text())['characters']
SCENARIO = json.loads((ROOT / 'scenarios/1e1_heat_beam.json').read_text())


def root(coefficient, radicand=3):
    return ExactAmount.of(ExactRootProduct(Fraction(coefficient), Fraction(radicand)))


class HeatBeamTests(unittest.TestCase):
    def test_exact_damage_and_final_state(self):
        result = summarize(run_scenario(SCENARIO, CHARACTERS))
        expected = root(Fraction(10437, 4))
        self.assertEqual(amount_from_record(result['hp_damage']), expected)
        self.assertEqual(amount_from_record(result['final_hp']), 9080 - expected)
        self.assertEqual(result['final_armor']['exact'], '165')
        self.assertEqual(result['armor_lost']['exact'], '0')
        self.assertEqual(result['excess_hp_damage']['exact'], '0')
        self.assertEqual(result['impact_count'], 0)
        self.assertEqual(result['damage_interval_count'], 3)
        self.assertEqual(amount_from_record(result['damage_by_effect']['heat']), expected)

    def test_lifecycle_and_continuous_interval_boundaries(self):
        run = run_scenario(SCENARIO, CHARACTERS)
        expected = {'ability_started': 0, 'beam_started': 180, 'active_completed': 480,
                    'beam_ended': 3180, 'heat_expired': 4680}
        for kind, time in expected.items():
            self.assertEqual([e['time_ms'] for e in run['events'] if e['type'] == kind], [time])
        intervals = [e for e in run['events'] if e['type'] == 'continuous_damage_resolved']
        self.assertEqual([(e['interval_start_ms'], e['interval_end_ms']) for e in intervals],
                         [(180, 480), (480, 3180), (3180, 4680)])
        self.assertEqual([e['components']['heat']['phase'] for e in intervals],
                         ['exposure', 'exposure', 'residual_heat'])
        self.assertEqual(amount_from_record(intervals[0]['applied_hp_damage']), root(Fraction(3479, 20), Fraction(3, 10)))
        self.assertEqual(amount_from_record(intervals[-1]['applied_hp_damage']), root(Fraction(3479, 4)))
        self.assertEqual(run['run_until_ms'], 4680)
        self.assertEqual(run['active_continuous_effects_final'], [])
        self.assertFalse(any(e['type'] == 'status_applied' for e in run['events']))

    def test_current_armor_and_heat_resistance_affect_future_damage_only(self):
        # Instrumentation at an existing event boundary, not a public mixed-action feature.
        for change in ('armor', 'resistance', 'both'):
            characters = deepcopy(CHARACTERS)
            advance = heat_engine._advance_statuses
            def change_defenses(states, start, end, log):
                advance(states, start, end, log)
                if end == 480:
                    if change in ('armor', 'both'):
                        states['2E4'].armor = Fraction(0)
                    if change in ('resistance', 'both'):
                        characters['2E4']['resistances']['heat'] = 0
            with self.subTest(change=change), patch.object(heat_engine, '_advance_statuses', side_effect=change_defenses):
                run = run_scenario(SCENARIO, characters)
            expected = (root(2700) - root(Fraction(121, 20), Fraction(3, 10))) if change == 'both' else (
                root(Fraction(21237, 8)) - root(Fraction(121, 40), Fraction(3, 10)))
            self.assertEqual(amount_from_record(summarize(run)['hp_damage']), expected)
            first = next(e for e in run['events'] if e['type'] == 'continuous_damage_resolved')
            self.assertEqual(first['components']['heat']['inputs']['a_current'], '165')
            self.assertEqual(first['components']['heat']['inputs']['Rh_current'], '165')

    def test_multiple_explicit_recipients_have_independent_totals(self):
        scenario = deepcopy(SCENARIO)
        scenario['encounter']['initial_states']['3E5'] = {'hp': 11400, 'armor': 250, 'shield': 0}
        scenario['action_sequence'][0]['targets'].append('3E5')
        result = summarize(run_scenario(scenario, CHARACTERS))
        self.assertEqual(result['targets'], ['2E4', '3E5'])
        self.assertEqual(amount_from_record(result['per_target']['3E5']['hp_damage']), root(Fraction(7475, 3)))
        self.assertEqual(amount_from_record(result['hp_damage']), root(Fraction(10437, 4) + Fraction(7475, 3)))
        self.assertEqual(result['damage_interval_count'], 6)

    def test_actor_can_be_an_explicit_unshielded_recipient(self):
        scenario = deepcopy(SCENARIO)
        scenario['encounter']['initial_states']['1E1']['shield'] = 0
        scenario['action_sequence'][0]['targets'].append('1E1')
        run = run_scenario(scenario, CHARACTERS)
        result = summarize(run)['per_target']['1E1']
        self.assertEqual(amount_from_record(result['hp_damage']), root(2625))
        active_end = next(e for e in run['events'] if e['type'] == 'active_completed')
        self.assertEqual(amount_from_record(active_end['actor_state']['hp']), 8140 - root(175, Fraction(3, 10)))

    def test_explicit_empty_beam_is_valid(self):
        scenario = deepcopy(SCENARIO)
        scenario['action_sequence'][0]['targets'] = []
        scenario['encounter']['initial_states'].pop('2E4')
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(summarize(run)['hp_damage']['exact'], '0')
        self.assertEqual(summarize(run)['targets'], [])
        self.assertEqual(run['initial_states'], run['final_states'])

    def test_initial_disorientation_delays_gathering_without_changing_dose(self):
        scenario = deepcopy(SCENARIO)
        scenario['encounter']['initial_states']['1E1']['disorientation'] = 80
        run = run_scenario(scenario, CHARACTERS)
        self.assertEqual(next(e['time_ms'] for e in run['events'] if e['type'] == 'beam_started'), 260)
        self.assertEqual(run['run_until_ms'], 4760)
        self.assertEqual(amount_from_record(summarize(run)['hp_damage']), root(Fraction(10437, 4)))

    def test_replay_decimal_context_and_input_immutability(self):
        scenario, characters = deepcopy(SCENARIO), deepcopy(CHARACTERS)
        expected = run_scenario(scenario, characters)
        for precision, rounding in ((10, ROUND_FLOOR), (60, ROUND_CEILING)):
            with localcontext() as context:
                context.prec, context.rounding = precision, rounding
                self.assertEqual(run_scenario(scenario, characters), expected)
        self.assertEqual(scenario, SCENARIO)
        self.assertEqual(characters, CHARACTERS)
        times = [e['time_ms'] for e in expected['events']]
        self.assertEqual(times, sorted(times))

    def test_fractional_residual_expiry_is_exact(self):
        # Synthetic duration exercises arithmetic; the authoritative ability remains 3000 ms.
        characters = deepcopy(CHARACTERS)
        characters['1E1']['abilities']['4']['beam_duration_ms'] = 3001
        run = run_scenario(SCENARIO, characters)
        self.assertEqual(run['run_until_ms'], {'exact': '9363/2', 'decimal_approx': '4681.5'})

    def test_nonlethal_precheck_and_exact_boundary(self):
        scenario = deepcopy(SCENARIO)
        scenario['encounter']['initial_states']['2E4']['hp'] = 4519
        with self.assertRaisesRegex(UnsupportedMechanicError, 'nonlethal'):
            run_scenario(scenario, CHARACTERS)
        self.assertFalse(heat_engine._is_nonlethal(Fraction(10), ExactAmount.of(10)))
        self.assertFalse(heat_engine._is_nonlethal(Fraction(1), root(1)))
        self.assertTrue(heat_engine._is_nonlethal(Fraction(2), root(1)))

    def test_shields_instability_repeats_and_partial_runs_rejected(self):
        for kind in ('shield', 'instability', 'repeat', 'truncate', 'movement', 'exposure'):
            scenario = deepcopy(SCENARIO)
            if kind == 'shield': scenario['encounter']['initial_states']['2E4']['shield'] = 1
            if kind == 'instability': scenario['encounter']['initial_states']['1E1']['instability'] = 1
            if kind == 'repeat': scenario['action_sequence'].append(deepcopy(scenario['action_sequence'][0]))
            if kind == 'truncate': scenario['run_until_ms'] = 3180
            if kind == 'movement': scenario['encounter']['movement'] = 'running'
            if kind == 'exposure': scenario['action_sequence'][0]['exposure_confirmed'] = False
            with self.subTest(kind=kind), self.assertRaises((UnsupportedMechanicError, ValueError)):
                run_scenario(scenario, CHARACTERS)

    def test_missing_resistance_and_unsupported_rule_modes_rejected(self):
        for field, value in (('damage_payment', 'ticks'), ('defense_sampling', 'snapshot'),
                             ('armor_loss', 'yes'), ('status_effects', 'yes'), ('k', 3), ('missing_heat', None)):
            characters = deepcopy(CHARACTERS)
            if field == 'missing_heat': characters['2E4']['resistances'].pop('heat')
            else: characters['1E1']['abilities']['4'][field] = value
            with self.subTest(field=field), self.assertRaises(UnsupportedMechanicError):
                run_scenario(SCENARIO, characters)
