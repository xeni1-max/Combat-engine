"""Actual death-triggered ability delivery plus labelled lifecycle probes."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import json
import unittest

from combat_sim.analysis import summarize
from combat_sim.effect_models import EffectSource
from combat_sim.mechanics.damage_ledger import DamageContribution,DamageLedger
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter,run_shared_scenario
from tests.test_melee_venom_combat import scene as melee_scene
from tests.test_mobile_combat import BODY,MOVEMENT,PROFILES,TERRAIN,command,events,read
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
# These contracts intentionally specify the pre-healing revival milestone.
# Current healing/revival interactions have their own shared-world coverage.
CURRENT=read('tests/fixtures/combat_locomotion_revival_v1.json')
from tests.test_world_colliders_combat import wall


def scene(duration=5000):
    s=melee_scene(duration)
    s['encounter']['participants']['A']['initial_state']['hp']=600
    s['action_selection']['B']['start_ms']=0
    return s


def quiet(duration=5000):
    s=scene(duration)
    s['encounter']['participants']['A']['initial_state']['hp']=9080
    for policy in s['action_selection'].values():policy['start_ms']=1000000
    return s


def run(s,*,operations=(),profiles=PROFILES,effects=CURRENT,interval=None,precision=50):
    inputs=dict(body_definition=BODY,terrain_definition=TERRAIN,movement_definition=MOVEMENT,
        combat_locomotion_definition=effects,jump_definition=JUMP,climb_definition=CLIMB,
        projectile_physics_definition=PHYSICS)
    if not operations:
        return run_shared_scenario(s,profiles,precision=precision,sample_interval_ms=interval,**inputs)

    class Probe(SharedEncounter):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            for when,op in operations:self.push(when,'fixture_revival',op)

        def _process(self,kind,p):
            if kind!='fixture_revival':return super()._process(kind,p)
            actor=self.fighters[p.get('actor','A')]
            if p['op'] in ('kill','credit'):
                target=actor if p['op']=='kill' else self.fighters[p.get('target','B')]
                source=self.fighters['B'] if p['op']=='kill' else actor
                amount=target.hp if p['op']=='kill' else min(target.hp,D(p['amount']))
                c=DamageContribution(EffectSource(source.id,'fixture:hp',next(self.action_ids),
                    life_generation=source.life_generation),amount,'fixture',self.applied_damage.eligible(source.id,target.id))
                self.applied_damage._record(('fixture_revival',self.time,target.id),target.id,
                    self.time,self.time,(c,),amount)
                target.hp-=amount;target.metrics['direct_hp_damage_received']+=amount
                self.log('fixture_hp_probe',actor=source.id,target=target.id,amount=amount,
                    reason='explicit lifecycle probe, not an authored attack')
            elif p['op']=='restore':
                success=self.life_cycles.revive(actor.id,expected_generation=p.get('generation',1),
                    hp=p.get('hp',1000),source='fixture:independent_restoration')
                self.log('fixture_independent_restoration',actor=actor.id,success=success)
            elif p['op']=='spawn':self.collider_system.spawn_definition(p['definition'])
            elif p['op']=='remove':self.collider_system.remove(p['id'],reason='fixture_removal')
            elif p['op']=='pause_policy':self.choices[actor.id]['start_ms']=1000000
            elif p['op']=='stale_completion':
                payload={'attempt_id':p.get('id','revival:1')}
                self.log('fixture_stale_revival',live=self.revival.live(payload))
                self.push(self.time,'revival_completed',payload)
            else:raise ValueError('Unknown revival probe')

    with localcontext(Context(prec=precision)):
        return Probe(s,profiles,precision=precision,sample_interval_ms=interval,**inputs).run()


def history(r):return DamageLedger.from_record(r['applied_hp_history'])


class RevivalCombatTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=60));context.__enter__();self.addCleanup(context.__exit__,None,None,None)

    def conserved(self,r):
        ledger=history(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(life['initial_hp']) for life in lives),D(0))
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-ledger.amount(target=name)),D('1e-20'))
        return ledger

    def test_real_gun_death_automatically_revives_exactly_two_seconds_later(self):
        r=run(scene(2700));first=events(r,'character_died','A')[0]
        restored=events(r,'life_restored','A')[0];attempt=r['revival_attempts'][0]
        self.assertEqual(D(restored['time_ms'])-D(first['time_ms']),2000)
        self.assertEqual(D(first['time_ms']),D('511.708578'))
        self.assertEqual(attempt['status'],'completed')
        self.assertEqual(restored['source'],attempt['id'])
        self.assertEqual(restored['life_generation'],2)
        self.assertEqual(r['revival_states']['A']['charges_remaining'],2)
        self.assertEqual(r['metrics']['A']['revivals_completed'],1)
        self.conserved(r)

    def test_snapshot_uses_actual_eligible_hp_at_death_not_later_posthumous_damage(self):
        r=run(scene(2700));attempt=r['revival_attempts'][0];death=D(attempt['started_at_ms']);ledger=self.conserved(r)
        expected=ledger.amount(actor='A',end=death,window_ms=10000,eligible_only=True)
        self.assertEqual(D(attempt['eligible_damage_at_death']),expected)
        self.assertEqual(D(attempt['restoration_hp']),expected)
        self.assertGreater(ledger.amount(actor='A',end=D(attempt['due_at_ms']),window_ms=10000,eligible_only=True),expected)
        self.assertTrue(any(e.contribution.source.actor=='A' and e.contribution.source.life_generation==1
            and e.contribution.kind=='venom' and e.begin>=death for e in ledger.entries))

    def test_next_death_during_cooldown_does_not_wait_and_revive_later(self):
        r=run(scene(70000));self.assertEqual(len(r['revival_attempts']),1)
        self.assertEqual(len(events(r,'character_died','A')),2)
        skipped=events(r,'revival_not_started','A')
        self.assertEqual([e['reason'] for e in skipped],['cooldown'])
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(r['revival_states']['A']['cooldown']['state'],'ready')
        self.assertEqual(r['revival_states']['A']['charges_remaining'],2)
        self.conserved(r)

    def test_death_before_dealing_hp_or_shield_only_damage_preserves_charges(self):
        for hp,shield in ((1,0),(600,1000)):
            with self.subTest(hp=hp,shield=shield):
                s=scene(3000);s['encounter']['participants']['A']['initial_state']['hp']=hp
                s['encounter']['participants']['B']['initial_state']['shield']=shield
                r=run(s)
                self.assertFalse(r['revival_attempts'])
                self.assertEqual(events(r,'revival_not_started','A')[0]['reason'],'no_eligible_damage')
                self.assertEqual(r['revival_states']['A']['charges_remaining'],3)
                self.assertEqual(history(r).amount(actor='A',eligible_only=True),0)

    def test_friendly_hp_damage_does_not_fund_revival(self):
        s=melee_scene(3000)
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(team='A',position_m=['.65',-20])
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s,operations=[(600,{'op':'kill'})]);ledger=self.conserved(r)
        self.assertGreater(ledger.amount(actor='A'),0)
        self.assertEqual(ledger.amount(actor='A',eligible_only=True),0)
        self.assertFalse(r['revival_attempts'])

    def test_construct_hp_does_not_fund_revival(self):
        s=melee_scene(3000);s['initial_colliders']=[wall(x='.65',hp=1000,size=('.1',2,2),z=1)]
        r=run(s,operations=[(600,{'op':'kill'})])
        self.assertEqual(D(r['world_collider_states']['gate']['hp']),560)
        self.assertFalse(r['revival_attempts'])
        self.assertEqual(r['revival_states']['A']['charges_remaining'],3)

    def test_overkill_and_dead_recipient_bleed_cannot_inflate_restore_hp(self):
        s=melee_scene(3000);s['encounter']['participants']['B']['initial_state']['hp']=50
        r=run(s,operations=[(500,{'op':'kill'})])
        self.assertEqual(D(r['revival_attempts'][0]['restoration_hp']),50)
        self.assertEqual(D(events(r,'life_restored','A')[0]['hp']),50)
        self.conserved(r)

    def test_rolling_death_window_excludes_old_boundary_and_initial_deficit(self):
        s=quiet(12300);s['encounter']['participants']['A']['initial_state']['hp']=100
        ops=[(100,{'op':'credit','amount':100}),(200,{'op':'credit','amount':200}),
            (201,{'op':'credit','amount':300}),(10200,{'op':'kill'})]
        r=run(s,operations=ops)
        self.assertEqual(D(r['revival_attempts'][0]['eligible_damage_at_death']),300)
        self.assertEqual(D(events(r,'life_restored','A')[0]['hp']),300)
        self.conserved(r)

    def test_restoration_hp_is_capped_at_profile_maximum(self):
        s=quiet(2300);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C']['position_m']=[50,-20]
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s,operations=[(10,{'op':'credit','amount':5000}),
            (11,{'op':'credit','amount':5000,'target':'C'}),(20,{'op':'kill'})])
        self.assertEqual(D(r['revival_attempts'][0]['eligible_damage_at_death']),10000)
        self.assertEqual(D(events(r,'life_restored','A')[0]['hp']),9080)
        self.conserved(r)

    def test_three_finite_charges_and_exact_65000_ms_ready_boundary(self):
        ops=[]
        for death,credit in ((200,100),(65200,200),(130200,300),(195200,400)):
            ops.extend([(death-1,{'op':'credit','amount':credit}),(death,{'op':'kill'})])
        r=run(quiet(197300),operations=ops)
        self.assertEqual(len(r['revival_attempts']),3)
        self.assertEqual([D(a['restoration_hp']) for a in r['revival_attempts']],[100,200,300])
        self.assertEqual([D(a['started_at_ms']) for a in r['revival_attempts']],[200,65200,130200])
        self.assertEqual(r['revival_states']['A']['charges_remaining'],0)
        self.assertEqual(events(r,'revival_not_started','A')[-1]['reason'],'no_charges')
        self.assertEqual(r['final_states']['A']['life_generation'],4)
        self.conserved(r)

    def test_ordinary_weapon_clock_stops_while_revival_clock_progresses_during_death(self):
        baseline=run(scene(1000));death=D(events(baseline,'character_died','A')[0]['time_ms'])
        r=run(scene(1500));clocks=r['final_states']['A']['cooldown_clocks']
        self.assertEqual(clocks['1']['state'],'stopped')
        self.assertEqual(clocks['5']['state'],'running')
        self.assertEqual(D(clocks['5']['remaining_work_ms']),65000-(1500-death))
        self.assertEqual(D(clocks['5']['ready_at_ms']),death+65000)

    def test_automatic_revival_pays_no_dyspnea_and_retains_death_resources(self):
        r=run(scene(2700));dead=events(r,'character_died','A')[0]['state']
        restored=events(r,'life_restored','A')[0]['state']
        for key in ('armor','shield','ammo','hands_m','dyspnea','disorientation','instability'):
            self.assertEqual(restored[key],dead[key],key)
        self.assertEqual(D(events(r,'revival_started','A')[0]['dyspnea_cost']),0)
        self.assertTrue(all(D(e['time_ms'])!=D(events(r,'life_restored','A')[0]['time_ms'])
            for e in events(r,'dyspnea_paid','A')))
        self.assertEqual(restored['owned_actions'],[])

    def test_replacement_item_survives_death_and_new_life_starts_a_new_grab(self):
        r=run(scene(2900));birth=D(events(r,'life_restored','A')[0]['time_ms'])
        self.assertEqual(D(next(e for e in r['events'] if e['type']=='replacement_blade_available')['time_ms']),891)
        grabs=events(r,'blade_grab_requested','A')
        self.assertTrue(any(D(e['time_ms'])==birth and e['life_generation']==2 for e in grabs))
        equipped=events(r,'blade_equipped','A')[0]
        self.assertEqual(equipped['life_generation'],2)
        self.assertEqual(equipped['blade']['source_life_generation'],1)

    def test_surviving_heat_beam_reenters_the_restored_life_with_fresh_memory(self):
        s=scene(4500);s['encounter']['participants']['B']['character']='1E1'
        s['action_selection']['B']['abilities']=['4']
        s['encounter']['participants']['A']['initial_state']['hp']=100
        r=run(s);self.assertTrue(events(r,'life_restored','A'))
        tracks=[e for e in r['effect_instances'] if e['kind']=='heat' and e['target']=='A']
        self.assertTrue(any(e['target_life_generation']==1 and e['status']=='ended' for e in tracks))
        self.assertTrue(any(e['target_life_generation']==2 for e in tracks))
        born=events(r,'life_restored','A')[0]['time_ms']
        self.assertTrue(any(e['type']=='heat_exposure_entered' and e.get('target')=='A'
            and e['time_ms']==born and D(e['q_seconds'])==0 for e in r['events']))
        self.conserved(r)

    def test_live_pause_field_leaves_attempt_time_alone_and_reconciles_cooldown_at_birth(self):
        s=scene(3000);s['encounter']['participants']['A']['initial_state']['hp']=300
        s['action_selection']['B']['abilities']=['2','1'];r=run(s)
        attempt=r['revival_attempts'][0];born=D(events(r,'life_restored','A')[0]['time_ms'])
        volume=r['cooldown_pause_volumes'][0]
        self.assertLess(born,D(volume['expiry']))
        self.assertEqual(born-D(attempt['started_at_ms']),2000)
        clock=r['revival_states']['A']['cooldown']
        self.assertEqual(clock['state'],'paused')
        self.assertEqual(D(clock['remaining_work_ms']),63000)
        self.assertEqual(clock['pause_sources'],[volume['id']])
        self.conserved(r)

    def test_airborne_death_freezes_pose_then_revive_falls_without_restarting_jump(self):
        s=melee_scene(3500);command(s,'A',1000,'jump')
        r=run(s,operations=[(1150,{'op':'kill'}),(1200,{'op':'pause_policy'})])
        dead=events(r,'character_died','A')[0]['state'];born=events(r,'life_restored','A')[0]['state']
        self.assertEqual(born['body_origin_m'],dead['body_origin_m'])
        self.assertGreater(D(born['body_origin_m'][2]),D('.875'))
        self.assertFalse(born['locomotion']['grounded'])
        self.assertEqual(len(events(r,'jump_takeoff','A')),1)
        self.assertEqual(r['metrics']['A']['jumps_started'],1)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])
        self.conserved(r)

    def test_occupied_solid_completion_fails_once_and_does_not_retry_after_removal(self):
        obstacle=wall('corpse_cover',x=0,hp=None,size=('.7','.7',2),z=1)
        r=run(scene(4000),operations=[(1000,{'op':'spawn','definition':obstacle}),
            (3000,{'op':'remove','id':'corpse_cover'})])
        self.assertFalse(events(r,'life_restored','A'))
        self.assertEqual(r['revival_attempts'][0]['status'],'failed')
        self.assertEqual(r['revival_attempts'][0]['end_reason'],'occupied_body_pose')
        self.assertEqual(r['metrics']['A']['revivals_blocked'],1)
        self.assertEqual(r['revival_states']['A']['charges_remaining'],2)
        self.assertFalse(r['final_states']['A']['alive'])

    def test_living_body_occupancy_blocks_completion_while_dead_bodies_do_not_collide(self):
        s=scene(3000);s['encounter']['participants']['B']['movement_direction']=[-1,0]
        command(s,'B',1000,'walk');command(s,'B',1550,'stop');r=run(s)
        self.assertEqual(r['revival_attempts'][0]['status'],'failed')
        self.assertEqual(r['revival_attempts'][0]['end_reason'],'occupied_body_pose')
        self.assertFalse(events(r,'body_contact'))

    def test_obstacle_expiring_at_completion_does_not_block_the_new_life(self):
        baseline=run(scene(2700));due=D(baseline['revival_attempts'][0]['due_at_ms'])
        obstacle=wall('corpse_cover',x=0,hp=None,duration=due-1000,size=('.7','.7',2),z=1)
        r=run(scene(2700),operations=[(1000,{'op':'spawn','definition':obstacle})])
        self.assertEqual(r['revival_attempts'][0]['status'],'completed')
        self.assertEqual(D(events(r,'life_restored','A')[0]['time_ms']),due)

    def test_independent_restoration_supersedes_the_old_attempt_without_refunding_it(self):
        r=run(scene(3000),operations=[(1000,{'op':'restore'}),(1100,{'op':'kill'}),
            (2600,{'op':'stale_completion'})])
        self.assertEqual(r['revival_attempts'][0]['status'],'superseded')
        self.assertEqual(r['revival_states']['A']['charges_remaining'],2)
        self.assertEqual(r['metrics']['A']['revivals_superseded'],1)
        self.assertFalse(events(r,'fixture_stale_revival')[0]['live'])
        self.assertEqual(len(events(r,'life_restored','A')),1)
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertFalse(r['final_states']['A']['alive'])
        self.conserved(r)

    def test_horizon_keeps_a_generation_bound_pending_attempt_and_clock(self):
        r=run(scene(1000));pending=[e for e in r['pending_events'] if e['type']=='revival_completed']
        self.assertEqual(len(pending),1)
        self.assertEqual(pending[0]['details']['attempt_id'],r['revival_attempts'][0]['id'])
        self.assertEqual(r['revival_attempts'][0]['life_generation'],1)
        self.assertEqual(r['revival_attempts'][0]['status'],'active')

    def test_precision_observations_and_actor_order_preserve_real_revive_outcomes(self):
        s=scene();baseline=run(s)
        for precision,interval in ((50,37),(80,113)):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,precision=precision,interval=interval)
            for kind in ('character_died','life_restored','revival_completed'):
                a,b=events(r,kind,'A'),events(baseline,kind,'A')
                self.assertEqual(len(a),len(b))
                for first,second in zip(a,b):self.assertLess(abs(D(first['time_ms'])-D(second['time_ms'])),D('1e-20'))
            self.assertEqual(r['revival_states']['A']['charges_remaining'],2)
            for name in r['final_states']:
                self.assertLess(abs(D(r['final_states'][name]['hp'])-D(baseline['final_states'][name]['hp'])),D('1e-20'))
            self.conserved(r)

    def test_summary_and_public_result_expose_actual_lives_attempts_and_charges(self):
        r=run(scene());summary=summarize(r)
        self.assertEqual(summary['revival']['attempts'],r['revival_attempts'])
        self.assertEqual(summary['revival']['states'],r['revival_states'])
        self.assertAlmostEqual(D(summary['participants']['A']['hp_damage_received']),history(r).amount(target='A'),places=30)
        self.assertEqual(json.loads(json.dumps(r)),r)

    def test_historical_opt_out_keeps_terminal_death_and_omits_revival_output(self):
        rules=deepcopy(CURRENT);rules.pop('death_revival')
        r=run(scene(),effects=rules)
        self.assertEqual(r['final_states']['A']['life_generation'],1)
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertNotIn('revival_attempts',r)
        self.assertNotIn('5',r['final_states']['A']['cooldown_clocks'])

    def test_invalid_mode_or_missing_life_dependency_rejects_before_running(self):
        for change in ({'mode':'unknown'},None):
            rules=deepcopy(CURRENT)
            if change is None:rules.pop('life_cycles')
            else:rules['death_revival']=change
            if change is None:rules.pop('melee')
            with self.assertRaisesRegex(UnsupportedMechanicError,'Death revival'):run(scene(),effects=rules)

    def test_invalid_source_parameters_and_unsupported_policies_are_rejected(self):
        for key,value,error in (('charges',True,ValueError),('charges',0,ValueError),('active_ms',0,ValueError),
                ('cooldown_ms','NaN',ValueError),('hp_snapshot','at_completion',UnsupportedMechanicError),
                ('dyspnea',{'kind':'action','base_value':1},UnsupportedMechanicError)):
            with self.subTest(key=key,value=value):
                profiles=deepcopy(PROFILES);profiles['2E4']['automatic_abilities']['5'][key]=value
                with self.assertRaises(error):run(scene(),profiles=profiles)


if __name__=='__main__':unittest.main()
