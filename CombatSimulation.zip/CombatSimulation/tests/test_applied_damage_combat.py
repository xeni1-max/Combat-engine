"""Actual shared damage commits produce conserved, source-attributed HP windows."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE
from combat_sim.models import UnsupportedMechanicError
from tests.test_mobile_combat import command,events,scenario
from tests.test_cooldown_fields_combat import CURRENT,marking_scene,run
from tests.test_spatial_heat_combat import beam_scene
from tests.test_thermal_recovery_combat import coupled_scene
from tests.test_world_colliders_combat import wall


def gun_scene(horizon=1000):
    s=scenario(horizon,fire_at=0);s['scope']=dict(GRAVITY_MOBILE_SCOPE)
    s['action_selection']['A']['reload_when_empty']=False
    return s


def heat_scene(horizon=5000):
    s=beam_scene(horizon);s['scope']=dict(GRAVITY_MOBILE_SCOPE)
    return s


def fluid_scene(horizon=26000):
    s=coupled_scene(horizon);s['scope']=dict(GRAVITY_MOBILE_SCOPE)
    return s


def history(result):return DamageLedger.from_record(result['applied_hp_history'])


class AppliedDamageCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def assert_conserved(self,r):
        ledger=history(r)
        for name,final in r['final_states'].items():
            actual=D(r['initial_states'][name]['hp'])-D(final['hp'])
            self.assertAlmostEqual(ledger.amount(target=name),actual,places=20)
        self.assertAlmostEqual(sum((ledger.amount(actor=a) for a in r['final_states']),D(0)),ledger.amount(),places=20)
        return ledger

    def test_real_gun_and_bleed_keep_projectile_action_and_effect_attribution(self):
        r=run(gun_scene());ledger=self.assert_conserved(r)
        points=[e for e in ledger.entries if e.contribution.kind=='slash']
        bleeds=[e for e in ledger.entries if e.contribution.kind=='bleeding']
        self.assertTrue(points);self.assertTrue(bleeds)
        self.assertTrue(all(e.contribution.source.actor=='A' and e.contribution.source.ability=='1' for e in ledger.entries))
        self.assertTrue(all(e.contribution.effect_id and e.contribution.source.projectile_id for e in bleeds))
        self.assertLessEqual({e.contribution.source.projectile_id for e in bleeds},
                             {e.contribution.source.projectile_id for e in points})

    def test_shield_only_hit_provides_no_credit(self):
        s=gun_scene(200);s['encounter']['participants']['B']['initial_state']['shield']=4000
        r=run(s);ledger=self.assert_conserved(r)
        self.assertGreater(D(r['metrics']['B']['shield_damage_received']),0)
        self.assertEqual(ledger.amount(actor='A',eligible_only=True),0)

    def test_lethal_point_credits_only_actual_hp_and_no_post_death_bleed(self):
        s=gun_scene();s['encounter']['participants']['B']['initial_state']['hp']=1
        r=run(s);ledger=self.assert_conserved(r)
        self.assertEqual(ledger.amount(actor='A'),1)
        self.assertEqual(len(ledger.entries),1)
        self.assertGreater(ledger.entries[0].contribution.nominal_hp,1)

    def test_real_simultaneous_guns_share_one_lethal_hp_budget(self):
        s=gun_scene();s['encounter']['participants']['A']['position_m']=[0,-25]
        s['encounter']['participants']['B']['initial_state']['hp']=100
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[0,-15]
        s['action_selection']['C']=deepcopy(s['action_selection']['A'])
        r=run(s);ledger=self.assert_conserved(r)
        batch=next(e for e in events(r,'impact_batch_resolved') if e['target']=='B')
        self.assertEqual(len(batch['hits']),2)
        self.assertEqual(ledger.amount(actor='A'),50);self.assertEqual(ledger.amount(actor='C'),50)

    def test_friendly_fire_is_real_but_cannot_generate_recovery_credit(self):
        s=gun_scene();s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[15,-20]
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s);ledger=self.assert_conserved(r)
        self.assertGreater(ledger.amount(actor='A'),0)
        self.assertEqual(ledger.amount(actor='A',eligible_only=True),0)
        self.assertTrue(all(e.target=='C' and not e.contribution.eligible for e in ledger.entries))

    def test_self_heat_is_recorded_separately_from_eligible_enemy_damage(self):
        s=heat_scene();s['encounter']['participants']['B']['position_m']=[6,-20]
        r=run(s);ledger=self.assert_conserved(r)
        self.assertGreater(ledger.amount(target='A'),0)
        self.assertAlmostEqual(ledger.amount(actor='A',eligible_only=True),ledger.amount(target='B'),places=20)
        self.assertGreater(ledger.amount(actor='A'),ledger.amount(actor='A',eligible_only=True))

    def test_released_heat_keeps_credit_after_caster_dies(self):
        s=heat_scene();s['encounter']['participants']['A']['initial_state']['hp']=1
        s['action_selection']['B']['start_ms']=500
        r=run(s);ledger=self.assert_conserved(r)
        died=D(events(r,'character_died','A')[0]['time_ms'])
        self.assertGreater(ledger.amount(actor='A'),ledger.amount(actor='A',end=died))
        self.assertTrue(any(e.contribution.source.actor=='A' and e.end>died for e in ledger.entries))

    def test_continuous_overkill_shares_actual_loss_across_independent_beams(self):
        s=heat_scene(1000);s['encounter']['participants']['B']['initial_state']['hp']=100
        s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C']['position_m']=[0,-25]
        s['action_selection']['C']=deepcopy(s['action_selection']['A'])
        r=run(s);ledger=self.assert_conserved(r)
        self.assertFalse(r['final_states']['B']['alive'])
        self.assertAlmostEqual(ledger.amount(actor='A'),50,places=20)
        self.assertAlmostEqual(ledger.amount(actor='C'),50,places=20)

    def test_rolling_bleed_windows_match_independent_integral_from_actual_deliveries(self):
        r=run(gun_scene(12000));ledger=self.assert_conserved(r)
        for end,width in ((D(12000),D(10000)),(D(10537),D(1333))):
            lower=end-width;expected=D(0)
            for event in events(r,'impact_batch_resolved'):
                if event['target']=='B' and lower<D(event['time_ms'])<=end:expected+=D(event['applied_hp_damage'])
            for event in events(r,'bleeding_started'):
                effect=event['effect']
                if effect['target']!='B':continue
                start=D(effect['start']);a=max(lower,start);b=min(end,start+8000)
                if b<=a:continue
                t0,t1=(a-start)/1000,(b-start)/1000
                expected+=D(effect['basis_y'])*(8*(t1-t0)-(t1*t1-t0*t0)/2)/320
            self.assertAlmostEqual(ledger.amount(actor='A',end=end,window_ms=width),expected,places=20)

    def test_nonlinear_heat_window_matches_independent_hp_prefix_runs(self):
        r=run(fluid_scene());ledger=self.assert_conserved(r)
        self.assertEqual(D(r['final_states']['B']['shield']),1928)
        self.assertTrue(any(c['curve_kind']=='piecewise_hp_dose_v1' for c in r['applied_hp_history']['curves'].values()))
        before=run(fluid_scene(20037));after=run(fluid_scene(21037))
        actual=D(before['final_states']['B']['hp'])-D(after['final_states']['B']['hp'])
        self.assertAlmostEqual(ledger.amount(actor='A',end=21037,window_ms=1000),actual,places=8)

    def test_paused_cooldown_does_not_pause_continuous_damage_or_history_age(self):
        s=marking_scene(5000,gun_start=1000);s['encounter']['participants']['A']['initial_state']['shield']=0
        r=run(s);ledger=self.assert_conserved(r)
        self.assertGreater(ledger.amount(actor='B',end=3000,window_ms=1000),0)
        self.assertTrue(all(e.contribution.kind=='bleeding' for e in ledger.entries if 2000<e.end<=3000))
        self.assertTrue(any(p['states']['B']['cooldown_clocks']['1']['state']=='paused' for p in r['curve'] if p['time_ms']=='3000'))

    def test_construct_loss_never_appears_as_character_credit(self):
        s=gun_scene();s['initial_colliders']=[wall(hp=500)]
        r=run(s);ledger=self.assert_conserved(r)
        self.assertEqual(D(r['world_collider_states']['gate']['hp']),0)
        self.assertTrue(all(e.target in r['final_states'] for e in ledger.entries))
        self.assertAlmostEqual(ledger.amount(actor='A'),D(r['initial_states']['B']['hp'])-D(r['final_states']['B']['hp']),places=20)

    def test_observation_precision_and_actor_order_preserve_credit_windows(self):
        s=fluid_scene();baseline=run(s);expected=history(baseline)
        for precision,interval in ((50,113),(80,37)):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            result=run(other,precision=precision,interval=interval);actual=self.assert_conserved(result)
            for width in (8000,10000):
                self.assertAlmostEqual(actual.amount(actor='A',window_ms=width),expected.amount(actor='A',window_ms=width),places=8)

    def test_legacy_mode_has_identical_physical_results_and_no_credit_claim(self):
        # Compare the history toggle on the earlier no-life ruleset; current
        # life restoration intentionally depends on attributed HP history.
        s=gun_scene();config=deepcopy(CURRENT);config.pop('binding_effects',None);config.pop('grapple_break',None);config.pop('grapple_casts',None);config.pop('controlled_damage',None);config.pop('continuous_effort',None);config.pop('grapple_links',None);config.pop('spatial_transitions',None);config.pop('attack_modifiers',None);config.pop('combat_reactions',None);config.pop('blocking',None);config.pop('hp_recovery',None);config.pop('death_revival',None);config.pop('melee',None);config.pop('life_cycles',None)
        current=run(s,effects=config);config.pop('damage_ledger')
        legacy=run(s,effects=config)
        self.assertNotIn('applied_hp_history',legacy)
        self.assertEqual(current['final_states'],legacy['final_states'])
        self.assertEqual(current['metrics'],legacy['metrics'])

    def test_unknown_history_mode_rejects_before_combat(self):
        config=deepcopy(CURRENT);config['damage_ledger']={'mode':'unsupported'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'Applied HP history'):run(gun_scene(),effects=config)


if __name__=='__main__':unittest.main()
