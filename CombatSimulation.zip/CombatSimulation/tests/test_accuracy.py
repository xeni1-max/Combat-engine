"""Independent geometry/unit checks for actual released spread cones."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.accuracy import disk_sample,dispersed_velocity,spread_radius


class AccuracyTests(unittest.TestCase):
    def test_authored_centimetres_per_metre_convert_to_cm_per_100m(self):
        self.assertEqual(spread_radius('2.4',10,115),D('127.4'))
        self.assertEqual(spread_radius('2.4',10,115,running=True),D('152.88'))

    def test_aim_removes_only_the_source_unaimed_increment(self):
        self.assertEqual(spread_radius('2.4',0,115),D('117.4'))
        self.assertEqual(spread_radius('1.7',10,0),D('11.7'))

    def test_zero_cone_preserves_the_exact_original_velocity(self):
        self.assertEqual(dispersed_velocity((3,4,0),0,(1,0)),(3,4,0))

    def test_disk_edge_crosses_the_100m_plane_at_the_requested_radius(self):
        with localcontext(Context(prec=80)):
            v=dispersed_velocity((900,0,0),100,(1,0),precision=80)
            self.assertLess(abs(sum(x*x for x in v).sqrt()-900),D('1e-70'))
            self.assertLess(abs(v[1]/v[0]*100+1),D('1e-70'))
            self.assertEqual(v[2],0)

    def test_vertical_and_general_shots_preserve_speed_and_cone_angle(self):
        with localcontext(Context(prec=80)):
            for original in ((0,0,900),(0,0,-900),(3,4,5),(-3,2,5)):
                v=dispersed_velocity(original,500,(D('.6'),D('.8')),precision=80)
                speed=sum(D(x)**2 for x in original).sqrt()
                dot=sum(D(x)*y for x,y in zip(original,v))/speed
                perpendicular=(sum(x*x for x in v)-dot*dot).sqrt()
                self.assertLess(abs(perpendicular/dot-D('.05')),D('1e-70'))
                self.assertLess(abs(sum(x*x for x in v).sqrt()-speed),D('1e-70'))

    def test_hash_sample_uses_stable_shot_identity_without_global_state(self):
        key=(7,'A','1E2',1,'1',4);a=disk_sample(*key)
        disk_sample(9,'unrelated','3E5',1,'2',1)
        self.assertEqual(a,disk_sample(*key));self.assertNotEqual(a,disk_sample(8,*key[1:]))
        self.assertNotEqual(a,disk_sample(7,'A','1E2',2,'1',4))

    def test_sample_distribution_has_area_uniform_second_moment(self):
        values=[disk_sample(0,'A','1E2',1,'1',i+1) for i in range(1024)]
        mean=lambda rows:sum(rows,D(0))/len(values)
        self.assertLess(abs(mean([x for x,y in values])),D('.04'))
        self.assertLess(abs(mean([y for x,y in values])),D('.04'))
        self.assertLess(abs(mean([x*x+y*y for x,y in values])-D('.5')),D('.04'))

    def test_sampler_and_owned_geometry_do_not_use_the_callers_precision(self):
        with localcontext(Context(prec=8)):a=disk_sample(3,'A','1E2',1,'1',1);v=dispersed_velocity((900,0,0),25,a)
        with localcontext(Context(prec=80)):self.assertEqual(a,disk_sample(3,'A','1E2',1,'1',1));self.assertEqual(v,dispersed_velocity((900,0,0),25,a))

    def test_invalid_keys_and_nonphysical_inputs_reject(self):
        for seed in (-1,True,1.2):
            with self.subTest(seed=seed),self.assertRaises(ValueError):disk_sample(seed,'A','1E2',1,'1',1)
        for vector,radius,sample in (((0,0,0),1,(0,0)),((900,0,0),-1,(0,0)),((900,0,0),1,(1,1)),((900,0,0),'NaN',(0,0))):
            with self.subTest(vector=vector,radius=radius),self.assertRaises(ValueError):dispersed_velocity(vector,radius,sample)
