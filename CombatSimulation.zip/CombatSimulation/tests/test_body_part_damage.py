"""Actual anatomical contact chooses a frozen output, independently of intent."""
import unittest

from combat_sim.mechanics.body_part_damage import contact_component,part_overrides


class BodyPartDamageTests(unittest.TestCase):
    def packet(self,**kw):
        return dict(component='projectile',collision_kind='body',hit_parts=['head'],**kw)

    def test_named_parts_are_validated_and_canonicalized(self):
        self.assertEqual(part_overrides({'torso':600,'head':1500},('head','torso')),(('head',1500),('torso',600)))

    def test_invalid_or_nonphysical_overrides_reject(self):
        for value in ([],{'fin':1500},{'head':-1},{'head':True},{'head':'NaN'},{'head':'Infinity'}):
            with self.subTest(value=value),self.assertRaises(ValueError):part_overrides(value,('head','torso'))

    def test_actual_head_selects_its_frozen_component(self):
        self.assertEqual(contact_component(self.packet(),('projectile','projectile:head')),'projectile:head')

    def test_body_contact_does_not_inherit_aim_intent(self):
        packet=self.packet();packet.update(hit_parts=['torso'],aim_part='head',aim_target='B')
        self.assertEqual(contact_component(packet,('projectile','projectile:head')),'projectile')

    def test_nonanatomical_intercepts_use_default_output(self):
        for extra in ({'collision_kind':'terrain'},{'block_layer_id':'block:1'}):
            packet=self.packet();packet.update(extra)
            self.assertEqual(contact_component(packet,('projectile','projectile:head')),'projectile')

    def test_ties_use_the_existing_lexical_part_identity(self):
        packet=self.packet();packet['hit_parts']=['torso','head']
        self.assertEqual(contact_component(packet,('projectile','projectile:head')),'projectile:head')
        packet['hit_parts'].reverse()
        self.assertEqual(contact_component(packet,('projectile','projectile:head')),'projectile:head')

    def test_a_missing_anatomical_receipt_is_an_error(self):
        for parts in (None,[],[''],[3],'head'):
            packet=self.packet();packet['hit_parts']=parts
            with self.subTest(parts=parts),self.assertRaises(ValueError):contact_component(packet,('projectile','projectile:head'))

    def test_area_components_keep_their_separate_power(self):
        packet=self.packet();packet['component']='delayed_blast'
        self.assertEqual(contact_component(packet,('delayed_blast','projectile:head')),'delayed_blast')
