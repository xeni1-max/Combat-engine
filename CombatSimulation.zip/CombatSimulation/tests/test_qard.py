import unittest
from fractions import Fraction

from combat_sim.mechanics.qard import post_mitigation_damage, raw_post_mitigation_damage


class InstantQardTests(unittest.TestCase):
    def test_documented_1e1_hit_against_2e4_defenses(self):
        # (450² - (165/2 + 82.5)²)/450 = 389.5
        self.assertEqual(post_mitigation_damage(450, 165, Fraction(165, 2)), Fraction(779, 2))

    def test_resistance_and_half_armor_are_added_before_squaring(self):
        self.assertEqual(post_mitigation_damage(10, 8, 2), Fraction(32, 5))

    def test_exact_boundary_and_excess_defense_floor_at_zero(self):
        self.assertEqual(post_mitigation_damage(100, 100, 50), 0)
        self.assertEqual(raw_post_mitigation_damage(100, 100, 100), -125)
        self.assertEqual(post_mitigation_damage(100, 100, 100), 0)

    def test_zero_defenses_and_large_values(self):
        self.assertEqual(post_mitigation_damage(10**12, 0, 0), 10**12)

    def test_zero_denominator_and_negative_inputs_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "dq=0"):
            post_mitigation_damage(0, 0, 0)
        for values in ((-1, 0, 0), (1, -1, 0), (1, 0, -1)):
            with self.subTest(values=values), self.assertRaisesRegex(ValueError, "nonnegative"):
                post_mitigation_damage(*values)
