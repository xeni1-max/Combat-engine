"""Exact face/gap witnesses for standing and changing body proxies."""
from fractions import Fraction as F
import unittest

from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.support_geometry import vertical_witnesses,first_overlap_departure,horizontal_gap_polynomials,grazing_vertical_departure

EPS=F(1,10**20)


class SupportGeometryTests(unittest.TestCase):
    def test_only_positive_area_underside_top_face_contacts_support(self):
        a=Cuboid('foot',(0,0,F(5,2)),(1,1,1));b=Cuboid('head',(0,0,1),(1,1,2))
        rows=vertical_witnesses({'B':(b,),'A':(a,)},distance_epsilon=EPS)
        self.assertEqual([(r.upper,r.lower,r.upper_part,r.lower_part) for r in rows],[('A','B','foot','head')])
        edge=Cuboid('edge',(1,0,F(5,2)),(1,1,1))
        self.assertEqual(vertical_witnesses({'B':(b,),'A':(edge,)},distance_epsilon=EPS),())

    def test_witness_order_and_compound_parts_are_stable(self):
        parts=(Cuboid('left',(-F(1,4),0,F(5,2)),(F(1,2),1,1)),Cuboid('right',(F(1,4),0,F(5,2)),(F(1,2),1,1)))
        b=(Cuboid('top',(0,0,1),(1,1,2)),)
        self.assertEqual(vertical_witnesses({'A':parts,'B':b},distance_epsilon=EPS),
            vertical_witnesses({'B':b,'A':tuple(reversed(parts))},distance_epsilon=EPS))

    def test_stationary_or_entering_overlap_does_not_create_false_departure(self):
        self.assertIsNone(first_overlap_departure(((1,0,0),(2,1,0)),3,distance_epsilon=EPS))
        self.assertIsNone(first_overlap_departure(((EPS,1,0),),1,distance_epsilon=EPS))

    def test_linear_departure_matches_analytic_contact_band(self):
        r=first_overlap_departure(((1,-2,0),),1,distance_epsilon=EPS)
        self.assertGreaterEqual(r,(1-EPS)/2);self.assertLess(r-(1-EPS)/2,F(1,10**30))

    def test_quadratic_overlap_departure_uses_first_exit_not_later_reentry(self):
        r=first_overlap_departure(((F(3,4)+EPS,-2,1),),2,distance_epsilon=EPS)
        self.assertGreaterEqual(r,F(1,2));self.assertLess(r-F(1,2),F(1,10**30))

    def test_zero_duration_and_exact_endpoint_are_defined(self):
        self.assertIsNone(first_overlap_departure(((1,-1,0),),0,distance_epsilon=EPS))
        self.assertEqual(first_overlap_departure(((1+EPS,-1,0),),1,distance_epsilon=EPS),1)
        self.assertEqual(first_overlap_departure(((EPS,-1,0),),1,distance_epsilon=EPS),0)

    def test_gap_polynomials_include_translation_and_both_pose_size_accelerations(self):
        a=Cuboid('foot',(0,0,3),(1,1,1));b=Cuboid('top',(0,0,1),(2,2,2))
        gaps=horizontal_gap_polynomials(a,b,(1,0,0),(0,0,0),(2,0,0),(0,0,0),
            first_size_rate=(2,0,0),second_size_rate=(2,0,0),first_size_acceleration=(4,0,0),second_size_acceleration=(4,0,0))
        self.assertEqual(gaps[:2],((F(3,2),3,3),(F(3,2),1,1)))

    def test_grazing_exit_is_distinct_from_approach_and_full_face_contact(self):
        params=dict(distance_epsilon=EPS,speed_epsilon=EPS)
        self.assertTrue(grazing_vertical_departure((1,0,1),(1,1,1),(2,0,0),(0,0,0),**params))
        self.assertFalse(grazing_vertical_departure((1,0,1),(1,1,1),(-2,0,0),(0,0,0),**params))
        self.assertFalse(grazing_vertical_departure((0,0,1),(1,1,1),(2,0,0),(0,0,0),**params))


if __name__=='__main__':unittest.main()
