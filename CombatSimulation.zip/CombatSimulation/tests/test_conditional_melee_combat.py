"""3E5's actual single conditional ability, branch debt and ballistic counters."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from tests.test_knock_motion_combat import scene as base_scene,run
from tests.test_grapple_links_combat import force,pos,vel
from tests.test_mobile_combat import command,events,PROFILES
from tests.test_world_colliders_combat import wall


def scene(duration=1200,distance='1.1'):
    s=base_scene(duration,distance);s['id']='conditional_melee'
    s['action_selection']['A']['abilities']=['1'];return s


def incoming(duration=4500,*,held=False):
    s=scene(duration);s['encounter']['participants']['A']['position_m']=[-4,-20]
    s['action_selection']['A']['start_ms']=370 if held else 350
    s['encounter']['participants']['B']['position_m']=['6.9',-20]
    s['encounter']['participants']['C']={'character':'3E5','team':'A','position_m':[8,-20],
        'facing':'-x','initial_state':{'shield':0}}
    s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['4'],start_ms=0)
    if held:
        s['encounter']['participants']['D']={'character':'1E5','team':'A','position_m':['6.9','-18.9'],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['D']=dict(s['action_selection']['B'],abilities=['2'],start_ms=0)
    return s


def dash(duration=4500,*,character='2E4'):
    s=scene(duration,8);s['action_selection']['A']['start_ms']=260
    s['encounter']['participants']['B']['character']=character
    s['action_selection']['B'].update(abilities=['3'],start_ms=0)
    return s


def selected(r):return [e for e in events(r,'conditional_component_selected') if e['actor']=='A']
def upward(r):return [k for k in r.get('knock_impulses',[]) if k.get('trajectory')=='ballistic_height']


class ConditionalMeleeCombatTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for actor,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=actor)
            self.assertLess(abs(supplied-D(r['final_states'][actor]['hp'])-ledger.amount(target=actor)),D('1e-8'))
        return ledger

    def test_normal_punches_alternate_pinned_hands_and_use_source_timing(self):
        r=run(scene(1000));frames=[f for f in r['melee_attacks'] if f['actor']=='A']
        self.assertEqual([f['melee_component'] for f in frames],['b','c','b'])
        self.assertEqual([D(f['created_at_ms']) for f in frames],[230,610,990])
        self.assertEqual([D(e['time_ms']) for e in selected(r)],[0,320,700])
        self.assertFalse(upward(r));self.assertFalse(events(r,'bleeding_started'));self.conserved(r)

    def test_normal_first_cost_and_target_statuses_are_not_the_counter_values(self):
        r=run(scene(230));paid=next(e for e in events(r,'dyspnea_paid') if e['actor']=='A')
        self.assertEqual(D(paid['base_value']),D('1.8'));self.assertEqual(D(paid['amount']),D('3.24'))
        power=next(p for p in r['released_attack_power'] if p['actor']=='A')
        self.assertEqual(D(power['components']['b']['output']),300)
        hit=next(e for e in events(r,'impact_batch_resolved') if e['target']=='B')
        self.assertLess(D(hit['status_additions']['instability']),150);self.conserved(r)

    def test_whiffs_advance_only_the_normal_cycle_without_self_effects(self):
        r=run(scene(900,30));self.assertEqual([e['component_id'] for e in selected(r)],['b','c','b'])
        self.assertFalse(events(r,'self_status_applied'));self.assertFalse(events(r,'cooldown_start_committed'))
        self.assertEqual(self.conserved(r).amount(),0)

    def test_incoming_real_knock_selects_the_counter_and_uses_pinned_power_cost(self):
        r=run(incoming(1000));first=selected(r)[0]
        self.assertEqual(first['component_id'],'a');self.assertEqual(first['assessment']['causes'],['knock'])
        paid=next(e for e in events(r,'dyspnea_paid') if e['actor']=='A')
        self.assertEqual((D(paid['time_ms']),D(paid['base_value']),D(paid['amount'])),(530,3,9))
        power=next(p for p in r['released_attack_power'] if p['actor']=='A')
        self.assertEqual(D(power['components']['a']['output']),600)
        self.assertEqual(D(upward(r)[0]['started_at_ms']),640)
        self.assertEqual(r['final_states']['A']['cooldown_clocks']['component:1:a']['ready_at_ms'],'4750')
        self.conserved(r)

    def test_counter_redirects_incoming_component_so_old_expiry_cannot_reintroduce_it(self):
        r=run(incoming(1100));k=upward(r)[0]
        self.assertGreater(D(k['removed_approach_speed_mps']),29)
        old=next(k for k in r['knock_impulses'] if k.get('trajectory') is None)
        self.assertEqual(D(old['retired_components'][0]['velocity_mps'][0]),0)
        self.assertEqual(vel(r,'B')[0],0);self.assertGreater(vel(r,'B')[2],0)

    def test_actual_apex_and_return_follow_gravity_instead_of_a_500_ms_window(self):
        s=incoming();r=run(s);k=upward(r)[0];speed=D(k['initial_velocity_delta_mps'][2])
        apex=D(k['started_at_ms'])+speed/D('9.81')*1000
        # Public observation horizons are integer ms. Check the last integer
        # before the apex against the independent closed-form gravity path.
        at=int(apex);s['encounter']['duration_ms']=at;at_apex=run(s)
        seconds=(D(at)-D(k['started_at_ms']))/1000
        expected=speed*seconds-D('9.81')*seconds*seconds/2
        self.assertAlmostEqual(pos(at_apex,'B')[2]-D('.875'),expected,places=18)
        self.assertLess(abs(pos(at_apex,'B')[2]-D('.875')-D(k['assessment']['resisted_m'])),D('1e-5'))
        self.assertAlmostEqual(vel(at_apex,'B')[2],speed-D('9.81')*seconds,places=18)
        self.assertEqual(k['end_reason'],'landed');self.assertGreater(D(k['ended_at_ms']),4000)
        self.assertEqual(pos(r,'B')[2],D('.875'));self.conserved(r)

    def test_real_incoming_dash_is_eligible_but_an_away_dash_is_not(self):
        incoming_run=run(dash(1000));away=run(dash(1000,character='1E5'))
        self.assertEqual(selected(incoming_run)[0]['component_id'],'a');self.assertTrue(upward(incoming_run))
        self.assertEqual(selected(away)[0]['component_id'],'b');self.assertFalse(upward(away))
        self.assertEqual(selected(away)[0]['assessment']['causes'],['dash'])

    def test_ordinary_approaching_run_is_not_a_dash_or_knock(self):
        s=scene(500,8);s['action_selection']['A']['start_ms']=200;command(s,'B',0,'run');r=run(s)
        row=selected(r)[0];self.assertGreater(D(row['assessment']['closing_speed_mps']),0)
        self.assertEqual(row['assessment']['causes'],[]);self.assertEqual(row['component_id'],'b')

    def test_a_pending_dash_landing_is_not_a_stale_dash_motion_cause(self):
        s=dash(1200);s['spatial_interventions']=[force(200,'B',[-2,0,3])];r=run(s)
        self.assertEqual(selected(r)[0]['component_id'],'b');self.assertEqual(selected(r)[0]['assessment']['causes'],[])
        self.assertFalse(upward(r));self.assertTrue(events(r,'body_launch_landed'))

    def test_reference_only_relocation_keeps_the_actual_dash_cause(self):
        s=dash(400);s['spatial_interventions']=[force(200,'B',reference=[9,-20,'1.2'])];r=run(s)
        self.assertEqual(selected(r)[0]['component_id'],'a');self.assertEqual(selected(r)[0]['assessment']['causes'],['dash'])

    def test_selected_counter_stays_pinned_if_the_motion_cause_changes_during_gathering(self):
        s=incoming(900);s['spatial_interventions']=[force(400,'B',[0,0,0])];r=run(s)
        self.assertEqual(selected(r)[0]['component_id'],'a');self.assertFalse(upward(r))
        frame=next(f for f in r['melee_attacks'] if f['actor']=='A')
        self.assertEqual(frame['melee_component'],'a');self.assertEqual(frame['status'],'missed')
        self.assertEqual(D(next(e for e in events(r,'dyspnea_paid') if e['actor']=='A')['base_value']),3)
        self.assertEqual(r['final_states']['A']['cooldown_clocks']['component:1:a']['ready_at_ms'],'4750')

    def test_counter_does_not_consume_the_normal_cycle_and_cooldown_uses_normal_fallback(self):
        r=run(incoming(3500));rows=selected(r)
        self.assertEqual([e['component_id'] for e in rows[:4]],['a','b','c','b'])
        falling=next(e for e in rows if e['assessment']['eligible'] and D(e['time_ms'])>2000)
        self.assertIn(falling['component_id'],('b','c'));self.assertEqual(falling['counter_ready_at_ms'],'4750')

    def test_counter_keeps_its_right_hand_cost_when_the_normal_cursor_is_left(self):
        s=incoming(650);s['encounter']['participants']['A']['position_m']=[-3,-20]
        s['action_selection']['A']['start_ms']=0;r=run(s)
        self.assertEqual([e['component_id'] for e in selected(r)],['b','a'])
        owner=next(o for o in r['final_states']['A']['owned_actions'] if o['action']['ability_id']=='1')
        self.assertEqual(owner['action']['component_id'],'a');self.assertEqual(owner['occupies'],['hand:right','weapon:1'])
        state=next(row for row in r['melee_component_sequences'] if row['actor']=='A')
        self.assertEqual(state['next_component'],'c')
        paid=[e for e in events(r,'dyspnea_paid') if e['actor']=='A']
        self.assertEqual([D(e['base_value']) for e in paid],[D('1.8'),D(3)])
        self.assertTrue(upward(r));self.conserved(r)

    def test_unaffordable_counter_can_use_the_legal_normal_branch(self):
        s=incoming(600);s['encounter']['participants']['A']['initial_state']['dyspnea']=100;r=run(s)
        row=selected(r)[0];self.assertTrue(row['assessment']['eligible']);self.assertEqual(row['component_id'],'b')
        self.assertEqual(D(row['base_dyspnea']),D('1.8'));self.assertFalse(events(r,'cooldown_start_committed'))

    def test_cancellation_before_active_has_no_cost_or_cooldown_debt(self):
        r=run(incoming(700),operations=[(400,{'op':'restriction','functions':['upper_body']})])
        self.assertFalse([e for e in events(r,'dyspnea_paid') if e['actor']=='A'])
        self.assertFalse(events(r,'cooldown_start_committed'));self.assertFalse(upward(r))

    def test_cancellation_after_payment_keeps_the_original_active_end_cooldown(self):
        r=run(incoming(900),operations=[(600,{'op':'restriction','functions':['hand:right']})])
        self.assertFalse(upward(r));row=events(r,'deferred_cooldown_started')[0]
        self.assertEqual(D(row['started_at_ms']),750);self.assertEqual(D(row['clock']['remaining_work_ms']),4000)
        self.assertEqual(r['final_states']['A']['cooldown_clocks']['component:1:a']['ready_at_ms'],'4750')

    def test_cooldown_debt_starts_while_dead_and_only_progresses_after_revival(self):
        r=run(incoming(1000),operations=[(600,{'op':'kill'}),(850,{'op':'revive','hp':1000})])
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(D(r['final_states']['A']['cooldown_clocks']['component:1:a']['remaining_work_ms']),3850)
        row=events(r,'deferred_cooldown_started')[0];self.assertEqual(row['clock']['state'],'stopped')
        self.assertEqual(row['source_life_generation'],1);self.assertEqual(D(row['started_at_ms']),750)

    def test_revival_before_deferred_start_cannot_erase_or_duplicate_the_debt(self):
        r=run(incoming(1000),operations=[(600,{'op':'kill'}),(650,{'op':'revive','hp':1000})])
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        self.assertEqual(D(r['final_states']['A']['cooldown_clocks']['component:1:a']['remaining_work_ms']),3750)
        self.assertEqual(len(events(r,'deferred_cooldown_started')),1)

    def test_real_pause_field_pauses_cooldown_work_after_the_active_tail(self):
        s=dash(4300);s['encounter']['participants']['C']={'character':'1E2','team':'B','position_m':[30,-22],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['2'],start_ms=0)
        r=run(s);row=events(r,'deferred_cooldown_started')[0]
        self.assertEqual(D(row['started_at_ms']),660);self.assertEqual(row['clock']['state'],'paused')
        self.assertEqual(r['final_states']['A']['cooldown_clocks']['component:1:a']['ready_at_ms'],'8200')
        self.conserved(r)

    def test_actual_held_pair_uses_summed_resistance_and_one_upward_launch(self):
        r=run(incoming(4500,held=True));k=upward(r)[0]
        self.assertEqual(k['assessment']['actors'],['B','D']);self.assertEqual(D(k['assessment']['maximum_hp_sum']),29080)
        self.assertEqual(D(k['started_at_ms']),660)
        self.assertEqual(pos(r,'B')[2],D('.875'));self.assertEqual(pos(r,'D')[2],D('1.1375'))
        self.assertAlmostEqual(pos(r,'B')[0],pos(r,'D')[0],places=18)
        self.assertEqual(k['end_reason'],'landed');self.conserved(r)

    def test_real_block_intercepts_counter_without_waiving_its_cost_or_cooldown(self):
        s=dash(700);s['action_selection']['B'].update(abilities=['basic_8','3'],held_blocks=['basic_8'])
        # The authored larger counter body also makes real top-face contact
        # with the dasher. Current rules supply the required body support.
        from tests.test_equilibrium_combat import rules
        r=run(s,rules=rules());self.assertEqual(selected(r)[0]['component_id'],'a');self.assertFalse(upward(r))
        self.assertTrue([e for e in events(r,'knock_skipped') if e['reason']=='blocked_or_zero_power'])
        self.assertEqual(D(next(e for e in events(r,'dyspnea_paid') if e['actor']=='A')['base_value']),3)
        self.assertEqual(D(events(r,'deferred_cooldown_started')[0]['started_at_ms']),660)
        self.conserved(r)

    def test_ceiling_stops_upward_motion_then_gravity_lands_with_the_original_dash_effects(self):
        s=dash(1800);s['initial_colliders']=[wall('ceiling',x='.5',hp=None,size=(6,4,'.2'),z=4)]
        r=run(s);self.assertTrue([e for e in events(r,'body_contact') if e['second']=='ceiling'])
        self.assertFalse(events(r,'elastic_body_response'));self.assertEqual(upward(r)[0]['end_reason'],'landed')
        self.assertLess(D(upward(r)[0]['ended_at_ms']),1800)
        landed=[e for e in events(r,'body_launch_landed') if e['actor']=='B']
        self.assertEqual(len(landed),1);self.assertEqual(landed[0]['self_effects'],{'disorientation':'120','instability':'160'})
        self.conserved(r)

    def test_precision_observation_and_participant_order_preserve_counter_results(self):
        for s in (incoming(),incoming(4500,held=True),dash()):
            baseline=run(s,interval=100);other=deepcopy(s)
            other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,interval=137,precision=80)
            self.assertEqual([e['component_id'] for e in selected(baseline)],[e['component_id'] for e in selected(r)])
            for actor in r['final_states']:
                for key in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertLess(abs(D(r['final_states'][actor][key])-D(baseline['final_states'][actor][key])),D('1e-8'))
                for a,b in zip(pos(r,actor),pos(baseline,actor)):self.assertLess(abs(a-b),D('1e-18'))
            self.conserved(r)


if __name__=='__main__':unittest.main()
