"""Integrated stationary team rules on the shared event timeline."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
from pathlib import Path
import unittest

from combat_sim.analysis import summarize
from combat_sim.shared_engine import run_shared_scenario
from combat_sim.shared_engine import SharedEncounter
from combat_sim.models import UnsupportedMechanicError


ROOT=Path(__file__).resolve().parents[1]
PROFILES=json.loads((ROOT/'data/characters.json').read_text())['characters']
SCENARIO=json.loads((ROOT/'scenarios/stationary_2v2.json').read_text())


def events(run,kind):
    return [e for e in run['events'] if e['type']==kind]


def duel(ability='1',horizon=1300,source_hp=8140,gun_start=200000):
    s=deepcopy(SCENARIO)
    s['encounter']['duration_ms']=horizon
    s['encounter']['participants']={
        'caster':{'character':'1E1','team':'A','position_m':[0,0],'initial_state':{'shield':0,'hp':source_hp}},
        'gunner':{'character':'1E2','team':'B','position_m':[30,0],'initial_state':{'shield':0}},
    }
    s['action_selection']={
        'caster':{'kind':'priority_when_ready','target':'nearest_living_enemy','abilities':[ability]},
        'gunner':{'kind':'priority_when_ready','target':'nearest_living_enemy','abilities':['1'],
                  'reload_when_empty':True,'start_ms':gun_start},
    }
    return s


class StationaryTeamIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result=run_shared_scenario(SCENARIO,PROFILES)

    def test_requested_positions_initial_shields_and_full_horizon(self):
        r=self.result
        self.assertEqual(r['run_until_ms'],'30000')
        for name,position,shield in [('A_1E1',[0,0],1000),('A_1E2',[0,10],1000),
                                      ('B_1E1',[30,0],4000),('B_1E2',[30,4],4000)]:
            self.assertEqual(r['initial_states'][name]['position_m'],position)
            self.assertEqual(D(r['initial_states'][name]['shield']),shield)
            self.assertEqual(D(r['initial_states'][name]['dyspnea']),0)

    def test_nearest_initial_targets_and_inclusive_area_recipients(self):
        starts=events(self.result,'ability_started')[:4]
        self.assertEqual({e['actor']:e['target'] for e in starts},
                         {'A_1E1':'B_1E1','A_1E2':'B_1E2','B_1E1':'A_1E1','B_1E2':'A_1E1'})
        beam=next(e for e in events(self.result,'beam_deployed') if e['actor']=='A_1E1')
        self.assertEqual(beam['recipients'],['B_1E1','B_1E2'])
        blast=next(e for e in events(self.result,'delayed_blast') if e['actor']=='A_1E1')
        self.assertEqual(blast['recipients'],['B_1E1','B_1E2'])

    def test_due_active_start_precedes_same_timestamp_incoming_status(self):
        r=run_shared_scenario(duel('4',1000,gun_start=147),PROFILES)
        # Beam: initial Recovery112 + Gathering180 =292. Gun:147+71+40+34=292.
        self.assertEqual(events(r,'beam_deployed')[0]['time_ms'],'292')
        self.assertTrue(any(e['time_ms']=='292' and e['target']=='caster' for e in events(r,'impact_batch_resolved')))
        self.assertFalse(any(e['actor']=='caster' for e in events(r,'gathering_extended')))

    def test_due_projectile_releases_before_exactly_tied_lethal_hit(self):
        r=run_shared_scenario(duel('1',1300,source_hp=1,gun_start=253),PROFILES)
        # Qard:78+140+180=398. Gun:253+71+40+34=398.
        release=next(e for e in events(r,'projectile_released') if e['actor']=='caster')
        death=next(e for e in events(r,'character_died') if e['actor']=='caster')
        self.assertEqual(release['time_ms'],'398')
        self.assertEqual(death['time_ms'],'398')
        self.assertLess(r['events'].index(release),r['events'].index(death))
        self.assertTrue(any(e['target']=='gunner' and e['time_ms']=='698' for e in events(r,'impact_batch_resolved')))
        self.assertTrue(any(e['actor']=='caster' for e in events(r,'dyspnea_paid')))

    def test_death_before_release_cancels_action_without_unpaid_cost(self):
        r=run_shared_scenario(duel('1',1000,source_hp=1,gun_start=0),PROFILES)
        death=next(e for e in events(r,'character_died') if e['actor']=='caster')
        self.assertEqual(death['cancelled_action']['phase'],'gathering')
        self.assertFalse(any(e['actor']=='caster' for e in events(r,'projectile_released')))
        self.assertFalse(any(e['actor']=='caster' for e in events(r,'dyspnea_paid')))

    def test_deployed_beam_survives_source_death(self):
        r=run_shared_scenario(duel('4',5000,source_hp=1,gun_start=400),PROFILES)
        death=next(e for e in events(r,'character_died') if e['actor']=='caster')
        self.assertIsNotNone(death['cancelled_action'])
        self.assertTrue(any(D(e['time_ms'])>D(death['time_ms']) and e['target']=='gunner'
                            and D(e['applied_hp_damage'])>0 for e in events(r,'continuous_damage_resolved')))
        self.assertEqual(events(r,'beam_deployed')[0]['time_ms'],'292')

    def test_released_qard_and_delayed_blast_survive_source_death(self):
        r=run_shared_scenario(duel('1',1300,source_hp=1,gun_start=400),PROFILES)
        death=next(e for e in events(r,'character_died') if e['actor']=='caster')
        self.assertLess(D(death['time_ms']),698)
        self.assertTrue(any(e['time_ms']=='698' and e['target']=='gunner' for e in events(r,'impact_batch_resolved')))
        self.assertTrue(any(e['time_ms']=='1198' and e['actor']=='caster' for e in events(r,'delayed_blast')))

    def test_applied_bleeding_survives_shooters_death(self):
        s=duel('1',5000,source_hp=1,gun_start=200)
        s['encounter']['participants']['caster']['character']='1E2'
        s['action_selection']['caster']['reload_when_empty']=True
        r=run_shared_scenario(s,PROFILES)
        death=next(e for e in events(r,'character_died') if e['actor']=='caster')
        self.assertTrue(any(D(e['time_ms'])>D(death['time_ms']) and e['target']=='gunner'
                            and any(p['kind']=='bleeding' and p['actor']=='caster' for p in e['components'])
                            for e in events(r,'continuous_damage_resolved')))

    def test_two_released_lethal_attacks_both_resolve(self):
        s=duel('1',1000,source_hp=1,gun_start=0)
        s['encounter']['participants']['caster']['character']='1E2'
        s['encounter']['participants']['gunner']['initial_state']['hp']=1
        s['action_selection']['caster']['reload_when_empty']=True
        r=run_shared_scenario(s,PROFILES)
        deaths=events(r,'character_died')
        self.assertEqual(len(deaths),2)
        self.assertEqual({e['time_ms'] for e in deaths},{'145'})
        self.assertEqual(r['surviving_teams'],[])

    def test_target_dying_during_preparation_does_not_redirect_projectile(self):
        s=duel('1',2000)
        s['encounter']['participants']['gunner']['initial_state']['hp']=1
        s['encounter']['participants']['ally']={'character':'1E2','team':'A','position_m':[0,1]}
        s['encounter']['participants']['far']={'character':'1E1','team':'B','position_m':[40,0]}
        s['action_selection']['ally']={'kind':'priority_when_ready','target':'nearest_living_enemy',
                                       'abilities':['1'],'reload_when_empty':True}
        s['action_selection']['far']={'kind':'priority_when_ready','target':'nearest_living_enemy',
                                      'abilities':['1'],'start_ms':200000}
        r=run_shared_scenario(s,PROFILES)
        release=next(e for e in events(r,'projectile_released') if e['actor']=='caster')
        self.assertEqual(release['target'],'gunner')
        self.assertEqual(release['location_m'],[30,0])
        self.assertTrue(any(e['actor']=='caster' for e in events(r,'projectile_arrived_at_dead_target_location')))
        starts=[e for e in events(r,'ability_started') if e['actor']=='caster']
        self.assertEqual([e['target'] for e in starts[:2]],['gunner','far'])

    def test_common_snapshot_and_proportional_shield_are_integrated(self):
        s=duel('1',200)
        s['encounter']['participants']['caster']['character']='1E2'
        s['encounter']['participants']['gunner']['initial_state']['shield']=100
        s['encounter']['participants']['ally']={'character':'1E2','team':'A','position_m':[0,1]}
        s['action_selection']['caster']['reload_when_empty']=True
        s['action_selection']['ally']={'kind':'priority_when_ready','target':'nearest_living_enemy',
                                       'abilities':['1'],'reload_when_empty':True}
        r=run_shared_scenario(s,PROFILES)
        batch=next(e for e in events(r,'impact_batch_resolved') if e['target']=='gunner')
        self.assertEqual(len(batch['hits']),2)
        self.assertEqual(D(batch['pre_hit_armor']),150)
        self.assertEqual(D(batch['applied_shield_damage']),100)
        with localcontext(Context(prec=50)):
            a,b=batch['hits']
            self.assertLess(abs(D(a['shield_absorbed'])/D(a['incoming'])-
                                D(b['shield_absorbed'])/D(b['incoming'])),D('1e-45'))

    def test_costs_use_authored_phases_and_beam_is_exempt(self):
        r=self.result
        for event in events(r,'dyspnea_paid'):
            self.assertEqual(event['phase'],'active_start' if event['action_kind']=='reload' else 'active_firing_end')
            self.assertNotEqual(event['action_kind'],'heat_beam')
        self.assertTrue(any(e['action_kind']=='reload' for e in events(r,'dyspnea_paid')))
        self.assertTrue(events(r,'dyspnea_recovered'))
        for point in r['curve']:
            for state in point['states'].values():
                self.assertGreaterEqual(D(state['dyspnea']),0)
                self.assertLessEqual(D(state['dyspnea']),100)

    def test_reload_uses_right_hand_transition_and_refills_magazine(self):
        reload=next(e for e in events(self.result,'reload_requested') if e['actor']=='A_1E2')
        self.assertEqual(reload['recovery_ms'],119)
        self.assertEqual(set(reload['individual_hands']),{'right'})
        self.assertTrue(any(e['actor']=='A_1E2' and e['ammo']==11 for e in events(self.result,'reload_completed')))

    def test_policy_waits_for_dyspnea_space_then_pays_at_authored_event(self):
        s=duel('1',2000)
        s['encounter']['participants']['caster']['initial_state']['dyspnea']=99
        r=run_shared_scenario(s,PROFILES)
        wait=next(e for e in events(r,'policy_wait') if e['actor']=='caster')
        start=next(e for e in events(r,'ability_started') if e['actor']=='caster')
        self.assertEqual(wait['resume_at_ms'],start['time_ms'])
        self.assertGreater(D(start['time_ms']),0)
        paid=next(e for e in events(r,'dyspnea_paid') if e['actor']=='caster')
        self.assertEqual(paid['phase'],'active_firing_end')
        self.assertLessEqual(D(paid['after']),100)

    def test_maximum_trigger_is_paid_and_serializable_at_its_event(self):
        # Controlled formula fixture: Db=10, D=0 reaches exactly 100. This
        # changes only a copied test profile, not authored character data.
        profiles=deepcopy(PROFILES)
        profiles['1E1']['abilities']['1']['dyspnea']['base_value']=10
        r=run_shared_scenario(duel('1',500),profiles)
        trigger=events(r,'maximum_dyspnea_trigger')[0]
        self.assertEqual(trigger['time_ms'],'398')
        self.assertEqual(D(trigger['added_disorientation']),200)
        json.dumps(r)

    def test_initial_missing_shield_is_not_restored_without_recorded_damage(self):
        s=duel('1',30000)
        s['encounter']['participants']['caster']['initial_state']['shield']=1000
        s['action_selection']['caster']['start_ms']=200000
        r=run_shared_scenario(s,PROFILES)
        self.assertEqual(D(r['final_states']['caster']['shield']),1000)
        self.assertEqual(D(r['shield_regenerated_total']),0)

    def test_unconfirmed_regeneration_overlap_with_heat_is_rejected(self):
        with localcontext(Context(prec=50)):
            encounter=SharedEncounter(duel('4',30000),PROFILES)
            encounter.time=D(20000)
            encounter.shield_recovery['gunner'].add_impact(D(0),D(100))
            encounter.effects.append({'id':1,'kind':'heat','actor':'caster','target':'gunner','ability':'4',
                                      'mode':'hp','start':D(20000),'leave':D(23000),'expiry':D(24500),
                                      'heat_output':D(900),'k':D(2)})
            with self.assertRaisesRegex(UnsupportedMechanicError,'overlapping ongoing heat'):
                encounter.advance(D(20100))

    def test_hp_shield_armor_accounting_and_dead_action_cancellation(self):
        r=self.result
        with localcontext(Context(prec=60)):
            for name,final in r['final_states'].items():
                initial,metrics=r['initial_states'][name],r['metrics'][name]
                hp=D(initial['hp'])-D(metrics['direct_hp_damage_received'])-D(metrics['continuous_hp_damage_received'])
                shield=D(initial['shield'])-D(metrics['shield_damage_received'])+D(metrics['shield_regenerated'])
                self.assertLess(abs(D(final['hp'])-hp),D('1e-40'))
                self.assertLess(abs(D(final['shield'])-shield),D('1e-40'))
                self.assertGreaterEqual(D(final['armor']),0)
                if not final['alive']:
                    self.assertIsNone(final['current_action'])
                    self.assertFalse(any(e.get('actor')==name and D(e['time_ms'])>D(final['died_at_ms'])
                                         for e in r['events'] if e['type'] in ('ability_started','projectile_released','reload_completed')))

    def test_regeneration_runs_after_own_loss_delay_and_one_shared_rate(self):
        r=self.result
        regen=events(r,'shield_regenerated')
        self.assertTrue(regen)
        self.assertTrue(all(D(e['time_ms'])>20000 for e in regen))
        with localcontext(Context(prec=60)):
            for event in regen:
                maximum=(D(event['interval_end_ms'])-D(event['interval_start_ms']))*D('.4')
                self.assertLessEqual(D(event['amount']),maximum+D('1e-40'))
        self.assertGreater(D(r['shield_regenerated_total']),0)

    def test_summary_reports_deaths_and_surviving_teams(self):
        summary=summarize(self.result)
        self.assertEqual(summary['outcome']['surviving_teams'],self.result['surviving_teams'])
        for name,p in summary['participants'].items():
            self.assertEqual(p['alive'],self.result['final_states'][name]['alive'])
            self.assertIn('shield_regenerated',p)

    def test_precision_and_observation_spacing_preserve_the_encounter(self):
        cadence=lambda r:[(e['time_ms'],e.get('actor'),e.get('target'),e.get('ability'),e['type'])
                           for e in r['events'] if e['type'] in ('ability_started','projectile_released','reload_completed')]
        for trial in (run_shared_scenario(SCENARIO,PROFILES,precision=80),
                      run_shared_scenario(SCENARIO,PROFILES,sample_interval_ms=137),
                      run_shared_scenario(SCENARIO,PROFILES,sample_interval_ms=None)):
            self.assertEqual(cadence(trial),cadence(self.result))
            with localcontext(Context(prec=90)):
                for name,final in trial['final_states'].items():
                    baseline=self.result['final_states'][name]
                    self.assertEqual(final['alive'],baseline['alive'])
                    for field in ('hp','shield','armor','dyspnea','disorientation','instability'):
                        self.assertLess(abs(D(final[field])-D(baseline[field])),D('1e-20'))
                    if final['died_at_ms'] is not None:
                        self.assertLess(abs(D(final['died_at_ms'])-D(baseline['died_at_ms'])),D('1e-20'))
