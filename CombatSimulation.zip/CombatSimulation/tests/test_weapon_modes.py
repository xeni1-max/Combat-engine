"""Inventory selection/snapshots independently of combat scheduling."""
from copy import deepcopy
from decimal import Decimal as D
from types import SimpleNamespace
import unittest

from combat_sim.automatic_abilities import ability_definition
from combat_sim.battle_models import BattleAction
from combat_sim.models import UnsupportedMechanicError
from combat_sim.weapon_modes import WeaponModes
from combat_sim.effort_rules import EffortRules
from tests.test_mobile_combat import PROFILES


def controller():return WeaponModes(SimpleNamespace(mobile_mode=True),{'mode':'owned_inventory_v1'})
def actor(name='A'):return SimpleNamespace(id=name,profile=deepcopy(PROFILES['1E1']))


class WeaponModeTests(unittest.TestCase):
    def test_inventory_changes_selection_without_mutating_author_profile(self):
        w=controller();a=actor();before=deepcopy(a.profile);w.attach_actor(a)
        self.assertEqual(ability_definition(a,'1')['execution_model'],'projectile_delayed_area')
        self.assertEqual(ability_definition(a,'Ultimate')['execution_model'],'weapon_swap')
        w.inventories[a.id].update(mode='launcher',rounds=10)
        self.assertEqual(ability_definition(a,'1')['execution_model'],'poison_projectile')
        self.assertEqual(a.profile,before)

    def test_two_actors_share_no_inventory_or_selected_definition_mutation(self):
        w=controller();a,b=actor('A'),actor('B');b.profile=a.profile
        w.attach_actor(a);w.attach_actor(b);w.inventories['A'].update(mode='launcher',rounds=8)
        self.assertEqual(w.inventories['B'],{'mode':'main','rounds':0,'capacity':10})
        w.configs['A']['firing']['poison']['toxicity']=1
        self.assertEqual(w.configs['B']['firing']['poison']['toxicity'],1200)
        self.assertEqual(a.profile['weapon_mode']['firing']['poison']['toxicity'],1200)

    def test_owned_action_snapshot_retains_main_definition_after_selection_changes(self):
        w=controller();a=actor();w.attach_actor(a)
        action=BattleAction(1,'A','B','1','projectile_delayed_area',D(0),D(0),D(180))
        w.snapshot(a,action,ability_definition(a,'1'))
        w.inventories['A'].update(mode='launcher',rounds=10)
        self.assertEqual(action.definition_snapshot['pre_mitigation_damage'],450)
        self.assertEqual(action.definition_variant,'main')
        self.assertNotIn('definition_snapshot',action.record())

    def test_swap_and_replaced_attack_reserve_the_same_slot_without_global_exclusivity(self):
        w=controller();a=actor();w.attach_actor(a)
        self.assertEqual(w.slot(a,'Ultimate'),w.slot(a,'1'));self.assertNotEqual(w.slot(a,'2'),w.slot(a,'1'))

    def test_empty_launcher_blocks_only_its_replaced_attack(self):
        w=controller();a=actor();w.attach_actor(a)
        self.assertFalse(w.empty(a,'1'));w.inventories['A'].update(mode='launcher',rounds=0)
        self.assertTrue(w.empty(a,'1'));self.assertFalse(w.empty(a,'2'));self.assertFalse(w.empty(a,'Ultimate'))

    def test_invalid_declarations_fail_before_attaching_actor_state(self):
        def capacity(a):a.profile['weapon_mode']['capacity']=True
        def toxin(a):a.profile['weapon_mode']['firing']['poison']['toxicity']='NaN'
        def swap_damage(a):a.profile['weapon_mode']['swap']['pre_mitigation_damage']=1
        def payment(a):a.profile['weapon_mode']['swap']['dyspnea'].pop('capacity_check_timing')
        def active(a):a.profile['timing_profiles']['Ultimate_firing']['active_ms']='180.5'
        def hand(a):a.profile['weapon_mode']['swap']['hand_positions_m']['start']['left']=[False,0,0]
        def destination(a):a.profile['weapon_mode']['swap']['swap_target']='main'
        for change in (capacity,toxin,swap_damage,payment,active,hand,destination):
            w=controller();a=actor();change(a)
            with self.subTest(change=change.__name__),self.assertRaises((ValueError,UnsupportedMechanicError)):w.attach_actor(a)
            self.assertFalse(w.configs);self.assertFalse(w.inventories);self.assertFalse(hasattr(a,'ability_resolver'))

    def test_historical_inputs_without_mode_rules_retain_legacy_definition(self):
        w=WeaponModes(SimpleNamespace(mobile_mode=True));a=actor();w.attach_actor(a)
        self.assertEqual(ability_definition(a,'Ultimate')['execution_model'],'poison_grenade')
        self.assertFalse(hasattr(a,'weapon_inventory'));self.assertFalse(hasattr(a,'ability_resolver'))

    def test_unselected_characters_and_unsupported_mode_rules_are_explicit(self):
        w=controller();a=SimpleNamespace(id='B',profile=PROFILES['1E2']);w.attach_actor(a)
        self.assertFalse(w.configs)
        with self.assertRaises(UnsupportedMechanicError):WeaponModes(SimpleNamespace(mobile_mode=True),{'mode':'unknown'})

    def test_selected_variant_uses_its_effort_source_instead_of_the_base_slot_cache(self):
        w=controller();a=actor();w.attach_actor(a)
        effort=EffortRules(SimpleNamespace());effort.phases[('A','1')]=('firing','extrinsic_sustained')
        self.assertEqual(effort.selected_phase(a,'1',w.configs['A']['firing']),('firing','intrinsic_momentary'))


if __name__=='__main__':unittest.main()
