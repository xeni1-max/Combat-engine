"""Declared engine numerics own construction, execution and subclass loading."""
from copy import deepcopy
from decimal import Context, Decimal as D, Inexact, ROUND_DOWN, ROUND_UP, getcontext, localcontext
from fractions import Fraction
import unittest

from combat_sim.shared_engine import SharedEncounter, run_shared_scenario
from tests.test_equilibrium_combat import scene as base_scene
from tests.test_mobile_combat import read, events
from tests.test_released_damage_combat import FILES


def scene():
    s = base_scene(500, o='80.0000000000000000000000000001')
    s['id'] = 'constructor_context_boundary'
    s['action_selection']['A']['start_ms'] = 0
    return s


def arguments():
    return read('data/characters.json')['characters'], {key: read(path) for key, path in FILES.items()}


class ConstructorContextTests(unittest.TestCase):
    def test_integer_gathering_boundary_has_identical_direct_and_public_traces(self):
        profiles, inputs = arguments()
        with localcontext(Context(prec=80)):
            expected = run_shared_scenario(scene(), profiles, precision=50, sample_interval_ms=None, **inputs)
        self.assertEqual([e['time_ms'] for e in events(expected, 'projectile_released')], ['121'])
        for precision in (28, 50, 80):
            with self.subTest(caller_precision=precision), localcontext(Context(prec=precision)):
                actual = SharedEncounter(scene(), profiles, precision=50, sample_interval_ms=None, **inputs).run()
                self.assertEqual(actual, expected)

    def test_fractional_initial_positions_and_stats_retain_declared_digits(self):
        s = scene()
        s['encounter']['participants']['A']['position_m'] = [Fraction(1, 7), Fraction(-141, 7)]
        s['encounter']['participants']['A']['initial_state']['hp'] = Fraction(10001, 7)
        profiles, inputs = arguments()
        values = []
        for precision in (28, 50, 80):
            with localcontext(Context(prec=precision)):
                world = SharedEncounter(s, profiles, precision=50, sample_interval_ms=None, **inputs)
                values.append(deepcopy(world.initial))
        self.assertEqual(values[0], values[1])
        self.assertEqual(values[1], values[2])
        with localcontext(Context(prec=50)):
            self.assertEqual(D(values[0]['A']['hp']), D(10001) / 7)

    def test_caller_rounding_and_traps_do_not_change_engine_results(self):
        profiles, inputs = arguments()
        expected = run_shared_scenario(scene(), profiles, sample_interval_ms=None, **inputs)
        for rounding in (ROUND_DOWN, ROUND_UP):
            with self.subTest(rounding=rounding), localcontext(Context(prec=28, rounding=rounding)):
                getcontext().traps[Inexact] = True
                self.assertEqual(SharedEncounter(scene(), profiles, sample_interval_ms=None, **inputs).run(), expected)

    def test_success_restores_the_caller_context_including_flags(self):
        profiles, inputs = arguments()
        with localcontext(Context(prec=28, rounding=ROUND_UP)):
            getcontext().flags[Inexact] = True
            before = getcontext().copy()
            SharedEncounter(scene(), profiles, sample_interval_ms=None, **inputs).run()
            after = getcontext()
            self.assertEqual((after.prec, after.rounding, after.flags, after.traps),
                             (before.prec, before.rounding, before.flags, before.traps))

    def test_failed_initialization_restores_the_caller_context(self):
        profiles, inputs = arguments()
        class Failure(SharedEncounter):
            def _load(self):
                self.assert_context = (getcontext().prec, getcontext().rounding)
                D(1) / 7
                raise ValueError('deliberate constructor failure')
        with localcontext(Context(prec=28, rounding=ROUND_DOWN)):
            before = getcontext().copy()
            with self.assertRaisesRegex(ValueError, 'deliberate constructor failure'):
                Failure(scene(), profiles, **inputs)
            self.assertEqual((getcontext().prec, getcontext().rounding, getcontext().flags, getcontext().traps),
                             (before.prec, before.rounding, before.flags, before.traps))

    def test_subclass_load_hook_observes_the_declared_context(self):
        profiles, inputs = arguments()
        class Extension(SharedEncounter):
            def _load(self):
                self.seen_context = (getcontext().prec, getcontext().rounding)
                super()._load()
        with localcontext(Context(prec=28, rounding=ROUND_UP)):
            world = Extension(scene(), profiles, precision=80, **inputs)
        self.assertEqual(world.seen_context, (80, 'ROUND_HALF_EVEN'))

    def test_invalid_precision_is_rejected_by_both_entry_points_before_loading(self):
        profiles, inputs = arguments()
        for precision in (True, False, 39, 0, -1, '50', 50.0):
            for constructor in (SharedEncounter, run_shared_scenario):
                with self.subTest(precision=precision, entry=constructor.__name__):
                    with self.assertRaisesRegex(ValueError, 'at least 40'):
                        constructor(None, profiles, precision=precision, **inputs)


if __name__ == '__main__':
    unittest.main()
