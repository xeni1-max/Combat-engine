"""Climb activation, motion and raised support run on the shared engine."""
from copy import deepcopy
from decimal import Decimal as D
import json
from pathlib import Path
import unittest

from combat_sim.engine import run_scenario
from combat_sim.shared_engine import run_shared_scenario
from combat_sim.models import UnsupportedMechanicError

ROOT=Path(__file__).resolve().parents[1]
load=lambda name:json.loads((ROOT/name).read_text())
SCENARIO=load('scenarios/scripted_climb_geometry.json')
PROFILES=load('data/characters.json')['characters']
OPTIONS={k:load(f) for k,f in [('body_definition','data/body_hitboxes.json'),
    ('terrain_definition','data/terrain/stationary_arena.json'),('movement_definition','data/movement/walk_run.json'),
    ('jump_definition','data/movement/jump.json'),('climb_definition','data/movement/climb.json')]}

def run(s=SCENARIO,**kwargs):return run_shared_scenario(s,PROFILES,**OPTIONS,**kwargs)
def events(r,kind):return [e for e in r['events'] if e['type']==kind]

class SharedClimbTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.result=run()

    def test_public_dispatch_and_completed_top_position(self):
        self.assertEqual(run_scenario(SCENARIO,PROFILES,**OPTIONS),self.result)
        state=self.result['final_states']['A_1E1']
        self.assertEqual(list(map(D,state['body_origin_m'])),[6,0,D('2.675')])
        self.assertEqual(state['locomotion']['support_id'],'cube_1')
        self.assertEqual(D(state['locomotion']['support_surface_z_m']),D('1.8'))
        self.assertTrue(state['locomotion']['grounded'])
        self.assertEqual(state['locomotion']['mode'],'standing')

    def test_only_the_selected_block_is_climbable(self):
        objects=OPTIONS['terrain_definition']['obstacles']
        self.assertEqual([o['id'] for o in objects if o.get('climbable')],['cube_1'])

    def test_gathering_active_corner_and_completion_times(self):
        r=self.result
        self.assertEqual(D(events(r,'climb_active_started')[0]['time_ms']),150)
        self.assertEqual(D(events(r,'climb_top_reached')[0]['time_ms']),D('318.75'))
        self.assertEqual(D(events(r,'climb_completed')[0]['time_ms']),450)
        start=events(r,'climb_active_started')[0]
        self.assertEqual(D(start['path_length_m']),D('3.2'))
        self.assertLess(abs(D(start['path_speed_mps'])-D(32)/3),D('1e-25'))

    def test_origin_gap_boundary_inclusive_not_body_surface_gap(self):
        request=events(self.result,'climb_requested')[0]
        self.assertEqual(D(request['origin_surface_distance_squared_m2']),D('.25'))
        s=deepcopy(SCENARIO);s['encounter']['participants']['A_1E1']['position_m']=['4.5',0]
        r=run(s)
        # Torso is 0.45 m from the block, but origin is 0.6 m away.
        self.assertTrue(any(e['actor']=='A_1E1' and e['reason']=='outside_activation_range' for e in events(r,'climb_rejected')))
        self.assertFalse(events(r,'climb_completed'))

    def test_just_beyond_range_is_rejected_without_motion(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['A_1E1']['position_m']=['4.5999',0]
        r=run(s)
        self.assertEqual(D(r['final_states']['A_1E1']['position_m'][0]),D('4.5999'))
        self.assertEqual(r['metrics']['A_1E1']['climbs_started'],0)

    def test_non_climbable_blocks_reject_activation(self):
        rejected=events(self.result,'climb_rejected')
        self.assertTrue(any(e['actor']=='B_1E2' and e['reason']=='target_not_climbable' for e in rejected))
        s=deepcopy(SCENARIO)
        s['encounter']['participants']['B_1E2']['position_m']=['13.6',15]
        s['movement_script'][1]['target']='cube_3'
        self.assertTrue(any(e['target']=='cube_3' and e['reason']=='target_not_climbable' for e in events(run(s),'climb_rejected')))

    def test_other_character_uses_its_own_documented_climb(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['A_1E1']['character']='1E2'
        r=run(s)
        self.assertEqual(r['metrics']['A_1E1']['climbs_completed'],1)
        self.assertEqual(D(events(r,'climb_completed')[0]['time_ms']),450)

    def test_all_body_parts_finish_above_block_and_fit_its_top(self):
        parts=self.result['body_geometry']['A_1E1']['parts']
        for p in parts:
            c=list(map(D,p['centre_m']));size=list(map(D,p['size_m']))
            self.assertGreaterEqual(c[2]-size[2]/2,D('1.8'))
            self.assertGreaterEqual(c[0]-size[0]/2,D('5.1'))
            self.assertLessEqual(c[0]+size[0]/2,D('6.9'))
            self.assertGreaterEqual(c[1]-size[1]/2,D('-.9'))
            self.assertLessEqual(c[1]+size[1]/2,D('.9'))

    def test_effects_remain_excluded_by_the_geometry_test(self):
        for name,state in self.result['final_states'].items():
            for key in ('hp','armor','shield','disorientation','instability','dyspnea'):
                self.assertEqual(state[key],self.result['initial_states'][name][key])

    def test_precision_and_sampling_preserve_climb(self):
        cadence=lambda r:[e for e in r['events'] if e['type'].startswith('climb_')]
        a=cadence(self.result)
        for other in (run(precision=80),run(sample_interval_ms=137),run(sample_interval_ms=None)):
            b=cadence(other)
            self.assertEqual([(e['type'],e.get('actor')) for e in a],[(e['type'],e.get('actor')) for e in b])
            for x,y in zip(a,b):self.assertLess(abs(D(x['time_ms'])-D(y['time_ms'])),D('1e-35'))
            self.assertEqual(list(map(D,other['final_states']['A_1E1']['body_origin_m'])),[6,0,D('2.675')])

    def test_jump_after_climbing_lands_back_on_the_block(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=1500
        s['movement_script'].append({'actor':'A_1E1','at_ms':600,'action':'jump'})
        r=run(s);state=r['final_states']['A_1E1']
        self.assertEqual(list(map(D,state['body_origin_m'])),[6,0,D('2.675')])
        self.assertEqual(state['locomotion']['support_id'],'cube_1')
        self.assertEqual(D(events(r,'jump_landed')[0]['ground_z_m']),D('1.8'))
        apex=events(r,'jump_apex')[0]
        self.assertLess(abs(D(apex['height_above_ground_m'])-D('1.8')-D(512)/981),D('1e-25'))

    def test_leaving_block_edge_requires_an_authored_response(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=1500
        s['movement_script'].append({'actor':'A_1E1','at_ms':600,'action':'walk'})
        with self.assertRaisesRegex(UnsupportedMechanicError,'ledge/fall'):run(s)

    def test_walking_approach_contact_then_climb(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=1200
        s['movement_script']=[{'actor':'A_1E1','at_ms':0,'action':'walk'},
            {'actor':'A_1E1','at_ms':500,'action':'climb','target':'cube_1'}]
        r=run(s)
        self.assertEqual(r['metrics']['A_1E1']['collision_stops'],1)
        self.assertEqual(r['metrics']['A_1E1']['climbs_completed'],1)
        self.assertEqual(D(events(r,'climb_completed')[0]['time_ms']),950)

    def test_moving_request_checks_range_at_active_not_request(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['A_1E1']['position_m']=[4,0]
        s['movement_script']=[{'actor':'A_1E1','at_ms':0,'action':'walk'},
            {'actor':'A_1E1','at_ms':200,'action':'climb','target':'cube_1'}]
        r=run(s)
        request=events(r,'climb_requested')[0]
        checked=events(r,'climb_range_checked')[0]
        self.assertGreater(D(request['origin_surface_distance_squared_m2']),D('.25'))
        self.assertTrue(checked['allowed'])
        self.assertEqual(D(checked['time_ms']),350)
        self.assertEqual(D(checked['origin_m'][0]),D('4.64'))
        self.assertEqual(D(events(r,'climb_completed')[0]['time_ms']),650)
        corner=events(r,'climb_top_reached')[0]
        states=[p['states']['A_1E1'] for p in r['curve'] if p['time_ms']==corner['time_ms']]
        self.assertTrue(states)
        for state in states:
            self.assertEqual(D(state['locomotion']['velocity_mps'][2]),0)
            self.assertGreater(D(state['locomotion']['velocity_mps'][0]),0)
        self.assertEqual(list(map(D,r['final_states']['A_1E1']['body_origin_m'])),[6,0,D('2.675')])

    def test_missing_climb_definition_is_rejected(self):
        opts={k:v for k,v in OPTIONS.items() if k!='climb_definition'}
        with self.assertRaisesRegex(UnsupportedMechanicError,'explicit climb'):
            run_shared_scenario(SCENARIO,PROFILES,**opts)

    def test_blocked_top_path_is_not_allowed_to_overlap_another_body(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=1400
        s['encounter']['participants']['B_1E2'].update(position_m=['7.4',0],facing='-x')
        s['movement_script']=[{'actor':'B_1E2','at_ms':0,'action':'climb','target':'cube_1'},
            {'actor':'A_1E1','at_ms':800,'action':'climb','target':'cube_1'}]
        with self.assertRaisesRegex(UnsupportedMechanicError,'Climb path is obstructed'):run(s)

    def test_previous_special_stopping_complete_traces_are_unchanged(self):
        folder=ROOT/'results/scripted-movement-stopping'
        opts={k:json.loads((folder/f).read_text()) for k,f in [('body_definition','body_hitboxes.json'),
            ('terrain_definition','terrain.json'),('movement_definition','movement.json'),('jump_definition','jump.json')]}
        profiles=json.loads((folder/'characters.json').read_text())['characters']
        for scenario,result in [('scenario.json','run.json'),('contact_scenario.json','contact_run.json')]:
            actual=run_shared_scenario(json.loads((folder/scenario).read_text()),profiles,**opts)
            self.assertEqual(actual,json.loads((folder/result).read_text()))

    def test_moving_out_of_range_does_not_fabricate_a_collision(self):
        s=deepcopy(SCENARIO);s['encounter']['participants']['A_1E1']['position_m']=['7.1',0]
        s['movement_script']=[{'actor':'A_1E1','at_ms':0,'action':'walk'},
            {'actor':'A_1E1','at_ms':100,'action':'climb','target':'cube_1'}]
        r=run(s)
        self.assertLess(D(events(r,'climb_requested')[0]['origin_surface_distance_squared_m2']),D('.25'))
        checked=events(r,'climb_range_checked')[0]
        self.assertFalse(checked['allowed'])
        self.assertEqual(D(checked['time_ms']),250)
        self.assertEqual(D(checked['origin_m'][0]),D('7.54'))
        self.assertFalse(events(r,'movement_blocked'))
        self.assertFalse(events(r,'climb_active_started'))
        self.assertEqual(D(r['final_states']['A_1E1']['position_m'][0]),D('8.84'))
        self.assertEqual(r['final_states']['A_1E1']['locomotion']['mode'],'walking')

    def test_contact_during_gathering_does_not_erase_pending_range_check(self):
        s=deepcopy(SCENARIO)
        s['movement_script']=[{'actor':'A_1E1','at_ms':0,'action':'walk'},
            {'actor':'A_1E1','at_ms':100,'action':'climb','target':'cube_1'}]
        r=run(s)
        self.assertEqual(D(events(r,'movement_blocked')[0]['time_ms']),205)
        self.assertEqual(D(events(r,'climb_range_checked')[0]['time_ms']),250)
        self.assertEqual(D(events(r,'climb_completed')[0]['time_ms']),550)

    def test_running_gathering_and_active_start_handoff(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=2000
        s['encounter']['participants']['A_1E1']['position_m']=[0,0]
        s['movement_script']=[{'actor':'A_1E1','at_ms':t,'action':a,**({'target':'cube_1'} if a=='climb' else {})}
            for t,a in [(0,'walk'),(1000,'run'),(1300,'climb')]]
        r=run(s)
        active=events(r,'climb_active_started')[0]
        self.assertEqual(D(active['time_ms']),1480)
        self.assertEqual(D(active['origin_m'][0]),D('4.682'))
        self.assertEqual(D(active['velocity_before_climb_mps'][0]),D('6.4'))
        self.assertEqual(D(events(r,'climb_completed')[0]['time_ms']),1780)

    def test_failed_active_check_does_not_retry_when_later_near(self):
        s=deepcopy(SCENARIO);s['encounter']['duration_ms']=1900
        s['encounter']['participants']['A_1E1']['position_m']=[0,0]
        s['movement_script']=[{'actor':'A_1E1','at_ms':t,'action':a,**({'target':'cube_1'} if a=='climb' else {})}
            for t,a in [(0,'walk'),(1000,'run'),(1200,'climb')]]
        r=run(s)
        self.assertEqual(len(events(r,'climb_range_checked')),1)
        self.assertFalse(events(r,'climb_range_checked')[0]['allowed'])
        self.assertEqual(D(events(r,'climb_range_checked')[0]['time_ms']),1380)
        self.assertFalse(events(r,'climb_active_started'))
        self.assertEqual(D(events(r,'movement_blocked')[0]['time_ms']),D('1521.875'))
        self.assertEqual(D(r['final_states']['A_1E1']['position_m'][0]),D('4.95'))
