"""Exact shape queries checked against an independent polygon clipping oracle."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
import random
import unittest

from combat_sim.hitboxes import Cuboid,standing_cuboids,world_standing_cuboids
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid,boxes_overlap,place_local_cuboids
from combat_sim.character_geometry import profile_scale,scaled_definition
from tests.test_mobile_combat import BODY,PROFILES


def polygon(box):
    if isinstance(box,OrientedCuboid):
        return [box.frame.to_world_point((x*box.size_m[0]/2,y*box.size_m[1]/2,0),box.centre_m)[:2]
            for x,y in ((-1,-1),(1,-1),(1,1),(-1,1))]
    a,b=box.bounds
    return [(a[0],a[1]),(b[0],a[1]),(b[0],b[1]),(a[0],b[1])]


def polygon_intersection(first,second):
    # Sutherland-Hodgman clipping. No separating-axis projections are used.
    points=polygon(first);clip=polygon(second)
    for a,b in zip(clip,clip[1:]+clip[:1]):
        def side(p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
        output=[]
        for start,end in zip(points,points[1:]+points[:1]):
            s,t=side(start),side(end)
            if (s>=0)!=(t>=0):
                fraction=s/(s-t);output.append(tuple(x+(y-x)*fraction for x,y in zip(start,end)))
            if t>=0:output.append(end)
        points=output
        if not points:break
    return points


def area(points):
    return abs(sum((a[0]*b[1]-a[1]*b[0] for a,b in zip(points,points[1:]+points[:1])),F(0)))/2


class OrientedGeometryTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=70));context.__enter__();self.addCleanup(context.__exit__,None,None,None)
        self.frame=YawFrame(F(3,5),F(4,5));self.box=OrientedCuboid('torso',(0,0,0),(4,'.2',2),self.frame)

    def test_enclosing_bounds_match_vertices_without_defining_the_solid(self):
        low,high=self.box.bounds;vertices=self.box.vertices()
        self.assertEqual(low,tuple(min(p[i] for p in vertices) for i in range(3)))
        self.assertEqual(high,tuple(max(p[i] for p in vertices) for i in range(3)))
        self.assertTrue(all(self.box.contains(p) for p in vertices))

    def test_enclosing_aabb_corner_is_not_inside_the_rotated_body(self):
        point=(F('1.6'),F('1.2'),0);aabb=Cuboid('broad',(0,0,0),tuple(b-a for a,b in zip(*self.box.bounds)))
        self.assertTrue(aabb.contains(point));self.assertFalse(self.box.contains(point))

    def test_sphere_rejects_false_aabb_corner_hit(self):
        self.assertFalse(self.box.intersects_sphere(('1.6','1.2',0),'.01'))

    def test_sphere_tangency_uses_exact_local_distance(self):
        point=self.frame.to_world_point(('2.1',0,0))
        self.assertTrue(self.box.intersects_sphere(point,'.1'))
        self.assertFalse(self.box.intersects_sphere(point,'.099999999999'))

    def test_rounded_sphere_corner_does_not_become_an_expanded_box(self):
        point=self.frame.to_world_point(('2.09','.19',0))
        self.assertFalse(self.box.intersects_sphere(point,'.1'))

    def test_vertical_column_uses_oriented_footprint(self):
        self.assertFalse(self.box.intersects_vertical_column(('1.6','1.2'),'.01'))
        point=self.frame.to_world_point(('2.1',0,0))
        self.assertTrue(self.box.intersects_vertical_column(point[:2],'.1'))

    def test_closest_point_is_world_point_on_the_actual_shape(self):
        point=self.frame.to_world_point(('2.2','.3','1.1'))
        expected=self.frame.to_world_point((2,'.1',1))
        self.assertEqual(self.box.closest_point(point),expected)
        self.assertTrue(self.box.contains(expected))

    def test_segment_intersection_has_exact_local_entry_and_exit(self):
        a,b=(self.frame.to_world_point(p) for p in ((-3,0,0),(3,0,0)))
        self.assertEqual(self.box.segment_interval(a,b),(F(1,6),F(5,6)))

    def test_segment_through_enclosing_corner_misses(self):
        self.assertIsNone(self.box.segment_interval(('1.6','1.2',-3),('1.6','1.2',3)))

    def test_straight_sphere_sweep_returns_world_coordinates(self):
        a,b=(self.frame.to_world_point(p) for p in ((-3,0,0),(3,0,0)))
        hit=self.box.swept_sphere_contact(a,b,'.1')
        self.assertEqual(hit.parameter,D('.15'))
        self.assertEqual(tuple(map(F,hit.centre_m)),self.frame.to_world_point(('-2.1',0,0)))
        self.assertEqual(tuple(map(F,hit.closest_box_point_m)),self.frame.to_world_point((-2,0,0)))

    def test_straight_sweep_miss_does_not_use_enclosing_box(self):
        self.assertIsNone(self.box.swept_sphere_contact(('1.6','1.2',-3),('1.6','1.2',3),'.01'))

    def test_oriented_box_overlap_rejects_enclosing_corner(self):
        other=Cuboid('other',('1.6','1.2',0),('.05',)*3)
        self.assertFalse(boxes_overlap(self.box,other));self.assertFalse(boxes_overlap(other,self.box))

    def test_closed_touch_and_interior_overlap_are_distinct(self):
        other=OrientedCuboid('other',self.frame.to_world_point((4,0,0)),(4,'.2',2),self.frame)
        self.assertTrue(boxes_overlap(self.box,other));self.assertFalse(boxes_overlap(self.box,other,closed=False))

    def test_independent_polygon_oracle_checks_mixed_orientations(self):
        rng=random.Random(13)
        for i in range(120):
            def box(name):
                frame=YawFrame.from_half_angle_tangent(F(rng.randrange(-5,6),rng.randrange(1,7)))
                return OrientedCuboid(name,(F(rng.randrange(-20,21),5),F(rng.randrange(-20,21),5),0),
                    (F(rng.randrange(1,20),5),F(rng.randrange(1,20),5),2),frame)
            first,second=box('a'),box('b');points=polygon_intersection(first,second)
            self.assertEqual(boxes_overlap(first,second,closed=False),area(points)>0,(i,first,second))
            self.assertEqual(boxes_overlap(first,second),bool(points),(i,first,second))

    def test_all_six_body_profiles_preserve_legacy_cardinal_placement(self):
        for profile in ('1E1','1E2','1E3','1E5','2E4','3E5'):
            body=scaled_definition(BODY,profile_scale(BODY,PROFILES[profile]))
            for heading,facing in ((0,'+x'),(180,'-x')):
                origin=(10,-20,-F(str(body['standing_placement']['ground_z_m'])))
                actual=place_local_cuboids(standing_cuboids(body),origin,YawFrame.from_degrees(heading))
                expected=world_standing_cuboids(body,origin,facing)
                self.assertEqual([(b.part,b.bounds) for b in actual],[(b.part,b.bounds) for b in expected])

    def test_arbitrary_frame_placement_keeps_source_dimensions_and_feet_plane(self):
        parts=place_local_cuboids(standing_cuboids(BODY),(5,7,F(7,8)),YawFrame.from_degrees(37))
        self.assertEqual(len(parts),6)
        self.assertEqual(min(p.bounds[0][2] for p in parts),0)
        for p,local in zip(parts,standing_cuboids(BODY)):
            self.assertEqual(p.size_m,local.size_m)
            self.assertEqual(p.frame.to_local_point(p.centre_m,(5,7,F(7,8))),local.centre_m)

    def test_translation_preserves_exact_shape_queries(self):
        shift=(10**10,-10**8,17)
        other=OrientedCuboid('other',shift,self.box.size_m,self.frame)
        for p in self.box.vertices():self.assertTrue(other.contains(tuple(a+b for a,b in zip(p,shift))))

    def test_invalid_shape_and_placement_inputs_are_rejected(self):
        for size in ((0,1,1),(-1,1,1),(1,True,1),(1,'NaN',1)):
            with self.subTest(size=size),self.assertRaises(ValueError):OrientedCuboid('bad',(0,0,0),size,self.frame)
        with self.assertRaises(ValueError):OrientedCuboid('bad',(0,0,0),(1,1,1),None)
        with self.assertRaises(ValueError):place_local_cuboids((self.box,),(0,0,0),self.frame)
        with self.assertRaises(ValueError):self.box.intersects_vertical_column((1,2,3),1)
        with self.assertRaises(ValueError):self.box.swept_sphere_contact((0,0,0),(1,0,0),1,precision=True)

    def test_deployed_registry_retains_oriented_shape_and_exact_frame(self):
        from combat_sim.world_colliders import ColliderRegistry
        registry=ColliderRegistry()
        obj=registry.add((self.box,),time=0,source='fixture:orientation_boundary')
        self.assertEqual(obj.parts,(self.box,))
        self.assertEqual(obj.record()['parts'][0]['yaw_frame'],self.frame.record())
        self.assertEqual(obj.record()['parts'][0]['shape'],'oriented_cuboid')

    def test_shared_world_admits_fixed_actor_yaw_with_true_body_shapes(self):
        from tests.test_equilibrium_combat import scene,run
        s=scene(100);s['encounter']['participants']['A']['facing']={'yaw_degrees':37}
        r=run(s);self.assertIn('yaw_frame',r['final_states']['A']['facing'])
        self.assertTrue(all(p['shape']=='oriented_cuboid' for p in r['body_geometry']['A']['parts']))

