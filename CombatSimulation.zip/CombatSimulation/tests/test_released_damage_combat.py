"""Labelled shared rate API probes; no claim that a fence was summoned.

Actual beams, gun deaths, revival and HP credit use the ordinary shared engine.
The API release references existing 1E2 ability5 without acquiring an action.
"""
from copy import deepcopy
from decimal import Context, Decimal as D, getcontext, localcontext
from types import SimpleNamespace
import unittest

from combat_sim.shared_engine import SharedEncounter
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from tests.test_mobile_combat import read, events
from tests.test_motion_boundary_combat import scene as base_scene
from tests.test_world_colliders_combat import wall

FILES = {
    'body_definition': 'data/body_hitboxes.json',
    'terrain_definition': 'data/terrain/stationary_arena.json',
    'movement_definition': 'data/movement/walk_run.json',
    'combat_locomotion_definition': 'data/movement/combat_locomotion.json',
    'projectile_physics_definition': 'data/physics/projectile_gravity.json',
    'jump_definition': 'data/movement/combat_jump.json',
    'climb_definition': 'data/movement/combat_climb.json',
}


def scene(duration=1000, *, shield=0, hp=None, character='1E2'):
    s = base_scene(duration, (0, -20))
    s['id'] = 'released_electrocution_shared_api'
    target = s['encounter']['participants']['B']
    target['character'] = character
    target['initial_state']['shield'] = shield
    if hp is not None:
        target['initial_state']['hp'] = hp
    return s


def packet(w, *, actor='A', target='B'):
    return {'actor': actor, 'ability': '5', 'action_id': 7000001,
            'source_life_generation': w.fighters[actor].life_generation,
            'target': target, 'target_life_generation': w.fighters[target].life_generation}


def release(w, **kw):
    values = {'damage_type': 'electrocution', 'base_dps': 800, 'until_ms': 1000}
    values.update(kw)
    return w.controlled_damage.start_released(packet(w), **values)


class RateProbe(SharedEncounter):
    """Explicit existing engineering interfaces, never character abilities."""
    def schedule_probe(self, time, operation, **values):
        self.push(time, 'released_damage_probe', {'operation': operation, **values}, priority=4)

    def _process(self, kind, p):
        if kind != 'released_damage_probe':
            return super()._process(kind, p)
        operation = p['operation']
        if operation == 'resistance':
            self.fighters['B'].profile['resistances']['electrocution'] = p['value']
        elif operation == 'armor':
            self.fighters['B'].armor = D(p['value'])
        elif operation == 'damage_collider':
            self.collider_system.damage(p['collider'], p['amount'], source='labelled_rate_probe', damage_type='blunt')
        elif operation == 'restore':
            assert self.life_cycles.revive(p['actor'], expected_generation=p['generation'], hp=p['hp'], source='labelled_rate_probe')
        elif operation == 'redeliver':
            release(self, until_ms=p['until_ms'])
        elif operation == 'end_stream':
            self.controlled_damage.end(self.controlled_damage.streams[p['stream_id']], 'contact_left')
        else:
            raise ValueError('Unknown labelled rate probe')
        self.log('released_damage_probe', **p, meaning='Shared API foundation, not an authored delivery')


def world(s, *, precision=50, interval=None, profiles=None, rules=None):
    inputs = {k: read(v) for k, v in FILES.items()}
    if rules is not None:
        inputs['combat_locomotion_definition'] = rules
    return RateProbe(s, deepcopy(profiles or read('data/characters.json')['characters']),
                     precision=precision, sample_interval_ms=interval, **inputs)


class ReleasedDamageCombatTests(unittest.TestCase):
    def setUp(self):
        ctx = localcontext(Context(prec=80))
        ctx.__enter__()
        self.addCleanup(ctx.__exit__, None, None, None)

    def conserved(self, r):
        ledger = DamageLedger.from_record(r['applied_hp_history'])
        healing = HealingHistory.from_run(r)
        for name, lives in r['actor_lives'].items():
            supplied = sum((D(l['initial_hp']) for l in lives), D(0)) + healing.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-ledger.amount(target=name)), D('1e-8'))
        return ledger

    def test_actual_hp_commit_uses_live_electrocution_resistance_without_armor_or_bleed(self):
        w = world(scene())
        release(w)
        r = w.run()
        ledger = self.conserved(r)
        self.assertLess(abs(ledger.amount(actor='A')-D('771.875')), D('1e-9'))
        self.assertEqual({e.contribution.kind for e in ledger.entries}, {'electrocution'})
        self.assertFalse(events(r, 'bleeding_started'))
        self.assertEqual(D(r['final_states']['B']['armor']), 150)
        self.assertEqual(r['controlled_damage_streams'], [])

    def test_released_pressure_spends_no_effort_and_acquires_no_body_or_hand(self):
        w = world(scene())
        w.fighters['A'].dyspnea = D(40)
        release(w)
        self.assertFalse(w.fighters['A'].live_actions())
        r = w.run()
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']), 0)
        self.assertFalse(r['continuous_effort_channels'])
        self.assertEqual(D(r['final_states']['A']['dyspnea']), 10)
        self.assertTrue(r['released_damage_streams'][0]['autonomous'])
        self.assertNotIn('category', r['released_damage_streams'][0])

    def test_positive_shield_and_exhaustion_use_the_existing_joint_timeline(self):
        w = world(scene(shield=100))
        release(w)
        r = w.run()
        ledger = self.conserved(r)
        self.assertEqual(D(r['final_states']['B']['shield']), 0)
        self.assertLess(abs(D(r['metrics']['B']['shield_damage_received'])-100), D('1e-9'))
        self.assertLess(abs(ledger.amount(actor='A')-D('771.875')*D('.875')), D('1e-8'))

    def test_regeneration_intercepts_raw_pressure_before_resistance(self):
        w = world(scene())
        w.shield_recovery['B'].add_impact(D(-20000), D(4000))
        release(w)
        r = w.run()
        ledger = self.conserved(r)
        self.assertLess(abs(ledger.amount(actor='A')-D('343.75')), D('1e-8'))
        self.assertLess(abs(D(r['metrics']['B']['shield_damage_received'])-400), D('1e-8'))

    def test_simultaneous_released_sources_share_one_recovery_budget(self):
        w = world(scene())
        w.shield_recovery['B'].add_impact(D(-20000), D(4000))
        first = release(w)
        second = release(w, base_dps=400)
        r = w.run()
        ledger = self.conserved(r)
        expected = (D(800)*D(2)/3-D(150)**2/(D(800)*D(2)/3)
                    +D(400)*D(2)/3-D(150)**2/(D(400)*D(2)/3))
        self.assertLess(abs(ledger.amount(actor='A')-expected), D('1e-8'))
        self.assertNotEqual(first.id, second.id)
        self.assertLess(abs(D(r['metrics']['B']['shield_damage_received'])-400), D('1e-8'))

    def test_source_instability_and_action_cancellation_cannot_weaken_released_pressure(self):
        w = world(scene())
        w.fighters['A'].instability = D(80)
        stream = release(w)
        w.controlled_damage.action_cancelled(w.fighters['A'], SimpleNamespace(id=7000001), 'probe_cancel')
        r = w.run()
        self.assertLess(abs(self.conserved(r).amount(actor='A')-D('771.875')), D('1e-8'))
        self.assertEqual((stream.ended_at_ms, stream.end_reason), (1000, 'duration_expired'))

    def test_live_resistance_change_invalidates_only_the_ongoing_response(self):
        w = world(scene())
        release(w)
        w.schedule_probe(400, 'resistance', value=300)
        r = w.run()
        self.assertLess(abs(self.conserved(r).amount(actor='A')-D('721.25')), D('1e-8'))

    def test_armor_change_does_not_change_electrical_damage(self):
        w = world(scene())
        release(w)
        w.schedule_probe(400, 'armor', value=900)
        r = w.run()
        self.assertLess(abs(self.conserved(r).amount(actor='A')-D('771.875')), D('1e-8'))

    def test_real_gun_kills_source_but_released_damage_keeps_original_life(self):
        s = scene()
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        s['encounter']['participants']['B']['position_m'] = [2, -20]
        s['action_selection']['B']['start_ms'] = 0
        w = world(s)
        stream = release(w)
        r = w.run()
        ledger = self.conserved(r)
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertLess(D(r['final_states']['A']['died_at_ms']), 200)
        self.assertEqual(stream.ended_at_ms, 1000)
        electrical = [e for e in ledger.entries if e.contribution.kind == 'electrocution']
        self.assertLess(abs(sum(e.amount for e in electrical)-D('771.875')), D('1e-8'))
        self.assertEqual({e.contribution.source.life_generation for e in electrical}, {1})

    def test_source_restoration_does_not_reassign_a_previously_released_effect(self):
        s = scene(400)
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        s['encounter']['participants']['B']['position_m'] = [2, -20]
        s['action_selection']['B'].update(start_ms=0)
        # Observe restoration before the next ordinary firing cycle.
        w = world(s)
        release(w, until_ms=400)
        w.schedule_probe(200, 'restore', actor='A', generation=1, hp=500)
        r = w.run()
        ledger = self.conserved(r)
        self.assertEqual(r['final_states']['A']['life_generation'], 2)
        self.assertEqual(r['released_damage_streams'][0]['source_life_generation'], 1)
        self.assertLess(abs(ledger.amount(target='B')-D('308.75')), D('1e-8'))

    def test_recipient_death_retires_attachment_before_restoration(self):
        w = world(scene(hp=100))
        stream = release(w)
        w.schedule_probe(300, 'restore', actor='B', generation=1, hp=500)
        r = w.run()
        ledger = self.conserved(r)
        death = D(r['actor_lives']['B'][0]['died_at_ms'])
        self.assertLess(abs(death-D(100000)/D('771.875')), D('1e-8'))
        self.assertEqual(stream.ended_at_ms, death)
        self.assertEqual(stream.end_reason, 'recipient_life_ended')
        self.assertEqual(D(r['final_states']['B']['hp']), 500)
        self.assertLess(abs(ledger.amount(target='B')-100), D('1e-8'))

    def test_fresh_delivery_can_attach_to_a_later_recipient_life(self):
        w = world(scene(hp=100))
        release(w)
        w.schedule_probe(300, 'restore', actor='B', generation=1, hp=500)
        w.schedule_probe(400, 'redeliver', until_ms=800)
        r = w.run()
        self.conserved(r)
        self.assertEqual([row['target_life_generation'] for row in r['released_damage_streams']], [1, 2])
        self.assertLess(abs(D(r['final_states']['B']['hp'])-D('191.25')), D('1e-8'))

    def test_material_destruction_ends_only_its_own_released_pressure(self):
        s = scene()
        s['initial_colliders'] = [wall('support', x=10, hp=2000), wall('other', x=15, hp=2000)]
        w = world(s)
        stream = release(w, source_collider='support')
        w.schedule_probe(200, 'damage_collider', collider='other', amount=2000)
        w.schedule_probe(400, 'damage_collider', collider='support', amount=2000)
        r = w.run()
        self.assertEqual((stream.ended_at_ms, stream.end_reason), (400, 'source_collider_ended'))
        self.assertLess(abs(self.conserved(r).amount(actor='A')-D('308.75')), D('1e-8'))

    def test_material_expiry_and_damage_expiry_are_both_half_open(self):
        s = scene()
        support = wall('support', x=10, hp=2000)
        support['duration_ms'] = 400
        s['initial_colliders'] = [support]
        w = world(s)
        stream = release(w, source_collider='support')
        r = w.run()
        self.assertEqual(stream.ended_at_ms, 400)
        self.assertLess(abs(self.conserved(r).amount(actor='A')-D('308.75')), D('1e-8'))
        w = world(scene())
        stream = release(w, until_ms=400)
        r = w.run()
        self.assertEqual((stream.ended_at_ms, stream.end_reason), (400, 'duration_expired'))
        self.assertLess(abs(self.conserved(r).amount(actor='A')-D('308.75')), D('1e-8'))

    def test_spatial_caller_can_end_contact_without_residual_damage(self):
        w = world(scene())
        stream = release(w)
        w.schedule_probe(400, 'end_stream', stream_id=stream.id)
        r = w.run()
        self.assertEqual(stream.end_reason, 'contact_left')
        self.assertLess(abs(self.conserved(r).amount(actor='A')-D('308.75')), D('1e-8'))

    def test_actual_beam_and_released_damage_mix_without_partition_dependence(self):
        results = []
        for precision, interval, reverse in ((50, None, False), (50, 137, False), (80, 17, True)):
            s = scene(shield=1000)
            s['encounter']['participants']['C'] = deepcopy(s['encounter']['participants']['A'])
            s['encounter']['participants']['C'].update(character='1E1', position_m=[29, -18])
            s['action_selection']['C'] = dict(s['action_selection']['A'], abilities=['4'], start_ms=0)
            if reverse:
                s['encounter']['participants'] = dict(reversed(list(s['encounter']['participants'].items())))
            with localcontext(Context(prec=precision)):
                w = world(s, precision=precision, interval=interval)
                release(w)
                r = w.run()
            ledger = self.conserved(r)
            kinds = {e.contribution.kind for e in ledger.entries if e.target == 'B'}
            self.assertEqual(kinds, {'electrocution', 'heat'})
            self.assertEqual(D(r['final_states']['B']['shield']), 0)
            results.append(D(r['final_states']['B']['hp']))
        for hp in results[1:]:
            self.assertLess(abs(hp-results[0]), D('1e-8'))

    def test_existing_passive_healing_consumes_actual_clipped_electrical_history(self):
        s = scene(character='2E4', hp=4000)
        s['encounter']['participants']['B']['position_m'] = ['.6', -20]
        s['action_selection']['B'].update(abilities=['1'], start_ms=0, reload_when_empty=False)
        w = world(s)
        release(w)
        r = w.run()
        self.conserved(r)
        self.assertTrue(events(r, 'melee_contact'))
        self.assertGreater(D(r['metrics']['B']['hp_healed']), 0)
        self.assertTrue(r['healing_history']['entries'])

    def test_actual_death_revive_does_not_inherit_the_old_electrical_attachment(self):
        s = scene(3500, character='2E4', hp=500)
        s['encounter']['participants']['B']['position_m'] = ['.6', -20]
        s['action_selection']['B'].update(abilities=['1'], start_ms=0, reload_when_empty=False)
        w = world(s)
        stream = release(w)
        r = w.run()
        ledger = self.conserved(r)
        self.assertTrue(events(r, 'life_restored'))
        self.assertGreaterEqual(r['final_states']['B']['life_generation'], 2)
        self.assertEqual(stream.ended_at_ms, D(r['actor_lives']['B'][0]['died_at_ms']))
        self.assertLess(stream.ended_at_ms, 1000)
        electrical = [e for e in ledger.entries if e.contribution.kind == 'electrocution']
        self.assertTrue(electrical)
        self.assertEqual({e.target_life_generation for e in electrical}, {1})

    def test_direct_api_owns_declared_precision_across_fractional_actual_revival(self):
        results = []
        for ambient in (28, 50, 80):
            with localcontext(Context(prec=ambient)):
                s = scene(3500, character='2E4', hp=500)
                s['encounter']['participants']['B']['position_m'] = ['.6', -20]
                s['action_selection']['B'].update(abilities=['1'], start_ms=0, reload_when_empty=False)
                w = world(s, precision=50)
                release(w)
                r = w.run()
                self.assertEqual(getcontext().prec, ambient)
                self.assertTrue(events(r, 'life_restored'))
                results.append(r)
        self.assertEqual(results[0], results[1])
        self.assertEqual(results[1], results[2])

    def test_direct_queue_normalizes_an_overprecise_future_clock_without_time_nudges(self):
        results = []
        timestamp = D('400.123456789012345678901234567890123456789012345678901234567890123456789')
        with localcontext(Context(prec=50)):
            expected = str(+timestamp)
        for ambient in (50, 80):
            with localcontext(Context(prec=ambient)):
                w = world(scene(), precision=50)
                release(w)
                w.schedule_probe(timestamp, 'resistance', value=300)
                r = w.run()
                self.assertEqual(events(r, 'released_damage_probe')[0]['time_ms'], expected)
                results.append(r)
        self.assertEqual(results[0], results[1])

    def test_owned_constriction_and_released_electricity_share_the_same_registry_and_stock(self):
        from tests.test_continuous_effort_combat import owner
        s = scene()
        s['encounter']['participants']['D'] = deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['D'].update(character='1E5', position_m=[0, -30])
        s['action_selection']['D'] = deepcopy(s['action_selection']['A'])
        w = world(s)
        w.shield_recovery['B'].add_impact(D(-20000), D(4000))
        release(w)
        action = owner(w, name='D')
        w.controlled_damage.start(w.fighters['D'], action, 'B', base_dps=900, until_ms=1000)
        r = w.run()
        ledger = self.conserved(r)
        electrical = D(800)*13/17
        intrinsic = D(900)*13/17
        self.assertLess(abs(ledger.amount(actor='A')-(electrical-150**2/electrical)), D('1e-8'))
        self.assertLess(abs(ledger.amount(actor='D')-(intrinsic-D(25)*150**2/(4*intrinsic))), D('1e-8'))
        self.assertEqual(len(r['released_damage_streams']), 1)
        self.assertEqual(len(r['controlled_damage_streams']), 1)

    def test_actual_beam_destroys_material_source_and_ends_its_electrical_pressure(self):
        s = scene()
        material = wall('material', x=30, hp=250, size=('.1', '1.8', '1.8'), z='.9')
        material['parts'][0]['centre_m'][1] = '-18.5'
        s['initial_colliders'] = [material]
        s['encounter']['participants']['C'] = deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(character='1E1', position_m=[29, -18])
        s['action_selection']['C'] = dict(s['action_selection']['A'], abilities=['4'], start_ms=0)
        w = world(s)
        stream = release(w, source_collider='material')
        r = w.run()
        ledger = self.conserved(r)
        removal = next(e for e in events(r, 'world_collider_removed') if e['collider']['id'] == 'material')
        self.assertEqual(removal['collider']['status'], 'destroyed')
        self.assertEqual(stream.ended_at_ms, D(removal['time_ms']))
        self.assertLess(stream.ended_at_ms, 1000)
        self.assertEqual(stream.end_reason, 'source_collider_ended')
        self.assertLess(abs(ledger.amount(actor='A')-D('771.875')*stream.ended_at_ms/1000), D('1e-8'))

    def test_later_released_contact_can_arrive_after_source_death(self):
        s = scene(400)
        s['encounter']['participants']['A']['initial_state']['hp'] = 1
        s['encounter']['participants']['B']['position_m'] = [2, -20]
        s['action_selection']['B']['start_ms'] = 0
        w = world(s)
        w.schedule_probe(200, 'redeliver', until_ms=400)
        r = w.run()
        ledger = self.conserved(r)
        self.assertFalse(r['final_states']['A']['alive'])
        self.assertLess(D(r['final_states']['A']['died_at_ms']), 200)
        self.assertEqual(D(r['released_damage_streams'][0]['started_at_ms']), 200)
        self.assertLess(abs(ledger.amount(target='B')-D('154.375')), D('1e-8'))

    def test_invalid_release_is_atomic_and_cannot_consume_identity_or_queue_work(self):
        w = world(scene())
        base = packet(w)
        invalid = [dict(base, source_life_generation=999), dict(base, target_life_generation=2),
                   dict(base, ability='invented'), dict(base, action_id=True),
                   dict(base, projectile_id='')]
        before = len(w.queue)
        for p in invalid:
            with self.subTest(packet=p), self.assertRaises(ValueError):
                w.controlled_damage.start_released(p, damage_type='electrocution', base_dps=800, until_ms=1000)
            self.assertEqual(len(w.queue), before)
            self.assertFalse(w.controlled_damage.streams)
        self.assertEqual(release(w).id, 'released-rate:1')

    def test_frozen_rules_reject_new_release_without_changing_existing_result_schema(self):
        cfg = read('data/movement/combat_locomotion.json')
        cfg.pop('released_rate_damage')
        w = world(scene(1), rules=cfg)
        with self.assertRaises(UnsupportedMechanicError):
            release(w)
        r = w.run()
        self.assertNotIn('released_damage_streams', r)
        self.assertNotIn('released_rate_damage_rules', r)

    def test_unknown_rules_and_invalid_pressure_or_material_reject_before_mutation(self):
        cfg = read('data/movement/combat_locomotion.json')
        cfg['released_rate_damage']['mode'] = 'unknown'
        with self.assertRaises(UnsupportedMechanicError):
            world(scene(), rules=cfg)
        w = world(scene())
        count = len(w.queue)
        for kw in ({'base_dps': True}, {'base_dps': 0}, {'base_dps': -1}, {'base_dps': 'NaN'},
                   {'until_ms': 0}, {'source_collider': 'missing'}):
            with self.subTest(parameters=kw), self.assertRaises(ValueError):
                release(w, **kw)
            self.assertEqual(len(w.queue), count)
            self.assertFalse(w.controlled_damage.streams)
        with self.assertRaises(UnsupportedMechanicError):
            release(w, damage_type='unknown')
        self.assertEqual(release(w).id, 'released-rate:1')


if __name__ == '__main__':
    unittest.main()
