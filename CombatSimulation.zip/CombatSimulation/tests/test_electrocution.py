"""Primary electrical response and mixed continuous layer allocation."""
from decimal import Context, Decimal as D, localcontext
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.electrocution import damage_rate
from combat_sim.mechanics.delayed_shield import DelayedShieldRecovery
from combat_sim.mechanics.rate_damage import RateDamageSource
from combat_sim.mechanics.recovery_flow import AffineRate, RootRate
from combat_sim.mechanics.thermal_balance import ThermalSource, build_thermal_plan


def source(name='electric', raw=800, resistance=150):
    return RateDamageSource(name, AffineRate(raw, 1000, 0), D(0),
                            family='electrocution', resistance=D(resistance))


def plan(*sources, shield=0, recovery=0):
    manager = DelayedShieldRecovery(1, recovery or 400)
    if recovery:
        manager.add_impact(D(0), D(10000))
    return build_thermal_plan(manager.plan(D(1000), D(2000)), D(shield), sources)


class ElectrocutionTests(unittest.TestCase):
    def setUp(self):
        ctx = localcontext(Context(prec=70))
        ctx.__enter__()
        self.addCleanup(ctx.__exit__, None, None, None)

    def test_source_formula_is_exact_and_ignores_armor(self):
        self.assertEqual(damage_rate(800, 150), F(6175, 8))
        self.assertEqual(damage_rate('800.5', '150.25'), F(9891603, 12808))

    def test_zero_rate_and_resistance_threshold_are_safe(self):
        for raw, resistance in ((0, 0), (0, 150), (150, 150), (100, 150)):
            self.assertEqual(damage_rate(raw, resistance), 0)
        self.assertEqual(damage_rate(800, 0), 800)

    def test_invalid_numeric_domains_reject(self):
        for raw, resistance in ((-1, 0), (1, -1), (True, 0), (1, False),
                                ('NaN', 0), (1, 'Infinity')):
            with self.subTest(raw=raw, resistance=resistance), self.assertRaises(ValueError):
                damage_rate(raw, resistance)

    def test_rate_source_requires_family_specific_defenses(self):
        with self.assertRaises(ValueError):
            RateDamageSource('x', AffineRate(800, 0, 0), D(150), family='electrocution')
        with self.assertRaises(ValueError):
            RateDamageSource('x', AffineRate(800, 0, 0), D(150), resistance=D(10))
        with self.assertRaises(ValueError):
            RateDamageSource('x', AffineRate(800, 0, 0), D(0), family='unknown')

    def test_overflow_is_mitigated_after_shield_allocation(self):
        s = source()
        self.assertEqual(s.hp_rate(D(1000), D('.5')), D('343.75'))
        self.assertEqual(s.hp_rate(D(1000), D(1)), 0)
        self.assertEqual(s.hp_rate(D(1000), D('.9')), 0)
        self.assertEqual(s.q_incident(D(2000)), 0)
        for fraction in (D('-.1'), D('1.1')):
            with self.assertRaises(ValueError):
                s.hp_rate(D(1000), fraction)

    def test_unshielded_body_gets_one_second_of_electrical_rate(self):
        stock, q, hp, shield = plan(source()).at(D(2000))
        self.assertEqual((stock, q, shield), (0, (D(0),), (D(0),)))
        self.assertLess(abs(hp[0]-D('771.875')), D('1e-20'))

    def test_positive_shield_absorbs_raw_pressure_without_body_memory(self):
        stock, q, hp, shield = plan(source(), shield=1000).at(D(2000))
        self.assertEqual((stock, q, hp, shield), (200, (D(0),), (D(0),), (D(800),)))

    def test_electrical_pressure_exhausts_shield_at_the_exact_boundary(self):
        p = plan(source(), shield=100)
        self.assertTrue(p.depleted)
        self.assertLess(abs(p.end-D(1125)), D('1e-24'))
        self.assertEqual(p.at(p.end)[2], (D(0),))
        self.assertLess(abs(p.at(p.end)[3][0]-100), D('1e-24'))

    def test_zero_stock_regeneration_is_shared_before_electrical_resistance(self):
        stock, _, hp, shield = plan(source(), recovery=400).at(D(2000))
        self.assertEqual(stock, 0)
        self.assertEqual(shield, (D(400),))
        self.assertLess(abs(hp[0]-D('343.75')), D('1e-20'))

    def test_sufficient_resistance_and_regeneration_prevent_hp_damage(self):
        stock, _, hp, shield = plan(source(), recovery=700).at(D(2000))
        self.assertEqual((stock, hp, shield), (0, (D(0),), (D(700),)))

    def test_two_sources_share_supply_proportionally_before_individual_resistance(self):
        stock, _, hp, shield = plan(source('a'), source('b', raw=400), recovery=600).at(D(2000))
        self.assertEqual((stock, shield), (0, (D(400), D(200))))
        for actual, expected in zip(hp, (D('343.75'), D('87.5'))):
            self.assertLess(abs(actual-expected), D('1e-20'))

    def test_electrocution_and_constriction_use_different_defenses_on_one_flow(self):
        constriction = RateDamageSource('drag', AffineRate(800, 1000, 0), D(150))
        stock, _, hp, shield = plan(source(), constriction, recovery=800).at(D(2000))
        self.assertEqual((stock, shield), (0, (D(400), D(400))))
        for actual, expected in zip(hp, (D('343.75'), D('48.4375'))):
            self.assertLess(abs(actual-expected), D('1e-20'))

    def test_heat_and_electrical_pressure_share_one_stock_exhaustion(self):
        heat = ThermalSource('heat', RootRate(400, 0, 1000, 1), D(0), D(300), True, False)
        p = plan(source(), heat, shield=1000)
        self.assertTrue(p.depleted)
        seconds = (p.end-1000)/1000
        self.assertLess(abs(800*seconds+D(800)/3*seconds**D('1.5')-1000), D('1e-20'))
        self.assertEqual(p.at(p.end)[2], (D(0), D(0)))
        self.assertLess(abs(sum(p.at(p.end)[3])-1000), D('1e-20'))

    def test_dense_electrical_dose_is_additive_across_arbitrary_observations(self):
        p = plan(source(), recovery=400)
        times = list(map(D, (1000, 1017, 1137, 1500, 1831, 2000)))
        pieces = sum(p.at(b)[2][0]-p.at(a)[2][0] for a, b in zip(times, times[1:]))
        self.assertLess(abs(pieces-p.at(D(2000))[2][0]), D('1e-50'))


if __name__ == '__main__':
    unittest.main()
