"""Get Up interacts with real shared combat, resources and cancellation."""
from copy import deepcopy
from decimal import Context, Decimal as D, localcontext
import json
from pathlib import Path
import unittest

from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter, run_shared_scenario


ROOT = Path(__file__).resolve().parents[1]
PROFILES = json.loads((ROOT/'data/characters.json').read_text())['characters']
DEFINITION = json.loads((ROOT/'data/movement/get_up.json').read_text())
TEMPLATE = json.loads((ROOT/'scenarios/stationary_2v2.json').read_text())


def scenario(*, horizon=1200, hp=8140, dyspnea=0, gun_start=200000):
    s = deepcopy(TEMPLATE)
    s['id'] = 'get_up_combat_test'
    s['common_abilities'] = ['get_up']
    s['encounter']['duration_ms'] = horizon
    s['encounter']['participants'] = {
        'caster': {'character': '1E1', 'team': 'A', 'position_m': [0, 0],
                   'initial_state': {'shield': 0, 'hp': hp,
                                     'dyspnea': dyspnea, 'knocked_down': True}},
        'gunner': {'character': '1E2', 'team': 'B', 'position_m': [30, 0],
                   'initial_state': {'shield': 0}},
    }
    s['action_selection'] = {
        'caster': {'kind': 'priority_when_ready', 'target': 'nearest_living_enemy',
                   'abilities': ['1']},
        'gunner': {'kind': 'priority_when_ready', 'target': 'nearest_living_enemy',
                   'abilities': ['1'], 'reload_when_empty': True, 'start_ms': gun_start},
    }
    return s


def run(s=None, **kwargs):
    return run_shared_scenario(s or scenario(), PROFILES,
                               get_up_definition=DEFINITION, **kwargs)


def events(result, kind, actor='caster'):
    return [e for e in result['events'] if e['type'] == kind and e.get('actor') == actor]


class EffectEncounter(SharedEncounter):
    """Inject an existing ability effect, without creating a fake ability."""
    def _process(self, kind, payload):
        if kind == 'test_knockdown':
            return self.apply_knockdown(payload['actor'], source='test effect')
        return super()._process(kind, payload)


def with_knockdowns(s, times):
    with localcontext(Context(prec=50)):
        e = EffectEncounter(s, PROFILES, get_up_definition=DEFINITION)
        for time in times:
            e.push(time, 'test_knockdown', {'actor': 'caster'}, priority=2)
        return e.run()


class SharedGetUpTests(unittest.TestCase):
    def test_get_up_blocks_attacks_until_completion_then_combat_resumes(self):
        r = run()
        self.assertEqual(events(r, 'get_up_started')[0]['time_ms'], '0')
        self.assertEqual(events(r, 'get_up_completed')[0]['time_ms'], '400')
        self.assertEqual(events(r, 'ability_started')[0]['time_ms'], '400')
        self.assertEqual(events(r, 'projectile_released')[0]['time_ms'], '798')
        self.assertFalse(r['final_states']['caster']['knocked_down'])
        self.assertTrue(r['initial_states']['caster']['knocked_down'])
        self.assertTrue(any(e['type'] == 'impact_batch_resolved' for e in r['events']))
        json.dumps(r)  # The replay artifact must be serializable.

    def test_payment_uses_current_dyspnea_and_remains_paid_through_active(self):
        r = run(scenario(horizon=399, dyspnea=50))
        payment = events(r, 'dyspnea_paid')[0]
        self.assertEqual(payment['phase'], 'active_start')
        self.assertEqual(D(payment['amount']), D('12.25'))
        self.assertEqual(D(r['final_states']['caster']['dyspnea']), D('62.25'))
        self.assertTrue(r['final_states']['caster']['knocked_down'])
        self.assertEqual(r['final_states']['caster']['current_action']['kind'], 'get_up')

    def test_existing_disorientation_does_not_add_gathering_to_get_up(self):
        s = scenario(horizon=400)
        s['encounter']['participants']['caster']['initial_state'].update(
            disorientation=800, instability=700)
        r = run(s)
        self.assertEqual(events(r, 'get_up_completed')[0]['time_ms'], '400')
        self.assertEqual(D(r['final_states']['caster']['disorientation']), 400)
        self.assertEqual(D(r['final_states']['caster']['instability']), 300)

    def test_incoming_status_does_not_extend_active_get_up(self):
        r = run(scenario(horizon=400, gun_start=0))
        self.assertTrue(any(e['type'] == 'impact_batch_resolved' and e['target'] == 'caster'
                            for e in r['events']))
        self.assertEqual(events(r, 'get_up_completed')[0]['time_ms'], '400')
        self.assertFalse(events(r, 'gathering_extended'))

    def test_death_during_active_cancels_completion_without_refund(self):
        r = run(scenario(horizon=1000, hp=1, gun_start=0))
        death = events(r, 'character_died')[0]
        self.assertEqual(death['time_ms'], '145')
        self.assertEqual(death['cancelled_action']['kind'], 'get_up')
        self.assertFalse(events(r, 'get_up_completed'))
        self.assertFalse(events(r, 'ability_started'))
        self.assertEqual(D(r['metrics']['caster']['dyspnea_paid']), 9)
        self.assertFalse(any(e['details'].get('actor') == 'caster'
                             for e in r['pending_events']))

    def test_initially_dead_never_pays_or_revives(self):
        r = run(scenario(hp=0))
        self.assertFalse(events(r, 'get_up_started'))
        self.assertFalse(events(r, 'dyspnea_paid'))
        self.assertEqual(D(r['final_states']['caster']['hp']), 0)

    def test_insufficient_capacity_waits_for_status_and_resource_recovery(self):
        s = scenario(horizon=1400, dyspnea=99)
        s['encounter']['participants']['caster']['initial_state']['disorientation'] = 100
        r = run(s)
        start = events(r, 'get_up_started')[0]
        self.assertGreater(D(start['time_ms']), 100)
        payment = events(r, 'dyspnea_paid')[0]
        self.assertEqual(payment['time_ms'], start['time_ms'])
        self.assertLessEqual(D(payment['after']), 100)
        self.assertEqual(len(events(r, 'get_up_waiting_for_capacity')), 1)
        for point in r['curve']:
            self.assertTrue(0 <= D(point['states']['caster']['dyspnea']) <= 100)

    def test_repeated_knockdown_cancels_old_completion_and_charges_new_attempt(self):
        r = with_knockdowns(scenario(horizon=900), [200])
        self.assertEqual([e['time_ms'] for e in events(r, 'get_up_started')], ['0', '200'])
        self.assertEqual([e['time_ms'] for e in events(r, 'get_up_completed')], ['600'])
        self.assertEqual(events(r, 'knockdown_applied')[0]['cancelled_action']['kind'], 'get_up')
        payments = [e for e in events(r, 'dyspnea_paid') if e['ability'] == 'get_up']
        self.assertEqual([D(e['amount']) for e in payments], [D(9), D('9.5481')])
        self.assertEqual(r['metrics']['caster']['get_ups_started'], 2)
        self.assertEqual(r['metrics']['caster']['get_ups_completed'], 1)

    def test_knockdown_cancels_preparation_and_prevents_unreleased_shot(self):
        s = scenario(horizon=500)
        s['encounter']['participants']['caster']['initial_state']['knocked_down'] = False
        r = with_knockdowns(s, [100])
        cancelled = events(r, 'knockdown_applied')[0]['cancelled_action']
        self.assertEqual(cancelled['phase'], 'gathering')
        self.assertFalse(events(r, 'projectile_released'))
        self.assertEqual(events(r, 'get_up_completed')[0]['time_ms'], '500')

    def test_knockdown_does_not_cancel_released_projectile(self):
        s = scenario(horizon=1300)
        s['encounter']['participants']['caster']['initial_state']['knocked_down'] = False
        r = with_knockdowns(s, [450])
        self.assertEqual(events(r, 'projectile_released')[0]['time_ms'], '398')
        self.assertTrue(any(e['type'] == 'impact_batch_resolved' and e['target'] == 'gunner'
                            and e['time_ms'] == '698' for e in r['events']))
        self.assertEqual(events(r, 'get_up_completed')[0]['time_ms'], '850')

    def test_same_time_completion_precedes_incoming_knockdown(self):
        r = with_knockdowns(scenario(horizon=800), [400])
        completed = events(r, 'get_up_completed')
        down = events(r, 'knockdown_applied')[0]
        self.assertEqual([e['time_ms'] for e in completed], ['400', '800'])
        self.assertLess(r['events'].index(completed[0]), r['events'].index(down))
        self.assertEqual([e['time_ms'] for e in events(r, 'get_up_started')], ['0', '400'])

    def test_same_time_release_precedes_incoming_knockdown(self):
        s = scenario(horizon=1200)
        s['encounter']['participants']['caster']['initial_state']['knocked_down'] = False
        r = with_knockdowns(s, [398])
        release = events(r, 'projectile_released')[0]
        down = events(r, 'knockdown_applied')[0]
        self.assertEqual(release['time_ms'], down['time_ms'])
        self.assertLess(r['events'].index(release), r['events'].index(down))
        self.assertTrue(any(e['type'] == 'impact_batch_resolved' and e['target'] == 'gunner'
                            and e['time_ms'] == '698' for e in r['events']))

    def test_deployed_beam_survives_knockdown_of_caster(self):
        s = scenario(horizon=1000)
        s['encounter']['participants']['caster']['initial_state']['knocked_down'] = False
        s['action_selection']['caster']['abilities'] = ['4']
        r = with_knockdowns(s, [350])
        self.assertEqual(events(r, 'beam_deployed')[0]['time_ms'], '292')
        self.assertTrue(any(e['type'] == 'continuous_damage_resolved' and e['target'] == 'gunner'
                            and D(e['time_ms']) > 350 and D(e['applied_hp_damage']) > 0
                            for e in r['events']))
        self.assertEqual(events(r, 'get_up_completed')[0]['time_ms'], '750')

    def test_exact_capacity_payment_emits_one_maximum_trigger(self):
        # A test-only Db=1.04 at D=96 costs exactly 4; this exercises the
        # capacity boundary without an irrational starting value.
        definition = deepcopy(DEFINITION)
        definition['characters']['1E1']['jump_base_dyspnea'] = '0.52'
        r = run_shared_scenario(scenario(horizon=400, dyspnea=96), PROFILES,
                                get_up_definition=definition)
        self.assertEqual(len(events(r, 'maximum_dyspnea_trigger')), 1)
        self.assertEqual(D(events(r, 'dyspnea_paid')[0]['after']), 100)
        self.assertEqual(events(r, 'get_up_completed')[0]['time_ms'], '400')

    def test_no_enemy_is_required_to_get_up(self):
        s = scenario(horizon=400)
        s['encounter']['participants']['gunner']['team'] = 'A'
        r = run(s)
        self.assertEqual(events(r, 'get_up_completed')[0]['time_ms'], '400')
        self.assertFalse(events(r, 'ability_started'))

    def test_healthy_standing_actor_does_not_use_get_up(self):
        r = run()
        self.assertFalse(events(r, 'get_up_started', 'gunner'))

    def test_invalid_enablement_and_state_are_rejected(self):
        s = scenario()
        with self.assertRaises(ValueError):
            run_shared_scenario(s, PROFILES)
        s['encounter']['participants']['caster']['initial_state']['knocked_down'] = 1
        with self.assertRaises(ValueError):
            run(s)
        s = scenario()
        s['common_abilities'] = ['invented_ability']
        with self.assertRaises(UnsupportedMechanicError):
            run(s)

    def test_dispatch_and_summary_include_get_up(self):
        r = run_scenario(scenario(), PROFILES, get_up_definition=DEFINITION)
        summary = summarize(r)
        self.assertEqual(summary['participants']['caster']['common_action_metrics']['get_ups_completed'], 1)

    def test_observations_precision_and_input_order_preserve_results(self):
        s = scenario(horizon=800, dyspnea=99)
        a = run(s, sample_interval_ms=None)
        b = run(s, sample_interval_ms=37)
        s['encounter']['participants'] = dict(reversed(list(s['encounter']['participants'].items())))
        c = run(s, sample_interval_ms=83, precision=80)
        for r in (b, c):
            for kind in ('get_up_started', 'get_up_completed'):
                self.assertEqual(events(a, kind), events(r, kind))
            for field in ('hp', 'armor', 'dyspnea', 'disorientation', 'instability'):
                self.assertEqual(D(a['final_states']['caster'][field]),
                                 D(r['final_states']['caster'][field]))


if __name__ == '__main__':
    unittest.main()
