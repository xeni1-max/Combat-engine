"""Isolated curved sphere contacts with authored terrain and body cuboids."""
from math import sqrt
import unittest

from combat_sim.gravity_collisions import first_contact
from combat_sim.mechanics.gravity import ProjectileTrajectory
from combat_sim.hitboxes import Cuboid
from combat_sim.terrain import RectangularGround
from combat_sim.models import UnsupportedMechanicError


class GravityCollisionTests(unittest.TestCase):
    def setUp(self):
        self.ground=RectangularGround('ground',[-250,-250,0],[250,250,0])
        self.cube=Cuboid('cube_1',[6,0,.9],[1.8,1.8,1.8])

    def test_horizontal_sphere_ground_time_matches_analytic_solution(self):
        p=ProjectileTrajectory([0,0,1.055],[100,0,0],.6)
        c=first_contact(p,[self.ground],.02)
        expected=sqrt(2*(1.055-.02)/9.81)
        self.assertLessEqual(c.time_lower_s,expected)
        self.assertGreaterEqual(c.time_upper_s,expected)
        self.assertLessEqual(c.time_upper_s-c.time_lower_s,1e-8)
        self.assertEqual(c.surface_point_m[2],0)
        self.assertGreater(c.distance_lower_m,100*c.time_lower_s)

    def test_cube_blocks_before_ground(self):
        p=ProjectileTrajectory([.4,-.1,1.055],[100,0,0],.6)
        c=first_contact(p,[self.ground,self.cube],.02)
        self.assertEqual(c.object_id,'cube_1')
        expected=(5.08-.4)/100
        self.assertLessEqual(c.time_lower_s,expected)
        self.assertGreaterEqual(c.time_upper_s,expected)
        self.assertEqual(c.surface_point_m[0],5.1)

    def test_arc_can_clear_cube_which_endpoint_chord_would_hit(self):
        p=ProjectileTrajectory([0,0,1],[10,0,5],1.2)
        self.assertIsNotNone(self.cube.swept_sphere_contact(p.at(0).position_m,p.at(1.2).position_m,.02))
        self.assertIsNone(first_contact(p,[self.cube],.02))

    def test_arc_can_hit_obstacle_which_endpoint_chord_misses(self):
        box=Cuboid('high_box',[5,0,2.2],[.2,.2,.2])
        p=ProjectileTrajectory([0,0,1],[10,0,5],1)
        self.assertIsNone(box.swept_sphere_contact(p.at(0).position_m,p.at(1).position_m,.02))
        c=first_contact(p,[box],.02)
        self.assertEqual(c.object_id,'high_box')
        self.assertLess(c.time_upper_s,.5)

    def test_finite_ground_miss_and_open_top(self):
        p=ProjectileTrajectory([251,0,1],[0,0,0],.6)
        self.assertIsNone(first_contact(p,[self.ground],.02))
        p=ProjectileTrajectory([0,0,199],[0,0,20],.2)
        self.assertGreater(p.at(.2).position_m[2],200)
        self.assertIsNone(first_contact(p,[self.ground],.02))

    def test_starting_overlap_is_contact_at_zero(self):
        p=ProjectileTrajectory([6,0,1],[100,0,0],.1)
        c=first_contact(p,[self.cube],.02)
        self.assertEqual((c.time_lower_s,c.time_upper_s),(0,0))

    def test_body_removed_from_explicit_scene_allows_ground_contact(self):
        p=ProjectileTrajectory([0,0,1.15],[100,0,0],.6)
        body=Cuboid('torso',[20,0,1.15],[.3,.5,.7])
        self.assertEqual(first_contact(p,[body,self.ground],.02).object_id,'torso')
        self.assertEqual(first_contact(p,[self.ground],.02).object_id,'ground')

    def test_gun_contact_converges_when_solver_and_geometry_controls_tighten(self):
        a=ProjectileTrajectory([0,0,1.025],[900,0,0],.6,deceleration_mps2=300)
        b=ProjectileTrajectory([0,0,1.025],[900,0,0],.6,deceleration_mps2=300,max_step_s=.001,relative_tolerance=1e-13,absolute_tolerance=1e-14)
        # Wider explicit test floor; the authored 500 m floor is not extended.
        floor=RectangularGround('test_floor',[-1000,-1000,0],[1000,1000,0])
        x=first_contact(a,[floor],.02)
        y=first_contact(b,[floor],.02,time_tolerance_s=1e-9,clearance_tolerance_m=1e-12)
        self.assertLess(abs(x.time_upper_s-y.time_upper_s),2e-8)
        self.assertLess(abs(x.distance_upper_m-y.distance_upper_m),2e-5)

    def test_shallow_corner_miss_does_not_use_expanded_box(self):
        box=Cuboid('box',[1,1,1],[2,2,2])
        p=ProjectileTrajectory([-1,-.019,-.019],[100,0,0],.04,gravity_mps2=0)
        self.assertIsNone(first_contact(p,[box],.02))

    def test_simultaneous_scene_contacts_are_not_arbitrarily_ordered(self):
        same=Cuboid('other',[6,0,.9],[1.8,1.8,1.8])
        p=ProjectileTrajectory([0,0,1],[100,0,0],.1)
        with self.assertRaisesRegex(UnsupportedMechanicError,'priority'):
            first_contact(p,[self.cube,same],.02)

    def test_near_tangent_contact_is_explicitly_unresolved(self):
        box=Cuboid('box',[1,1,1],[2,2,2])
        p=ProjectileTrajectory([-1,-.02000000001,1],[100,0,0],.04,gravity_mps2=0)
        with self.assertRaisesRegex(UnsupportedMechanicError,'unresolved'):
            first_contact(p,[box],.02)

    def test_horizontal_gun_can_pass_beyond_finite_floor_before_falling(self):
        p=ProjectileTrajectory([.3,10,1.025],[900,0,0],.6,deceleration_mps2=300)
        self.assertGreater(p.at(.6).position_m[0],250)
        self.assertLess(p.at(.6).position_m[2],0)
        self.assertIsNone(first_contact(p,[self.ground],.02))

    def test_larger_projectile_contacts_ground_earlier(self):
        p=ProjectileTrajectory([0,0,1],[100,0,0],.6)
        small=first_contact(p,[self.ground],.02)
        large=first_contact(p,[self.ground],.1)
        self.assertLess(large.time_upper_s,small.time_lower_s)

    def test_smaller_steps_preserve_qard_contact_brackets(self):
        a=ProjectileTrajectory([.4,-.1,1.055],[100,0,0],.6,max_step_s=.04)
        b=ProjectileTrajectory([.4,-.1,1.055],[100,0,0],.6,max_step_s=.00137)
        for shapes in ([self.ground],[self.cube,self.ground]):
            x=first_contact(a,shapes,.02)
            y=first_contact(b,shapes,.02)
            self.assertEqual(x.object_id,y.object_id)
            self.assertLess(abs(x.time_upper_s-y.time_upper_s),2e-8)

    def test_invalid_collision_controls_fail(self):
        p=ProjectileTrajectory([0,0,1],[100,0,0],.1)
        for kwargs in ({'radius_m':-1},{'radius_m':.02,'time_tolerance_s':0},
                       {'radius_m':.02,'clearance_tolerance_m':float('nan')}):
            with self.assertRaises(ValueError):first_contact(p,[self.ground],**kwargs)

    def test_later_uncertain_contact_does_not_cancel_an_earlier_hit(self):
        p=ProjectileTrajectory([0,0,1],[100,0,0],.5,gravity_mps2=0)
        later=Cuboid('later_tangent',[30,1.02000000001,1],[2,2,2])
        self.assertEqual(first_contact(p,[later,self.cube],.02).object_id,'cube_1')
