"""Observation-independent phase/contact arbitration and live climb prerequisites.

Ordinary scenarios use the public API. World changes use the existing collider
fixture solely to exercise supported registry transitions, not new abilities.

These numerical/phase contracts select the pre-equilibrium rules explicitly.
Current selected-rule interactions are covered in test_equilibrium_interactions.
"""
from decimal import Decimal as D
import unittest

from combat_sim.mobile_combat import GRAVITY_MOBILE_SCOPE
from combat_sim.shared_engine import run_shared_scenario
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB, climb
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_mobile_combat import BODY, MOVEMENT, PROFILES, TERRAIN, command, events, read
from tests.test_world_colliders_combat import platform, run as world_run, wall

CURRENT = read('tests/fixtures/combat_locomotion_pre_equilibrium_v2.json')
MATRIX = ((50, None), (50, 1), (50, 17), (50, 37), (50, 50), (50, 100), (80, 113))


def scene(duration=650, position=('4.59', 0)):
    return {
        'id': 'motion_boundary_regression', 'execution_model': 'shared_encounter',
        'scope': dict(GRAVITY_MOBILE_SCOPE), 'terrain_profile': TERRAIN['id'],
        'encounter': {'duration_ms': duration, 'ground_z_m': 0, 'participants': {
            'A': {'character': '1E2', 'team': 'A', 'position_m': list(position),
                  'facing': '+x', 'initial_state': {'shield': 0}},
            'B': {'character': '1E2', 'team': 'B', 'position_m': [30, -20],
                  'facing': '-x', 'initial_state': {'shield': 0}},
        }},
        'action_selection': {name: {
            'kind': 'priority_when_ready', 'target': 'nearest_living_enemy',
            'abilities': ['1'], 'reload_when_empty': True, 'start_ms': 100000,
        } for name in ('A', 'B')},
        'movement_script': [],
    }


def run(s, *, precision=50, interval=None):
    return run_shared_scenario(s, PROFILES, precision=precision, sample_interval_ms=interval,
        body_definition=BODY, terrain_definition=TERRAIN, movement_definition=MOVEMENT,
        combat_locomotion_definition=CURRENT, jump_definition=JUMP, climb_definition=CLIMB,
        projectile_physics_definition=PHYSICS)


def gate_scene(x='4.59'):
    s = scene(position=(x, 0))
    command(s, 'A', 0, 'walk')
    climb(s)
    return s


def platform_scene(*, crouch=True, duration=1100):
    s = scene(duration, ('.6', -20))
    s['initial_colliders'] = [platform()]
    if crouch:
        command(s, 'A', 0, 'crouch')
    climb(s, time=200, target='platform')
    return s


class MotionBoundaryCombatTests(unittest.TestCase):
    def assert_origin(self, result, expected):
        for value, target in zip(result['final_states']['A']['body_origin_m'], expected):
            self.assertLessEqual(abs(D(value)-D(target)), D('1e-20'))

    def test_exact_phase_contact_uses_new_climb_motion_in_every_partition(self):
        for precision, interval in MATRIX:
            with self.subTest(precision=precision, interval=interval):
                r = run(gate_scene(), precision=precision, interval=interval)
                self.assertFalse(events(r, 'body_contact'))
                self.assertFalse(events(r, 'climb_interrupted'))
                self.assertEqual(D(events(r, 'climb_active_started')[0]['time_ms']), 210)
                self.assertEqual(D(events(r, 'climb_completed')[0]['time_ms']), 510)
                self.assertEqual(r['metrics']['A']['climbs_completed'], 1)
                self.assertEqual(r['final_states']['A']['locomotion']['support_id'], 'cube_1')
                self.assert_origin(r, (6, 0, '2.675'))

    def test_contact_a_thousandth_ms_earlier_still_delays_gathering(self):
        for precision, interval in MATRIX:
            with self.subTest(precision=precision, interval=interval):
                r = run(gate_scene('4.590002'), precision=precision, interval=interval)
                contact = events(r, 'body_contact')[0]
                self.assertLessEqual(abs(D(contact['time_ms'])-D('209.999')), D('1e-20'))
                self.assertGreater(D(contact['relative_speed_mps']), 0)
                self.assertEqual(D(events(r, 'climb_active_started')[0]['time_ms']), 286)
                self.assertEqual(D(events(r, 'climb_completed')[0]['time_ms']), 586)
                self.assert_origin(r, (6, 0, '2.675'))

    def test_contact_a_thousandth_ms_later_is_superseded_by_the_climb(self):
        for precision, interval in ((50, None), (50, 1), (80, 113)):
            r = run(gate_scene('4.589998'), precision=precision, interval=interval)
            self.assertFalse(events(r, 'body_contact'))
            self.assertEqual(D(events(r, 'climb_completed')[0]['time_ms']), 510)

    def test_phase_completion_that_preserves_inward_motion_keeps_contact(self):
        for precision, interval in MATRIX:
            with self.subTest(precision=precision, interval=interval):
                s = scene(200, ('4.89', 0))
                command(s, 'A', 0, 'walk')
                r = run(s, precision=precision, interval=interval)
                contact = events(r, 'body_contact')
                self.assertEqual(len(contact), 1)
                self.assertEqual(D(contact[0]['time_ms']), 60)
                self.assertEqual(D(contact[0]['relative_speed_mps']), 2)
                ordered = [e['type'] for e in r['events'] if D(e['time_ms']) == 60]
                self.assertLess(ordered.index('movement_active_completed'), ordered.index('body_contact'))
                self.assert_origin(r, ('4.95', 0, '.875'))

    def test_posture_completion_does_not_suppress_a_real_translation_contact(self):
        for precision, interval in ((50, None), (50, 17), (80, 113)):
            with self.subTest(precision=precision, interval=interval):
                s = scene(400, ('4.606', 0))
                command(s, 'A', 0, 'walk')
                command(s, 'A', 0, 'crouch')
                r = run(s, precision=precision, interval=interval)
                self.assertEqual(D(events(r, 'crouch_completed')[0]['time_ms']), 210)
                contact = events(r, 'body_contact')
                self.assertEqual(len(contact), 1)
                self.assertLessEqual(abs(D(contact[0]['time_ms'])-210), D('1e-20'))
                self.assertGreater(D(contact[0]['relative_speed_mps']), 0)
                self.assertEqual(r['final_states']['A']['locomotion']['posture'], 'crouched')

    def test_real_overhead_obstruction_still_interrupts_the_approved_climb(self):
        for precision, interval in ((50, None), (50, 17), (80, 113)):
            s = scene(1100, ('4.6', 0))
            roof = wall('roof', x='4.6', hp=None, size=(1, 2, '.2'), z='2.9')
            roof['parts'][0]['centre_m'][1] = 0
            s['initial_colliders'] = [roof]
            climb(s)
            r = run(s, precision=precision, interval=interval)
            self.assertEqual(len(events(r, 'climb_interrupted')), 1)
            self.assertEqual(events(r, 'climb_interrupted')[0]['reason'], 'body_contact')
            self.assertLessEqual(abs(D(events(r, 'body_contact')[0]['time_ms'])-D('248.4375')), D('1e-20'))
            self.assertFalse(events(r, 'climb_completed'))
            self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_registered_climb_stands_and_pays_each_phase_once(self):
        for precision, interval in ((50, None), (50, 37), (80, 113)):
            r = run(platform_scene(), precision=precision, interval=interval)
            self.assertEqual(len(events(r, 'stand_completed')), 1)
            self.assertEqual(len(events(r, 'climb_active_started')), 1)
            self.assertEqual(len(events(r, 'dyspnea_paid', 'A')), 3)
            self.assertFalse(events(r, 'climb_attachment_lost'))
            self.assertFalse(events(r, 'climb_interrupted'))
            self.assertEqual(r['final_states']['A']['locomotion']['support_id'], 'platform')
            self.assert_origin(r, (2, -20, '2.675'))

    def test_expired_target_during_gathering_cannot_pay_or_activate(self):
        for expiry in (300, 350):
            with self.subTest(expiry=expiry):
                s = platform_scene(crouch=False)
                s['initial_colliders'][0]['duration_ms'] = expiry
                r = run(s)
                self.assertEqual(len(events(r, 'climb_requested')), 1)
                self.assertFalse(events(r, 'climb_active_started'))
                self.assertFalse(events(r, 'climb_completed'))
                self.assertFalse(events(r, 'dyspnea_paid', 'A'))
                self.assertFalse(any(e['type'] == 'active_completed' for e in r['pending_events']))
                self.assert_origin(r, ('.6', -20, '.875'))

    def test_removed_target_during_gathering_invalidates_the_owned_action(self):
        r = world_run(platform_scene(crouch=False), operations=[(300, {'op': 'remove', 'id': 'platform'})])
        self.assertFalse(events(r, 'climb_active_started'))
        self.assertFalse(events(r, 'dyspnea_paid', 'A'))
        self.assertFalse(events(r, 'climb_completed'))

    def test_support_expiring_at_completion_uses_real_fall_without_false_completion(self):
        for precision, interval in ((50, None), (50, 37), (80, 113)):
            s = platform_scene(crouch=False)
            s['initial_colliders'][0]['duration_ms'] = 650
            r = run(s, precision=precision, interval=interval)
            self.assertFalse(events(r, 'climb_completed'))
            self.assertEqual(events(r, 'climb_interrupted')[0]['reason'], 'lifetime_expired')
            self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
            self.assertEqual(len(events(r, 'dyspnea_paid', 'A')), 1)
            self.assert_origin(r, (2, -20, '1.6817375'))

    def test_blocked_stand_rejects_registered_climb_without_cost_or_launch(self):
        s = platform_scene()
        roof = wall('roof', x='.6', hp=None, size=(1, 1, '.2'), z='1.6')
        r = world_run(s, operations=[(200, {'op': 'spawn', 'definition': roof})])
        self.assertEqual(len(events(r, 'stand_rejected')), 1)
        self.assertFalse(events(r, 'climb_requested'))
        self.assertFalse(events(r, 'climb_active_started'))
        self.assertEqual(len(events(r, 'dyspnea_paid', 'A')), 1)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])
        self.assertEqual(r['final_states']['A']['locomotion']['posture'], 'crouched')

    def test_partial_pose_stands_after_clearance_returns_then_climbs(self):
        s = platform_scene(crouch=False, duration=1500)
        s['movement_script'] = []
        command(s, 'A', 0, 'crouch')
        command(s, 'A', 200, 'stand')
        climb(s, time=400, target='platform')
        roof = wall('roof', x='.6', hp=None, size=(1, 1, '.2'), z='1.7')
        r = world_run(s, operations=[(250, {'op': 'spawn', 'definition': roof}),
                                     (400, {'op': 'remove', 'id': 'roof'})])
        partial = events(r, 'posture_interrupted')[0]
        self.assertGreater(D(partial['crouch_fraction']), 0)
        self.assertLess(D(partial['crouch_fraction']), 1)
        self.assertEqual(len(events(r, 'stand_completed')), 1)
        self.assertEqual(len(events(r, 'climb_completed')), 1)
        self.assertFalse(events(r, 'climb_attachment_lost'))
        self.assert_origin(r, (2, -20, '2.675'))

    def test_sprinting_registered_climb_exits_sprint_before_start(self):
        s = scene(1600, ('.6', -28))
        s['initial_colliders'] = [platform()]
        s['encounter']['participants']['A']['movement_direction'] = [0, 1]
        command(s, 'A', 0, 'sprint')
        climb(s, time=700, target='platform')
        r = run(s)
        start = events(r, 'climb_active_started')[0]
        exits = [e for e in events(r, 'movement_active_completed', 'A')
                 if e['action'] == 'run' and D(e['time_ms']) > 700]
        self.assertEqual(len(exits), 1)
        self.assertLess(D(exits[0]['time_ms']), D(start['time_ms']))
        self.assertTrue(all(D(e['interval_end_ms']) <= D(exits[0]['time_ms'])
                            for e in events(r, 'sprint_dyspnea_gained', 'A')))
        self.assertEqual(len(events(r, 'climb_completed')), 1)

    def test_same_time_real_projectile_hit_precedes_renewed_body_contact(self):
        s = scene(350, (0, -20))
        s['encounter']['participants']['B'].update(position_m=[-30, -20], facing='+x')
        s['action_selection']['B']['start_ms'] = 0
        command(s, 'A', 0, 'walk')
        baseline = run(s)
        hit_time = events(baseline, 'projectile_body_collision', 'B')[0]['time_ms']
        r = world_run(s, operations=[(hit_time, {'op': 'spawn_at_body'})])
        hit = events(r, 'projectile_body_collision', 'B')[0]
        contact = events(r, 'body_contact')[0]
        self.assertEqual(D(hit['time_ms']), D(contact['time_ms']))
        self.assertGreater(D(contact['relative_speed_mps']), 0)
        self.assertLess(r['events'].index(hit), r['events'].index(contact))
        self.assertEqual(len(events(r, 'body_contact')), 1)


if __name__ == '__main__':
    unittest.main()
