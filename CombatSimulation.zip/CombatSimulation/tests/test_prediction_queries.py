"""Swept rejection preserves interior entries, deformation and same-clock poses."""
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
from types import SimpleNamespace
from unittest.mock import patch
import unittest
from combat_sim.equilibrium import Equilibrium,BalanceState
from combat_sim.mechanics.equilibrium import BalancePiece
from combat_sim.hitboxes import Cuboid
from combat_sim.orientation import YawFrame
from combat_sim.oriented_geometry import OrientedCuboid
from combat_sim.volume_geometry import box_cells,column_cells

ZERO=(0,0,0)
def moving(box,v=ZERO,a=ZERO,rate=ZERO,change=ZERO):return box,v,a,rate,change

class PredictionQueryTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def test_distant_column_and_panel_unions_need_no_candidate_roots(self):
        frame=YawFrame(F(3,5),F(4,5))
        for box in (Cuboid('body',(1000,0,0),(1,1,1)),OrientedCuboid('body',(1000,0,0),(1,1,1),frame)):
            with self.subTest(shape=type(box).__name__),patch('combat_sim.volume_geometry._roots',side_effect=AssertionError('Unreachable field cannot require candidate roots')):
                self.assertEqual(column_cells(ZERO,1,[moving(box)],[],1),[(D(0),False)])
                for panel in (Cuboid('panel',ZERO,(1,1,1)),OrientedCuboid('panel',ZERO,(1,1,1),frame)):
                    self.assertEqual(box_cells([panel],[moving(box)],1),[(D(0),False)])

    def test_column_flyby_enters_with_both_endpoints_outside(self):
        body=Cuboid('body',(-2,0,0),('.2',)*3)
        cells=column_cells(ZERO,'.5',[moving(body,(4,0,0),(-4,0,0))],[],2)
        self.assertEqual([inside for _,inside in cells],[False,True,False])
        for (actual,_),expected in zip(cells[1:],(1-D('.3').sqrt(),1+D('.3').sqrt())):
            self.assertLess(abs(actual-expected),D('1e-40'))

    def test_interior_size_bulge_enters_and_leaves_column(self):
        body=Cuboid('body',(2,0,0),(1,1,1))
        cells=column_cells(ZERO,'.75',[moving(body,rate=(8,0,0),change=(-8,0,0))],[],2)
        self.assertEqual([inside for _,inside in cells],[False,True,False])
        for (actual,_),expected in zip(cells[1:],(1-D('.625').sqrt(),1+D('.625').sqrt())):
            self.assertLess(abs(actual-expected),D('1e-40'))

    def test_rotated_panel_flyby_keeps_true_sat_entries(self):
        frame=YawFrame(F(3,5),F(4,5));n=frame.right
        panel=OrientedCuboid('panel',ZERO,('.2',4,4),frame)
        body=OrientedCuboid('body',tuple(-2*x for x in n),('.2',)*3,frame)
        cells=box_cells([panel],[moving(body,tuple(4*x for x in n),tuple(-4*x for x in n))],2)
        self.assertEqual([inside for _,inside in cells],[False,True,False])
        for (actual,_),expected in zip(cells[1:],(1-D('.1').sqrt(),1+D('.1').sqrt())):
            self.assertLess(abs(actual-expected),D('1e-40'))

    def test_closed_persistent_tangency_is_not_rejected(self):
        body=Cuboid('body',('1.5',0,0),(1,1,1))
        self.assertEqual(column_cells(ZERO,1,[moving(body)],[],1),[(D(0),True)])
        panel=Cuboid('panel',('2.5',0,0),(1,1,1))
        self.assertEqual(box_cells([panel],[moving(body)],1),[(D(0),True)])

    def test_unreachable_invalid_shape_trajectories_still_reject(self):
        frame=YawFrame(F(3,5),F(4,5));panel=Cuboid('panel',ZERO,(1,1,1))
        for box in (Cuboid('body',(1000,0,0),(1,1,1)),OrientedCuboid('body',(1000,0,0),(1,1,1),frame)):
            bad=moving(box,rate=(0,0,-8),change=(0,0,8))
            with self.assertRaises(ValueError):column_cells(ZERO,1,[bad],[],2)
            with self.assertRaises(ValueError):box_cells([panel],[bad],2)

    def test_balance_queries_follow_clock_replacement_and_reversed_observations(self):
        e=Equilibrium(SimpleNamespace());row=BalanceState(1,piece=BalancePiece(0,1000,0,1,0,'falling'));e.states['A']=row
        for t in (250,250,750,250):self.assertEqual(e.at('A',t),(F(t,1000),F(1),F(0)))
        row.piece=BalancePiece(0,1000,1,-1,0,'recovering')
        self.assertEqual(e.at('A',250),(F(3,4),F(-1),F(0)))
        self.assertEqual(e.at('A',1001),(F(0),F(0),F(0)))
        row.piece=None;row.progress=F(1,5)
        self.assertEqual(e.at('A',250),(F(1,5),F(0),F(0)))

    def test_balance_held_piece_and_new_life_keep_their_values(self):
        e=Equilibrium(SimpleNamespace());e.states['A']=BalanceState(1,piece=BalancePiece(0,1000,0,1,0,'falling'))
        e.at('A',500)
        e.states['A']=BalanceState(2,piece=BalancePiece(0,1000,F(1,3),0,0,'held'))
        for t in (0,500,1001):self.assertEqual(e.at('A',t),(F(1,3),F(0),F(0)))
        with self.assertRaises(ValueError):e.at('A','NaN')
