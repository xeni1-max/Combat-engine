"""Actual2E4 Dodge on current physical posture, charges, attacks and lifetimes."""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.battle_models import decimal_value as dec
from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from tests.test_blocking_combat import scene as base_scene
from tests.test_binding_combat import run as configured_run
from tests.test_equilibrium_combat import rules
from tests.test_mobile_combat import command,events,PROFILES
from tests.test_1e2_precision_projectile import scene as shot_scene
from tests.test_grapple_links_combat import force
from tests.test_world_colliders_combat import wall


def scene(duration=149,*,start=0,abilities=('basic_9',)):
    s=base_scene(duration,character='2E4');s['id']='actual_2e4_dodge'
    s['action_selection']['A'].update(abilities=list(abilities),held_blocks=[],start_ms=start)
    s['action_selection']['B']['start_ms']=100000
    return s


def run(s,**kw):return configured_run(s,rules=rules(),**kw)


def shot(*,part='head',dodge=True):
    s=shot_scene(400,part=part);s['id']='actual_dodge_incoming_shot'
    b=s['encounter']['participants']['B'];b['character']='2E4'
    b['initial_state'].update(hp=9080,armor=165)
    s['action_selection']['B'].update(abilities=['basic_9'],start_ms=50 if dodge else 100000,reload_when_empty=False)
    return s


def qard_shot(*,dodge=True):
    s=shot(dodge=False);s['encounter']['duration_ms']=800
    s['encounter']['participants']['A']['character']='1E1'
    s['encounter']['participants']['A']['initial_state'].update(hp=8140,armor=150)
    s['action_selection']['A']['abilities']=['1']
    # The canonical source cast releases at398 ms. Ducking begins after the
    # released aim is fixed; its ~45 ms flight then exercises real evasion.
    s['action_selection']['B']['start_ms']=399 if dodge else 100000
    return s


class DodgeCombatTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=80));context.__enter__();self.addCleanup(context.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=name)
            self.assertLess(abs(supplied-D(r['final_states'][name]['hp'])-ledger.amount(target=name)),D('1e-8'))
        return ledger

    def test_current_source_is_dodge_with_authored_stock_timing_and_cost(self):
        a=PROFILES['2E4']['abilities']['basic_9'];p=PROFILES['2E4']['timing_profiles']['basic_9']
        self.assertEqual((a['execution_model'],a['charges'],a['charge_cooldown_ms']),('dodge',4,4500))
        self.assertEqual((p['gathering_ms'],p['active_ms']),(0,150));self.assertEqual(dec(a['dyspnea']['base_value']),D('3.5'))
        self.assertEqual(PROFILES['2E4']['abilities']['basic_8']['execution_model'],'block')

    def test_actual_dip_peaks_at75_and_returns_at150_with_anchored_feet(self):
        r=run(scene(150),interval=25);row=r['dodge_actions'][0]
        self.assertEqual((D(row['started_at_ms']),D(row['midpoint_ms']),D(row['ended_at_ms'])),(0,75,150))
        self.assertEqual(row['status'],'completed')
        at75=next(p['states']['A'] for p in r['curve'] if D(p['time_ms'])==75)
        self.assertEqual(D(at75['locomotion']['crouch_fraction']),1)
        self.assertEqual(D(at75['locomotion']['body_height_m']),D('1.35'))
        self.assertEqual(D(r['final_states']['A']['locomotion']['crouch_fraction']),0)
        self.assertTrue(all(D(p['states']['A']['locomotion']['feet_z_m'])==0 for p in r['curve']))

    def test_pays_once_at_active_start_and_spends_one_independent_charge(self):
        r=run(scene());paid=events(r,'dyspnea_paid','A')
        self.assertEqual(len(paid),1);self.assertEqual((D(paid[0]['time_ms']),D(paid[0]['amount'])),(0,D('12.25')))
        self.assertEqual(paid[0]['phase'],'active_start')
        self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['available'],3)
        self.assertFalse(r['block_layers']);self.conserved(r)

    def test_no_enemy_is_required_and_self_target_is_explicit(self):
        s=scene();s['encounter']['participants']['B']['team']='A';r=run(s)
        self.assertEqual(events(r,'ability_started','A')[0]['target'],'A');self.assertTrue(events(r,'dodge_started'))
        self.assertFalse(events(r,'projectile_released'));self.conserved(r)

    def test_serial_recharge_does_not_restart_on_each_spend(self):
        r=run(scene(9200))
        self.assertEqual([D(e['time_ms']) for e in events(r,'dodge_charges_spent')],[0,150,300,450,4500,9000])

    def test_block_and_dodge_have_separate_four_charge_pools(self):
        r=run(scene(700,abilities=('basic_8','basic_9')))
        self.assertEqual(len(events(r,'block_charges_spent')),4);self.assertEqual(len(events(r,'dodge_charges_spent')),4)
        self.assertEqual(r['block_charge_pools']['A']['available'],0)
        self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['available'],0)
        self.assertIn('basic_block',r['final_states']['A']['cooldown_clocks']);self.assertIn('basic_9',r['final_states']['A']['cooldown_clocks'])
        self.conserved(r)

    def test_dodge_block_and_thrust_can_acquire_disjoint_resources_together(self):
        r=run(scene(1,abilities=('basic_9','basic_8','1')))
        self.assertEqual({e['ability'] for e in events(r,'ability_started','A')},{'basic_9','basic_8','1'})
        owners=r['final_states']['A']['owned_actions'];resources=[x for a in owners for x in a['occupies']]
        self.assertEqual(len(resources),len(set(resources)));self.assertEqual(len(owners),3)

    def test_self_selection_does_not_redirect_an_independent_attack(self):
        s=scene(400,abilities=('basic_9','1'));s['encounter']['participants']['B']['position_m']=['.6',-20]
        r=run(s);self.assertTrue(events(r,'melee_contact','A'))
        self.assertTrue(all(e['target']=='B' for e in events(r,'melee_contact','A')))
        self.assertEqual(D(r['final_states']['A']['hp']),D(r['initial_states']['A']['hp']));self.conserved(r)

    def test_stable_running_continues_through_the_dodge(self):
        s=scene(600,start=300);command(s,'A',0,'run');r=run(s)
        self.assertTrue(events(r,'dodge_started'));self.assertGreater(D(r['final_states']['A']['position_m'][0]),3)
        self.assertGreater(D(r['final_states']['A']['locomotion']['velocity_mps'][0]),0)

    def test_existing_hands_remain_in_their_authored_local_poses(self):
        r=run(scene(75));self.assertEqual(r['initial_states']['A']['hands_m'],r['final_states']['A']['hands_m'])
        before=D(r['initial_states']['A']['locomotion']['hand_world_positions_m']['left'][2])
        after=D(r['final_states']['A']['locomotion']['hand_world_positions_m']['left'][2])
        self.assertEqual(before-after,D('.4'))

    def test_a_real_head_shot_can_miss_the_ducking_body(self):
        baseline=run(qard_shot(dodge=False));changed=run(qard_shot())
        self.assertGreater(self.conserved(baseline).amount(target='B'),0)
        self.assertEqual(self.conserved(changed).amount(target='B'),0)
        self.assertFalse([e for e in events(changed,'projectile_body_collision') if e['target']=='B'])

    def test_a_close_shot_aimed_during_the_dip_can_still_hit(self):
        r=run(shot());self.assertGreater(self.conserved(r).amount(target='B'),0)
        self.assertTrue([e for e in events(r,'projectile_body_collision') if e['target']=='B'])

    def test_lower_real_shots_still_hit_the_body_during_dodge(self):
        r=run(shot(part='torso'));self.assertGreater(self.conserved(r).amount(target='B'),0)
        self.assertTrue([e for e in events(r,'projectile_body_collision') if e['target']=='B'])

    def test_restriction_before_active_does_not_pay_or_spend(self):
        s=scene(149);s['encounter']['participants']['A']['initial_state']['disorientation']=100
        def block(w):w.apply_action_restriction('A',source='dodge_probe',functions=['lower_body'],until_ms=500)
        r=run(s,operations=((20,block),));self.assertFalse(events(r,'dodge_started'))
        self.assertFalse(events(r,'dyspnea_paid','A'));self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['available'],4)

    def test_restriction_after_payment_freezes_pose_and_keeps_spent_charge(self):
        def block(w):w.apply_action_restriction('A',source='dodge_probe',functions=['lower_body'],until_ms=500)
        r=run(scene(),operations=((40,block),));row=r['dodge_actions'][0]
        self.assertEqual(row['status'],'cancelled');self.assertEqual(D(row['ended_at_ms']),40)
        self.assertLess(abs(D(r['final_states']['A']['locomotion']['crouch_fraction'])-D(8)/15),D('1e-35'))
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1);self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['available'],3)
        self.assertFalse(events(r,'dodge_return_started'));self.conserved(r)

    def test_imposed_flight_interrupts_dodge_without_replaying_its_old_pose_events(self):
        s=scene(300);s['spatial_interventions']=[force(50,'A',[0,0,3])]
        r=run(s);row=r['dodge_actions'][0];self.assertEqual(row['status'],'cancelled')
        self.assertEqual(D(row['ended_at_ms']),50)
        self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
        self.assertLess(abs(D(r['final_states']['A']['locomotion']['crouch_fraction'])-D(2)/3),D('1e-35'))
        self.assertFalse(events(r,'dodge_return_started'));self.assertFalse(events(r,'dodge_completed'));self.conserved(r)

    def test_returning_under_new_cover_uses_native_contact_and_stays_clear(self):
        def cover(w):w.collider_system.spawn_definition(wall('dodge_roof',x=0,hp=None,z='1.55',size=(4,4,'.1')))
        r=run(scene(149),operations=((75,cover),));row=r['dodge_actions'][0]
        self.assertEqual(row['status'],'cancelled');self.assertEqual(row['end_reason'],'body_contact')
        self.assertLess(abs(D(row['retained_crouch_fraction'])-D('.625')),D('1e-25'))
        self.assertLessEqual(D(r['final_states']['A']['locomotion']['body_height_m']),D('1.5')+D('1e-20'))
        self.conserved(r)

    def test_real_gun_death_cancels_the_owned_pose_and_stops_recharge(self):
        s=scene(300);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['B']['position_m']=[2,-20];s['action_selection']['B']['start_ms']=0
        r=run(s);a=r['final_states']['A'];self.assertFalse(a['alive'])
        row=r['dodge_actions'][0];self.assertEqual(row['status'],'cancelled')
        self.assertEqual(D(row['ended_at_ms']),D(a['died_at_ms']));self.assertFalse(events(r,'dodge_completed'))
        self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['available'],3)
        self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['clock']['state'],'stopped');self.conserved(r)

    def test_an_unaffordable_dodge_waits_without_spinning_or_spending_stock(self):
        s=scene(2);s['encounter']['participants']['A']['initial_state']['dyspnea']=98;r=run(s)
        self.assertFalse(events(r,'dodge_started'));self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['available'],4)
        self.assertLess(len(r['events']),100)

    def test_fully_crouched_body_does_not_start_a_costly_inert_dip(self):
        s=scene(700,start=300);command(s,'A',0,'crouch');r=run(s)
        self.assertFalse(events(r,'dodge_started'));self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['available'],4)

    def test_airborne_request_waits_for_native_landing(self):
        s=scene(1700,start=200);command(s,'A',0,'jump');r=run(s)
        self.assertTrue(events(r,'jump_landed','A'));self.assertTrue(events(r,'dodge_started'))
        self.assertGreaterEqual(D(events(r,'dodge_started')[0]['time_ms']),D(events(r,'jump_landed','A')[0]['time_ms']))
        self.conserved(r)

    def test_precision_samples_and_participant_order_preserve_actual_dodge_evasion(self):
        s=qard_shot();a=run(s);other=deepcopy(s)
        other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        b=run(other,precision=80,interval=17)
        for name in a['final_states']:
            for key in ('hp','armor','shield','disorientation','instability','dyspnea'):
                self.assertLess(abs(D(a['final_states'][name][key])-D(b['final_states'][name][key])),D('1e-8'))
        self.assertEqual(len(events(a,'projectile_body_collision')),len(events(b,'projectile_body_collision')))
        self.conserved(a);self.conserved(b)

    def test_actual_pause_area_pauses_recharge_and_ready_stock_remains_spendable(self):
        s=scene(9200);s['action_selection']['B'].update(abilities=['2'],start_ms=0,reload_when_empty=False)
        r=run(s);self.assertEqual([D(e['time_ms']) for e in events(r,'dodge_charges_spent')],[0,150,300,450,8500])
        self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['clock']['state'],'paused');self.conserved(r)

    def test_actual_heat_beam_does_not_gain_a_dodge_immunity_window(self):
        s=qard_shot();s['encounter']['duration_ms']=2500;s['action_selection']['A']['abilities']=['4']
        s['action_selection']['A'].pop('aim_part',None)
        changed=run(s);control=deepcopy(s);control['action_selection']['B']['start_ms']=100000;baseline=run(control)
        self.assertGreater(self.conserved(changed).amount(target='B'),0)
        self.assertLess(abs(D(changed['final_states']['B']['hp'])-D(baseline['final_states']['B']['hp'])),D('1e-8'))

    def test_completed_dip_restores_the_existing_partial_crouch(self):
        s=scene(400,start=250);command(s,'A',0,'crouch')
        def block(w):w.apply_action_restriction('A',source='partial_pose_probe',functions=['lower_body'],until_ms=200)
        r=run(s,operations=((75,block),));row=r['dodge_actions'][0]
        self.assertEqual(D(row['starting_crouch_fraction']),D('.5'));self.assertEqual(row['status'],'completed')
        self.assertEqual(D(events(r,'dodge_completed')[0]['crouch_fraction']),D('.5'));self.conserved(r)

    def test_life_restoration_retains_stock_and_cannot_replay_an_old_pose_completion(self):
        s=scene(300);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['B']['position_m']=[2,-20];s['action_selection']['B']['start_ms']=0
        restored=[]
        def revive(w):restored.append(w.life_cycles.revive('A',expected_generation=1,hp=500,source='dodge_life_probe'))
        r=run(s,operations=((130,revive),));self.assertEqual(restored,[True]);self.conserved(r)
        self.assertEqual(r['final_states']['A']['life_generation'],2)
        old,new=r['dodge_actions'];self.assertEqual(old['status'],'cancelled');self.assertEqual(new['source_life_generation'],2)
        self.assertEqual(new['status'],'active');self.assertFalse(events(r,'dodge_completed'))
        self.assertEqual(r['dodge_charge_pools']['A']['basic_9']['available'],2)
        death=D(old['ended_at_ms']);expected=9000-death-(300-130)
        self.assertLess(abs(D(r['dodge_charge_pools']['A']['basic_9']['clock']['remaining_work_ms'])-expected),D('1e-25'))

    def test_unsupported_held_form_is_rejected(self):
        s=scene();s['action_selection']['A']['held_blocks']=['basic_9']
        with self.assertRaises((ValueError,UnsupportedMechanicError)):run(s)

    def test_missing_current_dodge_rules_are_rejected(self):
        cfg=rules();cfg.pop('dodging')
        with self.assertRaises(UnsupportedMechanicError):configured_run(scene(),rules=cfg)


if __name__=='__main__':unittest.main()
