"""The authored 1E5 grab/drag through actual action selection and shared layers.

Restriction, forced motion and life presets are explicitly engineering probes;
ordinary captures retain the source character profile and real hit delivery.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.constriction import damage_rate
from combat_sim.mechanics.grapple import shared_velocity
from combat_sim.mechanics.knockback import resist_knockback,KnockbackBody
from combat_sim.models import UnsupportedMechanicError
from combat_sim.shared_engine import SharedEncounter
from tests.test_component_melee_combat import scene as melee_scene
from tests.test_blocking_combat import run as shared_run,events
from tests.test_mobile_combat import BODY,MOVEMENT,PROFILES,TERRAIN,command
from tests.test_airborne_combat import JUMP
from tests.test_climb_combat import CLIMB
from tests.test_gravity_mobile_combat import PHYSICS
from tests.test_motion_boundary_combat import CURRENT
from tests.test_grapple_links_combat import force,pos,vel
from tests.test_world_colliders_combat import wall


RULES=deepcopy(CURRENT)
RULES.update(continuous_effort={'mode':'shared_budget_v1'},controlled_damage={'mode':'controlled_layers_v1'},
    grapple_casts={'mode':'owned_grapple_v1'})
RULES['action_ownership']['actions'].update(
    grapple_grab={'occupies':['hands','weapon'],'requires':['upper_body','attack']},
    grapple_hold={'occupies':['hands','weapon'],'requires':['upper_body','attack']})


def scene(duration=1000,abilities=('2',),distance='1.1',shield=0):
    s=melee_scene(duration,abilities,distance,shield);s['id']='authored_grab_drag'
    return s


def run(s,**kw):return shared_run(s,rules=kw.pop('rules',RULES),**kw)


def engine(s,profiles=PROFILES):
    return SharedEncounter(s,profiles,sample_interval_ms=None,body_definition=BODY,terrain_definition=TERRAIN,
        movement_definition=MOVEMENT,combat_locomotion_definition=RULES,jump_definition=JUMP,
        climb_definition=CLIMB,projectile_physics_definition=PHYSICS)


def drag_dose(milliseconds,armor):
    """Independent integral: self U80 decays in 80 ms, giving 880 -> 900 DPS."""
    seconds=min(D(milliseconds),D(80))/1000;end=D(880)+250*seconds
    constant=D(25)*armor*armor/4
    ramp=(end*end-D(880)**2)/500-constant/250*(end/D(880)).ln()
    return ramp+max(D(0),(D(milliseconds)-80)/1000)*D(damage_rate(900,armor).numerator)/D(damage_rate(900,armor).denominator)


class GrappleCastTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for actor,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=actor)
            self.assertLess(abs(supplied-D(r['final_states'][actor]['hp'])-ledger.amount(target=actor)),D('1e-8'))
        return ledger

    def test_real_grab_contact_full_active_tail_and_separate_holding_source(self):
        r=run(scene(1000));h=r['grapple_holds'][0];stream=r['controlled_damage_streams'][0]
        self.assertEqual((D(h['started_at_ms']),D(h['hand_transferred_at_ms']),D(h['expiry_ms'])),(190,280,3190))
        self.assertNotEqual(h['grab_action_id'],h['holding_action_id'])
        self.assertEqual(stream['action_id'],h['holding_action_id']);self.assertFalse(stream['autonomous'])
        self.assertEqual(stream['category'],'intrinsic_sustained')
        contact=events(r,'impact_batch_resolved')[0]
        self.assertEqual(D(contact['applied_hp_damage']),0);self.assertEqual(D(contact['applied_armor_loss']),0)
        self.assertGreater(D(contact['status_additions']['instability']),0)
        paid=events(r,'dyspnea_paid');self.assertEqual(len(paid),1)
        self.assertEqual((D(paid[0]['time_ms']),D(paid[0]['amount'])),(100,4))
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['2']),9100)
        self.assertFalse(events(r,'grapple_link_created')[0]['engineering_controller'])
        self.assertFalse(events(r,'bleeding_started'));self.assertFalse(events(r,'blade_attached'))
        self.assertAlmostEqual(self.conserved(r).amount(actor='A'),drag_dose(810,D(165)),places=8)

    def test_grab_keeps_hand_until_280_then_transfers_without_a_free_gap(self):
        r=run(scene(250));owners=r['final_states']['A']['owned_actions']
        self.assertEqual(len(owners),2)
        parent=next(o for o in owners if o['action']['kind']=='grapple_grab')
        child=next(o for o in owners if o['action']['kind']=='grapple_hold')
        self.assertEqual(parent['occupies'],['hand:left','weapon:2'])
        self.assertEqual(child['action']['phase'],'holding_pending');self.assertNotIn('hand:left',child['occupies'])
        r=run(scene(280));owners=r['final_states']['A']['owned_actions']
        self.assertEqual(len(owners),1);self.assertEqual(owners[0]['occupies'],['hand:left','weapon:2'])
        self.assertEqual(owners[0]['action']['phase'],'holding')

    def test_hold_damage_tracks_live_instability_and_source_constriction_formula(self):
        r=run(scene(1100));ledger=self.conserved(r)
        self.assertAlmostEqual(ledger.amount(actor='A'),drag_dose(910,D(165)),places=8)
        self.assertEqual(D(r['final_states']['B']['armor']),165)
        self.assertEqual(len(r['continuous_effort_channels']),1)
        self.assertGreater(D(r['continuous_effort_channels'][0]['gained']),D('3.7'))
        self.assertEqual(D(r['final_states']['A']['dyspnea']),4+D(r['continuous_effort_channels'][0]['gained']))

    def test_miss_pays_and_cools_down_without_self_effect_or_hold(self):
        r=run(scene(400,distance=30));self.assertFalse(r['grapple_holds'])
        self.assertTrue(events(r,'melee_missed'));self.assertFalse(events(r,'self_status_applied'))
        self.assertFalse(r['controlled_damage_streams']);self.assertEqual(len(events(r,'dyspnea_paid')),1)
        self.assertEqual(D(r['final_states']['A']['ability_ready_at_ms']['2']),9100)

    def test_actual_block_intercepts_contact_without_damage_or_counter(self):
        s=scene(250);s['action_selection']['B'].update(abilities=['basic_8'],start_ms=0)
        r=run(s);self.assertFalse(r['grapple_holds']);self.assertFalse(r['reaction_emissions'])
        self.assertEqual(D(r['block_layers'][0]['hp']),800)
        self.assertEqual(events(r,'grapple_contact_rejected')[0]['reason'],'intercepted_surface')
        self.assertEqual(D(events(r,'impact_batch_resolved')[0]['applied_hp_damage']),0)

    def test_world_solid_intercepts_grab_without_fictitious_terrain_damage(self):
        s=scene(250);s['initial_colliders']=[wall('grab_cover',x='.6',z=1,size=['.05',1,2])]
        r=run(s);self.assertFalse(r['grapple_holds'])
        self.assertEqual(events(r,'melee_contact')[0]['collision_kind'],'terrain')
        self.assertFalse(events(r,'collider_damaged'))

    def test_first_friendly_body_can_be_grabbed_without_outgoing_healing_credit(self):
        s=scene(700,distance='1.4');c=deepcopy(s['encounter']['participants']['B'])
        c.update(team='A',position_m=['.7',-20]);s['encounter']['participants']['C']=c
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s);self.assertEqual(r['grapple_holds'][0]['target'],'C')
        ledger=self.conserved(r);self.assertGreater(ledger.amount(target='C'),0)
        self.assertEqual(ledger.amount(actor='A',eligible_only=True),0);self.assertEqual(ledger.amount(target='B'),0)

    def test_later_target_motion_is_an_actual_miss(self):
        s=scene(500);s['encounter']['participants']['B']['facing']='+x';command(s,'B',0,'walk')
        r=run(s);self.assertFalse(r['grapple_holds']);self.assertTrue(events(r,'melee_missed'))

    def test_same_time_lethal_attack_on_controller_does_not_create_a_hold(self):
        s=scene(230);s['action_selection']['A']['start_ms']=40
        s['encounter']['participants']['A']['initial_state'].update(hp=1,armor=0)
        s['encounter']['participants']['B']['character']='1E5'
        s['action_selection']['B'].update(abilities=['1'],start_ms=0)
        r=run(s);self.assertEqual(D(r['final_states']['A']['hp']),0);self.assertFalse(r['grapple_holds'])
        self.assertEqual(len(events(r,'melee_contact')),2)
        self.assertEqual(events(r,'grapple_contact_rejected')[0]['reason'],'action_or_participant_life_ended')
        self.conserved(r)

    def test_same_time_lethal_hit_on_recipient_does_not_attach_a_corpse(self):
        s=scene(230);s['action_selection']['A']['start_ms']=40
        s['encounter']['participants']['B']['initial_state'].update(hp=1,armor=0)
        c=deepcopy(s['encounter']['participants']['A']);c.update(character='1E5',position_m=['2.2',-20],facing='-x')
        s['encounter']['participants']['C']=c;s['action_selection']['C']=dict(s['action_selection']['A'],abilities=['1'],start_ms=0)
        r=run(s);self.assertEqual(D(r['final_states']['B']['hp']),0);self.assertFalse(r['grapple_holds']);self.conserved(r)

    def test_pending_grab_cancellation_ends_hold_and_all_its_owned_rates(self):
        r=run(scene(1000),operations=[(230,{'op':'restriction','functions':['hand:left']})])
        h=r['grapple_holds'][0];self.assertEqual(D(h['ended_at_ms']),230)
        self.assertIsNone(h['hand_transferred_at_ms']);self.assertEqual(r['grapple_links'][0]['status'],'ended')
        self.assertEqual(D(r['controlled_damage_streams'][0]['ended_at_ms']),230)
        self.assertEqual(D(r['continuous_effort_channels'][0]['ended_at_ms']),230)
        self.assertAlmostEqual(self.conserved(r).amount(actor='A'),drag_dose(40,D(165)),places=8)

    def test_transferred_hold_ends_when_its_hand_is_restricted(self):
        r=run(scene(1000),operations=[(500,{'op':'restriction','functions':['hand:left']})])
        self.assertEqual(D(r['grapple_holds'][0]['ended_at_ms']),500)
        self.assertFalse(r['final_states']['A']['owned_actions'])
        self.assertAlmostEqual(self.conserved(r).amount(actor='A'),drag_dose(310,D(165)),places=8)

    def test_recipient_lower_body_restriction_does_not_invent_a_release(self):
        r=run(scene(500),operations=[(300,{'op':'restriction','actor':'B','functions':['lower_body']})])
        self.assertEqual(r['grapple_holds'][0]['status'],'active');self.assertGreater(self.conserved(r).amount(target='B'),0)

    def test_death_before_active_pays_no_cost_and_starts_no_cooldown(self):
        r=run(scene(99),operations=[(50,{'op':'kill'})])
        self.assertFalse(events(r,'dyspnea_paid'));self.assertFalse(r['grapple_holds'])
        self.assertEqual(D(r['final_states']['A']['cooldown_clocks']['2']['remaining_work_ms']),0)

    def test_three_seconds_expiry_stops_damage_effort_and_owned_hand(self):
        r=run(scene(4000));h=r['grapple_holds'][0]
        self.assertEqual((h['status'],h['end_reason'],D(h['ended_at_ms'])),('ended','duration_expired',3190))
        self.assertFalse(r['final_states']['A']['owned_actions']);self.assertFalse(events(r,'bleeding_started'))
        self.assertAlmostEqual(self.conserved(r).amount(actor='A'),drag_dose(3000,D(165)),places=8)
        self.assertEqual(D(r['controlled_damage_streams'][0]['ended_at_ms']),3190)

    def test_personal_shield_absorbs_sustained_pressure_before_armor(self):
        r=run(scene(1000,shield=4000));self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertEqual(self.conserved(r).amount(),0);self.assertEqual(D(r['final_states']['B']['armor']),165)
        # Raw pressure integral: 0.08*(880+900)/2 + .73*900.
        self.assertAlmostEqual(D(r['metrics']['B']['shield_damage_received']),D('728.2'),places=8)
        self.assertFalse(events(r,'bleeding_started'))

    def test_ultimate_does_not_turn_constriction_into_slash_or_bypass_shield(self):
        r=run(scene(1100,('2','Ultimate'),shield=4000))
        self.assertTrue(r['attack_modifiers']);self.assertEqual(self.conserved(r).amount(),0)
        self.assertFalse(events(r,'bleeding_started'));self.assertEqual(D(r['final_states']['B']['armor']),165)
        self.assertEqual(len(events(r,'dyspnea_paid')),1)

    def test_actual_hold_keeps_its_partner_through_an_imposed_upward_force(self):
        s=scene(1300);s['spatial_interventions']=[force(400,'B',[2,0,3])]
        r=run(s);self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertEqual(vel(r,'A'),vel(r,'B'));self.assertAlmostEqual(pos(r,'B')[0]-pos(r,'A')[0],D('1.1'),places=15)
        self.assertEqual(pos(r,'A')[2]-D('1.1375'),pos(r,'B')[2]-D('.875'))
        self.assertEqual(len(events(r,'jump_landed')),2)
        self.assertEqual(len(r['spatial_transitions'][0]['bodies']),2);self.conserved(r)

    def test_actual_walk_drags_partner_using_summed_weighted_input(self):
        s=scene(1500);command(s,'A',400,'walk');r=run(s)
        expected=shared_velocity((2,0,0),(0,0,0),first_max_hp=20000,first_armor=350,
            second_max_hp=9080,second_armor=165)
        self.assertAlmostEqual(vel(r,'A')[0],expected[0],places=15)
        self.assertEqual(vel(r,'A'),vel(r,'B'));self.assertAlmostEqual(pos(r,'B')[0]-pos(r,'A')[0],D('1.1'),places=15)
        self.assertEqual(r['grapple_holds'][0]['status'],'active');self.conserved(r)

    def test_real_grab_registers_summed_stat_knockback_resistance(self):
        w=engine(scene(500));w.run()
        assessment=w.grapple_links.knockback_distance('B',15)
        expected=resist_knockback(15,(KnockbackBody('A',20000,350),KnockbackBody('B',9080,165)))
        self.assertEqual(assessment,expected)

    def test_real_gun_death_stops_controlled_drag_at_death_without_residual_damage(self):
        s=scene(1500);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['C']={'character':'1E2','team':'B','position_m':[-30,-21],
            'facing':'+x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['1'],start_ms=200)
        r=run(s);h=r['grapple_holds'][0];death=D(r['final_states']['A']['died_at_ms'])
        # The wider body meets the same physical shot slightly earlier.
        self.assertEqual(D(h['ended_at_ms']),death);self.assertEqual(death,D('343.914396'))
        self.assertEqual(D(r['controlled_damage_streams'][0]['ended_at_ms']),death)
        self.assertEqual(D(r['continuous_effort_channels'][0]['ended_at_ms']),death)
        ledger=self.conserved(r);self.assertEqual(ledger.amount(actor='A'),ledger.amount(actor='A',end=death))
        self.assertFalse([e for e in events(r,'bleeding_started') if e['effect']['actor']=='A'])

    def test_real_recipient_healing_death_and_revival_do_not_resume_the_old_hold(self):
        s=scene(3500);s['encounter']['participants']['B']['initial_state']['hp']=500
        s['action_selection']['B']['start_ms']=0;r=run(s);ledger=self.conserved(r)
        self.assertTrue(events(r,'life_restored'));self.assertEqual(r['final_states']['B']['life_generation'],2)
        self.assertGreater(HealingHistory.from_run(r).amount(actor='B'),0)
        self.assertEqual(len(r['grapple_holds']),1);self.assertEqual(r['grapple_holds'][0]['status'],'ended')
        self.assertTrue(any(e.contribution.kind=='constriction_tear' and e.target_life_generation==1 for e in ledger.entries))
        self.assertFalse(any(e.contribution.kind=='constriction_tear' and e.target_life_generation==2 for e in ledger.entries))

    def test_two_actual_grabs_share_motion_but_only_the_restricted_owners_hold_ends(self):
        s=scene(1300);s['encounter']['participants']['C']=dict(s['encounter']['participants']['A'],
            position_m=['2.2',-20],facing='-x')
        s['action_selection']['C']=dict(s['action_selection']['A'])
        r=run(s,operations=[(500,{'op':'restriction','functions':['hand:left']})])
        holds={h['actor']:h for h in r['grapple_holds']};self.assertEqual(len(holds),2)
        self.assertEqual(holds['A']['status'],'ended');self.assertEqual(holds['C']['status'],'active')
        ledger=self.conserved(r);self.assertGreater(ledger.amount(actor='C'),ledger.amount(actor='A'))
        self.assertEqual([c['actor'] for c in r['continuous_effort_channels'] if c['ended_at_ms'] is None],['C'])

    def test_real_beam_and_grab_share_depleting_personal_shield_and_hp_history(self):
        s=scene(1500,shield=1000);s['encounter']['participants']['C']={'character':'1E1','team':'A',
            'position_m':[30,-18],'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],abilities=['4'],start_ms=0)
        outcomes=[]
        for interval in (None,100,137):
            r=run(s,interval=interval);ledger=self.conserved(r)
            self.assertEqual({e.contribution.kind for e in ledger.entries},{'heat','constriction_tear'})
            self.assertEqual(D(r['final_states']['B']['shield']),0);outcomes.append(D(r['final_states']['B']['hp']))
        for value in outcomes[1:]:self.assertLess(abs(value-outcomes[0]),D('1e-8'))

    def test_compatible_right_arm_attack_executes_while_left_arm_keeps_holding(self):
        # Explicit engineering sequence preset: previous left swing has already
        # advanced to b. The actual right attack, cost and contact still execute.
        w=engine(scene(1000,('2','1')));w.melee.components[('A','1')]['next_component']='b';r=w.run()
        frames=[f for f in r['melee_attacks'] if f['ability']=='1']
        self.assertEqual([f['melee_component'] for f in frames],['b'])
        self.assertEqual(frames[0]['status'],'resolved');self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertGreater(len(r['applied_hp_history']['entries']),0);self.conserved(r)

    def test_repeated_contact_callback_does_not_duplicate_any_hold_or_rate(self):
        w=engine(scene(500));r=w.run();packet=events(r,'melee_contact')[0]
        w.grapple_casts.attach_contact(packet)
        self.assertEqual(len(w.grapple_casts.holds),1);self.assertEqual(len(w.controlled_damage.streams),1)
        self.assertEqual(len(w.continuous_effort.channels),1)

    def test_owner_release_cannot_release_a_different_controllers_hold(self):
        w=engine(scene(500));r=w.run();identity=r['grapple_holds'][0]['id']
        self.assertFalse(w.grapple_casts.release('B',identity));self.assertTrue(w.grapple_casts.release('A',identity))
        self.assertFalse(w.grapple_casts.release('A',identity));self.assertFalse(w.fighters['A'].live_actions())
        self.assertEqual(w.grapple_links.group('B'),('B',))

    def test_cap_fatigue_releases_the_real_hold_and_triggers_once(self):
        s=scene(5000);s['encounter']['participants']['A']['initial_state']['dyspnea']=73
        r=run(s);h=r['grapple_holds'][0]
        self.assertEqual(h['status'],'ended');self.assertEqual(h['end_reason'],'controller_exhausted')
        self.assertLess(D(h['ended_at_ms']),3190)
        self.assertEqual(len(events(r,'maximum_dyspnea_trigger')),1)
        self.assertEqual(r['controlled_damage_streams'][0]['ended_at_ms'],h['ended_at_ms']);self.conserved(r)

    def test_numeric_observation_and_participant_order_controls_preserve_real_outcomes(self):
        s=scene(2000,shield=100);base=run(s)
        for precision,interval in ((50,17),(50,100),(80,137)):
            other=deepcopy(s);other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
            r=run(other,precision=precision,interval=interval)
            self.assertEqual(r['grapple_holds'],base['grapple_holds'])
            for name in ('A','B'):
                for field in ('hp','armor','shield','dyspnea','disorientation','instability'):
                    self.assertLess(abs(D(r['final_states'][name][field])-D(base['final_states'][name][field])),D('1e-8'))
            self.conserved(r)

    def test_malformed_modes_phases_and_negative_rates_fail_before_combat(self):
        rules=deepcopy(RULES);rules['grapple_casts']={'mode':'unknown'}
        with self.assertRaises(UnsupportedMechanicError):run(scene(),rules=rules)
        for key,value in (('holding_damage_per_second',0),('holding_base_dyspnea',-1),('hold_duration_ms',0)):
            p=deepcopy(PROFILES);p['1E5']['abilities']['2'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):run(scene(),profiles=p)
        p=deepcopy(PROFILES);p['1E5']['documented_abilities']['2']['effort_phases']['holding']['category']='extrinsic_momentary'
        with self.assertRaises(ValueError):run(scene(),profiles=p)


if __name__=='__main__':unittest.main()
