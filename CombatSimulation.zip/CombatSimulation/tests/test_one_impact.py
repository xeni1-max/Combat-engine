import json
import unittest
from copy import deepcopy
from pathlib import Path

from combat_sim.analysis import summarize
from combat_sim.engine import run_scenario
from combat_sim.models import UnsupportedMechanicError


ROOT = Path(__file__).resolve().parents[1]
with (ROOT / "data" / "characters.json").open(encoding="utf-8") as stream:
    CHARACTERS = json.load(stream)["characters"]
with (ROOT / "scenarios" / "one_blunt_impact.json").open(encoding="utf-8") as stream:
    SCENARIO = json.load(stream)
with (ROOT / "scenarios" / "shield_overflow_and_regen.json").open(encoding="utf-8") as stream:
    SHIELD_SCENARIO = json.load(stream)
with (ROOT / "scenarios" / "repeated_shield_hits.json").open(encoding="utf-8") as stream:
    REPEATED_SHIELD_SCENARIO = json.load(stream)
with (ROOT / "scenarios" / "overlapping_shield_regeneration.json").open(encoding="utf-8") as stream:
    OVERLAPPING_REGEN_SCENARIO = json.load(stream)


class OneImpactTests(unittest.TestCase):
    def test_2e4_can_receive_the_existing_supported_blunt_attack(self):
        scenario = deepcopy(SCENARIO)
        target = scenario["encounter"]["initial_states"].pop("1E1")
        target.update(hp=9080, armor=165)
        scenario["encounter"]["initial_states"]["2E4"] = target
        scenario["action_sequence"][0]["target"] = "2E4"
        run = run_scenario(scenario, CHARACTERS)
        # y=(300^2-165^2)/300=209.25; HP=9080-209.25=8870.75.
        self.assertEqual(run["final_states"]["2E4"]["hp"]["exact"], "35483/4")
        self.assertEqual(run["final_states"]["2E4"]["armor"]["exact"], "4463979/28000")

    def test_2e4_requires_its_controlled_encounter_configuration(self):
        scenario = deepcopy(SCENARIO)
        scenario.pop("source_precedence", None)
        actor = scenario["encounter"]["initial_states"].pop("3E5")
        actor.update(hp=9080, armor=165)
        scenario["encounter"]["initial_states"]["2E4"] = actor
        scenario["action_sequence"][0].update(actor="2E4", ability="1")
        with self.assertRaisesRegex(UnsupportedMechanicError, "requires movement='stationary'"):
            run_scenario(scenario, CHARACTERS)

    def test_expected_event_and_final_state(self):
        run = run_scenario(SCENARIO, CHARACTERS)
        summary = summarize(run)
        target = run["final_states"]["1E1"]
        event = run["events"][0]
        self.assertEqual(target["hp"]["exact"], "7915")
        self.assertEqual(target["armor"]["exact"], "4041/28")
        self.assertEqual(target["shield"]["exact"], "0")
        self.assertEqual(summary["hp_damage"]["exact"], "225")
        self.assertEqual(summary["armor_lost"]["exact"], "159/28")
        self.assertEqual(event["damage_calculation"]["state_mapping_status"], "confirmed_by_user")
        self.assertEqual(event["time_ms"], 230)
        self.assertEqual(event["timing_calculation"]["impact_offset_ms"], 230)

    def test_same_inputs_produce_identical_logs(self):
        self.assertEqual(run_scenario(SCENARIO, CHARACTERS), run_scenario(SCENARIO, CHARACTERS))

    def test_fully_absorbed_hit_does_not_reduce_hp_or_armor(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"]["shield"] = 300
        run = run_scenario(scenario, CHARACTERS)
        target = run["final_states"]["1E1"]
        calculation = run["events"][0]["damage_calculation"]
        self.assertEqual(target["hp"]["exact"], "8140")
        self.assertEqual(target["armor"]["exact"], "150")
        self.assertEqual(target["shield"]["exact"], "0")
        self.assertEqual(calculation["formula_evaluation"], "skipped_fully_absorbed_by_shield")
        self.assertEqual(calculation["outputs"]["Ar"]["exact"], "0")

    def test_negative_blunt_outputs_are_logged_then_clamped(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"]["armor"] = 400
        run = run_scenario(scenario, CHARACTERS)
        calculation = run["events"][0]["damage_calculation"]
        self.assertEqual(calculation["raw_formula_outputs_before_zero_clamp"]["y"]["exact"], "-700/3")
        self.assertEqual(calculation["raw_formula_outputs_before_zero_clamp"]["Ar"]["exact"], "-2/21")
        self.assertEqual(calculation["outputs"]["y"]["exact"], "0")
        self.assertEqual(calculation["outputs"]["Ar"]["exact"], "0")
        self.assertEqual(run["final_states"]["1E1"]["hp"]["exact"], "8140")
        self.assertEqual(run["final_states"]["1E1"]["armor"]["exact"], "400")

    def test_only_shield_overflow_reaches_damage_formulas(self):
        scenario = deepcopy(SCENARIO)
        scenario["encounter"]["initial_states"]["1E1"]["shield"] = 100
        run = run_scenario(scenario, CHARACTERS)
        target = run["final_states"]["1E1"]
        calculation = run["events"][0]["damage_calculation"]
        self.assertEqual(calculation["shield_handling"]["damage_to_shield"]["exact"], "100")
        self.assertEqual(calculation["shield_handling"]["damage_left_after_shield"]["exact"], "200")
        self.assertEqual(calculation["formula_inputs"]["d_left_after_shield"], "200")
        self.assertEqual(calculation["outputs"]["y"]["exact"], "175/2")
        self.assertEqual(calculation["outputs"]["Ar"]["exact"], "197/56")
        self.assertEqual(target["hp"]["exact"], "16105/2")
        self.assertEqual(target["armor"]["exact"], "8203/56")
        self.assertEqual(target["shield"]["exact"], "0")

    def test_lost_shield_regenerates_after_20_seconds_at_400_per_second(self):
        run = run_scenario(SHIELD_SCENARIO, CHARACTERS)
        regen = next(event for event in run["events"] if event["type"] == "shield_regenerated")
        allocation = regen["eligible_loss_allocations"][0]
        self.assertEqual(allocation["eligible_from_ms"], 20000)
        self.assertEqual(regen["regeneration_interval"]["elapsed_available_ms"], 250)
        self.assertEqual(regen["regeneration_interval"]["regenerated_duration_ms"], 250)
        self.assertEqual(regen["amount_regenerated"]["exact"], "100")
        self.assertEqual(run["final_states"]["1E1"]["shield"]["exact"], "100")
        self.assertEqual(summarize(run)["shield_regenerated_total"]["exact"], "100")

    def test_no_shield_regeneration_before_delay(self):
        scenario = deepcopy(SHIELD_SCENARIO)
        scenario["run_until_ms"] = 19999
        run = run_scenario(scenario, CHARACTERS)
        self.assertFalse(any(event["type"] == "shield_regenerated" for event in run["events"]))
        self.assertEqual(run["final_states"]["1E1"]["shield"]["exact"], "0")

    def test_repeated_shield_hits_keep_independent_delay_timers(self):
        run = run_scenario(REPEATED_SHIELD_SCENARIO, CHARACTERS)
        regen = [event for event in run["events"] if event["type"] == "shield_regenerated"]
        allocations = [event["eligible_loss_allocations"][0] for event in regen]
        self.assertEqual([allocation["loss_instance"] for allocation in allocations], [0, 1])
        self.assertEqual([allocation["eligible_from_ms"] for allocation in allocations], [20000, 30000])
        self.assertEqual([allocation["amount"]["exact"] for allocation in allocations], ["300", "100"])
        self.assertEqual(run["final_states"]["1E1"]["shield"]["exact"], "400")
        self.assertEqual(summarize(run)["impact_count"], 2)

    def test_overlapping_eligible_losses_share_one_400_per_second_rate(self):
        run = run_scenario(OVERLAPPING_REGEN_SCENARIO, CHARACTERS)
        regen = [event for event in run["events"] if event["type"] == "shield_regenerated"]
        self.assertEqual([event["amount_regenerated"]["exact"] for event in regen], ["200", "200"])
        self.assertEqual(regen[1]["shared_rate_per_second"], "400")
        self.assertEqual(
            [item["amount"]["exact"] for item in regen[1]["eligible_loss_allocations"]],
            ["100", "100"],
        )
        self.assertEqual(run["final_states"]["1E1"]["shield"]["exact"], "400")

    def test_branch_b_condition_is_enforced(self):
        scenario = deepcopy(SCENARIO)
        scenario["action_sequence"][0]["target_context"]["target_is_dashing"] = True
        with self.assertRaisesRegex(UnsupportedMechanicError, "target_is_dashing=False"):
            run_scenario(scenario, CHARACTERS)

    def test_scripted_target_distance_drives_projectile_impact_time(self):
        scenario = deepcopy(SCENARIO)
        characters = deepcopy(CHARACTERS)
        ability = characters["3E5"]["abilities"]["1b"]
        ability.update(
            {
                "impact_timing": "projectile",
                "fallback_anchor": "end_of_active",
                "projectile_release_timing": "after_active",
                "projectile_speed_mps": 1000,
            }
        )
        scenario["action_sequence"][0]["target_distance_m"] = 10
        run = run_scenario(scenario, characters)
        event = run["events"][0]
        self.assertEqual(event["timing_calculation"]["projectile_release_time_ms"], 320)
        self.assertEqual(event["timing_calculation"]["travel_time_ms"], 10)
        self.assertEqual(event["time_ms"], 330)


if __name__ == "__main__":
    unittest.main()
