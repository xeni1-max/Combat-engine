"""Affine sustained pressure shares root-flow recovery without damage ticks."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.continuous_numeric import recorded_root_integral,recorded_root_rate,recorded_root_knots
from combat_sim.mechanics.delayed_shield import DelayedShieldRecovery
from combat_sim.mechanics.recovery_flow import AffineRate,RateShape,RootRate,RecoveryCursor,_rate_crossings
from combat_sim.mechanics.signed_rates import SignedRate


class AffineRecoveryTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def test_affine_positive_rate_and_integral_use_seconds(self):
        rate=AffineRate(880,100,250)
        self.assertEqual(rate.rate(D(180)),900)
        self.assertEqual(rate.integral(D(100),D(180)),D('71.2'))

    def test_declining_rate_stops_at_zero_without_negative_supply(self):
        rate=AffineRate(100,100,-200)
        self.assertEqual(rate.rate(D(1000)),0)
        self.assertEqual(rate.integral(D(100),D(1000)),25)
        self.assertEqual(recorded_root_knots(rate.record()),{D(600)})

    def test_mixed_root_and_affine_curve_roundtrips(self):
        shape=RateShape(D(40),(RootRate(600,0,0,1),),(AffineRate(100,0,200),))
        record=shape.record();self.assertEqual(record['curve_kind'],'sum_rates_v1')
        self.assertEqual(recorded_root_rate(record,D(1000)),940)
        self.assertEqual(recorded_root_integral(record,D(0),D(1000)),640)

    def test_old_rate_record_has_no_new_empty_fields(self):
        self.assertEqual(RateShape(D(40)).record(),{'curve_kind':'sum_root_v1','constant_per_second':D(40),'terms':[]})

    def test_delayed_affine_supply_is_shifted_and_service_capped(self):
        rate=AffineRate(100,0,200);r=DelayedShieldRecovery(1000,200)
        r.add_curve(D(0),D(1000),rate.integral(D(0),D(1000)),rate.record())
        plan=r.plan(D(0),D(2500))
        self.assertEqual(plan.delivered(D(1000)),0)
        self.assertLess(abs(plan.delivered(D(1500))-75),D('1e-20'))
        self.assertLess(abs(plan.total-200),D('1e-20'))
        self.assertTrue(any(p.shape.affine_terms for p in plan.pieces))

    def test_new_analytic_loss_can_feed_the_old_advance_adapter(self):
        rate=AffineRate(100,0,200);r=DelayedShieldRecovery(1000,200)
        r.add_curve(D(0),D(1000),rate.integral(D(0),D(1000)),rate.record())
        self.assertLess(abs(r.advance(D(0),D(2500))-200),D('1e-20'))

    def test_shifted_future_ramp_stays_zero_before_its_true_origin_crossing(self):
        rate=AffineRate(100,1000,200);r=DelayedShieldRecovery(1000,500)
        r.add_curve(D(0),D(1000),rate.integral(D(0),D(1000)),rate.record())
        plan=r.plan(D(0),D(2500))
        self.assertEqual(plan.delivered(D(1500)),0)
        self.assertEqual(plan.delivered(D(1750)),D('6.25'))
        self.assertEqual(plan.total,25)

    def test_prefix_consumption_does_not_restart_the_affine_service_plan(self):
        rate=RateShape(affine_terms=(AffineRate(100,0,200),));r=DelayedShieldRecovery(1000,200)
        r.add_curve(D(0),D(1000),rate.integral(D(0),D(1000)),rate.record())
        plan=r.plan(D(0),D(2500));cursor=RecoveryCursor(r,plan)
        amounts=[cursor.consume(t) for t in map(D,(1000,1200,1500,1750,2000,2500))]
        self.assertLess(abs(sum(amounts)-plan.total),D('1e-20'))
        self.assertLess(abs(r.recovered-200),D('1e-20'))

    def test_linear_rate_crossing_and_signed_cells_agree(self):
        shape=RateShape(affine_terms=(AffineRate(100,0,200),))
        crossings=_rate_crossings(shape,D(0),D(1000),D(200))
        self.assertEqual(len(crossings),1);self.assertLess(abs(crossings[0]-500),D('1e-20'))
        net=SignedRate.combine(D(0),((D(1),shape),(D(-1),RateShape(D(200)))))
        cells=net.cells(D(0),D(1000));self.assertEqual([s for _,_,s in cells],[-1,1])
        self.assertLess(abs(cells[0][1]-500),D('1e-10'))

    def test_signed_declining_rates_stay_clipped_after_the_zero(self):
        shape=RateShape(affine_terms=(AffineRate(100,0,-200),))
        net=SignedRate.combine(D(0),((D(1),shape),(D(-1),RateShape(D(25)))))
        self.assertEqual(net.value(D(1000)),-25)
        self.assertEqual(net.bounds(D(600),D(1000)),(D(-25),D(-25)))
        cells=net.cells(D(0),D(1000));self.assertEqual([s for _,_,s in cells],[1,-1])
        self.assertLess(abs(cells[0][1]-375),D('1e-10'))

    def test_cyclic_recovery_of_mixed_analytic_losses_preserves_work(self):
        source=RateShape(D(20),(RootRate(10,0,0,1),),(AffineRate(100,0,200),))
        amount=source.integral(D(0),D(1000));r=DelayedShieldRecovery(1000,400)
        r.add_curve(D(0),D(1000),amount,source.record())
        first=r.plan(D(0),D(2500));r.commit_plan(first)
        # Reabsorbed work retains both root and affine supply in its new debt.
        for piece in first.pieces:
            loss=piece.shape.integral(piece.begin,piece.end)
            if loss:r.add_curve(piece.begin,piece.end,loss,piece.shape.record())
        second=r.plan(D(2500),D(4000))
        self.assertLess(abs(first.total-amount),D('1e-20'))
        self.assertLess(abs(second.total-amount),D('1e-20'))

    def test_invalid_affine_values_and_slopes_reject(self):
        for args in ((-1,0,0),(1,-1,0),(1,0,'NaN'),(1,0,True)):
            with self.assertRaises(ValueError):AffineRate(*args)
        with self.assertRaises(ValueError):RateShape(affine_terms=(RootRate(1,0,0,1),))


if __name__=='__main__':unittest.main()
