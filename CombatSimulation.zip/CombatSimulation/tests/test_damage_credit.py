import unittest
from fractions import Fraction

from combat_sim.mechanics.damage_credit import (
    damage_based_recovery_amount,
    recovery_damage_basis,
)


class DamageCreditTests(unittest.TestCase):
    def test_shield_only_damage_provides_no_healing_or_revival_credit(self):
        self.assertEqual(damage_based_recovery_amount(500, 500, Fraction(1, 5)), 0)
        self.assertEqual(damage_based_recovery_amount(500, 500, 1), 0)

    def test_mixed_damage_excludes_shield_before_applying_20_percent(self):
        self.assertEqual(recovery_damage_basis(1000, 800), 200)
        self.assertEqual(damage_based_recovery_amount(1000, 800, Fraction(1, 5)), 40)

    def test_damage_equal_revival_uses_the_same_shield_exclusion(self):
        self.assertEqual(damage_based_recovery_amount(1000, 800, 1), 200)

    def test_zero_damage_and_exact_fractional_entitlements(self):
        self.assertEqual(damage_based_recovery_amount(0, 0, 1), 0)
        self.assertEqual(damage_based_recovery_amount(Fraction(9, 2), 1, Fraction(1, 5)), Fraction(7, 10))

    def test_invalid_damage_totals_and_negative_percentages_are_rejected(self):
        for total, shield in ((-1, 0), (1, -1), (1, 2)):
            with self.subTest(total=total, shield=shield):
                with self.assertRaises(ValueError):
                    recovery_damage_basis(total, shield)
        with self.assertRaises(ValueError):
            damage_based_recovery_amount(10, 0, -1)


if __name__ == "__main__":
    unittest.main()
