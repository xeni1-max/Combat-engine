"""Actual climb controls, turns and linked projection on one reference writer."""
from copy import deepcopy
from decimal import Decimal as D
from fractions import Fraction as F
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.exact_ratio import read_ratio
from tests.test_turn_links import run
from tests.test_actor_facing_combat import scene as base
from tests.test_climb_combat import climb
from tests.test_native_turns import turn
from tests.test_mobile_combat import events,PROFILES
from tests.test_grapple_links_combat import attach,force
from tests.test_world_colliders_combat import wall


def scene(duration=900,character='1E2',at=200):
    s=base(duration,character);s['id']='native_turning_climb'
    s['encounter']['participants']['A']['position_m']=['4.6',0]
    climb(s);turn(s,90,at);return s


def angular_wall(duration=600):
    s=scene(duration,at=130);s['id']='climb_angular_wall'
    obj=wall('turn_wall',x='4.9',z='.8',size=('.1',4,'1.6'),hp=None)
    obj['parts'][0]['centre_m'][1]=0;s['initial_colliders']=[obj];return s


def pair(duration=900,*,both=True,linked_at=0,expiry=5000,turning=True):
    s=scene(duration,at=130);s['id']='linked_prescribed_climb'
    s['encounter']['participants']['B']=deepcopy(s['encounter']['participants']['A'])
    s['encounter']['participants']['B'].update(team='B',position_m=['4.6',3])
    s['action_selection']['B']=deepcopy(s['action_selection']['A'])
    obj=wall('twin_cube',x=6,z='.9',size=('1.8',)*3,hp=2000,climbable=True)
    obj['parts'][0]['centre_m'][1]=3;s['initial_colliders']=[obj]
    s['spatial_interventions']=[attach(linked_at,identity='climb_pair',duration=expiry)]
    if both:
        climb(s,'B',target='twin_cube')
        if turning:turn(s,-90,200,'B')
    if not turning:s.pop('turn_script',None)
    return s


def real_grab(duration=650):
    s=scene(duration,at=130);s['id']='real_grab_during_climb'
    s['encounter']['participants']['B'].update(character='1E5',position_m=['3.5',0],facing='+x')
    s['action_selection']['B'].update(abilities=['2'],start_ms=0,reload_when_empty=False)
    return s


def charge_grab(duration=250):
    s=scene(duration,at=130);s['id']='actual_charge_grab_during_climb'
    s['encounter']['participants']['B'].update(character='3E5',position_m=['2.4',0],facing='+x')
    s['action_selection']['B'].update(abilities=['Ultimate'],start_ms=0,reload_when_empty=False)
    return s


def death_pair(duration=650):
    s=pair(duration);s['id']='gun_death_during_paired_climb'
    s['encounter']['participants']['B']['initial_state']['hp']=1
    s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
    s['encounter']['participants']['C'].update(position_m=[0,3])
    s['action_selection']['C']=deepcopy(s['action_selection']['A'])
    s['action_selection']['C'].update(abilities=['1'],start_ms=200)
    return s


def heavy_pair(duration=291):
    s=pair(duration);s['id']='heavy_knock_at_paired_climb_start'
    for command in s['movement_script']:
        if command['action']=='climb':command['at_ms']=140
    s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
    s['encounter']['participants']['C'].update(character='3E5',team='B',position_m=['3.5',0])
    s['action_selection']['C']=deepcopy(s['action_selection']['A'])
    s['action_selection']['C'].update(abilities=['4'],start_ms=0)
    return s


def bad_range():
    s=pair(both=False);s['encounter']['participants']['A']['position_m']=['4.599',0]
    return s


class TurningClimbTests(unittest.TestCase):
    def conserved(self,r):
        damage=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for name,lives in r['actor_lives'].items():
            hp=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=name)
            self.assertLess(abs(hp-D(r['final_states'][name]['hp'])-damage.amount(target=name)),D('1e-8'))

    def test_all_six_profiles_climb_during_active_turn_and_finish_both(self):
        for name in PROFILES:
            with self.subTest(character=name):
                r=run(scene(character=name));self.conserved(r)
                self.assertEqual(r['metrics']['A']['climbs_completed'],1)
                self.assertTrue(events(r,'turn_completed','A'));self.assertFalse(events(r,'climb_interrupted','A'))
                self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'cube_1')

    def test_gathering_turn_continues_across_active_start_and_corner(self):
        r=run(scene(at=100));self.conserved(r)
        self.assertEqual(D(events(r,'turn_completed','A')[0]['time_ms']),250)
        self.assertEqual(D(events(r,'climb_completed','A')[0]['time_ms']),450)

    def test_angular_obstruction_stops_heading_without_cancelling_tangent_climb(self):
        r=run(angular_wall(240));self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertTrue(events(r,'turn_cancelled','A'))
        self.assertFalse(events(r,'climb_interrupted','A'))
        self.assertEqual(r['final_states']['A']['current_action']['kind'],'climb')

    def test_real_reference_roof_obstruction_still_interrupts_climb(self):
        s=scene(at=130);obj=wall('roof',x='4.6',z='2.45',size=(4,4,'.1'),hp=None)
        obj['parts'][0]['centre_m'][1]=0;s['initial_colliders']=[obj]
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertTrue(events(r,'climb_interrupted','A'))
        self.assertEqual(r['metrics']['A']['climbs_completed'],0)

    def test_two_linked_climbers_keep_compatible_prescribed_routes(self):
        r=run(pair(turning=False));self.conserved(r)
        self.assertFalse(events(r,'climb_interrupted'))
        for n,support in (('A','cube_1'),('B','twin_cube')):
            self.assertEqual(r['metrics'][n]['climbs_completed'],1)
            self.assertEqual(r['final_states'][n]['locomotion']['support_id'],support)
        self.assertEqual(r['grapple_links'][0]['status'],'active')

    def test_two_linked_turning_climbers_preserve_world_reference_offset(self):
        r=run(pair());self.conserved(r)
        self.assertEqual(len(events(r,'climb_completed')),2);self.assertEqual(len(events(r,'turn_completed')),2)
        a,b=r['final_states']['A'],r['final_states']['B']
        self.assertLess(abs(D(b['position_m'][0])-D(a['position_m'][0])),D('1e-8'))
        self.assertLess(abs(D(b['position_m'][1])-D(a['position_m'][1])-3),D('1e-8'))
        self.assertFalse(events(r,'jump_takeoff'))

    def test_incompatible_single_climb_retires_control_without_double_averaging(self):
        r=run(pair(350,both=False));self.conserved(r)
        e=events(r,'climb_interrupted','A')[0]
        self.assertEqual((D(e['time_ms']),e['reason']),(150,'grapple_motion_redirected'))
        self.assertEqual(r['metrics']['A']['climbs_completed'],0)
        expected=D(16)/3-D('9.81')*D('.2')
        for n in ('A','B'):
            self.assertLess(abs(D(r['final_states'][n]['locomotion']['velocity_mps'][2])-expected),D('1e-8'))
        self.assertGreater(D(r['metrics']['A']['dyspnea_paid']),12)
        self.assertEqual(r['grapple_links'][0]['status'],'active')
        self.assertTrue([e for e in events(r,'movement_intent_blocked','A') if e['action']=='climb'])

    def test_link_attached_mid_climb_keeps_reached_position_and_joint_momentum(self):
        r=run(pair(350,both=False,linked_at=200));self.conserved(r)
        e=events(r,'climb_interrupted','A')[0]
        self.assertEqual((D(e['time_ms']),e['reason']),(200,'grapple_motion_redirected'))
        expected=D(16)/3-D('9.81')*D('.15')
        for n in ('A','B'):
            self.assertLess(abs(D(r['final_states'][n]['locomotion']['velocity_mps'][2])-expected),D('1e-8'))
        self.assertLess(abs(D(r['grapple_links'][0]['reference_offset_m'][2])+D(8)/15),D('1e-8'))

    def test_ground_drag_rejects_unsupported_climber_without_cancelling_climb(self):
        r=run(real_grab());self.conserved(r)
        self.assertFalse(r['grapple_holds'])
        self.assertEqual(events(r,'grapple_contact_rejected','B')[0]['reason'],'ground_drag_requires_supported_entry')
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)

    def test_actual_charge_grab_during_climb_keeps_hold_and_retires_climb_control(self):
        r=run(charge_grab());self.conserved(r)
        self.assertTrue(r['grapple_holds']);self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertTrue(events(r,'climb_interrupted','A'))
        self.assertEqual(r['grapple_links'][0]['ability'],'Ultimate')
        self.assertEqual(r['grapple_links'][0]['target'],'A')
        self.assertTrue(r['controlled_damage_streams'])

    def test_ground_drag_can_grab_supported_target_during_climb_gathering(self):
        s=real_grab(260);s['movement_script'][0]['at_ms']=100;s.pop('turn_script')
        r=run(s);self.conserved(r)
        self.assertTrue(r['grapple_holds']);self.assertFalse(events(r,'grapple_contact_rejected'))
        self.assertEqual(r['grapple_holds'][0]['target'],'A')

    def test_expiry_at_active_start_releases_group_before_free_climb(self):
        r=run(pair(both=False,expiry=150));self.conserved(r)
        self.assertEqual(r['grapple_links'][0]['status'],'ended')
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertFalse(events(r,'climb_interrupted'))

    def test_link_at_completion_does_not_rewind_or_reopen_finished_climb(self):
        r=run(pair(both=False,linked_at=450));self.conserved(r)
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertFalse(events(r,'climb_interrupted'))
        self.assertEqual(r['grapple_links'][0]['status'],'active')
        self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'cube_1')

    def test_slack_distance_and_turn_preserve_unlinked_climb(self):
        s=pair(both=False);s.pop('spatial_interventions')
        r=run(s,operations=[dict(kind='distance',at_ms=0,length=5)]);self.conserved(r)
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertEqual(r['distance_constraints'][0]['status'],'active');self.assertFalse(events(r,'climb_interrupted'))

    def test_taut_distance_turn_uses_real_redirected_native_path(self):
        s=pair(400,both=False);s.pop('spatial_interventions')
        r=run(s,operations=[dict(kind='distance',at_ms=0,length=3)]);self.conserved(r)
        self.assertEqual(D(r['run_until_ms']),400)
        self.assertTrue(r['distance_path_steps_planned']);self.assertTrue(events(r,'climb_interrupted'))
        self.assertEqual(r['metrics']['A']['climbs_completed'],0)
        self.assertFalse([e for e in events(r,'body_contact') if e['first']=='B' and e['second']=='ground' and D(e['time_ms'])<200])
        for row in r['last_committed_distance_plan']['bernstein_certificate']:
            self.assertTrue(all(read_ratio(v)<=0 for v in row['distance_squared_minus_limit_squared']))

    def test_compatible_pair_agrees_across_precision_order_and_observation(self):
        a=run(pair());s=pair();s['encounter']['participants']=dict(reversed(list(s['encounter']['participants'].items())))
        b=run(s,precision=80,interval=17)
        for n in ('A','B'):
            self.assertEqual(a['metrics'][n]['climbs_completed'],b['metrics'][n]['climbs_completed'])
            for x,y in zip(a['final_states'][n]['body_origin_m'],b['final_states'][n]['body_origin_m']):
                self.assertLess(abs(D(x)-D(y)),D('1e-8'))

    def test_target_expiry_preempts_linked_climb_without_detaching_grapple(self):
        s=pair(400);s['initial_colliders'][0]['duration_ms']=300
        r=run(s);self.conserved(r)
        self.assertEqual(r['grapple_links'][0]['status'],'active')
        self.assertTrue(events(r,'climb_interrupted','B'));self.assertTrue(events(r,'climb_interrupted','A'))
        self.assertFalse(events(r,'climb_completed'))

    def test_real_gun_death_releases_partner_without_preempting_its_compatible_climb(self):
        r=run(death_pair());self.conserved(r)
        self.assertFalse(r['final_states']['B']['alive'])
        death=D(r['final_states']['B']['died_at_ms']);self.assertGreater(death,150);self.assertLess(death,450)
        self.assertEqual(r['grapple_links'][0]['end_reason'],'participant_died')
        self.assertEqual(r['metrics']['A']['climbs_completed'],1)
        self.assertFalse(events(r,'climb_interrupted','A'))

    def test_actual_heavy_knock_preempts_paired_climbs_with_summed_resistance(self):
        r=run(heavy_pair());self.conserved(r);knock=r['knock_impulses'][0]
        self.assertEqual(knock['assessment']['actors'],['A','B'])
        self.assertEqual(D(knock['assessment']['maximum_hp_sum']),16280)
        self.assertEqual(D(knock['assessment']['armor_sum']),300)
        for n in ('A','B'):
            self.assertTrue(events(r,'climb_interrupted',n));self.assertGreater(D(r['metrics'][n]['dyspnea_paid']),12)
            self.assertEqual(r['metrics'][n]['climbs_completed'],0)
        self.assertFalse(events(r,'jump_takeoff'))

    def test_failed_entry_range_while_linked_and_turning_does_not_pay_or_detach(self):
        r=run(bad_range());self.conserved(r)
        check=events(r,'climb_range_checked','A')[0]
        self.assertFalse(check['allowed']);self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)
        self.assertEqual(r['grapple_links'][0]['status'],'active')
        self.assertTrue(events(r,'turn_completed','A'));self.assertFalse(events(r,'climb_active_started'))


if __name__=='__main__':unittest.main()
