"""Ordinary open-edge movement and labelled spatial/link interaction probes."""
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.models import UnsupportedMechanicError
from combat_sim.spatial_transitions import SpatialChange
from tests.test_equilibrium_combat import scene as base_scene,run
from tests.test_binding_combat import run as configured_run
from tests.test_mobile_combat import read,command,events
from tests.test_grapple_links_combat import force,attach


def scene(duration=1000,*,x='249.95',y=-20,character='1E2'):
    s=base_scene(duration,character=character);s['id']='finite_ground_edge'
    s['encounter']['participants']['A']['position_m']=[x,y]
    s['action_selection']['A']['start_ms']=100000
    return s


def driven(duration=400,*,x='249.95',velocity=(2,0,0),reference=None):
    s=scene(duration,x=x)
    s['spatial_interventions']=[force(0,'A',velocity,reference=reference)]
    return s


class FiniteGroundCombatTests(unittest.TestCase):
    def setUp(self):
        context=localcontext(Context(prec=70));context.__enter__();self.addCleanup(context.__exit__,None,None,None)

    def conserved(self,r):
        ledger=DamageLedger.from_record(r['applied_hp_history']);heals=HealingHistory.from_run(r)
        for n,lives in r['actor_lives'].items():
            supply=sum((D(l['initial_hp']) for l in lives),D(0))+heals.amount(actor=n)
            self.assertLess(abs(supply-D(r['final_states'][n]['hp'])-ledger.amount(target=n)),D('1e-8'))

    def test_stationary_partial_projection_has_actual_support(self):
        r=run(scene(200));self.conserved(r)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])
        self.assertFalse(events(r,'world_support_lost','A'))

    def test_initial_fully_outside_body_falls_without_an_invented_wall_or_death(self):
        r=run(scene(1000,x=251));self.conserved(r);a=r['final_states']['A']
        self.assertFalse(a['locomotion']['grounded']);self.assertEqual(D(a['body_origin_m'][2]),D('.875')-D('9.81')/2)
        self.assertEqual(D(a['hp']),8140);self.assertFalse(events(r,'jump_landed','A'))

    def test_ordinary_walking_crosses_the_ground_edge_and_reaches_horizon(self):
        s=scene(1000,x='249.8');command(s,'A',0,'walk');r=run(s);self.conserved(r)
        self.assertEqual(r['run_until_ms'],'1000');self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
        loss=events(r,'world_support_lost','A');self.assertEqual(len(loss),1)
        self.assertAlmostEqual(D(loss[0]['time_ms']),180,places=15)
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),250)
        self.assertFalse(events(r,'jump_takeoff','A'));self.assertFalse(events(r,'jump_landed','A'))

    def test_ordinary_running_can_leave_the_finite_floor(self):
        s=scene(1000,x=249);command(s,'A',0,'run');r=run(s);self.conserved(r)
        self.assertTrue(events(r,'world_support_lost','A'));self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
        self.assertGreater(D(r['final_states']['A']['position_m'][0]),252)

    def test_departure_retains_exact_tangent_velocity_and_one_gravity(self):
        r=run(driven());self.conserved(r);loss=events(r,'world_support_lost','A')
        self.assertEqual(len(loss),1);self.assertAlmostEqual(D(loss[0]['time_ms']),75,places=15)
        dt=(400-D(loss[0]['time_ms']))/1000;a=r['final_states']['A']
        self.assertEqual(tuple(map(D,loss[0]['velocity_mps'])),(2,0,0))
        self.assertAlmostEqual(D(a['body_origin_m'][2]),D('.875')-D('9.81')*dt**2/2,places=15)
        self.assertAlmostEqual(D(a['locomotion']['velocity_mps'][2]),-D('9.81')*dt,places=15)
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_all_four_open_edges_and_diagonal_corner_use_the_same_physics(self):
        for xy,velocity in (((-D('249.95'),-20),(-2,0,0)),((0,D('249.95')),(0,2,0)),
                ((0,-D('249.95')),(0,-2,0)),((D('249.95'),D('249.95')),(2,2,0))):
            with self.subTest(xy=xy):
                s=scene(400,x=str(xy[0]),y=str(xy[1]));s['spatial_interventions']=[force(0,'A',velocity)]
                r=run(s);self.conserved(r)
                self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
                self.assertEqual(len(events(r,'world_support_lost','A')),1)
                self.assertFalse(events(r,'jump_landed','A'))

    def test_outward_acceleration_from_last_contact_band_does_not_chatter(self):
        # Observe before the later, legitimate torso underside can meet the
        # sheet while the legs hang just beyond its edge.
        s=scene(200,x='250.09999999999999999998');command(s,'A',0,'walk')
        r=run(s);self.conserved(r)
        self.assertEqual(len(events(r,'world_support_lost','A')),1)
        self.assertFalse(events(r,'jump_landed','A'));self.assertFalse(r['final_states']['A']['locomotion']['grounded'])

    def test_all_six_body_scales_depart_without_new_jump_cost(self):
        for character in ('1E1','1E2','1E3','1E5','2E4','3E5'):
            with self.subTest(character=character):
                s=scene(500,character=character);s['spatial_interventions']=[force(0,'A',[2,0,0])]
                r=run(s);self.conserved(r)
                self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
                self.assertEqual(r['metrics']['A']['jumps_started'],0);self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),0)

    def test_crouch_on_a_partial_floor_keeps_the_feet_support(self):
        s=scene(400);command(s,'A',0,'crouch');r=run(s);self.conserved(r)
        self.assertEqual(r['metrics']['A']['crouches_completed'],1)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded']);self.assertFalse(events(r,'world_support_lost','A'))

    def test_partial_floor_get_up_crosses_pose_support_switch_without_false_impact(self):
        s=scene(600);s['encounter']['participants']['A']['initial_state']['knocked_down']=True
        r=run(s);self.conserved(r)
        self.assertEqual(len(events(r,'get_up_started','A')),1)
        self.assertEqual([D(e['time_ms']) for e in events(r,'get_up_completed','A')],[400])
        self.assertEqual(D(r['metrics']['A']['dyspnea_paid']),9)
        self.assertFalse(events(r,'equilibrium_deformation_blocked','A'));self.assertFalse(events(r,'body_contact'))
        self.assertFalse(r['final_states']['A']['knocked_down'])
        self.assertEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0)

    def test_partial_floor_balance_fall_reaches_knockdown_and_recovers(self):
        s=scene(2000);s['encounter']['participants']['A']['initial_state'].update(disorientation=1000,instability=1000)
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'knockdown_applied','A'));self.assertTrue(events(r,'get_up_completed','A'))
        self.assertFalse(events(r,'equilibrium_deformation_blocked','A'));self.assertFalse(events(r,'body_contact'))
        self.assertFalse(r['final_states']['A']['knocked_down']);self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_raised_support_uses_the_same_pose_switch_revalidation(self):
        from tests.test_terrain_support_combat import platform_scene
        for down in (False,True):
            with self.subTest(initially_prone=down):
                s=platform_scene(2000,x=20,velocity=0)
                if down:s['encounter']['participants']['A']['initial_state']['knocked_down']=True
                else:s['encounter']['participants']['A']['initial_state'].update(disorientation=1000,instability=1000)
                r=run(s);self.conserved(r)
                if not down:self.assertTrue(events(r,'knockdown_applied','A'))
                self.assertEqual(len(events(r,'get_up_started','A')),1)
                self.assertEqual(len(events(r,'get_up_completed','A')),1)
                self.assertFalse(events(r,'equilibrium_deformation_blocked','A'))
                self.assertEqual(r['final_states']['A']['locomotion']['support_id'],'deck')

    def test_above_and_below_open_floor_projection_allow_spatial_placement(self):
        for point in ([251,-20,'.875'],[0,-20,-3],[251,-20,-3],[0,-20,202]):
            with self.subTest(point=point):
                r=run(driven(100,reference=point,velocity=(0,0,0)));self.conserved(r)
                self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
                self.assertFalse(events(r,'jump_landed','A'));self.assertLess(D(r['final_states']['A']['body_origin_m'][2]),D(str(point[2])))

    def test_new_occupancy_cannot_cross_the_actual_zero_thickness_sheet(self):
        for point in ([0,-20,0],['250.05',-20,0]):
            with self.subTest(point=point):
                r=run(driven(reference=point,velocity=(0,0,0)));self.conserved(r)
                result=events(r,'spatial_intervention_processed')[0]['intervention']
                self.assertEqual(result['status'],'rejected')
                self.assertIn('crosses the finite ground surface',result['reason'])
                self.assertFalse(events(r,'spatial_transition_committed'))

    def test_direct_spatial_preflight_rejects_sheet_crossing_without_mutation(self):
        def check(w):
            before=w.spatial_transitions.reference('A')
            with self.assertRaisesRegex(ValueError,'crosses the finite ground surface'):
                w.spatial_transitions.prepare((SpatialChange('A',1,reference_m=(0,-20,0)),),source='fixture:sheet_occupancy')
            self.assertEqual(w.spatial_transitions.reference('A'),before)
        configured_run(scene(100),rules=read('data/movement/combat_locomotion.json'),operations=((0,check),))

    def test_descending_body_lands_on_partial_positive_area(self):
        r=run(driven(800,x='249.95',reference=['250.05',-20,2],velocity=(0,0,-1)));self.conserved(r)
        self.assertEqual(len(events(r,'jump_landed','A')),1)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])
        self.assertAlmostEqual(D(r['final_states']['A']['locomotion']['feet_z_m']),0,places=20)

    def test_descending_body_outside_projection_passes_ground_height(self):
        r=run(driven(800,reference=[251,-20,2],velocity=(0,0,-1)));self.conserved(r)
        self.assertFalse(events(r,'jump_landed','A'));self.assertFalse(events(r,'body_contact','A'))
        self.assertLess(D(r['final_states']['A']['body_origin_m'][2]),0)

    def test_return_from_above_the_edge_can_land_on_the_finite_surface(self):
        r=run(driven(1000,reference=[251,-20,2],velocity=(-2,0,0)));self.conserved(r)
        self.assertEqual(len(events(r,'jump_landed','A')),1)
        self.assertTrue(r['final_states']['A']['locomotion']['grounded'])

    def test_underside_contact_cancels_upward_velocity_without_grounding(self):
        r=run(driven(300,reference=[0,-20,-1],velocity=(0,0,3)));self.conserved(r)
        contacts=events(r,'body_contact');self.assertTrue(contacts)
        self.assertFalse(events(r,'jump_landed','A'));self.assertFalse(r['final_states']['A']['locomotion']['grounded'])
        self.assertLess(D(r['final_states']['A']['locomotion']['velocity_mps'][2]),0)

    def test_edge_intercepts_a_body_that_straddles_the_sheet(self):
        r=run(driven(300,reference=['250.4',-20,0],velocity=(-2,0,0)));self.conserved(r)
        self.assertTrue(events(r,'body_contact'));self.assertFalse(events(r,'jump_landed','A'))
        self.assertGreaterEqual(D(r['final_states']['A']['position_m'][0]),D('250.1')-D('1e-15'))

    def test_rigid_pair_loses_floor_support_together_and_keeps_link(self):
        s=scene(400);s['encounter']['participants']['B']['position_m']=['249.95',-22]
        s['spatial_interventions']=[force(0,'A',[2,0,0]),force(0,'B',[2,0,0]),attach(duration=1000)]
        r=run(s);self.conserved(r);self.assertEqual(r['grapple_links'][0]['status'],'active')
        for name in ('A','B'):
            self.assertFalse(r['final_states'][name]['locomotion']['grounded'])
            self.assertAlmostEqual(D(r['final_states'][name]['body_origin_m'][2]),D('.875')-D('9.81')*D('.325')**2/2,places=15)

    def test_one_grounded_group_member_can_hold_the_other_past_an_edge(self):
        s=scene(200,x='249.95');s['encounter']['participants']['B']['position_m']=['249.5',-22]
        s['spatial_interventions']=[force(0,'A',[2,0,0]),force(0,'B',[2,0,0]),attach(duration=1000)]
        r=run(s);self.conserved(r)
        self.assertEqual(D(r['final_states']['A']['body_origin_m'][2]),D('.875'))
        self.assertEqual(D(r['final_states']['B']['body_origin_m'][2]),D('.875'))

    def test_departure_does_not_cancel_an_independent_real_shot(self):
        s=scene(400,x='249.8');s['encounter']['participants']['A']['facing']='-x'
        s['encounter']['participants']['A']['movement_direction']=[1,0]
        s['action_selection']['A']['start_ms']=0;command(s,'A',0,'walk')
        r=run(s);self.conserved(r)
        self.assertTrue(events(r,'projectile_released','A'));self.assertTrue(events(r,'world_support_lost','A'))
        self.assertFalse([e for e in events(r,'controlled_action_cancelled','A') if e['action']['kind']=='slash_projectile'])

    def test_static_v1_and_historical_inputs_retain_their_explicit_floor_guard(self):
        for version in ('static_faces_v1',None):
            with self.subTest(version=version):
                rules=read('data/movement/combat_locomotion.json')
                if version is None:rules.pop('terrain_support')
                else:rules['terrain_support']={'mode':version}
                with self.assertRaisesRegex(UnsupportedMechanicError,'ground footprint'):
                    configured_run(scene(100),rules=rules)

