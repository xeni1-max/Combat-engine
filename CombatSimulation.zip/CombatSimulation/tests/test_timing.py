import unittest
import json
from pathlib import Path

from combat_sim.mechanics.timing import impact_time_from_activation, self_effect_time_from_activation
from combat_sim.mechanics.status import add_status, apply_self_status, decay_status, self_status_value
from combat_sim.models import UnsupportedMechanicError


ROOT = Path(__file__).resolve().parents[1]
with (ROOT / "data" / "characters.json").open(encoding="utf-8") as stream:
    CHARACTERS = json.load(stream)["characters"]


class ImpactTimingTests(unittest.TestCase):
    def test_active_start_effect_includes_gathering_but_not_active_duration(self):
        start, calculation = impact_time_from_activation(
            0, {"gathering_ms": 180, "active_ms": 300, "impact_timing": "start_of_active"},
        )
        self.assertEqual(start, 180)
        self.assertEqual(calculation["active_end_ms"], 480)

    def test_middle_of_active_includes_gathering(self):
        impact, calculation = impact_time_from_activation(
            1000,
            {"gathering_ms": 140, "active_ms": 180, "impact_timing": "middle_of_active"},
        )
        self.assertEqual(impact, 1230)
        self.assertEqual(calculation["impact_offset_ms"], 230)

    def test_end_of_active_includes_gathering(self):
        impact, _ = impact_time_from_activation(
            0,
            {"gathering_ms": 140, "active_ms": 180, "impact_timing": "end_of_active"},
        )
        self.assertEqual(impact, 320)

    def test_midpoint_rounds_fractional_millisecond_up(self):
        impact, _ = impact_time_from_activation(
            0,
            {"gathering_ms": 0, "active_ms": 181, "impact_timing": "middle_of_active"},
        )
        self.assertEqual(impact, 91)

    def test_projectile_release_and_constant_speed_travel(self):
        impact, calculation = impact_time_from_activation(
            1000,
            {
                "gathering_ms": 10,
                "active_ms": 20,
                "impact_timing": "projectile",
                "fallback_anchor": "end_of_active",
                "projectile_release_timing": "after_active",
                "projectile_speed_mps": 3,
            },
            target_distance_m=1,
        )
        self.assertEqual(impact, 1364)
        self.assertEqual(calculation["projectile_release_time_ms"], 1030)
        self.assertEqual(calculation["travel_time_ms"], 334)

    def test_constant_acceleration_changes_travel_time(self):
        impact, calculation = impact_time_from_activation(
            0,
            {
                "gathering_ms": 10,
                "active_ms": 20,
                "impact_timing": "projectile",
                "fallback_anchor": "end_of_active",
                "projectile_release_timing": "after_active",
                "projectile_speed_mps": 100,
                "projectile_acceleration_mps2": -10,
            },
            target_distance_m=100,
        )
        self.assertEqual(calculation["travel_time_ms"], 1056)
        self.assertGreater(impact, 1030)
        self.assertEqual(
            calculation["acceleration_interpretation"], "constant along the travel direction"
        )

    def test_explicit_archived_projectile_fallback_remains_reproducible(self):
        # Current profiles have no fallbacks; historical input snapshots can
        # still reproduce the expressly supplied surrogate anchor.
        impact, calculation = impact_time_from_activation(
            0,
            {
                "gathering_ms": 10,
                "active_ms": 21,
                "impact_timing": "projectile",
                "fallback_anchor": "middle_of_active",
                "projectile_release_timing": "after_active",
                "projectile_speed_mps": 10,
            },
        )
        self.assertEqual(impact, 21)
        self.assertEqual(calculation["used_fallback"], "middle_of_active")

    def test_projectile_beyond_deceleration_range_is_rejected(self):
        with self.assertRaises(UnsupportedMechanicError):
            impact_time_from_activation(
                0,
                {
                    "gathering_ms": 0,
                    "active_ms": 0,
                    "impact_timing": "projectile",
                    "projectile_release_timing": "after_active",
                    "projectile_speed_mps": 10,
                    "projectile_acceleration_mps2": -10,
                },
                target_distance_m=6,
            )

    def test_user_supplied_1e2_ability4_duration_enables_projectile_timing(self):
        ability = CHARACTERS["1E2"]["timing_profiles"]["4"]
        impact, calculation = impact_time_from_activation(0, ability, target_distance_m=100)
        self.assertEqual(calculation["active_ms"], 60)
        # Current source has no base Gathering for this 60 ms firing phase.
        self.assertEqual(calculation["projectile_release_time_ms"], 60)
        self.assertEqual(calculation["travel_time_ms"], 72)
        self.assertEqual(impact, 132)

    def test_profile_timing_data_covers_all_six_primary_characters(self):
        for character in ("1E1", "1E2", "1E3", "1E5", "2E4", "3E5"):
            profiles = CHARACTERS[character]["timing_profiles"]
            self.assertTrue(profiles)
            self.assertTrue(all("timing_source" in profile for profile in profiles.values()))

    def test_current_projectile_profiles_require_explicit_distance(self):
        checked = 0
        for character, data in CHARACTERS.items():
            for ability, profile in data["timing_profiles"].items():
                if profile["impact_timing"] != "projectile":
                    continue
                with self.subTest(character=character, ability=ability):
                    self.assertNotIn("fallback_anchor", profile)
                    with self.assertRaisesRegex(UnsupportedMechanicError, "distance is required"):
                        impact_time_from_activation(0, profile)
                checked += 1
        self.assertEqual(checked, 12)

    def test_zero_distance_impacts_at_release_for_current_projectiles(self):
        for character, ability, release in (
            ("1E1", "1", 320), ("1E1", "2", 400), ("1E1", "Ultimate", 620),
            ("1E2", "1", 40), ("1E2", "3", 220), ("1E2", "4", 60),
            ("1E2", "Ultimate", 370),
            ("1E3", "1", 320), ("1E3", "2", 360), ("1E3", "4", 320),
            ("3E5", "2", 400),
        ):
            with self.subTest(character=character, ability=ability):
                impact, calculation = impact_time_from_activation(
                    0, CHARACTERS[character]["timing_profiles"][ability], target_distance_m=0,
                )
                self.assertEqual(calculation["projectile_release_time_ms"], release)
                self.assertEqual(calculation["travel_time_ms"], 0)
                self.assertEqual(impact, release)

    def test_3e5_ultimate_uses_contact_instead_of_fixed_midpoint(self):
        profile = CHARACTERS["3E5"]["timing_profiles"]["Ultimate"]
        self.assertEqual(profile["impact_timing"], "contact_event")
        self.assertEqual(profile["impact_triggers"], [
            {"event": "first_target_contact", "recipient": "target"},
        ])
        with self.assertRaisesRegex(UnsupportedMechanicError, "contact_event"):
            impact_time_from_activation(0, profile)

    def test_projectile_self_effect_midpoint_does_not_require_target_distance(self):
        profile = CHARACTERS["1E1"]["timing_profiles"]["1"]
        effect = CHARACTERS["1E1"]["documented_abilities"]["1"]["self_effects"][0]
        time, calculation = self_effect_time_from_activation(
            0, profile, effect["application_timing"],
        )
        self.assertEqual(time, 230)
        self.assertEqual(calculation["self_effect_time_ms"], 230)
        self.assertEqual(calculation["ability_impact_timing"], "projectile")
        self.assertNotIn("impact_time_ms", calculation)
        self.assertNotIn("projectile_release_time_ms", calculation)

    def test_projectile_self_effect_release_and_target_impact_are_separate(self):
        profile = CHARACTERS["1E2"]["timing_profiles"]["1"]
        self_time, _ = self_effect_time_from_activation(0, profile, "middle_of_active")
        impact, calculation = impact_time_from_activation(0, profile, target_distance_m=100)
        self.assertEqual(self_time, 20)
        self.assertEqual(calculation["projectile_release_time_ms"], 40)
        self.assertEqual(impact, 154)

    def test_throw_self_effect_uses_active_midpoint(self):
        profile = CHARACTERS["1E2"]["timing_profiles"]["Ultimate"]
        time, _ = self_effect_time_from_activation(0, profile, "middle_of_active")
        self.assertEqual(time, 270)

    def test_self_effect_midpoint_includes_running_and_current_disorientation(self):
        time, calculation = self_effect_time_from_activation(
            1000, CHARACTERS["1E1"]["timing_profiles"]["1"], "middle_of_active",
            disorientation_at_gathering_start=80, is_running_at_gathering_start=True,
        )
        self.assertEqual(time, 1338)
        self.assertEqual(calculation["effective_gathering_ms"], 248)

    def test_1e5_on_impact_self_effect_uses_its_midpoint_hit(self):
        profile = CHARACTERS["1E5"]["timing_profiles"]["1"]
        time, calculation = self_effect_time_from_activation(0, profile, "impact")
        self.assertEqual(time, 230)
        self.assertEqual(calculation["active_end_ms"], 320)
        # Self 150 bypasses mitigation; the remaining 90 ms of Active leaves 60.
        self.assertEqual(decay_status(apply_self_status(0, 150), calculation["active_end_ms"] - time), 60)

    def test_1e5_self_effect_keeps_60_for_next_gathering(self):
        # Isolated disorientation/timing check, not complete 1E5 slash combat.
        profile = CHARACTERS["1E5"]["timing_profiles"]["1"]
        first_impact, first = impact_time_from_activation(0, profile)
        remaining = decay_status(apply_self_status(0, 150), first["active_end_ms"] - first_impact)
        second_impact, second = impact_time_from_activation(
            first["active_end_ms"], profile, disorientation_at_gathering_start=remaining,
        )
        self.assertEqual(remaining, 60)
        self.assertEqual(second["effective_gathering_ms"], 200)
        self.assertEqual(second_impact, 610)
        self.assertEqual(self_status_value(150, is_running_at_application=True), 180)

    def test_contact_and_unspecified_self_effects_are_not_given_default_times(self):
        with self.assertRaisesRegex(UnsupportedMechanicError, "contact_event"):
            self_effect_time_from_activation(
                0, CHARACTERS["3E5"]["timing_profiles"]["Ultimate"], "impact",
            )
        with self.assertRaisesRegex(UnsupportedMechanicError, "explicit event anchor"):
            self_effect_time_from_activation(
                0, CHARACTERS["1E5"]["timing_profiles"]["1"], "on swing",
            )

    def test_2e4_thrust_uses_its_explicit_midpoint_anchor(self):
        impact, _ = impact_time_from_activation(0, CHARACTERS["2E4"]["timing_profiles"]["1"])
        self.assertEqual(impact, 230)

    def test_1e5_given_80_current_disorientation_adds_80_gathering(self):
        profile = CHARACTERS["1E5"]["timing_profiles"]["1"]
        first_impact, first = impact_time_from_activation(0, profile)
        second_impact, second = impact_time_from_activation(
            first["active_end_ms"], profile, disorientation_at_gathering_start=80,
        )
        self.assertEqual(first_impact, 230)
        self.assertEqual(first["active_end_ms"], 320)
        self.assertEqual(second["gathering_ms"], 140)
        self.assertEqual(second["additional_gathering_ms"], 80)
        self.assertEqual(second["effective_gathering_ms"], 220)
        self.assertEqual(second["active_start_ms"], 540)
        self.assertEqual(second_impact, 630)
        self.assertEqual(second["active_end_ms"], 720)

    def test_historical_after_active_self_status_fixture_preserves_event_order(self):
        character = CHARACTERS["1E5"]
        ability = character["documented_abilities"]["1"]
        effects = ability["shared_component_effects"]
        reference = effects["last_confirmed_timing_reference"]
        self.assertEqual(reference["application"], "immediately_after_active")
        profile = character["timing_profiles"][ability["timing_profile"]]
        component, start, current = "a", 0, 0
        components, impacts, active_ends, snapshots, events = [], [], [], [], []
        for _ in range(3):
            snapshots.append(current)
            events.append((start, "next_gathering_started"))
            impact, calculation = impact_time_from_activation(
                start, profile, disorientation_at_gathering_start=current,
            )
            end = calculation["active_end_ms"]
            # Existing status decays during Gathering/Active; the new 80 is
            # added immediately after Active completes, before the next
            # Gathering samples the state, without collision mitigation.
            events.append((end, "active_completed"))
            current = add_status(
                decay_status(current, end - start), reference["value"],
            )
            events.append((end, "self_disorientation_added"))
            components.append(component)
            impacts.append(impact)
            active_ends.append(end)
            component = ability["consecutive_uses"]["next_component"][component]
            start = end
        self.assertEqual(components, ["a", "b", "a"])
        self.assertEqual(snapshots, [0, 80, 80])
        self.assertEqual(impacts, [230, 630, 1030])
        self.assertEqual(active_ends, [320, 720, 1120])
        self.assertEqual(current, 80)
        self.assertEqual(
            [kind for time, kind in events if time == 320],
            reference["boundary_event_order"],
        )

    def test_disorientation_delays_projectile_release_and_impact(self):
        profile = CHARACTERS["1E1"]["timing_profiles"]["1"]
        impact, calculation = impact_time_from_activation(
            0, profile, target_distance_m=100, disorientation_at_gathering_start=80,
        )
        self.assertEqual(calculation["projectile_release_time_ms"], 400)
        self.assertEqual(impact, 1400)

    def test_running_modifies_base_gathering_before_adding_current_disorientation(self):
        profile = CHARACTERS["1E5"]["timing_profiles"]["1"]
        impact, calculation = impact_time_from_activation(
            0, profile, disorientation_at_gathering_start=80,
            is_running_at_gathering_start=True,
        )
        self.assertEqual(calculation["gathering_ms"], 140)
        self.assertEqual(calculation["modified_base_gathering_ms"], 168)
        self.assertEqual(calculation["additional_gathering_ms"], 80)
        self.assertEqual(calculation["effective_gathering_ms"], 248)
        self.assertEqual(impact, 338)

    def test_running_self_status_is_scaled_once_then_added_to_modified_base(self):
        # Self effects use the listed amount directly, without mitigation.
        current = self_status_value(80, is_running_at_application=True)
        self.assertEqual(current, 96)
        _, calculation = impact_time_from_activation(
            0, CHARACTERS["1E5"]["timing_profiles"]["1"],
            disorientation_at_gathering_start=current,
            is_running_at_gathering_start=True,
        )
        self.assertEqual(calculation["effective_gathering_ms"], 264)

    def test_running_penalty_uses_the_state_at_each_separate_event(self):
        # Running is sampled separately at application and Gathering start.
        current = self_status_value(80, is_running_at_application=True)
        _, calculation = impact_time_from_activation(
            0, CHARACTERS["1E5"]["timing_profiles"]["1"],
            disorientation_at_gathering_start=current,
            is_running_at_gathering_start=False,
        )
        self.assertEqual(calculation["effective_gathering_ms"], 236)
        self.assertEqual(self_status_value(80), 80)

    def test_running_flags_must_be_boolean(self):
        with self.assertRaisesRegex(ValueError, "boolean"):
            self_status_value(80, is_running_at_application="yes")
        with self.assertRaisesRegex(ValueError, "boolean"):
            impact_time_from_activation(
                0, CHARACTERS["1E5"]["timing_profiles"]["1"],
                is_running_at_gathering_start="yes",
            )

    def test_fractional_disorientation_uses_existing_event_rounding(self):
        profile = {"gathering_ms": 0, "active_ms": 180, "impact_timing": "middle_of_active"}
        impact, calculation = impact_time_from_activation(
            0, profile, disorientation_at_gathering_start="0.5",
        )
        self.assertEqual(impact, 91)
        self.assertEqual(calculation["additional_gathering_ms"], "0.5")

    def test_negative_disorientation_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Disorientation"):
            impact_time_from_activation(
                0, CHARACTERS["1E5"]["timing_profiles"]["1"],
                disorientation_at_gathering_start=-1,
            )

    def test_projectile_profile_includes_weapon_swap_and_release(self):
        ability = CHARACTERS["1E1"]["timing_profiles"]["Ultimate"]
        impact, calculation = impact_time_from_activation(0, ability, target_distance_m=60)
        self.assertEqual(calculation["projectile_release_time_ms"], 620)
        self.assertEqual(calculation["travel_time_ms"], 1000)
        self.assertEqual(impact, 1620)

    def test_documented_1e2_projectile_acceleration_is_used(self):
        ability = CHARACTERS["1E2"]["timing_profiles"]["1"]
        impact, calculation = impact_time_from_activation(0, ability, target_distance_m=100)
        self.assertEqual(calculation["projectile_release_time_ms"], 40)
        self.assertEqual(calculation["travel_time_ms"], 114)
        self.assertEqual(impact, 154)

    def test_falling_contact_triggers_require_an_explicit_contact_event(self):
        for character, ability in (("1E1", "3"), ("3E5", "3")):
            profile = CHARACTERS[character]["timing_profiles"][ability]
            self.assertEqual(profile["impact_timing"], "contact_event")
            with self.assertRaises(UnsupportedMechanicError):
                impact_time_from_activation(0, profile)

    def test_missing_or_unanchored_timing_is_rejected(self):
        with self.assertRaises(UnsupportedMechanicError):
            impact_time_from_activation(0, {"gathering_ms": 100, "active_ms": 100})
        with self.assertRaises(UnsupportedMechanicError):
            impact_time_from_activation(
                0, {"gathering_ms": 100, "active_ms": 100, "impact_timing": "projectile"}
            )


if __name__ == "__main__":
    unittest.main()
