from fractions import Fraction
import unittest
from combat_sim.exact import ExactAmount,ExactRootProduct
from combat_sim.mechanics.poison import poison_coefficient,poison_damage_rate,poison_damage_between,full_exposure_and_recovery_damage


class PoisonFormulaTests(unittest.TestCase):
    def test_coefficient_precedence_and_resistance_squared(self):
        self.assertEqual(poison_coefficient(10,1),9)
        self.assertEqual(poison_coefficient(1200,44),Fraction(17758,15))

    def test_known_rates_and_residual_end(self):
        self.assertEqual(poison_damage_rate(10,1,4).as_fraction(),18)
        self.assertEqual(poison_damage_rate(10,1,4,3).as_fraction(),9)
        self.assertEqual(poison_damage_rate(10,1,4,4).as_fraction(),0)

    def test_known_full_phases_and_total(self):
        self.assertEqual(poison_damage_between(10,1,0,4,4).as_fraction(),48)
        self.assertEqual(poison_damage_between(10,1,4,0,4).as_fraction(),48)
        self.assertEqual(full_exposure_and_recovery_damage(10,1,4).as_fraction(),96)

    def test_canonical_two_second_exposure_exact_root(self):
        expected=ExactAmount.of(ExactRootProduct(Fraction(142064,45),2))
        self.assertEqual(full_exposure_and_recovery_damage(1200,44,2),expected)

    def test_arbitrary_partition_preserves_exact_integral(self):
        first=poison_damage_between(1200,44,0,Fraction(3,20),Fraction(3,20))
        rest=poison_damage_between(1200,44,Fraction(3,20),2,Fraction(37,20))
        self.assertEqual(first+rest,poison_damage_between(1200,44,0,2,2))

    def test_complete_exposure_and_residual_are_equal(self):
        for duration in (Fraction(1,4),1,2,8):
            self.assertEqual(poison_damage_between(1200,66,0,duration,duration),poison_damage_between(1200,66,duration,0,duration))

    def test_negative_coefficient_floors_and_zero_exposure(self):
        self.assertEqual(poison_coefficient(10,4),0)
        self.assertEqual(full_exposure_and_recovery_damage(10,4,8).as_fraction(),0)
        self.assertEqual(full_exposure_and_recovery_damage(1200,44,0).as_fraction(),0)

    def test_constant_rate_and_zero_elapsed(self):
        self.assertEqual(poison_damage_between(10,1,4,4,2).as_fraction(),36)
        self.assertEqual(poison_damage_between(10,1,4,4,0).as_fraction(),0)
        with self.assertRaises(ValueError): poison_damage_between(10,1,0,1,0)

    def test_invalid_inputs_and_real_root_domain(self):
        for tp,rt in ((0,0),(-1,0),(10,-1)):
            with self.assertRaises(ValueError): poison_coefficient(tp,rt)
        for tt,to in ((-1,0),(0,-1),(1,2)):
            with self.assertRaises(ValueError): poison_damage_rate(10,1,tt,to)
        for values in ((-1,0,1),(0,-1,1),(0,1,-1)):
            with self.assertRaises(ValueError): poison_damage_between(10,1,*values)
        with self.assertRaises(ValueError): full_exposure_and_recovery_damage(10,1,-1)
