"""Actual charge/kick angular sweeps and isolated live attachment geometry."""
from dataclasses import replace
from decimal import Context,Decimal as D,localcontext
from fractions import Fraction as F
from types import SimpleNamespace as NS
import unittest

from combat_sim.angular_paths import YawArc
from combat_sim.hitboxes import Cuboid
from combat_sim.mechanics.body_path import BodyPathPiece
from combat_sim.orientation import YawFrame
from combat_sim.owned_contacts import OwnedContacts
from combat_sim.turn_control import TurnControl
from tests.test_fractional_owned_contacts import world,GEOMETRY
from tests.test_charge_grapple_combat import scene as charge_scene,panel,run
from tests.test_body_leaps_combat import scene as kick_scene
from tests.test_native_turns import turn
from tests.test_mobile_combat import events,read,PROFILES
from combat_sim.shared_engine import SharedEncounter


def engine(s):
    return SharedEncounter(s,PROFILES,body_definition=read('data/body_hitboxes.json'),
        terrain_definition=read('data/terrain/stationary_arena.json'),movement_definition=read('data/movement/walk_run.json'),
        combat_locomotion_definition=read('data/movement/combat_locomotion.json'),
        jump_definition=read('data/movement/combat_jump.json'),climb_definition=read('data/movement/combat_climb.json'),
        projectile_physics_definition=read('data/physics/projectile_gravity.json'))


def charge_wall(*,turning=True,duration=1100):
    s=charge_scene(duration,distance=100);panel(s,'hand_wall',5)
    if turning:turn(s,90,200)
    return s


def kick_turns(kind='both',duration=2700):
    s=kick_scene(duration)
    if kind in ('source','both'):turn(s,90,1800)
    if kind in ('target','both'):turn(s,360,2000,actor='B')
    return s


class TurningOwnedContactTests(unittest.TestCase):
    def setUp(self):
        c=localcontext(Context(prec=80));c.__enter__();self.addCleanup(c.__exit__,None,None,None)

    def test_real_charging_grab_rotates_into_and_destroys_actual_wall(self):
        r=run(charge_wall());hit=events(r,'owned_contact_committed')[0]
        self.assertEqual((hit['collision_kind'],hit['target']),('terrain','hand_wall'))
        self.assertEqual(r['world_collider_states']['hand_wall']['status'],'destroyed')
        self.assertTrue(events(r,'turn_completed'))
        self.assertLess(D(hit['impact_time_ms']) if 'impact_time_ms' in hit else D(hit['time_ms']),830)
        self.assertTrue(all(row.get('follows_owner_heading') for row in r['owned_contact_volumes']))

    def test_rotation_changes_the_actual_wall_contact_time(self):
        base=run(charge_wall(turning=False));rotated=run(charge_wall())
        a=D(events(base,'owned_contact_committed')[0]['time_ms']);b=D(events(rotated,'owned_contact_committed')[0]['time_ms'])
        self.assertGreater(b-a,1)
        for x,y in zip(base['final_states']['A']['position_m'],rotated['final_states']['A']['position_m']):
            self.assertLess(abs(D(x)-D(y)),D('1e-8'))

    def test_contact_rearm_keeps_live_heading_after_turn_completion(self):
        w=engine(charge_wall());r=w.run()
        row=next(x for x in reversed(list(w.owned_contacts.rows.values())) if w.owned_contacts.active(x))
        box=w.owned_contacts.box(row)
        self.assertEqual(box.frame,w.fighters['A'].facing)
        self.assertNotEqual(box.frame,row['facing'])
        self.assertEqual(row['status'],'active')
        self.assertEqual(len(events(r,'owned_contact_committed')),1)

    def test_charge_translation_stays_in_the_original_world_direction(self):
        r=run(charge_wall())
        self.assertEqual(tuple(map(D,r['final_states']['A']['locomotion']['velocity_mps'])),(12,0,0))
        self.assertEqual(D(r['final_states']['A']['position_m'][1]),-20)

    def test_descending_foot_uses_a_turning_source_without_an_extra_cost(self):
        r=run(kick_turns('source'))
        hit=events(r,'owned_contact_committed','A')[0]
        self.assertEqual((hit['target'],hit['hit_parts']),('B',['head']))
        self.assertEqual(D(r['final_states']['B']['hp']),D('7577.5'))
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)

    def test_descending_foot_hits_actual_turning_target_geometry(self):
        r=run(kick_turns('target'))
        self.assertEqual(len(events(r,'owned_contact_committed','A')),1)
        self.assertEqual(D(r['final_states']['B']['hp']),D('7577.5'))
        self.assertEqual(events(r,'turn_cancelled','B')[0]['reason'],'function_restricted')

    def test_both_source_and_target_turn_with_one_committed_strike(self):
        r=run(kick_turns('both'))
        self.assertEqual(len(events(r,'owned_contact_committed','A')),1)
        self.assertEqual(len(r['knock_impulses']),1)
        self.assertEqual(tuple(map(D,r['knock_impulses'][0]['direction'])),(0,0,-1))

    def test_missed_turning_kick_reaches_real_ground_and_lands_once(self):
        s=kick_turns('source');s['encounter']['participants']['B']['position_m']=[100,-20]
        r=run(s)
        self.assertEqual(events(r,'owned_contact_committed','A')[0]['collision_kind'],'terrain')
        self.assertEqual(len(events(r,'body_launch_landed','A')),1)
        self.assertEqual(len(events(r,'dyspnea_paid','A')),1)

    def test_attack_restriction_prevents_contact_but_allows_independent_turn(self):
        s=charge_wall();s['initial_restrictions']=[dict(target='A',source='owned_angular_test',functions=['attack'],duration_ms=2000)]
        r=run(s)
        self.assertFalse(events(r,'owned_contact_committed'))
        self.assertEqual(r['world_collider_states']['hand_wall']['status'],'active')
        self.assertTrue(events(r,'turn_completed'))

    def test_target_turn_can_finish_before_grab_and_actual_hold_continues(self):
        s=charge_scene(1100);turn(s,90,100,actor='B');r=run(s)
        self.assertLess(D(events(r,'turn_completed','B')[0]['time_ms']),D(events(r,'owned_contact_committed')[0]['time_ms']))
        self.assertEqual(r['grapple_holds'][0]['status'],'active')
        self.assertTrue(r['controlled_damage_streams'])

    def test_world_rotation_precision_and_observations_keep_actual_fracture(self):
        from tests.test_actor_facing_combat import oriented
        a=run(charge_wall());b=run(oriented(charge_wall()),precision=80,interval=17)
        self.assertEqual(b['world_collider_states']['hand_wall']['status'],'destroyed')
        self.assertLess(abs(D(events(a,'owned_contact_committed')[0]['time_ms'])-
            D(events(b,'owned_contact_committed')[0]['time_ms'])),D('1e-8'))


class OwnedAngularAttachmentTests(unittest.TestCase):
    def setup_path(self,*,centre_v=-1,size_v=-2,centre_a=0,size_a=0):
        w,a,action=world(centre_velocity=centre_v,size_velocity=size_v,
                        centre_acceleration=centre_a,size_acceleration=size_a)
        w.scenario={'turn_script':[]};w.blocking.layers={}
        w.precision=70
        piece=BodyPathPiece(0,500,(0,0,1),(0,0,0),(0,0,0))
        w.body_paths=NS(ensure=lambda **kw:NS(pieces=(('A',piece),)))
        control=TurnControl(w);w.turns=control
        control.rows['A']=dict(status='active',life_generation=1,end_ms=D(500),
            arc=YawArc(0,F('.5'),YawFrame(),180))
        system=OwnedContacts(w);row=system.start(a,action,GEOMETRY,None)
        return w,a,system,row,control

    def test_fractional_lower_face_preserves_its_actual_height_during_rotation(self):
        w,a,system,row,control=self.setup_path()
        path=control.owned_path(row,D(500))
        for t in (0,F('.2'),F('.5')):
            self.assertEqual(path.at_time(t).bounds[0][2],0)
        self.assertEqual(path.local_velocity_mps[2],0)

    def test_fractional_acceleration_cancels_before_angular_floor_bound(self):
        w,a,system,row,control=self.setup_path(centre_v=0,size_v=0,centre_a=-1,size_a=-2)
        path=control.owned_path(row,D(500))
        self.assertEqual(path.local_acceleration_mps2[2],0)
        self.assertEqual(path.projection_range((0,0,1),0,F('.5'))[0],0)

    def test_volume_size_is_independent_of_its_resizing_body_anchor(self):
        w,a,system,row,control=self.setup_path()
        path=control.owned_path(row,D(500))
        self.assertEqual(path.at_time(0).size_m,path.at_time(F('.5')).size_m)
        self.assertEqual(path.size_rate_mps,(0,0,0))

    def test_creation_frame_is_not_rewritten_by_live_geometry_reads(self):
        w,a,system,row,control=self.setup_path();creation=row['facing']
        a.facing=YawFrame(0,1)
        self.assertEqual(system.box(row).frame,a.facing)
        self.assertEqual(row['facing'],creation)
        self.assertTrue(row['follows_owner_heading'])

    def test_owner_life_end_still_ends_original_controlled_volume(self):
        w,a,system,row,control=self.setup_path();a.life_generation=2
        self.assertFalse(system.active(row));system.settle()
        self.assertEqual(row['status'],'ended')

    def test_legacy_world_retains_its_original_geometry_and_records(self):
        w,a,action=world();system=OwnedContacts(w);row=system.start(a,action,GEOMETRY,None)
        self.assertNotIn('follows_owner_heading',row)
        self.assertIs(system.geometry_row(row),row)
        self.assertIsInstance(system.box(row),Cuboid)


if __name__=='__main__':unittest.main()
