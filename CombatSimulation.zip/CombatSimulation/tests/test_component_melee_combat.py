"""1E5's real alternating attacks, passive bleed and Ultimate on the shared world.

Explicit restriction/restoration and altered-profile controls are engineering
probes, not additional abilities or ordinary source-character captures.
"""
from copy import deepcopy
from decimal import Context,Decimal as D,localcontext
import unittest

from combat_sim.mechanics.damage_ledger import DamageLedger
from combat_sim.mechanics.healing_history import HealingHistory
from combat_sim.mechanics.simultaneous import DamagePacket,calculate_simultaneous_impacts
from combat_sim.models import UnsupportedMechanicError
from tests.test_blocking_combat import scene as base_scene,run,events
from tests.test_combat_reactions import engine
from tests.test_mobile_combat import PROFILES,command
from tests.test_motion_boundary_combat import CURRENT
from tests.test_world_colliders_combat import wall


def scene(duration=1000,abilities=('1',),distance='1.1',shield=0):
    s=base_scene(duration,character='1E5',distance=distance);s['id']='component_melee_combat'
    s['action_selection']['A']['abilities']=list(abilities)
    s['encounter']['participants']['B']['character']='2E4'
    s['encounter']['participants']['B']['initial_state']['shield']=shield
    s['action_selection']['B'].update(abilities=['1'],start_ms=100000,reload_when_empty=False)
    return s


def impacts(r,target='B'):
    return [e for e in events(r,'impact_batch_resolved') if e['target']==target]


class ComponentMeleeTests(unittest.TestCase):
    def setUp(self):
        ctx=localcontext(Context(prec=60));ctx.__enter__();self.addCleanup(ctx.__exit__,None,None,None)

    def conserved(self,r,*,external_losses=None):
        damage=DamageLedger.from_record(r['applied_hp_history']);healing=HealingHistory.from_run(r)
        external_losses=external_losses or {}
        for actor,lives in r['actor_lives'].items():
            supplied=sum((D(l['initial_hp']) for l in lives),D(0))+healing.amount(actor=actor)
            self.assertLess(abs(supplied-external_losses.get(actor,D(0))-D(r['final_states'][actor]['hp'])-damage.amount(target=actor)),D('1e-8'))
        return damage

    def test_real_components_alternate_hands_and_begin_next_gathering_at_active_end(self):
        r=run(scene(1000));frames=r['melee_attacks']
        self.assertEqual([f['melee_component'] for f in frames],['a','b','a'])
        self.assertEqual([D(f['created_at_ms']) for f in frames],[230,610,990])
        starts=[e for e in events(r,'ability_started') if e['actor']=='A']
        self.assertEqual([D(e['time_ms']) for e in starts],[0,320,700])
        self.assertTrue(all(e['recovery_ms']==0 for e in starts))
        self.assertEqual([D(f['origin_m'][1]) for f in frames],[D('-19.8'),D('-20.2'),D('-19.8')])
        self.assertEqual([p['component'] for e in impacts(r) for p in e['hits']],['a','b','a'])
        self.assertFalse([b for b in r['blade_items'] if b['actor']=='A']);self.assertFalse(events(r,'blade_attached'))
        self.conserved(r)

    def test_released_left_action_stays_left_owned_after_sequence_advances(self):
        r=run(scene(250));owned=r['final_states']['A']['owned_actions'][0]
        self.assertEqual(owned['action']['component_id'],'a')
        self.assertEqual(owned['occupies'],['hand:left','weapon:1'])
        self.assertEqual(r['melee_component_sequences'][0]['next_component'],'b')

    def test_whiffs_advance_the_cycle_without_impact_status_or_blade_replacement(self):
        r=run(scene(900,distance=30))
        self.assertEqual([f['melee_component'] for f in r['melee_attacks']],['a','b','a'])
        self.assertEqual([D(f['created_at_ms']) for f in r['melee_attacks']],[230,550,870])
        self.assertFalse(events(r,'melee_contact'));self.assertFalse(events(r,'self_status_applied'))
        self.assertFalse(events(r,'replacement_blade_summoning'))
        self.assertEqual(D(r['final_states']['A']['instability']),0)
        self.assertEqual(D(r['final_states']['A']['disorientation']),0)

    def test_cost_is_per_swing_and_passive_has_no_extra_payment(self):
        r=run(scene(230));paid=events(r,'dyspnea_paid')
        self.assertEqual(len(paid),1);self.assertEqual(paid[0]['ability'],'1')
        self.assertEqual(D(paid[0]['base_value']),D('1.8'));self.assertEqual(D(paid[0]['amount']),D('3.24'))
        h=impacts(r)[0];power=r['released_attack_power'][0]
        self.assertEqual(D(power['components']['a']['output']),440)
        self.assertEqual(D(power['instability_at_release']),0)
        self.assertGreater(D(r['final_states']['A']['instability']),0)

    def test_bleed_is_twice_post_armor_damage_with_source_provenance(self):
        r=run(scene(230));h=impacts(r)[0];effect=events(r,'bleeding_started')[0]['effect']
        hp=D(h['hits'][0]['nominal_hp_damage'])
        self.assertEqual(D(effect['basis_y']),2*hp)
        snapshot=r['released_attack_modifiers'][0]
        self.assertEqual(D(snapshot['values']['bleeding_multiplier']),2)
        passive=r['passive_attack_modifiers'][0]
        self.assertEqual(snapshot['passive_ids'],[passive['id']]);self.assertEqual(passive['ability'],'4')
        self.assertEqual(snapshot['component_id'],'a')

    def test_disabled_passive_probe_halves_only_bleeding_not_direct_hits_or_effort(self):
        s=scene(1000);normal=run(s);profiles=deepcopy(PROFILES);profiles['1E5']['passive_effects'].pop('4')
        without=run(s,profiles=profiles)
        self.assertEqual([e['hits'] for e in impacts(normal)],[e['hits'] for e in impacts(without)])
        self.assertEqual(normal['metrics']['A']['dyspnea_paid'],without['metrics']['A']['dyspnea_paid'])
        x=self.conserved(normal);y=self.conserved(without)
        direct=sum((D(e['applied_hp_damage']) for e in impacts(normal)),D(0))
        self.assertAlmostEqual(x.amount(actor='A')-direct,2*(y.amount(actor='A')-direct),places=8)

    def test_fully_shielded_hit_creates_no_bleed_or_armor_loss(self):
        r=run(scene(230,shield=4000));h=impacts(r)[0]
        self.assertEqual(D(h['applied_hp_damage']),0);self.assertEqual(D(h['applied_armor_loss']),0)
        self.assertEqual(D(h['applied_shield_damage']),440);self.assertFalse(events(r,'bleeding_started'))
        self.assertEqual(r['melee_component_sequences'][0]['next_component'],'b')

    def test_ultimate_increases_both_arms_piercing_without_adding_a_hand_or_payment(self):
        r=run(scene(1000,('Ultimate','1')))
        snapshots=r['released_attack_modifiers']
        self.assertEqual([s['component_id'] for s in snapshots],['a','b','a'])
        self.assertEqual(D(snapshots[0]['values']['additional_piercing']),0)
        self.assertTrue(all(D(s['values']['additional_piercing'])==80 for s in snapshots[1:]))
        grant=r['attack_modifiers'][0]
        self.assertEqual((D(grant['start_ms']),D(grant['expiry_ms'])),(320,15320))
        self.assertTrue(all(e['ability']=='1' for e in events(r,'dyspnea_paid')))
        # The first independent swing releases before the 320 ms grant. Both
        # authored arms subsequently release with the completed enhancement.
        first=impacts(r)[0];expected=calculate_simultaneous_impacts((DamagePacket('slash',440,0),),165,0,0)[0]
        self.assertAlmostEqual(D(first['applied_hp_damage']),D(expected.hp_damage.numerator)/D(expected.hp_damage.denominator),places=40)
        self.assertFalse(events(r,'blade_attached'));self.conserved(r)

    def test_piercing_ultimate_does_not_bypass_shield(self):
        r=run(scene(550,('Ultimate','1'),shield=4000));h=impacts(r)[0]
        self.assertEqual(D(h['applied_shield_damage']),440);self.assertEqual(D(h['applied_hp_damage']),0)
        self.assertFalse(events(r,'bleeding_started'))

    def test_real_timed_expiry_stops_affecting_later_emissions(self):
        r=run(scene(17000,('Ultimate','1'),distance=30))
        early=[s for s in r['released_attack_modifiers'] if D(s['released_at_ms'])<320]
        before=[s for s in r['released_attack_modifiers'] if 320<=D(s['released_at_ms'])<15320]
        after=[s for s in r['released_attack_modifiers'] if D(s['released_at_ms'])>=15320]
        self.assertTrue(early);self.assertTrue(before);self.assertTrue(after)
        self.assertTrue(all(D(s['values']['additional_piercing'])==0 for s in early))
        self.assertTrue(all(D(s['values']['additional_piercing'])==80 for s in before))
        self.assertTrue(all(D(s['values']['additional_piercing'])==0 for s in after))
        self.assertTrue(all(D(s['values']['bleeding_multiplier'])==2 for s in after))
        self.assertEqual(D(r['attack_modifiers'][0]['ended_at_ms']),15320)

    def test_left_hand_restriction_prevents_first_swing_without_skipping_to_right(self):
        s=scene(450);s['initial_restrictions']=[{'target':'A','source':'probe:left','functions':['hand:left'],'duration_ms':200}]
        r=run(s);self.assertEqual([f['melee_component'] for f in r['melee_attacks']],['a'])
        self.assertEqual(D(r['melee_attacks'][0]['created_at_ms']),430)

    def test_right_hand_restriction_preserves_left_control_and_delays_next_right(self):
        s=scene(1250);s['initial_restrictions']=[{'target':'A','source':'probe:right','functions':['hand:right'],'duration_ms':1000}]
        r=run(s)
        self.assertEqual([f['melee_component'] for f in r['melee_attacks']],['a','b'])
        self.assertEqual([D(f['created_at_ms']) for f in r['melee_attacks']],[230,1230])

    def test_cancellation_before_emission_retries_the_same_arm(self):
        r=run(scene(850),operations=[(200,{'op':'restriction','functions':['upper_body'],'until':600})])
        self.assertEqual([f['melee_component'] for f in r['melee_attacks']],['a'])
        self.assertEqual(D(r['melee_attacks'][0]['created_at_ms']),830)
        self.assertEqual(len(events(r,'dyspnea_paid')),2)

    def test_cancellation_after_emission_preserves_bleed_and_next_arm(self):
        r=run(scene(850),operations=[(250,{'op':'restriction','functions':['upper_body'],'until':600})])
        self.assertEqual([f['melee_component'] for f in r['melee_attacks']],['a','b'])
        self.assertEqual([D(f['created_at_ms']) for f in r['melee_attacks']],[230,830])
        self.assertGreater(self.conserved(r).amount(actor='A'),sum(D(e['applied_hp_damage']) for e in impacts(r)))

    def test_lower_body_restriction_does_not_cancel_arm_swing(self):
        r=run(scene(250),operations=[(200,{'op':'restriction','functions':['lower_body'],'until':600})])
        self.assertEqual(D(r['melee_attacks'][0]['created_at_ms']),230)
        self.assertFalse(events(r,'controlled_action_cancelled'))

    def test_component_and_buff_can_overlap_independent_walk(self):
        s=scene(900,('Ultimate','1'),distance=30);s['encounter']['participants']['A']['movement_direction']=[0,1]
        command(s,'A',50,'walk');r=run(s)
        snapshots=r['released_attack_modifiers']
        self.assertEqual(D(snapshots[0]['values']['additional_piercing']),0)
        self.assertTrue(any(D(s['values']['additional_piercing'])==80 for s in snapshots[1:]))
        starts=[e for e in events(r,'ability_started') if e['actor']=='A' and e['ability']=='1']
        self.assertLess(D(starts[0]['time_ms']),320)

    def test_repeated_emission_callback_cannot_repeat_damage_or_advance_twice(self):
        world=engine(scene(250));r=world.run();actor=world.fighters['A'];action=actor.live_actions()[0]
        before=len(world.melee.attacks);cursor=world.melee.next_component(actor,'1')
        world.melee.emit_frame(actor,action)
        self.assertEqual(len(world.melee.attacks),before)
        self.assertEqual(world.melee.next_component(actor,'1'),cursor)

    def test_world_solid_receives_raw_damage_without_organic_bleed(self):
        s=scene(250,distance=3);s['initial_colliders']=[wall(x='.7',hp=400)]
        r=run(s);self.assertEqual(events(r,'world_collider_removed')[0]['collider']['status'],'destroyed')
        self.assertFalse(events(r,'bleeding_started'));self.assertFalse([b for b in r['blade_items'] if b['actor']=='A'])
        self.assertEqual(self.conserved(r).amount(actor='A'),0)
        self.assertEqual(r['melee_component_sequences'][0]['next_component'],'b')

    def test_friendly_body_intercepts_and_bleeds_without_eligible_outgoing_credit(self):
        s=scene(250,distance=30);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(team='A',position_m=['1.1',-20])
        s['action_selection']['C']=deepcopy(s['action_selection']['B'])
        r=run(s);self.assertEqual(r['melee_attacks'][0]['contact']['target'],'C')
        ledger=self.conserved(r);self.assertGreater(ledger.amount(actor='A'),0)
        self.assertEqual(ledger.amount(actor='A',eligible_only=True),0)

    def test_simultaneous_other_source_keeps_ordinary_bleed_and_pre_hit_armor(self):
        s=scene(230);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['B'])
        s['encounter']['participants']['C'].update(team='A',position_m=['2.2',-20],facing='-x')
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=0)
        r=run(s);h=impacts(r)[0];self.assertEqual(D(h['pre_hit_armor']),165)
        damage={p['actor']:D(p['nominal_hp_damage']) for p in h['hits']}
        effects=events(r,'bleeding_started');self.assertEqual(len(effects),2)
        for e in effects:
            effect=e['effect'];source=effect['actor']
            self.assertEqual(D(effect['basis_y']),damage[source]*(2 if source=='A' else 1))

    def test_real_mutual_death_keeps_clipped_credit_without_inventing_revive_or_healing(self):
        s=scene(250);s['encounter']['participants']['B']['character']='1E5';s['action_selection']['B']['start_ms']=0
        for row in s['encounter']['participants'].values():row['initial_state'].update(hp=1,armor=0)
        r=run(s);ledger=self.conserved(r)
        self.assertTrue(all(not row['alive'] for row in r['final_states'].values()))
        self.assertEqual((ledger.amount(actor='A'),ledger.amount(actor='B')),(1,1))
        self.assertFalse(r['revival_attempts']);self.assertFalse(r['healing_history']['entries'])

    def test_old_recipient_bleed_does_not_transfer_to_restored_body(self):
        r=run(scene(1000),operations=[(500,{'op':'kill','actor':'B'}),(700,{'op':'revive','actor':'B'})])
        self.assertEqual(r['final_states']['B']['life_generation'],2)
        effects=[e for e in r['effect_instances'] if e['kind']=='bleeding']
        self.assertTrue(effects)
        old=[e for e in effects if e['target_life_generation']==1]
        self.assertTrue(old);self.assertTrue(all(e['ended_at_ms']=='500' for e in old))

    def test_numerics_and_participant_order_do_not_choose_components_or_damage(self):
        s=scene(1000,('Ultimate','1'));baseline=run(s);other=deepcopy(s)
        other['encounter']['participants']=dict(reversed(list(other['encounter']['participants'].items())))
        r=run(other,precision=80,interval=137)
        self.assertEqual([f['melee_component'] for f in r['melee_attacks']],[f['melee_component'] for f in baseline['melee_attacks']])
        for actor,row in baseline['final_states'].items():
            for key in ('hp','armor','shield','dyspnea','disorientation','instability'):
                self.assertAlmostEqual(D(row[key]),D(r['final_states'][actor][key]),places=8)

    def test_invalid_cycle_hand_and_unknown_passive_fail_before_simulation(self):
        for change in ('cycle','hand','passive'):
            profiles=deepcopy(PROFILES);a=profiles['1E5']['abilities']['1']
            if change=='cycle':a['melee_components']['a']['next']='a'
            elif change=='hand':a['melee_components']['a']['origin_hand']='third'
            else:profiles['1E5']['passive_effects']['4']['execution_model']='unknown'
            with self.subTest(change=change),self.assertRaises(ValueError):run(scene(),profiles=profiles)

    def test_individual_hand_restriction_also_respects_existing_thrust_and_block_resources(self):
        s=base_scene(600,distance=30);s['action_selection']['A']['abilities']=['1','basic_8']
        s['initial_restrictions']=[{'target':'A','source':'probe:right','functions':['hand:right'],'duration_ms':500}]
        r=run(s)
        blocks=[e for e in events(r,'ability_started') if e['actor']=='A' and e['ability']=='basic_8']
        thrusts=[e for e in events(r,'ability_started') if e['actor']=='A' and e['ability']=='1']
        self.assertTrue(blocks);self.assertEqual(D(blocks[0]['time_ms']),0)
        self.assertTrue(thrusts);self.assertTrue(all(D(e['time_ms'])>=500 for e in thrusts))
        self.assertTrue(events(r,'block_layer_damage'))

    def test_blocking_the_next_hand_does_not_cancel_the_released_previous_hand(self):
        r=run(scene(850),operations=[(250,{'op':'restriction','functions':['hand:right'],'until':600})])
        self.assertFalse(events(r,'controlled_action_cancelled'))
        self.assertEqual([f['melee_component'] for f in r['melee_attacks']],['a','b'])
        self.assertEqual([D(f['created_at_ms']) for f in r['melee_attacks']],[230,830])

    def test_a_handless_enhancement_can_activate_while_the_first_arm_is_restricted(self):
        s=scene(650,('1','Ultimate'))
        s['initial_restrictions']=[{'target':'A','source':'probe:left','functions':['hand:left'],'duration_ms':400}]
        r=run(s);self.assertEqual(D(r['attack_modifiers'][0]['start_ms']),320)
        self.assertEqual(D(r['melee_attacks'][0]['created_at_ms']),630)
        self.assertEqual(D(r['released_attack_modifiers'][0]['values']['additional_piercing']),80)
        self.assertNotIn('4',r['final_states']['A']['ability_ready_at_ms'])

    def test_real_gun_kills_source_but_previously_applied_double_bleed_continues(self):
        s=scene(1000);s['encounter']['participants']['A']['initial_state']['hp']=1
        s['encounter']['participants']['B']['position_m']=['1.1','-19.6']
        s['encounter']['participants']['C']={'character':'1E2','team':'B','position_m':[30,-21],
            'facing':'-x','initial_state':{'shield':0}}
        s['action_selection']['C']=dict(s['action_selection']['B'],start_ms=200)
        r=run(s);death=D(r['final_states']['A']['died_at_ms']);self.assertGreater(death,230)
        self.assertEqual(len(r['melee_attacks']),1)
        ledger=self.conserved(r)
        self.assertGreater(ledger.amount(actor='A')-ledger.amount(actor='A',end=death),0)
        wound=next(e for e in r['effect_instances'] if e['kind']=='bleeding' and e['actor']=='A')
        self.assertIsNone(wound['ended_at_ms']);self.assertEqual(wound['source_life_generation'],1)

    def test_restoration_retains_next_arm_and_passive_but_not_old_control(self):
        r=run(scene(1000),operations=[(300,{'op':'kill'}),(500,{'op':'revive','hp':5000})])
        self.assertEqual([f['melee_component'] for f in r['melee_attacks']],['a','b'])
        self.assertEqual([f['source_life_generation'] for f in r['melee_attacks']],[1,2])
        snapshots=r['released_attack_modifiers']
        self.assertEqual(snapshots[0]['passive_ids'],snapshots[1]['passive_ids'])
        self.assertTrue(all(D(s['values']['bleeding_multiplier'])==2 for s in snapshots))
        self.conserved(r,external_losses={'A':D(20000)})  # Explicit non-damage fixture removal.

    def test_separate_character_instances_do_not_share_component_or_passive_state(self):
        s=scene(850);s['encounter']['participants']['C']=deepcopy(s['encounter']['participants']['A'])
        s['encounter']['participants']['C'].update(position_m=['2.2',-20],facing='-x')
        s['action_selection']['C']=dict(s['action_selection']['A'],start_ms=100)
        r=run(s)
        for actor in ('A','C'):
            self.assertEqual([f['melee_component'] for f in r['melee_attacks'] if f['actor']==actor],['a','b'])
        ids={p['actor']:p['id'] for p in r['passive_attack_modifiers']}
        self.assertNotEqual(ids['A'],ids['C'])
        self.conserved(r)

    def test_expired_piercing_does_not_rewrite_existing_bleeding_wounds(self):
        s=scene(16000,('Ultimate','1'))
        s['initial_restrictions']=[{'target':'A','source':'probe:delayed_first_arm','functions':['hand:left'],'duration_ms':14000}]
        r=run(s);snapshots=r['released_attack_modifiers']
        before=[p for p in snapshots if D(p['released_at_ms'])<15320]
        after=[p for p in snapshots if D(p['released_at_ms'])>=15320]
        self.assertTrue(before);self.assertTrue(after)
        self.assertTrue(all(D(p['values']['additional_piercing'])==80 for p in before))
        self.assertTrue(all(D(p['values']['additional_piercing'])==0 for p in after))
        earlier=deepcopy(s);earlier['encounter']['duration_ms']=15300;prefix=run(earlier)
        old={e['id']:e for e in prefix['effect_instances'] if e['kind']=='bleeding'}
        current={e['id']:e for e in r['effect_instances'] if e['kind']=='bleeding'}
        self.assertTrue(old)
        for identity,e in old.items():
            self.assertEqual(e['basis_y'],current[identity]['basis_y'])
            self.assertEqual(e['expiry'],current[identity]['expiry'])
        self.conserved(r)

    def test_common_running_jump_uses_authored_speed_and_shared_gravity(self):
        s=scene(1700,distance=100);s['action_selection']['A']['start_ms']=100000
        command(s,'A',0,'run');command(s,'A',400,'jump');r=run(s)
        takeoff=next(e for e in events(r,'jump_takeoff') if e['actor']=='A')
        self.assertEqual(D(takeoff['velocity_mps'][2]),D('3.5'))
        self.assertTrue([e for e in events(r,'jump_landed') if e['actor']=='A'])
        self.assertEqual(D(r['final_states']['A']['body_origin_m'][2]),D('1.1375'))

    def test_common_sprint_uses_authored_bonus_without_casting_attacks(self):
        s=scene(1500,distance=100);s['action_selection']['A']['start_ms']=100000
        command(s,'A',0,'sprint');r=run(s)
        self.assertEqual(r['final_states']['A']['locomotion']['mode'],'sprinting')
        self.assertEqual(D(r['final_states']['A']['locomotion']['speed_mps']),D('12.2'))
        self.assertFalse(r['melee_attacks'])

    def test_real_arm_attack_can_hit_during_shared_jump_without_a_body_lock(self):
        s=scene(1000);command(s,'A',0,'jump');r=run(s)
        takeoff=next(e for e in events(r,'jump_takeoff') if e['actor']=='A')
        landing=next(e for e in events(r,'jump_landed') if e['actor']=='A')
        first=r['melee_attacks'][0]
        self.assertLess(D(takeoff['time_ms']),D(first['created_at_ms']))
        self.assertLess(D(first['created_at_ms']),D(landing['time_ms']))
        self.assertEqual(first['status'],'resolved');self.assertEqual(first['contact']['target'],'B')
        self.conserved(r)

    def test_real_block_absorbs_swing_and_releases_only_its_authored_counter(self):
        s=scene(249);s['action_selection']['B'].update(abilities=['basic_8'],start_ms=0)
        r=run(s)
        self.assertEqual(D(r['block_layers'][0]['hp']),360)
        self.assertEqual(len(r['reaction_emissions']),1);self.assertEqual(r['reaction_emissions'][0]['actor'],'B')
        self.assertFalse(events(r,'bleeding_started'))
        ledger=self.conserved(r);self.assertEqual(ledger.amount(actor='A'),0)
        self.assertEqual(ledger.amount(actor='B'),255)


if __name__=='__main__':unittest.main()
