"""Static plan view of the authored arena; no animation or plotting dependency."""
import json
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[2]
terrain=json.loads((ROOT/'data/terrain/stationary_arena.json').read_text())
scenario=json.loads((ROOT/'scenarios/stationary_2v2_terrain.json').read_text())
svg=ET.Element('svg',xmlns='http://www.w3.org/2000/svg',width='1100',height='640',viewBox='0 0 1100 640')
ET.SubElement(svg,'rect',width='1100',height='640',fill='#f7f8fa')
def text(x,y,value,size=16):
    e=ET.SubElement(svg,'text',x=str(x),y=str(y),fill='#162536',**{'font-family':'sans-serif','font-size':str(size)})
    e.text=value
text(30,35,'Stationary 2v2 battlefield — top view',24)
text(30,63,'Ground z=0; nominal height 200 m; open sides and top. Cubes: 1.8 m on every side.')
def panel(x,y,w,h,bounds,title):
    xmin,xmax,ymin,ymax=bounds
    scale=min(w/(xmax-xmin),h/(ymax-ymin))
    def point(a,b):return x+(a-xmin)*scale,y+(ymax-b)*scale
    text(x,y-15,title,18)
    ET.SubElement(svg,'rect',x=str(x),y=str(y),width=str((xmax-xmin)*scale),height=str((ymax-ymin)*scale),fill='white',stroke='#8794a1')
    for c in terrain['obstacles']:
        a,b,_=c['centre_m'];side=c['side_length_m'];px,py=point(a-side/2,b+side/2)
        ET.SubElement(svg,'rect',x=str(px),y=str(py),width=str(side*scale),height=str(side*scale),fill='#a0a8b1',stroke='#55616e')
        if scale>2:text(px,py-7,c['id'],12)
    for name,p in scenario['encounter']['participants'].items():
        a,b=p['position_m'];px,py=point(a,b);color='#1673bd' if p['team']=='A' else '#ba3939'
        ET.SubElement(svg,'circle',cx=str(px),cy=str(py),r='4',fill=color)
        if scale>2:
            text(px+7,py+17,name,13)
            dx=12 if p['facing']=='+x' else -12
            ET.SubElement(svg,'path',d=f'M {px} {py} l {dx} 0 l {-dx/3} -3 m {dx/3} 3 l {-dx/3} 3',stroke=color,fill='none')
    return point
panel(30,110,430,430,(-250,250,-250,250),'Full 500 × 500 m ground')
text(30,565,'x/y bounds: −250 to 250 m',14)
point=panel(510,110,550,430,(-5,35,-5,25),'Starting area (zoom; metres)')
for a in (0,10,20,30):
    px,py=point(a,-5);text(px-5,py+20,str(a),12)
text(510,565,'Blue: A faces +x. Red: B faces −x. Grey: fixed cubes.',14)
text(510,590,'Cube (6,0) blocks projectile paths; area attacks pass through cover.',13)
ET.ElementTree(svg).write(Path(__file__).with_name('arena.svg'),encoding='unicode')
