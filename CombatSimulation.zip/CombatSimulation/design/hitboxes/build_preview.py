"""Generate a vector diagram of the confirmed standing hitboxes (stdlib only)."""
from fractions import Fraction
from html import escape
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from combat_sim.hitboxes import combined_bounds, standing_cuboids

definition=json.loads((ROOT/'data/body_hitboxes.json').read_text())
boxes=standing_cuboids(definition)
low,high=combined_bounds(boxes)
colours={'head':'#eab85f','torso':'#5ba7df','left_arm':'#9d86df','right_arm':'#9d86df',
         'left_leg':'#61b6a3','right_leg':'#61b6a3'}
scale,origin_y=240,400


def number(value):
    return f'{float(value):.3f}'.rstrip('0').rstrip('.')


def text(x,y,label,**attributes):
    attrs=' '.join(f'{k.replace("_","-")}="{escape(str(v))}"' for k,v in attributes.items())
    return f'<text x="{x}" y="{y}" {attrs}>{escape(label)}</text>'


svg=['''<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="760" viewBox="0 0 1080 760" role="img" aria-labelledby="title desc">
<title id="title">Confirmed six-cuboid standing hitboxes</title>
<desc id="desc">Two orthographic projections of the confirmed standing body. Head, torso, two arms and two legs. Overall height 1.75 metres, width 0.70 metres and depth 0.30 metres. The origin is the centre of the whole body's outer bounds.</desc>
<style>text{font-family:system-ui,sans-serif;fill:#243645;font-size:14px}.grid{stroke:#e1e7ec;stroke-width:1}.outline{stroke:#253849;stroke-width:1.5}.axis{stroke:#6d7b88;stroke-width:1.2}.label{font-size:12px}</style>
<rect width="1080" height="760" fill="#f7fafc"/>
''']
svg.append(text(45,43,'Standing hitboxes — confirmed layout',font_size=26,font_weight=650))
svg.append(text(45,72,'Dimensions, positions and origin confirmed · fixed standing pose',fill='#6c4c16'))
svg.append(text(45,99,'Local axes: x right, y forward, z up. Origin: centre of the complete body bounds.'))
svg.append(text(280,155,'x–z projection',text_anchor='middle',font_size=19,font_weight=600))
svg.append(text(800,155,'y–z projection',text_anchor='middle',font_size=19,font_weight=600))

for centre_x,axis in ((280,0),(800,1)):
    for z in (Fraction(-3,4),Fraction(-1,2),Fraction(-1,4),Fraction(0),Fraction(1,4),Fraction(1,2),Fraction(3,4)):
        y=origin_y-float(z)*scale
        svg.append(f'<line x1="{centre_x-140}" x2="{centre_x+140}" y1="{y}" y2="{y}" class="grid"/>')
        if axis==0:
            svg.append(text(120,y+4,number(z),text_anchor='end',font_size=12))
    for box in boxes:
        a,b=box.bounds
        x=centre_x+float(a[axis])*scale
        y=origin_y-float(b[2])*scale
        w=float(b[axis]-a[axis])*scale
        h=float(b[2]-a[2])*scale
        svg.append(f'<rect data-part="{box.part}" data-projection="{axis}" x="{x}" y="{y}" width="{w}" height="{h}" fill="{colours[box.part]}" fill-opacity="{0.80 if axis==0 else 0.38}" class="outline"/>')
        if axis==0:
            cx=centre_x+float(box.centre_m[axis])*scale
            cy=origin_y-float(box.centre_m[2])*scale
            label=box.part.replace('left_','L ').replace('right_','R ').title()
            attributes={'text_anchor':'middle','font_size':12,'font_weight':600}
            if 'arm' in box.part or 'leg' in box.part:
                attributes['transform']=f'rotate(-90 {cx} {cy})'
            svg.append(text(cx,cy+4,label,**attributes))
    ground_y=origin_y-float(low[2])*scale
    svg.append(f'<line x1="{centre_x-145}" x2="{centre_x+145}" y1="{ground_y}" y2="{ground_y}" class="axis"/>')
    svg.append(f'<line x1="{centre_x-145}" x2="{centre_x+145}" y1="{origin_y}" y2="{origin_y}" stroke="#bd5c55" stroke-dasharray="5 4"/>')
    svg.append(f'<circle cx="{centre_x}" cy="{origin_y}" r="4" fill="#aa332e"/>')
    svg.append(text(centre_x+150,origin_y+5,'z=0',font_size=12))
    svg.append(text(centre_x,ground_y+25,f'Ground: z={number(low[2])} m',text_anchor='middle',font_size=13))
    span=high[axis]-low[axis]
    svg.append(text(centre_x,ground_y+53,f'{"Width" if axis==0 else "Depth"}: {number(span)} m',text_anchor='middle',font_weight=600))

top_y=origin_y-float(high[2])*scale
bottom_y=origin_y-float(low[2])*scale
svg.append(f'<line x1="70" x2="70" y1="{top_y}" y2="{bottom_y}" class="axis"/>')
for y in (top_y,bottom_y):
    svg.append(f'<line x1="62" x2="78" y1="{y}" y2="{y}" class="axis"/>')
svg.append(text(45,400,f'Height: {number(high[2]-low[2])} m',transform='rotate(-90 45 400)',text_anchor='middle',font_weight=600))
svg.append(text(800,702,'Arms and legs overlap in this side projection.',text_anchor='middle',font_size=13))
svg.append(text(45,733,'Six cuboids only. Combat collision/area rules remain separate from the confirmed body geometry.',font_size=13))
svg.append('</svg>')
path=OUT/'standing_proposal.svg'
path.write_text('\n'.join(svg)+'\n')
print(path)
print('Confirmed dimensions (x,y,z):',tuple(number(b-a) for a,b in zip(low,high)))
