"""Static orthographic comparison of the approved standing/crouched cuboids."""
import json
from pathlib import Path
import sys
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from combat_sim.postures import body_origin_from_bounds, world_posture_cuboids
from combat_sim.hitboxes import combined_bounds
body=json.loads((ROOT/'data/body_hitboxes.json').read_text())
profile=json.loads((ROOT/'data/movement/walk_run.json').read_text())['crouch']
svg=ET.Element('svg',xmlns='http://www.w3.org/2000/svg',width='1100',height='450',viewBox='0 0 1100 450')
ET.SubElement(svg,'rect',width='1100',height='450',fill='#f5f8fb')
def text(x,y,value,size=15):
    e=ET.SubElement(svg,'text',x=str(x),y=str(y),fill='#172b40',**{'font-family':'sans-serif','font-size':str(size)})
    e.text=value
text(25,30,'Standing and crouching — six-cuboid geometry',24)
text(25,55,'Feet stay on the same support. Legs shorten; head, torso and arms lower together. No animation.')
colors={'head':'#75a9e0','torso':'#52b9ab','left_arm':'#e6b660','right_arm':'#e6b660','left_leg':'#9baac0','right_leg':'#9baac0'}
scale=140;baseline=340
for x,fraction,axis,title in [(140,0,1,'Front: standing'),(400,1,1,'Front: crouched'),(675,0,0,'Side: standing'),(935,1,0,'Side: crouched')]:
    boxes=world_posture_cuboids(body,[0,0,.875],'+x',fraction,profile['target_leg_height_m'])
    text(x-90,90,title,17)
    for box in sorted(boxes,key=lambda b:b.centre_m[0 if axis==1 else 1]):
        low,high=box.bounds
        lo,hi=float(low[axis]),float(high[axis])
        if axis==1:lo,hi=-hi,-lo
        ET.SubElement(svg,'rect',x=str(x+lo*scale),y=str(baseline-float(high[2])*scale),
            width=str((hi-lo)*scale),height=str(float(high[2]-low[2])*scale),
            fill=colors[box.part],stroke='#263a50',**{'stroke-width':'1'})
    low,high=combined_bounds(boxes);origin=body_origin_from_bounds(boxes)
    ET.SubElement(svg,'line',x1=str(x-100),x2=str(x+100),y1=str(baseline),y2=str(baseline),stroke='#344d65',**{'stroke-dasharray':'5 4'})
    ET.SubElement(svg,'circle',cx=str(x),cy=str(baseline-float(origin[2])*scale),r='4',fill='#d14e40')
    text(x-85,375,f'Height {float(high[2]-low[2]):.2f} m')
    text(x-85,398,f'Origin z={float(origin[2]):.3f} m',13)
text(25,430,'Grey: legs. Teal: torso. Blue: head. Gold: arms. Red dot: body origin.',14)
ET.ElementTree(svg).write(Path(__file__).with_name('standing_crouch.svg'),encoding='unicode')
