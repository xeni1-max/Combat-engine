# Component melee and 1E5's arm blades

Primary source: `1E5.odt` p3–7 describes alternating left/right arm-blade
swings, each dealing 440 damage. p47–65 specifies slash, G140/A180, midpoint
impact, target/self O/U150 on impact, Db1.8 and intrinsic momentary effort.
When alternating, next Gathering starts immediately after the previous Active.
p13 gives twice the bleeding; p15/p103–105 gives +80 piercing to ability 1 for
15 s, A320 and 65 s cooldown. This is the revised Ultimate, without extra arms.
The author's passive/enhancement effort exemption remains.

Verified in the shared engine, 2026-11-01. The rules below distinguish
source facts above from delegated gap decisions. No root ODT is edited.

## One shared strike path

`SharedMelee` now accepts a data-defined cycle of explicit strike components.
Each component supplies damage, one hand, hand poses and its successor. A
component ID is pinned on the owned `BattleAction` before requirements are
acquired, and remains fixed through preparation, Active, impact and completion.
All component attacks use the existing melee contact queue, immutable effort
power, modifiers, simultaneous defense snapshots, HP journal and typed bleed.
2E4's thrust still uses its real venom/replacement-blade path; no second runner
or synthetic confirmed hit is used for 1E5.

Delegated geometry/defaults:

- Start with a/left, then b/right. Unlisted base piercing is zero. Piercing is
  the existing armor parameter and does not mean piercing through other bodies.
- Reuse the 1 m/2 cm-radius hand capsule, current physical body/solid query and
  torso-location aim locked at Active start. Actual contact at impact selects
  the first body or body-blocking solid, including allies. Movement/posture and
  gravity change the real geometry. Misses remain misses.
- Use neutral local hands left (-0.2,0.15,-0.1), right (0.2,0.15,-0.1), with
  matching start/end grip poses. These numerical proxies are delegated; no
  animation or unlisted authored sweep path is claimed. Body hitboxes retain
  the approved shared model.
- Require the acting hand, ability-1 weapon resource and existing upper-body/
  attack functions. Pin the hand even after the cycle advances. The shared
  ability resource enforces authored sequential swings; independent legal
  movement, jump or enhancement actions can overlap.

## Sequence, cost and cancellation

Advance the cycle once at midpoint emission, including a whiff or fully shielded
hit. Before emission, cancellation preserves the same next arm; after emission,
it preserves the successor and any released damage. Repeated emission callbacks
return the existing frame instead of charging/advancing/damaging twice.

At consecutive Active completion, immediate next Gathering has zero physical
Recovery as authored. Its actual Active still includes base Gathering and
current/incoming disorientation. Outside an uninterrupted continuation, use the
ordinary required-hand Recovery. Neutral poses give zero initial Recovery.
With standing uncontested contacts: first a hits at 230 ms, next Gathering
starts at 320 ms, b hits at 610 ms, next Gathering at 700 ms and a hits at 990 ms.
The later cadence includes the remaining on-impact self disorientation; it is
not an invented weapon cooldown.

Under delegation, check/pay Db1.8 once at Active start, giving 3.24 at zero
fatigue. Cancellation or a whiff after payment does not refund it. Actual body
or solid contact applies self O/U150 after captured power; a whiff applies no
on-impact self status. Intrinsic power remains `max(0, 440-U/10)` under the
shared phase snapshot. Other attacks in the same incoming wave cannot change
that already released power. Target statuses and HP/armor use pre-hit defenses.

Arm blades stay equipped: 1E5 does not discard, summon or grab 2E4's replacement
items, and gains no venom, healing, revival or Block-counter ability from this
shared implementation. Death cancels controlled work while released wounds
survive intentionally. Restoration retains the next-arm cursor like physical
resources, without resuming old action callbacks. This retention is a delegated
choice; 1E5 itself gains no revival cast.

## Passive bleed and timed piercing

`PassiveAbilities` routes known passive models to independent healing/modifier
controllers and rejects unknown or aliased definitions. 1E5 passive 4 supplies
an actor-specific multiplier of two. Each released attack snapshots that
passive's identity/value alongside any timed grant and its pinned component.
The passive has no action, hand lock, cooldown or dyspnea payment.

Each delivered slash creates the existing eight-second bleed using twice that
packet's nominal post-armor HP basis. It does not double direct damage, armor
loss or statuses. Full shield absorption creates no bleed. Different sources
keep their own multiplier; ordinary 2E4/gun wounds do not inherit it. The common
HP ledger still clips overkill and excludes friendly damage from eligible
outgoing credit. Wounds retain source/action/life identity and survive caster
death; recipient death retires that life's wounds.

The actual Ultimate uses [shared enhancement rules](ATTACK_MODIFIERS.md): no
unlisted hand/cost/self status, request-anchored 65 s cooldown, Active-end grant
at 320 ms and `[320,15320)` eligibility for an uncontested activation. Both arms
snapshot +80 piercing at their own emission. The bonus applies to slash armor
mitigation and hence the wound's post-armor bleed basis; it does not bypass
shielding. Expiry, cancellation or death cannot rewrite a released snapshot or
an already created wound. The passive remains on later attacks after expiry.

## Individual hand availability and common movement

The existing source-composed restriction mechanism now accepts named hands
`hand:left`/`hand:right`. A restriction checks both declared functions and named
occupied resources, so it prevents/cancels any action using that hand. This is
shared behavior: a blocked right hand also prevents 2E4's thrust while allowing
its left-hand Block. Restricting 1E5's next right hand does not cancel an active
left swing. The cycle waits for the required hand and does not skip to exploit
the other arm. Other independent restriction sources still compose.

1E5's sourced profile is HP 20000, armor 350, Recovery 200, run 7 m/s and sprint
bonus 5.2 m/s (total 12.2). Shared jump takeoff is 3.5 m/s upward with gravity 9.81.
Source basic sections p109–170 supply jump G100/A150/Db1.2, crouch A150/Db0.8,
walk/run O/U80/Db0.5, climb G150/A300/O80/U250/Db2.5, sprint transition O/U100/
Db0.5 and continuous base 2. Shield basic 7 gives 4000 stock, 20 s delay, 400/s
shared recovery and one toxin resistance per 100 current shield HP.
Missing values reuse explicit delegated defaults: walk 2 m/s, walk/run A150,
sprint transition A200, stand A150, existing stop/slide/pose/climb geometry and
neutral hands. The same body physics/resources execute; no standalone movement
benchmark is claimed as integration.

## Evidence and remaining scope

35 new interaction methods cover actual alternation, handed restrictions,
interruption, resource payment, passive isolation, independent actions, body
flight/hits, cover, Block/counter, mixed simultaneous wounds, exact expiry,
posthumous damage, old/new lives, immutable frame identity and numeric controls.
One additional provenance/units regression and all 1619 suite tests pass in
225.661 s. Nine ordinary complete API/CLI captures, three hash controls and
four combined precision/observation/order controls pass. Both review suites and
the preserved modifier/Block/counter/melee/effort/healing/revival/life captures
replay unchanged.
[Current inputs, public API/CLI captures and logs](results/component-melee/README.md).
Restriction/restoration/modified-profile controls are labelled engineering
probes; ordinary captures use unchanged current character profiles.

1E5's grapple/drag, dash and Break delivery remain unfinished, as do other
remaining character kits and general 5v5 completeness. Next: shared authoritative
spatial transitions and linked-body constraints for authored grapples, drag,
chains and portals. Preserve imposed displacement, support/ground departure,
collision validity and life identity in that work. Advanced NPCs and mass
experiments remain deferred.
