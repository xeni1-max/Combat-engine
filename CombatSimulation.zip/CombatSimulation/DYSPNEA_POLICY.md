# Dyspnea and physical effort

[Binding Break](BINDINGS.md) uses the source's fixed 20/s filling paused by
disorientation. Under delegation, attempted filling counts as escape work even
when stored D is capped; actual gains still cap at100 and use the shared writer.
Crossing the cap applies the existing O200 pause once. This prevents a full bar
from making escape impossible and is documented separately from the source rule.

The subsequent [effort/interruption clarification](ABILITY_EFFORT.md) defines
intrinsic/extrinsic and momentary/sustained per controlled phase. Cost, effort
category and independent effect lifetime are separate properties.

Current [payment-boundary handling](ACTION_OWNERSHIP.md) preserves the authored
cost anchors when concurrent continuous effort exhausts a pending action's
capacity. An unaffordable owned phase cancels transactionally without payment
or a new release; earlier committed work survives. This is a delegated failure
policy implementing `Dyspnea details.odt` p23, not a new early payment, refund,
cost clamp or universal activation cost. [Verification](results/payment-boundaries/README.md).

Author clarification, 2026-10-28. Dyspnea represents the character's effort.
Effortless extrinsic activation, summoning, marking an area, a passive effect
or an automatic enhancement does not need an invented dyspnea value. An effect's
damage or complexity does not itself establish a cost. The author gives these
explicit examples:

| Character / ability | Confirmed dyspnea rule |
|---|---|
| 1E1 / 4 | Summoning the beam by raising a hand has no cost. |
| 1E2 / 5 | Summoning the electrocution fence has no cost. |
| 1E3 / 3 | Opening the portals has no cost. |
| 1E3 / Ultimate | Marking the projectile-duplication area has no cost. |
| 1E5 / 4 | Passive bleeding enhancement has no separate cost. |
| 2E4 / 2 | The block-triggered effect has no additional cost. |
| 2E4 / Ultimate | Activating the ability-1 enhancement has no cost. |
| 2E4 / 5 | Revival has no cost, by explicit preference. |

The [actual automatic 2E4 counter](COMBAT_REACTIONS.md) now executes its exemption
without an additional payment or hand lock. The originating Block still pays
its own authored cost; no character ability is inferred from sharing the
underlying Block mechanic.

Physical operations retain their own costs: firing/recoil control, throwing,
blocking, reloading, movement or another documented effort. In particular,
1E2 gunfire retains Db=2 for recoil control and reload retains Db=0.5. The
existing author-confirmed 1E1 Qard firing cost Db=2 remains. Extrinsic damage
is not a blanket exemption for the physical action used to deliver it.
An enhanced attack or block keeps its own documented cost without adding a
second cost for the passive/triggered enhancement. Effort during an ability
may have a cost even when its activation is effortless; evaluate its actual
phases rather than charging for a summon's independent lifetime.

## Representation and integration

An exemption is explicit `dyspnea.kind=none`, **not Db=0**. The action formula
`Da=(Db+D/100)^2` still produces positive cost for Db=0 when D>0; an exempt
activation bypasses that formula and reserves no dyspnea capacity, including
at D=100. No dyspnea-value field is required for that exemption.

The eight cases are recorded in `data/characters.json` under
`documented_abilities`, separately from executable ability definitions. 1E1's
beam already uses the same exemption in shared combat. The other entries
confirm cost semantics; they do not establish effect integration. The passive
has no separate controlled activation. Source ODTs and historical captures
remain unchanged.

During future kit implementation, classify missing cost fields from the
documented physical effort and this author preference. Do not treat an
effortless summon/mark/passive's absent number as a blocker or silently assign
it Db=0. A physically demanding operation with incomplete timing/value data
still requires a documented delegated decision. Existing hand Recovery,
Gathering, cooldowns, restrictions and general dyspnea-recovery blockers are
separate mechanics; this clarification changes no such rule.

Delegated application: [1E2 ability 2](COOLDOWN_PAUSES.md), another area-marking
activation, now uses the effortless-activation exemption. Its older source value
0.5 remains recorded as history. This is an implementation application of the
author's general preference, separate from the eight explicitly named examples.

The 1E2 source revision inspected after resumption replaces that old 0.5 entry
with “extrinsic momentary” activation. The runtime exemption already agrees;
[source revision evidence](results/cooldown-pauses/REPORT.md) preserves the
original capture hash and the newly observed source.
