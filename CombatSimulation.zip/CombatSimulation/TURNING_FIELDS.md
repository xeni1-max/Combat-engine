# Turning bodies and deployed fields

2026-11-13. Delegated engineering integration; no character/ability data or
authored field behavior changes. [Evidence](results/turning-fields/README.md).

## Geometry and ownership

Native turns now participate in the existing heat columns, cooldown pause
columns, released spherical poison and segmented electrical fences. Each
recipient uses its actual six body parts and the same saved translation/pose
prefix as movement and contacts. Heading is the original anchored yaw arc.
No field query owns translation or reanchors a turn at observations.

The selected earlier membership rules remain: union overlap applies once to a
recipient; a beam part uses its nearest horizontal witness and top height for
the existing downward cover ray; cooldown areas and gas ignore cover; fence
parts use actual cuboid overlap. Released fields retain their deployment shape,
position, source action and source life. They do not rotate with the caster.
Heat/toxin memory and doses, remaining cooldown work, binding and electrocution
continue through their existing writers and recipient-life rules.

## Continuous query contract

Fixed-heading inputs keep the original rational-polynomial partitions. Active
yaw paths use rational intervals for reference/local pose, dimensions, yaw
coefficients and their derivatives. Sphere/column distance uses the actual
closest point in local coordinates; boxes use upright SAT axes. Cover tests
bound the same nearest witness in each fixed blocker's real local frame.

Whole-interval bounds prove eligibility or clearance. First-derivative bounds
and a mean-value enclosure tighten smooth tangencies. Midpoint values are
bounds anchors, not samples standing in for continuous geometry. Exact signed
vertical face coefficients preserve anchored feet and changing pose tops.
The existing bounded-yaw coefficient uncertainty is carried in the values.

Subdivision isolates transitions to 1e-28 s brackets. Adjacent unresolved
brackets may coalesce only within the existing 1e-27 s field resolution;
isolated tangencies add no open exposure. The next open cell starts at its
confirmed side, rounded upward. Fence entry therefore retains closed overlap
when its binding cancels motion/turning. Wider unresolved ranges or the bounded
100,000-node query budget raise explicitly rather than silently becoming misses.
Shared forecasts stop after the first change; the standalone query can return
all cells. Immutable yaw bounds are cached with a bounded cache.

Reconciliation itself can queue an immediate cooldown decision. This shortens
the saved prefix between fields/recipients. Geometry clips to that current
prefix, and the coordinator returns the queued phase before forecasting again.
The overlap regression exposed and verifies this correction. No query extends
a lease merely to answer an earlier, longer request.

## Scope and verification

Actual casts exercise stationary beam edge/cover changes, firing while entering
and leaving cooldown fields, overlapping pause sources, electrical contact and
turn cancellation, real grenade gas, independent source death, walking and
crouching. Numerical controls compare field transitions, exposure clocks,
cooldown work, source/recipient lives and HP accounting as well as final states.
See the evidence package for current counts and retained failed drafts.

[Angular support](ANGULAR_SUPPORT.md) now handles static/living departure and
landing through the same saved paths. The shared interval primitives now live
in angular_intervals.py; field clock behavior remains unchanged.
[Active grapple/tether response](ANGULAR_LINKS.md) is extended separately;
prescribed angular climbing remains guarded. This field extension itself removes
the field/contact-field admission guards only. The final cross-kit matrix and
reproducible 5v5 experiments remain; advanced NPC/mass/balancing work is deferred.
