# Author character revisions observed 2026-10-31

**Runtime follow-up, 2026-11-01:** [shared attack modifiers](ATTACK_MODIFIERS.md)
now execute 2E4 ability 4 and Ultimate with real timing, defense routing,
death and cooldown interactions. [Component melee](COMPONENT_MELEE.md) also
executes 1E5's actual alternation, passive double bleed and timed piercing.
The import status below describes the original 2026-10-31 source checkpoint.

Primary ODT hashes changed since the verified healing checkpoint for **1E5 and
2E4**; the other twelve primary documents match that checkpoint. Paragraph
comparisons against the preserved old sources establish these author edits:

| Ability | Current authored definition | Superseded definition |
| --- | --- | --- |
| 1E5 / 4 | Attacks apply twice the bleeding. | Bleeding amplification scaling with the caster's current bleeding on the recipient. |
| 1E5 / Ultimate | For 15 s, ability 1 gains 80 piercing; 320 ms Active, 65 s cooldown. | Two extra arms for 6 s, doubled attacks; self O/U200, Db4, intrinsic sustained category. |
| 2E4 / 4 | Next ability-1 attack removes 20 additional armor; 200 ms Active, 9 s cooldown, extrinsic momentary. | Slow owner-contact projectile followed by a radius-5-m attack/knockdown. |
| 2E4 / Ultimate | For 10 s, ability 1 ignores 4000 shielding; 400 ms Active, 60 s cooldown, extrinsic momentary. | Attached blades lasting 2.5 s. |

The updated author documents take precedence. `data/characters.json` and the
current roster now record these definitions. These four abilities are still
**source-only**, not shared runtime support. No old projectile, extra-arm or
attachment-duration ability is being implemented under their current names.
The actual basic thrust, venom, revival, passive healing and Block source values
are unchanged. Deleted paragraphs shift later 2E4 source indices; current
movement metadata now cites stable named sections.

Effort interpretation under the existing author policy: these enhancement
activations require no separate dyspnea charge where none is now specified.
1E5's changed Ultimate receives delegated extrinsic momentary activation metadata;
the author removed its old Db4/self-status/intrinsic-sustained entry. This is
metadata only until its actual enhancement controller is implemented. Preserve
the physical attack's own costs/statuses.

Future runtime work must define finite modifier lifetime, next-attack consumption,
simultaneous armor-loss ordering, and per-packet shielding bypass on the shared
layer foundation. Those delivery details are not claimed by importing fields.

Historical ODT copies, data, reports, captures and manifests remain unchanged.
The [source refresh package](results/character-source-refresh-2026-10-31/README.md)
contains exact current ODT copies, old/new hashes and paragraph diffs. Earlier
audit descriptions of these abilities are historical and superseded by this file.
