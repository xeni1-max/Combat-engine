# 2E4 ability 1: audit and controlled implementation

**Historical controlled scope.** As of 2026-10-29, the shared moving engine
also executes this thrust, real melee collision, shield overflow, attached and
residual venom, independent replacement summoning and owned grabbing.
[MELEE_VENOM.md](MELEE_VENOM.md) records current rules, delegated decisions and
remaining kit boundaries; [ordinary API/CLI evidence](results/melee-venom/README.md)
verifies the extension. The restrictions and test counts below describe the
preserved earlier runner. Current ODT replacement text is p74, formerly p72.

The root ODTs and author clarifications are authoritative. Source hashes match the reviewed snapshots; ODTs were not edited. The shared slash layer is reusable by 1E2 and 2E4, without requiring 1E2's firing/ammunition rules first.

## Confirmed definitions

| Rule | Source | Implementation |
|---|---|---|
| Raw thrust damage 440; slash; piercing 40 | `2E4.odt`, overview, p50/p67 | Combined shield/slash helper; unshielded thrust controller |
| Gathering 140 ms, Active 180 ms, midpoint impact at 230 ms | `2E4.odt`, p52/p53/p63 | Explicit timing and Active-end event |
| Target disorientation/instability 110/110; mitigation uses pre-hit armor | `2E4.odt`, p55/p56; author reply | Target effects applied once using the preserved armor snapshot |
| Self effects 150/150 on impact, bypassing mitigation | `2E4.odt`, p58/p59; latest self-effect exception | Actual self state application and continuous decay |
| Current damage is calculated before new self-instability and before armor loss | Author reply | First thrust starts with zero actor instability; direct HP then armor update, then new self effects |
| Slash HP `max(0,(d²-max(0,a-p)²)/d)` | `Damage types.odt`, Slash p15; author floors | Exact rational calculation |
| Slash armor loss `max(0,(d²-a³/700)/(50d))`, with no piercing term | `Damage types.odt`, Slash p19/p21 | Same pre-hit armor snapshot; actual armor state floors at zero |
| Bleed `b=y(8-tb)/320` DPS for eight seconds | `Damage types.odt`, Slash p13/p17 | Continuous analytic integral, using captured slash y |
| Venom toxicity 700; one-second attachment is exposure | `2E4.odt`, p61/p69 and overview | Attached blade lifecycle and exposure timer |
| Venom d is slash damage left after shields, before armor mitigation | Author reply | Explicit input in helper/data; shielded runtime remains excluded |
| Venom armor is captured before the thrust/armor loss | Author reply | Frozen delivery snapshot used for both venom phases |
| Exposure grows 0→1 during attachment; afterward exposure stays 1 while non-exposure grows 0→1 | Author replies | Toxin ends two seconds after impact, when the root reaches zero |
| Bleed and venom accumulate continuously | Author reply | Exact phase integrals; no invented damage ticks |
| New blade starts summoning after impact; grab delay 600 ms; Active grab 250 ms | `2E4.odt`, p72 | Imported definition only; grab anchor/availability remain unexecuted |

Slash therefore creates both direct damage and bleeding, alongside the separate venom effect. The direct-hit result alone is not the complete damage result.

The author confirms **every venomous attack contains a slash component that enables toxin entry**. Its delivery factor is slash damage after armor mitigation divided by slash damage before armor mitigation; both values concern the damage left after shield. If shield absorbs the entire thrust, d=0 and delivery/toxin damage are explicitly **zero**, without evaluating a zero denominator. The helper reuses the slash formula, including armor/piercing and zero floors. This resolves the former d=0 ambiguity; it does not define other shielded damage-over-time interactions.

The author further confirms that later armor reductions must never change an already applied venom effect. The sequence is: capture armor for this venom application, resolve slash HP damage, then reduce armor. Each later venom application captures the armor present immediately before its own hit. The current controller already preserves the original snapshot; new regression tests verify that even a synthetic later reduction to zero armor leaves the existing venom unchanged. Actual overlapping encounters remain outside this stage.

## Exact continuous calculations

For fixed inputs, venom is `C*sqrt(q)`. During a full exposure interval of T seconds, q grows 0→T; during the following non-exposure interval it falls T→0. Each phase integrates to `(2/3)*C*T*sqrt(T)`. The helper preserves irrational roots symbolically; the current exact-HP controller requires rational full-phase integrals, as in this base one-second attachment. Ultimate is not implemented.

One bleed integrates over an interval as `y*(8*(end-start)-(end²-start²)/2)/320`, clipped at eight seconds. Its full integral is `y/10`.

HP accumulation is evaluated analytically at effect boundaries. The intervening Active-end event samples only actor state. Interval logs describe continuous changes, not tick payouts. The model excludes HP-dependent actions/death inside these nonlethal intervals.

## Supported initial scope

One stationary, scenario-confirmed unshielded, nonlethal thrust; two distinct character profiles; zero initial actor instability; no other actions or effects. Initial actor disorientation is supported and modifies Gathering. The attached blade is treated as an autonomous target effect for its stated duration, consistent with its damage continuing beyond the thrust's Active phase. General channel interruption behavior is not inferred.

Both self and target statuses, armor loss, the single bleed, growing venom exposure, non-exposure decay, and effect expiry actually execute. Target toxin resistance stays at its profile value because this scenario has no resistance-changing action. Current state, snapshots, calculations, and effect lifecycle are logged. Summaries include direct, bleeding, venom, and total HP damage separately.

## Numerical base case

2E4 attacks 1E1 starting with HP 8140, armor 150, toxin resistance 40, and shield 0:

- At 230 ms: direct slash **412.5**, armor loss **26429/3080 ≈ 8.58084416**, self effects **150/150** unmitigated, target effects approximately **65.86395448** each using pre-hit armor.
- Bleed starts at **10.3125 DPS** and totals **41.25** over eight seconds.
- Venom delivery factor is **15/16**; toxin factor is **23988/35**. Peak rate is **17991/28 ≈ 642.53571429 DPS**.
- Venom totals **5997/14** during attachment and the same amount after detachment: **5997/7 ≈ 856.71428571** overall.
- Total HP damage is **36693/28 ≈ 1310.46428571**. Final HP is **191227/28 ≈ 6829.53571429**, armor **435571/3080 ≈ 141.41915584**.
- Blade detaches at **1230 ms**, venom expires at **2230 ms**, bleed expires at **8230 ms**.

## Remaining questions and explicit limitations

The d=0 delivery rule is resolved: fully shielded thrusts cause no toxin damage. Shielded encounters still need bleed basis/creation under shield absorption, raw continuous damage-to-shield handling, and corresponding regeneration history. The controller rejects shielded targets rather than guessing these rules.

Repeated attacks need bleed/blade overlap rules, replacement-blade grab delay anchor and availability, and Recovery/limb behavior. Ultimate interactions, general initial-instability damage modifiers, time-varying toxin resistance, dyspnea/cooldown eligibility, healing/revival, movement, general interrupts, death, and autonomous decisions remain outside this model. None is silently approximated.

The scenario and CLI are `scenarios/2e4_venomous_thrust.json` and `python3 -B -m combat_sim run scenarios/2e4_venomous_thrust.json`. The original saved stage passed **187 tests**; the current suite, including armor-snapshot and zero-delivery regressions, passes **192 tests**. The numerical outcomes are unchanged. Saved comparisons, source/code snapshots, full traces, and reproduction are in [results/2e4-ability1-stage](results/2e4-ability1-stage/README.md).
