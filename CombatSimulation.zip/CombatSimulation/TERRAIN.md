# Stationary battlefield terrain

Author-confirmed rules, 2026-10-25. These extend the approved bodies and
projectiles in [HITBOXES.md](HITBOXES.md); the earlier body-only result remains
frozen under its original scope.

The battlefield is 500 m along x, 500 m along y, and 200 m high. Its horizontal
centre is (0,0). The finite ground is the rectangle x/y −250 to 250 m at z=0.
The nominal volume extends to z=200. Sides and top are open: there are no
collision walls or ceiling. The 200 m height does not specify ground thickness.
The ground is represented by its surface, without an invented underground slab.

Three axis-aligned solid cubes rest on the ground. Each measures
1.8 × 1.8 × 1.8 m, with the supplied x/y positions at its horizontal centre.

| Object | Centre (x,y,z), m | x bounds, m | y bounds, m | z bounds, m |
|---|---|---|---|---|
| cube_1 | (6,0,0.9) | 5.1 to 6.9 | −0.9 to 0.9 | 0 to 1.8 |
| cube_2 | (2,15,0.9) | 1.1 to 2.9 | 14.1 to 15.9 | 0 to 1.8 |
| cube_3 | (15,15,0.9) | 14.1 to 15.9 | 14.1 to 15.9 | 0 to 1.8 |

Cubes remain fixed throughout the run. No terrain HP or destruction rule is
introduced. Terrain data are separate from character data and action policy:
[data/terrain/stationary_arena.json](data/terrain/stationary_arena.json).

Ground and cubes stop projectiles at the first actual sphere/surface contact.
The existing rounded sphere/cuboid sweep also handles the finite ground's edges
and corners. Terrain contacts use the same authored travel-speed/acceleration
rules and upward millisecond timestamp rounding as body contacts. Qard creates
its delayed mark at the physical surface contact point, then blasts 500 ms
later. Gunfire stops without creating a mark. Dead bodies cease colliding;
released projectiles retain their trajectory and may subsequently hit terrain.

Qard blasts and downward beams damage every overlapping living character,
once at full strength, regardless of intervening cubes. Terrain does not
occlude these two area effects. Friendly fire rules remain in effect.

Gravity remains unimplemented. This stage preserves straight projectile paths;
the later author clarification supplies g=9.81 m/s², compensated aim and actual
path-length falloff. Remaining trajectory choices and implementation status
are recorded in [GRAVITY.md](GRAVITY.md). A shot with no
scene contact remains pending on its original ray, without an invented lifetime
or boundary collision. Movement and terrain-aware NPC decisions remain outside
this stationary experiment. Exact ties between different scene contacts still
require a rule rather than an arbitrary priority.

Run the unchanged teams, initial states and action policy with terrain:

```sh
python3 -B -m combat_sim run scenarios/stationary_2v2_terrain.json --summary-only
```

[Saved terrain result](results/stationary-2v2-terrain/REPORT.md) ·
[Battlefield map](design/terrain/arena.svg).

## Climbable block extension

Cube_1 at (6,0) is now marked climbable; the other two remain non-climbable.
Origin-to-surface activation range is inclusive 0.5 m. The standing climb test
and approved path are documented in [CLIMBING.md](CLIMBING.md). Moving-climb
handoff and collision-response work awaits the author's new body-collision
details, at their request. Prior frozen terrain/result inputs remain unchanged.
