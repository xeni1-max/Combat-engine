# Common grapple Break and controller response

This executes the existing basic Break against actual
[1E5 grab/holding](GRAPPLE_DELIVERY.md). It adds no character ability. The shared
controller consumes live hold/action/life identities, so later grapple deliveries
can use the same contest rules. [Implementation](combat_sim/grapple_break.py).
Primary ODTs remain unchanged. Decisions below resolve source gaps under the
author's delegation; they are not additional author confirmations.

## Source and effort

`Grapple abilities.odt` p10/p14 and Object 2 compare empty bar capacity with
the signed status correction. Using current adjusted D/O/U:

`D_controller - D_defender >= (O_defender-O_controller+U_defender-U_controller)/10`.

Equality succeeds. Do not mitigate adjusted statuses again. The existing source
fatigue limit `D_controller >= max(0,100-(O_controller+U_controller)/10)` remains
separate. Pure source helpers retain exact rational arithmetic.

After a failed initial comparison, the controller can respond with the same
grapple input. The selected default response window is **150 ms**, configured
in `grapple_break.response_window_ms`. It is half open: a response strictly
before the deadline works; one at the deadline is late. Repeating Break does
not extend it. No response releases that hold. A timely response is contextual
input on the existing hold, not a new grab/cooldown/hand action.
Script/window clocks use the world's owned Decimal precision. Times within
1e-24 ms of a deadline classify as that deadline; rounding an exact rational
deadline under a caller's lower precision must not turn it into an early answer.
Configured windows must exceed that clock resolution.

The primary basic lists name Break without separate Gathering, Active or cost.
Under delegation its input is immediate, with **no separate point cost**. The
source-specific **20 D/s** then fills each participant during an answered
contest. This is explicit fixed filling, not Dd20 or negative ordinary recovery.
Holding and sprint still add their own squared sustained rates to the same bar.
Filling continues while disoriented; the binding pause is not copied here.

The comparison stays active during the response window, so a pending request
can succeed before an answer/deadline if its statuses/resources change. This
pending-window interpretation is delegated. Each contest owns only its chosen
hold, not every link in a connected motion group.

## Controls and ownership

Current shared inputs support optional `control_script` rows:

```json
{"actor":"B","at_ms":200,"command":"break","expected_life_generation":1}
```

Grapple commands are `break`, `continue_grapple` and `release_grapple`. `link_id` is
optional: choose the oldest eligible incoming hold for Break or outgoing hold
for response/release, breaking same-time ties by controller and link identity.
Use an explicit link when addressing one of several holds. Input list order
owns commands at the same timestamp. All rows validate before any scheduling;
a loaded script cannot be loaded again. There is no advanced NPC decision rule.

The same validated control script now routes [binding Break](BINDINGS.md).
An unqualified `break` selects an eligible incoming grapple first, then a
binding. Use `break_binding` or `binding_id` for explicit binding selection and
`stop_binding_break` to stop that focus. Mixed link/binding selectors are invalid.
Binding's maximum-HP work threshold and disorientation pause do not alter the
grapple comparison, response window or actual-gain penalties described here.

Scripts bind the supplied expected life, defaulting to initial life 1. Direct
API `world.grapple_break.command(actor, command, ...)` defaults to the actor's
current life at that call. Dead/stale lives, wrong controllers, unknown links
and late responses cannot operate another hold. Repeated event delivery and
duplicate requests/answers cannot create extra filling channels.

The defender's Break intent owns a private per-contest token, with no limb,
weapon or locomotion exclusivity and no point reservation. This bookkeeping
does not give a body-restriction effect an unintended way to lock out escape.
Compatible movement, sprint, weapon and other independent actions retain their
own rules. The controller's additional filling is owned by the existing hold;
the defender's by its Break intent. Both retain their current life identities.

## Clock, comparison and penalties

Controls enter after due phases, simultaneous hits and physical contacts.
Expiry/deadline phases and actual life/fatigue teardown precede an escape
resolved at that same instant. A forecast escape rechecks current bars/statuses;
a higher-priority change invalidates it rather than allowing an old prediction
to release the hold.

The earliest-boundary solver reads the same saved effort prefixes that commit
D. It splits at status expiry, caps, input changes and dense-polynomial knots.
Interval derivative bounds isolate the first nonnegative margin, including an
interior crossing with negative endpoints and a tangent. It does not advance
combat on observation/damage ticks or assume the difference is monotonic.
World resolution is 1e-24 ms in clock and 1e-18 in comparison margin; the mixed
effort ODE retains its existing conditional dense error controls, without a
certified global-error claim. [Solver](combat_sim/mechanics/escape_boundary.py).

For an answered contest, **every ending** (escape, expiry, owner release,
restriction or life/fatigue teardown) retains its accumulated Break penalty.
This delegated interpretation avoids dropping the accumulated penalty by
voluntarily releasing/cancelling. A is the sum of **actual fixed Break gains
on this link for both participants**, after caps. Ordinary holding/sprint and
point payments are excluded. An unanswered/immediate contest has A=0.

Incoming O/U base is `3*A` from source p17/p21/Object 4. Apply it once to this
pair's still-living matching lives, with their individual maximum HP, current
armor and live additional status defenses. Do not sum group stats or use a
running self multiplier. Other graph members get no penalty for sharing motion.
The effect deals no HP damage or healing/revival credit.

Positive penalties are staged **after due phases/hits/contacts**, using current
defenses at application. This preserves an Active start due at expiry/fatigue;
unfinished future Gathering still receives incoming O. An actual expiry/thrust
tie reproduced the premature-Gathering extension before this correction.
Penalty receipts apply once and remain life-bound after their hold ends.

## Verification and remaining scope

Current evidence is [results/grapple-break](results/grapple-break/README.md).
Actual grabs exercise immediate/pending/answered/unanswered/late Break, multiple
contests, proportional capped filling, real sprint/exhaustion, safe gun payment
failure, independent movement, imposed group flight, source death, recipient
healing/revival and stale controls. An independent RK4 comparison checks the
ordinary answered escape time. Numeric/observation/order and full API/CLI
captures verify the shared path; engineering timing/force probes are labelled.

Binding/chain and the environmental grappling gun retain separate release
rules. This does not complete 3E5 charge/slam, authored knock trajectories/
elasticity, dash/portal delivery or the six kits. Linked prescribed climbing,
ledge/dynamic support, fixed facing and broader prone/Get Up remain explicit
boundaries. Advanced NPCs and mass experiments remain deferred.
