# Project Instructions

## 1. Project purpose
This project is a computational simulation of a combat system described in the project documentation.

The goal is an internally consistent, inspectable combat simulation without animations,
progressing toward reproducible 5v5 experiments with different starting positions
and NPC behaviors. Use the six existing characters: 1E1, 1E2, 1E3, 1E5, 2E4, 3E5.
Do not invent new character abilities.

## Author delegation (2026-10-25)
The author's strategic instruction supersedes earlier requirements to obtain
permission for each missing or inconsistent mechanic. Work incrementally for
long-term efficiency. Decide and implement mechanics changes needed for internal
consistency, including battlefield and hitbox changes. Ask the author only when
input is indispensable. Record each material design decision, its rationale,
and implementation status in the relevant mechanics document and PROGRESS.md.
Distinguish author-specified rules from decisions made under this delegation.

### Role clarification (2026-10-27)
The author is the creative director, supplying characters, imaginative abilities,
combat preferences and feedback. The implementation agent owns detailed game
design, mathematics, architecture and implementation. Preserve unusual defining
features by solving their technical requirements; do not simplify them away for
convenience. Improve balance, exploits and unnecessary complexity within that
constraint, favoring reversible choices when uncertain. Ask only when a choice
would substantially change character identity, remove an important creative
feature, or establish a major direction not reasonably inferable from confirmed
preferences. Maintain those confirmed preferences in DESIGN_PREFERENCES.md,
separately from delegated decisions and interpretations.

Current priority is the shared combat engine with all existing abilities and
interactions testable. Advanced NPC intelligence, learning and large automated
experiments are later work; preserve reasonable compatibility without diverting
substantial effort from the engine. Prefer reusable mechanics and allow multiple
independently active abilities/persistent effects where documented rules permit;
do not impose arbitrary global exclusivity. Claim integration only after the
mechanic works in the shared combat engine.

## Session efficiency
The author also requests protecting quality as usage or context becomes scarce.
Use bounded, coherent work sessions. Reserve capacity for verification, review,
and a durable handoff; do not start another large change when it cannot be
finished and checked within the session. Stop at a verified checkpoint with
current results and the next concrete step recorded. Do not claim to know an
account quota that the available tools do not expose.

## 2. Source of truth
- Start with the root mechanics documents and explicit author clarifications.
- Resolve gaps and contradictions under the author delegation above; document
  selected rules instead of silently treating assumptions as author statements.
- Conventional game behavior is not automatically part of this system.
- `reference_material_non_authoritative/` is optional background, not a primary specification.
- Ask about ambiguity only when the decision cannot responsibly be made within
  the delegated scope; otherwise implement and test a documented choice.

## 3. Implementation
- Implement mechanics according to their documented definitions.
- Keep mechanics modular so they can be modified independently.
- Separate combat rules from character data and simulation controls.
- Preserve existing working functionality when making changes.
- Formula and numerical changes are authorized under the delegation above;
  justify material changes and preserve historical result snapshots.

## 4. Verification
- Test mechanics individually before testing complex interactions.
- Check edge cases and interactions between mechanics.
- Report discrepancies between documented behavior and implemented behavior.
- Make simulation results reproducible whenever practical.

## 5. Communication
- Ask specific questions when clarification is necessary.
- Explain significant implementation decisions.
- Clearly distinguish documented rules from implementation assumptions.
- Avoid unnecessary changes outside the requested task.

## 6. Project continuity
- Maintain PROGRESS.md with completed work, important decisions, known issues, and next steps.
- Consult PROGRESS.md when beginning new work.
- Record important clarifications in the relevant mechanics documentation rather than relying solely on conversation history.
