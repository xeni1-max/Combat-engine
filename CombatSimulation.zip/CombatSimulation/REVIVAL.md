# Death-triggered revival in shared combat

Implemented 2026-10-29. Current definitions opt into
`death_revival: {"mode": "death_revival_v1"}` with actor lives, applied-HP
history and remaining-work cooldowns. 2E4 ability 5 now runs automatically after
an eligible real death through the ordinary shared world. It is not a manual
restoration fixture or a living hand/body action. Frozen inputs without this
mode preserve their previous terminal-death behavior.

## Source facts and delegated decisions

Root `2E4.odt` p13 supplies the death trigger, HP equal to damage dealt in the
last 10 seconds, 65 s cooldown and three charges; p134 gives 2000 ms Active.
`Details2.odt` p0 excludes shield damage. The author's dyspnea clarification
explicitly exempts this revive from cost. The authored ODTs are unchanged.

The source leaves several operational details unspecified. Under delegation:

| Decision | Rationale and executed behavior |
|---|---|
| Snapshot eligible actual HP at death | Uses the existing actor-wide `(death-10000,death]` history after that damage boundary commits. Posthumous damage continues to its original source but cannot increase an attempt already started. |
| Clamp restoration to maximum HP | The shared life transition enforces the character's HP range. No positive minimum is invented. |
| Require positive HP basis | Zero damage, shield/armor/construct loss and ineligible friendly/self damage cannot start a useful revival. A rejected trigger consumes no charge and starts no cooldown. |
| Three finite encounter charges | The source specifies three charges and a cooldown but no recharge rule, unlike its explicitly per-charge block cooldown. Preserve that stock and the separate 65 s gate; do not invent a refill. This is an explicit delegated interpretation. |
| Pay a charge and start 65 s cooldown at attempt request | Each actual attempt spends its use once. Failure or supersession does not refund it. The next death triggers only if charge stock and cooldown permit. |
| No delayed trigger after a cooldown-blocked death | The ability triggers upon death. Becoming ready later does not fabricate another death event or sample a newer damage window. |
| Revival cooldown progresses while dead | This background ability explicitly continues its work across death; ordinary weapon/ability cooldowns still freeze. Dead actors leave cooldown-pause membership. On restoration the background clock inherits current living membership. |
| Attempt Active is an independent death controller | No living action acquisition, hand lock, dyspnea, new Gathering or status extension is inserted while the body is dead. The original life generation gates completion. |
| Occupied completion fails once | Keep the shared retained-body pose rule and prevent teleportation, penetration or polling retries. The charge/cooldown remain spent. A later cleared pose does not restart the old attempt. |
| Independent restoration supersedes pending work | A new life invalidates the old attempt and its completion. An old event cannot refill a later life or grant another resurrection. |

These choices preserve the existing ability and are separately recorded from
author-specified values. A different charge/retry interpretation would require
an explicit rules revision and new evidence, not silently changing old captures.

## Shared implementation

[DeathRevival](combat_sim/revival.py) reads executable
`automatic_abilities["5"]` character data. Its state is per permanent actor,
with finite stock, distinct attempt IDs, captured life generation, death-time
HP basis, due time and terminal reason. It registers a background ability clock
without adding ability 5 to an ordinary attack-selection policy. Scenarios
continue selecting 2E4's actual attacks; revival is automatic.

The existing [cooldown system](COOLDOWN_PAUSES.md) now supports explicit
background registration and a per-clock death-continuation flag. It uses the
same remaining-work and pause-source primitives. The 2000 ms Active itself is
physical phase time and is never extended by a cooldown-pause area. A newly
restored actor's 65 s clock pauses if a live area still contains it; expiry/exit
then resumes its remaining work normally.

The death hook runs after controlled action cancellation, recipient attachment
retirement and removal of dead pause membership. The completion is a priority-0
generation-bound event. It calls the existing [life transition](LIFE_CYCLES.md),
which validates the retained pose, advances generation and restores only HP.
Armor, shield/debt, ammo, hands, fatigue/status and ordinary cooldown work retain
their death values. Unsupported bodies fall from rest under existing gravity.
Policies wake using the new life; old controlled phases remain invalid.

Already released shots, attached venom, bleeding on other bodies, beams and
replacement items retain their original sources. A blade made while 2E4 was
dead can be grabbed by a fresh action in its new life. Existing heat volumes
create fresh recipient exposure on the restored body. No healing/revival credit
comes from applying HP restoration itself.

Spending a charge does not erase damage history or consume a separate healing
entitlement. The immutable journal remains available to its documented actor-
wide windows; [passive healing](HEALING.md) now has its own one-time payout accounting.

Public results and summaries expose `revival_rules`, `revival_states` and
`revival_attempts`, including remaining charges, pending identity, actual
cooldown state and terminal outcome. Actor metrics distinguish attempts,
completed/blocked/superseded revivals and actual HP restored. HP conservation
uses the sum of initial HP supplied to all recorded lives minus final HP,
compared against attributed actual losses.

## Verification and boundary

[Shared tests](tests/test_revival_combat.py) use ordinary real gun, beam and
pause-area encounters. Labelled engineering probes additionally cover exact
window boundaries, maximum HP, three-charge exhaustion at the 65 s boundary,
body/solid obstruction, same-time collider expiry, independent restoration,
stale completion and airborne death. Observation/precision/actor-order controls
preserve physical outcomes within the existing tolerances.

[Ordinary API/CLI captures](results/death-revival/README.md) exercise actual
ability delivery with unchanged character data and no injected events or
encounter subclasses. Old melee, life and effort packages remain frozen.

[2E4 basic-10 passive healing](HEALING.md) now executes with consumed funding
and joint continuous HP/heal/death calculation. Its 90%-of-recent-incoming-HP
cap concerns healing, not HP granted by this explicit revival ability. Current
encounters verify both together; this package preserves its pre-healing inputs.
Other 2E4 abilities, layered blocks/charges, linked constraints, the remaining
kits and general 5v5 completion remain unfinished.
