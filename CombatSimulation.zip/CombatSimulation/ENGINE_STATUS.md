# Current engine capability and decision index

Updated 2026-11-14. This file is the current index; dated progress entries and
saved result packages describe their historical checkpoints. The overall
six-character engine is **incomplete**. No animations or new abilities are added.

**Current source-resistance repair and inherited controls, 2026-11-14 — verified:**
All3379 methods pass1318.186s with495 fixed tested files and no skipped/failing
methods. This includes31 previously paused policy/query methods plus4 new
all-roster fence methods. Authored1E1/3E5 electrical resistance150/250 is restored;
actual all-six fence/shield/HP/heat runs and18 complete CLI/hash/numerical
controls pass. All38 old kit/policy whole traces and controls remain exact on
current fixed inputs. [Evidence](results/fence-roster/README.md).
Per-actor nearest/lowest-current-HP policies use the legal action pipeline.
The original30s mixed battle completes with A4/B1 alive and independent HP/
life/resource checks. After prototype gates the field-query memo is promoted.
All3389 methods pass1403.140s with497 unchanged tested files; fresh unchanged
review sets pass4/4 and7/7. Broad numerical/CLI/variation controls are running.
The nearest full30s API/CLI/high controls now pass and the staggered baseline
completes (4/12 receipts). An independently reproduced invalidated-pose prediction
still affects lease/clock selection; this shared defect is the next correction.
A bounded ordinary profile points to balance-resume/support planning, with
167-bit current coefficients and no active distance link in its sample.

**Current six-kit delivery audit, 2026-11-14 — verified:**
All32 creative abilities plus6 additional basic slots have positive witnesses
under canonical current rules. Thirty-two complete encounters pass actual
contacts/triggers, HP/healing/life/resource accounting, fullCLI/hash4511 equality
and combined numerical/order controls (largest about2.0316e-43). Three stale
character status descriptions are corrected; all mechanical values and engine/
test code remain unchanged from the verified3344-method backend. This does not
prove universal interactions or final5v5. [Current mapping](KIT_INTERACTIONS.md) ·
[Evidence and next work](results/current-kit-audit/README.md).

**Prescribed angular/linked climbing, 2026-11-14 — verified:**
[Climb control](CLIMBING.md) now composes turns and compatible linked routes.
Genuinely redirected controls retire before future motion with native momentum;
tangent angular contact retains climbing. Joint gravity reaction and stationary
curve normals correct artificial floor launches. All **3344 methods pass in
1280.173 s**,490 fixed tested files,24 added methods and1 strengthened old
expectation. Seventeen complete captures pass hash/numerical controls;59 prior
controls pass (38 exact,16 cache-only,4 reaction-diagnostic-only,1 reviewed chain
physics change). All9748 older result files/fourteenODTs retain hashes. No
character data changed. The taut400ms case is correct within these checks but
expensive; broader cross-kit/5v5 verification remains. [Evidence and next work](results/linked-climb/README.md).

**Active linked turns, 2026-11-13 — verified:**
[Reference-space grapples and distances](ANGULAR_LINKS.md) now compose actual
angular impact response and cached-contact departure with saved motion. All
**3320 methods pass in 1073.145 s**, with 487 fixed tested files, twenty added
methods, 24 focused checks and both unchanged review sets (4 + 7 checks). Twelve complete frozen
captures and their hash/numerical controls reproduce; all 47 previous captures
remain exact. Shared recovery clearance now supplies existing native stationary-
face resolution after the real hook control reproduced precision-dependent
Get Up. All 9534 older result files/fourteen ODTs retain hashes; no character data
changed. Prescribed angular/linked climbing, final cross-kit coverage and
reproducible 5v5 remain unfinished. [Evidence and next work](results/angular-links/README.md).

**Angular support, 2026-11-13 — verified:**
[Finite/raised/living support](ANGULAR_SUPPORT.md) now composes candidate saved
paths without recursive lookup. Relative co-falling bounds and angular outgoing
edge revalidation correct two reproduced failures. All **3300 methods pass in
1042.127 s**, with 484 frozen tested files, unchanged review checks, twelve
complete captures/controls reproduced from frozen inputs and 35 prior captures
exact. Two current encounters are ordinary traversal/climb; ten explicitly label
initial placement/velocity probes. All 9386 old result files/fourteen ODTs retain
hashes. No character/ability data changed. Active links and prescribed climbing
remain guarded. [Evidence and next work](results/angular-support/README.md).

**Angular fields, 2026-11-13 — verified:**
[Saved-path membership and beam cover](TURNING_FIELDS.md) now supports native
turning through heat, cooldown pause, released gas and electrical fences. Existing
exposure/work/binding/life writers remain authoritative. All **3262 methods pass
in 972.101 s**, with 479 frozen tested files, unchanged review checks and seven
complete ordinary API/CLI/hash/numerical captures reproduced from frozen inputs.
All 28 prior captures and 9276 old result files/fourteen ODTs remain unchanged.
The shortened-lease overlap defect is reproduced before/after its correction.
Fields and angular support are integrated; active-link response and prescribed
climbing remain guarded.
[Evidence and remaining work](results/turning-fields/README.md).

**Angular owned contacts, 2026-11-13:** [live body attachments](TURNING_CONTACTS.md)
now connect the existing charge grab and falling foot to owner/target turns,
including post-turn rearm and fractional pose derivatives. Seventeen new tests
and four complete ordinary API/CLI/hash/numerical captures pass. All **3237
methods pass in 879.184 s**, with 475 frozen tested files, unchanged review
checks and 24 preceding complete combat captures exact with controls. All
9196 old results/fourteen ODTs retain hashes. Fields are extended above;
support is extended above; active-link guards remain. This extends the
initial native scope below, without changing character or ability data.

**Initial native turning, 2026-11-13:**
[Owned common turns](NATIVE_TURNING.md) now execute for all six profiles on the
shared timeline. Independent walking, real gunfire/Block, angular wall/body
contact and fatal interruption pass 26 new tests and six complete API/CLI/hash/
numerical captures. All **3220 methods pass in 854.181 s**, with 473 frozen tested
files and no failures/errors/skips. Both review sets pass; 18 old combat captures
and eight angular examples remain exact with controls. Fields are extended above;
support is extended above; active linked response and prescribed climbing
remain guarded pending migration. This is an initial native scope, not complete turning
for arbitrary six-kit encounters. [Evidence](results/native-turning/README.md).

**Latest verified angular prerequisite, 2026-11-13:**
[Anchored yaw paths](ANGULAR_PATHS.md) now compose exact saved reference pieces,
local pose/size polynomials, actual point derivatives and conservative continuous
enclosures. Box/box queries and the existing curved-projectile contact API use
actual oriented confirmation, preserving original flight distance. The 52 new
methods and 13 existing curved-contact checks pass. All **3194 methods pass in
957.233 s**, with 469 frozen tested files and no failures/errors/skips. Eight
geometry API examples pass hash/precision/order/context controls; 18 preceding
complete combat captures remain exact. Review checks remain 4/4 and 7/7. All
9037 older result files/fourteen ODTs retain hashes.
[Evidence](results/angular-paths/README.md).
At that geometry checkpoint native timed control was unfinished; it is extended above.
Common path/ownership integration, angular response/support and constrained
references must precede world admission. Character data and ability rules retain
their existing contracts.

**Latest verified actor geometry, 2026-11-13:**
[Fixed initial yaw](ACTOR_FACING.md) now works through actual pose/hand/Recovery,
Block, owned attacks, heading-dependent movement/delivery, dynamic planes and
implicit fence orientation. All six source body scales/Get Up work. All
**3142 methods pass in 952.210 s**, with 37 new methods and 464 frozen tested
files. Eighteen current captures pass hash/numerical/frozen-input controls;
eighteen previous captures remain exact. Review checks remain 4/4 and 7/7.
False restoration-corner and duplicate floor-solid checks are reproduced and
corrected. Character data and all fourteen primary ODTs are unchanged.
[Evidence](results/actor-facing/README.md). Timed angular motion is unfinished;
continuous prediction and owned turns are next, followed by prescribed linked
climbing and the final current cross-kit/5v5 checks.

**Latest verified shared geometry, 2026-11-13:**
[Fixed oriented materials](ORIENTED_WORLD.md) now feed native support/contact
response, occupancy, gravity projectiles, cover/fields, anchors and ordinary
climbing. Real charge-hand fracture, falling kick and slash also compose.
All **3105 methods pass in 931.219 s**, with 460 frozen tested files and
36 new methods. Eighteen complete captures pass hash/numerical controls and
fresh frozen-input reproduction; twelve prior current captures remain exact.
Review specifications remain 4/4 and 7/7. A newly exposed owned-contact numeric
type crash is reproduced and corrected, with pre-fix evidence preserved.
All 8648 older results/fourteen ODTs remain exact; no character data changed.
[Evidence](results/oriented-world/README.md). Its actor-facing guard is now
extended by the fixed-yaw integration above; continuous angular prediction/
owned turns, prescribed linked climbing and final cross-kit/5v5 remain.

**Latest verified orientation prerequisite, 2026-11-13:**
[Frames and oriented queries](ORIENTED_GEOMETRY.md) preserve the exact selected
metric and support fixed-yaw shapes in the existing projectile/body contact
APIs. Independent angle/polygon checks, source scales and curved/resizing
contacts pass. All **3069 methods pass in 936.224 s**, including 58 new checks,
with 456 frozen tested files. Six labelled geometry-query examples pass hash/
precision controls; twelve complete prior current-combat captures remain exact.
[Evidence](results/oriented-geometry/README.md). This is a prerequisite:
**the shared world does not execute timed turns**. Fixed material and actor
consumers are now migrated above. Continuous angular prediction and owned
turn control remain.

**Latest verified shared geometry, 2026-11-13:**
[Finite ground](FINITE_GROUND.md) uses real sheet contacts and the common saved
support-loss/flight writer. Partial support, all four edges, underside/edge
entry, valid below/outside placement, actual gunfire/heavy knock/grab and links
compose. Actual contact revalidation also prevents pose support switches from
freezing balance or restarting paid Get Up. Historical rules retain their old
guard. All **3011 methods pass in 783.208 s**, with 451 frozen tested files
and 35 new methods. Twelve current
captures pass hash/numerical controls; eight complete frozen older traces remain
exact. Review specifications remain 4/4 and 7/7. No character data or primary
source changed. [Evidence](results/finite-ground/README.md).
General facing/turning, prescribed linked climbing and complete current
cross-kit/5v5 verification remain unfinished.

**Latest verified review corrections, 2026-11-10:**
[R1/R2/R3 response](PRINCIPAL_ENGINEERING_REVIEW_2026-11-10_RESPONSE.md) verifies
raised static-face departure through shared paths/gravity, declared constructor
precision for direct/subclass/public callers, and current capability mapping.
Grenade pulse cover is explicit while gas remains unoccluded. All **2976 methods
pass in 886.083 s**, with 33 new methods, 75 affected compatibility checks,
four current and seven previous-review specifications. Fifteen current captures,
18 exact constructor/context comparisons, actual torso/post support and eight
exact frozen-input older traces pass. All 448 tested files retain pre/post hashes.
No old evidence, primary source or character data changed.
[Evidence](results/principal-fixes-2026-11-10/README.md).
That checkpoint retained an outer-floor guard, superseded by the finite-sheet
extension above. General turning, linked climbing and cross-kit/5v5 remain.

**Latest verified ability integration, 2026-11-10:**
[1E1's actual launcher](LAUNCHER.md) now uses owned 400 ms equip, per-actor ten-round
inventory, frozen ability 1 variants, physical first-contact grenades, independent
5m/8s poison and paid empty-stock return. Copies, source lives, Block, materials,
friendly fire, independent leap/beam, pause and earned revival compose.
All **2943 methods pass in 753.112s**, with 39 new methods and 442 frozen tested
files. The 103-method affected subset passes. Twenty-four ordinary API/CLI/hash
casts and five labelled API probes reproduce with precision 80/17 ms/reversed/
ambient precision 28 controls. Historical controlled timing remains exact. Of227 previous
complete traces,226 are exact; 1 correct only the wall-slam receipt's
contact → blunt label, with every other field exact. Original evidence remains.
All 7742 older results and fourteen ODTs retain their hashes;549 current files
are pinned. [Evidence](results/1e1-launcher/README.md) · [Scenario](scenarios/1e1_launcher.json).
Each roster creative ability now has a shared delivery, with documented limits.
That checkpoint's support work is now superseded by the shared static/finite
face extensions. General facing/turning, interaction checks and reproducible
5v5 remain. The overall Goal is incomplete.

**Previous verified shared foundation, 2026-11-10:**
[Poisonous volumes](POISON_VOLUMES.md) supply exact spherical body/pose membership,
independent load/residual episodes, live toxin defenses, HP-only doses,
source/recipient lives and passive healing/earned revival. The foundation's
2904-method suite and24 labelled API/eight ordinary cases remain separately
scoped historical evidence. Actual launcher delivery is verified above.
[Foundation evidence](results/poison-volumes/README.md).

**Previous verified ability integration, 2026-11-09:**
[Existing 1E1 leap and 3E5 leap/falling kick](LEAPS.md) now execute through shared
launch, flight, ownership, fractional foot-contact geometry and life rules.
Authored speeds/timings/costs/statuses remain; the first real kick contact uses
shared intrinsic power, shields/Block/material HP and downward knock, including
summed-stat grapples. Descent reversal, tethers, transport, death and earned
revival compose. All **2862 methods pass in 706.069 s**, with 36 new methods and
434 frozen tested files. Twenty ordinary API/CLI/hash/numerical captures and six
labelled API probes reproduce; all 169 prior complete traces are exact. No old
test changed. All 7330 earlier results and fourteen ODTs remain unchanged.
An optional periodic-stack-dump diagnostic exited 139 and remains unresolved;
ordinary native grapple and read-only observer paths pass. Current manifests
pin 539 files. [Evidence](results/leaps/README.md) ·
[1E1 scenario](scenarios/1e1_leap.json) · [3E5 scenario](scenarios/3e5_falling_kick.json).
Next deliver the existing 1E1 launcher, remaining interactions/boundaries and
reproducible 5v5. The complete six-kit Goal remains unfinished.

**Previous verified ability integration, 2026-11-09:**
[Existing1E3 portals](PORTALS.md) now use owned300ms/no-dyspnea deployment,
10m/8s endpoints, explicit allied use and shared per-user/pair/life2s reuse.
Atomic voluntary transport preserves offset, independent movement/force inputs,
pose, flight and landing debt; actual grapples travel together, tethers/blocked
partners preflight atomically, and native support/heat/electrical/pause/life
interactions compose. A reproduced same-clock tether attachment defect is fixed
by distance-topology plan dependencies. All **2826 methods pass in 749.094s**,
with52 new methods and429 frozen tested files. Twenty-four complete ordinary
API/CLI/hash/numerical cases and six labelled API probes reproduce; all139 prior
complete traces are exact. No existing test changed. All7093 earlier results
and fourteen primary ODTs retain their hashes.
[Evidence](results/portals/README.md) · [Scenario](scenarios/1e3_portals.json).
The subsequent leaps are verified above; remaining launcher/interactions
and the complete six-kit/5v5 Goal remain unfinished.

**Previous verified ability integration, 2026-11-09:**
[Actual 1E3 Ultimate](PROJECTILE_DUPLICATION.md) now deploys its 12m/25s field,
continuously detects allied projectile entry and symmetrically splits flights
4m apart. Source lives, released power, accuracy, utility payloads and traveled
distance survive; inherited field IDs prevent recursion while independent
fields stack. Native marking, device explosions, hooks, endpoint body/material
hits, expiry, death and restoration compose. All **2774 methods pass in 780.062 s**
with exact once-only coverage and 425 frozen tested files. Twenty ordinary
API/CLI/hash/numerical cases and six labelled API probes reproduce immutably;
all 113 selected prior complete traces remain exact. No existing test changed.
All 6916 older result files and fourteen primary ODTs retain their hashes.
[Evidence](results/projectile-duplication/README.md) · [Public scenario](scenarios/1e3_duplication.json).
The subsequent portal integration is verified above; remaining kits and5v5 are unfinished.

**Previous verified ability integration, 2026-11-09:**
[1E2 Ultimate](IMPACT_AREAS.md) now delivers the actual gravity/impact device,
one 900-base Qard area per physical collision and life-bound 250 ms Gathering
addition for six seconds. [Timed Gathering](TIMED_GATHERING.md) shares phase
commitments across attacks, reload, Aim, posture, jump, climb and replacement
preparation; maximum composition and once-only quantization prevent refresh
and rounding exploits. Source death, shield/Block/cover, material damage,
friendly fire and earned revival compose. All **2736 methods pass in 745.068 s**
with exact once-only coverage and 420 frozen tested files. Eighteen ordinary
API/CLI/hash/numerical cases and six labelled API probes reproduce immutably;
all 89 selected prior complete traces remain exact. No existing test changed.
Primary ODTs and all 6728 older result files remain unchanged.
[Evidence](results/1e2-ultimate/README.md) · [Public scenario](scenarios/1e2_ultimate.json).
The subsequent actual duplication field is verified above; the six-kit Goal
remains incomplete.

**Previous verified ability integration, 2026-11-09:**
[1E2's fence](ELECTROCUTION_FENCE.md) now uses owned summon, five independent
1500-HP panels, continuous body contact, shared 800/s electrical damage and
lower-body B2/common Break. Gaps, seams, actual gun/Qard/heat, independent
actions and source/recipient lives compose. Certified contact-side roots fix
the public walk/Break case. Feature dependencies no longer disable unrelated
world modes. All **2701 methods pass in 782.064 s**, with exact once-only
coverage and 415 frozen tested files. Twenty complete API/CLI/hash/numerical
cases and six labelled API probes reproduce; maximum final difference is
4.7388e-26 against 1e-8. All 63 selected prior complete API traces remain exact.
The first full run's two gate errors and exact source proof remain archived;
no existing test was rewritten. [Evidence](results/electrocution-fence/README.md).
[Public walk/Break scenario](scenarios/1e2_fence.json). The subsequent actual impact device and timed Gathering are verified above;
the full six-kit Goal is incomplete.

**Previous verified shared foundation, 2026-11-09:**
[continuous electrocution](ELECTROCUTION.md) now uses primary resistance through
the joint shield/HP solver, released source/recipient lives, optional material
support and immutable damage/healing credit. Actual beam destruction and natural
2E4 revival compose. A direct-API mixed-precision zero-step loop is fixed by
declared run context and queue normalization; an archived module reproduces it.
All **2658 methods pass in 860.075 s**, with exact once-only coverage and 411
frozen tested files. Eighteen labelled shared API/hash/numerical/context cases
and fresh reproduction pass; maximum final difference is 1.2471e-26 against
1e-8. All 45 selected prior complete API traces remain exact. Author data and
old evidence remain unchanged. [Evidence](results/electrocution-rate/README.md).
The subsequent actual fence delivery is verified above. This earlier
foundation checkpoint retained its separately labelled API scope.

**Previous verified integration:** [2E4 basic9 Dodge](DODGING.md)
replaces its obsolete Block import. The selected physical downward variant
retains Active 150 ms/Db 3.5, has independent four-charge/4500 ms serial stock, and
uses owned posture, actual hitboxes, interruption and life retirement. Hands
remain available for independent Block/thrust. A real beam exposed forecasting
past the pose reversal; heat eligibility now clips to valid path/phase bounds
before geometry queries. All 2618 methods pass in 828.112 s with exact once-only
coverage and 408 frozen tested files. Eighteen complete API/CLI/hash/numerical
cases and four labelled shared API probes pass and reproduce immutably; maximum
final-state difference is 1.0410e-46 against 1e-8. Author ODTs and older captures
remain intact. [Evidence](results/2e4-dodge/README.md).
The source audit, electrical foundation and actual five-part fence are now
verified above; other kit deliveries remain.

**Previous verified integration:** authored1E5/3E5 proportions now feed
per-actor six-part placement, pose/Get Up, hands/reach, movement/landing, climb,
support, clearance, aiming and area eligibility. Standing heights are2.275 m
and1.8375 m; ability definitions and combat stats remain unchanged. A real chain
exposed repeated motor input and near-tangent certification failure; corrected
residuals, a feasible shared-velocity anchor and matching per-force transport
retain strict certificates. Knock expiry also clears numerical residue.
All2590 methods pass in826.089 s with exact once-only coverage and405 frozen
tested files. Twenty-one complete API/CLI/hash/numerical witnesses and fresh
immutable reproduction pass; maximum final-state difference is2.5582e-45 against
1e-8. Sixteen prior hook traces remain exact, as do five older frozen-input
comparisons with the archived pre-change runtime. The502-file source/doc/primary
checkpoint preserves5661 earlier results and fourteen primary ODTs.
[Evidence](results/body-scales/README.md) · [Rules](CHARACTER_GEOMETRY.md).
The subsequent basic9 Dodge correction is verified above; other kits remain unfinished.

**Previous verified integration:** explicit world/surface targets
and1E2's grappling gun now execute actual physical hooks, separate paid launch,
finite terrain rope and native contact effects. Real beam destruction verifies
immediate control release through shared distance-end observers. All2560 methods
pass in528.051 s across four isolated processes with exact once-only coverage.
All401 tested files retain pre-run hashes. Sixteen complete API/CLI/hash and
combined precision80/17 ms/reversed captures pass, as does fresh reproduction;
sixteen previous complete traces remain exact. The497-file checkpoint preserves
all5493 earlier results and the current author source versions.
[Evidence](results/grappling-gun/README.md) · [Decisions](GRAPPLING_GUN.md).
The [authored geometry import](CHARACTER_GEOMETRY.md) is now verified above,
including shared motor/constraint corrections. The
[new primary-source revisions](SOURCE_UPDATES_2026-11-09.md) now have verified
geometry, Dodge and actual five-part fence imports, verified above.

**Previous verified integration:** existing [1E2 ability4](1E2_ABILITY4_AUDIT.md)
now fires through the shared owned projectile/accuracy world. Reusable
[body-part damage](BODY_PART_DAMAGE.md) freezes default/head outputs with one
release U snapshot and selects by actual contact before range loss and shared
defenses. Head intent can hit a torso; Block/terrain use default output. Source
firing/recoil/Db/cooldown and direct damage execute without an unlisted magazine.
185 affected methods, sixteen complete API/CLI/hash/numerical captures, fresh
reproduction and eleven unchanged prior complete Aim traces pass. The first
canonical run found only two obsolete Gathering180 timing expectations. Their
originals and failed run are preserved; 34 corrected timing methods pass. The
complete **2526-method suite passes in 805.091 s** across four isolated unittest
processes, with exact once-only discovery coverage and no skips or failures.
At that checkpoint all397 tested files matched their pre-run hashes. Integrity preserved
5348 prior results and fourteen ODTs; 491 current source/doc/primary files and
the new evidence are pinned. [Evidence](results/1e2-ability4/README.md).

**Previous verified integration:** [1E2 Aim and shared released accuracy](AIMING.md)
now has a sealed current-input checkpoint, including
[confirmed curved entry](CURVED_CONTACTS.md) for ordinary prison/ice contact.
Eleven complete API/CLI/hash captures, combined 80-digit/17 ms/reversed controls
and independent cone/HP/source/wall audits pass, as does fresh reproduction.
The 72-method focused subset passed. At that checkpoint all 393 runtime/data/
test/scenario files matched the 2492-method successful regression below; that
handoff changed documentation/evidence, not runtime behavior. Twenty-three
legacy traces retain their complete physical content; internal path counters and
pending decision revisions reflect the N1 correction. The archived scheduler
restores all 23 old traces exactly in an isolated diagnostic. Neither older Aim
package nor any preceding result is rewritten.
[Evidence](results/aim-toggle-confirmed-entry/README.md).
The subsequent grappling-gun delivery is verified above. Authored body scales
are now verified above, as is the subsequent basic9 Dodge correction. Other
unfinished kits and the full six-character/5v5 objective remain.

**Latest verified correction:** November 3 review findings N1/N2 are fixed.
Every successful owned acquisition reconsiders independent ready actions through
the common queue; an inert stop no longer changes combat readiness or damage.
Pose-only contact freezes deformation without cancelling a legal tangential
climb or turning its speed into free flight. Actual obstruction, imposed motion
and target loss still interrupt. That correction passed **2492 full-suite tests in 1627.776 s**,
including 24 new current-input methods. Sixteen complete API/CLI comparisons,
eighty observation/precision captures and numerical/order/hash controls pass.
Consequential concurrency changes are documented in
[action ownership](ACTION_OWNERSHIP.md) and [climbing](CLIMBING.md); original test
setups and all historical results are preserved.
[Response](PRINCIPAL_ENGINEERING_REVIEW_2026-11-03_RESPONSE.md) ·
[Evidence](results/principal-review-fixes-2026-11-03/README.md).
The Aim/confirmed-entry handoff is now sealed above. The six-kit/5v5 Goal remains
incomplete.

**Previous ability integration:** [3E5 charge/grapple/wall slams](CHARGE_GRAPPLE.md)
now uses owned swept boxes, life-bound ground motor bonuses, complete grab
Active and eight-second holding/Break. Real glancing/airborne grabs, first-body/
Block interception, speed expiry/reset, two-wall fracture and committed 700-base
victim damage execute through the common world. Source omissions use documented
600 DPS/Dd2; Db3/cooldown starts at charge Active. All 2425 full-suite tests pass
in 1508.383 s, and 77 focused methods pass in 95.419 s. Thirteen complete
API/CLI/hash/numerical controls and six unchanged previous contact traces pass.
[Evidence](results/charge-grapple/README.md).

The shared [knock timing correction](KNOCK_DELIVERY.md) snapshots the actual
pre-hit group/defenses and applies released forces after character damage but
before fatigue/new attachment. Both actual 1E5 and 3E5 holds keep the author's
summed-stat resistance through the very attack that exhausts control. Opposed
heavy punches remain additive with independent clocks. Frozen earlier inputs
retain their former force-phase policy.

The preceding [committed native receipts](CONTACT_EVENTS.md) pin lives, actions,
held groups and collider tags/revisions before control changes. Owned signals
retain their source; no subscriber adds no physical knot. Its 2384-test
checkpoint and six complete control captures remain historical evidence.
The [concurrent source record](SOURCE_UPDATES_2026-11-02.md) pins the 1E2 Aim
and 1E3 duplication revisions. Both Aim and the actual duplication field
are integrated and verified above; the portal pair remains unfinished.

**Previous verified integration:** [living-body contact](BODY_SUPPORT.md) feeds the
existing saved contact/distance paths, with native gravity/landings, pose
withdrawal, real hold/tether coupling and life/terrain removal. Coherent queries
during atomic path consumption and stationary-face tangency prevent intermediate
contact records and numerical corner impulses. The full 2200 ms crowded encounter
passes API/CLI/hash and numerical controls. All 2360 full-suite tests pass in
1418.168 s; six complete captures/controls and eighteen previous traces pass.
[Evidence](results/body-support/README.md).

**Latest correction:** [velocity-only spatial changes](SPATIAL_TRANSITIONS.md)
reuse current contact geometry without requiring a new empty placement. Actual
force expiry inside the prison now completes the1800ms encounter; relocation,
restoration and stale-plan checks remain strict. The selected living-body support
mode above extends the same solver with contact witnesses.
[Evidence](results/velocity-transitions/README.md).

**Earlier integration:** [1E3's physical prison](PRISON.md) forms a hollow
six-face 4000-HP/12s enclosure through actual utility contact. Shared solid hand
reach prevents close firing/swing origins from crossing thin walls. Ordinary
gun/Qard/heat, movement/jump/climb, holds, copied carriers and occupant revival
compose. Current contact rules distinguish pose obstruction from approaching
motion and bound rapid repeated restitution. Longer crowded continuations still
reached dynamic-support and velocity-only spatial-validation failures in that
checkpoint. Both now have shared corrections; final support regression status
is recorded in the new evidence package.
[Prison evidence](results/prison-cast/README.md).

The preceding [1E3 actual ice bomb](IMPACT_BINDINGS.md) uses
physical contact plus an independent 8 m/10 s lower-body binding burst. Intrinsic
throw output, shared defenses, real Block/terrain detonation, common Break,
native flight/holds/knocks and life retirement compose. 200 blunt contact damage
is a documented delegated value because no amount is authored; the burst adds
no HP damage. [Evidence](results/ice-bomb/README.md).

The appended [collision-source equilibrium rule](SOURCE_UPDATES_2026-11-02.md)
now runs in current defaults: live balance integration, concurrent crouch,
six-part prone geometry and paid Get Up share motion, contacts, effects and
lives. Actual Block counters supply ordinary falls; all six common Get Up
profiles and existing-kit interactions execute on that geometry.
[Decisions](EQUILIBRIUM.md) · [Evidence](results/equilibrium/README.md).

**Current integration:** [three 2000-HP walls](DESTRUCTIBLE_WALLS.md) now support
the author's damage families, direct/area Qard hits, continuous heat and shared
collision removal. Current collider version 2 adds object blast recipients;
saved version 1 traces retain their former behavior. Actual 3E5 charge now
uses the wall tag and the same object HP/removal lifecycle.
[1E1's actual ground chain](GROUND_CHAIN.md) now uses fixed surface constants
on the shared planner, source-independent attachment life and common Break.
Actual climb/anchor/beam destruction, held knocks and revival compose.
[Wall evidence](results/destructible-walls/README.md) ·
[Ground-chain evidence](results/ground-chain/README.md).

The preceding [3E5's authored chain](CHAIN_CAST.md) casts through
the common action/projectile pipeline: damage-free 30 m/s throw, paid phases,
moving 20 m flight limit, 15 s spatial binding and common Break. Released payload
snapshots, live endpoint generations, interception, actual holds/knocks and
ordinary death/revival compose. [Evidence](results/chain-cast/README.md).
The [persistent controller](PERSISTENT_DISTANCES.md) supplies certified paths,
independent knots, slack/inward/tangential motion and individual force expiry.

The current shared [saved polynomial body paths](BODY_PATHS.md) give motion
prediction and advancement one immutable reference prefix and one position
writer. Same-time status/driver changes, life, support, grapple groups and force
changes invalidate it; observations alone retain the saved polynomial. Actual
held-pair horizontal/upward knocks, climb/jump, firing, fields and bindings use
the common path. [Evidence](results/body-paths/README.md).
The later controller and actual chain use those prefixes for persistent curved
tether paths.

The preceding [joint radial/contact projection](TETHERS.md) adds optional
constraints to atomic spatial prepare/commit. It composes one-sided radial/
contact limits with actual grapple/bilateral constraints, checks exact rational
certificates and retains inspectable JSON records. Shared API probes cover real
movement, firing, holding and stale/life boundaries. **This is instantaneous;
persistent paths and the authored chain use the later shared backend.**
[Evidence](results/tether-projection/README.md).

Actual [shared binding/Break and 1E3 marking projectile](BINDINGS.md) retains:
real contacts add refreshed source/life-specific marks; three consume the pool
for an independent upper-body freeze. Common Break uses the primary maximum-HP
threshold and disorientation-paused 20/s filling, with separate escape work at
the bar cap. Actual cast/hold interruption, legal movement, Block/shield and
life handling use the common world. Primary 1E3 stats and common movement are
imported. [Evidence](results/binding-marks/README.md).

Actual [3E5 conditional ability 1](CONDITIONAL_MELEE.md) retains
alternating normal punches and upward counter, pinned branch data, motion-cause/
closing checks, deferred after-Active cooldown work and resisted ballistic group
launch. Hand/cost pinning, cancellation, pauses, death/restoration and existing
landing obligations use the shared world. [Evidence](results/conditional-melee/README.md).

Actual [3E5 heavy-punch knock/elasticity](KNOCK_DELIVERY.md) retains
real timed melee damage/statuses, summed-stat group resistance, additive finite
force components and 100% elastic contacts. Independent expiries, release,
source/recipient death and jump landing obligations use the shared world.
[Evidence](results/knock-delivery/README.md).

Actual [1E5/2E4 dashes](BODY_LAUNCHES.md) share body
launch/flight/landing, lower-body ownership, payment/cooldown and life handling.
Actual holds, independent attacks, contacts, beam/gun, climb and pause fields
compose on the common clock. [Evidence](results/body-dashes/README.md).

Actual 1E5 grab/owned holding retains physical contact,
complete grab Active, atomic hand transfer, 3 s constriction/tear and holding
effort on shared shield/HP/resource timelines. Real grabs use the persistent
group coordinator, including shared forces/gravity, individual contact penalties,
fatigue/expiry, death and actual revival. The author's summed-stat knockback
assessment applies to the resulting live groups.
[Rules](GRAPPLE_DELIVERY.md) · [Knockback](KNOCKBACK.md) ·
[Evidence](results/authored-grapple/README.md).
[Common Break](GRAPPLE_BREAK.md) now adds validated life-bound controls, a
half-open response window, fixed filling, earliest escape and phased actual-gain
penalties. Later heavy/upward knocks and charge/wall slams reuse those groups.
The [payment-boundary correction](results/payment-boundaries/README.md) now
cancels an unpaid owned action safely when concurrent effort exhausts its
capacity, preserving prior work, other owners and the authored payment anchor.
The overall Goal is active. All six existing creative kits have shared delivery
within the documented scope; remaining geometry and interaction coverage still
need verification.

| Area | Verified shared-engine support | Remaining boundary |
|---|---|---|
| Aim and physical release accuracy | Actual 1E2 160 ms owned toggle, hand/restriction/pace/life handling, deterministic release cones with source base/unaimed/O/running contributions, immutable per-life shot samples and copied receipts; schema-2 ordinary curved entries; actual ability4 uses that release pipeline | General unresolved grazing priorities, moving-target lead and advanced NPC behavior remain unfinished |
| Body-part damage and direct projectiles | Existing 1E2 ability4: source body600/head1500, intrinsic flat-U release components, direct HP impact, actual anatomical receiver selection, scripted part aim, default power for guard/material, travelled loss and simultaneous defenses; no unlisted stock | Fixed anatomical proxies; other abilities acquire no implicit regional multiplier |
| Equilibrium and Get Up | Source live-rate progress with O/U decay, partial recovery, six-part convex standing/crouch/prone proxies, accelerated centre/size queries, owned paid recovery, clearance/interruption, native forces and life-bound completion; all six profiles and actual Block-counter falls | Six-part convex proxies; broader articulation and final linked/turn interaction coverage remain unfinished |
| Fixed initial actor heading | Current finite-face mobile combat accepts explicit yaw; all six local body scales, standing/crouch/prone/Get Up, hands/Recovery, Block, owned attacks and dynamic planes use real frames; legacy inputs retain their branches | Native turns, owned contacts, fields, support, active links and prescribed climbing compose; final cross-kit coverage remains |
| Continuous angular query paths | Anchored constant-rate yaw, bounded rational degree selection, rotating/resizing local boxes and point derivatives; continuous box/box and curved-projectile queries with actual shape confirmation | Native ownership, fields, support, active links and prescribed climbing use the shared query paths; rotating environment geometry is outside current scope |
| Current moving combat | All roster creative abilities: 1E1 Qard/chain/leap/beam/launcher; all 1E2 active abilities, Aim/reload; 1E3 marking/ice/portals/prison/duplication; 2E4 thrust/venom/defenses/reactions/enhancements/revival; 1E5 arm attacks/grab/dash/passive/Ultimate; 3E5 punches/chain/leap/kick/charge; common movement and solid hand reach | Complete interaction coverage and reproducible 5v5 remain unfinished |
| Block and charges | 2E4 basic8 and3E5 basic8; attached800 HP/250 ms surfaces, held timing/status bonus, physical interception, simultaneous sharing, serial recharge with pauses/death and frozen sources | Personal-volume overflow proxy; broader linked/turn interaction coverage remains; frozen legacy profiles retain their earlier aliases |
| Dodge | Existing2E4 basic9; actual75/75 ms dip/return, Db3.5, independent four-charge stock, self targeting, shared pose/hands, native contact/control/life interruption and recharge pauses | Selected downward variant; general lateral alternatives are not assigned to this profile |
| Automatic combat reactions | Actual 2E4 ability 2: committed Block signals, causal waves, independent 500-damage line, statuses, one-charge 9 s refill/pauses/death, clipped HP/healing/revival credit; automatic definitions dispatch independently | Current authored counter trigger; blunt/2 cm-line/cover defaults are delegated |
| Melee and attached blades | Hand-origin timed capsule contact; real body/solid interception, simultaneous slash/shield/armor snapshots, bleed and attached/residual venom; moving attachments, live toxin resistance including 2E4 shield bonus; independent replacement items and owned grabs | Source-specific capsule/box proxies; broader turn/phase interaction coverage remains |
| Attack modifiers | Actual 2E4 next-thrust armor loss/shielding bypass and 1E5 passive double bleed/timed piercing, owned activations, immutable release snapshots, once-only consumption, finite budgets across intercepted layers, constrained proportional sharing, cooldown/expiry/death handling | Only the authored attack families acquire their declared modifiers; unrelated projectiles gain no implicit enhancement |
| World physics | Immutable integrated_v2 gravity/support, real removal/expiry/jump loss, reference-versus-pose contact classification and bounded repeated restitution; static-face ledges and finite-ground flight described in SUPPORT_DEPARTURE.md and FINITE_GROUND.md | Broader interaction coverage remains unfinished |
| Living-body support | Life-bound part witnesses, rooted/floating stacks with one gravity, native impacts/landings and owed effects, pose withdrawal, alternate parents, death/restoration and terrain loss; shared contacts, real grapples and tethers; coherent atomic queries and stable stationary-face tangency | No authored horizontal friction/carrying; angular support and active linked response compose; no universal convergence certificate is claimed |
| Saved body paths | One immutable polynomial reference prefix supplies prediction and advancement; separate pose deformation, owned precision, lease/life validation, exact rational JSON coefficients and frozen-input compatibility; live constrained prefixes use the same writer | Final cross-kit coverage remains; no universal temporal or rational-bit-growth bound is claimed |
| Finite distance planner and live controller | Certified moving/fixed endpoint interval bounds, joint relative/static contacts and grapples; live slack crossings and independent knots, separate ground/inertial state and per-force expiry; actual 3E5/1E1 chains and engineering API; independent analytic refinement case and numerical ten-body audits | No universal temporal accuracy, energy or rational-bit-growth claim; rotating environment geometry remains outside current scope |
| Body launches/dashes | Existing 1E5/2E4 dashes and 1E1/3E5 leaps, shared ballistic launch writer, independent body ownership, paid life-bound landing effects and actual group/terrain contacts; 3E5 descending foot kick has real power/knock/defenses | Source-specific trajectory/direction and downward-knock defaults are delegated; broader interaction coverage remains |
| Charge and owned moving contacts | Actual 3E5 Ultimate, saved-path body-part boxes, current-pose contacts, first interception, full grab tail/owned hold/Break, motor bonus expiry/reset, conditional tagged-wall fracture and immutable 700-base victim slams | Live owned yaw, angular support and active linked turning are extended above; delegated grab geometry/600 DPS/Dd2; untagged solids keep native response |
| Released knock/elasticity | Actual 3E5 heavy punch, upward counter and descending kick; pre-batch summed resistance, additive finite components, independent expiry, ballistic height/support, temporary elasticity and group/life handling | Horizontal duration, counter deflection and kick direction/contact proxy are documented delegated choices; native turns compose and broader interaction coverage remains |
| Conditional melee | Actual single 3E5 ability 1, b/c normal cycle and eligible a, pinned branch hand/damage/cost/timing/statuses, cause independent of landing obligation, private deferred counter clock with pauses/death/debt handling | Current source-specific predicate/cycle; hypothetical contextual examples are not invented abilities; other contextual kits unfinished |
| Radial/contact projection | Joint exact instantaneous velocity limits through atomic APIs; true grapple expansion, one-sided contact, exact certificate and JSON trace; independent oracle and up-to-ten-body audit | These APIs retain explicit replacement semantics; the separate live distance controller preserves forces/control for real chain motion |
| Binding and marks | Actual 1E3 marking/freeze and ice-bomb lower burst, 3E5 chain and 1E1 ground chain, source/life instances, fixed surface/collider lifetimes, spatial limits and common Break; paused filling, capped gains, independent teardown; real Block, death and revival handling | Physical prison and the actual allied portal pair are separate shared cast/transport systems; wider interaction coverage remains |
| Movement commands and external changes | One typed-intent dispatcher; motion/pose contact revalidation; atomic transitions; persistent grapple-group inputs/forces, shared gravity and simultaneous contact transmission | Ordinary motors retain scripted world directions; automatic steering and advanced policies remain deferred |
| Controlled actions | Declared hand/weapon/locomotion ownership; pinned component hands; complete grab tail and atomic handoff to a separate hold; individual restrictions; compatible body/right-arm/enhancement overlap; paid receipts and selective cancellation | Current authored action mappings and native heading ownership are integrated; final cross-kit coverage remains |
| Actor lives | Per-life controlled events/recipient attachments; immutable autonomous source life; shared restoration/credit windows; actual grab/hold, stream and effort retire together; actual revival cannot rejoin old control | Current delivered bindings, portals and other released sources retain their life contracts; broader interaction/geometry coverage remains |
| 2E4 revival | Actual automatic death trigger, 2000 ms generation-bound attempt, death-time eligible HP snapshot, maximum-HP clamp, finite three-charge stock and 65 s background cooldown; body occupancy failure and stale-attempt retirement | Charge/refill and retry gaps use explicit delegated rules in REVIVAL.md; healing has separate consumed funding |
| HP healing | Actual basic-10 passive at 20% of eligible HP; consumed 90%/8 s FIFO incoming-loss funding; one-time point entitlements and joint continuous HP/heal/death; full/dead excess discarded; stored nonlinear history and life-aware queries | Other authored healing deliveries/source filters and maiming cures unfinished |
| Effort/interruption categories | Intrinsic momentary releases; sustained gun control/recoil exemption; independent beam/mark activation; live intrinsic holding output U/4; one continuous writer adds squared sustained rates and fixed filling, caps/allocates gains, reanchors solo sprint; safe unpaid-phase cancellation; actual Break fixed filling/escape | Reviewed current phase mappings apply; no invented effort for summons, marks, passives or enhancements |
| Grapple motion and knock resistance | Actual 1E5 physical grab/hold and common Break; shared weighted drives/gravity, individual contact penalties and life/fatigue teardown; actual heavy-punch group knocks with summed-stat resistance and elasticity | Actual portal transport, active linked turns and prescribed climbing compose; broader interaction coverage remains |
| Physical projectiles | Independent identities, original source lives/power/accuracy/payloads, contact policies and owner clearance; actual 1E3 continuous-entry field, atomic symmetric split and inherited per-field lineage; current collider invalidation | Explicit numerical near-tangency guard; owner-contact remains an engineering capability after its former 2E4 source attack was removed |
| Segmented contact fields | Actual 1E2 fence: five independent 1500-HP panels, typed immunity, continuous body/pose contact, one electrical stream and B2 instance per field/body/life episode, common Break, gaps, destruction and restoration; source-independent lifetime | Independent fixed panels, axis-aligned or body-lateral oriented; body-permeable electrical screen is delegated |
| Fixed world entities | Compound HP/expiry/tags, independent blocking; three 2000-HP walls, real gun/punch/Qard impact and blast/continuous heat damage; typed constriction/tear object API, cover destruction, anchor/contact invalidation and support loss | No continuous or rotating platforms; typed constriction/tear object support is an API and adds no invented creature-to-wall ability |
| Climb | Approved range/path on active climbable single cuboids; angular contacts, compatible linked routes, pre-advance constraint interruption, native momentum, death/removal, raised support and subsequent jump | Constant approved routes remain explicit; arbitrary ledge grips/articulation are not invented |
| Stationary combat | 1E1 Qard/delayed blast/heat and 1E2 gun, simultaneous defense snapshots and per-loss shield recovery | Frozen definitions retain their explicit historical scope |
| Persistent effects | Actual bleed/heat/attached venom, impact gas, electrical fields, cooldown areas, marks and freezes; owned constriction shares shield/HP/healing/resource rules while keeping its own lifetime | Instantaneous grenade pulse follows explicit world cover; gas is unoccluded. Angular membership/cover is integrated; broader interaction coverage remains |
| Applied HP attribution | Actual HP receipts, proportional overkill, source/target life and action/projectile/effect attribution, immutable analytic/dense histories and actor-wide 8/10 s windows; healing and revival use actual HP; gross losses remain separate from recovery | Other authored recovery deliveries/source filters unfinished; outgoing friendly/self damage remains ineligible |
| Cooldowns | Remaining work, independent pauses, real marking, exact entry/exit/expiry, ready activation in fields; ordinary clocks stop at death; registered revival background clock continues and reconciles living pause membership at birth | Serial stock, weapon variants and released field clocks are integrated; current geometry boundaries still limit encounters |
| Shield recovery flow | Analytic root/affine work/rate plans and bidirectional zero clipping; joint heat/constriction stock, proportional zero-stock interception, warm body memory and delayed recycled losses; owner/history-bound prefixes | Current coupled heat uses k=2 and positive delay; unselected thermal parameter families retain their explicit numerical scope |
| Six kits | All existing roster creative abilities now have actual shared delivery within documented scope, including launcher, portals, leaps and falling kick; common actions apply to all six | Complete cross-kit coverage and reproducible 5v5 remain unfinished |
| Numerical initialization | Direct construction, subclass load hooks and public execution use declared precision and ROUND_HALF_EVEN; caller context/traps/flags are restored on success/failure | New constructor/rounding and failure tests pass; final whole-engine gates are recorded in PROGRESS.md |

**Earlier force-expiry verification:** 2316 full-suite tests pass in 782.867 s; nine new
velocity-transition checks and 35 existing spatial checks pass. The complete
force-expiry cast now finishes; prior fifteen prison captures replay unchanged.
Three controlled traces independently compare physical position/velocity and
resources. [Current evidence](results/velocity-transitions/README.md).

**Prison verification:** 2307 full-suite tests pass in 674.831 s; 69 focused checks
pass in 60.172 s; 15 complete ordinary
API/CLI captures and five hash/five combined numerical/observation/order controls
pass. Previous twelve ice-bomb/four wall captures replay unchanged. Complete
full-suite/reproduction/integrity results are indexed in
[the new checkpoint](results/prison-cast/README.md). Concrete support/force-expiry
failures stay documented; the Goal is incomplete.

**Previous ice-bomb verification:** 2237 full-suite tests pass in 603.380 s; 30 new live
methods pass in 31.480 s, and96 combined current-rule checks pass in 101.225 s.
Twelve ordinary complete API/CLI captures and fresh reproduction pass, with
five complete hash-seed and five combined precision/observation/order controls.
HP/life, utility isolation, independent binding/Break/expiry and actual paired
knock audits pass. Prior equilibrium and ground-chain captures replay unchanged.
All 4523 earlier result files and 14 primary ODTs are preserved; historical
manifests are not refreshed. [Checkpoint gate](results/ice-bomb/verify_integrity.py).
The complete six-kit/5v5 Goal remains unfinished.

**Previous chain checkpoint verification:** 2096 full-suite tests pass in 472.829 s; all 35 focused
checks pass in 20.208 s (30 live/five pure). Ten complete ordinary API/CLI
captures and fresh reproduction pass, with three complete hash-seed and five
combined precision/observation/order controls. Real chain/hold/knock, Break,
interception, distant misses and actual death/revival compose. Earlier distance
and body-path packages and the review-correction matrix replay unchanged.
All 4179 prior result files and primary ODTs are unchanged. Only 3E5's authored
ability 2/metadata and its action mapping are added; existing stats and the other
five profiles stay unchanged. [Integrity gate](results/chain-cast/verify_integrity.py).
The overall six-kit/5v5 Goal remains active and incomplete.

[Current chain evidence](results/chain-cast/README.md) ·
[Current full tests](results/chain-cast/full-tests.txt) ·
[Shared body-path evidence](results/body-paths/README.md) ·
[Previous projection evidence](results/tether-projection/README.md) ·
[Previous binding evidence](results/binding-marks/README.md) ·
[Previous binding tests](results/binding-marks/full-tests.txt) ·
[Previous conditional evidence](results/conditional-melee/README.md) ·
[Previous conditional tests](results/conditional-melee/full-tests.txt) ·
[Previous knock evidence](results/knock-delivery/README.md) ·
[Previous knock tests](results/knock-delivery/full-tests.txt) ·
[Previous dash evidence](results/body-dashes/README.md) ·
[Previous dash tests](results/body-dashes/full-tests.txt) ·
[Previous Break evidence](results/grapple-break/README.md) ·
[Previous Break tests](results/grapple-break/full-tests.txt) ·
[Current payment evidence](results/payment-boundaries/README.md) ·
[Payment prerequisite tests](results/payment-boundaries/full-tests.txt) ·
[Actual grab/holding evidence](results/authored-grapple/README.md) ·
[Previous grab/holding tests](results/authored-grapple/full-tests.txt) ·
[Current linked-motion evidence](results/grapple-motion/README.md) ·
[Full tests](results/grapple-motion/full-tests.txt) ·
[Atomic spatial evidence](results/spatial-transitions/README.md) ·
[Component melee](results/component-melee/README.md) ·
[Modifiers](results/attack-modifiers/README.md) ·
[Reactions](results/combat-reactions/README.md) ·
[Block](results/block-defenses/README.md) ·
[Healing](results/hp-recovery/README.md) ·
[Revival](results/death-revival/README.md) ·
[Melee](results/melee-venom/README.md) ·
[Lives](results/life-generations/README.md) ·
[Effort](results/phase-effort/REPORT.md) ·
[Review corrections](results/principal-review-corrections-2026-10-29/README.md).

F1–F5 are corrected. Historical artifacts remain unchanged: their initial-hand
snapshot bug, one new blocked-intent diagnostic and insignificant Decimal
format changes are explained by the
[19-case comparison](results/projectile-entities/historical-comparisons.txt).
One additional reporting correction removes 14 obsolete pending stop events
for already collided flights in the old moving-gun duel.
Old scripts that demand byte-identical current output can therefore fail.
Use the [current comparison script](results/projectile-entities/compare_historical.py)
to verify the documented corrections rather than rewriting old evidence.

The A1 foundation is implemented; its earlier restriction demonstrations use
pre-applied conditions and do not claim 1E3 ability delivery. Current inputs opt
into declared ownership; frozen inputs retain explicit exclusive scheduling.
[ACTION_OWNERSHIP.md](ACTION_OWNERSHIP.md) records consequential choices.
The subsequent [binding increment](BINDINGS.md) delivers 1E3's real marking
projectile without claiming its other source casts.

The first A2 projectile increment is implemented. Internal IDs are independent
in all physical-flight scopes; current inputs expose entity traces while frozen
inputs retain a presentation adapter. Copy/owner probes exercise production
physics and APIs without claiming 1E3's cast. The source revision removed the
former 2E4 owner-contact attack; retained probes are engineering capabilities.
[PROJECTILE_ENTITIES.md](PROJECTILE_ENTITIES.md) records the boundaries.

A2's fixed-world foundation is now verified: compound HP/lifetime, independent
blocking, contact invalidation and support loss. The hollow-shell scene uses
initial geometry and does not cast 1E3's prison. Construct damage grants no
character healing/revival credit. [WORLD_COLLIDERS.md](WORLD_COLLIDERS.md)
records delegated choices and the continuous-area boundary.

A3's first increment is verified: independent heat volumes, typed bleeding and
thermal tracks, moving entry/exit/re-entry and continuous cover damage. The
existing beam casts alongside body movement and survives caster death.
[SPATIAL_EFFECTS.md](SPATIAL_EFFECTS.md) records source and delegated rules.

The [recovery-flow prerequisite](RECOVERY_FLOW.md) now feeds verified
[continuous heat/shield coupling](HEAT_SHIELD_COUPLING.md): net stock balance,
zero-stock absorption, independent incident/body memory, warm reformation and
delayed recycled losses. Conditional dense plans preserve observation-independent
prefixes; current inputs no longer reject this overlap. Frozen definitions retain
their historical adapter/guard.
[Cooldown work and the existing 1E2 pause area](COOLDOWN_PAUSES.md) now execute
on this same coordinator; overlapping sources compose without pausing physical
phases/effect lifetimes or shield recovery.
[Applied HP history](DAMAGE_LEDGER.md) now records actual damage and clips
rolling windows through the original analytic/dense curves. It allocates
simultaneous overkill and preserves released-effect ownership after caster death;
it does not pay healing. [Phase-specific effort](ABILITY_EFFORT.md) now aligns
intrinsic Qard and sustained gun control with the reviewed source labels while
preserving independent effects. [Life/event generations](LIFE_CYCLES.md) and
restoration are now integrated, including recipient retirement, surviving source
identity, body/support, cooldown/shield debt and rolling history.
[2E4 thrust/venom/replacement-blade delivery](MELEE_VENOM.md) is now integrated,
including real gunfire, posture, shield regeneration and life interactions.
[Actual revival](REVIVAL.md) now supplies the death trigger, timing, finite
charges, background cooldown and payout. [Consumed healing allowance and
passive HP/heal flow](HEALING.md) now execute with continuous death timing.
Layered Block interception/HP/resistances, rechargeable charges and 2E4's
automatic counter and actual 2E4 enhancements now execute on this timeline.
1E5's actual component melee/passive/Ultimate now use the same timeline.
Atomic spatial transitions and persistent group trajectories are now verified.
Actual grab/owned holding and common Break now execute with phase resources,
shared damage/effort and life teardown. Actual dashes, heavy/upward knocks and
3E5 charge/holding now extend that coordinator. Other kit deliveries remain. The older
restoration API probe retains its foundation scope.
Reuse this
coordinator and its contact mathematics; A3 and full kits remain incomplete.
Advanced NPC intelligence, learning and mass experiments remain deferred.

Source/decision navigation: [confirmed preferences](DESIGN_PREFERENCES.md),
[author effort/dyspnea policy](DYSPNEA_POLICY.md),
[effort and interruption categories](ABILITY_EFFORT.md),
[six-character inventory](ROSTER.md), [development path](ROADMAP.md),
[action ownership](ACTION_OWNERSHIP.md),
[projectile entities](PROJECTILE_ENTITIES.md),
[world colliders](WORLD_COLLIDERS.md),
[persistent effects](SPATIAL_EFFECTS.md),
[recovery flow](RECOVERY_FLOW.md),
[heat/shield coupling](HEAT_SHIELD_COUPLING.md),
[cooldown work/pause areas](COOLDOWN_PAUSES.md),
[applied HP history](DAMAGE_LEDGER.md),
[actor lives](LIFE_CYCLES.md),
[actual revival](REVIVAL.md),
[passive healing and consumed allowance](HEALING.md),
[Block and rechargeable stock](BLOCKING.md),
[causal reactions and automatic counter](COMBAT_REACTIONS.md),
[attack enhancements and release snapshots](ATTACK_MODIFIERS.md),
[component melee and 1E5](COMPONENT_MELEE.md),
[atomic spatial changes and velocity projection](SPATIAL_TRANSITIONS.md),
[persistent grapple-group motion](LINKED_MOTION.md),
[summed-stat knockback and direction rules](KNOCKBACK.md),
[melee/venom/replacement blades](MELEE_VENOM.md),
[movement rules](MOVING_COMBAT.md), [climb](CLIMBING.md),
[collision](COLLISIONS.md), [jump](JUMPING.md),
[posture/sprint](CROUCH_SPRINT.md), [chronological handoff](PROGRESS.md).
