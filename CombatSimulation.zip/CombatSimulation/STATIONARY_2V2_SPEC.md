# Earlier point-based stationary 2v2 specification

This file records the earlier controlled point-eligibility experiment and its
saved assumptions. The current body-collision model is specified in
[HITBOXES.md](HITBOXES.md). Later author clarifications require Qard to collide
before creating a mark, exclude dead bodies from collisions, and use hand
origins/physical projectile radii. The old trace remains a historical comparison;
its location-impact assumptions do not define the current collision model.

Status: implemented and run on 2026-10-25. The shared stationary team scope
executes this 30-second encounter with hand Recovery, dyspnea, death, area
eligibility and per-loss shield regeneration. Confirmed rules are separate from
scenario defaults. See [results](results/stationary-2v2/REPORT.md).
Primary sources remain the root mechanics/character ODTs and author clarifications.

## Confirmed encounter setup

| Instance | Team | Character | Stationary position (x, y), metres | Starting current regenerative shield |
|---|---|---|---|---:|
| A_1E1 | A | 1E1 | (0, 0) | 1000 |
| A_1E2 | A | 1E2 | (0, 10) | 1000 |
| B_1E1 | B | 1E1 | (30, 0) | Not overridden by the request |
| B_1E2 | B | 1E2 | (30, 4) | Not overridden by the request |

- Requested battle horizon: 30000 ms.
- HP reaching zero means the character dies. This replaces the earlier
  observation-only interpretation for this encounter. Controlled actions cancel;
  released and deployed effects persist under the rules below.
- Use currently supported abilities; a ready higher-damage ability has priority.
- Include dyspnea.
- 1E2 reloads when out of ammunition.

## Confirmed author clarifications

- **Targets:** select the nearest living enemy. For the supplied starting
  positions, A_1E1 selects B_1E1, A_1E2 selects B_1E2, and both B actors select
  A_1E1. No equally near enemies occur in this layout; other layouts with ties
  require a selection rule rather than an implicit instance-name priority.
- **Dyspnea values:** listed action values are Db. Projectile Db=2; gunfire
  Db=2, paid once per firing immediately after Active; reload Db=0.5. Beam is
  exempt from dyspnea, rather than evaluated as `(0 + D/100)^2`. The author's
  tentative intention for other summons is not a confirmed general rule.
- **Dyspnea check/payment timing:** Qard and gunfire calculate/check/pay at the
  end of firing. Reload calculates/checks/pays at the start of Active. Gunfire
  has one action payment per firing, not a continuous recoil-control gain.
  Death cancelling an action before its payment incurs no cost. This does not
  establish a refund of a payment made before death.
- **Death:** all actions still controlled/performed by the dying character are
  cancelled. Already released projectiles, applied bleeding, deployed beams,
  and other existing summons are not cancelled by their source's death.
- **Simultaneous impacts:** each hit uses the defenses from before the attacks.
  For total raw incoming damage T and current shield S, when T>S each hit with
  raw damage d absorbs `d*S/T` shield and leaves `d*(T-S)/T` pre-mitigation
  damage for its HP formula. With sufficient shield every hit is absorbed.
  No rule for hits tied to phase completion is implied by this allocation.
- **Geometry:** retain confirmed hits and use position centres with inclusive
  area-radius boundaries. Team B's exact 4 m separation includes both actors
  in a delayed blast centred on either actor; the 7 m beam also includes both.
  This controlled geometry does not define a general hitbox/accuracy model.
- **Physical Recovery:** the author supplied initial hand positions and
  start/end poses for projectile, beam, gunfire, and reload in the primary
  character documents. Calculate each required hand's Recovery individually;
  the movements overlap, so the total duration is the longest individual time.
  Recovery scheduling is enforced before Gathering in the stationary team scope.

### Imported hand-pose data

Both characters have Recovery 200 ms/m and initial left/right hand positions
(-0.20, 0.15, -0.1)/(0.20, 0.15, -0.1). Coordinates are metres relative to body
centre, x right, y forward, z up, as defined by the explicit projectile example.

| Character/action | Required hand(s) | Start and end positions |
|---|---|---|
| 1E1 projectile | Right | (0.1, 0.4, 0.18) |
| 1E1 beam | Right | (0.30, 0.15, 0.45) |
| 1E2 gunfire | Left and right | Left (0, 0.30, 0.15); right (0.05, 0.25, 0.1) |
| 1E2 reload | Right | Start (0.15, -0.25, -0.2); end (0.05, 0.25, 0.1) |

These values and confirmed dyspnea metadata are recorded in
`data/characters.json` and executed by the shared stationary team scope.

The request changes team A's starting current shield, not its documented maximum
capacity or regeneration formula. Under the existing confirmed history rule,
initially missing shield receives no invented prebattle loss timestamps. Only
observed losses have known regeneration eligibility unless the author supplies
additional history.

## Scenario choices and defaults

- Use the shared engine's existing ability subset: 1E1 ability 1 (Qard projectile
  and delayed blast), 1E1 ability 4 (independent heat beam), and 1E2 ability 1
  (gunfire), with reload. The separately scoped Ultimate runner is not yet shared.
- Interpret the requested damage priority as beam before projectile for 1E1.
  This is a fixed priority, not an implemented dynamic damage prediction.
- Retain canonical full HP/armor, full magazines, ready abilities, zero starting
  disorientation/instability and dyspnea, and 4000 starting shield for team B.
- Start action selection at time zero. Position-derived projectile distances
  should use the previously confirmed straight-line convention.

These are reproducible scenario choices; they do not define general tactical behavior.

## Confirmed final boundary clarifications

- **Exact ties:** Gathering completion/Active start takes effect before a hit at
  that identical timestamp. A due projectile releases before a simultaneous
  lethal incoming hit. The shared team queue drains due phase events before
  resolving the simultaneous incoming-hit batch, then selects new actions.
- **Target death during preparation:** finish the current attack toward its
  original location. The next action selects the nearest living enemy. A Qard
  projectile arriving at a dead target's location still schedules its delayed
  blast there; live area recipients are determined at blast time.

## Integrated implementation

The existing `SharedEncounter` owns one queue and common states. Modular team
rules in `combat_sim/team_rules.py` use the same continuous damage integrals,
heat transitions, status formulas and replaceable priority policy. The earlier
controlled duel's complete saved trace is preserved under its original scope.

- Per-instance stationary centres determine target selection, distance falloff,
  projectile travel and inclusive area recipients. Friendly fire remains on.
- Individual hand movements overlap. Gathering reads current disorientation
  after Recovery completes; an incoming hit during Recovery does not insert a
  Gathering phase until that transition. End poses update after Active.
- The existing beam cooldown anchor remains the activation request (selection),
  including the newly scheduled Recovery before Gathering.
- The policy forecasts whether an action's cost will fit, waiting for recovery
  when needed; the authoritative check/payment occurs at the authored event.
  This avoids initiating a known unaffordable action. Beam remains exempt.
- Simultaneous hits apply each formula with common pre-hit armor. Status values
  are each mitigated separately, then added as one simultaneous change. Shield
  absorption and HP/armor losses are applied once to the target state; no
  per-attacker overkill credit is invented.
- Death cancels Recovery/Gathering/Active/reload and future selections. Released
  projectiles, delayed blasts, beams and bleeds continue independently. Dead
  recipients leave live combat; their final resources retain the death state.
- Continuous HP zero is located between scheduled events. Observation continues
  to the requested 30000 ms after deaths or team elimination.
- Shield recovery preserves point loss timestamps and continuous heat-loss
  distributions, shifted by the 20-second delay. Eligible amounts share one
  work-conserving 400 HP/s rate, including when eligibility accrues continuously.

## Boundaries

No movement, hitboxes, accuracy/cover, revival, other kits or general interruption
system is claimed. Other layouts with exactly tied nearest enemies are rejected
until a selection rule is supplied. Shield regeneration overlapping ongoing heat
is rejected pending an authored heat re-entry/exposure rule; this encounter does
not exercise that overlap. Pending effects and source histories remain inspectable.

## Verified foundations

- `combat_sim/stationary_geometry.py`: exact squared-distance selection and
  inclusive area membership, with fixed-precision distance evaluation for travel.
- `combat_sim/mechanics/shield.py`: proportional simultaneous shield allocation.
- `combat_sim/mechanics/simultaneous.py`: slash/Qard per-hit formulas evaluated
  against one common pre-hit armor snapshot and allocated shield shares.
- `tests/test_stationary_foundations.py`: 17 isolated tests cover the supplied
  initial targets, deaths in target selection, exact radius boundaries, shield
  conservation, mixed damage, and permutation-independent impact calculations.
- `combat_sim/mechanics/dyspnea.py`: the phase-payment helper applies recorded
  costs at their authored events, including capacity rejection, the existing
  maximum trigger, beam exemption, and cancellation before payment. It does not
  itself schedule actions; the team controller invokes it at the authored phases.
- `tests/test_action_dyspnea_phases.py`: seven focused tests verify those payment
  events and exemptions. Earlier foundation stages passed 382 and 389 tests.
- `tests/test_team_recovery_and_shield.py`: 11 individual Recovery/delayed-supply tests.
- `tests/test_stationary_2v2.py`: 21 integration tests cover deaths, exact ties,
  targeting, areas, payments, conservation and numerical invariance.
- The complete suite passes **421 tests**. An 80-digit evaluation, 137 ms
  observations and no periodic observations preserve action cadence and agree
  within 1e-20 in checked final states, death times and total regeneration.
- [Frozen replay and evidence](results/stationary-2v2/REPORT.md) preserve the
  complete scenario, code/data/tests, primary documents, traces and hashes.
