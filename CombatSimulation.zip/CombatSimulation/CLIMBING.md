# Climbable block and Active-start eligibility

**Angular/linked integration verified, 2026-11-14:** the delegated control
rule preserves both the approved constant-speed route and weighted grapple
movement. Compatible prescribed routes can remain active together. If actual
shared motion redirects a route, that climb ends before consuming a future
interval, keeps paid effects and its own momentum behind the group projection,
then uses native physics. It does not automatically detach the hold, slow the
path clock, regrip or complete at an unreached destination. Same-time control
starts settle before physical vertical synchronization; all-climbing compatible
groups retain their prescribed acceleration. Heading remains independent.

An angular impact can end heading while a tangent reference path continues.
Collision statuses still apply. An unchanged upward prescribed velocity remains
controlled rather than becoming a new ballistic launch; actual redirected
velocity, loss of attachment, death and real obstruction retain interruption.
The real taut case also corrected missing grounded gravity reaction and a
fictitious midpoint hop. All3344 methods and17 complete capture controls pass;
59 prior captures retain current contracts with reviewed output differences.
The400ms taut case remains expensive despite completing. [Evidence and limits](results/linked-climb/README.md).
Earlier dated boundaries below are historical.

**Contact classification correction, 2026-11-03:** the November review's N2
identified pose-only wall contact cancelling a tangential climb before the
posture handler froze deformation. Movement-intent and climb handlers now honor
the existing `pose_only` classification: keep the climb/intent and forward the
contact to the pose-freeze handler. No translation impulse or conversion of
climb speed into free flight occurs. A true translation obstruction, imposed
motion, target removal or lost attachment still interrupts normally.
Current-input tests exercise x=4.59/4.589998 wall tangency, a real impact just
before Active, a roof, target expiry and forced motion. This corrects handler
consistency; entry range, path, geometry, tolerances and action costs are unchanged.
[Review](PRINCIPAL_ENGINEERING_REVIEW_2026-11-03.md) ·
[Evidence](results/principal-review-fixes-2026-11-03/README.md).

**Persistent-motion boundary, 2026-11-01:** [linked-group forces](LINKED_MOTION.md)
now propagate through the shared spatial interface. Prescribed climb actions
remain incompatible with the current rigid velocity-group foundation: interrupt
the pending/Active climb before linking, and keep linked climb traversal guarded
until the actual cast supplies its traversal/release rules. This is an unfinished
integration boundary, not an additional author restriction on future abilities.

**2026-11-01 spatial integration:** validated external changes now cancel body
control through [one atomic transition](SPATIAL_TRANSITIONS.md). An active
climber keeps its new reference and instantaneous velocity under gravity,
without path rewind or completion. A no-op or rejected multi-body update does
not interrupt it. Successful climbing consumes imposed ground motion; failed
entry retains it. See [ordinary and labelled probe evidence](results/spatial-transitions/README.md).

Current status: integrated with shared moving gun combat, including costs,
statuses, contacts, imposed-displacement interruption, live registered targets,
support and death. Earlier sections below
describe the preserved geometry-only checkpoint; the combat extension follows.

**Author clarification, 2026-10-29:** imposed displacement interrupts climbing;
being removed from the climbable object's required reach cannot leave the old
climb running. The approved path must not pull the character back or complete
after attachment is lost. The original once-at-Active-start test below is the
entry gate, not immunity to displacement during Active.

Author-confirmed rules, 2026-10-25:

- **cube_1**, centred at (6,0), is the one climbable block. Its top is at
  z=1.8 m. Cube_2 at (2,15) and cube_3 at (15,15) remain non-climbable.
- Range is the shortest **3D distance from character body origin to block
  surface**, inclusive of exactly **0.5 m**. It is not a hand/feet/body-surface gap.
- Entry range is checked **once, at Active start**. Being in range at request time
  does not guarantee a climb; being out of range at request time does not
  prevent a request from proceeding through Gathering.
- Walking/running **continues during Gathering**, with ordinary physical
  contact handling. A contact that removes ground movement does not itself
  cancel the pending climb's Gathering.
- On success, the approved climb path replaces ordinary movement: vertically
  until feet reach top height, then horizontally to the top centre, finishing
  standing. Path speed is constant during the **300 ms Active**; segment
  times are proportional to segment lengths.
- On a failed Active-start range check, climbing does not start and movement
  continues. Collision occurs **only on actual body contact**, not merely
  because range failed. The failed request does not automatically retry later.

The root 1E1/1E2 basic ability 4 specifies Gathering 150 ms, Active 300 ms,
self disorientation 80, self instability 250 and listed dyspnea 3.5.
Running's established Gathering modifier makes base Gathering 180 ms when
requested while running. [data/movement/climb.json](data/movement/climb.json)
records the author clarifications and copied ability values.

The geometry/timing test still excludes actual status application and dyspnea
payments by author choice. Collision-disorientation effects on Gathering are
not claimed by this bounded test.

## Shared-engine demonstrations

```sh
python3 -B -m combat_sim run scenarios/scripted_climb_geometry.json --summary-only
python3 -B -m combat_sim run scenarios/scripted_moving_climb_geometry.json --summary-only
```

Standing case: A starts at x=4.6, exactly 0.5 m from cube_1's x=5.1 surface.
Requested at 0 ms, Active starts at 150 ms. The 3.2 m path rises 1.8 m and
moves horizontally 1.4 m, at 10⅔ m/s. Feet reach top height at 318.75 ms;
standing at top centre completes at 450 ms. B's nearby cube_2 request fails
because that block is not climbable.

Moving case: A starts at x=4 and walks at 2 m/s after its 60 ms start transition.
It requests climb at 200 ms, when origin x=4.34 is still 0.76 m from the face.
Movement continues; at Active start, 350 ms, origin x=4.64 is now 0.46 m away.
The check succeeds and A finishes climbing at 650 ms.

B starts at x=7.1 and walks away. At its 100 ms request it is in range, but at
250 ms Active start its origin is x=7.54, 0.64 m from the right surface. The
check fails, movement continues, and no collision is invented. At 900 ms A
stands at (6,0) on the block; B is still walking at x=8.84.

## Geometry, support and verification

The approved origin is 0.875 m above the feet. On top, its z is 2.675 m,
feet z=1.8 m. The block remains solid. Six body cuboids follow the path and
fit above its top. Raised support persists, including a subsequent stationary
jump and landing back on the same top.

Nine pure climb tests and twenty-one shared climb tests cover the distance,
constant-speed path, Active-start gate, both directions of range change,
running Gathering, contact before Active, no late automatic retry, actual
collision after failure, support and earlier stopping traces unchanged.
The complete suite passes **638 tests**.

[Saved moving/standing results](results/climbing-active-start/REPORT.md).

## Historical geometry-only boundaries

The current shared geometry scope retains its temporary contact stop and
excludes effects. New directional collision response calculations are tested
separately in [COLLISIONS.md](COLLISIONS.md); full timeline/status integration
and edge/corner handling remain pending. A blocked climb path and leaving a
raised support require defined responses and are explicitly unsupported.
No collision penalty or stopping slide is invented merely for a failed climb.

## Ongoing attachment and movement review corrections, 2026-10-29

These are delegated engineering choices implementing the author's displacement
clarification and the [follow-up review](PRINCIPAL_ENGINEERING_REVIEW_2026-10-29.md):

- The approved path maintains attachment while it lifts the feet and crosses
  onto the top. Repeating the entry origin-radius test at every instant would
  wrongly cancel every ordinary climb: on top the origin is 0.875 m above the
  surface, exceeding the 0.5 m entry radius. Instead, an imposed position or
  physical-velocity override preempts the prescribed path, including a shift
  still inside entry reach. No automatic replan or regrip is inferred.
- Preserve the actual displaced position and supplied physical velocity; if no
  replacement velocity is supplied, retain the current path momentum. End only
  the owned climb, invalidate its remaining phases/corner, retain paid dyspnea
  and self statuses, then use ordinary gravity and actual contacts. This is not
  a basic jump and adds no jump payment or jump-specific landing penalties.
  Damage/status changes without displacement do not by themselves break attachment.
  Released shots, bleeds, beams and eligible independent hand actions survive.
- A later explicit climb may succeed after its normal prerequisites. Standing
  and sprint-exit prerequisites consult the same live collider interface as
  the request and Active-start checks. This includes registered single-cuboid
  platforms, not just the initial terrain list. Blocked standing rejects the
  parent intent once. Removal/expiry invalidates the owned climb; an invalid
  target/posture/pace cannot pay or start a path at Active.
- Climb geometry writes use `set_body_reference`: horizontal placement, upright
  reference, transformed body origin and collision cuboids change together.
  A recentered crouched origin is never used as an upright climb frame. Commit
  activation before publishing its start and refreshing dependent views.
- Computed contacts within `1e-24 ms` of a known kinematic/scheduled boundary
  use that boundary's phases-first ordering. Contact predictions depend on both
  participants' motion and pose. A changed dependency triggers a fresh touching
  and closing-motion check **before** interruption, statuses or velocity removal.
  Starting a vertical climb can therefore supersede an old inward wall contact;
  a real ceiling/body obstruction still interrupts and preserves real momentum.
  [Shared motion rules](MOVING_COMBAT.md) record the numerical resolutions.

The 24 displacement tests and 14 movement-boundary/registry tests exercise the
shared engine, including actual projectiles, heat membership, queued movement,
partial/blocked posture, sprint exit, expiry, obstruction and selective ownership.
Explicit displacement fixtures are engineering probes for future authored force
delivery; they grant no character a new ability. At that checkpoint coupled/
linked motion was unfinished. [The persistent foundation](LINKED_MOTION.md) now
works; moving supports, ledge traversal and remaining cast delivery are unfinished.
[Verification and reproduction](results/principal-review-corrections-2026-10-29/README.md).

## Shared combat extension, 2026-10-28

[combat_climb.json](data/movement/combat_climb.json) now selects the combat
rules independently of the geometry-only file. The API accepts it as
`climb_definition`. The current CLI world loads its action data before execution;
`--combat-climb` selects the file. Commands carry a target object identity and
use the same iterative dispatcher as other movement.

Primary-source audit: 1E1 paragraphs 194–201 and 1E2 paragraphs 210–217 contain
the listed timing, 80/250 self effects and 3.5 dyspnea (zero-based indices).
Neither supplies climb hand poses. The following are delegated engineering
choices, distinct from the author-confirmed path/range rules above:

- Retain current hands without inventing Recovery motion. Request Gathering
  uses the existing running factor and current/incoming O. Physical contact
  during Gathering can extend it without canceling the pending climb.
- Check capacity before selection and at Active start. Pay `Da=(3.5+D/100)^2`
  and apply self 80 O / 250 U only after successful range eligibility; from
  D=0 the payment is 12.25. Existing running modifiers apply to self effects.
  Failed targets/range/capacity do not fabricate payment or collision and do not
  automatically retry. Maximum-dyspnea triggering retains its normal rule.
- Climb starts grounded and standing. Crouched requests stage the existing
  stand action; sprinting requests stage the existing run exit. A rejected or
  physically blocked prerequisite finishes the parent intent once. Later
  explicit commands may retry. Airborne ground intents wait for landing.
- Successful Active replaces ordinary translation with the approved constant
  speed path for 300 ms. U does not subtract from that prescribed speed again.
  No continuous climb cost or new hand motion is added. Active already blocks
  resource recovery. Current declared ownership assigns climb locomotion and
  hand resources, so conflicting weapons wait; already released shots/effects
  persist. This explicit requirement also preserves the frozen exclusive input's
  scheduling without prohibiting independent future abilities globally.
- Every path segment is checked against current bodies, terrain and projectiles.
  Obstruction interrupts the path, keeps paid cost/statuses, projects velocity
  through normal collision response and then uses gravity. It does not become
  a paid basic jump or acquire jump landing self penalties. A ceiling can
  interrupt ascent; another character on top can interrupt crossing. No path
  teleport, obstruction bypass or automatic completion is allowed.
- A corner splits the common timeline analytically. Contact exactly at a bend
  uses the outgoing velocity; an exact ceiling fit is allowed. Completion
  establishes support on the cube at feet z=1.8 and upright origin z=2.675.
  Subsequent jump/landing uses that real support. Death freezes the reached
  body and invalidates later phases through existing action revisions.

The geometry model and root terrain remain unchanged. Climbing reuses
`ClimbPath`, swept contacts and the existing coordinator. Static-support landing
now removes a tiny root-rounding remainder by snapping to the actual top plane.
There is no general edge/fall system yet: walking off raised support, finite
ground departure and standing on another body remain guarded. Other kits and
moving areas remain unfinished.

Twenty-two focused shared tests plus real gunfire/obstruction demonstrations
verify these rules, with 50/80-digit and observation controls.
[Saved scenarios, complete traces and CLI replay](results/climb-combat/REPORT.md).
The [current index](ENGINE_STATUS.md) and [review response](PRINCIPAL_ENGINEERING_REVIEW_RESPONSE.md)
cover the simultaneous foundational corrections.

Subsequent [action ownership](ACTION_OWNERSHIP.md) keeps that climb requirement
explicit. A stop queued during climb waits until the owned path completes;
upper/lower restrictions cancel the affected climb through its existing
interruption/flight response. Phase and corner events use action identity and
revision so cancellation cannot complete a stale path. The four saved climb
traces still replay exactly with their frozen definitions. Later collider,
[typed heat-volume](SPATIAL_EFFECTS.md), [recovery-flow](RECOVERY_FLOW.md),
[heat/shield coupling](HEAT_SHIELD_COUPLING.md), [pause](COOLDOWN_PAUSES.md) and
[attribution](DAMAGE_LEDGER.md) increments reuse this coordinator; the
[current index](ENGINE_STATUS.md) tracks the latest full-suite verification.
[Ownership evidence](results/action-ownership/REPORT.md) ·
[Projectile evidence](results/projectile-entities/REPORT.md).

Current world entities extend the approved path to active climbable single
cuboids, with availability checked at Active and completion. Target removal or
expiry cancels preparation or interrupts the active path; support disappearance
causes a real fall while independent weapons continue. Compound landing uses its
contacted part's height. The integrated airborne validator now owns support
checks, allowing a jump to leave raised support; ordinary grounded ledge departure
is still guarded. See [world collider rules](WORLD_COLLIDERS.md) and
[four API/CLI encounters](results/world-colliders/REPORT.md).
