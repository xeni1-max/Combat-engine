# 1E1 ground chain and fixed terrain endpoints

2026-11-02. Primary `1E1.odt` ability 2 throws a 30 m/s chain, attaching its
recipient to the ground for 15 s with a 10 m length and binding value 6.
Its source specifies G180/A220, self disorientation/instability 160, target
disorientation/instability 80, Db3.5 and a 9 s cooldown. Its effort is an
intrinsic momentary throw, followed by an independent binding.

## Delivery and delegated choices

Reuse the [chain projectile](CHAIN_CAST.md), action ownership, phase effort,
physical contacts, common Break and saved-body-path controller. The throw
releases at Active end (400 ms at baseline), pays 12.25 dyspnea then and starts
its cooldown then. Self statuses apply at throw midpoint (290 ms). Use the
neutral right-hand pose and existing 2 cm projectile because the source gives
no chain-specific hand/socket geometry. These payment/status/geometry choices
are delegated. Direct HP, armor and shield damage remain zero.

On body contact, select the highest solid horizontal surface vertically below
the recipient's upright reference and no higher than its feet. The attachment
point is on that actual registered part, within 10 m of the recipient. A raised
platform can supply that surface; a floor farther than 10 m cannot. This
deterministic rule supplies the source's unspecified ground connection without
inventing a second projectile, moving the target or pretending an unseen
surface exists. If no reachable surface exists, contact statuses still apply
but no binding, distance row or anchor is created. Independent Block or terrain
intercepts the thrown chain without creating a recipient binding. Personal
regenerative shielding does not prevent damage-free body contact.

The **binding length is not the flight range**. Unlike 3E5's caster-attached
chain, 1E1's projectile has a pure ballistic flight policy. It uses the ordinary
faster gravity-compensated arc and actual collisions; a body 30 m from its
caster can attach to the ground beneath itself. Released binding, status and
flight-policy data are immutable projectile payloads, including on copied
flights. Unreachable aim retains the shared explicit paid-miss policy.

After release the caster is attribution, rather than the physical endpoint.
Its death or later life does not stop the projectile or the established ground
binding. Recipient death, expiry, common Break, external separation, or loss/
geometry change of the anchored collider ends the binding, anchor and distance
row together once. Revival does not inherit old attachments. Nonlethal wall HP
loss preserves collision revision and therefore preserves its anchors. A wall
destroyed by a real beam loses its anchor and standing support at the same
boundary; ordinary gravity and unpaid falling/landing then apply. The casting
hand is free after the throw; duplicate casts retain separate instances/clocks.

## Shared architecture and numerical limits

`TerrainAnchorCandidate` pins collider ID, collision revision, named part and
exact surface coordinates. [TerrainAnchors](combat_sim/terrain_anchors.py)
validates it and owns its independent lifecycle. Public
`distance_constraints.attach_fixed(actor, candidate, maximum_m=...,
expires_at_ms=..., source=..., expected_life=...)` preflights life, geometry,
length and expiry before creating anything. It records the recipient life;
terrain does not acquire a fabricated actor life.

The pure planner now accepts `FixedPoint`/`FixedDistance` alongside two-actor
`MaximumDistance`. Fixed points are constants in the distance polynomials.
They are not solver variables, fake fighters or huge-stat bodies. Their radial
velocity limit is a static contact plane; their finite interval limit remains
the complete quartic squared-distance certificate. Actual grapple/contact
participants alone supply response weights and knockback resistance. In a real
hold/heavy-punch/ground-chain interaction, only held B/D contribute the author's
summed stats; neither the terrain point nor remote caster contributes.

The existing 5 ms/relative-travel knots remain independent of observations.
Exact committed reference witnesses prevent Decimal conversion from placing
the next start just outside a fixed sphere. A bounded repair reconciles to the
owned Decimal grid while checking **all** touching distances, keeping grounded
height fixed and never moving terrain. Repair must stay below 1e-22 m, below
the 1e-20 m contact tolerance. Full-length fixed balls are retained because
shrinking several intersecting balls can wrongly make their feasible set empty.
For a degenerate set with no grid interior, the existing exact legal witness
is retained and counted, rather than asserting a nonexistent rounded solution.

This is a local certified path method, not a universal temporal-accuracy,
energy-conservation or rational-bit-growth guarantee. Result diagnostics report
the maximum numerator/denominator bit count and exact-witness fallbacks.
Pure tests cover joint constraints and tangent fixed balls. Live tests audit
the last full-prefix Bernstein certificate independently and check the
actually committed geometry. Traces without fixed endpoints retain the old
record shape and numeric path; fixed coordinates appear separately from
moving body pieces and force recipients.

[Verification and reproduction](results/ground-chain/README.md).
