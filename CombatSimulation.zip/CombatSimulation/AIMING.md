# Aim toggle and released projectile accuracy

2026-11-03. The existing 1E2 Aim toggle and shared physical release accuracy are
verified in the shared engine. Eleven ordinary current-input API/CLI/hash and
numerical controls include the actual prison/ice interaction under
[confirmed curved entry](CURVED_CONTACTS.md). At that checkpoint, all runtime
inputs/tests matched the source that passed 2492 full-suite methods; 72 focused
methods passed afresh. The subsequent ability4 increment changes that runtime
and has its own current verification in PROGRESS.md.
[Evidence](results/aim-toggle-confirmed-entry/README.md).

## Author rules

Current `1E2.odt` p259–267 defines basic ability 8 as an Aim toggle with 160 ms
Active, unavailable while running. Without Aim, abilities 1 and 4 add 10 cm
radius per 100 m. Ability 1's base accuracy is 2.4 cm/100 m, ability 4's is
1.7 cm/100 m. `Collision details.odt` p6/p12 gives disorientation accuracy loss
`L = O/100` cm radius per metre, equivalently **O cm/100 m**. `Details.odt` p11
reduces running accuracy by 20%. Source copies and independently checked
paragraph excerpts are pinned in results/aim-toggle-confirmed-entry.

## Delegated mathematical choices

Spread is a cone around the existing compensated fastest-arc launch, rather
than a target-hit probability. Add base radius, applicable unaimed radius and
current disorientation, then multiply that total by 1.2 when running. This is
the selected interpretation of the unspecified percentage composition.
Unspecified weapon base radius remains zero; the general O/running rules apply
to every physical projectile. Abilities without physical projectiles do not
acquire an invented spread rule.

At release use a uniform point in the unit disk, mapped to the tangent plane
of the ideal launch direction. Cone slope radius is total cm/100 m divided by
10000. Normalize the perturbed direction to preserve launch speed. Gravity,
direction-following drag, actual contacts and actual travelled-distance falloff
then use this real velocity. O is read at release after due phases, including
the firing midpoint recoil and subsequent decay; no source rule exempts that
self disorientation from accuracy loss. Compensation chooses the faster ideal arc;
no moving-target lead, cover avoidance or advanced NPC intelligence is added.

Deterministic SHA-256 disk rejection uses the explicit scenario random_seed
(default 0), stable actor/profile/life, ability and per-ability released-shot
ordinal. It uses no Python hash, global RNG, observation count or global action
ID. Corresponding aimed/unaimed experiments share the same sample, while a
seed change creates a reproducible different experiment. Cancelled actions do
not spend a shot sample. Copies retain their original release receipt and
momentum; they never resample or re-aim.

## Owned toggle and controls

Aim is a basic control, not an attack-priority loop. Shared control_script
accepts toggle_aim, aim_on and aim_off for characters with that source ability;
set-state controls are idempotent conveniences for the same toggle. Actual
Recovery and disorientation Gathering precede its 160 ms Active. Reuse the gun's
two-hand grip because the source supplies no separate Aim hand pose. Toggle
activation owns both hands and its private focus, requiring upper-body/hand
function. It has no dyspnea or self-status cost under the author extrinsic-effort
policy. Aim commits only at Active end; cancelled work cannot enable it.

A request waits for occupied hands, without blocking independent body work.
Duplicate desired state does not restart work. A contrary request cancels a
pending change if it asks for the current state. The persistent mode adds no
permanent global weapon lock: firing/reload and other abilities retain their
actual ownership. Running/sprinting clears Aim and cancels pending enable work;
starting while running rejects rather than silently waiting for a later stop.
Run uses the shared motor pace classification, becoming running at transition
completion; a request alone does not change pace. Death clears focus and
pending control, and old-life requests cannot bind to a
revived character. Released shot accuracy remains immutable through all of this.

## Compatibility and boundaries

The selected projectile_accuracy mode explicitly enables these rules. Frozen
inputs omitting it retain historical perfect aim and schema. Character data
states weapon accuracy and the existing basic toggle; scenario controls state
seed and intent. The shared controls coordinator dispatches both existing
Break commands and Aim commands, preserving former command records and clocks.

The subsequent [actual ability4 delivery](1E2_ABILITY4_AUDIT.md) uses the same
Aim/accuracy receipts with its 1.7 cm/100 m source radius and current recoil.
Scripted aim_part chooses a live cuboid centre at release, while native contact
selects [body/head output](BODY_PART_DAMAGE.md). Default torso aim and the
faster-arc/no-lead behavior remain. Advanced NPCs, complete six-kit coverage and
complete reproducible 5v5 remain unfinished. Verification is in PROGRESS.md.
