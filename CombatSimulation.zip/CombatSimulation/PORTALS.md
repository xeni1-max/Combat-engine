# Allied portal pairs and voluntary transport

2026-11-09. Existing1E3 ability3 on the shared combat engine.
[Controller](combat_sim/portals.py) · [Transport](combat_sim/spatial_transitions.py) ·
[Public scenario](scenarios/1e3_portals.json) · [Evidence](results/portals/README.md).

## Author rules

1E3.odt p7 specifies two portals: the current location and a selected location
up to10m away, lasting8s, usable by the caster and allies every2s, with12s cast
cooldown. p93 gives300ms Active; p95 identifies extrinsic momentary activation.
The author explicitly assigns no dyspnea to this summon. Released independent
effects survive source death. Actual grapple groups move together under the
author's common-motion rule. Members retain their own lives and stats.

The following completion choices are delegated engineering/game-design rules,
not additional author statements. They preserve this existing ability.

## Casting and endpoints

Unlisted base Gathering/self disorientation/self instability are zero. Use the
existing neutral left-hand pose, unchanged at completion. Normal hand Recovery,
Gathering additions, requirements and cancellation apply. Independent right-hand
attacks and ordinary locomotion may overlap. Start12s cooldown on selection and
release the autonomous pair at Active end. Cancellation prevents deployment;
spent cast cooldown is retained.

Freeze the target world point at selection. Without an explicit target, use the
nearest living enemy's feet, clamped to10m in that direction. Decimal normalization
takes representable inward steps only when needed to fit the declared limit.
Explicit world/surface targets remain exact; they permit utility casting with
only allies. Source endpoint uses current feet at release, so walking can move
it. Feet mean reference x/y and lowest current body cuboid z. Recheck the3D10m
limit at release: an invalid target records rejection without refund or silently
moving the endpoint. Air targets are legal; native gravity/contact follows use.
The pair occupies no blocking volume and transports no projectiles or fields.

## Explicit environmental use

`control_script` and `world.combat_controls.command` accept `use_portal`, with
optional `portal_id` and `expected_life_generation` (script default1):

```json
{"actor":"A","at_ms":350,"command":"use_portal"}
```

The living initiator's feet must be within0.5m inclusive of an active allied
endpoint. Choose the nearest eligible endpoint, with pair ID/endpoint index
tie-breaking, unless identity is supplied. Attempt exactly that pair; a blocked
exit does not select another. Entry is explicit, so exit never automatically
returns the actor. Expiry wins same-clock use. Whole-body binding denies use;
upper/lower bindings alone do not and retain their own attachment rules.

Translate by exit minus entry, retaining entry offset, facing, pose, independent
motor/force inputs and physical velocity. There is no intermediate swept path:
intervening walls do not block teleporting; overlapping final solids/living
bodies do. Coincident endpoints are no-op with no cancellation or reuse cost.
Malformed controls reject before running; dead/stale-life requests are ignored.

All actual grapple members, including held enemies, receive one translation.
Distance tethers alone do not carry their remote endpoint. Validate the full
prospective group and all moving/fixed distance limits before moving anyone.
Voluntary transport cannot silently break a chain. Failed preflight changes no
body/control/reuse clock. Commit bugs propagate instead of claiming safe rejection.

## Shared transport, support and combat

`prepare_transport` extends atomic spatial transitions with reference-only
changes. External displacement/velocity replacement keeps its older cancellation
contract. Transport retains walking/running acceleration and phase clocks,
partial pose changes, basic-jump/dash flight, owed landing/contact effects,
independent weapons and finite knock components. It retains each grapple member's
free motor input instead of averaging an already shared velocity again.

Actual active climb is interrupted, retaining instantaneous physical velocity
under gravity. Gathering climb remains pending for its existing Active-start
range check. Evaluate support against all proposed body placements together;
linked stacks can retain rooted support. An unlinked rider stays behind and
falls when its carrier leaves. Unsupported exits start free fall without a paid
jump. Inward destination contacts settle at the same clock.

The common commit invalidates saved-path/contact forecasts, reconciles support,
heat/electrical exposure and cooldown-pause membership, and requests decisions.
Released shots, beams and other independent effects stay in their own world
positions; transport neither drags them along nor cancels them.

## Shared reuse work and lives

Success starts2000ms of remaining cooldown work for every transported member,
keyed by actor life and pair. Every member must be ready for the group to travel.
Separate users/pairs have independent work. Environmental clocks use each actor's
shared cooldown book; this adds no selectable ability, ammunition or effort.
Pause fields affect both existing clocks and clocks first registered inside.
Exit resumes remaining work at that clock. Rejection does not spend/restart it.

User death retires/removes its clock; restoration gets a fresh-life clock and
cannot execute stale-life use. Source death/restoration neither ends nor
reattributes the pair. Pair expiry retires all of its reuse clocks and retains
final inspection records.

## Boundaries and verification

Existing spatial guards reject destinations beyond the finite floor footprint
or partially supported on raised static terrain. This increment does not claim
ledge/floor-edge fall integration. Fixed facings and bounded numerical/contact
domains remain shared engine limitations, not authored portal range reductions.

Tests separately cover shared transport and actual owned casting/use. Native
grabs, climb, dash/basic landing debt, knock motion, stacks, chains, electrical
screens, heat, pause fields, life retirement, blocked exits and numerical controls
use the common engine. [PROGRESS.md](PROGRESS.md) records verified results and
remaining Goal priorities; historical sealed packages remain immutable.
