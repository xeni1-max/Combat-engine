# Finite ground and open-edge flight

2026-11-13. Current shared combat selects
`terrain_support: {"mode":"finite_faces_v2"}`. This extends
[static-face support](SUPPORT_DEPARTURE.md) through the existing saved paths,
support-loss transaction, gravity and native collision response. It adds no
character ability or separate movement integrator.

The author specifies a 500 × 500 m finite floor centred at (0,0), gravity
9.81 m/s², open sides/top and death at zero HP. The following contact details
are engineering decisions under the author's delegation:

- Ground remains a closed, zero-thickness rectangle at z=0. Its footprint is
  x/y −250 to 250. The declared z=200 top creates no ceiling. Whole-body
  containment is unnecessary; actual positive-area underside contact supplies
  support, using the same 1e-20 m band as other static surfaces.
- Last-witness departure ends the saved prefix and uses common support loss.
  Position, tangent velocity, independent inputs, forces, links and already
  earned landing obligations retain their existing ownership. Departure adds
  no jump cost or jump landing penalty.
- Body parts use the existing quadratic cuboid/sheet contact solver also used
  by owned ability volumes. The old infinite landing-plane shortcut is skipped
  in this mode. Descent outside the actual footprint cannot land on the floor.
  Return from above can land wherever there is real overlap.
- The sheet is two-sided, consistent with its existing projectile and owned
  volume geometry. Face normals are vertical; an underside impact removes
  upward motion without establishing standing support. At its finite perimeter,
  an entering body that actually straddles z=0 meets the edge's horizontal
  constraint. This edge-feature rule extends the author's flat-face collision
  rule; it is not a vertical boundary wall. A body wholly above or below the
  sheet can cross the perimeter freely.
- Positions outside the footprint, wholly below the sheet or above z=200 are
  valid. Gravity continues through the requested horizon. No abyss death,
  automatic removal, boundary teleport or fall damage is introduced.
- New placements, transports and restored occupancy may not straddle the actual
  sheet interior beyond the shared contact band. Preflight rejects those
  destinations atomically; destinations wholly below or outside remain valid.
  Velocity updates retain their existing contact-roundoff handling. Ordinary
  solid/living-body occupancy and stale-life checks still apply.

The selected static support rule permits any actual underside, including a
torso when the legs are beyond an edge. Such a later torso landing is a real
contact, not repeated numerical grounding. This uses the existing convex body
proxy; no new balancing or articulated hanging behavior is inferred. Impact
instability may also change body-reference height while the feet remain at the
support surface.

Prediction and same-time revalidation apply the same separating-edge test to
bodies and selected static faces. At zero edge speed, outward acceleration or
pose-size acceleration also counts as departure. Stationary tangency is not a
new impact; actual inward entry still collides. Cached vertical contact planes
already require positive supporting area.

Current-mode contacts always recheck the actual touching/closing parts before
applying interruption, status or impulse. A saved prediction can end at a
standing/crouch/prone support-envelope switch. Its payload dependencies are
installed after advancement, so an unchanged endpoint dependency does not
certify the prediction's outgoing pose derivative. Revalidation uses the real
one-sided pose at that endpoint, preventing a support-part change from becoming
a false impact. The same correction covers the finite floor, raised solids and
living bodies; historical modes retain their prior contact path. Both the
reproduced cached-contact failures and corrected native fall/Get Up are retained
in the evidence package.

Historical inputs without this rule, and explicit `static_faces_v1`, retain
their old outer-floor guard and landing-plane path. Frozen historical evidence
is preserved. Current [scenario](scenarios/finite_ground_departure.json) and
[evidence](results/finite-ground/README.md) distinguish ordinary movement/casts
from engineering setup and tether API probes.

[Angular support](ANGULAR_SUPPORT.md) now handles rotating footprints, support
departure, native sheet return/underside/edge contact and separating grazes.
Active linked turning, prescribed linked climbing and final cross-kit/5v5
verification remain separate work. Advanced NPC behavior and balancing
automation remain deferred.
