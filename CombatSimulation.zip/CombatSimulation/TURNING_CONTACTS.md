# Turning controlled body-part contacts

2026-11-13. This extends [native turns](NATIVE_TURNING.md) through the shared
owned-contact coordinator. The existing current users are **3E5 Ultimate's
charge grab** and **3E5 ability3's descending foot kick**. Component melee frame
attacks retain their existing separate delivery. No new ability, damage, effort,
phase, payment, motor or character definition is introduced.

## Selected attachment rule

Under delegation, a controlled body-part volume follows its owner's **live body
heading**, including after that turn finishes. The original row's `facing`
remains creation metadata; `follows_owner_heading` declares the live attachment.
Geometry reads do not overwrite the row or its lifecycle. Historical encounters
without native turn control retain their previous data and query path.

This is physical attachment, not retargeting. The action's target, intended
location, source life and attack identity retain their existing rules. Released
projectiles, detached Block and independently deployed effects keep their own
world snapshots. Control/life end still withdraws an uncommitted owned volume.
A committed strike retains the existing damage and life attribution.

## Shared path composition

The body-part path already contains the actual saved reference and local pose
polynomials, with its original angular anchor. For local part centre q, full
size s, fixed attachment fraction f and offset o, the controlled volume uses:

```
local centre       = q + o + f * s
local velocity     = q' + f * s'
local acceleration = q'' + f * s''
```

Its own declared dimensions remain constant; changing leg height does not resize
the foot volume. A lower-face attachment can therefore preserve exact vertical
position even when part centre/size change. The composed point rotates through
the same body frame and retains angular/Coriolis contributions in the existing
path backend. No second reference writer or independent trajectory integration
is added.

When either participant turns, `OwnedContacts` queries actual source/target box
paths within their common saved lease. Fixed materials/finite ground and detached
Block remain static shapes. Continuous bounds reject empty intervals; actual
oriented overlap confirms contact. Same-boundary phase ordering is retained.
First interception, current forward/down ordering, revalidation, friendly/body/
Block/material eligibility, self effects, intrinsic power and once-only commit
still use the original coordinator. The resolver ends the authoritative row,
not an ephemeral live-frame geometry view.

Charge movement still follows the world direction sampled by its existing motor
at Active start. Turning changes the attached grab geometry, not that motor.
The leap's frozen takeoff/landing intent likewise remains physical; yaw does not
steer flight. Source/target/both-turning kicks retain one original payment, one
committed strike and the existing downward knock. A missed kick can strike the
real ground and settle its existing landing debt once.

## Verified scope and remaining work

[Evidence](results/turn-owned-contacts/README.md) covers actual turning charge/wall
fracture, changed contact time, post-turn rearm, source/target/both-turning kicks,
missed-kick landing, original ownership/life and a target turn finishing before
a later grab/hold. The prior blanket owned-volume turn guard is removed.

The subsequent [field extension](TURNING_FIELDS.md) integrates angular field
membership and cover. [Angular support](ANGULAR_SUPPORT.md) now includes
finite/raised/body support and native landings. [Active grapple/tether turns](ANGULAR_LINKS.md)
now preserve reference-space links, resting-contact lifetimes and actual impacts.
Prescribed angular/linked climbing remains guarded. Finish that consumer and final cross-kit/5v5
verification before considering the overall Goal complete. Advanced NPCs, mass
experiments and balance automation remain deferred.
