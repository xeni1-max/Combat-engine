# Shared poisonous volumes

Verified 2026-11-10 as a shared released-volume foundation. [The actual 1E1
launcher](LAUNCHER.md) now supplies owned swap/ammunition and physical impact
grenades on this same timeline. [Foundation evidence](results/poison-volumes/README.md)
retains its labelled API-only scope; [actual-cast evidence](results/1e1-launcher/README.md)
verifies delivery. Historical controlled inputs remain reproducible.

## Author facts

Current 1E1.odt p11/p13 specifies ten impact grenades, each releasing poison in
radius 5 m for 8 s, with 65 s Ultimate cooldown. Current p137/p139/p141 gives
400 ms intrinsic-sustained swap and Db2.5; p148–172 gives G140/A180, target110/110,
self140/140, toxicity1200, 1150 ms firing cooldown, Db3.5, 60 m/s and release at
firing end. These current facts do not rewrite the old controlled runner's
historical 300 ms equip timing.

Damage types.odt's Poisonous equation and confirmed author clarifications give
`max(0, (Tp² - 10 RT²) / Tp) * sqrt(tT - to)` HP damage per second, with no slash
delivery factor, shield absorption or armor loss. Exposure grows inside gas;
after leaving, its residual falls to zero over the same duration. Each grenade's
poison is independently additive. Area O/U applies once at detonation; this
foundation alone adds no instantaneous hit or statuses.

## Delegated integration rules

- Use a fixed 3D sphere. Any overlap with one or more living body cuboids is
  one exposure; isolated tangencies add no positive-duration dose. Exact
  polynomial cell boundaries handle translation, acceleration and pose changes.
- Gas affects organic characters, including friends and the source. Fixed
  materials have no toxin receiver and take no gas damage. Select unoccluded
  membership within the sphere; diffusion paths and concentration gradients are
  not authored, so no wall/ceiling attenuation or extra spread is invented.
- Maintain one net toxin load per cloud and recipient life: it grows at one
  second per second inside and decays at the same rate outside. Re-entry before
  zero resumes the remaining load; after zero it starts a new episode. Separate
  clouds remain independent and additive. At exact zero, physical expiry
  starts a new episode even if a due phase runs before the queued timer. This
  extends the confirmed single exposure/residual clock without creating
  simultaneous duplicate visits.
- A released zero-toxicity output has zero dose without evaluating a zero
  denominator; its geometry, lifetime and exposure clocks remain.
- Toxin resistance is live, including 2E4's current shield-stock bonus. Shield
  bypass does not disable that explicit resistance. Constant-defense doses use
  analytic affine-root integrals; changing shield defenses use the existing
  dense integration and immutable HP/damage/healing history infrastructure.
- A released cloud survives source death/restoration with its original source
  life identity. Recipient death retires that life's toxin. A new life inside a
  surviving cloud acquires a fresh zero-load exposure, never the old residual.
- Cloud expiry stops exposure, then each recipient's existing residual decays.
  The horizon only observes current state; it does not expire gameplay effects.

The public shared API supplies an attributed released volume. API probes are
labelled separately from ordinary character casts. Actual launcher delivery
supplies frozen released parameters and original action/life/projectile identity
through shared weapon-mode, ammunition and projectile ownership. Each actual
first contact also emits its once-only area O/U through shared status resolution.

The actual launcher's instantaneous O/U pulse has its own explicit world-cover
policy, while this persistent chemical volume remains unoccluded. This
behavior-preserving delegated distinction is recorded in [LAUNCHER.md](LAUNCHER.md)
and verified with covered and uncovered actual collisions.
