# Atomic body transitions and instantaneous velocity projection

Finite ground, 2026-11-13: [finite-sheet rules](FINITE_GROUND.md) permit outside
and wholly below-floor placement/transport/restoration while rejecting new
occupancy crossing the actual sheet. Departure keeps the existing support-loss
transaction. No boundary wall, abyss death or alternate translation writer is
introduced. Historical inputs retain their floor guard.

Partial static support, 2026-11-10: With [static-face rules](SUPPORT_DEPARTURE.md), prospective placement/transport/restoration queries use actual underside/top witnesses, permitting partial raised support. Settled departure retains velocity/motor/forces through the existing support-loss transaction. Independent controlled and released lifetimes remain unchanged.

**Voluntary transport extension,2026-11-09:** `prepare_transport` validates
reference-only changes, expands actual grapples, checks prospective support and
rejects exceeded live distance limits before commit. It preserves independent
motor/force inputs, phase clocks, pose, flight and landing debt; only actual
active climb loses its attachment. External replacement keeps the contract below.
Notification/contact machinery remains common. [1E3 portals](PORTALS.md) supply
the authored delivery and environmental reuse clocks.

Spatial plan dependencies also include distance topology. A tether attached at
the same timestamp after preparation invalidates the plan even when no body has
moved. The archived module reproduces the former erroneous transport and
`external_separation`; current source rejects before either change.

**2026-11-02 velocity correction:** an unchanged current pose is not a new
placement. Only actual relocations and restoration perform fresh overlap checks;
every relocated body is still checked against all proposed/unmoved recipients,
including those receiving velocity-only changes. Contact roots can leave tiny
positive overlap within collision resolution; ending a force must not reject
that existing geometry as a new destination. Life/generation, finite input,
floor/support and stale-plan validation remain. Restoration is fresh occupancy
even when its reference is unchanged. No movement, extra payment or new ability
is added. [Evidence and remaining support work](results/velocity-transitions/README.md).

Delegated engineering decisions, 2026-11-01. These are reusable shared-world
mechanics, not new character abilities. Existing gravity, collision, climbing,
stopping and death rules remain in force. Primary ODTs are unchanged.
[Implementation](combat_sim/spatial_transitions.py) ·
[Verification](results/spatial-transitions/README.md).

The later [tether projection foundation](TETHERS.md) adds optional `taut=` and
`contacts=` constraints to `prepare_projection`/`project`. It solves radial
limits, one-sided contact and existing grapple/bilateral constraints jointly,
with exact certificates and JSON-readable records. Live participant expansion,
stale-plan checks and external velocity-replacement semantics remain. This API
is instantaneous; persistent curved tether paths and the chain cast are pending.

Current ordinary body advancement now uses [saved polynomial paths](BODY_PATHS.md),
with the same upright reference and one shared translation writer. This does
not change the external replacement/cancellation contract of this API.

**Later extension, 2026-11-01:** [persistent grapple-group motion](LINKED_MOTION.md)
now uses this interface. External changes expand to current linked members,
and explicit projection includes their existing equality constraints. The
instantaneous projection API itself remains instantaneous; persistent links
have a separate source/life/expiry/fatigue controller. The original milestone
and its frozen evidence below retain their stated scope.

## Purpose and authority

The principal review identified duplicated position/reference/velocity/support
writes as an integration gate for existing drag, chain, grapple and portal
abilities. Independent controllers must not overwrite one another's body state
or average pairs successively in an order-dependent way.

Current inputs select `spatial_transitions.mode=atomic_body_v1`. The coordinator
validates a complete proposed change before cancelling control or writing any
body. Actual support loss and restoration now use this interface. Ordinary
movement still evaluates through its existing trajectory/contact controllers;
this is a narrow transition boundary rather than a second physics engine.

## Prepare and commit

`SpatialChange` contains an actor ID, mandatory expected life generation and
optional upright reference and physical velocity in world coordinates.
Coordinates are copied into immutable exact rational tuples; the world owns
Decimal conversion and numerical precision. A reference is distinct from the
recentered body origin of a crouching character.

`prepare(changes, source=...)` returns an immutable plan tied to one world.
It checks all destinations together, including current pose, living bodies,
solids, selected finite-sheet occupancy and support. Two actors can swap destinations
atomically; a destination overlapping an unmoved living actor is rejected.
Dead bodies do not obstruct destinations. Relocation tests the destination,
not a swept path; imposed velocity instead uses ordinary continuous contacts.

The plan captures time, geometry and collider epoch, life, motion and support,
pose, relevant statuses and owned action revisions. `commit(plan)` rejects a
foreign or stale plan before mutation. A change below the existing spatial or
speed resolution is a no-op and does not interrupt an action. An invalid second
destination cannot cancel the first actor's jump, move it, or charge effort.
Unexpected runtime errors during commit propagate; they are not reported as a
safe preflight rejection after partial execution.

External changes cancel the affected actor's current body action. They preserve
compatible independent weapon actions and already released projectiles, wounds
and areas. A relocated partial crouch retains its present pose and loses its
old posture control. A displaced climber keeps the new location and inherited
instantaneous velocity under gravity; its old path cannot resume or complete.

After all bodies change, the world refreshes locomotion and field membership,
invalidates continuous HP/thermal forecasts and collider contacts, and requests
legal decisions. A touching inward contact at the observation horizon is
resolved at that time. Cooldown-pause exit resumes remaining work immediately;
leaving heat ends exposure without deleting the independent beam.

## Imposed physical motion

An external horizontal velocity becomes an explicit imposed motion driver. It
is physical velocity, so voluntary instability speed penalties do not silently
reduce it or accelerate it while U decays. No extra dyspnea, invented friction
or selectable knockback ability is added. Ordinary ground/obstacle/body contacts
project its velocity and apply the existing actual-collision status rules.

Gravity affects its vertical component. Horizontal motion continues through
flight and landing, including dormant ground motion projected at a mid-air
collision. A force launch is not a basic jump and pays no jump effort or landing
self effects. A force applied during an actual basic jump preserves that jump's
owed landing effects. Independent weapon effort continues normally.

A new voluntary movement or special-stop command takes control from the
physical current speed/direction. The existing resisted stopping slide applies;
there is no reinstated linear-stopping mechanic. Successful climb activation
switches to its authored path; a failed climb entry retains ordinary motion.
Death clears imposed control and freezes the existing dead pose. Restoration
does not restart it or an old controlled jump/climb.

Support removal prepares a fall at the current reference, preserving existing
horizontal movement without a fake jump payment. Restoration prepares zero
velocity and reconciles support before HP/life generation changes. The spatial
audit records the old generation being restored; the subsequent `life_restored`
event records the new life. Frozen inputs without the new mode retain their
old output schema and complete replay results.

Current [living-body support](BODY_SUPPORT.md) uses that same loss/restoration
transaction. Loss can supply the last committed physical velocity and choose
an alternate rooted support. Prospective destinations inspect proposed cuboids;
an unchanged contact pose inspects current witnesses so a withdrawing part is
not reattached by its own loss transaction. Life and occupancy guards remain
strict, including restoration at a retained location.

## Whole-graph calculation

[velocity_projection.py](combat_sim/mechanics/velocity_projection.py) extends
the grapple source's two-body formula under delegation. An equality edge means
the two nodes must receive the same complete velocity at this instant. Every
connected component is solved once:

`v = sum(w_i * v_i) / sum(w_i)`, with
`w_i = (maximum_HP_i / 500 + current_armor_i / 10)^1.1`.

The existing 40-digit body/status weight is unchanged. It is a source-defined
weight, not physical mass in kilograms. Exact rational accumulation and
orthogonal projection remove order drift from duplicate edges, cycles and
linearly dependent blocked-direction rows. Blocked directions remove the
component along a supplied nonzero normal from the whole connected group.
Those rows are bilateral equality constraints, not unilateral taut/slack ropes.
Independent components remain independent; final conversion uses owned world
precision. All resulting body changes commit in one transaction.

**This calculation is instantaneous.** It does not install a persistent link,
combine later voluntary accelerations, supply grapple fatigue/Break, or cast an
existing character ability. A later independent movement command can separate
the velocities. Real contacts add statuses; a mathematical blocked-direction
row alone does not invent a collision.

## Inspectable scenario controls

Optional `spatial_interventions` are explicitly engineering-only scenario
controls, separate from `action_selection` and legal character abilities:

```json
{
  "at_ms": 0,
  "scope": "engineering",
  "source": "scenario:force_probe",
  "changes": [
    {"actor": "A", "expected_life_generation": 1, "velocity_mps": [3, 0, 3]}
  ]
}
```

A row may instead contain `projection` with an actor-to-life map, equality
pairs and optional `blocked_directions` records (`actor`, `normal`). All input
rows validate before scheduling. They run once at script priority 5, after
same-time phases and already due damage/contacts. A stale/dead member skips the
entire batch; invalid geometry rejects it. Records distinguish `queued`,
`applied`, `no_change`, `skipped` and `rejected`, including source, expected
lives and processed time. These controls make ordinary CLI/API evidence
possible without encounter subclasses or mislabelling a probe as a portal cast.

## Remaining gates

Selected static-face rules permit partial raised support and schedule its
actual departure; living-body support also uses the shared witness/path model.
Current finite-floor departure uses the same transaction. General body turning
and prescribed linked climbing remain explicit boundaries. Get Up, current prone/crouch proxies and actual
grapple, chain, hook and portal deliveries have their own verified controllers.
The battlefield retains open sides/top; this API adds no boundary walls.

[Persistent coupled motion](LINKED_MOTION.md), [actual grab/drag](GRAPPLE_DELIVERY.md),
[Break](GRAPPLE_BREAK.md), [hooks](GRAPPLING_GUN.md) and [portals](PORTALS.md)
now use this interface. Their actual casts, rather than the relocation API alone,
establish delivery; the dated initial projection checkpoint remains historical.
