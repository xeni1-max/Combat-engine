# Impact binding areas and 1E3's ice bomb

**2026-11-02 cover correction:** the selected binding-only `occlusion:none`
now bypasses cover in the shared body-area helper. Actual prison material
blocks HP damage without suppressing that existing binding policy.
[Regression and prison interaction](results/prison-cast/README.md).

Primary `1E3.odt` p5/p68-p89 specifies an ice bomb: G140/A220, 60 m/s,
release after throw, self O160/U180 on throw, target O/U110 on impact, Db2,
and an 8 m radius explosion freezing everyone's lower body for 10 s with B3.
Overview cooldown is 9 s. The throw is intrinsic momentary; the released binding
is independent. The author has already established midpoint self effects.

Engineering decisions under author delegation:

- No damage amount is authored. Use a reversible **200 blunt base damage on
  physical contact**, below the character's 350-damage ordinary projectile
  because this attack also supplies a long binding. This numerical choice is
  reversible and preserves the stated damage family. The explosion adds binding
  without additional HP damage.
- Target O/U110 applies at direct impact. The binding-only burst does not invent
  another status impulse on that recipient or other nearby bodies.
- Pay Db2 and start the 9000 ms cooldown at throw end. At D0 cost is 4. Native
  intrinsic release output uses current U/10; the canonical U70 gives 193 blunt.
  Binding B3/duration/radius are not reduced by throw effort or damage absorption.
- Use the existing neutral right hand, 2 cm sphere, gravity and current-torso
  faster arc without predictive lead. There is no invented caster-relative
  throw range. Algebraically unreachable aims use the existing paid ballistic
  miss proxy; actual collision remains necessary for any explosion.
- First physical body, independent Block, terrain or wall contact detonates.
  Direct damage still uses normal simultaneous shield/armor/terrain handling.
  At the exact contact surface, select every living body with any cuboid
  overlapping the closed 3D sphere once, including allies and caster. The burst
  ignores cover, consistent with the literal everyone-in-radius effect and
  existing broad area convention; this is delegated, not an author confirmation.
- Personal shield stock and independent Block can absorb direct damage but do
  not suppress a burst already caused by physical collision. Terrain receives
  only the physical carrier's damage and no creature binding or recovery credit.
- Released radius/binding/status parameters are copied with each physical
  projectile. Each independently copied projectile can burst once. Live source
  death or later profile changes do not erase released flight/binding. Recipient
  death in the impact wave prevents attachment; later revival inherits none.

The shared component expands a physical impact into normal direct damage plus
zero-damage binding components in the same impact wave. Bindings attach after
damage/healing/death through the existing life-bound binding/Break controller.
No alternate damage, movement or Break engine is introduced. Lower freeze
removes voluntary lower-body control, preserving native momentum/gravity and
legal upper-body actions. An airborne jump retains its existing landing receipt.

Current selected input enables `impact_bindings.mode = contact_burst_v1` and
adds explicit hand/weapon/upper-body ownership for the carrier. Definitions
without this mode retain their former behavior; no historical manifest is
refreshed. Current result records include every burst/contact, affected body,
recipient life, queued/applied outcome and independent binding identity.
`hits_resolved` counts physical and utility components; the `binding_burst`
component always has zero incoming/HP/armor/shield damage. Full JSON retains
these lifecycles; summary-only output emphasizes final actors and resources.

**Verification:** 2237 full-suite tests pass in 603.380 s; 30 new live methods pass
in 31.480 s; 96 combined balance/geometry/current-kit checks pass in 101.225 s.
Twelve ordinary complete API/CLI captures and fresh reproduction pass, with
five hash-seed and five combined precision/observation/order controls. Tests
include simultaneous copied carriers with proportional shield breaking,
actual friendly interception, lethal contact, real source death and recipient
revival, upper/lower overlap, independent expiries/Break, airborne/climb/Get Up
interruption and real held-pair summed-stat knocks. Copy/lifecycle/boundary
probes are labelled engineering controls, not the duplication ability.
[Evidence](results/ice-bomb/README.md).

All 4523 earlier result files and 14 current ODTs are unchanged. Only 1E3 ability 2
and its reviewed metadata are imported; other character stats/abilities are
unchanged at that checkpoint. The subsequent [physical prison](PRISON.md) uses
shared compound HP/expiry and contact delivery; portals/duplication and other
kits remain unfinished. Its current support/collision boundaries are documented.
