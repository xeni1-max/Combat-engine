# Shared movement and combat integration

[ENGINE_STATUS.md](ENGINE_STATUS.md) is the current capability/decision index.
The initial integration and dated extensions below retain their historical
scope. The latest correction and climb extension supersedes old pending lists.

**Current 2026-11-01 extension:** [saved body paths](BODY_PATHS.md) now provide
one immutable translation prefix and one advancement writer for current moving
inputs. Existing grapple groups, ballistic motion, climb, pose and contact/field
queries share it. All six profiles have common movement basics; the roster and
engine index supersede older profile/ability limits below. Persistent curved
tethers, moving-support departure and broader facing/prone paths remain pending.

**2026-11-01:** [shared spatial transitions](SPATIAL_TRANSITIONS.md) now own
atomic external reference/velocity changes, support loss and restoration.
Imposed physical velocity uses the existing continuous contacts/gravity and
hands control back to voluntary movement or special stopping. A whole-graph
instantaneous projection composes cycles without sequential pair averaging;
persistent links remain next. Current locomotion profiles include 1E5, 2E4 and
3E5 as well as 1E1/1E2; actual 2E4 healing/revival and 1E5 component attacks are
integrated. The two-/three-profile limits below describe earlier checkpoints.

Current 2026-10-29 inputs also integrate [phase effort](ABILITY_EFFORT.md):
intrinsic Qard and its delayed blast share straight/gravity projectile contacts,
moving bodies, cover and HP receipts. Sustained gun control can be interrupted
without cancelling independent flights or body actions. Historical milestones
below retain their original numeric expectations under frozen definitions.

Current inputs also integrate [2E4 thrust/venom/replacement blades](MELEE_VENOM.md)
and its existing movement basics. Real contact, autonomous wound/item clocks,
controlled grabbing and live shield/toxin defenses use this same coordinator.
The earlier two-profile scope below is historical; current body profiles cover
1E1, 1E2 and 2E4. Healing/revival and the remaining kit deliveries are unfinished.

Decision record, 2026-10-26, under the author's mechanics delegation of
2026-10-25. The implemented milestone joins existing grounded, upright,
straight walking/running/stopping with the existing 1E2 gun. It introduces no
character or character-specific ability. The six-character project roster is
unchanged; the current locomotion profiles cover 1E1 and 1E2 only.

**Implemented: moving gun combat with gravity, compensated aim, sprint and basic jump.**
[combat_locomotion.json](data/movement/combat_locomotion.json) records the
selected movement-effect rules. The shared engine now advances motion, gun
flights, damage, bleeding, statuses, resources and death together. The previous
stationary combat, geometry-only movement and Get Up results retain their own
scopes and unchanged trace regressions. See the [gravity encounters and replay](results/moving-gravity-combat/REPORT.md)
and the earlier [straight-flight encounters](results/moving-gun-combat/REPORT.md).

## Existing source rules

Paragraph references are zero-based ODT paragraph indices.

| Rule | Primary source or explicit author clarification |
|---|---|
| 1E1 walk/run transition: 150 ms Active, 80 self disorientation, 80 self instability, listed dyspnea 0.5 | `1E1.odt` p183-p189 |
| 1E2 walk/run transition: the same values | `1E2.odt` p199-p205 |
| Running increases Gathering, hand Recovery and self disorientation/instability by 20% | `Details.odt` p11 |
| Stopping gives 150 self disorientation and instability per 5 m/s of previous travel | `Details.odt` p38 |
| Instability decays by one per millisecond; speed loss is U/200 m/s | `Collision details.odt` p18-p24 |
| Action cost uses `Da = (Db + D/100)^2`; insufficient capacity prevents the action | `Dyspnea details.odt` and existing shared dyspnea implementation |
| Dyspnea recovers at 30/s while stationary/walking and 18/s while running; disorientation, instability, Gathering, Recovery and Active block recovery | `Dyspnea details.odt` p15-p19 |
| Baseline walking is 2 m/s and running is 6.4 m/s for these two profiles; stand-to-walk takes 60 ms and walk/run transitions take 150 ms | Author clarifications in [MOVEMENT.md](MOVEMENT.md) |
| Special stopping starts at Active start, uses resisted distance and a linear slide-speed curve, and lasts for its base stopping instability in milliseconds | Author clarifications in [STOPPING_REVIEW.md](STOPPING_REVIEW.md) |
| Collision status uses 60 times relative projected speed for both characters; each loses its own component along the collision direction | Author clarifications in [COLLISIONS.md](COLLISIONS.md) |
| Character contact uses the centre line; obstacle contact uses the contacted surface normal | Author clarification in [COLLISIONS.md](COLLISIONS.md) |

The source documents do not by themselves select all payment/effect anchors,
transition modifier snapshots or scheduling interactions below. Those choices
are made under the delegated authority and remain independently revisable.

## Selected movement-effect decisions

1. **Walk/run cost and self statuses occur at Active start.** Treat each listed
   0.5 as `Db`, check capacity with current dyspnea and pay through the existing
   action-cost helper. Add the two self statuses through the unmitigated self
   route. Insufficient capacity cannot partially begin or partially pay for
   the transition. An interrupted transition retains its paid cost and already
   applied statuses.

2. **Either running endpoint selects the transition self-effect modifier.**
   Walk-to-run and run-to-walk each add 96 disorientation and 96 instability
   before any independent same-time incoming effects. This symmetric choice
   avoids dependence on whether an implementation updates the pace enum before
   or after applying the transition effects. The base Active remains 150 ms;
   running's duration modifier applies to Gathering/Recovery, not Active.

3. **Starting ordinary walking has no added status or dyspnea cost.** No such
   amounts are specified for standing-to-walking. Preserve its approved
   baseline acceleration duration. This exemption is a delegated decision;
   it does not infer that every undocumented action is free.

4. **A special stop snapshots actual speed before its new penalties.** Use
   that one speed for base O/U (`30 × speed`), stopping duration and the
   approved resisted slide calculation. If the source pace is running,
   multiply only the self-status additions by 1.2. Slide duration uses the
   unscaled base instability and does not include existing accumulated U.
   No separate dyspnea cost is assigned to stopping. A zero-speed stop does
   not fabricate travel, penalties or a positive-duration slide.

5. **Ordinary locomotion applies instability continuously.** Its actual speed
   is `max(0, commanded_speed - U/200)`. Commanded speed is the baseline pace
   or its approved linear transition. U decays continuously by one/ms, so
   both actual velocity and distance must account for that decay between
   events. Split an analytic interval when U expires or the speed crosses
   zero; never rely on reporting samples as movement ticks. Reanchor position
   before changing U or a commanded-speed curve.

6. **The prescribed special slide has no second U speed reduction.** Its
   resisted distance, duration and derived initial speed already specify the
   whole path. Subtracting U/200 again would change the explicitly approved
   slide. New instability still affects status state, eligibility/resource
   recovery and subsequent ordinary locomotion. An actual body/terrain contact
   can interrupt the slide through the selected collision response.

7. **Resource context follows both movement and combat.** A movement Active
   blocks recovery just as a combat Active does. Other existing blockers keep
   their precedence. Constant walking/running selects its documented recovery
   rate when no blocker remains. This increment adds no continuous running
   charge. Running modifiers for attack Gathering, hand Recovery and self
   statuses must use the actual locomotion state at their defined anchors.

The data file contains these amounts, anchors and interpretations. Speeds and
transition durations continue to come from the existing movement definition;
weapon costs and timings continue to come from the existing character data.

## Coordinator requirements

The historical geometry-only and stationary scopes retain their separate paths.
The integrated scope uses one coordinator. An interval
ends at the earliest relevant scheduled event or continuous boundary: motion
contact, projectile contact, HP/shield exhaustion, status expiry, a speed-floor
crossing, or any other state change that invalidates the interval's formulas.
Positions, collision geometry, damage, shield history, statuses and dyspnea
must all advance from the same starting time to that same boundary once.

Geometry is updated before events at its new timestamp are resolved. A status
addition, pace change, contact or death invalidates dependent motion/contact
predictions. Merely updating a sampled character position while retaining a
projectile's launch-time contact list would still simulate stationary targets.

Constant locomotion and a controlled action are distinct state. The legality
layer must explicitly arbitrate commands that request movement transitions
while another controlled action is in progress. It must record whether a
scripted request executed, waited, or was rejected; no command may silently
bypass Active/Gathering/Recovery eligibility. The final command arbitration
and same-time contact ordering must be recorded with the implementation.

Death invalidates controlled motion and pending movement phase revisions as
well as the existing combat action. Released projectiles retain their own
trajectories. Body removal, status updates and stale event cancellation must
use the same death resolution as the existing team engine.

## Collision requirements

**Boundary correction, 2026-10-29 (delegated):** classify a predicted body
contact within `1e-24 ms` of a known scheduled/kinematic boundary at that boundary.
Search through that endpoint resolution so a rounded root just beyond it is
not missed. Other physical times retain their fractional milliseconds; reporting
observations are not physics ticks. Due phase closure precedes projectiles and
body contacts. The reported observation-partition defect is covered by seven
50/80-digit/observation variants and both 0.001 ms neighboring controls.

Predicted body contacts carry internal value dependencies on living participants'
geometry, pose deformation, velocity/acceleration, support and spatial revision.
After due phases/hits, changed dependencies require renewed touching and inward
motion before any action interruption, impulse or status. Individual collider
revisions still reject removed/reshaped contacts. An unrelated registry epoch
change cannot discard an otherwise valid simultaneous contact batch. Internal
dependency records are excluded from public traces.

Time resolution is `1e-24 ms`; touching geometry uses `1e-20 m`; inward speed
and acceleration use separately named `1e-24 m/s` and `1e-24 m/s²` resolutions.
Persistent tangency is not a new impact. A phase retaining inward motion still
collides, including posture completion; a new tangential climb replaces its old
wall approach. Genuine obstruction, external displacement and disappearing
support retain normal response and legitimate inherited momentum.

`spatial_motion.py` supplies a narrow shared upright-reference transition and
contact dependency interface, currently used for climb placement. Existing
motion producers are included by value in dependency checks while their wider
migration remains incremental. This does not claim a general teleport,
knockback, moving-support or coupled-chain implementation.
[Correction evidence](results/principal-review-corrections-2026-10-29/README.md).

The contact detector must supply the actual contacted parts and obstacle face
normal. Reuse the existing isolated directional-response helpers and incoming
status mitigation. Snapshot velocities and defenses before resolving a
simultaneous contact set so iteration order cannot change the result.
Apply each character's incoming collision statuses through the same status
path as other incoming effects, including extension of existing Gathering.
Preserve the permitted perpendicular velocity component.

A single physical collision can involve several cuboids from the same body.
Deduplicate those part contacts before charging collision statuses. Persistent
touching without renewed closing motion must not repeatedly add status or
create a zero-time event loop. Character centre-line responses and solid
nonpenetration constraints need compatible handling; do not replace the
author's response direction merely because a cuboid face is easier to detect.
The final rule for simultaneous faces/corners/contacts must be recorded and
tested, or remain an explicit bounded-scope rejection.

## Initial bounded verification

The first moving encounter should prove a real moving-body hit and a real miss
with the existing gun, in addition to these individual checks:

- Walk/run cost and self-status timing, affordability, running multipliers and
  exact dyspnea bounds; blocked and permitted resource recovery.
- Continuous U-dependent movement during constant pace and transitions,
  including status expiry, a stopped-speed interval and incoming-status jumps.
- Prescribed stop distance/duration despite its own new instability, with no
  second speed reduction; contact interruption.
- Actual relative-motion projectile contact; target motion changing after
  release; collision/falloff based on traveled trajectory, not initial range.
- Movement/collision status during combat Gathering; controlled-motion
  cancellation on death; retained released shots.
- No duplicate collision penalties, penetration or zero-time loops in the
  supported contact cases; same-time ordering independent of actor input order.
- Agreement under higher precision and different/no observation schedules.
- Complete regression preservation for existing explicit historical scopes.

Jumping, climbing, posture changes, sprinting, arbitrary turning, advanced aim,
moving heat exposure/re-entry, broader character kits and general 5v5 coverage
are outside this first bounded integration. Their existing geometry helpers
or isolated studies retain their own capabilities. Unsupported inputs must be
identified explicitly rather than being accepted with stationary behavior.

## Implemented scheduling and contact choices

- Historical exclusive scheduling: commands enqueue FIFO intents. An intent waits for the current controlled
  action, then takes priority over the next automatic attack. Movement Active
  occupies the same action slot as attacks. Steady walking/running continues
  during weapon Recovery/Gathering/Active. Direct standing-to-running intent
  expands into the existing start-walking and walk-to-run transitions.
- Movement direction is a supplied fixed world direction, independent of the
  body's fixed +x/-x facing. This permits a straight lateral test without
  pretending to implement turning. A contact can remove blocked components.
- Due phases/releases resolve first, projectile hits second, body contacts
  third, new movement intents next, and policy decisions last. A horizon event
  ensures contacts are still processed when no policy or sample events remain.
- Each character pair or character/obstacle contact is charged once even when
  several body parts touch. Every incoming contact is mitigated separately,
  then summed before extending Gathering. All contact speeds use one snapshot.
- Character status uses the centre line; obstacle status uses the face normal.
  An exact obstacle edge/corner uses the normalized sum of touching face
  normals for one status impulse. Solid nonpenetration additionally constrains
  all touching faces. An orthonormal projection satisfies simultaneous component
  constraints without reintroducing a removed component. This extra solid-face
  constraint is a delegated resolution of the cuboid/centre-line mismatch.
- Contact projects actual velocity, then restores the prior U offset in the
  nominal pace before adding new collision U. This avoids subtracting the old
  penalty twice. Tangential travel remains; the newly applied instability can
  slow it further. Contact cancels a movement Active but does not invent an
  interruption of a weapon action; incoming O can extend weapon Gathering.
- Death cancels controlled motion and pending movement intents. Dead bodies
  stop colliding. Already released projectiles continue independently.

## Projectile integration and numerical scope

The existing gun's spherical projectiles start at the specified left hand and
aim at the target torso's location at release. Aim is not predictive. Each
flight is retained and checked against current body motion after every relevant
boundary; a target can enter or leave its path after release. A projectile
ignores its shooter and can hit another living teammate or terrain.

Relative motion is quadratic over an interval. Exact rational polynomial root
isolation locates the sphere/cuboid's true rounded contact, including tangency,
without reporting samples as physics ticks or substituting expanded boxes.
Finite ground remains a zero-thickness rectangle. Contact times retain
fractional milliseconds; unlike the historical stationary runner, they are not
rounded to the next millisecond. Exact-time object ties consume the projectile
once using stable object/part identity. Different shots still use shared
pre-hit defenses and proportional shield absorption.

The first integrated flight retains the gun's straight -300 m/s² deceleration.
Falloff uses distance actually traveled to contact. At zero speed the round
becomes inert without an impact, damage or fabricated mark; this is an explicit
delegated zero-speed rule for this historical straight-flight scope. The new
gravity scope below extends this shared coordinator. Earlier result packages
continue to select their original explicit scope.

Ground footprint departure still raises an unsupported-case error; falling
from an edge is not silently simulated. Prone/Get Up geometry and moving area
exposure remain unsupported. Airborne locomotion was excluded from this first
grounded milestone and is added by the optional jump definition below.

Validation includes 20 analytic moving-sphere tests and 21 integrated tests,
covering post-release target changes, resource and status timing, collisions,
death, exact running Recovery rounding, simultaneous per-contact mitigation,
and results independent of observation interval, actor order and precision.
The full five-second duel exposed a repeated resting-contact loop at 80-digit
precision. The detector now requires renewed inward velocity or acceleration;
tiny rounded overlap at rest/tangency does not create another impact. A
permanent long-duel regression checks this without weakening collision geometry.


## Gravity-enabled moving gun, 2026-10-26

`GRAVITY_MOBILE_SCOPE` selects `projectile_motion: gravity_directional_deceleration`.
The same movement/combat coordinator and legal actions run with compensated gun
launches and persistent curved flights. Physics controls are explicit inputs in
[data/physics/projectile_gravity.json](data/physics/projectile_gravity.json).
The CLI loads that definition only for the gravity scope; APIs require it.

The author-specified gravity, direction-following deceleration and actual-path
falloff are integrated. Aim uses the current torso at release, starts at the
left-hand start position, and follows the short branch continued from fastest
ballistic aim. Target leading and cover avoidance are not inferred. The numerical
branch limit is explicit; it is not a proof of global fastest aim for unsupported
near-stop trajectories. [GRAVITY.md](GRAVITY.md) records the model, numerical
limits and delegated choices.

A trajectory is computed once at release, independently of observations. Relative
curved sphere/cuboid queries re-evaluate contacts against current body motion.
All eligibility, death, action, status, defense and friendly-fire rules above
still apply. The original finite arena and cubes are unchanged.

Confirmed curved contacts use a common 1 ns event grid, with numerical ties
ordered by stable object/part identity. Separate projectiles at a tick share
pre-hit defenses. Deferred contact evidence survives a boundary between detection
and the rounded event; an earlier interruption invalidates an unreached prediction.
Inert terminal events run after projectile impacts in the same tick. This event
grid is a numerical resolution choice, not exact physical simultaneity. Body
contacts retain their existing fractional timing.

[Saves and replay](results/moving-gravity-combat/REPORT.md) cover a five-second
duel, a lateral miss reaching the original floor, a cube interception and a miss
that leaves the finite floor and becomes inert. Focused tests additionally cover
post-release motion, shooter death, true curved-distance falloff, observation
and precision checks, and rounding boundaries. At that checkpoint the remaining
spatial actions were still geometry-only; sprint and jump are integrated below.
Climb/crouch, turning, prone/Get Up collision geometry and moving area exposure
remain unfinished in combat.


## Sprint extension, 2026-10-27

The optional sprint combat definition now adds the existing 11.2 m/s pace and
200 ms transitions to this coordinator. Hands recover to the authored sprint
pose before Active; transition costs/self statuses apply at Active start.
Continuous nonlinear effort, capacity exhaustion, attack/reload exclusion,
free-stop fallback and collision wake-up are integrated. The earlier geometry
sprint remains unchanged. [CROUCH_SPRINT.md](CROUCH_SPRINT.md) distinguishes
source rules from delegated timing, hand-pose and interruption choices.

Contact during a stop preserves its original completion time and remaining
projected slide. It does not restart sprint or charge the stopping interval as
sprint effort. Fractional status-expiry residuals below the representable clock
increment are cleared to prevent zero-time loops. Existing historical trace
packages continue to match. [Sprint results](results/sprint-combat/REPORT.md)
include the mixed gun encounter and the relevant capacity/contact edge cases.

## Basic jump extension, 2026-10-27

The optional [combat jump definition](data/movement/combat_jump.json) adds
Active-start takeoff, independently evolving airborne motion and actual landing
to the same coordinator. Upward speed is half base running speed and horizontal
velocity is retained. In the frozen exclusive scheduling input, the 100 ms
Gathering and 150 ms Active share occupancy with weapons; Active completion
does not end flight. Current declared ownership permits eligible gunfire during
jump Gathering/Active too. Ground movement intents still wait for landing and
their required resources. See [ACTION_OWNERSHIP.md](ACTION_OWNERSHIP.md).

Jump costs/self statuses, physical landing penalties, airborne resource
recovery, full 3D directional contact, projectile interaction and death now
execute together. [JUMPING.md](JUMPING.md) records the source values, delegated
anchors and limits. Collision-induced lifting also uses the flight path without
charging a jump or inventing jump self effects. Ground support constrains
downward projection. Tiny post-projection velocity components are cleared to
prevent false repeat contacts after status expiry.

[Jump combat results](results/jump-combat/REPORT.md) include running jump with
airborne fire and a queued stop, cube contact, an actual airborne limb hit, and
death with a released shot still traveling. Historical result packages retain
their explicit definitions and exact traces. Fixed facings/upright bodies,
finite-footprint restrictions and gun-only moving combat still apply. Crouch,
climb, turning, prone/Get Up geometry, moving areas and full kit integration are
subsequent work.

## Crouch/stand extension, 2026-10-27

The optional `posture` section of the combat locomotion definition joins the
approved changing cuboids to this coordinator. Both projectile models account
for per-part translation and linear size changes; hand origins lower with the
upper body. Posture actions share eligibility, costs/statuses and death with
combat, while steady pace and released effects persist. Crouched jump uses the
same retained momentum, foot-plane contact and landing effects.

Current occupancy checks permit exact standing clearance. New solid contact
freezes the reached partial pose and invalidates completion, then applies the
existing physical response. Reference height is separate from recentered body
origin; hand state remains canonical for Recovery. Sprint payments reanchor
effort, and exhaustion interrupts posture through the existing single cap event.
[CROUCH_SPRINT.md](CROUCH_SPRINT.md) records author rules versus delegated choices.

[Four demonstrations and replay](results/posture-combat/REPORT.md) and 25 added
checks verify the integration. **874 tests pass** and all 15 previous compact
replay cases retain complete traces and summaries. Climbing is next; fixed
facing, finite-footprint restrictions, gun-only moving combat and incomplete
remaining spatial actions/kits continue to bound this checkpoint.

## Current world, command and climb corrections, 2026-10-28

`combat_locomotion.json` declares `world.ruleset=integrated_v2` and 9.81 m/s²
body gravity. Support/flight physics is immutable across the encounter and
independent of future commands. Jump/climb definitions describe actions; current
CLI loading no longer scans commands to select body physics. Frozen rule inputs
without `world` use an explicit historical adapter; the CLI requires
`--historical-airborne` to select flight with those old inputs.

One iterative dispatcher owns typed intents and compound prerequisites. Every
queue-head change reselects the action handler; a no-op cannot bypass jump,
posture, sprint or target-bearing climb dispatch. Physical blocking finishes the
parent intent once; a new explicit command can retry. No artificial small time
delay is used. Phase/resource calculations remain modular and return explicit
outcomes. The subsequent ownership increment below removes the temporary
single-slot restriction for current action types.

## Declared action ownership, 2026-10-28

Current inputs declare separate hand/weapon/locomotion resources and required
upper/lower/attack functions. Gun/reload can overlap eligible ground transitions,
jump and posture. Sprint transitions and climb retain hand/body occupancy;
steady sprint retains its weapon prohibition. Phase processing and contacts bind
the relevant action ID, payments reserve capacity without paying early, and
selective restrictions cancel only actions requiring affected functions.
Incoming and parallel self O extend unfinished Gatherings without adding a new
Gathering to Active. See [rules and delegated choices](ACTION_OWNERSHIP.md).

**943 tests pass**, plus the original review's five checks. Four new encounters
and their CLI replay match exactly; prior climb scenes still replay exactly
with frozen definitions. [Evidence](results/action-ownership/REPORT.md).
Frozen inputs without ownership retain explicit historical exclusive scheduling;
older scheduling descriptions in this document apply to those checkpoints.
Initial upper/lower restriction scenes test existing freeze conditions, not
1E3's unimplemented ability delivery. Other moving weapons/kits remain unfinished.

## Projectile entity extension, 2026-10-28

Physical flights now use entity IDs independently of their parent action,
with source/lineage, explicit contact policies and revision-based lifetime.
Default gun behavior is unchanged. Owner-enabled policies use whole-body
separation for birth immunity; the shared copy API preserves momentum, source
and actual distance rather than paying/refiring/reaiming. See
[PROJECTILE_ENTITIES.md](PROJECTILE_ENTITIES.md) for delegated choices and scope.

The complete suite now passes **980 tests**. One ordinary combat trace and three
explicit engineering probes replay exactly; the ordinary public CLI trace also
matches in full. [Evidence](results/projectile-entities/REPORT.md).
Actual 1E3/2E4 field/cast/secondary-attack delivery and dynamic world colliders
remain unfinished. Frozen traces retain a presentation adapter; the current
historical comparison classifies one additional obsolete-pending-stop correction.

## Fixed world entity extension, 2026-10-28

Current inputs resolve world objects through a shared registry: compound parts,
one HP pool, expiry, blocking channels, contact/clock revisions and source
attribution. Gun damage, creation/destruction, shape changes, posture clearance,
climb and actual support loss share the coordinator. Summaries distinguish
construct state from character damage. See [WORLD_COLLIDERS.md](WORLD_COLLIDERS.md).

**1022 tests pass**. Four ordinary encounters replay through the API and complete
public CLI: barrier destruction, expiry in flight, a hollow shell and disappearing
support. [Evidence](results/world-colliders/REPORT.md). These do not cast prison
or charge abilities. Dynamic area HP damage and moving heat/poison exposure still
require typed effects/volumes. Grounded ledge departure and moving-body support
remain guarded; source area-transparent cubes are unchanged.

Basic flight retains projected commanded drive independently of physical
velocity; landing cannot turn airborne U into extra pace. Nested hands and
locomotion are captured by value. Historical result files remain unchanged,
with known snapshot/format/diagnostic differences classified in the
[review response](PRINCIPAL_ENGINEERING_REVIEW_RESPONSE.md).

Climb now runs with the gun, resources, statuses, posture, sprint exit,
obstruction, gravity, support and death on this coordinator. Range is checked
once at Active start; movement continues through Gathering. The approved
up/across path has actual swept contacts rather than a teleport or fixed
recipient list. [CLIMBING.md](CLIMBING.md) records source rules and delegated
anchors; [four complete scenes](results/climb-combat/REPORT.md) replay exactly.
The climb checkpoint passed 906 tests plus the review's five unchanged tests.

## Typed heat-volume extension, 2026-10-28

Current moving combat also casts existing 1E1 ability 4. Controlled hand/function
ownership is separate from the independently deployed volume. Moving bodies can
enter, leave, cool and re-enter; each source/target/layer retains its own thermal
clock. Real gunfire changes current defenses, and damageable cover can burn away
mid-exposure. Fixed facings and earlier grounded ledge/Get Up guards remain.
[SPATIAL_EFFECTS.md](SPATIAL_EFFECTS.md) records the exact source/delegated rules.

**1066 tests pass** plus all five unchanged review checks. Six new ordinary
encounters match complete API/CLI traces; prior replays remain reproducible.
That checkpoint left heat/recovery coupling for its follow-up.
[Evidence and commands](results/spatial-heat/REPORT.md).

## Continuous heat/shield recovery extension, 2026-10-28

Current definitions now couple incoming heat with delayed recovery before finding
shield depletion. Zero stock consumes returning shield continuously; independent
incident/body memory preserves warm HP heat through reformation and cooling.
Consumed recovery retains its own delayed loss history. Moving exit, actual
gunfire changing defenses, caster death and recipient residual death run on the
same coordinator. [Rules and numerical limits](HEAT_SHIELD_COUPLING.md).

**Heat/recovery checkpoint: 1129 tests passed** plus the original five review checks. Seven ordinary captures
reproduce complete API/CLI traces; prior movement/collider/effect captures still
replay with frozen definitions. That checkpoint left pause/credit work for its
follow-up.
[Evidence](results/heat-shield-coupling/REPORT.md).

## Cooldown and attribution follow-through, 2026-10-29

[1E2's pause area](COOLDOWN_PAUSES.md) now delivers composable cooldown pauses
with actual moving membership. [Applied HP history](DAMAGE_LEDGER.md) now records
real point/continuous losses and immutable rolling windows on the same clock.
These preserve physical phase/effect timing and released ownership after death.
Healing payout and life generations/revival remain unfinished; remaining kits
still need actual delivery. [Current verification](ENGINE_STATUS.md).
