# Get Up

The author defines Get Up as a common ability used after knockdown, with
`Active = 2 × Recovery` and dyspnea equal to twice the character's jump value.
This rule is in `Details2.odt` paragraphs 4–10 and the author's instruction.
It does not add a new character-specific ability.

## Interpretation under delegated mechanics authority

On 2026-10-25 the author authorized implementation decisions and mechanics
changes for internal consistency, with minimal clarification requests. The
following choices resolve the previously unanswered Get Up questions:

- Recovery means the character's numeric Recovery attribute, in milliseconds
  for this formula. It does not mean a contextual hand-travel duration.
- Double the basic jump's **base** dyspnea value, then apply the existing
  action formula `Da = (Db + D/100)²` using current dyspnea `D`.
- Get Up starts Active directly, with no Gathering or additional hand Recovery.
  Capacity is checked and the cost paid at Active start. Insufficient capacity
  leaves the character knocked down without paying or beginning Active.
- Only a living, knocked-down character can use Get Up. The character remains
  down until Active completes. Get Up does not heal, revive, or erase statuses.
- Death cancels this controlled action. Death before payment incurs no cost;
  cancellation after payment does not refund that payment.

These are recorded implementation decisions under the new delegation; the
source document itself only supplies the ability purpose and two multipliers.
The later [equilibrium increment](EQUILIBRIUM.md) integrates the new source
fall-duration formula; it does not add a character attack or invent a status
threshold. Partial balance recovery cannot bypass paid Get Up after a full fall.

## Character values

| Character | Recovery | Jump Db | Get Up Active | Get Up Db | Cost at D=0 |
|---|---:|---:|---:|---:|---:|
| 1E1 | 200 | 1.5 | 400 ms | 3 | 9 |
| 1E2 | 200 | 1.5 | 400 ms | 3 | 9 |
| 1E3 | 250 | 1.5 | 500 ms | 3 | 9 |
| 1E5 | 200 | 1.2 | 400 ms | 2.4 | 5.76 |
| 2E4 | 150 | 1.2 | 300 ms | 2.4 | 5.76 |
| 3E5 | 150 | 1.2 | 300 ms | 2.4 | 5.76 |

[Profile data](data/movement/get_up.json) records the original Recovery and
jump inputs with source paragraph references. Values are derived rather than
storing independently editable copies of the computed durations/costs.

## Implementation boundary

[get_up_profile](combat_sim/mechanics/get_up.py) validates the selected profile
and returns exact rational duration and an Active-start dyspnea rule. The
existing dyspnea mechanism performs the capacity check/payment. This pure
helper does not schedule an action, change a hitbox, or generate knockdown.
The shared-engine integration and its scenario tests are recorded separately
in [PROGRESS.md](PROGRESS.md); six numerical profiles alone do not make all six
characters' full kits executable.

The current moving world enables Get Up automatically with the selected
equilibrium rules, deriving its profile from the actor Recovery and supplied
basic-jump definition. The CLI supplies current jump data automatically.
Historical `common_abilities: ["get_up"]` inputs still enable the earlier
stationary action with an explicit Get Up definition. An initial
`knocked_down: true` state exercises it in a scenario. The policy prioritizes
getting up before attacks, even if no enemies remain. The engine's
`apply_knockdown` effect entry point cancels the current controlled action and
invalidates its queued phases; reapplication during Get Up requires a fresh,
paid attempt. Already released projectiles and deployed effects persist.

Current balance rules use actual six-part prone geometry and shared clearance.
The Active linearly reverses balance/crouch progress; death, new explicit
knockdown or contact can interrupt it. Unchanged static cover waits without
payment; a failed paid attempt retains its cost. Native gravity/forces and
independent effects retain their own lifetimes. Restoration keeps the physical
pose, rejects old completion events and prioritizes recovery independently of
weapon-policy start. Definitions without the equilibrium mode keep the earlier
upright proxy for frozen-replay compatibility. [Geometry and decisions](EQUILIBRIUM.md).

The example [get_up_combat.json](scenarios/get_up_combat.json) starts one 1E1
knocked down. It gets up over 0–400 ms, pays 9 dyspnea, and then resumes its
existing projectile ability. No additional ability is created for the test.

Focused tests cover all six source-derived profiles, current-dyspnea costs,
insufficient capacity, payment phase, cancellation before payment, exact
arithmetic, output isolation, and invalid definitions.

The current [prone demonstration](scenarios/prone_get_up.json) uses 1E3's
500 ms Active and 9-dyspnea payment on the shared moving-world geometry.
The [real Block-counter encounter](scenarios/equilibrium_counter.json) causes
source-rate balance loss and automatic paid recovery without an injected
knockdown. [Current evidence](results/equilibrium/README.md).
