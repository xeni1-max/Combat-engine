# Fixed initial actor headings

2026-11-13. Shared combat now admits a fixed initial yaw for each actor, using
the same exact [frame/shape geometry](ORIENTED_GEOMETRY.md) and
[native material paths](ORIENTED_WORLD.md). Verification is recorded in
[this increment](results/actor-facing/README.md). The overall Goal is active.
Timed [whole-body turns](TURNING.md) still need continuous angular prediction
and owned control; accepting an initial frame does not execute a turn.

## Inputs and retained contracts

Legacy `"facing":"+x"` and `"facing":"-x"` keep their original representation,
axis-aligned branches and saved outputs. Current finite-face mobile combat
also accepts `"facing":{"yaw_degrees":37}`. Heading zero faces +world X;
positive angles proceed toward +world Y. Input angles select an immutable
rational unit frame at declared engine precision. Reported facing contains the
actual `yaw_frame` coefficients. Earlier rulesets retain their explicit guard.
No heading is inferred from targets, and NPC intelligence is not expanded.

The following extensions are delegated engineering decisions. All six source
characters, abilities, dimensions, timings, costs and primary ODTs remain.

- Body parts retain local right/forward/up dimensions. Their centres and true
  oriented shapes rotate together, through standing, crouch, prone and Get Up.
  Full-size pose derivatives remain local; centre derivatives are world
  vectors. Exact finite-difference checks cover concurrent quadratic balance
  and crouch deformation. The body origin is the rotated local envelope's
  centre, preserving covariance for asymmetric prone poses. Upright reference
  translation remains owned by the existing shared writer.
- Hands, constrained reach, Recovery, projectile/melee origins and Block use
  that frame. Block retains local width/thickness/height and its actual frozen
  frame after detachment. Owned attack volumes transform local offsets and
  anchor fractions before world translation. Forward ordering and charge-front
  tests use heading projection. Existing leap, dash, charge and coincident-
  target knock fallbacks use forward heading.
- Default walking/running direction begins at the supplied heading. Explicit
  `movement_direction` remains a world vector independent of heading. External
  knock, collision projection, support loss and transport do not invent body
  steering. No speed-sampling policy for a future turn is implied.
- Support and retained dynamic-body planes use real projected footprints and
  normals. Contact cache dependencies retain the actual frame and local sizes.
  Different local resizing channels cannot cancel merely because their
  untransformed coefficient tuples add to zero. Occupancy/restoration uses
  true narrow-phase overlap when either body/material is oriented. The old
  early revival AABB precheck is migrated too, preventing an empty enclosing
  corner from blocking an otherwise valid new life.
- The finite zero-thickness floor is checked through its declared crossing/
  contact band once by spatial preflight. It is excluded from the later solid-
  volume overlap pass and restoration's early solid check. This keeps tiny
  within-band contact valid for both cardinal and oriented bodies while real
  sheet crossing still rejects atomically.
- An implicitly aimed 1E2 fence uses its selected actor's local lateral axis
  and freezes that frame with the target snapshot. The five panels retain
  their dimensions, HP, immunity, binding and autonomous duration. Explicit
  world `axis:"x"`/`"y"` still overrides that default; all legacy inputs retain
  their old axis behavior. Panel and field records retain the actual frame.

Frames and shapes stay constant in yaw over a saved prediction interval. Pose,
flight, effects, constraints and translation keep their existing ownership.
Released trajectories and deployed/frozen geometry retain their own source
life and snapshot rules. Restoration retains actor heading while retiring the
old controlled work. No new character ability, animation or global resource
exclusivity is introduced.

## Next boundary

Add owned timed turning using the author's rate, with documented sampling,
steering and interruption policy. Continuous rotation changes part-centre
paths, directions and projected dimensions; fixed-frame quadratic queries alone
do not certify an angular sweep. Preserve one translation writer and verify
thin obstacles, pose/support boundaries, held/owned/released geometry,
grapples/tethers, death/revival and numerical/CLI/hash controls before admitting
that command. Prescribed linked climbing and final current cross-kit/5v5 work
also remain; advanced NPC, mass experiments and balancing are deferred.
