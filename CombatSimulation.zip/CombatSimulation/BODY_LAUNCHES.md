# Ballistic body launches and the existing dash abilities

The later [existing leaps and falling kick](LEAPS.md) reuse this body writer:
15/20 m/s total takeoff speed, source jump/landing effects and distinct launch
control. 3E5's controlled descending foot volume reads actual saved-path vertical
motion, including grapple/tether changes. The original dash evidence below
retains its historical scope. Current verification is indexed in PROGRESS.md.

The subsequent [1E2 grappling gun](GRAPPLING_GUN.md) reuses this native body
writer with a Decimal fastest arc toward a witnessed terrain anchor. Explicit
non-upward launch is allowed for that trajectory. New contact obligations are
life-bound and additive, survive external velocity/reference changes, and are
consumed once at actual translation contact. A later voluntary launch preserves
earlier jump/dash landing obligations. Generic fixed-distance end observers
release hook control at the actual anchor end while momentum remains physical.

Implemented in the shared combat world, 2026-11-01. This delivers 1E5 ability 3
and 2E4 ability 3 through the same action, resource, cooldown, contact and life
systems used by attacks and basic movement. It adds no character ability.
[Launch mathematics](combat_sim/mechanics/body_launch.py) ·
[Cast coordinator](combat_sim/body_dashes.py) ·
[Shared flight/landing](combat_sim/airborne_combat.py) ·
[Evidence](results/body-dashes/README.md).

## Primary definitions

`1E5.odt` p11/p87–p100 specifies 13.5 m away, 5.2 s cooldown, Gathering
140 ms, Active dash 150 ms, Db2.5, intrinsic momentary effort, takeoff self
O80/U80 and landing self O120/U160. `2E4.odt` p7/p83–p96 specifies the same
timings, cost, classification and statuses, with range 14 m and cooldown
2.85 s. The texts name jumping and landing; they do not supply a vertical
speed, direction input, trajectory, payment instant or cooldown anchor.

The author confirmed gravity 9.81 m/s² and basic jumping's upward initial
speed of half base running speed, applied at Active start. Those confirmations
are about basic jumping. Applying that upward-speed rule to dash is the
delegated choice below, not an additional author statement.

## Delegated trajectory and controls

Dash launches ballistically at Active start with `up = base_running_speed/2`.
For nominal same-height range L, `T = 2*up/gravity` and horizontal speed
`L/T`. A standing 1E5 launches at 3.5 m/s upward and approximately
18.9192857 m/s horizontally, returning to its launch height after about
713.558 ms and covering 13.5 m in unobstructed level geometry.

The 150 ms Active is the launch-control phase, as with the existing basic
jump; it is not a forced landing timestamp. Gravity, continuous body sweeps,
terrain and grapple constraints determine actual travel and landing. A ceiling
can shorten flight. A wall removes only the collision-normal component.
There is no range teleport, fixed-tick hit or invented attack damage.

The current simple policy uses the requested enemy's position saved at cast
request: 1E5 moves away from it; 2E4 moves toward it. Launch freezes the
horizontal direction using the actor's actual takeoff position. A coincident
point uses the fixed body facing as the forward fallback. Death of that enemy
does not retarget the already requested cast. This small policy keeps advanced
aiming/NPC decisions separate from movement physics.

The ability supplies total horizontal launch speed, rather than adding that
speed to walking/running momentum and exceeding its advertised nominal range.
The prior independent ground pace resumes on landing, after contact constraints
and current instability. Sprint is replaced by running at launch; its filling
ends at that boundary. Dash is movement, so sprint's weapon restriction does
not prevent it. No extra sprint-exit gesture/cost or special-stop slide is
invented for a movement program replaced by the dash itself.

The launch owns locomotion and requires lower-body function. It retains hands
without fabricated poses or Recovery. Compatible upper-body attacks, held
effects, enhancements and grapple contests keep their own owners. Gathering
still receives current O and the existing running multiplier. Takeoff and
landing self effects use the same running self-effect policy as basic jump.
Instability's damage-output formula is not repurposed to subtract launch range.

## Payment, cooldown, flight and life

[3E5's conditional counter](CONDITIONAL_MELEE.md) now reads a separate internal
dash motion cause on the actual flight. A reference-only relocation preserves
it, while external velocity replacement clears it. The landing obligation can
remain owed after that replacement and does not itself make a body "dashing".

Db2.5 is checked/paid once at Active start through the existing shared payment
gate. Cooldown starts there after successful payment, including launches which
later hit an obstacle. A failure of capacity, lower-body function or actual
support before takeoff emits no launch and starts no cooldown. The ordinary
policy only admits a new dash from actual static support; it cannot chain
another dash in midair after the 150 ms control ends.

Launch and physical flight are separate lifetimes. An immutable landing
obligation retains actor life, ability, action and base O/U in the flight state.
It is consumed once at real support contact, including a cube top. Cancelling
control after takeoff does not erase that already incurred obligation or stop
gravity. An external spatial change preserves it, even when the new destination
has support: the ordinary contact pass resolves that support before landing
effects are applied. Death retires the flight; revival cannot inherit the old
obligation. A new successful dash gets a different action/landing identity.

`launch_body` is also used by basic jump, keeping a single flight writer and
existing basic-jump traces. Generic forced flight acquires no dash cost or
landing effects. The external spatial transaction remains responsible for
interrupting body control; voluntary launch does not cancel its own owner.

## Grapples and remaining displacement work

A voluntary dash changes its actor's independent drive. The existing grapple
coordinator projects that drive once with the others, preserving common
translation/gravity and individual landing effects. Linked contacts restore the
dash actor's prior ground drive rather than turning its launch speed into
permanent ground propulsion. Other participants gain no fabricated dash cost
or landing self effects. Normal hold fatigue/Break/death causes still apply.

This is different from a knock imposed on the entire linked component: that
uses the author's summed maximum-HP/current-armor resistance and one imposed
group motion, without another weight division. [Confirmed rules](KNOCKBACK.md).
[Actual 3E5 heavy-punch knock/elasticity](KNOCK_DELIVERY.md) now uses those
physics, including a real jumper bouncing before its eventual landing. Other
knocks, 3E5's directed leap/kick and charge/wall-slam, binding and portals remain
unfinished. Existing ledge/dynamic-support/facing/
prone/Get Up boundaries remain explicit; complete kits and general 5v5 are not
claimed from these two newly delivered abilities.
