# Combat mechanics audit and initial scope

Audit date: 2026-10-24

**Author revision notice, 2026-10-31:** current 1E5/2E4 passive/enhancement
definitions supersede older source descriptions below. See the exact
[source changes](SOURCE_UPDATES_2026-10-31.md). Shared
[Block/charge defenses](BLOCKING.md) now execute; the original audit retains
its historical scope.

Current capability status is maintained in [ENGINE_STATUS.md](ENGINE_STATUS.md).
The older source-only entries below retain their audit scope. In particular,
[2E4 melee/venom](MELEE_VENOM.md), [actor lives](LIFE_CYCLES.md) and
[actual revival](REVIVAL.md) and [passive healing](HEALING.md) now execute in
shared combat under documented delegated decisions.

The latest full-source review is in [CONSISTENCY_REVIEW.md](CONSISTENCY_REVIEW.md). It records current conflicts, prioritized questions, numerical probes, and technical fixes; previously reported 2E4 piercing/sprint gaps are resolved below.

## Source precedence

The thirteen ODT files at the workspace root, outside `reference_material_non_authoritative/`, are the primary mechanics and character data for this work. **Author clarification, 2026-10-25:** `reference_material_non_authoritative/` is optional background material, not the project being implemented or an authoritative mechanics source. Ideas from it require author confirmation before becoming simulator rules; it does not fill gaps in the primary specifications. Historical differences are recorded below; its alternate values are not substituted for root-level values. The user announced revised dyspnea rules and added root `Details2.odt` and `2E4.odt` on 2026-10-24; these are included in the current primary set.

The user's clarifications are authoritative alongside the priority documents: shields absorb raw damage first; only overflow enters HP formulas; fully shielded hits do not reduce armor, while target effects still go through and receive mitigation before addition. HP/armor and adjusted defenses have zero minima. Running modifies base Gathering by 20% before adding current disorientation. The latest author override explicitly exempts self disorientation/instability from all HP, armor, and additional-resistance mitigation; running still increases their listed amounts by 20%. This supersedes the preceding self-mitigation clarification. Shield bonuses must be explicitly stated. Venom factors each floor before multiplication. 1E5 self effects use impact; projectile firing/throwing self effects use Active midpoint.

No combat code existed in the supplied workspace when this audit began. This audit records both the original source review and later user clarifications; implemented portions are identified in the registry and stage notes below.

## Notation conventions

The user permits renaming symbols for clarity in both documents and implementation. A symbol is interpreted within its formula, section, and source document. Reusing a letter alone is neither a rules conflict nor a reason to block implementation.

For example, `d` meaning pre-mitigation damage in both Blunt and Slash is valid: each calculation supplies the damage for its own attack. Where the same symbol denotes different quantities, implementation variables and explanations use descriptive, distinct names. Source references retain the original symbol and section so the mapping remains traceable.

Aliases preserve the documented formulas, units, timing, and interactions. An undefined meaning or a contradictory mechanic still needs to be recorded and clarified; permission to rename symbols supplies no missing values or attack-to-formula relationships.

## File inventory

The original audit counted 71 ODT files and one HTML file. The current primary set contains fourteen root ODTs, including the author-added `Grapple abilities.odt` (2026-10-29):

- Character and ability profiles: `1E1.odt`, `1E2.odt`, `1E3.odt`, `1E5.odt`, `2E4.odt`, `3E5.odt`.
- Shared mechanics: `Binding abilities.odt`, `Grapple abilities.odt`, `Collision details.odt`, `Contextual abilities.odt`, `Damage types.odt`, `Details.odt`, `Details2.odt`, `Dyspnea details.odt`.

At the original audit, the optional reference directory (now `reference_material_non_authoritative/`, formerly `Game project 1.4/`) contained 58 secondary ODT files and one HTML file: 50 numbered enemy/profile and detail documents plus eight general/player documents (`Basic enemies`, `EnemyShortDescriptions`, `Items`, `p1`, `p3`, `p4`, `p5`, `pdetails4`), and `spawned-space-return-to-a.html`. The remaining numbered profiles cover sparse entries for teams 1–11 and available `Edetails` documents. The current root files are counted only in the primary set.

No implementation, test, or build files existed when the initial audit began; the current code and tests are outputs of the later stages below.

## Primary mechanics extracted

### Damage formulas

The equations below are transcribed from embedded MathML in root `Damage types.odt`; simple text extraction omitted these objects.

| Damage type | Documented formula and variables | Source section |
|---|---|---|
| Blunt | `y = (d² - a²) / d`; `Ar = (d² - a³/700) / (50d)`. `d` is pre-mitigation damage, `a` armor, `y` post-mitigation damage; `Ar` is armor reduced per attack. User clarification: negative `y` and negative armor loss clamp to zero. | `Damage types.odt`, “Blunt”; user clarification |
| Slash | `y = (d² - (a-p)²) / d`; `b = y(8-tb) / 320`. Slash applies bleeding which decays over 8 seconds; `p` is piercing and `b` bleeding damage per second. Slash also gives the same `Ar` formula above. | `Damage types.odt`, “Slash” |
| Constriction/tearing | `y2 = (((4/25)d2² - a²) / d2) × (25/4)`; `Ar2 = (((2/5)d2)² - a³/700) / (8d2)`. `d2` and `y2` are damage per second; `Ar2` is armor reduced per second for some attacks. | `Damage types.odt`, “Constriction/tearing” |
| Venomous | `Td = ((d² - (a-p)²) / d²) × ((Tp² - 10(RT-p/5)²) / Tp) × sqrt(tT-to)`. `Tp`, `tT`, `Td`, `RT`, and `to` are described as toxicity, exposure time, toxin damage per second, toxin resistance, and non-exposure time. The Venomous section does not redefine `d`, `a`, or `p`; the author confirms d means slash damage after shield, before armor mitigation, while a is captured before the thrust/armor loss and p is piercing. | `Damage types.odt`, “Venomous”; `Blunt` and `Slash` variable definitions |
| Poisonous | `Td = ((Tp² - 10RT²) / Tp) × sqrt(tT-to)`. Poisonous attacks are gas attacks applying toxin damage for a duration. | `Damage types.odt`, “Poisonous” |
| Heat | `hd = ((ho² - (a²+Rh²)/2) / ho) × kth-root(th - k×to2)`. `ho` is heat output; `th` and `to2` are heat exposure and non-exposure times; `Rh` is heat resistance; `k` is based on heat area and is at least 2. | `Damage types.odt`, “Heat” |
| Electrocution | `de2 = (de²-Re²) / de`, with `de` and `de2` pre- and post-mitigation damage per second and `Re` electrocution resistance. | `Damage types.odt`, “Electrocution” |
| Qard | Instant: `dq2 = (dq² - (a/2+Rq)²) / dq`. Continuous: `dq4 = (((4/25)dq3² - (a/2+Rq)²) / dq3) × (25/4)`. | `Damage types.odt`, “Qard” |

Author clarifications add these floors to the source equations: adjusted armor/resistance floor at zero before squaring; venom's delivery and toxin factors each floor at zero before multiplication. Thus the implemented venom rate is `max(0,(d²-max(0,a-p)²)/d²) × max(0,(Tp²-10×max(0,RT-p/5)²)/Tp) × sqrt(tT-to)`. Two negative factors cannot yield positive damage. The author also confirms venomous attacks always contain a slash delivery component: the first factor equals its post-armor/pre-armor damage ratio, with both values after shield absorption. Fully absorbed d=0 means delivery=0 and toxin damage=0, rather than division by zero.

No general valid-input range is specified for these formulas. User clarification establishes a zero floor for negative damage and armor-loss outputs. Several equations still have zero denominators or fractional powers with potentially invalid inputs, so those cases need explicit handling before broad use.

### Collision effects and movement

The author's 2026-10-29 clarification defines attack categories by controlled
character effort and whether that effort is sustained. Effect duration is
separate: 1E1's independent beam has extrinsic momentary activation. See
[ABILITY_EFFORT.md](ABILITY_EFFORT.md) for primary phase labels, their separation
from legacy damage-routing flags, and unimplemented general interruption rules.

Root `Collision details.odt` documents:

- Disorientation decays as `O(t)=Ok-t` with `t` in milliseconds. Added gathering is `J=O`; accuracy loss is `L=O/100` centimeters radius per meter range. During additional gathering, the latest ability has priority.
- Instability decays as `U(t)=Uk-t`. Intrinsic momentary damage reduction is `M=U/10`; movement-speed loss is `K=U/200` m/s; intrinsic sustained damage-per-second reduction is `M2=5U/20`.
- For disorientation and instability, `N2 = N - (H/500 + a/10)^1.1 - R`, with `N2` described as minimum 0. `H` is maximum HP, `a` current armor, and `R` additional resistance.
- Knockback mitigation is `P2 = P - (H/500 + a/10)^1.1 / 150`.

Root `Details.odt` documents the movement-speed modifier `M(θ)=θ²/270-30` for `0 ≤ θ ≤ 90`, symmetry through 180 degrees, a 30% speed loss when running outside that angle range, and slide mitigation `S2 = S - (H/500 + a/10)^1.1 × 1/250`.

Baseline additional R=0, target mitigation-before-addition, additive accumulation, and zero decay floors are confirmed. Target effects pass through shields, with only expressly stated shield bonuses. Self disorientation/instability bypass mitigation under the latest author override, retaining the running +20% increase. The preceding mitigation-before-running self rule is historical, preserved in the previous stage snapshot.

Historical fixture: Active completed, then self-disorientation 80 was added, then the next Gathering began at that same timestamp. The revised 1E5 source now specifies self-disorientation/instability 150 each on impact. The former boundary order is preserved only in an explicitly historical reference.

The timing helper accepts `disorientation_at_gathering_start` and `is_running_at_gathering_start`; running modifies base Gathering only. Current O=80 and base 140 while running give 248 ms. A listed self 80 becomes 96 while running, giving 264 ms Gathering when supplied as current O. `self_status_value` computes the unmitigated amount and `apply_self_status` stacks it. Controlled 1E1 and 2E4 execute stationary self/target statuses and decay; the legacy Blunt runner does not.

### Dyspnea

**Current author clarification, 2026-10-28:** dyspnea represents physical effort.
Effortless extrinsic activation, summons, area marking, passive and automatic
enhancement effects do not require a cost number. Eight confirmed examples are
recorded in [DYSPNEA_POLICY.md](DYSPNEA_POLICY.md) and source metadata, including
2E4's revival. Their explicit exemption bypasses the action formula; Db=0 would
still cost dyspnea when D>0. Recoil control and other documented physical effort
retain their own values. Missing numbers on effortless effects are not blockers.

Root `Dyspnea details.odt` documents:

- Current dyspnea `D` has a maximum of 100.
- Per-action value: `Da = (Db + D/100)^2`, where `Db` is the base dyspnea value for the action.
- Continuous-action value per second: `Dc = (Dd + D/100)^2`, where `Dd` is the base dyspnea value per second for the action.
- Walking or staying in place loses 30 dyspnea per second; running loses 18 per second.
- No dyspnea is lost while disoriented, unstable, on a grapple ability, in an ability's Active phase, gathering, recovering, or sprinting. Each listed condition independently blocks loss, including when movement would otherwise permit it. The user explicitly confirmed this reading after announcing the document revision.
- An action cannot happen if the “empty” amount of the dyspnea bar is less than its action value.
- Reaching maximum dyspnea gives 200 disorientation.

The six primary character profiles contain per-action dyspnea values and say sprinting gains 2 dyspnea per second. The user confirmed that sprint's base 2 is `Dd`; the profiles' per-action values have not been explicitly mapped to `Db`. `Details.odt` says running, jumping, climbing, sprinting, dodging, and some attacks fill dyspnea. `Binding abilities.odt` still describes reversing an old 20/s loss into filling while breaking free; its specific filling rate needs reconciliation with the revised general recovery rules.

The user's action/cap clarifications remain: available capacity is `100-D`; an allowed action adds `Da`; reaching 100 emits one 200-disorientation trigger per crossing. The revised document supersedes the previous uniform 20/s loss and the earlier clarification that this loss continued while sprinting. That superseded combination caused a net sprint loss of 11–16/s. With the revised sprint loss of zero, `Dd=2` produces a positive gain of 4–9/s over the bar's range, resolving that conflict.

The maximum-dyspnea trigger is a self effect and bypasses mitigation: its helper adds 200, or 240 while running, to existing disorientation. Defense arguments were removed so callers cannot imply resistance affects it. Encounter cost/cap scheduling remains outside this stage.

Helpers now require an explicit `DyspneaContext`. Recovery blockers override movement rates. The continuous solver uses `dD/dt=(Dd+D/100)^2-L`, where `L` is 0, 18, or 30 for that context, and evaluates its closed form at 50-digit Decimal precision. Treating `Dc` as an instantaneous rate that changes with `D` remains a labeled implementation interpretation. A context must stay unchanged during a helper call: the caller splits at movement/phase changes, status expiry, or new effects. Unknown movement recovery rates are rejected when unblocked; a known blocker still gives zero without assigning an unknown movement a rate. The shared stationary team scope schedules its selected status/phase boundaries; movement and continuous-action encounter integration remain outside that scope.

### Damage-based healing and revival

Root `Details2.odt` explicitly excludes shield damage when an ability heals for a percentage of damage dealt or revives with HP based on damage dealt. The pure helper implements `eligible = total damage dealt - shield damage dealt`, then `entitlement = eligible × fraction`, for explicitly supplied credited totals. It does not define which other damage contributions count, create a damage history, apply HP caps, or change life state.

For `2E4`, basic ability 10 uses a 20% fraction; ability 5 uses 100% of eligible damage in the previous 10 seconds. The general 90%-of-damage-taken-in-8-seconds healing cap in `Details.odt` still needs to be applied by a future healing implementation. The meaning of overkill, armor loss credit, history boundaries, and revival HP limits remains unspecified.

### Binding, timing, and general rules

- Root `Binding abilities.odt`: a bound character can use Break; while breaking, dyspnea changes from emptying at 20/s to filling, and disorientation pauses that filling. Its old 20/s reference is retained as a source disagreement with revised `Dyspnea details.odt`; the Break-specific filling rate is not silently changed. The break threshold is `A=(20B-H/500)^0.9`, where `B` is binding value and `H` target maximum HP. Binding types can have different effects; a full freeze permits only attempts to break out.
- Root `Details.odt`: Gathering precedes the first Active phase. Recovery repositions the hands from the preceding attack's ending position to the next attack's required starting position before its Gathering. Recovery value is explicitly in ms/m: `Recovery time = Recovery value × repositioning distance`. The document's example is `200 ms/m × 0.6 m = 120 ms`. Coincident positions produce zero Recovery.
- The six primary character profiles include release points for several projectiles: at the end of firing or immediately after a throw. Current projectile impact profiles require distance and add travel time after release; the author removed the former distance-free fallbacks. Archived inputs can reproduce an explicitly supplied historical fallback. 2E4 ability 4's separate owner-contact attack remains outside these executable impact profiles.
- The user clarified that acceleration affects projectile travel time. The profiles give speeds/velocities and, for two `1E2` shots, acceleration `-300 m/s²`, but do not provide a travel-time equation. The implementation treats listed velocity as speed at release, treats acceleration as constant along the travel direction, and solves `distance = initial speed × time + 1/2 × acceleration × time²` for the earliest outbound arrival. These are recorded as implementation assumptions. `target_distance_m` is treated as path length from release point to target; distances beyond the resulting stopping distance are rejected instead of inventing a continuation rule.
- The user also clarified that event times may be rounded up to integer milliseconds. Midpoint and projectile travel calculations use ceiling to the next whole millisecond.
- `1E2` ability 4's missing Active firing duration was clarified as 60 ms. `1E1` ability 3 and `3E5` ability 3 now have explicit contact triggers, but the time of falling target/ground contact still depends on movement and scenario geometry. That event time must be supplied until the movement model can calculate it. Cooldown start rules are stated only on some abilities.
- Root `Details.odt` says friendly fire is on; healing is capped at 90% of damage taken in the previous 8 seconds; sprinting prevents attacks; running increases gathering, recovery, self-disorientation, and self-instability by 20%; and a block can stop up to 800 damage for 250 ms while adding resistance. These are partial rules, not a complete implementation specification.

### Hand positions, straight-line Recovery, and alternating arms

The user confirmed that repositioning distance is a straight line, using three-dimensional coordinates relative to the centre of the acting character's hitbox. Positions are measured in meters to match the documented ms/m Recovery values. Within one consistent local frame, a hand's distance is `sqrt((x_next-x_previous)^2 + (y_next-y_previous)^2 + (z_next-z_previous)^2)`. Axis directions must be documented consistently when pose data is supplied.

The consecutive-use rules in 1E5 ability 1 and 3E5 ability 1 specify alternating arms with zero Recovery. 1E5 names a/b; 3E5 names right b/left c. Initial component choice, sequence resets, and unused-hand updates remain unspecified. Self effects bypass mitigation; intrinsic same-impact damage ordering remains open.

The user selected one logical ability with two hand-specific components as the representation for these attacks. Each component identifies its attacking hand and its required start/end pose information. For the two abilities above, the stated intent is to alternate the selected component across consecutive activations; a component definition alone does not mean both attacks occur in one activation. Existing common ability rules remain attached to the ability, and the alternating-component Recovery exception is explicit. No component or limb scheduler is implemented yet.

The pose of the unused hand matters for the third and later attacks in an alternating sequence; any return during the other arm's attack should be explicitly defined. The documented zero-Recovery exception remains authoritative without inventing a return trajectory. Other abilities that execute several components within one activation need their own timing and hand requirements; the chosen data representation supplies no implicit parallel or sequential execution rule.

Current `1E5.odt` ability 1 defines a as left-arm 440 damage and b as right-arm 440 damage, slash, base Gathering 140 ms, Active 180 ms, midpoint impact, target status 150 each, **self status 150 each on impact**, and listed dyspnea 1.8. Next Gathering starts immediately after previous Active during alternation. The revised values and trigger are imported; full component combat remains unimplemented.

Historical arithmetic reference: self 80 after Active gave impacts 230/630/1030 ms. The current source lists self 150 on midpoint impact. Under the latest exemption, it applies as 150 while stationary, leaving 60 after the remaining 90 ms of Active. Next base Gathering 140 becomes 200 ms; isolated impacts are 230 then 610 ms. While running self 150 becomes 180. The preceding 34.50388132 mitigated result is superseded. These are status/timing checks, not complete 1E5 combat.

The source Recovery rule measures hands. Foot coordinates can be recorded for future mechanics, but their contribution to Recovery has not been defined. The later stationary-2v2 clarification establishes overlapping individual hand Recovery times; the longest required time controls. Poses and execution rules for broader kits, including 1E5's additional arms under Ultimate, remain incomplete. The earlier scoped runners do not execute physical Recovery; the stationary team scope does.

**Stationary-2v2 source update, 2026-10-25:** the current primary 1E1/1E2 documents
now supply initial hand positions, 200 ms/m Recovery, and start/end poses for
1E1 projectile/beam and 1E2 gunfire. These data are imported in
`data/characters.json`. The author subsequently supplied reload's right-hand
start (0.15, -0.25, -0.2) and end (0.05, 0.25, 0.1), and confirmed that individual
hand recoveries overlap: the total is the longest required hand time. These are
also imported and their Recovery scheduling is integrated in the shared team scope.
[STATIONARY_2V2_SPEC.md](STATIONARY_2V2_SPEC.md) records these current
values and the author's confirmed nearest-living-enemy policy, inclusive
position-centre area checks, Db values (projectile/gun 2, reload 0.5), beam dyspnea
exemption, per-shot after-Active gun cost, death cancellation/persistent summons,
and proportional simultaneous shield allocation with pre-hit defenses.
These rules now execute in the shared stationary team scope, including hand
Recovery, action eligibility, area geometry, death and delayed shield recovery.
The tentative idea
of exempting other summons has not been adopted as a general mechanic.

**Dyspnea payment clarification, stationary 2v2:** the author confirms that Qard
and gunfire calculate/check/pay their action dyspnea at firing end; reload does
so at Active start. Death before payment incurs no cost. The recorded action
rules and phase-payment helper implement these anchors in shared stationary team
scheduling. No refund of an already-paid cost is
inferred from this clarification.

**Final 2v2 boundary clarifications:** at the exact timestamp Gathering completes,
Active has already begun before an incoming hit; a projectile due to release
releases before a same-time lethal hit. An attack already in progress finishes
toward its original target location if that target dies. New actions select the
nearest living enemy. These are implemented and tested alongside common pre-hit
defenses, proportional shield allocation, and persistent released/deployed
effects after source death. The earlier duel retains its original scope/trace.
See [the current 2v2 specification](STATIONARY_2V2_SPEC.md) for remaining
boundaries, notably shield regeneration overlapping ongoing heat.

The usable timing notes in the six primary profiles are recorded as follows:

| Profile | Impact timing documented in the profile | Remaining boundary |
|---|---|---|
| `1E1` | Abilities 1, 2, and Ultimate release at the end of firing/throwing and require distance-dependent impact. Speeds are 100, 30, and 60 m/s. Ability 3 landing is ground contact. Ultimate lists an initial 300 ms weapon swap before Gathering. | Former end-of-Active fallbacks were removed. Flight time and ability 4 effect start remain unspecified. |
| `1E2` | Abilities 1, 3, 4, and Ultimate release right after firing/throwing and require distance. Abilities 1/4 have initial speeds 900/1400 m/s and acceleration −300 m/s². Ability 3 speed is 40 m/s; Ultimate 60 m/s. Ability 4 Active firing is 60 ms. | All former impact fallbacks were removed; firing/throwing self effects occur at Active midpoint, not target impact. |
| `1E3` | Abilities 1/4 release at the end of firing; ability 2 right after throwing. Distance is required; speeds are 100, 60, and 100 m/s. | Former end-of-Active fallbacks were removed. Status/freeze/cube processing is outside the current damage stage. |
| `1E5` | a is left arm, b right arm, each slash damage 440, Gathering 140 ms and Active 180 ms with midpoint impact. Self status is 150/150 on impact; consecutive alternation has no Recovery delay. | The 230/630/1030 chain is historical only. Self effects bypass mitigation; intrinsic ordering, initial selection, reset, and Ultimate mapping remain open. |
| `2E4` | Ability 1 gathers for 140 ms and thrusts for 180 ms, with impact at the midpoint: 230 ms after action start. Ability 4 releases a 6 m/s projectile after 140 ms Gathering plus 180 ms release. | Only ability 1 has an executable impact timing profile. Ability 4 requires projectile contact with its owner before a separate 180 ms Active attack; that attack's damage anchor is missing. The 600 ms replacement-blade grab delay in ability 1 has an unclear anchor. |
| `3E5` | Abilities 1a, 1b/c, and 4 impact at Active midpoint. Ability 2 releases after throwing and requires distance (30 m/s). Ability 3 uses falling-kick/ground contacts. Ultimate impact is contact with the target. | Contact times require trajectory/geometry or explicit timestamps; Ultimate no longer has a fixed midpoint impact. |

For midpoint timing, the event is at `action start + ceil(preparation + effective Gathering + Active/2)`. For a projectile, travel time begins at its documented release point. The JSON timing profiles record usable timing inputs from all six primary character profiles. All 11 current projectile profiles require an explicit distance; archived fallback fields are supported only when supplied by historical inputs. The self-effect timing helper calculates midpoint/impact anchors separately from applying statuses. Supported combat damage includes legacy `3E5` ability 1b, controlled `1E1` ability 1, and the controlled unshielded base `2E4` ability 1 with continuous effects. Other profiles' timing data does not imply their damage or effects execute.

### Six-cuboid body definition — current author clarification

The author specifies six cuboids per body: head, torso, left/right arms and
left/right legs. With local axes x right, y forward, z up, confirmed sizes in
metres are head (0.25,0.25,0.25), torso (0.5,0.3,0.7), each arm (0.1,0.1,0.8),
and each leg (0.2,0.2,0.8). The author selected fixed standing hitboxes for this
first model, independent of the numerical hand poses used for Recovery.

The author reviewed and approved the standing arrangement. Confirmed centres
and the whole-bounds origin are documented in [HITBOXES.md](HITBOXES.md),
with data in `data/body_hitboxes.json` and exact cuboid geometry helpers in
`combat_sim/hitboxes.py`. Team A faces world +x and team B world -x, fixed for
the stationary encounter. The author confirms a 4 m 3D sphere for the Qard
blast and 7 m vertical cylinder for the beam; they affect everyone eligible
in the area. These shapes now execute against actual cuboids in the explicit
body-collision scope. Qard launches from the ability's right-hand start pose;
gunfire from its left-hand start pose. Both aim at torso centre with initial
2 cm sphere radii stored per projectile. The earlier body-centre origin
suggestion was superseded by the author's hand-origin clarification.

Owner hitboxes are ignored; the first other living body is struck, including
teammates. Dead bodies stop colliding. Qard marks require actual collisions;
missed shots do not create a blast at an empty former target location. Sphere
sweeps retain rounded corners and are tested against an expanded-box false
positive. Areas apply once per eligible character at full strength; labels add
no headshot or limb multiplier. Earlier point-eligibility evidence is preserved
as its historical controlled scope. Ground/gravity are planned next; no gravity
value, ballistic aim compensation or terrain impact rule has been invented.

### Character and ability data available at the root

The root profiles provide concrete data for six characters: `1E1`, `1E2`, `1E3`, `1E5`, `2E4`, and `3E5`. All list HP, armor, running speed, some resistances, and a 4000-HP shield with a regeneration rule. They also list ability descriptions and, in varying detail, damage types, raw damage, timings, cooldowns, effect values, projectile speeds, ranges, or durations.

Useful initial candidate: `3E5` ability 1 right-arm component **b** deals 300 blunt damage and belongs to the alternating b/c chain selected when the target is not dashing or being knocked toward the attacker. Shared details give 140 ms Gathering, 180 ms Active, and zero Recovery between alternating uses. `1E1` supplies a target profile with 8140 HP and 150 armor. Its 4000 shield is a documented maximum; the initial scenario explicitly sets current shield to zero.

The four direct conflicts from the general review are now resolved: 3E5 left arm is c, target disorientation/instability are 150 each, ability 2 binding is 6, and 1E3 ability 2 cooldown is 9 seconds. The latter no longer retains a detailed cooldown-start anchor after the conflicting line was removed.

### New primary profile: 2E4

`data/characters.json` records the following definitions under `documented_abilities`, separate from executable combat abilities. The base first thrust now executes in a controlled unshielded, nonlethal single-action model; other definitions remain outside execution.

| Section in `2E4.odt` | Confirmed source values and behavior | Status / implementation boundary |
|---|---|---|
| Profile | HP 9080, armor 165, running 8 m/s, shield 4000 with 20-second per-loss delay and shared 400/s; heat 165, toxin 44, qard 82.5, electrocution 165, Recovery value 150. | **Confirmed** data. |
| Ability 1 | 440 slash thrust plus attached-blade toxin; toxicity 700, piercing 40, attachment/exposure 1 second. Gathering 140 ms, Active 180 ms, midpoint impact. Target status 110/110; self status 150/150 on impact; listed dyspnea 3. Summon after impact, grab delay 600 ms, Active grab 250 ms. | Base single-effect timing/damage/status execution **implemented**: pre-hit armor snapshots, elapsed exposure, non-exposure decay, and continuous payment confirmed. Shielded delivery, overlaps, and replacement-grab timing/availability remain **Ambiguous**. |
| Ability 2 | Gain one charge every 9 s, maximum one; a successful block consumes it and launches a 500-damage line attack 5 m forward. Target disorientation/instability 800 each. | Damage type and impact timing **Missing**; initial charge and cooldown/charge clock details **Ambiguous**. |
| Ability 3 | Dash 14 m, cooldown 2.85 s, Gathering 140 ms, Active dash 150 ms, listed dyspnea 2.5; self status entries on jump and landing. | Values **Confirmed**; movement and jump/landing timing **Ambiguous**. |
| Ability 4 | Projectile release after Gathering 140 ms and Active release 180 ms; projectile 6 m/s. Contact with its owner consumes it and triggers a 600-blunt attack in a 5 m radius, knocking targets down. Triggered Active 180 ms, target disorientation/instability 600 each, cooldown 9 s, listed release dyspnea 2. | Release values and owner-contact trigger **Confirmed**. Projectile path/contact, attack damage anchor, and knockdown rules **Missing/Ambiguous**. No automatic projectile return or 320 ms damage impact is assumed. |
| Ultimate | Active 400 ms; next 10 s makes ability-1 blades stay attached for 2.5 s; cooldown 60 s. | Values **Confirmed**. Activation/effect start and effects on already attached blades **Ambiguous**. |
| Ability 5 | On death, revive with HP equal to eligible damage in the preceding 10 s; cooldown 65 s, 3 charges, Active 2000 ms. Shield damage excluded by `Details2.odt`. | Entitlement rule **Confirmed**. Revival completion time, HP maximum/zero result, charge behavior, cooldown anchor, history boundaries, and shield/armor state after revival **Ambiguous/Missing**. |
| Basic abilities 8 / 9 | Two listed Block entries, each with 4 charges and 4.5 s per-charge cooldown; Active 150 ms, listed dyspnea 2 and 3.5 respectively. | Entries **Confirmed**; distinct versus shared block/charge pools **Ambiguous**. |
| Basic ability 10 | Heal for 20% of damage dealt, excluding shield damage. | Entitlement **Confirmed** and pure helper implemented; recipient, payment timing, and general healing-cap integration **Missing/Ambiguous**. |
| Sprint | The current overview and detailed basic ability 5 both add 6 m/s. Detailed entry gives base dyspnea 2/s. | **Confirmed**; the earlier 6 versus 4.8 discrepancy is resolved and the data has been updated. Movement itself remains unimplemented. |

## Mechanics registry

Statuses apply to the root-level source unless a secondary-file discrepancy is identified.

| Mechanic | Status | What is documented | Gap or implementation boundary |
|---|---|---|---|
| Character profiles | **Confirmed** corrected explicit fields in six root profiles | 3E5 components b/c, status 150 each, binding 6; 1E3 ice-bomb cooldown 9 s; 2E4 piercing 40 and sprint +6. | Controlled 1E1 schedules its documented self/target effects; general component, cooldown, and other ability scheduling remain outside the runner. |
| Blunt and slash calculations | **Confirmed** equations, defense floors, state floors, and blunt mapping | HP/armor cannot fall below zero. Slash uses max(0,a-p) before squaring; negative final damage floors at zero. Blunt uses pre-hit armor, and the log separates nominal outputs from actual losses. | Blunt and controlled 2E4 slash/armor-loss execution are available. Single bleeding rate/integral is implemented. Death, overlaps, other slash abilities, and general action legality remain outside scope. |
| Venomous calculation | **Confirmed** equation, slash-delivery ratio, zero-delivery rule, defense floors, and factor floors | 2E4 supplies damage 440, toxicity 700, piercing 40, and exposure duration. Adjusted defenses floor before squaring; each damage factor floors before multiplication. | Rate/full-phase integral helpers and the controlled 2E4 lifecycle are implemented. Pre-hit snapshots, elapsed exposure, non-exposure decay, and continuous payment are confirmed; shielded/overlapping/Ultimate cases remain open. |
| Instant Qard / 1E1 ability 1 | **Confirmed and implemented in controlled scope** | Instant Qard uses shield overflow, half-armor plus Qard resistance before squaring, and zero-floor HP damage. Both initial and delayed hits use 450 Qard and target effects 110/110; Qard armor loss is zero. | One stationary scripted activation with explicit hit and blast eligibility. Geometry, cooldown/dyspnea availability, death, and repeated actions remain outside this model. |
| Poisonous, constriction, heat, electrocution, continuous Qard | **Confirmed** equations; implementation pending | Root `Damage types.odt` gives formulas and variable definitions; profiles provide selected attack values. | Exposure accumulation, continuous tick order, formula domain errors, and timing remain for duration-based effects. |
| Disorientation and instability | **Confirmed** target mitigation, self exemption, stacking/decay, running increase, and anchors | Target effects receive collision mitigation; self effects bypass all mitigation and retain running ×1.2. Projectile self effects use Active midpoint; listed melee effects use impact. | Controlled 1E1 executes statuses and initial Gathering modification. Intrinsic same-impact order, movement, and general interrupts remain open. |
| Knockback, slide, movement | **Confirmed** stated equations; world response **Missing/Ambiguous** | Root `Collision details.odt` and `Details.odt` provide mitigation and movement modifiers. | No collision geometry, trajectory, friction, stop/landing integration, or full movement model. |
| Binding break | **Confirmed** threshold; specific fill rate interpreted under delegation | `A=(20B-H/500)^0.9`; Binding explicitly pauses filling under disorientation. Current selected specific Break filling rate is20/s, distinct from ordinary0/18/30 recovery; see GRAPPLE.md. | Grapple formula helpers do not implement Binding delivery or a shared Break controller; boundary/cap/application details remain implementation work. |
| Grapple contests/movement | **Primary source imported**; formula helpers tested | Controller capacity100-(Oa+Ua)/10; signed escape correction, D=3A and HP/armor-weighted vector motion from root `Grapple abilities.odt`. Explicit source labels:1E5/2 and3E5 Ultimate grapple;3E5/2 binding. | Formula helpers and shared status-weight extraction only. Grapple casts, response/resource state, coupled constraints and continuous damage are not yet integrated. See GRAPPLE.md. |
| Shields | **Confirmed** priority, effect eligibility, explicit bonus policy, per-loss delay, shared recovery | Shield receives raw damage before HP formulas. Effects still apply; only stated status-resistance bonuses are added. Each loss waits 20 s; eligible losses share 400 HP/s. | Runner executes damage/regeneration only. Status helper accepts supplied R; selecting active bonuses and effect scheduling remain separate. |
| Impact timing | **Confirmed** explicit anchors; projectile equation a labeled assumption; other anchors **Missing** | Six primary profiles provide usable timing, including 2E4 ability 1's 230 ms midpoint. | Contact times require scenario geometry. 2E4's triggered area attack has no damage anchor. Cooldown anchors and full scheduler behavior remain open. |
| Hand-position Recovery | **Confirmed** scalar formula, units, distance metric, local origin, and alternating-arm intent; limb scheduling **Ambiguous/Missing** | `Details.odt` defines ms/m times distance before the next Gathering. User confirms straight-line 3D positions relative to hitbox centre and explains 1E5 ability 1 / 3E5 ability 1b's alternating-arm zero-Recovery exceptions. | Actual poses, consistent axis directions, multiple-hand aggregation, unused-hand updates, same-hand transitions, and intervening-action behavior remain undefined. Foot contributions and encounter implementation are absent. |
| 1E5 ability 1 components | **Confirmed** values, alternation, self trigger/exemption | a/b are left/right, slash 440 each, Gathering 140, Active 180, midpoint impact, self 150/150 unmitigated on impact, zero Recovery for alternating uses. | Old after-Active and mitigated-self fixtures are historical. Full slash/bleed/component combat, intrinsic ordering, initial selection/reset, piercing, and Ultimate mapping remain open. |
| Dyspnea | **Confirmed** revised recovery conditions and transition helpers | Revised `Dyspnea details.odt`: lose 30/s while walking/stationary, 18/s running, zero under any listed blocker including sprinting. User confirms each blocker pauses loss. Capacity `100-D`, action cost addition, sprint `Dd=2`, and one maximum trigger per crossing remain. | The previous negative-net-sprint conflict is resolved. Profile `Dyspnea value` to `Db` mapping and encounter event/state scheduling remain open. Rate recalculation and 50-digit continuous evaluation are labeled implementation choices. |
| Damage-based healing / revival credit | **Confirmed** shield exclusion; pure helper implemented | `Details2.odt` excludes shield damage from damage-dealt scaling. 2E4 heals for 20%; revival uses eligible damage in the preceding 10 s. | Helper only calculates an entitlement from supplied totals. Damage ownership, overkill, armor credit, and history boundaries remain unspecified; no healing or revival state transition is implied. |
| Healing cap | **Confirmed** cap; payout process **Missing/Ambiguous** | Root `Details.odt`: at most 90% of damage taken in the preceding 8 s can be healed. 2E4 basic 10 provides an entitlement, not the complete payout process. | Timing, recipient, consumed healing allowance, and whether shield loss enters this damage-taken cap remain open. `Details2` addresses damage dealt, not this damage-taken window. |
| 2E4 revival | **Confirmed** stated values; full operation **Ambiguous/Missing** | Death trigger, eligible damage over last 10 s as HP, 65 s cooldown, 3 charges, Active 2000 ms. | Revival HP limit, zero-damage result, activation/completion timing, cooldown/charge behavior, and restored armor/shield require clarification. |
| Blocks | **Confirmed** partial rule | Root `Details.odt` gives shield amount/duration/resistance effects; root `3E5` lists four charges and 4.5 s per charge cooldown. | Damage ordering, held-block timing, charge consumption/refill event details, and stacking of resistance are not fully specified. |
| Headshots | **Confirmed** ability-specific values; spatial model **Missing** | Root `1E2` ability 4 explicitly uses 600 normal damage or 1500 on a headshot. | Hit locations and aim randomness are unimplemented. The historical secondary 35% rule is excluded by source precedence and is not a current value conflict. |
| Contextual abilities | **Ambiguous** | Root `Contextual abilities.odt` gives examples of conditions selecting an alternate action. Root `3E5` ability 1 has one explicit branch condition. | No general condition language, priority policy, or behavior when conditions change during Gathering is specified. |
| Targeting, collision, teams, AI | **Missing** for simulation | Root `Details.odt` says 5v5 3D and friendly fire is on. Some profiles specify area/range/projectile values. | No general spatial hit testing, line of sight, aiming, target selection, autonomous AI, or complete encounter/outcome rule. Initial action inputs must be explicit. |
| Result aggregation | Per-run metrics and scripted comparisons implemented | `analysis.py` summarizes damage, armor loss, shield recovery, and final states. Saved demo runs compare seven independent scenarios. | Full-encounter and team comparisons require the missing mechanics first. A new game-design rule is not required merely to choose analysis metrics. |

## Secondary-document discrepancies

These comparisons were recorded during the original audit. Several secondary copies have since been moved or removed; this table preserves that historical comparison rather than claiming those copies are still available. Current root files remain authoritative under the user's precedence instruction.

| Profile/rule | Root primary | Historical optional-reference copy (then `Game project 1.4/`) |
|---|---|---|
| `1E1` ability 1 | 450 damage on impact and a second 450-damage effect after 0.5 s in a 4 m radius. | 875 damage and a 1.96 s cycle time. |
| `1E2` ability 3 | 30 m grappling rope. | 16 m rope. |
| `1E2` ability 4 | 1500 damage if headshot. | 1500 damage if critical hit. |
| `1E3` ability 4 | 4000-HP prison cube lasting 12 s. | 10 m-radius half-shell shield with 1000-HP cells lasting 5 s. |
| `1E5` ability 2 | 900 damage/s during a 3 s drag. | Damage omitted. |
| `1E5` ultimate | Two extra arms; ability 1 attacks twice during its 6 s duration. | Ability 1 has a 200 ms cycle during the duration. |
| `3E5` ability 3 | 20 m/s initial leap speed, then kick while falling. | 14 m leap. |
| Shared rules, historical snapshot | Root `Binding abilities`, `Collision details`, and `Contextual abilities` were byte-identical to their copies at the original audit. Root `Damage types` supplied the full formulas. | Secondary `Details` supplied additional structural rules but omitted several primary timing/movement details; its additions were not imported. |

## Proposed first implementation scope

### Stage 1: one scripted blunt impact

Build a small data-driven event simulator for one explicit hit:

- Attacker: `3E5`, ability 1 branch b, selected under its documented condition (target is not dashing or being knocked toward the attacker).
- Defender: `1E1`, initialized with HP 8140 and armor 150, and an explicitly configured current shield of 0. This is a scenario state, not a change to the profile's 4000 shield capacity.
- Input event: one scenario-confirmed 3E5 ability 1b activation at time 0. Its 140 ms Gathering and 180 ms Active swing put impact at 230 ms (`140 + 180/2`), as specified by the newly added timing note. The scenario supplies the successful-hit confirmation; the engine does not simulate movement, aiming, or hit detection.
- Calculation: use the root blunt formula with `d=300`, `a=150`, producing `y=225` and `Ar=159/28` (about 5.6785714286). Compute both from pre-impact armor. Apply `y` to HP and subtract `Ar` from armor, retaining fractional values. This mapping was confirmed by the user on 2026-10-24.
- Expected state: HP 7915, armor `4041/28` (about 144.3214285714), shield 0.
- Exclude disorientation/instability (the original branch b conflict is now resolved; status execution remains a later stage), attack windup/cooldown, shield overflow/regeneration, positioning, other damage types, autonomous action selection, and team battles.


This is a zero-shield **single-impact simulation**. It exercises separate character data, mechanics, engine, scripted input, encounter state, event log, and a per-run summary. Tests cover the exact formula outputs, the derived 230 ms impact time, final state, and invalid denominator input; no randomness is needed.

### Stage 2: shield-first blunt hit and one recovery interval

The clarified shield behavior extends the same one-impact simulator:

- Apply the incoming damage to current shield first, raw and without armor/resistance mitigation.
- If shield absorbs all damage, do not evaluate the HP damage formula or reduce armor.
- If the hit overflows the shield, use only the leftover damage as `d` for the blunt HP/armor formulas; apply `y` to HP and `Ar` to armor.
- Record the shield amount lost. After 20 seconds, regenerate that amount at the profile's 400 HP/s rate. This first shield stage handled one such loss interval per run; Stage 3 below extends it to repeated losses.

### Stage 3: repeated hits with separate shield timers

- Accept multiple explicitly confirmed impacts from the same actor and ability against the same target.
- Record each shield loss as a separate cohort with its own 20-second delay and lost amount.
- Advance each loss after its own 20-second delay. All eligible losses share a single 400 HP/s rate; the total rate does not stack when windows overlap.
- For event-log attribution, allocate recovery to the oldest eligible loss first while preserving the shared total rate.

### Architecture and next stages

Python was selected because no implementation language or build setup existed when the initial audit began:

1. Keep character and ability data in JSON with per-field source references.
2. Put pure formula functions in `mechanics/`, separate from mutable character state.
3. Have the combat engine consume timestamped, explicit impact inputs and emit calculation/state-change events.
4. Keep action selection as a replaceable scripted-input component; the first stage does not choose attacks or targets.
5. Keep encounter initial state separate from character profile data so scenarios can set current shield/HP/armor explicitly.
6. Add analysis summaries after an individual run can be reproduced from its inputs and rules.
7. Add damage/effect mechanics for the other characters using their now-data-driven timing profiles. Feed explicitly scripted contact times for leap/landing events until movement is implemented.

## Open items before broader encounters

Venom factor floors, shield bonus policy, projectile-distance requirements, and the specified main attack self-effect anchors are now resolved. Source snapshots and numerical checks are in [results/rule-update-checks](results/rule-update-checks/README.md).

1. Self effects bypass mitigation and retain running +20%; resolve intrinsic same-impact ordering and precise movement events before extending those mechanics.
2. Base 2E4 clocks/payment/snapshots are confirmed. Define shielded continuous damage and overlapping blades/bleeds, plus 1E5 piercing/amplification, before broader cases.
3. HP/armor minima are implemented. Death timing, pending actions at zero HP, overkill credit, and revival accounting remain open.
4. Running/base-Gathering order is confirmed. Incoming disorientation during Gathering is now confirmed below: extend the remaining Gathering by the new mitigated amount. Ability reselection, other debuff stacking, and mid-action movement changes remain open.
5. Confirm per-action Db mapping and reconcile Break's old 20/s reference with its specific filling behavior.
6. Supply hand poses and multiple-hand/sequence-reset rules, cooldown/charge anchors, healing budget accounting, and future spatial/instance scheduling.

See [CONSISTENCY_REVIEW.md](CONSISTENCY_REVIEW.md) for the current resolved/open statuses and preserved audit evidence.

## Implemented stage 4: controlled 1E1 ability 1

The author confirms both 1E1 events deal 450 Qard and apply target disorientation/instability 110/110; Qard leaves armor unchanged. The latest override exempts self effects from mitigation, with running +20% retained. This replaces the preceding mitigated-self rule.

The source-complete controlled scope is one stationary, scenario-authorized activation: current O adds Gathering, self effects occur at Active midpoint, projectile release is at Active end, supplied distance determines travel, and a fixed impact-location marker detonates 500 ms after the hit. `area_targets` explicitly supplies blast eligibility; no spatial hit testing is implied. Actual self/target status application, stacking, decay, HP/shield state, and pending shield-loss timers are logged. Qard leaves armor unchanged, so local damage/status log order does not choose the unresolved intrinsic ordering rule.

Sources: `1E1.odt` ability/profile, `Damage types.odt` instant Qard, `Collision details.odt` target mitigation/decay, `Details.odt` extrinsic firing/running, and author clarifications. Current inputs, five runs, source/code snapshots, and limitations are in [results/self-status-unmitigated](results/self-status-unmitigated/README.md). **154 tests pass.** The previous [1E1 stage](results/1e1-ability1-stage/README.md) preserves its historical mitigated-self implementation and 152-test result.

## Implemented stage 5: controlled 2E4 ability 1

The author confirms: d is post-shield/pre-armor slash damage; venom delivery and target-status mitigation use pre-hit armor; damage is calculated before adding new self-instability and before armor loss; exposure grows with attachment time; non-exposure starts when the blade disappears and grows until toxin damage is zero; bleed and venom accumulate continuously.

One stationary unshielded nonlethal thrust now executes direct slash/armor loss, actual self/target statuses, one eight-second bleed, one second of growing exposure, and one second of toxin recovery. Exact analytic phase integrals resolve the complete effects. Source formulas, supported scope, remaining shield/overlap/grab rules, and numerical results are recorded in [2E4_ABILITY1_AUDIT.md](2E4_ABILITY1_AUDIT.md). Saved full traces and reproducible snapshots are in [results/2e4-ability1-stage](results/2e4-ability1-stage/README.md). **187 tests pass.**

## Venom delivery clarification

Every venomous attack includes a slash attack that enables toxin entry. `venom_delivery_ratio` uses post-armor slash formula damage divided by post-shield/pre-armor slash damage. The helper shares the slash calculation; no HP-cap/overkill credit rule is introduced. Fully shielded thrusts have d=0 and no toxin damage. Zero delivery propagates to both venom rate and full-phase integral helpers. Pre-hit armor snapshots remain fixed for an existing application.

This is implemented and verified by **192 tests**. The complete encounter model remains unshielded until bleeding under shield absorption and continuous shield-damage/regeneration interactions are specified. Previous result directories preserve the implementations and test counts from their own stages.

## Controlled 1E1 ability 4: heat

The author confirms Active-start beam timing, growing exposure followed by residual heat, continuous accumulation, unchanged armor, no added self/target statuses, and current armor/heat resistance. These rules now execute for one stationary, unshielded, nonlethal k=2 beam with explicit recipients. Current-defense changes are verified with interval-boundary regression instrumentation; mixed actions are not supported. Exact rational/square-root HP replaces any need to round integrated heat damage. **221 tests pass**. See [the focused heat registry/audit](1E1_ABILITY4_AUDIT.md) and [saved results](results/1e1-ability4-stage/README.md). Shielded heat, overlap/re-entry, interrupts, death and action availability remain outside this stage. Earlier counts and result packages are historical.

### Heat shield priority and independent overlaps

The author confirms heat damages shields first and overlapping beams are calculated individually. Existing shield immunity to armor/resistance mitigation still applies. These rules are confirmed but not yet executed by the one-beam unshielded runner. The author confirms HP heat exposure starts at zero when the shield breaks; time spent damaging the shield does not count. The author explicitly confirms shield armor and heat resistance are zero. After the ratio analysis, the author confirms shields take residual heat, which ends at shield break without transferring to HP. Shielded execution is not yet supported. See [the heat audit](1E1_ABILITY4_AUDIT.md). Frozen numerical results retain their original scope.

### Residual heat ratio analysis

A separate formula-analysis helper now evaluates general k>=2 without changing encounter execution. For fixed defenses/output, residual/exposure damage is `1/k`, and residual/total is `1/(k+1)`. The study initially treated shield residual as a candidate. The author subsequently confirmed it damages shields and terminates at shield break without transferring to HP; this rule is recorded but shielded execution is not implemented. See [the parameter study](results/heat-ratio-analysis/REPORT.md); **232 tests pass** including independent approximate quadrature and exact ratio checks.

## Controlled 1E2 ability 1

The author confirms zero base Gathering, continuous range falloff (5 raw damage per 20 m), and pre-hit armor for target status mitigation. Readying is an automatic weapon cooldown: 360 ms after 40 ms firing, independent of character actions/statuses and blocking no other actions. The controlled model executes one stationary confirmed unshielded nonlethal shot and its full single bleed. It logs a separate weapon cycle; ammo/reload, repeated fire and general action scheduling are not implemented. The stale imported 140 ms Gathering is corrected. Current source changes outside this ability are recorded in [the focused audit](1E2_ABILITY1_AUDIT.md). **254 tests pass**, including prior models; [the result package](results/1e2-ability1-stage/README.md) preserves current source/code/test snapshots and exact traces.

## 1E2 shield/repeat extension

Confirmed and executed: raw shield priority, overflow as slash pre-mitigation d, no shield bleeding, independent additive eight-second HP bleeds, existing bleeding continuing through regenerated shields, finite ready-timed repeat policy, ammo consumption and empty-magazine stopping, and independent per-loss shield regeneration delays sharing one rate. **285 tests pass**. Reload now executes current-O Gathering before 1800 ms Active, overlapping automatic cooldown; it refills the empty magazine and firing waits for both completion conditions. The author confirms no additional Gathering is inserted once an ability is already Active, including continuous abilities; disorientation still reduces accuracy. Exact rational impact results above 12000 bits are explicitly rejected as an engineering limit; no rounding is substituted. See [the focused audit](1E2_ABILITY1_AUDIT.md) and [the latest evidence](results/1e2-repeat-fire-stage/README.md). Earlier packages retain their earlier scope.

### Additional Gathering and already Active abilities: confirmed

Source: `Collision details.odt` p0/p2/p6 and `Details.odt` Gathering definition; explicit author clarification resolves the former continuous-ability question. Additional Gathering J=O delays entry to Active for an ability not yet started, even with zero base Gathering. Once Active has begun, new disorientation does not insert Gathering, restart, or pause that Active phase on account of Gathering. This includes continuous abilities already in use. Disorientation's documented accuracy penalty remains a separate effect. The later shared-encounter clarification confirms that new incoming disorientation during an existing Gathering extends its remaining time by the newly mitigated amount. Multi-component transitions remain a separate scheduling question.

Current controlled runners fix the phase schedule when initiating their supported action and do not insert Gathering during Active. This clarification changes specification/source notes only; it adds no new continuous-ability execution model. Frozen reports retain their historical pending-question wording.

## Controlled 1E1 Ultimate: poisonous gas

The current source defines a 300 ms equip, 140 ms Gathering, 180 ms firing, 60 m/s grenade, 1200 toxicity, 5 m radius, 8 s cloud, 10 ammo and 1150 ms cooldown after firing. The author confirms elapsed exposure/residual clocks, gas bypassing shields, unchanged armor, and 110/110 effects once to all explosion recipients. One equip/grenade now executes with explicit single exposure windows, constant resistance, zero initial caster statuses and nonlethal returned runs. Full cloud and residual clocks are preserved when a recipient leaves early. **311 tests pass**; [the source registry and limitations](1E1_ULTIMATE_AUDIT.md) and [saved evidence](results/1e1-ultimate-stage/README.md) cover exact results. Repeated grenades, general geometry/movement, cloud overlap, resistance changes, death, Ultimate cooldown anchor and equip/fire status transitions remain excluded.

## Repeated ten-second comparison

The author selects canonical 1E1/3E5/1E5 targets, repeated use, a ten-second horizon and shielded/unshielded variants. New confirmations: beam cooldown starts at activation; replacement blade grab starts 600 ms after impact, lasts 250 ms, then next thrust Gathering; grenade poison curves are independently additive. 1E5 defender stats are imported from the primary document.

A separate numerical benchmark now executes all six ability families in this passive-target scope, including shielded heat and shielded repeated venom delivery. It uses the same formula helpers with fixed 50-digit numerical arithmetic, rather than expanding exact armor fractions. Thirty-six cases are checked at 80 digits; errors are below 1e-20 in tested metrics. Original exact scoped runners retain their own restrictions. HP depletion is an observation stop, not a death/victory implementation. New losses cannot regenerate in ten seconds. **329 tests pass**; [scope, inputs and complete results](results/repeated-10s-comparison/REPORT.md) describe numerical precision and excluded dyspnea/accuracy/defensive choices.

## 1E1 ability 2: confirmed tether boundary

The author confirms the anchor is the impact position. The ten-metre chain acts as a wall/unavailable region for the chained target's body/hitbox: ordinary movement/dashes cannot cross it, and outside teleport destinations are unavailable. Projectiles and summons are not constrained by the tether. This resolves anchor and boundary policy, not hitbox geometry or failed-action costs. The rule is recorded, not yet an executable movement/binding mechanic; see [the focused tether audit](1E1_ABILITY2_AUDIT.md).

## Shared stationary encounter

The author confirms that incoming disorientation extends an existing Gathering by its newly mitigated amount, and 1E1's summoned beam operates independently. The shared runner now executes 1E1 projectile/heat and 1E2 gun/reload actions on one timeline with independent character instances, common state updates, additive continuous effects, and inspection at the horizon or first HP zero. Coupled simultaneous events with unspecified ordering are rejected. Area eligibility is explicitly the policy-selected target only; no automatic radius detection is implied.

This controlled study excludes dyspnea/physical Recovery eligibility and confirmed-hit accuracy/geometry. It is not a complete legal match or strength ranking. Earlier scoped runners and archived results retain their historical limits. See [the current shared audit](SHARED_ENCOUNTER_AUDIT.md) and [the saved 1v1 results](results/1e1-vs-1e2-shared/REPORT.md).


## Terrain extension, 2026-10-25

The earlier body-only stage above remains historical. The current terrain
scope adds author-confirmed finite ground, three fixed 1.8 m cubes and open
sides/top; see [TERRAIN.md](TERRAIN.md) for authoritative conversation
clarifications, dimensions and collision/area rules. Gravity remains
unimplemented. The complete earlier body-only trace is unchanged. The full
suite now passes 479 tests; terrain results are saved separately under
[stationary-2v2-terrain](results/stationary-2v2-terrain/REPORT.md).


## Primary grapple source added — 2026-10-29

The author supplied `Grapple abilities.odt`. All text and four embedded MathML
formulas are reviewed in [GRAPPLE.md](GRAPPLE.md); the source ODT is unchanged.
This adds controller-fatigue cancellation, status-adjusted empty-capacity Break
comparison, a controller response opportunity with both bars filling, escape
penalties and weighted vector movement. The shared formula implementation uses
the existing status weight and preserves current combat numerics. Formula
support does not establish a grapple cast or paired motion in the shared world.
The older Break-rate question above is superseded by the documented delegated
20/s-specific filling choice; ordinary recovery rates are unchanged. Remaining
response/flow/lifecycle/constraint details are implementation work under the
standing delegation, not unanswered questions requiring the author.
