# Continuous heat and shield recovery

Verified in the shared engine, 2026-10-28. Current world data selects
`heat_shield_coupling.mode=fluid_layers_v1`, requiring analytic shield recovery
and typed spatial effects. Incoming heat and delayed recovery now share one
continuous shield balance, including a shield held at zero. No ability or runner
is added. [Evidence](results/heat-shield-coupling/REPORT.md) ·
[Current engine scope](ENGINE_STATUS.md).

## Source rules and delegated decisions

The existing beam has output 900, k=2, a 3 s volume lifetime and a 9 s cooldown
(`1E1.odt` p9/p113–123). Regenerative shield has 4000 HP; each actual loss waits
20 s before sharing 400 HP/s of recovery (p30/p227 and author clarifications).
Heat uses current defenses, shield heat has zero armor/resistance, an initially
cold body begins HP exposure at zero after shield depletion, and shield residual
heat ends on depletion without transferring to HP. Deployment survives caster
death. These confirmed rules remain intact; see [spatial effects](SPATIAL_EFFECTS.md)
and [recovery flow](RECOVERY_FLOW.md).

Partial continuous protection and a warm body receiving new shielding were
unspecified. The following are **engineering decisions under delegation**:

- Keep independent incident and body thermal memory per beam/recipient.
  Incident memory follows geometric exposure even while shield stock is zero.
  This prevents incoming pressure from repeatedly restarting cold when recovery
  is immediately spent. Leaving cools incident memory at k=2; re-entry resumes
  remaining memory. Full cooling ends that episode.
- Positive shield stock fully intercepts incident pressure. Existing body heat
  cools at k=2 and can still damage HP. Reformation cannot erase accumulated
  body heat; this preserves the memory rule already used for spatial re-entry.
- At zero stock, returning shield immediately absorbs incoming pressure up to
  the available recovery rate. Allocate absorption proportionally to each
  source's instantaneous pressure. Use the same protected-time fraction for
  the body clocks, rather than repeatedly breaking/reforming tiny shields.
- Outside the volume, shield residual pressure only persists while that shield
  layer survives. Depletion detaches it permanently for that cooling episode.
  Incident bookkeeping never transfers detached residual damage to HP. Existing
  HP residual memory continues its own cooling.

## Balance and body evolution

All derivatives below use seconds. For source i, geometric incident memory
`a_i >= 0` grows at 1 inside and cools at −2 outside. Eligible shield pressure
is `p_i = output_i * sqrt(a_i)`; total pressure is `P = sum(p_i)`. A detached
shield residual contributes no pressure. Let `R` be the recovery planner's
current service rate, `S` shield stock, `L` absorbed shield loss and `U` recovered
work. Enforce:

```text
S(t) = S(begin) + U(t) - L(t) >= 0
S > 0:       dL/dt = P;        theta = 1
S = 0:       dL/dt = min(R,P); theta = min(1,R/P) when P > 0
body inside: dq_i/dt = 1 - 3*theta
body outside:dq_i/dt = -2
q_i is floored at zero
HP rate_i = current_heat_coefficient_i * sqrt(q_i)
```

With no incoming pressure, body residual heat simply cools. At zero stock with
`R=P`, stock remains exactly zero while fresh body exposure is fully protected.
When `R>P`, surplus recovery builds stock. Existing HP heat continues cooling
through either case. There is no arbitrary recharge threshold, extra shield HP
at reformation, or synthetic gameplay delay.

The stock solver partitions signed `R-P` rates and locates depletion within a
decreasing interval. A positive endpoint balance alone cannot prove that a
shield did not break earlier. Shield loss remains a constant/positive-root
analytic curve: either incident pressure or actual consumed recovery. Record
that **actual** loss with its own delay, so recovery spent under heat can itself
recover later. Shield/construct damage grants no character healing/revival
credit. Per-source HP components retain attribution; general applied-overkill
credit remains unfinished.

## Shared-clock architecture

[thermal_balance.py](combat_sim/mechanics/thermal_balance.py) provides immutable
conditional thermal plans over an immutable recovery plan. Shield work stays
analytic; nonlinear partial-protection body memory and HP dose use adaptive
Decimal integration. [thermal_recovery.py](combat_sim/thermal_recovery.py)
composes those plans with the existing coordinator, typed effects, spatial
membership, damage application and shield-loss history.

Incident memory starts at actual deployment/entry. Coupling activates at actual
recovery onset when incident heat remains; it preserves an existing HP clock.
Conditional epochs last at most 250 ms or half the positive recovery delay,
whichever is shorter, and stop at incident cooling zero. This prevents newly
incurred, unrecorded losses from entering the forecast's eligible supply.
Authoritative physical changes invalidate the conditional plan when processed;
future scripted commands never select earlier physics or invalidate earlier
history. A recovery cursor consumes increasing prefixes once, checking owner,
eligible history and recovered-work baseline.

Observations read immutable dense prefixes; they do not select the adaptive
step grid or pay recovery. The common coordinator still competes for shield/HP
exhaustion, phases, contacts, membership, cover destruction and actual point
hits. Caster death preserves deployed sources; recipient death freezes its
resources and prevents further recovery. Incident cooling timers have revisions
independent of shield-layer detachment. Once all incident memory cools, ordinary
recovery takes over; later exposure can activate a new coupled episode.

## Numerical contract

Signed root-rate classification uses interval bounds, near-equal root pairing
and explicit finite-precision normalization. Body integration uses Dormand–Prince
5(4) with quartic dense output. The mathematical tableau was checked against
[SciPy's pinned primary source](https://github.com/scipy/scipy/blob/v1.15.3/scipy/integrate/_ivp/rk.py);
there is no SciPy/NumPy dependency or runtime download. Split partial-body
integration at `P-3R` sign changes so a short heating interval cannot hide between
adaptive stages. Recorded curves clip to their own support when subtracting a
delay lands infinitesimally before a fractional reference time.

| Control | Current value |
|---|---:|
| Body local absolute / relative error controls | 1e-14 / 1e-13 |
| Maximum adaptive body step | 20 ms |
| Signed rate boundary uncertainty | 1e-12 ms |
| Shield stock / dense HP root bisection | 1e-25 ms |
| Signed rate zero resolution | 1e-18 HP/s |
| Normalized incident clock quantum | 1e-28 s |
| Recovery work roundoff budget | 1e-24 HP |
| Maximum conditional epoch | 250 ms, also bounded by delay/2 |

The opt-in work roundoff budget prevents negligible numerical debt from creating
micro-bursts of full-capacity recovery or tiny positive shield stock. Residual
debt is retained; actual delivered work is clipped to eligible supply. Historical
plans keep their previous zero-tolerance convention. Plans/runs expose controls
and step counts. These are finite-precision numerical diagnostics, **not certified
global error bounds** or a claim of 50-digit physical accuracy. Tighter local
controls, analytic ODE checks, 50/80-digit evaluations, altered observations and
actor order support the tested 1e-8 HP agreement.

## Verification and remaining scope

**1129 tests pass**, including 20 new primitive/numerical tests and 15 new
shared-combat tests; 88 focused checks and the review's five unchanged checks
pass. Seven ordinary authored-ability encounters reproduce their complete API
and CLI traces with frozen inputs; balanced/overlap captures also reproduce
under two hash seeds. Prior recovery, heat, collider, projectile, ownership,
climb and classified historical replays still pass. Engineering API fixtures
add temporary cover/re-entry and gunfire changing live defenses; they do not
claim a new construct ability. [Commands and results](results/heat-shield-coupling/REPORT.md).

Frozen definitions without this mode retain their explicit legacy behavior,
including the historical heat/recovery guard. Old evidence is unchanged.
Current coupling supports the existing k=2 heat beam and positive delayed
shield profiles. [Pause clocks](COOLDOWN_PAUSES.md) and
[applied-loss history](DAMAGE_LEDGER.md) are now integrated. Poison, healing,
revival and remaining kit delivery still need integration. Fixed-facing and broader
body-support guards remain. A3, full six kits and general 5v5 are incomplete.
