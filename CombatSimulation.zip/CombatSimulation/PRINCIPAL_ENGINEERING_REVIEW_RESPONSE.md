# Principal engineering review response — 2026-10-28

**Follow-up, 2026-10-29:** the new review's R1–R3 are justified and corrected.
That movement checkpoint passed 1297 tests; both five-test review scripts pass unchanged.
[Evaluation, corrections and verification](results/principal-review-corrections-2026-10-29/README.md).
The initial response and dated foundation checkpoints below remain historical.

**Lifecycle follow-through, 2026-10-29:** the suite now passes **1335 tests**.
Life-bound owned events/recipient attachments, immutable autonomous source life,
shared restoration, cooldown/debt/support reconciliation and actor-wide rolling
history are integrated. Three ordinary API/CLI captures and one labelled API
restoration probe reproduce with conserved HP; this is not the authored 2E4
revival cast. [Decisions and verification](LIFE_CYCLES.md).
Next: shared 2E4 thrust/venom/replacement phases, then actual healing/revival.

The five reproduced defects in [the independent review](PRINCIPAL_ENGINEERING_REVIEW.md)
are justified and corrected. A1–A3 are also valid prerequisites for the affected
authored abilities; they do not prove those unimplemented abilities already
execute incorrectly. The original review and evidence files remain intact.
These corrections and choices are engineering decisions under the author's
delegation, not newly attributed author rules.

| Finding | Correction | Evidence |
|---|---|---|
| F1: blocked prerequisite cycle | Typed movement intents retain explicit parent ownership. Contact finishes the blocked parent once; retry requires a new command. No synthetic time delay or repeated processing. | Direct run/sprint wall cases reach the horizon; a new command succeeds after a moving blocker leaves; blocked stand rejects parent climb. |
| F4: no-op family crash | One iterative dispatcher selects a handler after every queue change. Handlers return started, waiting, consumed, rejected or stop-fallback outcomes. Ground, sprint, jump, posture and target-bearing climb share this representation. | Mixed no-op prefixes before all families; 1200 no-ops without recursion or extra payment. |
| F2: future commands alter physics | `combat_locomotion.json` declares immutable `world.ruleset=integrated_v2` and body gravity. Body support/flight is separate from jump-action data. CLI loads the current ability definitions independently of script contents. | Equal API and CLI prefixes with a future jump/climb appended, including different posture collisions; optional jump data does not change earlier physics. |
| F3: airborne U creates propulsion | Flight stores commanded ground drive separately from physical velocity. Contacts project that drive; landing resumes it with current ground penalties, without adding airborne U. Forced/path motion retains its own velocity rather than receiving a universal pace cap. | Repeated walking/running jumps, airborne gunfire and incoming U; 50/80-digit controls. Climb still travels above running speed at its authored path speed. |
| F5: mutable snapshot | Combatant serialization deep-copies nested hands and locomotion when the record is captured. | Prior records survive nested mutations and later firing; initial state agrees with the initial observation/profile. |

**Initial F1–F5 checkpoint: 906 tests passed in 36.931 s.** The review's original script passed all five tests
unchanged (1.467 s). Ten additional cross-feature invariant tests plus 22 climb
tests are in the regular suite. [Full suite](results/engineering-corrections-2026-10-28/full-tests.txt),
[original review checks](results/engineering-corrections-2026-10-28/review-tests.txt),
[invariant tests](tests/test_command_invariants.py), [climb tests](tests/test_climb_combat.py).

The actual F3 reproduction now ends at **6.3556802276 m/s actual speed**, with
**6.4 m/s commanded running pace**, versus the review's 6.8287026537 m/s actual
speed. [Scenario](results/engineering-corrections-2026-10-28/f3_scenario.json) and
[corrected complete run](results/engineering-corrections-2026-10-28/f3_corrected_run.json)
preserve this result. Airborne momentum remains unchanged by self/incoming U.

## Historical evidence and compatibility

No old result package was rewritten. Nineteen compact historical cases compare
as follows: four are exactly equal; thirteen differ only in corrected initial
hands; one also has 42 equivalent Decimal string-format changes; one adds a
single blocked-intent diagnostic. Apart from the intended initial snapshot
correction, their numeric combat values are unchanged. The older jump example
did not itself expose F3; its changed Decimal exponents must not be described
as a changed physical outcome. The separate F3 reproduction above does expose it.

Three full stationary historical assertions now reconstruct only expected
initial hands from their own frozen profiles. Every other event, observation,
calculation and final value still compares in full. This does not normalize
away arbitrary discrepancies. The corrected state is captured by the engine;
the expectation adapter does not repair output after simulation.

Current world physics uses explicit input data. Frozen API inputs lacking a
`world` field select the named `historical_optional_flight_v1` adapter, with
flight selected by the explicit supplied jump definition. For historical CLI
inputs, `--historical-airborne` selects that flight behavior explicitly; future
commands never choose it. These compatibility choices preserve historical
rule selection without retaining F1/F3/F4/F5 defects.

Run `python3 results/engineering-corrections-2026-10-28/compare_historical.py`.
It checks all nineteen cases and the saved corrected F3 run, using archived
inputs. [Captured comparisons](results/engineering-corrections-2026-10-28/historical-comparisons.txt).

## Architecture follow-through

- **A1 implemented for current action types:** dispatch/intent ownership and an
  action registry coordinate atomic hand/weapon/locomotion requirements,
  phase-bound payment receipts/reservations and selective source restrictions.
  Phase calculations remain in their rule modules with explicit action contexts.
  Independently released effects remain outside controlled-action locks. Future
  kit-specific and phase-specific requirements remain integration work.
- **A2 foundations implemented for supported types:** physical flights have independent IDs,
  owner/ability/action/parent/root attribution, lifecycle revisions, explicit
  contact policy, birth-owner immunity and copy APIs. Compound HP/expiry world
  colliders, blocking policy, contact invalidation and support loss now execute
  in shared moving combat. Actual field/cast/follow-up and coupled-motion ability
  delivery remain unfinished. Reuse swept mathematics.
- **A3 partially implemented:** typed bleed/heat instances, independent volumes,
  moving membership, re-entry, thermal/layer clocks and continuous cover damage
  now run in shared combat, including net heat/recovery balance, zero-stock
  absorption and warm body memory. Remaining-work cooldowns, composable pauses
  and actual 1E2 pause-area casts also execute. Applied-HP attribution, overkill
  allocation and immutable rolling histories are integrated. Life generations,
  healing payout and revival remain unfinished.
  Unsupported combinations retain guards; released effects stay independent.

The unfinished climb integration is now verified with four real shared-engine
encounters, not merely formula tests; see [its report](results/climb-combat/REPORT.md).
The subsequent A1/A2 foundations and A3 heat/recovery increments below are also
verified. Next are life generations and actual healing/revival delivery.
[ENGINE_STATUS.md](ENGINE_STATUS.md) is the single current
capability/decision index; older dated sections remain historical.

## A1 follow-through, 2026-10-28

Current moving-combat data now declares occupied resources separately from
required functions. Eligible gun/reload and body actions coexist by action ID;
upper restriction permits ordinary lower-body movement/jump, and lower
restriction permits gunfire/reload. Multiple sources expire independently,
including refresh generations and exact expiry boundaries. Cancellation is
local to affected actions; body contacts cannot cancel a separate weapon, and
death cancels all owned actions without removing released shots.

Deferred costs reserve bounded capacity against other controlled debits while
retaining their existing payment/calculation anchors. Each payment has an
action/phase receipt. Continuous sprint exertion can invalidate an unpaid body
phase, which defers/cancels under the existing rules without a failed debit.
Incoming O extends all unfinished Gatherings after one state application;
self O from one action also extends another unfinished Gathering. No Gathering
is inserted into an Active action. Three changing-property no-op regressions
and an actor-identity guard close additional mixed-queue/ownership failures.

**943 tests pass in 43.916 s**, including ten registry and 27 shared interaction
tests. The original review's five checks pass unchanged (1.264 s). Four new
complete encounters and their CLI replay match exactly; four prior climb
encounters and the nineteen classified historical cases still match with
frozen inputs. [Evidence](results/action-ownership/REPORT.md),
[rules/decisions](ACTION_OWNERSHIP.md), [full tests](results/action-ownership/full-tests.txt).

The upper/lower scenes use pre-applied existing freeze conditions. Runtime API
tests verify application/cancellation/refresh during combat, but 1E3's casts,
projectiles, marks and area delivery remain unimplemented. Current requirements
cover existing moving gun/reload and body actions, not all six kits or arbitrary
phase-specific handoffs. Frozen scheduling fixtures preserve earlier evidence;
the original principal review and its evidence are unchanged. A2/A3 remain
required work, and the overall engine goal is incomplete.

## A2 projectile follow-through, 2026-10-28

All shared physical-flight paths now allocate entity identities independently
of controlled actions. Moving straight/gravity flights use explicit policies,
including owner consumption/impact after whole-body separation. Continuous
clearance handles overlapping parts, translating/resizing bodies, exit/re-entry,
quantized confirmation and Decimal/binary64 endpoint rounding. Default authored
gun/Qard owner exclusion and friendly fire remain unchanged.

The shared copy API retains actual momentum, path-distance falloff, source
attribution and per-flight lifetime without another firing/ammo/payment action.
Parent and descendant branch history prevents repeated copying by one field
instance; different sources remain independent. Terminal/inert shots cannot
produce active copies, while a ballistic apex remains active. Copies continue
and retain attribution after owner death. Engineering probes validate these
interactions without claiming 1E3 field activation/split placement or 2E4's
release/follow-up attack. See [rules and choices](PROJECTILE_ENTITIES.md).

**980 tests pass**, including 37 new entity/geometry, shared-combat and boundary
checks. Four complete new traces replay exactly, including an ordinary combat
trace through the public CLI. Prior ownership/climb replays and the review's
five original tests still pass. [Evidence](results/projectile-entities/REPORT.md).

Internal simulation IDs are always independent. Frozen inputs retain the named
legacy trace projection; old artifacts remain untouched. One new reporting
correction removes 14 obsolete pending stop events from the old moving-gun duel.
The [current comparison](results/projectile-entities/compare_historical.py)
checks all nineteen historical cases and the corrected F3 trace with only that
additional expected-field correction; earlier strict scripts can now fail there.
No actual event, calculation or numeric outcome is discarded.

A2 still requires damageable/expiring world-collider identities, explicit
blocking policy and contact invalidation. A3 typed effects/volume membership,
paused clocks, damage attribution and revival remain pending. The next increment
should establish collider lifecycle in the existing coordinator before porting
prison/wall destruction; complete kit integration remains the goal.

## A2 fixed-world follow-through, 2026-10-28

The collider foundation now runs in the same coordinator: fixed compound parts,
one optional HP pool, independent blocking channels, expiry/refresh generations,
source identity and collision revisions. Current gunfire damages/destroys objects
using actual-path falloff; simultaneous hits share pre-batch geometry and all
stop without overkill transmission. Later shots see the opening. Nonlethal HP
damage retains contact evidence; structural changes invalidate it and rescan
current contacts. Creation around a shot and exactly against a moving body work.

Climb uses registered active single-cuboid targets. Expiry/removal interrupts
preparation/path or releases support into a real fall, retaining paid costs,
momentum and independent weapons. Compound landing uses its hit part. An older
inherited geometry-only validator incorrectly treated unsupported falling bodies
as standing; integrated airborne validation now owns that check, including an
actual raised-platform jump. Area witness policy is implemented, while changing
cover during continuous heat explicitly awaits typed exposure membership.

**1022 tests pass**, including 42 new tests. Four ordinary shared encounters
match the complete API and CLI: destruction, expiry in flight, opposing fire at
a hollow shell and support disappearance. Prior projectile/ownership/climb traces,
historical comparisons and all five original review checks pass. Summaries expose
construct HP/lifetime independently of character loss. No old evidence changed.
[Rules/decisions](WORLD_COLLIDERS.md) · [Evidence](results/world-colliders/REPORT.md).

The shell is explicit initial geometry, not 1E3's cast. Prison delivery, charge
conditions, field duplication and owner-contact secondary attacks remain kit
work. Next is A3 typed persistent effects and independent volumes, starting with
existing heat exposure/lifetime and moving entry/exit/re-entry; paused clocks,
damage attribution/revival and broader kits remain required. The overall goal
is still incomplete.

## A3 heat-volume follow-through, 2026-10-28

The first A3 increment replaces fixed deployment recipients in current moving
combat with independent heat columns and typed, source-attributed bleed/thermal
instances. Existing 1E1 ability 4 now casts in the moving engine. Per-target
membership, residual clocks and re-entry are separate from volume lifetime and
controlled hand locks. Different sources expire independently, and caster death
cannot erase deployed heat. Unknown effect/curve kinds no longer imply heat.

Continuous geometry finds body/column/cover boundaries on the existing clock;
real gunfire updates the defenses used by ongoing heat. A damageable roof can
burn away mid-exposure and immediately expose the body with fresh memory.
Verification corrected a half-open lifetime discrepancy: continuous damage up
to collider expiry applies before expiry, while point hits at that instant
remain ineligible. Final membership settles horizon-time cover changes.
Member processing is sorted so hash seeds cannot change expiry event order.

**1066 tests pass** (44 new), and all five original review tests pass unchanged.
Six ordinary complete encounters match public API and CLI traces, including
multi-target hash-seed controls. Earlier collider/projectile/ownership/climb
captures and nineteen classified historical cases plus corrected F3 still
reproduce. [Evidence](results/spatial-heat/REPORT.md),
[source/delegated rules](SPATIAL_EFFECTS.md).

The per-layer re-entry choice is delegated, documented and reversible; no new
ability was invented. A3 remains partial. Heat/shield regeneration is explicitly
rejected and is next; affine loss history already preserves its distribution.
Paused clocks, applied-loss credit, revival and remaining ability delivery
still require implementation.

## A3 recovery-flow prerequisite, 2026-10-28

Current ordinary regeneration now uses immutable analytic work/rate plans from
known loss history, with supply/capacity boundaries and owner/revision-bound
single consumption. A constant-plus-root curve family retains continuous loss
distribution when recovered work is later spent again. Nested snapshots remain
detached, and cooling-zero knots preserve the service solver's concavity premise.
This is the mathematical prerequisite for the review's heat/regeneration issue.

**1094 tests pass** (28 new), plus all five unchanged review checks. Two ordinary
35-second API/CLI traces recover real gun/heat losses; three analytic diagnostic
plans also reproduce. Earlier full captures and classified historical comparisons
still pass. [Rules/remaining work](RECOVERY_FLOW.md),
[evidence](results/recovery-flow/REPORT.md).

The simultaneous overlap guard remains. Net shield balance, zero-stock heat
allocation and incident/layer thermal memory must be coupled before that
interaction is supported. A3, full kits and the broader Goal remain incomplete.

## A3 continuous heat/recovery follow-through, 2026-10-28

The previously rejected overlap now runs in the shared coordinator. Immutable
recovery work and incident pressure determine net shield depletion; zero stock
immediately consumes returning shield instead of repeatedly starting fresh cold
layers. Per-source incident/body memory preserves current defenses, shield
residual non-transfer, warm reformation and attribution. Newly absorbed recovery
is recorded as actual delayed loss and can recover again. Recipient death stops
recovery; caster death preserves deployment.

Partial protection and warm re-shielding are documented delegated decisions,
not new author statements. Analytic shield histories and adaptive Decimal dense
body-heat plans use explicit tolerances. Observation reads do not select their
step grids, and conditional plans never inspect future commands. Balanced flow
has no numerical shield micro-stock or excess recovered work. This is an
incremental composition with the existing coordinator, not a second engine.
[Rules and numerical limits](HEAT_SHIELD_COUPLING.md).

**1129 tests pass in 89.995 s** (35 new primitive/shared checks); the focused 88
checks and original five review regressions pass. Seven ordinary authored-ability
captures reproduce complete API/CLI traces. They cover positive/zero/balanced
stock, independent overlapping sources, moving exit, caster death, delayed
recycled losses and residual HP death after reformation. Precision, observation,
participant-order and future-command controls pass. Earlier recovery, heat,
collider, projectile, ownership, climb and classified historical replays still
pass; old evidence remains intact.
[Evidence and commands](results/heat-shield-coupling/REPORT.md).

A3 remains partial: next remaining-work cooldowns with composable pause sources,
then the existing 1E2 area delivery. Applied-loss credit/life generations precede
healing and revival. Other kits and broader body-support/facing work remain.
No complete six-kit or general 5v5 claim is made.

## A3 cooldown/pause-area follow-through, 2026-10-28

Current ability and automatic weapon cooldowns now use remaining work and sets
of independent pause sources. Ready actions can activate inside a field; their
new cooldown work inherits its pauses. Entry/exit/expiry invalidates old waits;
overlap and same-timestamp field handoff cannot resume early. Dead actor clocks
stop; deployed fields survive caster death. Physical action phases, reload,
effects and shield recovery keep their own clocks.

The existing 1E2 ability 2 is delivered through the same controlled-action
registry, body-volume geometry and event coordinator. Deployment/pose/shape and
effort-policy interpretation are explicit delegated decisions, with the original
listed cost retained as source history. Frozen inputs retain their old clock
presentation; no historical evidence was rewritten.
[Rules and decisions](COOLDOWN_PAUSES.md).

**1159 tests pass in 107.187 s**, including 30 new primitive/shared tests. The
original five review checks still pass. Eight ordinary API/CLI captures match,
with hash-seed controls. Prior coupled heat/recovery, recovery, heat, collider,
projectile, ownership, climb and classified historical replays pass. Actual
reload/heat lifetimes and the twenty-second shield-recovery interaction continue
under fields. [Evidence and commands](results/cooldown-pauses/REPORT.md).

A3 remains partial: attributed applied-HP-loss credit and explicit life
generations precede healing/revival. Remaining existing kits and broader spatial
support still need delivery. The full Goal remains active/incomplete.

## A3 applied-HP attribution follow-through, 2026-10-29

Current shared direct/continuous damage now records immutable source-attributed
actual HP loss. Simultaneous overkill is allocated by nominal post-defense HP
weights. Shield, armor and construct loss do not generate character recovery
credit. Friendly/self damage remains recorded but is ineligible for outgoing
recovery, a documented delegated exploit-prevention decision. Point windows
are left-open/right-closed; continuous windows retain analytic or dense curves.
Dead sources retain released-effect attribution. Attack identity rejects repeat
credit even when damage is recalculated. [Rules](DAMAGE_LEDGER.md).

**1192 tests pass in 121.998 s**, including 33 ledger/API/shared checks. Nine
ordinary API/CLI captures and saved-curve window queries match. Nonlinear heat
windows agree with independent HP-prefix runs; bleed windows match an
independent delivery-based integral. Observation/precision/source-order
controls pass. The original five review checks and prior frozen replays remain
verified. [Evidence](results/applied-hp-credit/REPORT.md).

This implements the review's applied-loss history prerequisite; it does not
pay healing or revive actors. Life/event generations and actual 2E4 recovery
delivery remain next, along with their shared attack/effect prerequisites.
Full kits and the broad Goal remain incomplete.


## Subsequent prerequisite: shared effort response — 2026-10-29

Source-selected phases now drive intrinsic Qard release power and sustained gun
control interruption. Immutable release snapshots survive copying, caster status
changes and death; live target defenses and HP attribution stay on the shared
coordinator. Qard now uses existing moving/gravity/terrain/area delivery. Beam
and marking activation remain momentary while their effects run independently.

Causal recoil, stable-start gating, per-action cancellation, independent weapon
Readying, no-enemy completion and same-time phase snapshots have explicit
[delegated rules](ABILITY_EFFORT.md). Heap-insertion reversal checks preserve
committed output. Actual body actions, payments, released effects and historical
rule-version traces remain covered. [Verification and ordinary replays](results/phase-effort/REPORT.md).

This removes the current gun/Qard effort-response gap. It does not complete
intrinsic sustained delivery, other kits, life generations, healing or revival.
The Goal remains active, with explicit life/event generations and actual 2E4
recovery plus its shared attack/effect prerequisites next.

Verification at this checkpoint: **1234 suite tests pass**, including 42 new effort checks; all five original review tests pass unchanged. Nine current API/CLI captures, source/hash checks, HP-conservation checks and nine prior replay packages pass. The Goal remains active.
