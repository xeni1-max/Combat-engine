# 1E1 ability 2: ground tether clarification

Primary sources: `1E1.odt`, ability 2 overview p5 and detailed p69 onward; `Binding abilities.odt`, distinction between a tether and full freezing. Explicit author replies take precedence. This is a specification audit, not an implemented ability.

| Rule | Status | Source |
|---|---|---|
| Chain attaches target to ground for 15 seconds; length 10 m; cooldown 9 s | Confirmed values | `1E1.odt` p5 |
| Anchor is at impact position | Confirmed | Author clarification |
| Chain boundary excludes the chained target's body/hitbox from going beyond its permitted reach | Confirmed | Author clarification: acts as a wall/unavailable area |
| Walking, running and dashes cannot carry the target's body/hitbox across the boundary | Confirmed application of boundary rule | Author clarification; dash is an example of attempted escape |
| Teleport destination beyond the boundary is unavailable to the chained target | Confirmed | Author clarification |
| Projectiles and summons may cross/be placed beyond the boundary | Confirmed | Author clarification; restriction applies to the bound target's body/hitbox, not its ranged effects |
| Existing ordinary actions remain permitted within the boundary | Tether rather than full freezing | `Binding abilities.odt` p0; author body/hitbox restriction |

The impact anchor and ten-metre chain define the movement constraint. Ordinary movement reaches the boundary and cannot continue beyond it. An invalid teleport destination does not become a valid position by clamping it to the boundary. This does not specify cooldown/resource costs for a failed teleport attempt.

Implementation must account for the target's body/hitbox. A centre-point-only check must not silently allow part of its hitbox to enter the forbidden area. Exact geometric enforcement still needs an agreed hitbox shape/dimensions and dimensional treatment of the tether; do not invent body measurements or replace the specified hitbox boundary with a point proxy. These geometry details are separate from the now-confirmed anchor and boundary behavior.

The tether is not complete immobilization and does not block projectiles or summons. A general movement/collision system, teleport validation, knockback interaction details, Break behavior, failed-action costs and ability scheduling are not claimed implemented here. The earlier throw/timing/status definitions can be audited independently before combat implementation.
