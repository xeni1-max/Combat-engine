# Character effort and interruption categories

[1E1's actual launcher](LAUNCHER.md), 2026-11-10, separates authored intrinsic
sustained swap (Db2.5,Active-start payment) from intrinsic momentary firing
(Db3.5,firing-end payment). Non-damaging swap invents no pressure DPS or extrinsic
interruption. Required-function/death cancellation still applies. Ability1's
grenade variant refers to Ultimate's reviewed firing phase and freezes it with
the selected definition; the ordinary Qard keeps its own phase. Released carrier
power is zero, while Tp1200 is a separate immutable chemical payload, preserving
the documented chemistry through source instability, copying and later swaps.

[2E4 basic9 Dodge](DODGING.md) uses delegated intrinsic momentary body effort,
with authored Db3.5 paid at Active start. Its physical dip/return adds no damage
release or autonomous shield. Native geometry, required functions, interruption
and source-life cancellation still apply. The current profile replaces the old
extrinsic Block interpretation; all other effort categories retain their values.

[1E3's marking projectile](BINDINGS.md) is source extrinsic momentary: self
O/U120 occurs at Active midpoint, but its released projectile, marks and freeze
are independent of continued control. No unlisted recoil/exertion cost is added.
Binding Break's explicit 20/s filling pauses during disorientation; unrelated
sustained channels still use their own rules and the common capped writer.

[3E5's conditional first ability](CONDITIONAL_MELEE.md) now pins each intrinsic
momentary branch: b/c use Db1.8 and 300 base blunt; a uses Db3 and 600. The same
phase category does not make their costs/power/statuses interchangeable. Each
midpoint release captures its branch before new on-impact self instability;
its ballistic up knock is released physical motion with no sustained effort.

[3E5 heavy punch](KNOCK_DELIVERY.md) now captures its intrinsic momentary 600
blunt power at midpoint contact, before new self U200. Db3 pays at Active start.
The released knock is physical motion with its own finite lifetime, rather than
a sustained character-effort channel. Body resistance determines distance;
instability's damage-output formula is not reused to scale knock distance.

[Existing 1E5/2E4 dash](BODY_LAUNCHES.md) is authored intrinsic momentary effort.
Db2.5 pays at takeoff; its later physical flight is not an intrinsic sustained
channel. Real contacts and restrictions can change/cancel control without
erasing the already incurred landing effects. No damage-output instability
formula is repurposed to reduce its range.

[1E5 grab/holding](GRAPPLE_DELIVERY.md) now separates intrinsic momentary grab
from intrinsic sustained holding. The latter samples live `max(0, 900-U/4)`
pressure and pays delegated Dd2 while owned control remains live; it is not an
immutable released hit. Its source life, target life and holding action govern
teardown. Shared effort adds each `(Dd_i+D/100)^2` and any explicit fixed filling
rate before advancing one capped bar; it does not square a sum of bases or let
sprint overwrite holding's result. [Actual common Break](GRAPPLE_BREAK.md) now
adds 20/s filling per answered contest, using actual capped gains separately
from holding/sprint and preserving authored independent payment anchors.

[1E5 component strikes](COMPONENT_MELEE.md) now capture intrinsic momentary
power separately for a/left and b/right at actual midpoint emission. The same
immutable release also records passive double bleed and timed piercing, without
extra effort payments. Physical Db1.8 is paid once at Active start; a whiff does
not refund it. Source on-impact statuses apply after power capture and do not
change another independently released hit in the same wave.

[Shared attack enhancements](ATTACK_MODIFIERS.md) retain each physical attack's
effort/power snapshot and capture its modifier values at the same emission.
The 2E4 enhancement activations are extrinsic momentary and cost no dyspnea;
they do not waive the thrust's physical cost or add self statuses. Extra armor
loss and shield bypass supply no power at zero released damage. Later expiry
or death does not rewrite a released attack's captured values.

Confirmed author clarification, 2026-10-29. These categories describe the
character's effort while performing an action or phase. They do not classify
how long its projectile, summoned object, area or damage lasts.

The shared engine now also captures 2E4's intrinsic momentary thrust power at
its actual midpoint frame, before new on-impact self instability. It uses a
melee attack identity without inventing a projectile. Attached venom and
replacement summoning persist independently; [MELEE_VENOM.md](MELEE_VENOM.md)
records their controlled/autonomous boundary.

The shared [2E4 Block counter](COMBAT_REACTIONS.md) now captures a direct,
extrinsic momentary emission with immutable source/action identity. No extra
dyspnea or hand/body action is introduced. Actual high-instability tests retain
its 500 output; released hits survive the emitter's later death. Its category is
a documented delegated interpretation of the author's no-additional-effort rule.

| Effort category | Author examples | Meaning |
|---|---|---|
| Intrinsic momentary | Punch, sword swing | Character effort performs a discrete attack. |
| Extrinsic momentary | Shotgun trigger/discharge; 1E1 beam activation | An external mechanism or summon performs most of the work after the character's brief activation. |
| Intrinsic sustained | Holding and pushing a chainsaw | Character effort continues during use, even when a powered tool also contributes substantial work. |
| Extrinsic sustained | Full-auto gun, flamethrower | Character operation continues over time while the mechanism supplies most of the output. |

These are conceptual examples, not new abilities assigned to the six characters.
Momentary does not mean zero milliseconds. Active duration alone cannot select
a category. Composite abilities can have different categories in different
phases; record each controlled phase separately.

## Effort, cost and effect lifecycle are distinct

- Effort category selects the applicable instability response. Root
  `Collision details.odt` p16–18 reduces intrinsic attack damage and interrupts
  extrinsic sustained abilities. The momentary/sustained distinction follows
  the character's ongoing effort.
- Dyspnea follows its documented effort/payment rule. An extrinsic attack can
  still cost dyspnea for recoil control. Classification does not assign a base
  cost, make every extrinsic ability free, or create a continuous cost from an
  effect's duration. [Confirmed cost policy](DYSPNEA_POLICY.md).
- Released effects retain their own lifetime and ownership rules. An independent
  beam is not a sustained character action simply because it continues damaging
  targets. Interrupting ongoing controlled effort does not retract already
  released projectiles or independently deployed effects.

## 1E1 ability 4

The activation is **extrinsic momentary** (`1E1.odt` p131 and this author
clarification). Its 300 ms controlled Active and three-second beam lifetime
are separate. The beam deploys at Active start under the existing confirmed
rule. Once deployed, the character cannot stop it; caster instability cannot
interrupt that independent beam. It expires on its own clock and retains its
existing exposure/residual rules.

The shared engine already separates the owned summon gesture from the deployed
volume. Cancelling the remaining controlled gesture or killing the caster
preserves the beam. This clarification adds no new interrupt threshold, duration,
resource payment or early-removal action.

## Reviewed phases and current runtime

`data/characters.json` records `effort_phases` under `documented_abilities`.
The currently reviewed entries are 1E1 Qard firing (intrinsic momentary, p71),
1E1 beam activation (extrinsic momentary, p131), 1E2 firing control (extrinsic
sustained, p66), and 1E2 marking activation (extrinsic momentary, p88).
The primary source's phase labels take precedence over assumptions based on
the presence of a gun or projectile.

The executable `effort_phase` selects one of those source-reviewed phases.
Current `phase_effort_v1` world rules implement intrinsic Qard release power,
sustained gun control/interruption and momentary beam/mark activation. The old
`damage_category` is retained for restricted historical handlers; it does not
classify current effort. Inputs without the new declaration keep their old
behavior and do not claim current effort response.

Other kits still need explicit phase selection and delivery, including composite
phase transitions and intrinsic sustained attacks. A formula/category alone
does not establish shared-engine integration. [Current scope](ENGINE_STATUS.md).

## Shared effort response: delegated implementation, 2026-10-29

The following resolves timing and control details under the author delegation;
these details are not additional author confirmations. Current shared-world
inputs select `effort_rules.mode = phase_effort_v1`.
Historical inputs without that declaration retain their recorded rules.

- Executable actions name their source-reviewed `effort_phase`; categories are
  never inferred from effect duration, weapon type, dyspnea or the old damage
  routing field. Reload and body actions retain their separate existing rules.
- An intrinsic momentary release snapshots `max(0, base damage - U/10)` before
  falloff and target defenses. Qard's projectile and delayed blast inherit that
  same release, including copies and posthumous effects. Target defenses remain
  live at each hit. The ordinary Qard release therefore includes its own
  remaining instability (50 after its midpoint effect has decayed for 90 ms),
  giving 445 from its authored 450 base. Later caster status cannot rewrite it.
- Intrinsic sustained output uses `max(0, base DPS - U/4)` from the embedded
  `M2=5U/20` formula in `Collision details.odt`. This is shared formula support,
  not delivery support for an as-yet unintegrated sustained attack.
- Gun control is a separately identified sustained intent linking its firing
  actions. Automatic Readying holds no hand resources and blocks no other
  action. Positive instability prevents a new sustained emission/start; policy
  waits for stability as well as weapon/resource availability.
- Instability from incoming hits or another action interrupts sustained control
  and cancels its unfinished firing action. The causing firing action's own
  recoil is exempt for that control; otherwise every documented gun shot would
  cancel itself at its midpoint. That exemption decays with the source status,
  does not exempt parallel movement/jump penalties, and does not waive the next
  emission's stable-start check. No cancelled, unreleased shot spends ammo,
  firing dyspnea or weapon cooldown. Already paid costs are not refunded.
- Complete all due phase/release events before settling their interruption
  consequences; resolve incoming hit batches next, then settle before policy.
  A release and incoming hit tied in time preserve the committed release.
  Intrinsic releases sample instability before the closure of due phase events
  at that instant. Concurrent self-status additions affect later output, not
  another already-due release; nested zero-time phases share this snapshot.
  Thus queue insertion order cannot decide a same-time release's power.
- Resource reassignment, blocked required functions, reload, empty magazine or
  death ends the corresponding control without imposing a global channel lock.
  With no living enemy, an idle control ends; an already-started attack still
  finishes toward the original location before its control ends.
  Disjoint actions and independently released objects retain their lifetimes.
  Differences below `1e-18` instability count as numerical zero; this prevents
  observation partition roundoff from inventing interruptions.

Initial delivery targets were the reviewed gun, Qard, beam activation and marking
activation. Do not claim intrinsic sustained delivery or other character kits
from the presence of their category or formula alone.

**Body-part projectile extension, 2026-11-03:** the current 1E2 ability4 source
explicitly calls its firing intrinsic momentary. The shared release captures
default600 and head1500 independently with one U snapshot; each loses U/10.
Actual contact later selects its frozen component before travelled-distance
loss and normal defenses. A missed head aim cannot select head output, and a
copy/source death cannot resample output. No other attack acquires an invented
anatomical multiplier. [Rules](BODY_PART_DAMAGE.md) ·
[Source/default audit](1E2_ABILITY4_AUDIT.md).

Implementation: [pure output rules](combat_sim/mechanics/effort.py),
[shared controller](combat_sim/effort_rules.py) and the existing encounter,
projectile and simultaneous-damage boundaries. Released power is immutable per
original projectile; copies resolve its root identity. Separate future emissions
from one action can have separate snapshots. Records expose source, phase,
instability, base/output components and sustained-control action/lifetime links.
[Ordinary encounter evidence and reproduction](results/phase-effort/REPORT.md).
