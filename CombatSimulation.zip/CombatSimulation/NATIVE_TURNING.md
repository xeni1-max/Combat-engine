# Initial native whole-body turn scope

2026-11-13. Timed turns now execute on the existing shared combat timeline for
all six source profiles. This is an initial scope, not complete angular support
for every existing ability/interaction. [Evidence](results/native-turning/README.md).

The subsequent [owned-contact extension](TURNING_CONTACTS.md) now carries the
existing charge-grab and descending foot volumes through live owner/target
turns. Creation snapshots remain inspectable; released objects stay separate.
The [field extension](TURNING_FIELDS.md) now supplies continuous membership and
beam cover for heat, cooldown, gas and electrical fences on those same paths.
[Angular support](ANGULAR_SUPPORT.md) now extends finite/raised/body support and
native departures/landings, preserving the existing positive-area witness rule.

## Input and source rule

An optional `turn_script` supplies explicit relative signed angles:

```json
"turn_script": [{"actor":"A", "at_ms":200, "angle_degrees":90}]
```

`expected_life_generation` defaults to 1. Commands queue by actor; zero-angle
requests consume no action. A wrong-life command is ignored. The old movement
command `action: turn` without an angle remains invalid. The feature requires the
current owned, saved-path, gravity/finite-face world. An absent turn script keeps
historical result fields and behavior unchanged.

The **author's rule** is 90 degrees per `150 + 40v` ms. Delegated choices:

- Sample the magnitude of actual xyz movement velocity at Active start; retain
  that rate until completion/interruption. The instantaneous request/start has
  no invented Gathering, Recovery, hand pose or extra dyspnea base cost. Its
  Active uses the existing resource-recovery context.
- Use explicit signed relative angles, including multiple revolutions. Do not
  select a shortest arc or NPC heading. Ordinary movement retains its existing
  world direction; turning does not steer it.
- A separate `heading` resource requires `lower_body`, allowing compatible
  locomotion, firing and Block owners to coexist. Existing restrictions, action
  identities, life generations and phase revisions remain authoritative.
- Actual material/body impact interrupts the involved turn controls. Death or
  loss of upright control ends them; paid weapon costs and released effects keep
  their existing lifetimes. Later explicit commands can turn away from contact.

## One translation writer and continuous geometry

`SavedBodyPaths` still consumes the reference trajectory once. Turn state owns
only heading. A stable angular driver key replaces instantaneous facing in the
saved translational dependency while a turn is active; observations do not
reanchor translation. Query slices retain the original angular anchor.
Existing pose/hand/Recovery and Block geometry derive from the current real
frame; local centre/size polynomials compose with the same saved reference.

The earlier angular handoff overstated a dense-reference prerequisite. The
current `persistent_distances.py` imports the exact quadratic planner in
`mechanics/distance_path.py`, and its replacement pieces are `BodyPathPiece`s.
No separate reference integrator or curve fitting is needed. Angular support
and [active grapple/distance response](ANGULAR_LINKS.md) now compose with it.

Continuous box queries predict real overlaps, including a rotating body with a
stationary reference. Upright vertical faces use signed combined polynomial
coefficients before bounding: an anchored foot cannot acquire a fictitious
floor crossing from separately bounded centre and extent accelerations.

Native entry uses an inner resolution band `CONTACT_DISTANCE_EPS_M / 100` and
`1e-28 s` bracket resolution. A previously resolved, separating overlap may need
an additional inner-band depth before nominating a new entry; all accepted
contacts still revalidate within the existing `1e-20 m` spatial contact band.
This avoids repeated rejected zero-time events without inventing a physical
skin or changing old fixed-heading tolerances.

Contact witnesses use the actual clipped footprint polygon and vertical overlap.
Their velocities include yaw, local pose and resizing. Existing collision status
formulas use these pre-response point velocities; reference projection uses the
original character velocity. Rotation therefore cannot become an invented
sideways reference impulse. Character/character response keeps the authored
centre-line direction; static response keeps surface normals and existing
resistance/status mitigation. Compound pair ties retain deterministic part order.

Incoming curved projectiles query the moving boxes, including attached Block.
World flights remain immutable, with original traveled-distance/falloff values.
The binary64 flight clock maps into a saved world lease, clipping only endpoint
conversion roundoff (explicit `1e-12 s` band); it never extrapolates body motion.
Released launch origins use actual hand geometry at release. Detached Block and
released projectiles retain their separate frozen geometry/life rules.

## Current climbing integration and remaining work

2026-11-14: prescribed climbing now uses the same angular queries. The blanket
admission guard is removed. Compatible linked routes remain controlled; a
shared constraint that changes a route retires that control before future
motion is consumed. Angular impact can stop heading while retaining a tangent
climb. Real reference obstruction still interrupts. [Climbing rules](CLIMBING.md)
and [current verification](results/linked-climb/README.md) record this integration.

Fields, owned contacts, finite/raised/body support and reference-space links
use their shared consumers. Remaining boundary/order and cross-kit coverage
must still be checked before the final reproducible 5v5 experiments. Advanced
NPCs, mass simulations and balancing remain deferred; the overall Goal is
active and incomplete. Dated earlier checkpoints retain their historical scope.
