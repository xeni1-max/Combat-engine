# Per-character body geometry

2026-11-09. Verified through the complete2590-method suite and21 complete
API/CLI/hash/numerical witnesses, including the original chain/support failure.
[Evidence and reproduction](results/body-scales/README.md). Earlier supplied
body inputs retain their original proxy. The full six-kit Goal remains incomplete.

`Details2.odt` makes1E5 thirty percent taller and sixty percent wider/thicker
than1E1, and3E5 five percent taller and fifteen percent wider/thicker. These are
author rules. The approved1E1 six-cuboid body remains the reference, with local
x right, y forward and z up. Other unspecified proportions retain that size.

| Profile | Local x/y/z factors | Standing width/depth/height m | Standing centre above feet m |
|---|---|---|---|
| Reference1E1/1E2/1E3/2E4 |1/1/1 |0.7/0.3/1.75 |0.875 |
|1E5 |1.6/1.6/1.3 |1.12/0.48/2.275 |1.1375 |
|3E5 |1.15/1.15/1.05 |0.805/0.345/1.8375 |0.91875 |

The following are delegated implementation choices:

- Scale every cuboid's local centre and size by those positive exact factors.
  This preserves the approved arrangement, names and anchored feet. Compiled
  placement is labelled scaled_from_confirmed_reference, not a new author
  confirmation. Fixed standing arm proxies remain separate from ability hands.
- Preserve authored hand coordinates, weapon geometry, reach, ability distances,
  speed, cooldowns and costs in their stated units. A hand coordinate is still
  a metre offset from that character's own body origin. Crouch/prone transforms,
  solid hand reach and physical Recovery use its actual body definition.
- Preserve the approved crouch proportion: baseline legs0.8→0.4 m corresponds
  to1E5 legs1.04→0.52 and3E5 legs0.84→0.42. Thus full crouch heights are1.755
  and1.4175 m. This proportional extension is delegated. Native balance can
  deform the body further, independently of the nominal crouch fraction.
- Prone geometry rotates the scaled cuboid dimensions through the existing
  convex pose model. Resulting prone thickness is0.48 m for1E5 and0.345 for3E5.
  Get Up keeps its authored duration/cost and checks actual expanded clearance.
- Compile each actor's geometry at load, rather than sharing one pose template.
  Trait geometry remains fixed for the actor instance across lives; this adds no size-change
  ability. Characters' HP/armor and force-response weights are not scaled.

Current `data/body_hitboxes.json` enables character_geometry/profile_scale_v1;
`body_scale_xyz` in character data supplies the relative factors. Older supplied
body definitions without that mode retain their common proxy, and missing scale
data uses the reference size. This is explicit compatibility for historical
inputs; current root inputs enable the authored scales.

One per-actor definition now feeds standing placement, movement/jump/landing,
climb feet, crouch, prone/Get Up, body support, spatial transactions, hand reach,
projectile aim and area eligibility. Output character_geometry identifies each
actor's factors, standing dimensions, placement status and source; body_geometry
records the actual current cuboids. There is no visual-only resize.

Initial regressions assumed identical0.875 m origins, equal grapple-partner
centres and a ceiling below the newly taller1E5's head. Their originals and
failures are preserved in results/body-scales. Current tests now use the authored
centres, equal feet, correct half-depth and the same physical head clearance.
A remaining Get Up clearance basis call was also corrected to select its actor.
Actual mixed-roster placement, pose, native movement/support, head shots and
edge-of-area interactions now have complete regression and reproduction evidence.

The full regression also exposed shared numerical defects, preserved alongside
the geometric fixture failures. Knock expiry removes cancellation residue in
the existing contact-speed band. Taut-chain inertia subtracts the actor's own
motor request once; subtracting its projected share repeatedly accelerated a
real carrier beyond500 m/s. The corrected unequal-height interaction also
requires a feasible shared-velocity anchor near tangency. Strict distance and
objective/error certificates remain, and released-force transport includes
that anchor. See PERSISTENT_DISTANCES.md, DISTANCE_PATHS.md and KNOCK_DELIVERY.md.
