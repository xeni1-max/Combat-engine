**Independent principal engineering review — 2026-11-03**

Two high-severity defects remain in ordinary, supported scenarios. Independent
abilities can depend on unrelated input to start, and a contact caused only by
pose deformation can cancel a climb and turn its prescribed speed into a
launch. Both have reproducible causes and focused corrections. Neither requires
removing character features or replacing the engine.

This is a fresh review of the current implementation and recorded design
decisions, including the unfinished Aim/dispersion and confirmed curved-entry
changes. It covers shared scheduling, ownership, resource payment, life/effect
lifetimes, continuous damage/healing, movement, collision, bindings, grapples,
and the supported deliveries of the six existing characters. Advanced NPC
systems and balance optimization are outside scope. No implementation, character
data, existing tests, scenarios or primary sources were edited.

The review was paused and resumed at the author's request. The resumed source
matches all 392 files in the development checkpoint's
`results/aim-toggle/regression-source-before.json`. A separate 481-file review
fingerprint is saved in the [evidence package](results/principal-review-2026-11-03/README.md).
The pre-pause temporary test logs did not survive; no completed-suite claim is
based on them. The durable full-suite rerun passed **2,468 tests in 1527.217 s**.
The new review specifications remain outside that suite and expose the two
coverage gaps below. The final [integrity check](results/principal-review-2026-11-03/integrity-check.json)
confirms that only `PROGRESS.md` changed among the 481 pre-existing fingerprinted
files; the report and its evidence package are new review artifacts.

| Priority | Finding | Evidence status |
|---|---|---|
| P1 — high | N1: free resources do not reliably trigger independent abilities | Reproduced with unmodified current inputs through public API and CLI |
| P1 — high | N2: pose-only contact cancels a climb and creates unintended flight | Reproduced with unmodified current inputs through public API and CLI |

P1 means a correction is needed before relying on the affected combat or movement
outcomes. The integration risks and known limits below are explicitly separate
from these verified defects.

**N1 — Independent actions wait for an arbitrary wakeup, allowing inert input to change damage.**

At 0 ms, give 2E4 the priority list `['1', 'basic_8']` against a firing 1E2
1.1 m away. The thrust owns the right hand; Block uses the free left hand.
Both actors start on the floor, with no initial shield. Over the next 300 ms:

| Scenario | 2E4 ability starts | 2E4 final HP | Opponent final HP |
|---|---|---:|---:|
| No extra input | Thrust at 0 ms | 8773.416392 | 7727.041502 |
| Add only `stop` at 1 ms | Thrust at 0 ms; Block at 1 and 151 ms | 9080 | 7259.064752 |

The engine itself reports the added command as `movement_command_no_change`.
Its wakeup nevertheless starts Block, which intercepts the gunshot and permits
the automatic counter. Reversing the priority list is a positive control: both
independent actions start at 0 ms. This is an action scheduling/input-consistency
defect; repeated execution of an identical scenario remains deterministic.

The cause is in
[team_rules.py:58](/home/erzen/Projects/CombatSimulation/combat_sim/team_rules.py:58).
`decide_team` correctly filters conflicting resources but acquires only one
ability. At
[team_rules.py:137](/home/erzen/Projects/CombatSimulation/combat_sim/team_rules.py:137)
only `block` and `ballistic_dash` explicitly request another decision after
acquisition. Other kinds leave usable resources idle until a later phase or
unrelated input wakes selection. The asymmetric Block-first regression in
[test_blocking_combat.py:159](/home/erzen/Projects/CombatSimulation/tests/test_blocking_combat.py:159)
does not expose the reverse ordering. The same structural problem can affect
other free-resource combinations; this review does not claim every such
combination has been reproduced.

Correct this at the common eligibility/decision boundary. After a successful
action acquisition, reevaluate readiness at the same timestamp until no further
legal independent action can start. Retain priority ordering for conflicts,
phase ordering, resource reservations, and the authoritative payment checks.
Use a measurable progress condition or bounded work queue; a blocked intent
must not cause a zero-time retry cycle. Remove the ability-kind whitelist as
the mechanism for deciding whether concurrency is considered. This is a
dispatcher correction, not a request for a more intelligent NPC policy.

Acceptance: both thrust/Block priority orderings acquire the independent actions
at 0 ms; an already-satisfied movement command does not alter casts or damage;
three or more disjoint actions reach the same eligibility fixed point; shared
hands remain exclusive; costs, charges and cooldowns are applied once. Include
the original blocked compound-movement progress regression when making this
change. The new executable specifications are `test_n1_*` in
[reproduce.py](results/principal-review-2026-11-03/reproduce.py).

**N2 — A pose-only contact is treated as a translation collision before the correct handler sees it.**

Place 1E2 at `[4.59, 0]` and queue `walk` then `climb cube_1` at 0 ms, with
weapons disabled by a later start time. The climb legally begins at 210 ms,
at body origin `[4.95, 0, 0.875]`, with an upward path speed of 9.50 m/s and
completion due at 510 ms. Its own O/U starts equilibrium deformation. That
deformation touches the wall; reference translation is tangential to the wall.

At the same 210 ms, the engine cancels the climb with reason `body_contact`,
then logs `body_pose_contact` with response
`deformation_stops_reference_motion_preserved`. There is no ordinary
`body_contact` impulse in this case. The cancellation nevertheless transfers
9.50 m/s upward into free flight. At 650 ms the origin is
`[4.95, 0, 4.105392]`, airborne, with zero completed climbs. A nearby starting
x-coordinate of `4.589998` produces the same failure shortly after 210 ms;
it is not confined to an exact timestamp tie. The standing climb from x=4.6
with enough pose clearance completes normally at `[6, 0, 2.675]`.

The contact is already classified correctly in
[linked_motion.py:88](/home/erzen/Projects/CombatSimulation/combat_sim/linked_motion.py:88).
However,
[command_dispatch.py:120](/home/erzen/Projects/CombatSimulation/combat_sim/command_dispatch.py:120)
blocks the movement intent and
[climb_combat.py:337](/home/erzen/Projects/CombatSimulation/combat_sim/climb_combat.py:337)
interrupts every participating climb without respecting `pose_only`.
`interrupt_combat_climb` converts the prescribed velocity into a jump state.
The later base handler at
[mobile_combat.py:447](/home/erzen/Projects/CombatSimulation/combat_sim/mobile_combat.py:447)
correctly skips a translation response for that contact, but the climb has
already been destroyed. This contradicts [EQUILIBRIUM.md](EQUILIBRIUM.md)'s
separation of pose deformation and saved reference motion.

Make the contact classification authoritative for every consumer. A pose-only
contact must still stop the offending deformation, but it must not cancel a
tangential climb, consume its movement intent, apply a translation impulse, or
produce free flight. The immediate correction belongs in the movement-intent
and climb handlers. Keep the pose-freeze path in
`PostureCombatRules.resolve_mobile_contacts`; discarding these contacts globally
would permit deformation through solids. Preserve interruption for real
translation obstruction, imposed displacement, destroyed attachments and
genuine overhead collisions.

Acceptance: both supplied close-wall cases complete their climb without launch;
pose geometry stays outside the wall; a real overhead obstruction still
interrupts; a genuine impact before Gathering completion still delays it;
observations, participant insertion order and higher precision do not choose
the physical outcome. Run these contracts with the selected current rules.
[test_motion_boundary_combat.py:20](/home/erzen/Projects/CombatSimulation/tests/test_motion_boundary_combat.py:20)
deliberately uses pre-equilibrium rules, so its passing assertions do not cover
this integration. Preserve those historical tests and add current-rule versions
of the invariants. See `test_n2_*` and the positive controls in
[reproduce.py](results/principal-review-2026-11-03/reproduce.py).

**Architecture assessment and risks that are not additional reproduced defects.**

The implementation now has substantially stronger common foundations than the
earlier reviews: explicit action resources, actor-life generations, immutable
released-power/modifier snapshots, actual HP ledgers, consumed healing funding,
independent cooldown/effect lifetimes, shared continuous effort, saved body
paths, atomic spatial plans, and joint grapple/distance/contact handling.
Current bindings, Block/counters, revival, poison attachments, prison material,
and charge/slams use those shared systems. The old recommendations to first
create these foundations are no longer an accurate description of the project.

There remains a **medium structural risk** in implicit orchestration order.
`SharedEncounter` has fifteen rule mixins, several overrides of contact
resolution, and a long ordered sequence of controller settlements in
[shared_engine.py:1060](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:1060).
N2 proves one failure of that arrangement; this review has not reproduced a
second independent settlement-order defect. Make contact categories and
before/after-wave invariants explicit at a common coordinator. A late controller
that invalidates an earlier subsystem must either repair that dependency or
enqueue an appropriate same-time event. Add assertions for coherent motion
ownership and life-bound resources at settled boundaries. Avoid a broad rewrite
or an unconditional loop that repeatedly executes every `settle` callback.

There is also a **verification risk** when historical numerical contracts become
the only tests for a lasting invariant. Versioned fixtures are valuable for
preserving historical results. They should be paired with current-rule checks
for causality, legal concurrency, conservation and collision classification.
N2 is a concrete example of why a large passing suite alone is insufficient.
Use small interaction matrices around the changed boundary, not exhaustive
character-combination testing or large NPC experiments.

**Known capability limits and practical integration gates.**

These are acknowledged incomplete capabilities, not discoveries of broken
implemented abilities. They still matter before claiming the six kits can run
arbitrary encounters. The inventory in [ROSTER.md](ROSTER.md) and current entries
in [ENGINE_STATUS.md](ENGINE_STATUS.md) remain the appropriate starting points.

| Existing feature | Work still required before claiming integration |
|---|---|
| Walking from raised terrain; general turning | Static support-edge departure remains explicitly rejected, including by `airborne_combat.py:367`; fixed facings constrain geometry. Reuse saved paths and support-loss transitions for physical falls. Maintain explicit limits until those transitions are implemented. |
| 1E2 grappling gun; remaining leap/kick deliveries | Existing forces, anchors and body launches are useful foundations. Each actual cast still needs its own acquisition, flight/attachment, interruption, cost and landing rules. Prescribed climbing within linked groups remains guarded. |
| 1E3 portals | Atomic relocation exists; the actual portal entry/reuse controller and transport policy for attached/grappled/tethered actors do not. Commit the affected group and link changes consistently, with blocked exits and same-time entry tested. Document delegated transport choices without erasing the portal feature. |
| 1E3 duplication | Projectile identity/copy support exists; the actual 12 m field and 4 m separation do not. Reuse the existing per-source lineage guard in `projectile_world.py:194`, which prevents copying parent/child repeatedly through the same field instance. Integrate actual boundary entry and split placement using stable field identities, retaining source life, power, accuracy sample and accumulated travel. No current duplication-loop exploit was reproduced. |
| 1E1 grenade-launcher Ultimate and remaining 1E2 effects | Separate runners/metadata do not establish shared integration. Weapon replacement, remaining ammunition, independent clouds/fences and temporary Gathering modifiers need actual common-clock delivery and teardown tests. Preserve already released effects when control ends. |

These gates should be addressed incrementally after the two verified defects.
They are not a proposal to add abilities or postpone the shared engine for
advanced NPC work. The current Aim increment also remains a development
checkpoint, even if its regression suite passes: its final documentation,
evidence and status reconciliation belong to the implementation agent.

**Verification and handoff.**

The new review script contains seven test methods. Three controls pass and four
desired-behavior specifications fail, covering the two findings. All six ordinary
scenarios produce matching complete API/CLI output, including the CLI's derived
summary. Thirty captures span precision 50/80 and observations disabled or
1/37/100/113 ms; the defects retain the same discrete outcomes. The selected HP
comparison differs by at most 3e-46 across that capture matrix. Additional
controls reverse participant insertion order, and complete CLI results for
both defect cases match with `PYTHONHASHSEED=1` and `987654`. This evidence is local to these
cases, not a universal error bound or proof of every interaction.

The October 28 script as originally written now has five setup-error reports
because some cases omit dependencies required by the current world. Its original
five test methods all pass with the current gravity/jump/climb inputs supplied
by [previous_current_inputs.py](results/principal-review-2026-11-03/previous_current_inputs.py),
without changing assertions. The October 29 observation-invariance and registered
climb-prerequisite cases pass. Its two remaining failing methods encounter N2's
new pose/climb interaction; the former observation-dependent contact choice is
not reproduced. Its old heat-volume schema-error test also passes in the current
suite. Raw outputs are preserved so setup failures are not mistaken
for renewed production defects.

Implement N1 and N2 in separate changes, using the supplied scripts as regression
specifications. Then run the affected current-rule interactions and the complete
suite. Keep the old frozen evidence. Update the relevant mechanics documents
and `PROGRESS.md` with the selected corrections and their validation. No change
to creative identity is necessary for either fix.

Run from the repository root:

```sh
python3 -B results/principal-review-2026-11-03/reproduce.py
python3 -B results/principal-review-2026-11-03/reproduce.py --capture
python3 -B results/principal-review-2026-11-03/check_captures.py
python3 -B results/principal-review-2026-11-03/previous_current_inputs.py
python3 -B -m unittest discover -s tests -v
```

The first command intentionally fails on this reviewed snapshot. Evidence and
source fingerprints are described in the
[review package](results/principal-review-2026-11-03/README.md).
