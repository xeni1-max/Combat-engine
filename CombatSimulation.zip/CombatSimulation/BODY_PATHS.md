# Saved body paths

Static departure boundary, 2026-11-10: [Static face departure](SUPPORT_DEPARTURE.md) shortens the same certified saved prefix after constraint compilation. Its root bound is normalized to the scheduler's declared Decimal clock. Prediction and advancement consume that one interval; there is no additional movement integrator.

Delegated architecture decision, 2026-11-01. Current moving-world inputs select
`body_paths.mode=saved_polynomial_v1`. Existing movement, gravity, grapple,
collision and ability formulas are retained. This backend saves their current
translation polynomial and supplies it to prediction and advancement.
[Coordinator](combat_sim/saved_body_paths.py) ·
[Immutable piece](combat_sim/mechanics/body_path.py) ·
[Evidence](results/body-paths/README.md).

The later [live distance controller](PERSISTENT_DISTANCES.md), 2026-11-02, now
selects the [finite planner](DISTANCE_PATHS.md) for taut connected participants.
Its quadratic pieces certify maximum separation over their complete interval;
independent physics knots, separate drivers and per-force response preserve the
shared writer. [3E5's actual chain cast](CHAIN_CAST.md) now uses that controller.
Exact piece records now also have a reader and support large decimal ratios
without changing Python's integer-string guard; ordinary records are unchanged.

## One reference path and one advancement writer

Previously, ground movement, airborne motion, posture, climbing and linked
motion each participated in advancing body positions. Curved distance limits
need a common saved path: predicting one trajectory and advancing another
would produce inconsistent body, projectile and field contacts.

`BodyPathPiece` saves an absolute interval and exact rational reference,
velocity and acceleration coefficients. Position is `p + v*t + a*t²/2` and
velocity is its derivative. Queries cannot extrapolate outside the interval.
Slicing retains the same polynomial; a zero-duration piece is a valid snapshot
while phases at the current time are pending. Records encode ratios as strings.

The reference is the upright body reference used by atomic spatial transitions.
Pose deformation is separate: crouching can lower the reported body origin
without moving the feet or translating that reference. Existing body-part
offsets and pose rates remain in contact queries.

`SavedBodyPathRules` is the first shared-world motion mixin. When enabled, body,
terrain, projectile, Block, heat-volume and cooldown-field queries obtain the
same translation coefficients through `mobile_motion`. The coordinator alone
advances the body reference from that saved polynomial. It advances independent
driver state too, so gravity, desired ground speed and existing grapple sharing
remain coherent. Existing support and landing handlers still own their events.
Consuming an observation prefix does not increment the spatial-command revision.

The first backend saves the existing free, grapple and climb polynomials. A
climb segment is fitted to its canonical absolute-time corner/endpoint to avoid
accumulating rounded speed across observations. Its contact at a corner retains
the existing outgoing-velocity convention.

## Leases, invalidation and numerical boundaries

One immutable frame contains all actors, with canonical actor/group ordering.
Its end is the earliest existing motion knot, semantic queued event or horizon.
The live distance controller can additionally shorten it at a physical distance
crossing or its configured integration knot.
Observation timers and the horizon marker do not shorten a lease. A newly
queued earlier semantic event slices the existing piece without reanchoring at
the observation time. Future advancement rebuilds an ended lease after due
phase changes; an instantaneous snapshot can still describe that endpoint.

Action/force/support/contact/life changes and meaningful processed event batches
invalidate the frame. A signature also detects same-time changes before the
batch finishes: instability, movement direction, current armor, maximum HP,
group membership, life, position, jump/imposed velocity, climb and ground
drivers are included. This matters when incoming instability changes movement
inside the same phase batch. Driver validation checks the saved derivative and
actual reference when an observation advances time.

The world owns Decimal precision. Exact rational pieces preserve coefficients
after the existing model's Decimal calculations; this does not make those
upstream calculations exact. A `1e-35` matching tolerance reconciles driver and
reference roundoff during ordinary lease validation; constrained references use
`1e-22` to reconcile their smaller-than-contact-resolution inward inset. Neither
is a collision tolerance or a license to extrapolate. Integration controls and
their accuracy limits are documented in [PERSISTENT_DISTANCES.md](PERSISTENT_DISTANCES.md).
Frame counts are diagnostic and are not physical steps.

Frozen definitions without `body_paths` retain their prior advancement path
and result shape. Only the current locomotion JSON gains the explicit mode.
Character definitions, primary ODTs and the other runtime inputs are unchanged.

## Verified interactions and remaining work

Checks cover exact slicing, derivative coherence, immutable vectors, query
bounds, owned precision, actual ballistic flight reusing the same frame across
observations, posture, climb corners, death/revival and same-time instability.
A test disables the legacy body writer while real walk/jump still completes.
Complete saved encounters exercise gun/reload, sprint/stop, beam exposure,
cooldown-field crossings, binding/Break, elastic knock contacts and an actual
grappling pair receiving both horizontal and upward knocks. The latter retains
the author's [summed-stat resistance](KNOCKBACK.md); this architecture does not
change that formula or add binding-chain members to a grapple group.

The [live controller](PERSISTENT_DISTANCES.md) now supplies curved tether paths
with slack/inward freedom, joint contacts/grapple constraints and separate
finite-force shares/expiry. It avoids external velocity replacement at physics
knots, so compatible control and paid landing obligations survive. Engineering
attachments and [3E5's actual chain](CHAIN_CAST.md) verify these interactions.
Current [equilibrium/Get Up](EQUILIBRIUM.md) owns prone deformation, while
[living-body support](BODY_SUPPORT.md) contributes life/part contact planes.
Contact readers retain a coherent snapshot during atomic path consumption.
Broader support/turning and general5v5 completion remain unfinished.
