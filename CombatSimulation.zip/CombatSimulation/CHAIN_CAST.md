# 3E5 chain cast and spatial binding

Source import and delegated integration decisions, 2026-11-02.
`3E5.odt` p11/p100–119 defines ability 2: G180/A220, a chain released after
throwing at 30 m/s, self O/U120 on throw, target O/U60 on impact, Db3.5,
binding value 6, 15 s duration and 20 m chain length. The overview gives a
9 s cooldown. The throw is intrinsic momentary; the subsequent attachment is
binding. Primary documents remain unchanged.

## Phase and geometry decisions

The source supplies no damage, hand coordinates, cooldown anchor or precise
dyspnea-payment point. Under delegation, the cast uses the existing neutral
right-hand pose and 2 cm spherical projectile, current-torso compensated short
arc, native gravity and no target lead. Pay Db3.5 at throw completion, just
before release: action cost is 12.25 by the existing dyspnea formula. Start the
9 s cooldown at the same firing-end anchor used by shared projectile actions.
An uninterrupted stationary cast releases at 400 ms and becomes ready at
9400 ms. Author-confirmed on-throw self statuses apply at Active midpoint,
290 ms in that case. Existing Recovery, running modifiers and disorientation
can change those times.

If the original target is algebraically unreachable at the supplied ballistic
speed, a delegated fallback aims at a reachable proxy in that direction within
the chain's extension. The same flight/contact/range rules then produce a paid
miss. Reachable targets keep the faster arc unchanged. This prevents distant
valid battlefield positions from crashing the cast; it is not target lead or a
claim that the original aim point was reached. The trace records the requested
point and proxy rule. Numerical solver failures are still reported explicitly.

The right hand/ability weapon owner is occupied only during casting. After
release, the projectile and binding are independent of that controlled action.
Other legal actions and multiple chain instances retain their own owners and
clocks. Death or upper-body restriction before payment cancels unreleased work
without a cost. Already released flight survives the caster's death.

This is a **zero-damage contact projectile**. It uses the existing typed
`contact` packet, not an invented damage amount. Its intrinsic phase records
zero damage output; the binding's authored B6 is an independent effect, not a
damage value attenuated by the intrinsic damage formula. Target O/U60 uses the
same pre-hit armor/status snapshot as other simultaneous impacts. Contact
alone spends no personal shield HP, armor, HP or damage-credit/healing funding.
Independent Block surfaces and solid terrain intercept it, with no fictitious
damage or attachment to the shield's owner. Friendly bodies can intercept it.

## Moving flight limit and attachment

A living original caster supplies a moving 20 m spherical envelope, measured
from its upright translation reference to the projectile centre. The first
outward crossing ends flight without creating an impact. This represents full
chain extension; it is separate from terrain/body collision. A caster moving
toward a distant target can bring it into reach, while retreat can exhaust
the chain before reaching a previously near target.

[The exact crossing helper](combat_sim/mechanics/distance_events.py) isolates
the quartic squared-distance polynomial for two quadratic paths, including
initial taut/outward states, internal tangencies and endpoint crossings.
[The range adapter](combat_sim/projectile_limits.py) uses the saved source
lease's absolute interval, not a new polynomial rooted at each observation.
The undecelerated ballistic projectile is quadratic; its physical contact path
retains the existing binary64 implementation. Range events use the existing
gravity event quantum, validate projectile revision/original life and the
anchor's witnessed position after due phases, and create no damage.
Physical impacts at the same numerical tick resolve before maximum-extension
removal, matching the existing inert-stop rule. A consumed contact cannot then
be removed a second time by its stale range event.

On body contact, the target's upright reference must be within 20 m of the
living original caster's reference. This matches the shared controller's
initial attachment model. A body edge can be contacted while its reference is
outside that limit: impact statuses still apply, but attachment reports
`outside_maximum_distance` and creates no partial binding/constraint.
Hand/socket-specific chain attachments remain a later geometry extension.

An unanchored projectile still travels after source death or restoration, and
can deliver its released contact statuses. It cannot attach to a dead or new-life
caster. Requiring living physical endpoints is a delegated lifetime rule,
consistent with the current removal of dead-body collisions; it avoids an
immovable corpse anchor. This is not a source-death rule for independent beams,
marks or other summons.

## Common binding and Break lifecycle

`BindingEffects.create(..., kind='distance', maximum_m=...)` creates one spatial
binding and one [persistent distance row](PERSISTENT_DISTANCES.md), with the
same endpoint lives and expiry. It imposes no arbitrary limb freeze. Existing
slack, inward and tangential movement, joint contacts/grapples, gravity and
individual knock-force expiry continue through shared saved paths.

Common `break`/`break_binding` focuses one eligible binding. It uses the source
maximum-HP escape threshold, disorientation-paused 20/s filling and separate
escape work at the dyspnea cap. Escape ends that binding and its distance row
at the same instant. Expiry, recipient death, anchor death, or external
separation also release both; a focused Break ends with them. Release preserves
transmitted physical momentum. A revived participant inherits neither the old
binding nor its constraint. Independently active duplicates retain their own
lifetimes and Break focus.

A chain is binding, not a grapple. The author's [knockback rule](KNOCKBACK.md)
still sums actual grapple participants before nonlinear resistance and applies
equal group increments. Tether-only actors share the resulting constrained
motion without being added to that resistance group.

## Implementation and verification boundary

The ability is a selectable `binding_projectile` in the shared action/projectile
pipeline. Binding contact runs after the complete simultaneous HP/death batch;
an already dead recipient cannot receive a new attachment. The existing
projectile identity, source life, ownership, cooldown, effort, Block, HP ledger,
binding/Break and persistent-distance controllers are reused. There is no
separate chain simulation engine.
Range, binding parameters and impact statuses are copied into the released
entity. Later profile changes cannot rewrite them, and the existing projectile
copy API retains that payload without another action payment. Flights without
this payload do not query an anchor or require the richer encounter interface.

The final 2096-test full suite, 35 focused methods and ten ordinary complete
API/CLI captures pass. [Evidence/reproduction](results/chain-cast/README.md) and
[PROGRESS.md](PROGRESS.md) record controls, diagnostics and preserved history.
Full six-kit and reproducible 5v5 completion, other
freeze/construct/portal deliveries, leap/kick and charge/slam remain unfinished.
The subsequent [1E1 ground chain](GROUND_CHAIN.md) now supplies typed fixed
terrain endpoints. Its physical collider lifetime is separate from caster
attribution; it does not inherit this ability's living-caster endpoint rule.
