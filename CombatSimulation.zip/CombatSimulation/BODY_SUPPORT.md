# Living-body contact and support

Static terrain extension, 2026-11-10: Static tops now share positive-area underside witnesses and common support-loss closure. See [SUPPORT_DEPARTURE.md](SUPPORT_DEPARTURE.md) for saved-prefix departure, alternate supports, native flight and the separately guarded outer-floor boundary. Historical body-support contracts retain their source inputs.

2026-11-02. This is a shared contact mechanic, not a new character ability.
The author specifies body collision direction, status pressure, removal of
normal movement, gravity, noncolliding dead bodies and interruption by physical
displacement. The following support policy is an engineering decision under
the author delegation. Verification status lives in [PROGRESS.md](PROGRESS.md).

## Contact model

The optional `body_support: {"mode": "resting_body_faces_v1"}` input uses the
existing six cuboid proxies and current crouch/equilibrium poses. A part's
underside may rest on another living body's top face when their vertical gap
is within the existing 1e-20 m contact resolution and their horizontal overlap
has positive area beyond that band. Face edges with separating horizontal
motion cannot create a new standing contact. Dead bodies never supply support.
An actor's reported support parent is a deterministic living path to a static
support; a floating stack has contacts but is airborne.

Each witness identifies both actors, both life generations and the two parts.
Native impacts retain the authored centre-line relative-speed calculation and
per-actor resistances. Establishing a resting reaction does not repeatedly add
collision statuses. A newly imposed inward velocity requires a native impact;
continuous gravity at a previously resolved resting contact is a reaction.
Taking off, dying, restoring a life, changing poses, losing overlap or removing
underlying terrain changes the contact graph. Alternate valid supports are
selected without fabricating a fall or a second landing.

There is no horizontal friction rule in the source. This increment therefore
does not copy a carrier's horizontal translation to the upper actor. Either
actor can walk away from the contact. This choice is distinct from an actual
grapple, whose authored joint movement and summed-stat knock resistance remain
in force. Merely touching or standing on someone never grants that resistance.

## Shared path and pose ownership

`BodySupport` owns witnesses and admission. It contributes one-sided relative
vertical planes to the existing `PersistentDistances` compiler. That compiler
already joins real grapples, taut/fixed tethers and solid contacts. It now also
accepts contact-only graphs without inventing distance bindings. All resulting
reference translation still goes through `SavedBodyPaths`; there is no carrier
position-copy loop or second movement integrator.

Saved-path consumption is an atomic geometry/driver update. Support queries
inside its per-actor writes retain the preceding coherent witness/admission
snapshot. Discovery and retirement run after all endpoint states and the shared
clock are installed. Intermediate mixtures of begin/end geometry cannot create
contact-history records or change the graph being consumed.

An upper actor requests the ordinary -9.81 m/s² gravity while supported by
a body alone. An independent static floor/platform retains its existing
reaction; an incidental body witness must not add another gravity request.
The shared reaction can cancel unsupported gravity against a rooted stack. A free stack
falls with one gravity, rather than accumulating it once for each contact or
converting it into a persistent knock contribution. Existing finite force
transport and expiry remain separate from this base acceleration.

The existing pose-obstruction policy is retained: a closing deformation gets a
native contact and stops; a withdrawing deformation releases support. Standing
and Get Up retain their clearance checks. No automatic pose-driven lifting is
added. Part-centre and part-size velocity/acceleration participate in discovery,
native sweeps and departure. Only contacts with zero normal pose motion supply
a resting reference plane. Vertical body planes in the generic resting cache
cannot also keep a withdrawing part supporting a tethered actor.

Horizontal overlap departure is located analytically on quadratic part-face
paths, including translation and pose-size changes. The selected saved prefix
ends at that boundary, using a root upper bound within the existing contact
band so repeated lower-bound replanning cannot stall there. This uses the
current distance planner's at-most-5 ms leases; observations retain the saved
prefix and are not new physical integration knots.

Native prediction and contact revalidation share one stationary-face tangency
rule. A face within the existing 1e-20 m distance, 1e-24 m/s speed and 1e-24 m/s²
acceleration resolutions is nonpenetrating when its normal motion is zero at
that resolution. Tangential movement past another edge cannot then create a
corner impulse from subresolution overlap. The full crowded control exposed
such an impact from 1.12e-78 m overlap at 80-digit precision. Genuine inward speed,
acceleration and positive-area overlap still collide. Historical inputs without
this support mode retain exact-face sweep behavior; no tolerance is widened.

## Loss, landing and inspection

Support loss goes through the common spatial transaction, retaining actual
physical velocity and independent legal actions. A moving/withdrawing/dead
carrier cannot leave the upper actor silently suspended. Terrain removal can
release an entire stack. Prospective placement/restoration checks use the
proposed cuboids; an existing support-loss transaction uses present witnesses
so it cannot reattach the contact it is releasing.

Native airborne handling establishes a rooted top-face landing and removes its
small root-rounding penetration using the actual touching parts. A basic jump's
owed landing self effects apply once. Later physical falls/recontacts caused by
collision-driven balance changes retain their own collision statuses without
repeating that payment or owed landing effect. Death and new life generations
cannot reuse the deceased carrier's witness. Occupied restoration remains an
atomic refusal until there is room for the restored full pose.

Results expose `body_support_rules`, `body_support_contacts` and
`last_committed_body_support_plan`. The latter includes the actual shared
polynomial and exact projection/distance certificates. Event records distinguish
contact start/end, parent changes, common `world_support_lost`, and real impacts
and landings. Geometry-only stacking interventions in verification are labelled
engineering operations; they are not selectable character abilities.

## Boundaries

This subsystem does not claim a universal multi-body convergence or energy
certificate. It composes the current collision response, numerical contact band
and certified finite path planner. Selected [static-face support](SUPPORT_DEPARTURE.md)
now handles ordinary raised ledges; older inputs keep their guard. Outer-floor
departure is extended by [finite ground](FINITE_GROUND.md), and
[angular support](ANGULAR_SUPPORT.md) now composes actual rotating witnesses
against candidate saved paths. Active linked turning and prescribed climbing
remain guarded. Portals, duplication and the
roster casts have shared delivery; complete cross-kit/5v5 validation remains.
Advanced NPCs, mass simulations and balancing automation remain deferred.

[Shared collider rules](WORLD_COLLIDERS.md) · [Saved paths](BODY_PATHS.md) ·
[Distance controller](PERSISTENT_DISTANCES.md) · [Spatial transactions](SPATIAL_TRANSITIONS.md)
