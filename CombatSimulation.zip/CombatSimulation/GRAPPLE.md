# Grapple rules and implementation boundary

**Current angular integration, 2026-11-13:** [active linked turns](ANGULAR_LINKS.md)
retain each hold, its independent work/lifetime, the fixed world reference offset
and the author's summed-stat knock rule. Real angular impacts use the shared
contact response. Prescribed angular/linked climbing remains unfinished.

**Author clarification, 2026-11-01, reaffirmed 2026-11-02:** when a participant receives knockback
while the grapple still holds, the participants are knocked together. The
resistance formula uses their summed stats (maximum HP, current armor), summed
before its exponent. Knock away/back are synonyms; knock up/down change the
direction. [Knockback source and integration](KNOCKBACK.md). This does not
automatically turn a binding chain into a grapple or combine damage/status
defenses for unrelated incoming effects.

**Current authored delivery:** [1E5 grab/holding](GRAPPLE_DELIVERY.md) now starts
from real hand-capsule contact, preserves the full grab Active, transfers hand
ownership atomically and supplies 3 s of owned 900/s constriction/tear and
continuous effort to the shared layers. Actual death/revival, multiple holds,
heat overlap and imposed group motion are checked. Common
[Break/controller response](GRAPPLE_BREAK.md) now executes through life-bound
inputs, continuous escape and actual-gain penalties.

**Inventory correction, 2026-11-01:** the source explicitly names the target's
Break ability for grapple escape (p10). It is not physical stopping by opposite
movement input (`Details.odt` p38). [ROSTER.md](ROSTER.md) previously conflated
these; that description is corrected. Break and physical special stopping now
execute as separate mechanics. No new ability is introduced.

Primary source added by the author: `Grapple abilities.odt`, 2026-10-29.
Read together with `Binding abilities.odt`, `Dyspnea details.odt`, character
profiles and explicit author clarifications. The author ODTs are unchanged.
Paragraph references count all ODT text paragraphs from zero, including blanks;
the four equations are embedded MathML objects, not ordinary paragraph text.

## Source rules

A grapple can slow, restrain, drag, latch onto or move two participants together.
Its spatial behavior comes from the particular ability; a generic grapple does
not automatically freeze both participants or replace their whole ability kits.

Let `D_a/D_b` be controller/defender dyspnea, `O_a/U_a/O_b/U_b` their current
disorientation/instability after their application rules, and `E=100-D` the
empty bar space. The source calls those statuses `M_a/N_a/M_b/N_b`.

| Mechanic | Formula/rule | Primary location |
|---|---|---|
| Controller exhaustion | Holding ends at `D_a >= 100-(O_a+U_a)/10`. | p3/p7, Object 1 |
| Immediate Break comparison | `E_b-E_a >= (O_b-O_a+U_b-U_a)/10`, including equality. | p10/p14, Object 2 |
| Failed initial comparison | Controller has a short opportunity to respond with the same grapple input. A timely response makes both bars fill for the rest of the grapple; escape occurs when the comparison becomes satisfied. | p10 |
| Break filling | Specific source reference: 20 dyspnea/s. Scaling with grapple cost is described as a possibility, without a proportional formula. | p10/p14 |
| Escape penalty | Everyone in the grapple gains disorientation and instability with base `3*A`, where A is total dyspnea gained through Break during that grapple. | p17/p21, Object 4 |
| Shared movement | `v=(w_a*v_a+w_b*v_b)/(w_a+w_b)`, `w=(H/500+armor/10)^1.1`. H is maximum HP and armor is current armor. | p25/p29, Object 3 |

Velocities are vectors in the same coordinate frame. This weighted average is
not a projectile-aiming rule, a kg mass, or a collision/constraint solver.
Shield HP and additional status resistance do not occur in the weight formula.

## Classification and source consequences

- **1E5 ability 2:** source p84 explicitly says Grapple. Its authored drag lasts
  three seconds, deals 900 constriction/tear damage/s, and has a nine-second
  cooldown (p9/p69). 100 ms Gathering/180 ms Active and midpoint grab remain documented.
  The previously confirmed self-status-at-impact clarification remains in force.
- **3E5 Ultimate:** p186 explicitly says Grapple. First-target grabbing, an
  eight-second hold, its two-second +50% charge speed and wall-slam/destruction
  identity remain. Wall damage is 700 blunt; p171 names constriction/tear for
  dragging but supplies no drag DPS. Do not copy 1E5's DPS into this kit.
- **3E5 ability 2:** p119 explicitly separates its intrinsic momentary throw
  from the **binding** phase. Moving together at a taut chain does not replace
  its binding release rules with a grapple contest. Its length/duration remain
  20 m/15 s.
- **1E2 grappling gun:** its name alone does not establish a two-character
  grapple contest. Preserve its projectile/environmental launch phases.

Grapple/binding describes an interaction/control model; it does not replace the
separate [effort categories](ABILITY_EFFORT.md). Sustained output, independent
objects and dyspnea payment must still follow the actual controlled phases.

## Delegated mathematical interpretations

These choices implement the equations without adding author confirmations:

- Use the supplied **current adjusted statuses**, including self statuses as
  actually applied. Do not mitigate an already-adjusted value again.
- Floor the controller's reduced full-bar threshold at zero. Status totals of
  1000 or more therefore leave no capacity to hold; D never becomes negative.
- Read empty-capacity advantage as `E_b-E_a = D_a-D_b`. Keep the signed status
  correction. A more impaired defender needs more advantage; a more impaired
  controller is easier to escape. Exhaustion and the escape comparison are
  separate facts; this algebra does not arbitrate simultaneous release causes.
- Use **20/s as the default specific Break filling rate**. Ordinary recovery
  stays 30/s stationary/walking, 18/s running and zero under the documented
  blockers. Grappling already blocks ordinary recovery; it does not itself
  create Break effort. Do not reverse the ordinary recovery rate into filling.
- Binding explicitly pauses Break filling while disoriented; the new grapple
  text does not state that pause. Do not silently copy binding behavior into
  grapple behavior. The generic effort helper advances only the supplied active
  interval and rate, before caps or pause scheduling.

The [actual delivery](GRAPPLE_DELIVERY.md) and [Break controller](GRAPPLE_BREAK.md)
record concrete holding cost, response duration, actual-gain aggregation,
penalty phases and boundary arbitration. These are delegated profiles, distinct
from the primary source equations and author confirmations.

## Implementation and next integration

[grapple.py](combat_sim/mechanics/grapple.py) retains exact fatigue/escape/effort
calculations and the source two-body vector helper. [Source registry](data/mechanics/grapple_rules.json)
records primary formulas, the author's new knockback rule and selected delegated
interpretations. `body_status_weight` still owns the unchanged 40-digit weight.

[Persistent linked motion](LINKED_MOTION.md) now evaluates all participants'
independent drives through a shared connected-component projection on the
combat clock. It propagates external changes atomically and transmits collision
movement loss without duplicating statuses onto noncontacting partners. Real
jumping, stopping, gun damage, current-armor changes, fatigue, death, actual
revival and simultaneous contacts are verified. A real unequal-drive jump
regression exposed and corrected double averaging. Links retain both lives;
retired control cannot attach to a revived target. [Evidence](results/grapple-motion/README.md).

[Knockback resistance](KNOCKBACK.md) now snapshots actual group membership and
sums maximum HP/current armor before the nonlinear reduction. A force applied
to one member moves the entire current group at the requested physical velocity,
without another weight division. Binding chains remain separate.
Current cast delivery pins that membership before the hit's own statuses can
exhaust the controller. Forces apply after complete character HP/status work
and before fatigue/new attachments, with life-bound recipients and additive
components. [Impact timing correction](KNOCK_DELIVERY.md).

**Engineering link controls remain distinct from authored casts.** They acquire
no character limb resources or holding effort. Actual 1E5 contact/holding now
uses this coordinator with phase ownership, damage, effort and life teardown;
[delivery decisions and evidence](GRAPPLE_DELIVERY.md) record the boundary.
The Break/controller-response lifecycle, actual heavy/upward knocks and
[3E5 chain](CHAIN_CAST.md) now compose. The [3E5 charge](CHARGE_GRAPPLE.md) now
uses the same holding/Break coordinator, with owned forward contacts and
conditional material fracture. Current full verification status is in PROGRESS.md.
Downward kick and environmental linked deliveries remain unfinished. Use this coordinator
rather than replacing it with pairwise writes or a second runner. General
ledge/dynamic-support and prescribed linked-climb guards remain explicit.
