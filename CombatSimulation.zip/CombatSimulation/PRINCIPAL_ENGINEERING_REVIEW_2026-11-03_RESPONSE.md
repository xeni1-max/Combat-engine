# November 3 engineering review corrections

Both P1 findings are justified. The unchanged review script reproduced four
failed desired-behavior specifications before the corrections and passes all
seven methods afterward. Production edits are limited to three files; character
data, primary sources, numerical tolerances and payment rules are unchanged.
All 2492 full-suite tests pass, and the final integrity audit preserves the
review, original sources and every preceding result file.

## N1: independent action readiness

`StationaryTeamRules.decide_team` now requests same-clock reconsideration after
every successful owned acquisition. The common queue still resolves due phases
before decisions, and existing priority, requirements, reservations, charges and
payment gates remain authoritative. No available option means no new retry.
Nonempty disjoint ownership and positive action durations bound acquisition at
one clock; no new settlement loop or arbitrary concurrency cap is introduced.

The original scene now starts thrust and free-hand Block at 0 ms. Adding the
stationary stop at 1 ms changes neither HP receipts, released shots, costs nor
ability start times. Both runs finish with A=9080 HP and
B=7259.064752135059... HP. Previously A had 8773.416392163199... HP without that
inert input. Four existing disjoint actions also start together; conflicting
hands and insufficient dyspnea capacity still deny acquisition.

Correct concurrency changes former serial setups. Enhancements grant at their
documented completion, so an early strike remains unbuffed where appropriate.
A dash may make an overlapping grab miss. Additional legal Block layers can
prevent a counter from reaching HP. Five old test files now explicitly prepare
the conditions their damage/lifecycle contracts require, with labelled hand or
locomotion restrictions. Formula, defense-sharing, once-only payment, mutual
death and clipped revival-credit assertions remain. Current-input cases also
test the ungated concurrent outcomes. Original test sources are archived.

## N2: pose contact during climbing

`MovementCommandRules` and `ClimbCombatRules` now honor `pose_only` before
blocking an intent or interrupting a climb. They forward the complete live
contact list to posture handling, which still freezes the blocked deformation.
Tangential reference motion remains prescribed rather than becoming free flight.

Both supplied close-wall cases complete at 510 ms on cube_1, ending at
`(6, 0, 2.675)` with one climb payment. Previously they became airborne near
z=4.1054 with no completed climb. Read-only inspection of the actual six body
boxes at 1 ms observations checks solid clearance. A genuine contact at
209.999 ms still delays Gathering to 286 ms and completion to 586 ms. A real
roof, imposed velocity and target expiry still interrupt through the existing
physical/lifetime rules. No contact tolerance or pose law is relaxed.

## Verification

- All seven unchanged review specifications pass; five preceding review
  invariants also pass with current required world inputs.
- Twenty-four new permanent current-input methods cover the findings and
  nearby concurrency, modifier, guard, grapple/dash and climb interactions.
- Focused logs: 43 readiness/ownership/command checks, 108 current/enhancement
  checks, 27 final dash/counter checks and 68 posture/contact checks pass.
- Sixteen complete API/CLI comparisons, eighty observation/precision captures,
  sixteen reversed-participant controls and six complete hash-seed comparisons
  pass, with HP conservation, unique payment keys and disjoint ownership audits.
- Final canonical **2492-method suite passes in 1627.776 s**, exit code 0.
  All 393 source/data/test/scenario files remain identical to their pre-run
  hashes. The earlier known-failing attempt was stopped
  to correct explicit preparation fixtures and is preserved separately.
- The final integrity audit confirms all 5186 prior result files and fourteen
  primary ODTs unchanged, with only the documented production/test/documentation
  edits to reviewed files. Source/evidence manifests and verification output
  are sealed. Failed fixture-schema/setup logs are retained, not overwritten.

[Evidence and reproduction](results/principal-review-fixes-2026-11-03/README.md).

## Remaining engineering work

The review's orchestration concern is a structural risk rather than a third
reproduced bug. These fixes use the existing queue/contact classification and do
not add another ordering-dependent settlement pass. Extend explicit ownership,
contact receipts and invariants at the next actual subsystem boundary.

The overall six-character/5v5 Goal is incomplete. Next reconcile the unfinished
Aim/confirmed-entry evidence and documentation, then use the current capability
index to select the next shared missing delivery. Advanced NPC behavior, mass
experiments and balancing automation remain deferred.
