# Whole-body turning — timing and initial native integration

Author rule, 2026-10-25: 90 degrees per 150 ms, with that time increased by
200 ms per 5 m/s of current movement speed.

For supplied nonnegative speed v in m/s:

```
time_per_90_ms(v) = 150 + 200 × v / 5 = 150 + 40v
angular_speed_degrees_per_second(v) = 90000 / (150 + 40v)
```

At unchanged speed, duration for an explicit angle magnitude is
`abs(angle_degrees) / 90 × time_per_90_ms(v)`.

| Movement speed | Time per 90° |
|---|---:|
| Stationary, 0 m/s | 150 ms |
| Walking, 2 m/s | 230 ms |
| Running, 6.4 m/s | 406 ms |
| Sprinting, 11.2 m/s | 598 ms |

[mechanics/turning.py](combat_sim/mechanics/turning.py) implements the confirmed
exact rational timing. [data/movement/turn.json](data/movement/turn.json) retains
the author source values. The isolated helper chooses neither steering nor speed
sampling. Its historical checkpoint passed 676 tests; current verification is
indexed in [ENGINE_STATUS.md](ENGINE_STATUS.md).

## Initial native scope — 2026-11-13

[Owned whole-body turns](NATIVE_TURNING.md) now execute explicit signed angles on
the shared action, translation, contact, projectile and life timeline. The six
source profiles use their actual body geometry. Stationary/walking turns, real
gunfire and Block, wall/body impacts, observations and fatal interruption are
covered by actual engine tests and complete captures.
The [owned-contact extension](TURNING_CONTACTS.md) adds charge-grab and falling
foot sweeps following live owner/target heading, with original phase/life rules.
The [field extension](TURNING_FIELDS.md) adds continuous heat/cover, cooldown,
gas and electrical contact on the shared saved path.

Delegated runtime choices: sample physical xyz speed once at Active start,
retain existing world movement direction, and use a separate heading resource
requiring lower-body control. No shortest-arc/NPC choice or new character ability
is inferred. Local hands and controlled body geometry follow the actual frame;
released objects retain their separate lifetimes. [Full rules and limits](NATIVE_TURNING.md).

This uses [continuous angular paths](ANGULAR_PATHS.md), not an end-facing flip,
expanded-AABB hit substitute or stationary-pose sampling. The saved reference
writer remains authoritative; query slices keep the angular anchor. The current
constraint planner is already quadratic. [Angular support](ANGULAR_SUPPORT.md)
now includes finite/raised/body witnesses, departure and native landing.
[Active linked response](ANGULAR_LINKS.md) preserves reference metrics, cached
contact lifetimes and actual impact response. Prescribed climbing remains
explicitly guarded pending its integration. That guard is a development
boundaries, not permanent mechanics or a claim of completed six-kit turning.

[Current evidence](results/native-turning/README.md) preserves source preimages,
failures investigated, controls and the concrete next steps. The overall Goal
remains active and incomplete.
