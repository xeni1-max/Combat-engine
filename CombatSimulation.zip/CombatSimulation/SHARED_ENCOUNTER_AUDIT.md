# Shared stationary encounter: 1E1 versus 1E2

Current numerical contract, 2026-11-10 (R2 correction): the common constructor
validates requested precision (at least 40 digits) before loading. Initialization,
including Fraction conversion, geometry, subclass load hooks and initial
snapshots, runs in a fresh Decimal context with that precision and
ROUND_HALF_EVEN. Execution establishes the same contract independently. Caller
precision, rounding, traps and flags are restored on success and failure.
Direct construction, subclasses and the public wrapper share this entry point;
the wrapper no longer owns a second initialization contract. Verification is
recorded in [PROGRESS.md](PROGRESS.md).

This audit describes the earlier controlled duel, whose complete saved trace
remains reproducible. The current shared engine also executes the broader
[stationary 2v2 scope](STATIONARY_2V2_SPEC.md), including physical Recovery,
dyspnea, authored simultaneous-event handling, death and shield regeneration.
Restrictions below apply to this earlier duel's explicit scope.

Current shared-world [phase effort](ABILITY_EFFORT.md) uses source-reviewed
intrinsic Qard release power and sustained gun interruption. The earlier duel's
450-Qard routing below is historical, not the current effort rule.

This stage integrates existing supported mechanics on one clock. Primary sources
are the root ODTs. `reference_material_non_authoritative/` is optional background material, not the
project being implemented or an authoritative mechanics source.
Explicit author clarifications take precedence. No author ODT is modified.

## Confirmed rules used

| Mechanic | Specification | Reference |
|---|---|---|
| Incoming disorientation during Gathering | Add the newly mitigated amount to the remaining Gathering | Author clarification, current shared-encounter stage; `Collision details.odt` p0/p2/p6 |
| Disorientation after Active starts | Does not insert additional Gathering into that Active | Earlier author clarification |
| Beam independence | Once summoned, the beam operates independently for its lifetime | Author clarification, current shared-encounter stage |
| Projectile | 140 ms Gathering, 180 ms Active, self 140/140 at midpoint, release after Active, 100 m/s; 450 Qard at impact and 500 ms later; target 110/110 both | `1E1.odt` ability 1 p3/p45-p66; earlier clarifications; data timing profile 1 |
| Projectile readiness | Automatic 1150 ms weapon cooldown after firing | `1E1.odt` p57 |
| Beam | Gathering 180 ms; Active 300 ms; starts at Active start; lifetime 3000 ms; output 900, k=2; cooldown 9000 ms from activation | `1E1.odt` p9/p104-p116; earlier author clarifications |
| Heat | Continuous analytic accumulation; current armor/resistance; no armor loss or statuses; each beam independent | `Damage types.odt`, Heat; earlier author clarifications |
| Shielded heat | Zero defenses; no HP exposure while shielded; active shield break starts HP exposure at zero; residual shield heat terminates at shield break | Earlier author clarifications; `1E1_ABILITY4_AUDIT.md` |
| Gun | Base Gathering 0, Active 40 ms, self 135/135 midpoint, release at end; damage 437 minus 0.25 per metre, piercing 18, speed 900 m/s, acceleration -300 m/s² | `1E2.odt` ability 1 p3/p50-p74; earlier clarifications |
| Gun readiness | Automatic 360 ms weapon cooldown after firing; 11 ammo; empty reload adds current-disorientation Gathering then 1800 ms Active; overlaps cooldown | `1E2.odt` p3/p62/p64; earlier author clarifications |
| Slash and bleed | Shield first; overflow supplies pre-mitigation HP damage; HP damage before armor loss; target statuses use pre-hit armor; independent eight-second bleeds on HP | `Damage types.odt`, Slash; earlier clarifications |
| Status | Incoming mitigation, additive stacking, decay 1/ms; self effects unmitigated; minima zero | `Collision details.odt`; earlier author clarifications |
| Shield recovery | Each loss waits 20 seconds, sharing 400 HP/s thereafter | Character basic ability 7 and author clarifications; no loss in this 10-second run is eligible |

Action/phase/travel timestamps round upward to integer milliseconds under the
author's rounding instruction. A new Gathering extension adds its mitigated
amount to the currently scheduled Active start, then rounds upward. This is the
explicit numerical convention for applying the existing instruction successively.
Continuous damage boundary times retain fractional milliseconds.

## Established controlled scope

Two independently identified instances use canonical character data, full starting
HP/armor/shields, supplied 10-metre paths, stationary positions, confirmed hits,
and explicitly selected-target-only area recipients. Additional participants are not automatically added to an area without supplied geometry/eligibility. A replaceable priority policy chooses beam before
projectile when available for 1E1, and gunfire/reload for 1E2. Ability selection
occurs after combat events at the same timestamp. This decision convention is
part of the scenario policy. Weapon readiness does not block another ability.

The observation lasts 10 seconds or stops when HP first reaches zero, retaining
pending actions/effects without inferring death, cancellation, victory or revival.
Coupled simultaneous impacts/phase transitions with unspecified ordering are
rejected instead of using insertion order as an authored combat rule. Independent
cross-target events can occur at the same time.

## Explicitly unsupported eligibility and missing rules

- **Recovery/weapon transitions:** `Details.odt` p20-p27 defines repositioning
  hands before Gathering. Required poses/distances for switching these abilities
  are missing. Transition eligibility is excluded from this controlled study;
  zero physical Recovery is not asserted as a game rule.
- **Dyspnea:** `Dyspnea details.odt` specifies `Da=(Db+D/100)^2`, capacity gating
  and recovery blockers. The mapping/charging anchor for listed costs and costs
  absent from beam/reload remain unresolved. Dyspnea legality is excluded.
- **Accuracy and geometry:** supplied hit and area eligibility do not execute
  accuracy, hitboxes, projectile collisions, cover or movement.
- **HP zero:** later actions/effects and encounter outcomes need death rules.
- **Simultaneous coupled events:** damage ordering against one shield/armor state
  and incoming status exactly at a phase transition remain ambiguous.
- **Shield regeneration within a longer encounter:** the shared runner rejects
  observation windows reaching the regeneration delay; it records loss history
  but does not claim to execute recovery merely because timer fields exist.

Consequently, this is an interaction study under stated action eligibility, not a
complete legal match or a character-strength ranking. The duel itself does not
change the armor of the heated target: 1E2's gun damages 1E1 while the beam heats
1E2. A separate test must exercise current-armor heat after an armor-changing hit.

## Validation of the implemented stage

The complete suite passes **365 tests**, including shared-state interactions,
successive Gathering extensions, independence of the deployed beam, pre-hit
status mitigation, shield/HP conservation, magazine/reload transitions, rejection
of coupled simultaneous events, and HP-zero observation boundaries. Passive
subcases agree with the earlier ability-family benchmark. A separate three-actor
fixture verifies heat responding to another actor's armor-changing attack.

The shared runner uses 50-digit Decimal state and analytic continuous integrals,
with established 40-digit incoming status mitigation. Damage is not rounded to
integers. An 80-digit reference and alternate 137 ms observation spacing preserve
action cadence and agree within 1e-20 for the checked final states. This numerical
evaluation is distinct from the older symbolic exact runners.
