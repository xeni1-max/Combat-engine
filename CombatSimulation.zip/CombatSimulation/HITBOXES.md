# Six-cuboid body geometry

## Confirmed author definitions

One body has six cuboids: one head, one torso, two arms and two legs. Sizes are
in metres. The author clarified the torso axis order and selected fixed standing
hitboxes for this first model. Local axes remain x right, y forward, z up.

| Part | Count | Size along local x, y, z (m) |
|---|---:|---|
| Head | 1 | (0.25, 0.25, 0.25) |
| Torso | 1 | (0.5, 0.3, 0.7) |
| Arm | 2 | (0.1, 0.1, 0.8) |
| Leg | 2 | (0.2, 0.2, 0.8) |

Fixed hitboxes do not follow the ability hand poses or their Recovery movements.
Those numerical hand positions continue to determine action timing separately.
No headshot bonus, limb damage multiplier or damage-type change follows from
having a named head/limb cuboid.

## Confirmed standing placement

The author reviewed and approved the following upright standing arrangement,
including its origin and six centres.
All cuboids align with the local axes. Legs touch the torso's underside; the
head touches its top; the arms hang against its sides. No neck, hands or feet
are separate collision shapes in the requested six-part model.

Place the origin at the centre of the complete body's combined bounds,
preserving the existing body-centre reference used for hand positions. This is
the centre of the outer bounds, not the torso's centre or a centre of mass.

| Cuboid | Confirmed centre x, y, z (m) | Vertical bounds z (m) |
|---|---|---|
| Head | (0, 0, 0.75) | 0.625 to 0.875 |
| Torso | (0, 0, 0.275) | -0.075 to 0.625 |
| Left arm | (-0.3, 0, 0.225) | -0.175 to 0.625 |
| Right arm | (0.3, 0, 0.225) | -0.175 to 0.625 |
| Left leg | (-0.1, 0, -0.475) | -0.875 to -0.075 |
| Right leg | (0.1, 0, -0.475) | -0.875 to -0.075 |

The resulting outer bounds are **0.70 m wide × 0.30 m deep × 1.75 m tall**.
Ground is at local z=-0.875; the head's top is z=0.875. A ground-level world
placement puts this origin 0.875 m above the ground, while keeping the supplied
battlefield x/y coordinates.

## Confirmed stationary battle facings and area shapes

For the stationary 2v2, team A faces world +x and team B faces world -x throughout
the encounter. Facing does not change when a new target is selected. Because
local forward is +y, these are exact quarter-turns: local right maps to world -y
for team A and world +y for team B.

The author confirms a **3D sphere of radius 4 m** for the delayed Qard blast and
a **vertical cylinder of radius 7 m** for the downward heat beam. These attacks
damage everyone eligible in their area; the cuboid labels do not introduce
separate damage payments per body part. The geometry helpers test sphere/box
and vertical-column/box overlap. The column utility has no height limits; a
finite beam-height rule would need explicit bounds before that case is modeled.

[Placement diagram](design/hitboxes/standing_proposal.svg) ·
[Data](data/body_hitboxes.json) · [Diagram generator](design/hitboxes/build_preview.py)

## Confirmed projectile and collision rules

- Projectiles launch from the ability's starting hand position, superseding the
  earlier body-centre launch suggestion. 1E1 uses its right hand; 1E2 uses its
  left hand. The local pose is transformed using the fixed character facing.
- Aim perfectly at the selected enemy torso centre. An action already in
  progress retains that original point when its target dies; the projectile
  continues on the same trajectory rather than redirecting.
- Projectile shape is a sphere. The initial supported Qard and gun projectiles
  each have radius **0.02 m**, stored per ability because sizes may differ.
- Ignore the shooter's own cuboids. Collide with the first other living body on
  the path, including teammates. Dead bodies stop colliding.
- A Qard mark requires an actual collision. Reaching an empty former target
  location creates no mark or delayed blast. A projectile can continue beyond a
  dead recipient along its original path and hit another body.
- Area eligibility uses any cuboid overlap. A blast/beam affects every eligible
  character once at full strength, including friendly fire, without a separate
  damage payment for each intersected body part.

## Integrated implementation and scope

`combat_sim/hitboxes.py` supplies rational cuboid geometry, exact sphere/column
area overlap, explicit world placement and swept-sphere contact calculations.
The latter partitions squared distance into exact rational quadratics and
uses fixed-precision roots for contact parameters. Rounded sphere/box corners
are preserved rather than using an expanded-box approximation.

`combat_sim/body_collisions.py` integrates these rules with the same shared
state/event timeline. Fixed bodies are cached; projectile candidate contacts
are checked again at arrival so bodies that die in flight no longer obstruct.
Projectile travel time and distance falloff use the centre's actual travelled
path to first contact. The Qard marker is anchored at the physical body contact
point. Simultaneous contacts with different characters at indistinguishable
positions are rejected until a priority rule is supplied; contacts with several
parts of one character produce one hit.

Run [scenarios/stationary_2v2_hitboxes.json](scenarios/stationary_2v2_hitboxes.json):

```sh
python3 -B -m combat_sim run scenarios/stationary_2v2_hitboxes.json --summary-only
```

The body definition is a separate input (`--body-hitboxes` in the CLI). The
scenario supplies facing and ground datum; body dimensions stay in
`data/body_hitboxes.json`, and projectile geometry stays in the ability data.

**Ground and gravity are planned next.** The current ground z datum places
feet, but is not a collision plane. No gravity value, ballistic aim
compensation, terrain, obstacle or lifetime/despawn rule has been invented.
A missed projectile remains inspectable as pending without a fabricated ground
impact. Movement, arbitrary facing changes, aim dispersion and revival remain
outside the current scope. Beam area is a vertical column for these standing
bodies; finite height bounds would need an additional definition for other cases.

The earlier point-based 2v2 remains a frozen controlled comparison; its original
trace and assumptions are preserved, rather than being presented as the new
physical collision model.

## Verification

The full suite passes **461 tests**, including 25 cuboid/swept-sphere geometry
checks and 15 collision-integration tests. The body encounter is checked at 80
digits, with 137 ms observations and without periodic observations. Action
cadence is preserved and checked final states/death times agree within 1e-20.
Both previous complete encounter traces reproduce unchanged.

[Current report](results/stationary-2v2-hitboxes/REPORT.md) ·
[Body-collision timeline](results/stationary-2v2-hitboxes/timeline.html)


## Terrain extension, 2026-10-25

The earlier body-only stage above remains historical. The current terrain
scope adds author-confirmed finite ground, three fixed 1.8 m cubes and open
sides/top; see [TERRAIN.md](TERRAIN.md) for authoritative conversation
clarifications, dimensions and collision/area rules. Gravity remains
unimplemented. The complete earlier body-only trace is unchanged. The full
suite now passes 479 tests; terrain results are saved separately under
[stationary-2v2-terrain](results/stationary-2v2-terrain/REPORT.md).

## Approved crouch pose extension

The original standing body remains the reference and older frozen scopes stay
fixed. The author now approves a crouch transform: legs 0.8 → 0.4 m, upper
body down 0.4 m, feet anchored, total height 1.35 m, recentered body origin
0.675 m above support. Shared geometry/timing interpolates this over 150 ms
and checks clearance before reversing it. See [CROUCH_SPRINT.md](CROUCH_SPRINT.md).
