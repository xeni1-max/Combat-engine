# Confirmed curved projectile entry

Current physics schema 2 selects `contact_refinement = confirmed_entry_v2`.
The ordinary prison/ice-projectile interaction and source Aim/accuracy rules
are verified together in the [current evidence](results/aim-toggle-confirmed-entry/README.md).
This is a delegated numerical correction, not a new character mechanic.
The author rules for gravity, compensated faster arcs, directional deceleration
and travelled-distance falloff remain in [GRAVITY.md](GRAVITY.md).

## Failure and correction

The original ice projectile approached a prison's west face at x=8.9 m with
radius 0.02 m. A conservative expanded chord nominated an interval whose last
sample remained approximately 6.68e-15 m outside contact. The old solver raised
an unresolved-contact error even though an actual entry was available inside
the remaining contact-time budget. The original receipt and failed run remain
in results/aim-toggle-initial-contact-guard.

The kernel still rejects impossible intervals using bounded-acceleration chord
enclosures. At a candidate leaf it checks actual sphere/shape overlap at sampled
times. When neither endpoint nor midpoint confirms entry, schema 2 may check a
later point up to `leaf_left + contact_time_tolerance_s`, capped by the original
physical integration/query interval. Floating-point rounding moves that upper
point inward when necessary to keep the bracket width within the budget.
Only a point inside the actual shape's radius-expanded distance confirms a hit.
The conservative enclosing shape alone cannot confirm one.

The returned interval starts at the outside leaf sample and ends at the
confirmed point. It contains the numerical trajectory's entry; it does not
extrapolate into a future physical interval. Moving and resizing shapes use
their actual translated/deformed surface at that point. Other candidate
receivers retain their own brackets and existing ordering checks.

## Unchanged limits and compatibility

- Current contact-time tolerance is 1e-12 s; clearance tolerance is 1e-14 m.
  The common event grid is 1e-6 ms. Gravity, radius, trajectory step/tolerances
  and event rounding were not widened to accept this contact.
- An unresolved graze, a query ending before confirmation, or overlapping
  receiver brackets without a priority rule still raises `UnsupportedMechanicError`.
  The solver does not silently choose a miss, hit or arbitrary receiver.
- Physics schema 1 retains the previous behavior. Low-level helpers default to
  that behavior unless `confirm_near_entry=True` is explicitly supplied; current
  public physics schema 2 supplies it. Invalid refinement selectors reject.
- Body motion/pose, released ownership, death, shield/damage batches and actual
  flight-distance falloff keep their existing shared-engine rules.

Trajectories use binary64 adaptive integration. Contact intervals and numerical
refinement are diagnostics, not certified error bounds for the exact ODE.
An actual numerical inside point is stronger evidence than an expanded-chord
candidate, but it is not a universal convergence proof. General unresolved
grazing/receiver-priority behavior remains an explicit engine boundary.

## Evidence

The original face crossing has analytic time approximately
0.16111528104520415 s. Its confirmed bracket width is
9.999778782798785e-13 s. A translating/resizing face also brackets its analytic
crossing, with width 5.820899318109696e-13 s. Independent distance checks verify
the recorded upper points are inside the 2 cm sphere contact condition.
The frozen and truncated-query controls retain their ambiguity guard.

Seven permanent kernel methods cover confirmation, query bounds, resizing,
earlier receivers, unresolved grazing and simultaneous-priority guards. The
current 72-method accuracy/Aim/static/moving-contact subset passes, and all
393 runtime/data/test/scenario files match the source that passed the complete
2492-method suite. Eleven ordinary current-input captures pass complete
API/CLI/hash and combined 80-digit/17 ms/reversed-participant checks, including
the real prison/ice casts. [Reproduction](results/aim-toggle-confirmed-entry/README.md).
