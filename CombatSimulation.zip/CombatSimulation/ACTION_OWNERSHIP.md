# Controlled action ownership

**Actual 1E1 launcher, 2026-11-10:** [weapon modes](LAUNCHER.md) keep inventory
per actor while shared author definitions remain immutable. Ultimate swap and
ability 1 firing reserve the same weapon1 resource and their two hands;
independent lower-body actions remain legal. Selection freezes action rules;
release freezes projectile rules/payload through later swaps, copies and source
lives. Active-start swap cost and firing-end grenade cost/ammo/cooldown are paid
once at their own authoritative boundaries. Successful equip loads 10 and starts
65 s reuse; empty return uses the same paid swap without refilling/restarting it.
Ready Ultimate may replace empty stock directly. Source death cancels controlled
work while released grenades/clouds retain the old life; restoration retains
physical inventory. Applied-HP receipts use the same released/component
definition as damage resolution; this also corrects existing wall-slam kind
from generic contact to Blunt without changing HP or timing. The standalone
profile-only journal interface remains supported. Evidence is in PROGRESS.md.

**Existing leaps, 2026-11-09:** [1E1/3 and 3E5/3](LEAPS.md) use a locomotion
owner without hand occupancy. Their listed cost is paid at takeoff. 3E5 retains
lower-body control after jump Active, then atomically acquires the attack
requirement for its descending foot contact. This transfers paid requirements;
it adds no second reservation or invented kick fee. Cancellation ends the
unreleased kick while native flight and already owed landing effects remain.
Verification status is recorded in PROGRESS.md.

**1E3 portals,2026-11-09:** [the existing ability3](PORTALS.md) owns the neutral
left hand and own ability resource during preparation/300ms Active, then releases
an autonomous pair. Environmental use has per-life shared reuse work and no new
ability/effort owner. Atomic transport retains compatible independent controls;
actual active climb loses its old attachment. External imposed replacement
continues to use the separate cancellation contract below.

**1E3 duplication field, 2026-11-09:** [the actual Ultimate](PROJECTILE_DUPLICATION.md)
owns its neutral left hand and own ability resource, requiring upper-body/attack
function. Existing right-hand marking and ordinary walking can start independently
at the same clock. Common Recovery/Gathering precede300ms Active; source no-dyspnea
activation releases a persistent field at Active end. Cancellation before release
creates no field; source death after release preserves it. Each copied flight
retains the original attacker/action/life and independent entity ownership;
the field owner gains no new payment, attack action or outgoing damage credit.

**1E2 Ultimate, 2026-11-09:** [the impact device](IMPACT_AREAS.md) owns its
neutral right hand and ability resource, requiring upper-body/attack function.
Common hand Recovery, Gathering and Active retain those resources. Throw-end
payment/release/cooldown then free them. The released explosion and timed
Gathering instances survive source control loss/death; recipient death retires
its own modifier. [The preparation controller](TIMED_GATHERING.md) commits work
to each existing Gathering independently, including compatible parallel body
and weapon actions. It adds no resource exclusivity or new Active-only phase.

**1E2 fence, 2026-11-09:** [ability5](ELECTROCUTION_FENCE.md) uses the neutral
left hand, its own ability resource, and upper-body/attack function during
controlled work. It can overlap independent walking. Deployment at Active end
releases those resources; the five materials and contact episodes are
autonomous. Lower-body binding cannot cancel an unrelated upper-body owner.
Caster death after deployment leaves the field; required-function loss before
deployment cancels only unreleased work. Field dependencies are checked when
selected, preserving unrelated straight-flight and disabled-rate API worlds.

**Dodge correction, 2026-11-09:** [2E4 basic9](DODGING.md) owns the shared
posture/locomotion resource and requires upper/lower-body function. It retains
hands, permitting independent Block, thrust and enhancements. Stable pace
continues; incompatible body transitions wait. Declared self targeting permits
activation without an enemy. Pose contact and control loss freeze the reached
fraction; death retires the Dodge record as well as its action. Its recharge
stock is independent of Block and retains ordinary pauses/death/resume behavior.

**Grappling-gun extension, 2026-11-09:** [actual1E2 ability3](GRAPPLING_GUN.md)
retains hands/weapon during firing and hook flight, then atomically acquires
locomotion for the separately paid launch. A conflicting body owner or unpaid
capacity cannot create a partial launch. Hook flight adds no global lock;
compatible movement continues until launch. Distance-end observers release
the owner at the actual terrain-destruction/expiry clock. Released projectiles
and already incurred native contact obligations retain their own lifetimes.

[Shared bindings and 1E3 marking](BINDINGS.md) now apply life-bound upper/lower
function restrictions through this registry. Upper freeze interrupts actual
attacks/holding while legal movement and released effects continue. Whole-body
binding additionally denies controlled actions with no limb requirement.
Common binding Break owns one focus token per actor, with no limb reservation;
repeated inputs cannot multiply filling. Grapple contests retain their separate
per-link owners. Physical momentum/gravity are independent of action cancellation.

**Component/hand extension, 2026-11-01:** [1E5's actual alternating attacks](COMPONENT_MELEE.md)
pin a component before ownership acquisition and use that fixed hand throughout
every phase. The next-arm cursor may advance while the released action still
owns its previous hand. Named `hand:left`/`hand:right` restrictions now match
occupied resources alongside declared functions, so they also affect existing
actions using that hand. Other sources and opposite-hand actions remain
independent. No global ability lock or unlisted extra arm is introduced.

Implemented and verified **2026-10-28** in the shared moving-combat engine.

Current 2026-10-29 [phase effort](ABILITY_EFFORT.md) adds sustained firing
controls that link these owned actions without holding resources during weapon
Readying. Instability cancels the control's unfinished emission through this
registry; unrelated body actions, automatic readiness and released effects keep
their own lifetimes. Qard declares its right hand/weapon requirements and shares
the same ownership/payment rules. [Evidence](results/phase-effort/REPORT.md).
This replaces universal controlled-action occupancy for current inputs;
released projectiles, independent effects and physical flight keep separate
lifetimes. [ENGINE_STATUS.md](ENGINE_STATUS.md) records overall engine scope.

## Sources and delegated decisions

The author requires permitted independent abilities/effects to coexist and
delegates detailed engineering decisions. `Details.odt` p10 forbids attacks
while sprinting; p17–27 describes hand Recovery/Gathering. `Collision details.odt`
p4/p10 applies disorientation to unfinished Gathering, including another ability
already being prepared. `1E3.odt` p3/p5 distinguishes upper-body attack prevention
from lower-body movement prevention. Paragraph indices are zero-based.

Those sources do not specify every resource conflict. The requirements below,
capacity reservations, restriction expiry/cancellation policy and concurrency
ordering are **delegated, reversible implementation choices**, not additional
author confirmations. They preserve the existing abilities and payment anchors.

## Resources and functions

Current definitions live in
[combat_locomotion.json](data/movement/combat_locomotion.json), mode
`declared_requirements_v1`. A resource has one owner; a required function is an
eligibility condition and can serve several actions simultaneously.

| Action | Exclusive resources | Required functions |
|---|---|---|
| Walk/run transition, special stop | Locomotion | Lower body |
| Basic jump | Locomotion | Lower body |
| Crouch/stand | Locomotion | Lower and upper body |
| Sprint entry/exit | Locomotion and hands | Lower and upper body |
| Climb | Locomotion and hands | Lower and upper body |
| Existing 1E2 gun | Authored hands and its weapon | Upper body and attack |
| Existing 1E2 ability4 direct shot | Existing grip hands and its own ability resource | Upper body and attack |
| Reload | Authored hands and its weapon | Upper body |
| Existing 1E5/2E4 dash | Locomotion | Lower body |

`hands` expands to named hand resources from the ability's authored start pose;
body actions that occupy hands use the actor's hand set. Weapon resources carry
the ability identity. No jump/posture hand movement is invented. Jump and
posture can therefore overlap gunfire/reload when otherwise eligible. Climb
and sprint transitions retain hand ownership; steady sprint still prohibits
weapon actions. Most actions retain one requirement set. Actual
[1E5 grab/holding](GRAPPLE_DELIVERY.md) uses phase-specific transfers: the grab
keeps its occupied hand through its full Active, while contact starts a separate
owned hold; at grab end the hand/weapon transfer atomically. Paid receipts remain
paid. Registry prepare/commit validates the complete final owner set, rejects
foreign/stale/replayed plans, preserves unpaid costs and rechecks functions and
reservations before mutation. Required functions remain nonexclusive.
Future kit mappings must be declared and tested at their real boundaries.

**Direct projectile extension, 2026-11-03:** [1E2 ability4](1E2_ABILITY4_AUDIT.md)
uses the same phase/payment gate, with no unlisted ammunition owner. A selected
scripted aim_part is pinned on the action and retained by its released entity;
it is neither a hand lock nor a promise to hit that part. Native contact chooses
the [damage output](BODY_PART_DAMAGE.md). The actual 9 s cooldown starts after
successful firing-end payment; cancellation/rejection before that point starts
no cooldown or projectile. Existing gun magazine/reload ownership is unchanged.

[Body dashes](BODY_LAUNCHES.md) retain both hands and use the same phase-payment
gate. Their 150 ms control owner ends separately from ballistic flight. Actual
landing consumes a life-bound obligation even if external displacement or a
restriction cancelled launch control; death retires it. An ordinary dash cannot
be admitted again in midair. Voluntary launch changes one independent input;
the grapple coordinator projects it once rather than treating it as an imposed
group knock. The source gives no hand gesture, so none is fabricated.

[3E5 heavy punch](KNOCK_DELIVERY.md) owns its right hand/weapon and requires
upper-body/attack function. Its released knock keeps no controlled action owner.
Finite per-impulse lower-body restrictions prevent walking/stopping/dash from
erasing imposed motion while leaving upper-body actions independent. Each expiry
releases only its own restriction and transformed force component. Stopping's
no-op admission now checks imposed velocity as well as nominal ground speed.

[Conditional melee](CONDITIONAL_MELEE.md) pins a complete branch before policy
admission/acquisition. Its own named hand, cost, timing and effects remain tied
to the action even as the normal cursor advances. Counter a retains its right
hand while b/c's cursor may point left. The private after-Active cooldown debt
is committed only after payment and keeps no hand/weapon/control owner after
cancellation; it cannot replay an old-life attack.

Acquisition checks all occupied resources and blocked functions before any
registry mutation. Completion/cancellation releases only that action's resources.
No-op intents bypass an occupied resource only if the relevant property will
remain stable: stand during crouch Gathering, sprint during sprint exit and
stop during climb must wait rather than disappear or modify the active path.

## Action identity, phases and payment

[ActionRegistry](combat_sim/action_ownership.py) owns immutable requirements,
capacity reservations and payment receipts per action ID. The coordinator
resolves each phase by actor, action ID and revision, rechecks function/sprint
eligibility and explicitly binds that action while its existing rule executes.
Body events/contact handling bind the locomotion owner; they cannot accidentally
cancel an independent weapon. A character cannot acquire or bind another
character's action. Stale completion and climb-corner events are invalidated.

`Combatant.current` remains a phase compatibility adapter: implicit access with
multiple actions raises an error. Releasing an already-removed selected action
does not release another live action. State records expose authoritative
`owned_actions` with requirements, reserved capacity and paid phases;
`current_action` is populated only when exactly one action is live. Hand and
locomotion records remain value snapshots.

An unpaid action reserves dyspnea **capacity**, without paying early. For
`Da=(Db+D/100)^2`, the cost while `D<=100` is bounded by `(Db+1)^2`. Acquisition
reserves the smaller of this bound and remaining unreserved capacity, after
checking that the action is currently affordable. Other controlled actions
cannot spend reserved capacity. This conservative admission rule can defer an
otherwise momentarily affordable overlap near capacity; it prevents a later
controlled debit from stealing a promised firing/reload payment.

Actual costs are recalculated, checked and paid at their existing authoritative
anchors: gun at firing end, reload/body actions at Active start. A receipt
prevents duplicate payment; wrong cost/phase definitions fail explicitly.
Release before payment frees the reservation without a debit. Paid costs and
statuses are not refunded on cancellation. Continuous sprint effort is not a
controlled debit and can invalidate an unpaid body phase; that phase then uses
its existing defer/cancel/exhaustion rule without making a failed payment.

**Payment-boundary correction, 2026-11-01 (delegated):** continuous filling can
also invalidate an independently prepared weapon/reload action. In owned mode,
the shared payment gate now cancels only that unpaid action and logs a rejected
payment instead of raising an unsupported-mechanic error. No receipt/debit,
ammo change, new release, item/charge consumption or release-anchored cooldown
occurs. No already-applied status, paid cost, released projectile or independent
effect is retracted. Gun/Qard still check and pay at firing end; their physical
release follows that successful gate. Reload/grab/melee remain at Active start.
Rejected starts never log a successful Active or schedule its completion.
Existing body-specific defer/special-stop rules remain separate.

This applies the primary `Dyspnea details.odt` p23 rule that an unaffordable
action cannot happen, while retaining author-confirmed payment anchors. Holding
or fixed filling is not capped early to protect a pending reservation. Its own
actual gains/full-bar consequences remain authoritative, and later ordinary
recovery can admit another attempt. [Evidence](results/payment-boundaries/README.md).

[Common grapple Break](GRAPPLE_BREAK.md) owns a private token per contest,
without occupying limbs, weapons or locomotion. The controller's fixed filling
belongs to its existing hold; the defender's to its Break intent. Both retain
current lives and actual gains. Ending a hold releases these owners/channels;
positive penalties are separate once-only life-bound effects after due phases,
hits and contacts. They cannot retract a due Active start or penalize a revived
life that did not participate.

Incoming disorientation is added once to character state and extends each
unfinished Gathering separately. Self disorientation from one owned action
also extends another unfinished Gathering, excluding the causing action and
Gatherings whose Active boundary is already due. Already Active actions never
acquire a new Gathering phase. Resource recovery checks all live action phases.

## Independent readiness correction, 2026-11-03

The November review's N1 exposed an inconsistent wakeup rule: only Block and
dash acquisition immediately reconsidered other legal actions. A right-hand
thrust could therefore leave a free-hand Block idle until an unrelated input.
This was a scheduling defect, not an additional resource conflict.

After **every successful owned acquisition**, request a same-clock decision
through the existing event queue. Due phases retain their earlier priority;
selection retains the configured ability order, requirements, cooldowns,
capacity reservations and payment anchors. Each successful acquisition owns
new nonempty disjoint resources. A decision with no available option returns
without scheduling another retry, so this does not introduce a zero-time
polling loop. Four independent existing actions can start at one clock; actions
sharing a hand still cannot. An already-stationary stop cannot change combat
readiness or damage.

Priority selects acquisition order; it does not wait for a higher-priority
independent enhancement to finish. For example, 2E4's 200/400 ms enhancements
can prepare alongside a thrust released at 230 ms. Only the completed 200 ms
grant applies to that release. A later grant cannot rewrite a released snapshot.
Tests of a fully prepared Ultimate explicitly hold the attack hand until the
grant, using a labelled engineering restriction rather than implicit serial
policy. Current-input regressions accompany the preserved historical fixtures.
No ability, formula, numerical tolerance or payment rule changes.

[Review](PRINCIPAL_ENGINEERING_REVIEW_2026-11-03.md) ·
[Correction evidence](results/principal-review-fixes-2026-11-03/README.md).

## Selective restrictions and cancellation

The shared API `apply_action_restriction(target, source=..., functions=...,
until_ms=...)` applies an existing body-function restriction until an absolute
time. Distinct sources stack independently; refreshing one source advances its
generation so its older expiry cannot release the replacement. Expiry is
half-open: the function is available at `until_ms`, including when a phase at
that time is processed before the expiry event.

Only actions requiring a blocked function are cancelled. Upper-body restriction
allows ordinary lower-body movement/jump; lower-body restriction permits
gunfire/reload. Lower-body restriction ends voluntary ground drive and clears
its stored landing drive, while existing airborne velocity/gravity continue.
Climb interruption and partial-posture freezing reuse their physical responses.
No new collision or stopping penalty is invented by a restriction. Source expiry
wakes waiting policy decisions. Death cancels every controlled action, retaining
already released shots and effects. A deduplicated cancellation receipt covers
restriction, contact, exhaustion and death paths.

Scenario `initial_restrictions` represents **pre-applied conditions**, with
`duration_ms` equal to remaining lifetime from scenario start. These scenes and
runtime API tests validate the requirements of the existing 1E3 freezes;
they do not implement its projectile, marks, area delivery or ability activation.
Typed heat/bleeding instances are now integrated; actual restriction-producing
ability delivery remains A3/kit work, rather than a generic invented ability.

## Verification and boundaries

Ten registry tests and 27 shared interaction tests join the **943-test passing
suite at the A1 checkpoint**. The subsequent projectile increment brings the
suite to 980 tests; the world-collider increment brings it to 1022. Ownership checks cover actual overlap, mid-crouch launch origins, empty-magazine
reload, self/incoming Gathering extension, near-capacity admission, source
refresh/expiry, selective cancellation, physical flight/contact, death,
precision/observation/input-order controls and the public CLI prefix.
[Tests](tests/test_owned_actions_combat.py) ·
[Pure registry tests](tests/test_action_ownership.py) ·
[Four exact replay demonstrations](results/action-ownership/REPORT.md).

Frozen inputs without `action_ownership` retain explicit historical exclusive
scheduling. Prior feature tests use their own
[frozen fixture](tests/fixtures/combat_locomotion_exclusive_v2.json), rather than
depending on a rebuildable results folder. Historical artifacts are unchanged.
Current world physics remains immutable `integrated_v2` in both scheduling modes.

Moving combat now covers the existing 1E2 gun, 1E1 heat/Qard and 2E4 thrust;
body profiles cover 1E1/1E2/2E4. Beam summoning occupies its right hand/ability weapon and requires
upper-body/attack functions. Lower-body movement may overlap. An Active summon
can be cancelled while its independently deployed volume persists; it retains
no hand lock after controlled completion. See [SPATIAL_EFFECTS.md](SPATIAL_EFFECTS.md).
This is the current-action A1 foundation, not full six-kit integration. The
subsequent [A2 projectile increment](PROJECTILE_ENTITIES.md) adds independent
flight identity, contact policies and copy APIs. [Fixed world colliders](WORLD_COLLIDERS.md)
now provide HP/lifetime and contact invalidation. Typed heat/bleeding and moving
volumes are verified. The [1E2 pause area](COOLDOWN_PAUSES.md) now occupies its
left hand/ability resource during marking while eligible body movement may
continue; deployment releases those resources. [Applied HP history](DAMAGE_LEDGER.md)
retains independent effect ownership. [Revival](REVIVAL.md) uses a death
controller outside living locks; [passive healing](HEALING.md) uses point
entitlements and continuous HP flow without acquiring a hand/body action.
Other ability delivery remains unfinished.

[2E4 thrust/replacement grabbing](MELEE_VENOM.md) uses declared right-hand and
weapon resources. Thrust also requires attack function; grabbing requires only
upper-body function and can overlap constant sprint. Its autonomous item delay
owns no controlled resource. Cancelling a grab leaves the available item for a
new eligible action; it does not erase the summon or any attached wound.

[Block](BLOCKING.md) uses its neutral left hand and `defense:basic_block`,
requires upper-body function and does not require attack/lower-body function.
The existing right-hand thrust can execute independently. Held control schedules
two momentary releases; selective cancellation removes pending control while
released shields retain their lifetimes. Source death freezes their geometry and
ends controlled release; no old control or status bonus transfers to a new life.

[Automatic Block reactions](COMBAT_REACTIONS.md) subscribe to committed defense
signals outside controlled locks. They require a living current source life,
but acquire no hand/attack/body requirement absent from the authored ability.
Released direct packets have their own immutable source/action identity. A
cancelled guard can therefore retain its released shield and automatic trait;
death cancels an unissued reaction without cancelling a released attack.
