# 3E5 charge, front grab and wall slam

2026-11-03. Integrated in the shared engine; all 2425 full-suite tests pass.
[Evidence/reproduction](results/charge-grapple/README.md) ·
[Current handoff](PROGRESS.md). No new character ability is introduced.

## Source and selected phases

`3E5.odt` p17/p169–p186 specifies a two-second forward charge with +50%
movement speed, first-target grabbing, holding in front for eight seconds,
wall destruction while the bonus is present, 700 blunt victim damage on a
wall slam, bonus reset on each slam and 65 s cooldown. Gathering is 100 ms,
grab Active 180 ms, target O/U 400, self O/U 150 and listed dyspnea 3. The drag
is constriction/tear; its DPS and detailed holding effort are unspecified.

The following details are delegated implementation choices, not extra author
confirmations. Ordinary Recovery precedes Gathering. Pay Db3 and start the
65 s cooldown at charge Active start, including misses. Enter forward running
at the existing base 8 m/s, with the +50% ground motor bonus. The search window
is two seconds; successful/intercepted gripping gets its full 180 ms Active
from contact. Preserve an eight-second hold from successful contact. A miss
ends search at two seconds. Ordinary running continues after motor ownership
ends; use the existing Stop action to brake rather than receiving a free stop.
The action records its actual continuous Active duration separately from the
authored 180 ms grab, with explicit search/grab subphase clocks.

The parent owns locomotion, the left hand and its own weapon during search/
grab. A separate owned hold begins at contact, relying on the parent's hand
during the full grab tail. Hand/weapon ownership then transfers atomically to
the hold. Right-hand abilities remain available under their real requirements.
Normal Break, fatigue, function restrictions, death and life restoration use
the existing shared holding coordinator. Entry requires current support;
actual subsequent air motion and airborne recipients use shared gravity and
linked paths. No victim position is copied or teleported.

Use **600 base constriction/tear DPS and Dd2** while holding. Those reversible
values fill the source omissions, keeping this longer hold distinct from
1E5's 900 DPS/3 s drag. Existing live intrinsic sustained output loss U/4,
shield allocation, armor formula, clipped HP and joint effort still apply.
Initial grab is damage-free contact utility, retaining target/self statuses.
Every real grip-volume interception applies the listed self effects once;
wall slams do not repeat the initial grab statuses or point cost.

## Shared owned contact volume and motor

The delegated grab proxy is a moving cuboid anchored to the actual torso:
local centre offset `(0, 0.65, 0)` and local size `(0.5, 1, 0.5)` metres, with
local x right, y forward and z up. In a standing +x body it spans 0.15–1.15 m
forward of the torso centre. It follows the torso's actual pose motion and
the common saved reference path. [Native angular attachments](TURNING_CONTACTS.md)
now follow the live body heading; the stored facing remains creation metadata.
The charge motor still uses its existing Active-start world direction.
Active linked turning remains guarded until its response integration is done.
Glancing captures preserve the actual lateral offset; a successful
front hold requires the target reference in the body's forward half-space.

`OwnedContacts` solves quadratic translating/resizing body contacts on the
same interval as movement/projectiles. First body or solid interception wins;
same-time geometry uses stable distance/object/part ordering. Revalidate after
due phases. Released Block remains solid interception, while personal shield
stock is a damage layer. Dead bodies do not become targets. This is controlled
work bound to an actual action and life, not a projectile that survives death.
Finite ground retains exactly zero thickness; the geometry solver's explicit
static-plane option permits that surface without relaxing ordinary size guards.

`GroundSpeedBonuses` multiplies only nominal ordinary ground drive, before
the existing U speed penalty and grapple averaging. It does not multiply
launched/imposed velocity or the prescribed stopping slide. Native collision
and velocity-to-drive conversions invert the same multiplier, preventing a
bonus from being applied twice. Each bonus has its own source life and clock.

The existing incoming-burst upward counter treats an actively controlled
forward charge as a dash-family cause, recorded distinctly as `charge`.
This is a delegated classification choice; ordinary running or the remaining
speed bonus after charge control ends does not acquire that classification.

## Fracture and committed wall damage

Wall identity is the immutable `wall` tag, not a name. Qualifying destruction
requires this cast's own live +50% bonus; an unrelated speed buff is insufficient.
Permanent ground is never removed. During search, a tagged breakable wall can
intercept the proxy and fracture; search then continues through the opening.
Other solids intercept the grab attempt. No victim slam is invented before a
victim is actually held.
Controlled hand contacts stage fracture until the complete shared character/
ordinary-object damage batch finishes. Every same-batch nonpiercing shot still
meets the pre-batch wall. A living matching control can then resume search;
an already committed wall touch is not erased by same-batch source cancellation.

While holding, a slam requires the victim itself to contact the wall. Touches
from unrelated members of a larger graph do not damage this victim. Deduplicate
by cast, wall and committed contact wave, across all material/body parts.
Controller-only wall contacts can fracture material during the bonus but do
not count as victim slams.

**Material decision:** a qualifying wall fractures at contact before an
infinite-mass solid response. Apply its remaining HP through the typed object
damage path, separately from the victim's 700 base blunt damage. No position,
lost velocity or already-paid action is restored. The now-absent material
cannot also impose an intact-wall stop/status impulse. This preserves breaking
through several walls. Nonqualifying contacts keep native velocity loss and
statuses. The distinction and pre-fracture HP/identity are recorded explicitly.

Pin the owned source action/life, output from pre-contact U, attack modifiers,
actual held victim/life and wall identity before native response can cancel
control. A leased [committed contact signal](CONTACT_EVENTS.md) emits the damage
through the usual causally later shared impact batch. It applies ordinary
personal shield/armor/HP and recovery-credit rules; no terrain HP becomes actor
damage or healing credit. A committed impact remains resolved if the collision
then exhausts the controller; future controlled work ends normally.

A victim slam refreshes the bonus to two seconds from that contact while the
hold remains controlled, including restarting an expired bonus. Expiry is
half-open and due phases precede contacts: a wall reached exactly at bonus
expiry gets native response, then a surviving hold can gain the renewed bonus.
A renewed bonus alone does not restore movement lost in that collision.

## Shared knock timing correction

An actual heavy punch exposed a shared ordering bug: incoming statuses could
exhaust a grapple before the later knock event read group membership. Current
`knock_group_timing: {"mode":"at_impact_v1"}` pins the pre-hit group and defenses.
After all same-time character HP/status calculations, apply committed forces
before fatigue teardown, material damage and new grab attachments. Multiple
forces add to current physical velocity. Living matching participants receive
the common impulse even when that very attack ends the hold; retired lives
never receive it. Resistance uses their pre-hit summed maximum HP/current armor.

Frozen inputs without that mode retain their earlier force-phase policy. This
is an explicit correction to implement the author's grapple/knock rule, not a
3E5 exception. Tests also use the existing 1E5 hold and opposed heavy punches.

[Shared grapple rules](GRAPPLE.md) · [Holding](GRAPPLE_DELIVERY.md) ·
[Knock delivery](KNOCK_DELIVERY.md) · [Walls](DESTRUCTIBLE_WALLS.md)
