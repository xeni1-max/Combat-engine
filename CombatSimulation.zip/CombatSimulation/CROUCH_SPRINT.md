# Crouching and sprinting — shared geometry/timing

Current profile geometry uses [the authored body proportions](CHARACTER_GEOMETRY.md).
The dimensions below describe the approved reference body. Its crouch ratio
extends proportionally to1E5 legs1.04→0.52 m and3E5 legs0.84→0.42 m, a delegated
choice. Their respective nominal crouched heights are1.755 and1.4175 m; native
balance deformation remains independent. Hand offsets retain authored metres.

Current scope: sprint and crouch/stand are integrated with combat; see the final
sections and [posture results](results/posture-combat/REPORT.md). The earlier
geometry/timing scope and its saved results below remain historical.

Author approvals and primary character definitions, 2026-10-25. Configuration is
in [data/movement/walk_run.json](data/movement/walk_run.json), separate from
execution and standing body reference data.

## Crouch

The author approved the proposed geometry and confirmed reverse standing Active:

- Feet remain on the same support surface.
- Legs shorten from 0.8 m to **0.4 m**, from their tops.
- Torso, head and arms retain their dimensions and move **0.4 m downward**.
- Geometry changes linearly over **150 ms crouch Active**. Total height changes
  from **1.75 to 1.35 m**. Body origin is recalculated from combined bounds:
  0.875 → **0.675 m above the feet**.
- Standing reverses the pose over **150 ms**, after checking room for expansion.
  A blocked expansion is rejected with the character remaining crouched.
  Exact contact at the completed standing height is permitted without penetration.
- Hand positions and the authored projectile-hand-origin transform follow the
  lowered upper body. The recentered body frame is accounted for; they do not
  lower by only the body's 0.2 m centre displacement.

Posture is independent of ground pace. No crouched speed modifier is documented,
so the geometry model preserves the selected walking/running/sprint speed.
No automatic crouched-running prohibition or speed penalty is introduced.
Walking while crouching and sprinting while crouched are tested. Jumping retains
its current posture and the approved base-running-speed jump rule.

The hand reference is evaluated analytically in this scope, avoiding accumulated
observation-step offsets. Ability attacks and their Recovery remain outside
this controlled test; the pose-local projectile-origin conversion is supplied
for subsequent integration. No animation or anatomical knee/elbow model is used.

## Sprint

Both 1E1 and 1E2 basic ability 5 specify:

- Base running speed 6.4 m/s plus **4.8 m/s**, giving **11.2 m/s** sprint speed.
- Run ↔ sprint uses **200 ms Active**, with linear speed change as previously
  confirmed for movement transitions. Each transition covers **1.76 m**.
- Sprinting prevents attacks. The source restriction is recorded; attacks are
  excluded throughout the current geometry test, so mixed attack enforcement
  is not claimed by this demonstration.
- The source lists self disorientation/instability 100/100 and dyspnea value
  0.5 per transition, plus continuous base dyspnea Dd=2. Those effects are recorded
  but not applied in the author-approved geometry/timing scope.

Direct stand/walk → sprint, sprint → walk, and jumping/climbing directly from
sprint need defined handoff/timing rules; these requests are explicitly rejected
in the bounded test. Return to running before the latter actions. A special
stop from sprint is supported using actual 11.2 m/s and the existing slide rule.

## Shared-engine demonstration

```sh
python3 -B -m combat_sim run scenarios/scripted_crouch_sprint_geometry.json --summary-only
```

Both characters walk, run, sprint, return to running, special-stop, crouch and
stand. They then walk, crouch, jump while crouched, stand and stop. Each finishes
at x≈**33.0934558179 m**, standing, upright and grounded. Each completes two
crouches, two stand-ups, two run/sprint transitions, one jump and two special stops.

[Inspect timeline](results/crouch-sprint-shared/timeline.html) ·
[Body diagram](design/postures/standing_crouch.svg) ·
[Report and frozen replay](results/crouch-sprint-shared/REPORT.md).

## Verification and boundaries

The full suite passes **665 tests**. New checks cover anchored feet, head/torso/
arm translation, body-centre and hand origins, intermediate poses, standing
clearance and exact fit, sprint speed/distance, crouched jumping, special stop
from sprint, independent posture/pace, numerical controls and older complete
climb traces unchanged.

Continuous contact geometry now supports linear cuboid size changes together
with quadratic translation; it does not approximate changing legs as one rigid
box or rely on observation samples. A moving obstruction during an in-progress
pose transition remains explicitly unsupported; no partial-pose collision
response is invented. Static occupancy is checked before stand-up expansion.
Raised ledge departure and general airborne response remain pending as before.
Actual statuses, dyspnea and attacks remain excluded. Frozen older results and
standing hitbox reference data remain unchanged.

## Sprint integrated with combat, 2026-10-27

Sprint now executes with the existing gun, gravity, contacts, statuses, resources
and death in both grounded combat scopes. Crouch remains in the earlier geometry
scope. The optional `sprint` section in `combat_locomotion.json` enables the new
rules; historical saved definitions without it retain their exact behavior.

Primary source audit: 1E1 paragraphs 206–216 and 1E2 paragraphs 222–232 specify
+4.8 m/s, run↔sprint Active 200 ms, self O/U 100/100, transition dyspnea 0.5 and
continuous gain 2 per second. `Details.odt` p10 forbids attacks while sprinting;
p11 specifies running's 20% modifiers. `Dyspnea details.odt` p15–25 defines recovery
blockers, capacity and the 200-disorientation cap trigger; its embedded formulas
are `Da=(Db+D/100)^2` and `Dc=(Dd+D/100)^2`. Paragraph indices are zero-based.

The following timing and interaction choices are made under the author's
mechanics delegation, not presented as additional author clarifications:

- Treat transition 0.5 as Db and continuous 2 as Dd. Pay/check transition capacity
  and apply self statuses at Active start. Sprint inherits running's self-status
  modifier; run↔sprint receives 120 O / 120 U. Nominal speed changes linearly over 200 ms;
  the existing continuous U/200 penalty applies to actual travel.
- Resolve hand Recovery before each sprint transition, with running's 1.2 timing
  factor and one final ceiling. Ordinary movement continues during Recovery.
  Authored sprint start hands are left (-.20,.15,-.10), right (.20,.15,-.10).
  1E1 explicitly uses those end poses too; use that same end pose for 1E2, whose
  source lists only the start. Recovery completion places both hands there.
  No additional Gathering is inserted. Capacity is checked again before payment.
- Continuous sprint effort begins at entry Active start, continues through
  steady sprint and exit Recovery/Active, and ends at exit completion, special
  stop Active start, full collision stop or death. Glancing travel retains effort
  while sprinting. Instability can reduce actual speed to zero without making
  an attempted sprint free. Sprint blocks dyspnea recovery.
- With Dd=2 and zero recovery, `dD/dt=(2+D/100)^2`, in seconds. Evaluate this
  analytically from the last entry/payment anchor. The next exact resource
  boundary is `100000*(1/(2+D0/100)-1/3)` ms after that anchor. Observation samples
  never determine the accumulation or exhaustion time.
- Sprint blocks new weapon actions, including reloads. The attack restriction
  is authored; extending it to reload is delegated to keep the hand/action and
  capacity model consistent. Released projectiles remain independent. The
  conflicting controlled action finishes before a sprint intent begins.
- Reaching 100 emits the unmitigated cap trigger once, after interval status
  decay: 200 O multiplied by the running self factor, normally 240 O. If still
  sprinting, cancel the current sprint action and start the existing free
  special stop using actual speed. Its own stopping penalties still apply.
  A transition that has already finished returning to running needs no forced
  stop. Death at the boundary cancels the pending exhaustion response.
- If a paid exit is unaffordable, replace that exit intent with the existing
  free special stop. Log the fallback; do not wait for recovery while sprint
  prevents it. This finishes standing without automatically retrying the run/walk
  destination. Later explicit commands remain eligible.
- Stand/walk→sprint and sprint→walk stage the existing transitions. They do not
  invent direct timing shortcuts. Movement intents remain FIFO. The frozen
  exclusive input shares one controlled-action slot with weapons; current
  ownership explicitly declares sprint transition hand/body requirements.
- A full collision wakes a previously sprint-blocked weapon policy. During a
  special stop, a glancing contact removes normal velocity and linearly decays
  the remaining tangential slide to zero at the original Active end. The stop
  action remains active even if all travel is removed. Do not restart sprint,
  reapply stopping penalties or subtract instability again from this slide.

The collision choice also avoids charging effort from a stale sprint anchor
when contact interrupts stopping. A separate numerical fix clears a decaying
status remainder only when adding it cannot advance the Decimal clock; this
prevents a repeated zero-time expiry boundary without changing measurable status
lifetimes. Previous complete moving/gravity replay traces remain exact.

`dyspnea_paid` continues to report discrete action payments. Continuous sprint
gain is reported separately as `sprint_dyspnea_gained`, with interval events and
summary totals. Transition and exhaustion counts are also exposed.

[Saved combat scenarios and replay](results/sprint-combat/REPORT.md) demonstrate
incoming gunfire during sprint, hand Recovery, paid exits, exhaustion, an
unaffordable exit and a glancing stop. Sixteen focused tests cover these rules,
independent formula checks, death, full collision, no observations, 80-digit
combat states and unchanged historical scope selection. Basic jump now also
shares combat and stages the paid sprint-to-run exit before takeoff; see
[JUMPING.md](JUMPING.md). Crouch, climb, turning and prone/Get Up geometry still
need integration into moving combat.

## Crouch/stand integrated with combat, 2026-10-27

The optional `posture` section of `combat_locomotion.json` enables these actions
in the existing coordinator. `posture_combat.py` handles effects and action
eligibility; approved cuboids and part velocities remain in `postures.py` and
the reusable posture geometry helpers. Historical definitions without the
section retain their exact output and reject posture commands in combat.

Primary source audit: `1E1.odt` p172–179 and `1E2.odt` p188–195 list crouch
Active 150 ms, self disorientation/instability 80/80 and dyspnea value 1. Neither
lists crouch hand poses, separate standing effects or payment/status anchors.
The author separately approved reverse stand Active, geometry and clearance as
recorded above. Paragraph indices are zero-based.

Implemented under the author's delegation, rather than additional author rules:

- Treat 1 as Db in `(Db+D/100)^2`. Standing uses the same cost and 80/80 self
  statuses as crouching: reversing the same displacement has comparable effort.
  Check capacity at selection and Active start;
  pay and apply unmitigated self effects at Active start. Running/sprint scales
  self statuses by 1.2. A rejected expansion pays nothing; interruption after
  payment keeps the paid cost and existing effects.
- Base Gathering is zero, with current disorientation added using the existing
  rule. Incoming O can extend it. No authored hand movement means no invented
  hand Recovery. In the frozen exclusive input, pose Active occupies the same
  slot as weapons; current ownership permits eligible gun/reload during pose
  Gathering/Active because posture owns no hands. Steady pace, released
  projectiles and independent flight/effects persist. Posture adds no weapon
  restriction to stable crouching. Posture commands wait for actual landing; an incidental
  lift during Gathering defers the action again before payment.
- Both directions use the approved linear 150 ms full transition. A partially
  interrupted pose can resume toward either endpoint at the same pose rate,
  using a duration proportional to the remaining fraction and a full new action
  cost. Posture and pace remain independent; no crouched speed penalty or
  sprint prohibition is invented. Active blocks dyspnea recovery normally.
- Retain hands in the canonical standing reference frame for Recovery and hand
  state. World hand positions and projectile origins apply the approved pose
  transform at use, lowering by the full 0.4 m when crouched. Keeping canonical
  poses avoids cumulative offsets and preserves weapon end poses. Body origin
  remains the actual centre of combined bounds; locomotion/flight retain a
  separate upright reference so recentering cannot drift feet or landing height.
- Check expansion against current solid occupancy before selection and before
  payment; exact endpoint contact is allowed. Future motion is resolved by live
  continuous queries, rather than speculative extrapolation across unknown
  phase/status boundaries. Queries include part translation and linear size
  change for both bodies; straight and gravity projectile queries do likewise.
- A live solid contact freezes an in-progress pose at its reached fraction and
  cancels its completion, preserving nonpenetration. The existing translational
  collision response and resisted statuses still run once. Pose deformation
  alone does not count as whole-body collision speed and adds no new impact
  penalty. New legal posture commands can leave the partial pose. Endpoint
  roundoff within the existing 1e-24 ms contact tolerance uses zero completed
  pose velocity, so an exact ceiling fit does not become an earlier collision.
- Death freezes the last pose and cancels its completion and flight through the
  existing death path. Released shots persist. A crouched jump retains posture
  and uses the same foot-plane landing and landing effects as an upright jump.
- Posture payment during sprint reanchors continuous effort. Natural exhaustion
  freezes any active pose before the free stop. Payment reaching exactly 100
  delegates to the same single sprint cap event, avoiding a duplicate trigger
  or zero-time resource loop. No-change commands pay nothing.

**874 tests pass**, including 25 posture integration checks and unchanged older
geometry tests. Saved demonstrations, numerical controls and exact replay are in
[results/posture-combat](results/posture-combat/REPORT.md). The posture definition
covers both 1E1/1E2 source values; the verified moving encounters use the existing
1E2 gun. Moving 1E1 area attacks and the other kits remain unintegrated. Using
the current controlled-action slot here does not establish universal exclusivity
for other abilities; independently released effects still coexist, and later
kit integration must honor documented concurrent actions.

Current inputs now use [declared ownership](ACTION_OWNERSHIP.md), superseding
the temporary slot described by the historical posture results. Posture requires
both body functions and locomotion; sprint entry/exit additionally occupy hands,
and steady sprint still prohibits gun/reload. A weapon can release from the
actual mid-crouch hand position while both actions remain live. Stand queued
during crouch Gathering waits for that change; sprint queued during an exit
also waits rather than being discarded as a no-op. Selective cancellation,
continuous-cap interactions and these mixed queues are covered in the
[943-test ownership checkpoint](results/action-ownership/REPORT.md).
