# 2E4 basic9 Dodge

Verified 2026-11-09: 2618 complete tests pass, including 28 new Dodge methods.
Eighteen complete API/CLI/hash/numerical cases and four labelled shared API
probes pass and reproduce immutably. [Evidence](results/2e4-dodge/README.md).
The full six-kit engine remains incomplete. Author rules are
`2E4.odt` p34 (Dodge, four charges, 4500 ms per charge), p193–197 (150 ms
Active, Db 3.5), and `Details.odt` p14 (quick upper-body movement sideways or
downward, sometimes accompanied by a short sideways dash). The previous
basic9 Block import was incorrect. Basic8 remains the authored Block.

The following choices are delegated implementation decisions:

- 2E4 uses the downward variant permitted by the shared definition. Its
  existing proportional crouch geometry dips from the starting fraction to
  full crouch over 75 ms, then returns over 75 ms. Feet/reference translation
  and authored hand offsets retain their existing meanings. This selected
  variant adds no lateral step, lateral lean, damage immunity or Block layer.
- Hits use the actual moving six cuboids, hands and carried defenses. Ducking
  can avoid a high shot while remaining vulnerable to lower shots and areas.
  Starting fully crouched, prone, airborne or climbing does not start this
  downward variant. A partial starting crouch is retained after completion.
- No Gathering or hand repositioning is authored: select zero base Gathering
  and retain hands. Ordinary incoming disorientation still delays Gathering.
  Pay Db 3.5 once and spend one charge at Active start; interrupted paid work
  retains its cost and recharge. No extra unlisted self-status is added.
- Stock is independent of basic8 Block. Reuse serial rechargeable work clocks,
  including pauses, death/resume and fixed filling capacity. Full stock banks
  no time. The activation is intrinsic momentary body effort, not a sustained
  attack or released autonomous defense.
- Own the shared posture/locomotion resource and require both upper/lower-body
  function, as the existing crouch does. Hands remain available for independent
  Block, attacks and enhancements where their own requirements permit. Stable
  walking/running continues; incompatible body transitions wait.
- Contact or loss of required control freezes the actual crouch fraction and
  cancels the remaining dodge. Return motion has normal native clearance and
  contact handling. Later ordinary crouch/stand input can change the retained
  pose. Death cancels control and dead bodies stop colliding under existing rules.
- The ability explicitly targets self and can activate without an enemy. Its
  policy remains scripted priority-when-ready; this adds no predictive NPC AI.

The general definition's lateral alternatives remain options for later data
profiles, not additional abilities granted to 2E4 by this import. Frozen old
profiles retain their historical basic9 Block; current root data uses Dodge.
