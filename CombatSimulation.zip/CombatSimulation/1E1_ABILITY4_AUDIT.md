# 1E1 ability 4: heat audit and controlled implementation

**Current support, 2026-10-28:** the shared moving engine now casts this existing
beam with independent volumes, moving entry/exit/re-entry, typed thermal tracks,
current defenses, shield depletion and changing/damageable cover. See
[SPATIAL_EFFECTS.md](SPATIAL_EFFECTS.md) for current source references and delegated
rules, and [verified evidence](results/spatial-heat/REPORT.md). Heat overlapping
shield regeneration is still guarded. The audit below records earlier controlled
runner checkpoints; its restricted scope and paragraph numbers are historical.

Root ODT documents take priority over the optional `reference_material_non_authoritative/` directory. Source documents are preserved unchanged. The new 1E1 revision adds only “Beam activated right after gathering.” This agrees with the author’s Active-start clarification; its updated hash/text are preserved with this stage. Paragraph numbers below refer to the text snapshots in the saved results package.

| Rule | Source | Status |
|---|---|---|
| Beam lifetime 3 s; cooldown 9 s | `1E1.odt`, ability overview p9 | Confirmed; lifetime executed, cooldown eligibility not executed |
| Gathering 180 ms, Active 300 ms | `1E1.odt`, ability 4 p108–109 | Confirmed and executed |
| Heat output 900, k=2, radius 7 m | `1E1.odt`, ability 4 p111–112, p116 | Confirmed; radius recorded, recipients explicitly supplied |
| `hd=((ho²-(a²+Rh²)/2)/ho)*(th-k*to2)^(1/k)` | `Damage types.odt`, Heat p49–53 | Confirmed; k=2 implemented |
| Nonnegative damage | Author clarification | Confirmed; negative coefficient clamps to zero |
| Beam begins at Active start | Author reply; current `1E1.odt` p114 | Confirmed; 180 ms from unmodified activation |
| Exposure grows with elapsed exposure, freezes after beam ends; non-exposure then grows | Author reply | Confirmed; exposure 0→3 s, residual non-exposure 0→1.5 s |
| Heat leaves armor unchanged; no self/target disorientation or instability | Author replies | Confirmed and executed |
| Ongoing damage uses current armor and heat resistance | Author reply | Confirmed; each interval reads current defenses |
| Damage accumulates continuously | Author reply | Confirmed; analytic integration, no invented ticks |

For k=2 define `C=max(0,(ho²-(a²+Rh²)/2)/ho)` and `q=th-2*to2`. Damage is the integral of `C*sqrt(q)` over seconds. With fixed defenses and full exposure T, exposure damage is `(2/3)*C*T*sqrt(T)` and residual damage is `(1/3)*C*T*sqrt(T)`. Thus the complete T=3 beam deals `3*C*sqrt(3)`.

A defense-changing event must split the interval: integrate the preceding interval using its defenses, apply the change, then integrate later damage using the new defenses. Regression instrumentation separately changes armor, heat resistance, and both at 480 ms to verify this order. This does not add mixed-action encounter support. Unlike venom, heat never retains a permanent pre-hit armor snapshot.

The exact arithmetic layer stores rational amounts plus square-root terms. HP and totals remain symbolic; 50-digit decimal values are labeled approximations for display. Equal root terms cancel across interval boundaries. Existing rational result records retain their previous format. Activation timing uses the existing integer-millisecond ceiling rule; a continuous effect expiry can retain an exact fractional millisecond instead of extending damage by rounding it later.

## Established initial scope

One stationary, scenario-authorized beam, k=2, explicit unique recipients exposed for the entire beam lifetime, no other actions. Each recipient must be unshielded and survive the complete effect. Initial caster instability must be zero. Current disorientation modifies Gathering and existing statuses decay. An explicitly listed unshielded caster can also receive damage; this preserves friendly fire without inventing spatial hit testing.

The event log records initial states, activation timing, beam start/end, Active end, residual expiry, interval formulas/clocks/current defenses, exact HP changes, final states and limitations. Multiple recipients have individual and aggregate summaries. Empty explicit recipient lists are supported.

## Base result

1E1 attacks 2E4 with initial HP 9080, armor 165, heat resistance 165 and shield 0. The caster remains outside the beam as explicitly configured.

- C = `(810000-27225)/900 = 3479/4`.
- Beam starts at **180 ms**, Active ends at **480 ms**, beam ends at **3180 ms**, and residual heat ends at **4680 ms**.
- Exposure damage: `(3479/2)*sqrt(3)` ≈ **3012.902380 HP**.
- Residual damage: `(3479/4)*sqrt(3)` ≈ **1506.451190 HP**.
- Total: `(10437/4)*sqrt(3)` ≈ **4519.353570 HP**.
- Final HP: `9080-(10437/4)*sqrt(3)` ≈ **4560.646430**; armor remains **165**.

## Unimplemented and unresolved

Shielded heat/exposure and continuous shield interactions, overlapping beams, re-entry, moving targets, automatic radius detection, caster interruption, death/revival inside an interval, cooldown anchors/availability, dyspnea costs and Recovery are outside this stage. They are rejected or explicitly excluded rather than approximated. The nonlethal check is exact for the constant defenses of this single-action scope. Only k=2 heat is implemented; other root orders raise an explicit unsupported error.

**221 automated tests pass**, covering existing mechanics plus heat formula/integral boundaries, live-defense changes, lifecycle order, multiple recipients, friendly fire, exact expiry, deterministic replay, and unsupported input rejection. Saved scenarios, complete logs, source hashes and runnable snapshots are in [results/1e1-ability4-stage](results/1e1-ability4-stage/README.md).

## Subsequent shield and overlap clarifications

The author confirms shield damage takes priority for heat, and each overlapping beam is calculated individually. Together with the existing shield rule, armor and heat resistance do not mitigate the portion absorbed by shields. Each beam therefore needs its own exposure/non-exposure clocks and damage calculation; beam outputs or exposure histories must not be merged before calculating damage. Individual contributions update the recipient's shared HP/shield state.

| Rule | Status | Implementation state |
|---|---|---|
| Shields take heat damage before HP | Confirmed by author | Not yet executed by the controlled heat runner |
| Armor/resistance do not reduce shield damage | Confirmed general shield rule | Must also apply to heat when shielded support is added |
| Overlapping beams are calculated individually | Confirmed by author | Not yet executed; current runner accepts one activation |
| HP heat exposure while shield absorbs damage | Confirmed: does not accumulate; begins at zero when shield breaks | Not yet executed by the controlled heat runner |
| Shield armor and heat resistance | Confirmed explicitly: both count as zero | Incorporated in isolated analysis; shielded encounter execution remains unsupported |
| Residual heat on shields | Confirmed: damages shields; ends when the shield breaks, with no transfer to HP | Specified but not yet executed by the controlled heat runner |

The existing unshielded results and frozen evidence remain valid for their established scope. The current runner still rejects shielded recipients and repeated activations; these clarifications are recorded specifications, not claims of implemented support. Continuous shield losses will also require preserving their individual regeneration-delay history rather than treating an entire interval's damage as one hit.

The author confirms HP exposure starts at zero when the shield breaks. For example, if a shield breaks two seconds into a three-second beam, HP exposure grows from 0 to 1 during the remaining second; applying the already confirmed k=2 residual rule gives 0.5 seconds of subsequent HP residual heat. This example assumes no other effects or shield changes. Shielded time does not enter this HP exposure clock. The shield's armor and heat resistance are explicitly confirmed as zero. Residual heat damages shields but ends when the shield breaks; the HP exposure clock is separate from shield exposure.

## Residual heat parameter study

The author requests a comparison before choosing shield residual behavior. With fixed coefficient C and full exposure T, the documented general-k curve gives exposure damage `C*k/(k+1)*T^(1+1/k)` and candidate residual damage `C/(k+1)*T^(1+1/k)`. Thus residual/exposure is exactly `1/k` and residual/total is `1/(k+1)` whenever exposure damage is positive. Neither ratio changes with T, output or unchanged defenses. Shield depletion or changing defenses can change actual phase loss ratios.

[The isolated analysis](results/heat-ratio-analysis/REPORT.md) includes 48 parameter cases, six sensitivity cases, an interactive comparison and independent numerical integration checks. The separate general-k analysis helper does not extend the authoritative k=2 encounter runner. **232 tests pass**. The study preceded the shield residual decision below; shielded encounter execution is not yet implemented.

## Shield residual decision after the parameter study

The author selects residual heat damage on shields. When the shield breaks, its residual heat ends; remaining shield residual damage does not transfer to HP. Shield armor and heat resistance remain zero. If the beam is still exposing the target when the shield breaks, HP exposure starts at zero and grows only from subsequent unshielded exposure. If the beam has already ended, the shield's residual effect cannot start HP exposure or a new HP residual effect.

For unchanged output/defenses and a complete uncapped curve, k>=2 implies residual damage is at most one-half of exposure damage, and at most one-third of the combined total. Shield depletion truncates the actual residual damage. For example, if the beam has ended, a shield has 100 left, and its remaining residual potential is 300, it loses 100, reaches zero, and the remaining 200 causes no HP damage. This is a consequence of the author clarification, not an executed encounter result.

These are confirmed rules in the registry. The current heat encounter runner still accepts only its established unshielded single-beam scope. The saved ratio-analysis package preserves the earlier comparison when shield residual was undecided; its uncapped calculations remain valid. No combat code changed for this documentation update.
