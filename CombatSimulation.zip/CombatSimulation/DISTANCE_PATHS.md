# Finite distance-path planner

2026-11-14 verified correction: a contact normal with zero projected initial
relative velocity and zero endpoint displacement must not open through an
invented quadratic arch. Its midpoint projection now includes the reverse of
that existing contact half-space, retaining the normal equality. This applies
to static and relative body contacts without locking tangential motion. Actual
outgoing velocity or endpoint separation keeps the ordinary unilateral branch.
The low/high middle controls then share that plane, and the original complete
Bernstein certificate is checked after blending. No reference is clamped after
certification and no distance/contact is removed.

A pure two-body case reproduced zero initial/endpoint normal motion but about
1.667e-13 m/s of upward curve velocity before correction. The new static/relative
support tests keep the plane closed and retain real velocity/acceleration lift.
The actual tiny-step floor cycle also needed raw gravity in the live solver;
see [the controller](PERSISTENT_DISTANCES.md) and results/linked-climb.

2026-11-09 numerical correction: after eight supporting-plane refinements, a
stalled radial feasible bound may also use a feasible velocity field in which
connected distance endpoints share velocity. Fixed endpoints require zero
velocity; contact planes, blocked directions and grapple equalities remain in
the same linear solve. Interpolating from this field preserves the distance
limits and homogeneous contacts. The candidate is accepted only when its
unchanged objective/error certificate succeeds, and exact nonlinear feasibility
is rechecked. This avoids erasing shared translation when tiny tangent motion
and rounded supporting normals make scaling from zero ineffective.

The optional feasible_anchor_projection output pins that selected response.
Per-force accounting blends the original and anchor linear responses using the
same feasible scale. It therefore retains a common released impulse even when
the radial scale is zero. Earlier successful branches retain their record
format. Original failures, pure exact-certificate/common-force regressions and
actual unequal-height chain checks are preserved in results/body-scales.

Delegated numerical/architecture decisions, 2026-11-01. A pure planner now
constructs quadratic reference paths with maximum-distance certificates over
their complete interval. It supports overlapping distance limits, actual
grapple-style equalities and one-sided contact planes jointly. The later
[live controller](PERSISTENT_DISTANCES.md), 2026-11-02, now uses this planner
through saved world paths. The numerical module itself adds no chain cast,
binding, cost, cooldown, force lifetime or character definition.
[Evidence](results/distance-paths/README.md) ·
[Finite projection](combat_sim/mechanics/distance_projection.py) ·
[Path planner](combat_sim/mechanics/distance_path.py).

## Why instantaneous projection is insufficient

An initially taut pair with tangential relative velocity can satisfy the
[instantaneous radial limit](TETHERS.md) and exceed the maximum distance an
instant later. A quadratic fitted only to legal endpoints can also overstretch
between them. Both failures are reproduced by the new numerical checks.

The existing [saved-path backend](BODY_PATHS.md) gives prediction and advancement
one polynomial. This planner bounds that entire polynomial; the separate
[live coordinator](combat_sim/persistent_distances.py) selects persistent physics
knots and commits state through that backend.

## Certified finite endpoint response

For references `p`, desired velocities `u` and positive duration `h`, minimize
`sum_i(w_i * |v_i-u_i|²)/2` subject to:

- `|(p_B-p_A) + h*(v_B-v_A)| <= maximumDistance` for each distance limit;
- existing grapple velocity equalities and bilateral blocked axes;
- one-sided `v_i·normal <= 0` for a static plane, or
  `(v_i-v_j)·normal <= 0` for relative body contact.

Use individual positive weights `(maximumHP/500+currentArmor/10)^1.1`, as in the
existing grapple projection. This is a delegated chain-sharing model. It does
not add chain participants to the author's summed-stat knockback resistance
group. Connected grapple equalities count each supplied body once.

All starting references must already satisfy their distances. Zero velocity
is then feasible. Supporting planes of the endpoint balls give outer linear
relaxations with nonnegative bounds. Normals can be rounded without invalidating
the plane; a checked rational upper bound on their norm keeps it an outer bound.
The exact linear QP supplies a lower objective bound.

[The affine solver](combat_sim/mechanics/affine_velocity.py) extends the exact
active-set approach to nonzero bounds. A tighter row can be dependent on the
currently active rows; an exact dual multiplier pivot removes a limiting row
without moving the primal before the next solve. For example, `x<=2`, `y<=2`,
`x+y<=1` needs this pivot when starting from `(3,3)`. Treating every entering row
as independent would attempt a singular solve. Canonical ordering, normalized
duplicate bounds and exact feasibility/complementarity checks remain.

A checked radial scaling toward zero makes the finite nonlinear response
strictly feasible. Its objective is an upper bound on the true minimum.
Strong convexity gives `|returned-optimum| <= sqrt(2*gap/minimumWeight)`.
The default Euclidean velocity-error budget is `1e-10 m/s`; the returned exact
rationals satisfy the distances without spending that budget on overstretch.
Iteration failure raises an error, rather than returning pairwise corrections.
Only active supporting planes need retention between refinements: their exact
KKT certificate retains the previous lower bound. Physical contact planes stay
present. This avoids accumulating an unnecessary quadratic-sized Gram matrix.

## Whole-interval path certificate

First project the initial velocity against currently taut radial limits,
equalities and contact planes. Plan a feasible half-time control point and a
feasible endpoint using the finite solver; free acceleration enters the
endpoint request. These define a safe quadratic Bezier control cage.

Move the middle control point toward the desired initial tangent as far as the
certificate allows. For relative control points `r0,r1,r2` and maximum length L,
the degree-four Bernstein coefficients of squared distance minus L² are:

`r0²-L²`, `r0·r1-L²`, `(r0·r2+2*r1²)/3-L²`, `r1·r2-L²`, `r2²-L²`.

All five are checked nonpositive using exact rationals. Bernstein basis
functions are nonnegative and sum to one, proving the bound for every time in
the interval. The blend search uses checked linear/quadratic root bounds. The
safe cage makes zero blend feasible; choosing the largest certified blend
retains more of the tangent than blindly using that cage. This is a sufficient,
conservative certificate, not a claim of an optimal continuous trajectory.

Returned `BodyPathPiece` coefficients have consistent position/velocity
derivatives and exact slicing. Unconstrained ballistic motion and common gravity
have exact unchanged test cases. Equalities and contact planes hold
throughout the curve too. The independent audit expands the actual returned
power polynomial and converts it to Bernstein form, rather than trusting the
planner's control-point calculation.

## Exact records and numerical boundaries

The ten-body case produces coefficient numerators exceeding 43000 bits.
Python's ordinary `Fraction.__str__` can reject their decimal conversion.
[Local ratio formatting/parsing](combat_sim/mechanics/exact_ratio.py) preserves
the existing decimal `numerator/denominator` strings and every digit, using
Decimal conversion without changing the process-wide integer-string guard.
Use `BodyPathPiece.from_record` or `read_ratio` for large saved ratios.
Ordinary historical records retain identical bytes.

Owned Decimal precision bounds supporting-plane input growth and presents
velocities; exact rational checks certify the resulting finite problem. This
does not certify a global ODE error, conservation law, temporal accuracy or
performance for repeated live steps. Large exact denominators also require
bounded-precision state reconciliation in the live controller.

## Live integration and remaining delivery

The [persistent coordinator](PERSISTENT_DISTANCES.md) now chooses knots
independently of observations, locates actual slack-to-taut crossings on coupled
candidates and preserves separate ground/inertial drivers. Existing terrain,
body, projectile, Block and field queries use the same paths. Finite-force
components share the selected linear response with the affine offset in base
motion once. Native expiry, gravity/support, life and paid landing handlers
remain in charge of their events. Reconciliation and a measured free-orbit
refinement case have explicit numerical boundaries; these do not establish
universal temporal accuracy or energy conservation.

[3E5's existing 30 m/s chain](CHAIN_CAST.md), 20 m maximum separation, 15 s
binding and common Break now use the planner through live projectile/action/life
systems. Engineering attachments remain available as explicitly labelled probes.
The later [1E1 ground chain](GROUND_CHAIN.md) adds typed fixed surface endpoints
to these same polynomials, with constants recorded separately from actor pieces.
The full six-kit/5v5 Goal stays active and incomplete.
