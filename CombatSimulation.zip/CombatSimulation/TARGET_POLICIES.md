# Simple target policies in the shared engine

2026-11-14. Delegated simulation-control extension; no character ability changes.
The fresh3389-method gate and all6 complete policy controls pass on current
fixed inputs; see [current verification](results/fence-roster/README.md). The
[paused implementation package](results/target-policies/README.md) is preserved.
The broader Goal remains incomplete. Advanced NPC planning is deferred.

Each team participant still uses priority_when_ready for ordered legal ability
selection. Its target field now selects an independent enemy policy:

| target value | Choice |
|---|---|
| nearest_living_enemy | Existing exact horizontal squared distance, then stable actor identity; preserved default |
| lowest_hp_enemy | Lowest current HP, then exact horizontal squared distance, then stable actor identity |

HP is absolute current HP, not a percentage or a balance score. Distance keeps
the original x/y convention; altitude does not acquire an implicit new targeting
rule. Friends, dead actors and the source itself are ineligible. A dead source
or no living enemy yields no enemy. Self-targeted abilities and explicit world/
surface commands keep their existing legal paths.

Policies receive a copied read-only snapshot containing only string team
identities, exact HP and horizontal position. Mutable team identities reject at
that boundary. Eligibility is captured before calling a replacement policy. They return an identity or None; the engine validates that
boundary. They do not own resources, readiness, motion, death, cooldowns or
released effects. Ability priorities and authoritative phase payments are
unchanged. Already-started actions/released attacks retain their old snapshots.
A policy can choose None intentionally; it does not acquire a scheduled retry
or authority to change combat state by doing so.

The nearest policy calls the existing selector and adds no trace events.
Other policies emit target_policy_selected only for an action actually started,
with action ID, policy name, eligible HP/distance facts, selected enemy and the
actual action target. The latter can be self or None for utilities. Automatic
weapon return remains its own owned action, not an enemy-policy decision.

For research API use, an engine.target_policies[actor] entry can be replaced
before run() by an object implementing EnemyTargetPolicy: a nonempty name and
choose(actor, participants). The same snapshot and legal-target check apply.
Reproducing a custom policy retains its implementation alongside the inputs;
built-in scenario names are resolved through a fixed registry. This is a small
replacement interface, not an autonomous steering or planning system.

Ordinary movement/control scripts continue through the shared legal action
path. Simple targeting/priority variation and scripted straight movement supply
initial5v5 experiments; they do not claim advanced NPC intelligence.
