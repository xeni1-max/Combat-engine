# Persistent grapple-group motion

**Current turning extension, 2026-11-13:** [active linked turns](ANGULAR_LINKS.md)
preserve common translation, world-space reference offsets and frozen drives.
Real angular impacts still transmit blocked movement and retain individual
penalties. Summed-stat group knocks, controlled holding work and independent
expiry/life rules remain. Prescribed angular/linked climbing is still pending.

Shared-world foundation, 2026-11-01. This extends the earlier
[atomic spatial interface](SPATIAL_TRANSITIONS.md). It adds persistent coupled
motion. [Actual 1E5 grab/holding](GRAPPLE_DELIVERY.md) now creates these links
through real contact and owned control. [Common Break](GRAPPLE_BREAK.md) now
releases individual holds. [Actual heavy-punch knocks](KNOCK_DELIVERY.md) now
impose shared group motion and elasticity; other knock trajectories remain unfinished.
[Voluntary dash launches](BODY_LAUNCHES.md) now supply independent body inputs
to this same projection. Actual contacts restore their prior ground pace while
retaining individual landing effects; imposed group knocks remain separate.
[Implementation](combat_sim/grapple_links.py) ·
[Trajectory integration](combat_sim/linked_motion.py) ·
[Evidence](results/grapple-motion/README.md).

Current inputs now advance these existing grapple polynomials through the
[saved body-path coordinator](BODY_PATHS.md). Prediction and advancement share
one reference prefix; independent driver/gravity state and individual landing
obligations remain. Actual held-pair horizontal and upward knocks are included
in the [current path evidence](results/body-paths/README.md).

## Source and selected model

`Grapple abilities.odt` p25/p29 supplies the two-body vector mean with
`w = (maximum_HP/500 + current_armor/10)^1.1`. Author clarification, 2026-11-01,
requires a knock to move the still-grappled participants together, using summed
stats in displacement resistance. [KNOCKBACK.md](KNOCKBACK.md) separates this
confirmed rule from delegated connected-component and runtime choices.

Current inputs select `grapple_links.mode=grapple_velocity_v1`. Links are
directed for controller/life/fatigue attribution and undirected for motion.
Each connected component gets one common velocity and acceleration from all
independent character drives, evaluated on the existing event timeline.
Cycles and multiple simultaneous links count an actor once. The source's
40-digit weight and existing owned-precision projection are reused; they are
not physical masses in kilograms. Characters keep fixed relative translations
while joined; this is not a rotating rigid-body or unilateral rope solver.

Independent horizontal inputs are retained behind the constraint. A later
walk/run transition or special stop changes that actor's input, then the group
is projected again. This prevents a last-writer controller from moving one
body alone or repeatedly averaging an already shared velocity. A basic jump
likewise preserves the free horizontal input behind its already averaged
physical takeoff velocity. The initially implemented double averaging was
reproduced and corrected; its failing regression is retained in the evidence.

Vertical launch is combined once and then evolves as shared physical velocity
under one 9.81 m/s² gravity. An upward group force releases every member from
support. Static support held by a member can prevent downward group motion;
unsupported partners remain airborne rather than acquiring a fictional floor.
The numerical body reference and pose transforms remain authoritative.

## External changes and resistance

Atomic external reference/velocity changes expand to the current component.
A reference change supplies the same translation to every member; an imposed
velocity supplies the same physical velocity to every member. The latter is
not divided again by the component's weights. Conflicting explicit requests,
including an explicit unchanged destination/velocity, reject before mutation.
One blocked partner destination rejects the entire transaction. No-ops remain
no-ops. Explicit instantaneous projection also includes registered links and
their otherwise omitted participants before solving all constraints together.

`world.grapple_links.knockback_distance(actor, nominal_m)` snapshots current
living membership, summed maximum HP/current armor and the resisted distance.
For two ordinary 1E2 bodies, a nominal 15 m gives summed H=16280, armor=300 and
resisted distance 14.3692821023… m. A singleton instead gets 14.7057596966… m.
Actual incoming armor loss changes both movement weights and the resistance
snapshot. Remaining HP and shield stock do not replace maximum HP.

This query calculates distance; each actual cast still needs its own timing,
elasticity, physical contact and fatal-hit effect ordering.
Direction helpers treat knockback/knock away as synonyms and up/down as ±z.
[Heavy-punch delivery](KNOCK_DELIVERY.md) now adds the actual contact, causal
life ordering, finite impulses and elastic contact response for that ability.
Force probes exercise group physics without claiming a cast of those abilities.

## Contacts on the common timeline

Existing continuous sweeps predict real body/terrain contacts from the shared
trajectory. At impact, the existing collision system applies statuses to the
actual contacting bodies using their individual snapshots and defenses.
The lost movement is transmitted to all free inputs in that grapple component.
All same-time face normals and character centre-line directions are projected
together, rather than applying separate pair corrections in sequence.

Noncontacting partners receive no invented collision penalty. Their blocked
input/acceleration cannot reintroduce inward velocity after the contact. An
affected locomotion transition is cancelled through owned-action handling;
special stopping retains its remaining slide endpoint. Compatible independent
weapon actions and released effects keep their own lifetimes.

This uses collision impulses instead of persistent resting-contact locks. Such
locks would make reactivation depend on when an observation notices a gap.
Ceiling impact removes upward motion and then gravity resumes; ground contact
establishes actual support. A force launch has no fake jump cost or landing self
effects, while a real jumper retains those obligations. Tests cover oblique
character contacts, two grapple groups, and two different members contacting
perpendicular surfaces at the same time.

Expiry is a priority-0 phase boundary. A force applied after expiry sees the
new membership. A predicted contact tied to expiry is revalidated under the
released motion; the saved 390 ms contact correctly uses 2 m/s rather than the
old shared 1 m/s across observation/precision/order controls.

## Life, fatigue and release

A link captures immutable participant life generations, creation, source and
expiry. Death ends incident links; revival cannot reacquire an old one. IDs
cannot be reused. Prepare/commit plans are world-bound and reject stale time,
geometry, life, free input, status, action or link state before mutation.
Typed durations retain exact input fractions until owned-precision scheduling.
Repeated release/expiry callbacks are harmless.

Both participants block ordinary dyspnea recovery while joined. This does not
invent a holding cost. The controller releases at the source fatigue limit
`D >= max(0, 100-(O+U)/10)`. Real incoming gun statuses can trigger it. Existing
continuous sprint effort uses its anchored nonlinear formula; actual holding
and compound effort use the shared budget writer. Both fatigue forecasts
split at status knots and bracket a crossing, rather than using fixed ticks or
replacing effort with a linear approximation.

Under delegation, release removes the velocity constraint and resumes each
independent free input; it does not add another impulse. An imposed force already
propagated to every member therefore persists for a surviving released member.
Shared ballistic vertical state remains physical; old jump/landing obligations
are neither refunded nor resumed in a later life. This is a game kinematic
model; no energy-conservation or general force/mass solver is claimed.

## Inspectable controls and remaining work

Engineering-only `spatial_interventions` can contain a `grapple` operation
instead of body changes or an instantaneous projection:

```json
{
  "at_ms": 0,
  "scope": "engineering",
  "source": "scenario:grapple_motion_probe",
  "grapple": {
    "operation": "attach", "id": "hold",
    "controller": "A", "target": "B",
    "controller_life_generation": 1, "target_life_generation": 1,
    "duration_ms": 3000
  }
}
```

Release uses `{"operation":"release","id":"hold"}`. All intervention rows
validate before scheduling and run once in input order at script priority 5.
This allows public API/CLI evidence without encounter subclasses. It does not
make an engineering operation selectable as a character ability. Result links,
locomotion groups, spatial records and contact-transmission logs are inspectable.

Actual 1E5 grab/drag now adds physical contact, phase-specific limb/action
ownership, holding effort and 900/s constriction/tear. Its links retain ability,
holding action and both lives, and end with their controlled damage/effort.
Generic engineering controls retain their explicit labels and acquire none of
those cast resources. Common Break now uses the actual hold identities. No kit completion
is claimed. [Actual delivery and evidence](GRAPPLE_DELIVERY.md).
3E5's authored charge/wall slam and other knocks remain unfinished. Its heavy
punch now supplies actual group knocks and finite elasticity, including real
wall/ground/body contacts and independent overlapping force expiries.
Binding-chain, portal and environmental grapple-gun rules remain separate.

Finite/raised and living support now use [actual departure witnesses](ANGULAR_SUPPORT.md).
A prescribed climb action must be
interrupted before linking; starting a prescribed climb while linked remains
guarded until shared traversal/release is integrated. Current body turning and
prone/Get Up geometry use their documented shared paths; wider interaction
coverage remains to be verified.
