# Physical prison and shared solid hand reach

2026-11-02. Existing **1E3 ability 4** now uses a real utility projectile and
shared mutable colliders. [Evidence and boundaries](results/prison-cast/README.md).
The six-kit/5v5 Goal remains incomplete.

## Source and delegated rules

Primary `1E3.odt` p9/p99–116 supplies G140/A180, speed100 m/s, release after
firing, self O/U120, target O/U110, Db2, a 4000-HP prison cube, 12 s duration
and 9 s cooldown. Firing is intrinsic momentary. No direct HP damage family,
amount, binding value or cube dimensions are listed.

Under author delegation:

- Use a **damage-free contact carrier**. Pay Db2 and start cooldown at release
  (320 ms and cost4 at D0 in the neutral case). Self effects apply at Active
  midpoint; target effects apply on direct body contact. Reuse the neutral
  right hand, 2 cm sphere, faster compensated gravity arc and paid ballistic
  miss for unreachable aim. Block/terrain intercept without damage or a cube;
  personal shielding does not prevent a utility contact with the body.
- Six fixed cuboid faces share **one 4000-HP pool**, zero inherent armor and
  a 12 s clock from formation. Enable body/projectile/area blocking, wall/prison
  tags and ordinary typed damage/heat/removal. No character recovery credit.
  The compound object is unclimbable.
- Begin with 2 m inner side, 0.1 m material and 0.1 m body clearance. Fit an
  axis-aligned cube around current recipient geometry, with floor below its
  lowest point. Include actual grapple partners, already-contained bodies and
  bodies intersecting proposed material; expand until no living body is cut.
  Sorted finite closure never moves actors. Static-object overlap retains the
  registry's existing policy.

## Ownership and interactions

Pin the released definition and target statuses, including physical copies.
Utility contact joins the normal simultaneous HP/shield/armor wave at zero
power. Form after healing/death; reject a dead/replaced recipient life. Two
actual mirrored casts verify same-wave damaging contact killing before formation.
Caster death preserves released flight; original source action/life attribution
survives restoration before contact. A formed object is independent of caster
and occupant lives. Death/revival neither erases nor recreates it. Copies have
independent pools/clocks; a later shot hits material instead of refreshing it.

Walls confine through native contacts. Actions, forces and flight continue.
Jumping meets the roof and lands; climbing can meet the new shell and interrupt;
raised-floor expiry causes support loss/falling/landing. Existing bleeding,
toxins and body heat keep their normal lifetimes. No invented binding/Break
value replaces physical material.

Traversing damage is blocked in both directions. Occupants sharing a cavity
can hit one another; remote summons can be placed outside. This is material
cover, without a global attack ban. The ice bomb's binding-only burst retains
its selected cover-transparent policy; its physical carrier damages walls.
Actual beam destruction exposes a body at the live field's removal boundary.

## Shared hand reach and area policy

An authored muzzle could extend beyond thin cover while the body stayed inside.
Current `solid_hand_reach_v1` sweeps a 2 cm sphere from actual torso centre to
requested hand against body-blocking solids and other living bodies. Ignore
own/dead bodies and projectile-only Block surfaces. Clip at first contact with
a **1 μm inset toward the torso**. Use the same resolved point for reporting,
physical Recovery, melee and release. Two hands retain parallel Recovery.
Canonical requests stay separate. No animation, body translation or action-time
refund; later geometry can obstruct an already-timed action. Clipped flights
record requested/actual origins, anchor and blocker. Owned precision and a
geometry/life/pose cache keep queries deterministic. Old selected inputs retain
their previous reach behavior.

Body-area recipient selection now accepts explicit occlusion. Damage retains
world cover; the ice bomb's existing `none` setting now actually bypasses it.
Previously the helper silently used ordinary cover for both policies.

## Contact correction and concrete remaining failures

Current `reference_contacts_v1` stops pose deformation at contact without
reflecting a body already travelling away or kicking an internally touching
rigid grapple. Elastic moving-body contacts use a common pre-response frame
from existing HP/armor weights; static material fixes world zero. Zero elasticity
retains authored loss of each own collision component. A unit-elastic equal-weight
pair exchanges normal speeds while preserving tangential movement.

Repeated contact by the same life/geometry pair within **1 ms** absorbs normal
movement for that response/current grapple group, preventing rapid elastic
reflections in microscopic gaps. Keep statuses and finite force clocks; do not
skip time or move bodies. Log stabilization. This delegated numerical contact
band is not a universal multi-body energy/convergence certificate. Old selected
inputs retain their historical responses.

The full2200ms crowded heavy-knock continuation now completes with selected
[living-body contact/support](BODY_SUPPORT.md), including a complete numerical
control and public API/CLI/hash replay. The earlier force-expiry placement failure is
now corrected by [velocity-only transition validation](SPATIAL_TRANSITIONS.md):
its actual cast continuation completes at1800ms and retains references at expiry.
Both original failed diagnostics remain preserved in [the old checkpoint](results/prison-cast/README.md);
the shorter paired-contact capture there verifies only its first wall response.
Shared support composes with the same path writer before charge/wall slam;
final regression status is in [its evidence package](results/body-support/README.md).
General turning, ledges,
portals, duplication and remaining kit deliveries stay unfinished. Advanced NPCs
and mass/balancing automation remain deferred.
