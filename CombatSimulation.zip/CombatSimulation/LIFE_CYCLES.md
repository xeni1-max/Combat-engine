# Actor lives, death and restoration

**2026-11-01 spatial integration:** physical restoration now preflights and
commits through [the shared spatial coordinator](SPATIAL_TRANSITIONS.md) before
HP and life generation change. It clears imposed motion, preserves the frozen
pose and chooses actual support or gravity. The spatial audit identifies the
old life; `life_restored` identifies its successor. Ordinary revival and frozen
life/revival replays verify this path. [Persistent grapple links](LINKED_MOTION.md)
now retire across death and cannot rejoin actual revived lives. Cast-specific
ownership/resource teardown and other linked deliveries remain unfinished.

[1E5 component melee](COMPONENT_MELEE.md) now verifies these boundaries with
real posthumous doubled bleed and clipped mutual-death credit. Under delegation,
restoration retains the next-arm cursor without resuming old control. Its
permanent passive applies to newly released attacks, while each old wound keeps
its original life/power/modifier identity. Recipient wounds still retire at that
life's death. No 1E5 healing or revival ability is inferred from this support.

Current shared-world inputs select `life_cycles.mode=actor_lives_v1`. Generations
run with actual actions, damage, projectiles, effects, cooldowns, recovery and
body geometry. An engine restoration API is integrated, and current definitions
also execute [2E4's authored death-triggered revival](REVIVAL.md) and
[continuous passive healing](HEALING.md). [Foundation evidence](results/life-generations/README.md).

## Source and authority

The author requires death at zero HP, cancellation of controlled actions and
survival of released/deployed work. `2E4.odt` p13 specifies revival with HP equal
to damage dealt in the preceding 10 s, 65 s cooldown and three charges; p134
specifies 2000 ms Active. The author explicitly exempts revival from dyspnea.
`Details2.odt` p0 excludes shield damage from damage-based recovery; `Details.odt`
p3 specifies the separate healing cap of 90% of damage received in the last 8 s.

Those rules do not fully define state across lives. The policies below are
delegated engineering decisions, preserving HP-only restoration and the authored
rolling history. They do not change the six characters or add an ability.

## Identities and transition policies

An actor has a permanent encounter ID and a positive integer life generation.
Each life records birth, initial HP, death and restoration source. A new life
never erases the previous death. The combatant's `died_at_ms` describes its
current life; `actor_lives` retains the complete history.

| State/work | Selected lifecycle |
|---|---|
| Owned actions and phases | Capture generation on acquisition/scheduling. Death cancels ownership; an old phase cannot run in a later life even if another revision matches. |
| Decisions/restriction expiry | Life-bound tokens plus existing revisions. Rescheduling preserves an already captured token. |
| Future scripted commands | External actor-level inputs, evaluated when due. Dead actors reject them; they are not old owned actions. |
| Projectiles/copies | Keep actor, source generation, ability/action and lineage. Source death/restoration does not cancel physics or change released power. New contacts identify the actual target life. |
| Beam/pause areas and fixed objects | Autonomous with captured source attribution. Expiry uses the entity revision, not the caster's current life. |
| Recipient bleeding, heat/incident/body memory and function restrictions | Retire with that life. Old expiry cannot affect the new body. A surviving area creates a fresh track on the restored life, starting at zero heat memory. |
| Armor, shield stock, ammo, hands/pose, fatigue, applied O/U and knockdown | Retain frozen death-state values. Restoration grants HP; no reload, effort refund, armor/pose reset or general status cleanse. |
| Ordinary cooldowns | Preserve remaining work; dead time supplies no progress. Resume with currently live pause sources, dropping expired sources. |
| Shield recovery | Keep actual debt and absolute eligibility times. Dead time supplies no work. Resume service at birth; invalidate old forecasts at both boundaries. |
| HP-loss/credit history | Keep actor-wide rolling windows across lives. Preserve source/target generation, including posthumous damage; optional life filters support inspection. |

For owner-contact policies, birth immunity belongs to the original source body.
It ends when that life ends, even if a slow projectile has not exited it. An old
projectile copied into a later owner life is born armed against that body;
the source identity still stays old. Default owner-ignore policy is unchanged.
Contact records retain both lives for explicit policies. The current source
revision removed 2E4's former owner-contact follow-up; the retained generic
capability does not imply an unfinished current character ability.

[Attack enhancement grants](ATTACK_MODIFIERS.md) are also life-bound. Death
retires unused/timed grants; restored actors do not inherit them. Released
attack snapshots retain original source life and values through later death,
expiry or cancellation. Actual mutual-death thrusts verify clipped HP credit
and revival eligibility while bypassed shield stock remains intact.

Death snapshots eligible outgoing HP over `(death-10000,death]` after damage
already committed at that causal boundary. Later posthumous damage keeps its
original source life and remains in rolling actor history; it does not rewrite
an earlier snapshot. [The revival controller](REVIVAL.md) now uses that basis;
it does not spend the separate [consumed healing allowance](HEALING.md).

Ordinary action acquisition is forbidden while dead. The death-triggered
2000 ms revival uses a life-bound attempt controller outside living `BattleAction`
ownership. Its finite charges, background cooldown, HP snapshot and occupied-
completion failure policy are documented separately in [REVIVAL.md](REVIVAL.md).

## Physical restoration and records

`SharedEncounter.life_cycles.revive(actor, expected_generation=..., hp=..., source=...)`
requires a settled dead life, positive HP no higher than profile maximum and
source attribution. Invalid values raise before mutation; stale/already fulfilled
requests return false. An old completion cannot refill a newer life.

Restore at the retained body pose. Occupying terrain/living bodies cause a false
return without teleporting, granting HP or advancing generation. The future
ability must own any retry. Establish support only from actual current geometry;
otherwise fall from rest under normal gravity, without restarting jump/climb or
adding jump-specific payment/landing penalties. Old queued movement does not
resume. Wake living policies while respecting their configured start times.

Records expose `life_generation`, `actor_lives`, life-aware source/target damage
and effects, projectile source/contact life and controlled-event actor life.
Summaries use accumulated actual direct plus continuous HP loss: initial minus
final HP is invalid when restoration increases HP.

`DamageLedger.amount(..., source_life_generation=1, target_life_generation=2)`
filters immutable history without changing default actor-wide 8/10 s windows.
Saved JSON validates receipt/entry life agreement. Self/friendly, shield, armor
and construct credit rules are unchanged.

## Verification and boundary

The preserved foundation checkpoint passed **1335 tests in 151.621 s**, including
12 new identity/history checks and
26 shared lifecycle methods. Coverage includes real lethal gunfire, repeated
death/restoration, old/new source bleeds, fresh heat/dense thermal retirement,
pause reconciliation, matured shield debt without dead-time work, obstruction,
airborne/climb interruption, stale events, old copied shots, Qard marks hitting
a restored life and correct damage summaries. Precision/observation controls
retain the existing numerical tolerances.

Final review reproduced and corrected birth immunity crossing owner lives.
Slow shots still inside a dying owner and old shots copied into its later life
now contact under their declared consume/impact policy. Self impact retains the
old source life and remains ineligible for recovery credit.

Three ordinary encounters reproduce complete API/CLI output. A fourth complete
engineering probe restores after a real lethal hit; it is **not a 2E4 cast**.
All conserve attributed HP across their lives. Both reviews and the movement
matrix pass; nine earlier effort API/CLI captures replay under frozen inputs.

Frozen definitions without life rules retain their historical terminal adapter
and omit unknown generation fields. Captures/manifests are unchanged. Component
toggle tests explicitly disable dependent life rules for earlier no-history or
no-cooldown configurations.

[2E4 thrust, attached venom and replacement items](MELEE_VENOM.md) now use
these identities: recipient death retires wounds, original source attribution
survives death, and a new life starts a fresh grab for an autonomous old item.
Actual ability-5 revival now calls this transition with its own timing, charges
and cooldown. Consumed funding and continuous passive healing now share the
same life identities and gross HP history. [Block layers/charges](BLOCKING.md)
and [automatic counters](COMBAT_REACTIONS.md) now also use these identities:
signals validate source life before emission, old frozen surfaces cannot spend
new-life stock, and released direct hits survive later source death. Mutual
counter death funds actual revival with clipped HP only. Persistent grapple
motion/life retirement is also verified. Other kits, cast-specific constraints,
moving-support/Get Up geometry and general six-character 5v5 remain unfinished.
