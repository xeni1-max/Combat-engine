# Typed effects and independent heat volumes

2026-11-09 forecasting correction: heat eligibility queries now clip to the
next valid shared body-path and phase boundary before constructing geometry
cells. HP recovery's independent250 ms forecast must obey that same boundary.
Previously the late clip let a75 ms Dodge dip keep shrinking legs beyond its
reversal and raised a negative-size error. The strict geometry guard remains;
normal pulses and accelerated pose changes use only their valid polynomials.
Observation times remain excluded from physical-only recovery epochs. The
actual beam/Dodge regression and unchanged older heat traces are preserved in
[the Dodge checkpoint](results/2e4-dodge/README.md).

Verified 2026-10-28 in shared moving combat. Current definitions opt into
`persistent_effects.mode=typed_heat_volumes_v1` with `world.ruleset=integrated_v2`.
This component uses the existing clock, body motion, collider registry,
continuous damage integrals and action ownership. It adds no runner or ability.
[Current capabilities](ENGINE_STATUS.md).

The 2026-10-29 extension adds typed [attached venom](MELEE_VENOM.md) in this
same registry/coordinator: moving wound anchors, attachment/residual clocks,
recipient-life retirement, live toxin defenses and immutable HP dose curves.
The 2026-11-10 [poison-volume foundation](POISON_VOLUMES.md) now shares
membership/HP/life coordination through a labelled released-volume API.
Actual launcher weapon/ammunition/projectile delivery remains unfinished.

## Source rules and delegated extensions

**Author effort clarification, 2026-10-29:** the beam's activation is extrinsic
momentary. Its independent lifetime does not represent sustained caster effort.
Once deployed, the character cannot stop it and caster instability does not
interrupt it. [Effort categories](ABILITY_EFFORT.md).

1E1 ability 4 summons an independent downward beam at a location: 3 s lifetime,
9 s cooldown, 180 ms Gathering, 300 ms Active, heat output 900, k=2 and radius
7 m. It deploys at Active start. Current root `1E1.odt` paragraphs are p9 and
p113–123, including the right-hand start/end pose `(0.30,0.15,0.45)`. Older
audits refer to their saved source revisions. `Damage types.odt` p49–53 and
the author's clarifications establish continuous damage, current defenses,
shield behavior and residual decay. The beam has **no dyspnea cost**, rather
than a Db=0 debit.

These extensions are engineering decisions under the author's delegation:

- At Active start, snapshot the selected target's current torso location for
  the stationary column. A dead target retains its last location. Deployment
  does not track subsequent movement or introduce predictive NPC intelligence.
- Any eligible body part exposes the character once at full strength, including
  friendly fire. Default cubes remain area-transparent as author-confirmed.
  Explicit area-blocking constructs use the existing downward witness policy;
  this is a deterministic cover model, not partial visibility.
- Per beam, target and defense layer, store nonnegative thermal memory `q` in
  seconds. While exposed, `dq/dt=1`; outside, `dq/dt=-k`, floored at zero.
  Re-entry before cooling completes resumes remaining memory; after zero it
  starts a new episode. This preserves uninterrupted exposure while preventing
  repeated exits from resetting or amplifying residual heat.

For k=2, rate is `C*sqrt(q)`, where
`C=max(0,(ho²-(armor²+Rh²)/2)/ho)`. Each unchanged-state interval uses current
defenses and an analytic affine-q root integral. Separate volumes have separate
tracks. Output/k are immutable deployment parameters; armor/resistance are live.

## Identity, ownership and clocks

`effect_models.py` defines explicit bleeding, heat-exposure and heat-column
types. Effect/volume IDs are independent of action IDs. Sources retain actor,
ability, parent action and, for a bleeding flight, projectile ID. Heat records
include target kind, layer, reference clock, q, exposure, revision, terminal time
and reason. Unknown effect/curve kinds are rejected.

The controlled summon declares its right hand and ability weapon resource and
requires upper-body/attack functions. Eligible lower-body movement can overlap.
An upper restriction can cancel controlled work; after deployment it cannot
remove the independent volume. Death likewise preserves released heat/bleeding
and their attribution. Persistent volumes retain no caster hand lock.

Leaving starts a revision-bound cooling expiry. Re-entering invalidates that
timer without resetting q. Volume expiry ends exposure, then each remaining
track cools for its own `q/k` seconds. Construct removal ends its track. Dead
actors leave spatial membership; applied effects retain their clocks. This is
not yet a revival implementation.

Shield heat uses zero armor/resistance and does not build HP exposure. Depletion
ends shield tracks. If the column still exposes the living recipient, each
beam starts a new HP track at q=0 at that boundary. Shield residual depletion
transfers no damage or memory to HP. These are the author's existing rules.
Current definitions extend this cold-start case with
[continuous heat/shield coupling](HEAT_SHIELD_COUPLING.md). Returning shield can
absorb pressure at zero stock; warm HP memory cools rather than disappearing
when shielding reforms. These partial-protection/warm-memory rules are delegated
extensions. Frozen definitions without the coupling mode retain the earlier
overlap guard.

## Continuous geometry and damageable cover

`volume_geometry.py` partitions intervals at rational polynomial roots:
quadratic part translation, affine pose resizing, circular footprint contact
and fixed-cover witness crossings. Predicates classify the open cells between
roots; there are no damage ticks or trajectory time samples. The earliest
membership boundary competes with phases, contacts and HP/resource exhaustion
on the common coordinator. A point tangency without a positive interval adds
no heat; persistent tangential contact remains eligible.

Roots refine to the run's Decimal precision; boundaries within
`1e-27 s = 1e-24 ms` are merged. Final membership settles at that resolution
without advancing time, paying resources or integrating future damage, including
cover changes at the horizon. Runs and compact summaries expose the heat
geometry tolerance; runs also record rules/precision, and evidence includes
source hashes. This does not certify projectile ODE cross-platform error bounds.

Damageable fixed objects receive heat once per object, regardless of part count.
They use zero inferred armor/resistance and share one HP pool across beams.
Their own parts are excluded from their cover query; other area blockers still
shield them. Undamageable geometry is not a heat recipient. `areas=false` makes
an object transparent to cover, not immune to damage if it has explicit HP.
Construct damage grants no character healing/revival credit.

The coordinator locates construct HP exhaustion continuously, removes the
collider, invalidates contacts/support and recomputes exposure for the remaining
interval. Blocked exposure is not transferred to the newly exposed body.
Continuous loss on `[begin,end)` applies before expiry at `end`; point hits
exactly at expiry still see an inactive object. Terminal objects stay terminal.

## Compatibility, verification and remaining scope

Frozen inputs without the new mode retain the fixed-recipient effect adapter
and established trace format. Legacy heat still rejects changing area cover.
Old evidence is preserved, including the principal review. Unknown legacy
effects now reject instead of implicitly becoming heat.

**Heat checkpoint: 1066 tests passed**: 44 new tests comprise 17 primitive geometry/memory/history,
25 shared-combat and two registry boundary checks. The focused run includes
existing registry tests (58 total). All five original review checks pass
unchanged. Six ordinary API encounters match complete public CLI traces,
including hash-seed controls. [Report and commands](results/spatial-heat/REPORT.md).

Current moving combat supports 1E1's beam, 1E2's gun/reload/pause area and existing
body actions. Moving Qard, poison volumes, restriction delivery,
source-specific bleeding bonuses, revival and complete kits remain
unfinished. Shield-loss history preserves its continuous distribution for later
recovery. Full six-kit/general 5v5 completion remains unverified.

The subsequent [recovery-flow increment](RECOVERY_FLOW.md) reached 1094 tests.
The subsequent [heat/shield coupling](HEAT_SHIELD_COUPLING.md) reached **1129 tests**
and verifies net stock, zero-stock absorption, incident/body memory, warm
reformation, delayed recycled losses and recipient death. Seven ordinary coupled
API/CLI captures reproduce; prior heat captures still match their frozen inputs.
[Evidence](results/heat-shield-coupling/REPORT.md).
The [cooldown-pause area](COOLDOWN_PAUSES.md) and [applied-HP history](DAMAGE_LEDGER.md)
are now integrated too. [Life generations/restoration](LIFE_CYCLES.md) now retire
recipient bleed/heat/incident memory at death while deployed source areas keep
their original life attribution. A restored recipient gets fresh exposure from
surviving volumes. Actual healing/revival, other damage types and complete kits
still need their authored shared delivery.
