# Combat engine implementation path

Author direction, 2026-10-25: proceed incrementally, choose mechanics needed for
internal consistency, minimize questions, retain the six existing characters
and their existing abilities. No animations. The longer-term target is
reproducible 5v5 battlefield experiments, not a claim that every kit already runs.

Author priority clarification, 2026-10-27: complete the shared combat engine and
test all existing abilities and interactions first. Preserve character identities
and unusual creative features while addressing balance and consistency. Shared
systems must accommodate independently active abilities and persistent effects
where their rules permit. Advanced NPC intelligence, learning and large automated
experiments remain later possibilities; step 6 follows engine completeness.
Confirmed design preferences are recorded in [DESIGN_PREFERENCES.md](DESIGN_PREFERENCES.md);
working responsibilities and decision boundaries are in [AGENTS.md](AGENTS.md).

## Completion criteria

- One shared world advances movement, actions, projectiles, effects, resources,
  collisions and death in a deterministic order.
- All six existing profiles have explicit supported ability definitions; an
  unsupported ability is reported rather than silently replaced or omitted.
- Scripted scenarios and replaceable NPC policies use the same legal actions.
- Reproducible 5v5 experiments vary roster instances, positions and policies,
  and report outcomes, damage, resources and a trace explaining the outcome.
- Numerical tolerances, mechanics revisions and scenario inputs are recorded.
  Identical inputs reproduce results; observations do not alter combat.

## Sequence

**Current source repair and simple policies, 2026-11-14 — verified gates:**
Authored electrical resistance150/250 is restored for1E1/3E5, fixing actual
fence pressure failure. All3379 methods,18 all-six fence controls and38 old
whole kit/policy controls pass under canonical fixed inputs. Nearest/lowest-HP
policies now use the same legal actions. [Evidence](results/fence-roster/README.md).
The original full30s mixed encounter completes with independent accounting,
A4/B1 alive. An exact-input field-query memo is promoted after prototype gates.
All3389 methods pass1403.140s with497 matching tested files. Complete broad
controls/position/policy/roster variations are running. The broader Goal is not
yet proven complete.
The nearest30s baseline/CLI reproduce the original output exactly; its complete
high control also passes (maximum2.57e-10 against1e-8). The staggered baseline
completes, making4/12 broad receipts. Intermediate-state/life HP audits pass the
original/high traces and32 previous kit traces. A small reproduction now proves
that invalidated pose predictions can still cut leases/advance the clock; fix
that shared mechanism and test the real slow support/recovery continuation.
The policy-description/provenance candidate stays isolated. Keep full scopes,
preserve earlier results and resolve manager scheduling without duplicate jobs.

**Current six-kit delivery audit, 2026-11-14 — verified:**
[All32 creative abilities and6 additional basics](KIT_INTERACTIONS.md) have
actual current-rule delivery/trigger witnesses across32 complete controlled
encounters, with wholeCLI/hash and numerical/order controls. All engine/tests
and mechanical values remain identical to the3344-method checkpoint;3 stale
descriptive fields are corrected. Remaining work is simple target-policy
replacement, reproducible5v5 variations and targeted failures in broader
interactions. Advanced NPC/mass/balance work stays deferred. [Evidence](results/current-kit-audit/README.md).

**Prescribed angular/linked climbing, 2026-11-14 — verified:**
[Climb control](CLIMBING.md) now composes turns and compatible linked routes;
actual redirection retires control before future motion, retaining momentum and
paid effects. Shared gravity reaction/stationary-normal corrections prevent
artificial floor launches. All3344 methods pass in1280.173s,17 complete
capture controls and59 prior controls pass; reviewed output changes are explicit.
[Evidence](results/linked-climb/README.md). Next audit the current cross-kit
matrix and stale descriptive metadata, then reproducible5v5 with simple policies.
Taut planner cost is an explicit concern for broad scenarios. Advanced NPCs,
mass experiments and balancing remain deferred; the overall Goal is incomplete.

**Active-link turns, 2026-11-13 — verified:**
[Reference-space linked turns](ANGULAR_LINKS.md) preserve world offsets,
fixed/moving distance certificates and real impact response. The real hook
control also corrected missing native stationary-face resolution in recovery
clearance. All 3320 methods, 24 focused checks, unchanged review checks, twelve
complete frozen captures/controls and 47 prior captures pass. Next complete
prescribed angular/linked climbing, then the current cross-kit matrix and
reproducible 5v5. [Evidence](results/angular-links/README.md). Advanced NPC,
mass experiments and balancing automation remain deferred.

**Current angular support integration, 2026-11-13:** [support/contact paths](ANGULAR_SUPPORT.md)
now compose finite/raised/body witnesses against candidate saved references.
Relative collision bounds cancel co-falling motion, and outgoing footprint
revalidation prevents false vertical grazes. All 3300 methods, twelve complete
capture controls and 35 prior captures pass; [evidence](results/angular-support/README.md)
is sealed separately. Next migrate active link/contact response and
prescribed angular/linked climb, then final cross-kit/5v5. No new abilities.

**Current angular field integration, 2026-11-13:** [field membership/cover](TURNING_FIELDS.md)
now consumes live saved yaw paths for heat, cooldown areas, gas and electrical
fences. Preserve the existing exposure/work/life writers and independent released
fields. Angular support and active-link response, prescribed linked climbing and
the final cross-kit/5v5 evidence remain. All 3262 methods, seven ordinary
captures/controls and 28 prior captures pass; [evidence](results/turning-fields/README.md)
is sealed separately. Advanced NPC/mass/balancing work stays deferred.

**Current owned-contact turn extension, 2026-11-13:** [angular attachments](TURNING_CONTACTS.md)
now support the existing charge-grab and falling-foot volumes through live
owner/target turns and fractional pose derivatives. Preserve creation snapshots,
one-time commit and independent released objects. Fields are extended above.
Support is extended above. Next remove active-link guards through actual consumers; no new
character ability or separate movement writer is needed.

**Current native turn increment, 2026-11-13:** [owned common turns](NATIVE_TURNING.md)
now use the shared action/translation/contact/projectile/life timeline. Finish
active linked response and prescribed climbing before removing their remaining guards or
claiming arbitrary six-kit turns. Owned attacks and fields are extended above. The
constraint reference planner is already quadratic; do not add a redundant
reference integration backend. Then complete prescribed linked climb and the
final current interaction/5v5 checks. Advanced NPC and mass balancing stay deferred.

**Current angular prerequisite, 2026-11-13:**
[Continuous yaw query paths](ANGULAR_PATHS.md) now supply rotating/resizing local
parts, point velocities/accelerations, conservative swept bounds and actual
box/curved-projectile contacts. This extends the preceding fixed material/actor
orientation work. Native timed turns still need owned action control, common
saved references (including dense constrained paths), support/contact response
and live-versus-released attachment handling. Preserve one translation writer.
The query backend alone does not establish a turn or alter existing casts.
Finite-floor departure is already integrated; prescribed linked climbing and
the complete current interaction/5v5 checks follow the turning work.

**Earlier shared increment, 2026-11-02:** [persistent distance limits](PERSISTENT_DISTANCES.md)
now integrate the [certified planner](DISTANCE_PATHS.md) into saved world paths.
Actual slack crossings, tangential curvature, independent knots, separate ground/
inertial drivers, joint contacts/grapples and individual force expiry compose
with existing abilities and landing/life handlers. Engineering attachment
captures and an analytic refinement case make the current boundary inspectable.
[Evidence](results/persistent-distances/README.md). The later
[actual chain cast](CHAIN_CAST.md) now adds source phases, damage-free contact,
moving flight range and common binding/Break attachment.

The subsequent [1E1 ground chain](GROUND_CHAIN.md) adds constant terrain
endpoints and the actual 10 m/15 s ground binding. The author's requested
[2000-HP walls](DESTRUCTIBLE_WALLS.md) now supply tagged destructible terrain,
direct/area damage and shared removal in preparation for the later charge.
Actual climb/anchor/beam destruction composes with support loss and falling.

The preceding [saved polynomial body paths](BODY_PATHS.md)
now give the common prediction queries and body advancement one immutable
reference prefix. Existing free/grapple/climb motion, separate pose deformation,
same-time driver changes, life and frozen historical inputs are verified through
real interactions. [Evidence](results/body-paths/README.md).

The preceding [joint tether/contact projection](TETHERS.md)
now solves instantaneous radial limits alongside grapple equalities and body/
terrain directions through atomic spatial APIs. Exact certificates, an
independent exhaustive oracle and real firing/holding/movement probes verify
this prerequisite. It is not a persistent tether or a chain cast.

The preceding [shared binding/Break and actual 1E3 ability 1](BINDINGS.md)
now supply source marking contacts, refreshed pools and independent upper-body
freezes. Break uses the primary maximum-HP threshold, paused 20/s filling and
separate escape work at the dyspnea cap. Real hold/cast cancellation, movement,
shield/Block interception and life boundaries use the shared world. Primary
1E3 stats and common movement are imported. [Evidence](results/binding-marks/README.md).

The preceding [actual 3E5 conditional ability 1](CONDITIONAL_MELEE.md)
now supplies its normal b/c cycle and upward counter through pinned action
data, documented motion causes, after-Active cooldown debt and shared ballistic
group flight. Real dash/knock/hold/Block/ceiling/pause cases and cancellation/
life controls verify the boundaries. [Evidence](results/conditional-melee/README.md).

The preceding [actual 3E5 heavy punch](KNOCK_DELIVERY.md)
now delivers physical melee contact, finite additive knocks and temporary 100%
elasticity, using summed-stat grapple resistance and individual defenses.
Released impulses keep separate clocks/lives through contacts, release and death.
[Evidence](results/knock-delivery/README.md).

The preceding [existing 1E5/2E4 dashes](BODY_LAUNCHES.md)
now execute through reusable body launches, real gravity/contacts and life-bound
landing obligations, with independent action requirements and existing payment/
cooldown handling. Actual hold/Break, gun/beam, running/sprint, climb and pause
field interactions use the common world. [Evidence](results/body-dashes/README.md).

The preceding [common grapple Break](GRAPPLE_BREAK.md)
now operates on actual 1E5 holds: validated life-bound controls, response window,
shared fixed filling, earliest continuous escape and per-link actual-gain
penalties. It reuses [owned holding](GRAPPLE_DELIVERY.md), persistent motion,
joint damage/resources and the safe [unpaid-action gate](ACTION_OWNERSHIP.md).
Phased penalties preserve a due Active start; owned clock parsing preserves an
exact response deadline. [Evidence](results/grapple-break/README.md).

The [new equilibrium rule](SOURCE_UPDATES_2026-11-02.md) now runs with shared
prone geometry, concurrent crouch, interruption/clearance, Get Up and actor
lives. [Decisions](EQUILIBRIUM.md) and [evidence](results/equilibrium/README.md)
include ordinary Block-counter falls and existing-kit interactions.
[1E3's ice bomb](IMPACT_BINDINGS.md) now delivers its lower-body freeze through
shared contact bursts and common Break, preserving real Block/terrain impact,
native motion and recipient lives. Its later [physical prison](PRISON.md) now
uses shared compound HP/expiry, actual contact and solid-aware hand reach.
Fifteen ordinary captures include material destruction, life/heat/climb and
paired-knock interactions. The subsequent [velocity-only validation correction](SPATIAL_TRANSITIONS.md)
lets the earlier heavy-knock/prison continuation finish after force expiry.
Selected [living-body support](BODY_SUPPORT.md) now lets the full 2200 ms crowded
continuation finish, with public API/CLI/hash and numerical controls. Final
regressions are recorded in [its evidence package](results/body-support/README.md).
Shared [committed contact receipts](CONTACT_EVENTS.md) now pin actual groups,
lives and wall identity before collision/fatigue can release a hold. The actual
[3E5 charge/grab/front holding](CHARGE_GRAPPLE.md) now reuses saved paths,
owned contact volumes, motor bonuses, existing holding/Break and conditional
wall material. Its source omissions have documented delegated values, and
committed victim slams retain pre-contact power/source through cancellation.
Shared impact-time group snapshots also preserve the author's summed-stat knock
rule when that very hit exhausts control. The subsequent
[1E2 Aim integration](AIMING.md) now adds owned toggling and deterministic
released projectile cones. [Confirmed curved entry](CURVED_CONTACTS.md) handles
ordinary prison/ice contact inside the existing time budget; current complete
API/CLI/hash and numerical witnesses are sealed. The subsequent
[1E2 ability4 implementation](1E2_ABILITY4_AUDIT.md) adds reusable
[body-part output selection](BODY_PART_DAMAGE.md) on actual physical contact,
source firing/recoil/cost/cooldown and headshot behavior. Complete verification
is recorded in PROGRESS.md. The subsequent [grappling gun](GRAPPLING_GUN.md)
uses explicit world/surface targets, actual hook contact, separate paid launch
and shared finite rope/native contact obligations. A real destructive beam
verifies control release at the anchor's end. Final regression/reproducibility
status is in PROGRESS.md. The [authored body scales](CHARACTER_GEOMETRY.md) now
feed per-actor shared geometry, pose, hands/reach and contacts. Their integration
also corrects motor residuals and certified near-tangent constraint response;
current verification is in results/body-scales. The [basic9 Dodge](DODGING.md)
now uses physical downward evasion, independent stock, shared owned posture and
source-life handling. The beam interaction also bounds geometry forecasts by
the valid path/phase interval. The source audit for 1E2's five-part fence now
adds [continuous electrocution and released-rate support](ELECTROCUTION.md) to
the joint shield/HP timeline, including material lifetimes and damage credit.
The same increment fixes declared-precision ownership and mixed-precision
queue clocks exposed by actual revival. The [actual five-part fence](ELECTROCUTION_FENCE.md)
now uses shared materials, continuous body contact, binding/Break and released
rates; current full regression/reproduction status is in PROGRESS.md. A real
walking/Break case fixes contact-side root selection, and feature dependencies
are validated on selection rather than disabling unrelated world modes.
The [existing 1E2 Ultimate](IMPACT_AREAS.md) now delivers actual gravity/impact
area damage and reusable [timed Gathering](TIMED_GATHERING.md). Independent
recipient-life instances, maximum committed preparation and once-only
quantization preserve phase/lifetime consistency; verification is in PROGRESS.md.
The [actual 1E3 Ultimate](PROJECTILE_DUPLICATION.md) now uses continuous radial
entry, atomic symmetric projectile branches and independent field lineage.
Native payload/HP/marking/terrain/life interactions are verified in PROGRESS.md.
The [existing portal pair](PORTALS.md) now uses atomic voluntary transport,
prospective support, linked/tether preflight and shared per-life reuse work.
The [existing 1E1/3 and 3E5/3 leaps](LEAPS.md) now use shared fixed-speed
launch/landing, actual constrained descent and controlled foot contacts. Current
verification is in PROGRESS.md. [The actual 1E1 launcher](LAUNCHER.md) now
uses per-actor inventory, owned swap/firing, frozen released variants and the
[poison-volume foundation](POISON_VOLUMES.md). Actual casts, copies, source lives,
empty return, terrain, Block and earned revival are verified in PROGRESS.md.
[Static-face raised-support departure](SUPPORT_DEPARTURE.md) is now verified using shared support loss/paths/gravity. Next implement general
facing/turning, then outer-floor departure and a compact cross-kit interaction matrix
before reproducible 5v5. Each roster creative ability now has shared delivery;
documented boundaries still prevent claiming arbitrary encounter support.
Preserve each source's anchor, range and life
policy; neither a distance limit nor a physical prison is a rigid grapple or
an intangible substitute.
Knock resistance alone does not supply a trajectory;
retain the author's summed-stat grapple rule. 3E5 charge/wall slam,
elasticity, binding and portal/environmental attachment rules retain their
identities and own requirements. Keep remaining support/turning guards until those
paths work. This milestone does not complete steps 4–6 or the six kits.

1. **Common action lifecycle — implemented.** Keep timing, payment,
   interruption and death on the shared combat queue, including current Get Up.
   Maintain the documented decision process and factual six-character inventory.
2. **Movement with combat state — implemented foundation.** Replace mutually exclusive movement/combat
   advancement with one coordinator for the earliest phase, contact, resource,
   status and damage boundary. First support grounded straight-line movement;
   integrate existing directional contact responses and movement costs/statuses.
3. **A moving gun encounter — implemented.** Use the existing 1E2 gun against moving bodies.
   Track projectiles in flight, update contacts after motion changes, and apply
   distance falloff to actual traveled distance. Integrate gravity and aiming
   through the same trajectory interface. Test a real moving hit and miss.
4. **Shared spatial interactions — integrated within documented boundaries.**
   Jump, crouch, sprint, climb, prone/Get Up, native turns, field entry/exit,
   static/living support/departure and active links share the combat writer.
   Final cross-kit coverage still needs current evidence; heat/shield recovery
   stays on that coordinator.
5. **Six existing kits — delivery present, final interaction audit pending.**
   Map every current source ability to actual delivery, ownership/lifetime,
   defenses, lives, terrain and movement interactions. Close real gaps using
   the shared mechanics. Metadata and historical tests alone do not prove it.
6. **Policies and 5v5 experiments.** Add deterministic targeting/movement policies,
   scenario batches and comparisons. Tune runtime only after measuring actual
   workloads. Report support boundaries with each experiment.

Steps can be split into smaller tested increments. A formula helper or metadata
entry does not count as an integrated feature. Avoid a second general engine or
a separate bespoke runner for each new mechanic; extend the shared lifecycle.

## Decisions and verification

Record the source rule, delegated choice, rationale, tests and remaining scope
in the mechanic's document. Keep primary ODTs intact; explicit documented
decisions supersede source wording only for the stated behavior. Historical
snapshots remain historical. Update current docs instead of accumulating new
questions that no longer require author input.

Each increment needs focused mechanics/interaction checks and the relevant
existing regressions. Integrated milestones need deterministic replay and
observation-schedule checks. Prefer small scenario/result artifacts; do not
duplicate the entire project for every minor change.

## Session budget and handoff

Author addition, 2026-10-25: efficiency includes avoiding degraded work when
usage runs low. Use bounded sessions ending at a verified checkpoint. Reserve
capacity for tests, review, documentation and handoff before starting the next
large change. When usage availability is unknown, use conservative task size;
do not assume unlimited quota or report an unobserved remaining allowance.

At each checkpoint, PROGRESS.md should state what works, tests/results, known
limits, delegated decisions and the next concrete task. An unfinished overall
goal remains unfinished; a completed increment is not completion of the engine.

## Foundation history and remaining gaps

The common Get Up lifecycle began in stationary combat; current equilibrium
rules add shared prone geometry, clearance and paid recovery. A grounded
combat mode integrates walking/running/stopping, U-dependent velocity, gun
flights against moving bodies, directional contacts, statuses, resources and
death on one advancing clock. A five-second moving gun duel and a lateral
miss are reproducible. The historical geometry-only mode remains distinct.

Gravity and compensated short-arc gun aiming now run through persistent flights,
with moving body/terrain contacts and actual traveled-distance falloff. Sprint
adds hand Recovery, continuous dyspnea, weapon-action exclusion, exhaustion and
collision/stop interactions. Basic jump now joins the same coordinator with
takeoff, retained horizontal velocity, landing, costs/statuses and airborne
projectile contacts. Flight persists after the controlled jump Active ends.

Crouch/stand and climb now share the coordinator, including changing cuboids,
hand/projectile transforms, costs/statuses, clearance, actual obstruction,
path interruption, raised support, crouched/raised jumping and death.
At that correction checkpoint, **1446 tests passed**, plus both reviews' five
unchanged tests each. The follow-up
review's phase/contact ordering, registered climb prerequisites and beam assertion
are corrected; imposed-displacement interruption is verified. A narrow shared
upright-reference/contact-dependency interface precedes later linked motion.
[Correction evidence](results/principal-review-corrections-2026-10-29/README.md).
Nine ordinary effort
encounters reproduce complete API/CLI traces, including the current-rule
30-second 2v2. Prior applied-HP traces and saved-window queries still reproduce.
Eight prior pause-area encounters, seven coupled
heat/recovery encounters, two recovery
encounters, three analytic rate plans and six earlier heat-volume
encounters match complete API/CLI traces, including hash-seed controls. Four world-collider
encounters match the API and complete CLI; prior projectile, ownership and climb
cases replay exactly with their explicit inputs.
Historical artifacts retain their original evidence;
known corrected snapshot/format/diagnostic differences are classified in the
[review response](PRINCIPAL_ENGINEERING_REVIEW_RESPONSE.md).

The principal review justified five correctness fixes before further kit work:
one iterative command dispatcher with blocked-parent outcomes, immutable world
physics independent of script contents, separate ground drive/physical flight,
and value state snapshots. Those fixes are verified. [ENGINE_STATUS.md](ENGINE_STATUS.md)
is the current index; dated sections elsewhere retain their historical scope.

Current gun/reload and body actions now use declared hand/weapon/locomotion
ownership, atomic admission, per-action deferred payments and selective
restriction/cancellation. Gunfire and reload overlap eligible body actions;
pre-applied upper/lower-body restrictions and live API tests validate the
existing 1E3 requirement foundation without claiming its ability delivery.
Independent released effects remain outside controlled locks. See
[ACTION_OWNERSHIP.md](ACTION_OWNERSHIP.md) for delegated rules and boundaries.

Physical flights now have independent IDs, source/parent/root attribution,
lifecycle revisions, explicit contact policies and safe whole-owner birth
immunity. The shared copy API retains momentum, distance falloff and independent
stopping/removal without spending an action twice. Ordinary combat plus labelled
engineering probes verify this foundation; actual field entry/splitting and
owner-contact follow-up attacks are not yet ability integrations. See
[PROJECTILE_ENTITIES.md](PROJECTILE_ENTITIES.md).

Fixed world-collider identity/lifecycle is also integrated: compound parts with
one HP pool, independent blocking channels, expiry/refresh, topology revisions,
contact rescans and actual support loss. Ordinary gunfire destroys a barrier
before later shots pass; a six-part hollow shell blocks fire in both directions.
These are scene geometry demonstrations, not completed prison/charge casts.
See [WORLD_COLLIDERS.md](WORLD_COLLIDERS.md).

The first A3 increment is integrated: typed bleed/heat instances, independent
beam volumes, moving entry/exit/re-entry, layer/residual clocks and heat destroying
cover mid-exposure. Existing 1E1 ability 4 casts alongside body movement; source
death cannot remove its volume. Frozen stationary evidence remains reproducible.
See [SPATIAL_EFFECTS.md](SPATIAL_EFFECTS.md) and [evidence](results/spatial-heat/REPORT.md).

Immutable [recovery-flow plans](RECOVERY_FLOW.md) now drive both ordinary
regeneration and [continuous heat/shield coupling](HEAT_SHIELD_COUPLING.md): net
stock, zero-stock absorption, incident/body memory and delayed recycled losses.
[Cooldown work and 1E2 pause-area delivery](COOLDOWN_PAUSES.md) now execute with
composable sources, moving membership and independent physical/effect clocks.
The [applied HP ledger](DAMAGE_LEDGER.md) now supplies conserved attribution,
proportional overkill and rolling analytic/dense histories. The author's
[effort categories](ABILITY_EFFORT.md) now drive intrinsic Qard release power
and sustained gun interruption while preserving independent beam/mark effects.
Moving Qard shares the existing physics and damage coordinator.
[Life/event generations and restoration](LIFE_CYCLES.md) now preserve actor-wide
credit, bind controlled/recipient work to each life and reconcile resources,
cooldowns and body support. Three ordinary API/CLI captures and an explicit
restoration API probe verify the foundation without claiming a 2E4 cast.
[2E4 thrust, attached venom and replacement-blade phases](MELEE_VENOM.md) now
execute on that coordinator with real contact, independent wounds/items, owned
grabbing and live shield/toxin defenses. Four ordinary public API/CLI captures
verify the family, including gun interaction, walking away and continuous death.
[Actual 2E4 revival](REVIVAL.md) now uses a death-generation-bound attempt,
damage snapshot, finite charges and background cooldown to call the shared life
transition. Ordinary gun/beam/pause-area and body-obstruction encounters verify
delivery. [Consumed healing allowance and continuous passive healing](HEALING.md)
now execute with preserved source/life attribution, actual gross HP receipts,
nonlinear histories and net HP/death boundaries. Five ordinary encounters verify
the family, including two healers through capped revival. Shared
[Block/charges](BLOCKING.md) and [actual counter reactions](COMBAT_REACTIONS.md)
now execute on those foundations. [Timed/next-attack modifiers](ATTACK_MODIFIERS.md)
now deliver current 2E4 enhancements with per-packet defense bypass. Shared
[component melee](COMPONENT_MELEE.md) also executes 1E5's actual alternation,
passive and Ultimate. [Atomic spatial state](SPATIAL_TRANSITIONS.md) and
instantaneous whole-graph projection now execute in the common world.
[Persistent coupled motion](LINKED_MOTION.md) now serves actual
[1E5 grab/drag delivery](GRAPPLE_DELIVERY.md), including phase ownership,
holding effort and rate damage. [Actual common Break](GRAPPLE_BREAK.md) now
uses the same holds/lives, shared filling and continuous comparison; death and
restoration cannot transfer old control. Both existing 1E5/2E4 dashes now use
[shared body launches](BODY_LAUNCHES.md). Actual [heavy-punch knock/elasticity](KNOCK_DELIVERY.md)
now uses the same world, including the [conditional upward counter](CONDITIONAL_MELEE.md).
3E5's chain now executes on shared binding/Break and persistent distance paths.
Fixed-ground binding and charge/wall delivery now reuse those foundations.
Aim, duplication, portals, leaps and the actual 1E1 launcher now execute on
these shared foundations. Remaining interactions and support/turning guards
must be implemented and tested before claiming arbitrary six-kit encounters.
Remaining integration must retain and test phase-specific resource transfers
where current source abilities require them. Do not build extra-arm mechanics for the superseded 1E5 Ultimate. Reuse the shared coordinator rather than a second engine.

Prescribed angular/linked climbing is integrated and verified above.
Remaining interaction coverage, full six-kit validation and final 5v5 experiments
remain unfinished. NPC learning,
mass experiments and balancing automation remain deferred. This is a verified
engine increment, not completion of the broader goal.
