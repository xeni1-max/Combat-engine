# Applied HP-loss attribution

Verified in the shared engine, 2026-10-29. Current world definitions select
`damage_ledger.mode=applied_hp_v1`; frozen definitions retain their earlier trace
adapter. This supplies attribution/history for existing real damage, not automatic
healing or revival. [Evidence and verification](results/applied-hp-credit/REPORT.md).

**Lifecycle extension, 2026-10-29:** current inputs also use
[actor life generations](LIFE_CYCLES.md). Receipts/entries retain source and
recipient life; actor-wide rolling windows survive death/restoration. `amount`
accepts optional `source_life_generation` and `target_life_generation` filters;
saved histories validate agreement. Cross-life summaries report actual damage,
rather than initial minus restored HP. Real damage and restoration API probes
verify this. [Actual 2E4 revival](REVIVAL.md) now uses the death-time basis;
[passive healing and its consumed allowance](HEALING.md) now execute separately
from this immutable damage journal.

**Causal direct reactions, 2026-11-01:** automatic 2E4 counters use the same
point receipts with original actor/action/life identity and blunt damage kind.
Each causal wave commits before the next, without crediting absorbed shield,
armor or construct loss. Mutual 1-HP death credits exactly 1 HP to each released
source and funds real 1-HP revival; an original 80 HP wound funds 72 counter healing.
[Verified interactions](COMBAT_REACTIONS.md).

## Source and delegated decisions

`Details2.odt` p0 excludes shield damage from damage-based healing/revival.
`2E4.odt` p13/p36 specifies revival based on damage in the previous 10 s and
healing for 20% of damage dealt. `Details.odt` p3 caps healing at 90% of damage
taken in the previous 8 s. `1E5.odt` p13 requires source-specific bleeding.
Existing author clarifications require shared pre-hit defenses for simultaneous
hits and continuous damage independent of observations.

The source does not allocate simultaneous overkill or fully define eligible
damage/history boundaries. Under delegation, record actual actor HP removed,
after shield/defenses and the HP floor. Allocate simultaneous applied HP among
contributors proportionally to their nominal post-defense HP damage. Armor and
construct HP are separate resources and grant no character recovery credit.
Keep their existing damage/bleed formulas unchanged.

Record every attributed actor HP loss, including friendly/self damage. As an
explicit exploit-prevention decision, outgoing healing/revival credit counts
only damage to another team's actor; self/friendly damage remains real and is
auditable but cannot generate recovery entitlement. Recipient HP-loss windows
include all real HP losses. Snapshot eligibility when loss applies; later source
death does not erase released-effect attribution.

Use `(end-window,end]` for point losses. Continuous contributions integrate only
their intersection with that window. Initial HP deficits and shield/armor loss
do not become incoming HP damage. This provides a basis, not a payout or a
consumed healing allowance. [Life rules](LIFE_CYCLES.md) now define death
snapshots and preserve rolling actor history. [Revival](REVIVAL.md) now has its
explicit timing/charges/controller; [healing](HEALING.md) now consumes funding
and pays each eligible entitlement once.

## Immutable measures and integration

[DamageLedger](combat_sim/mechanics/damage_ledger.py) stores immutable
source/target/time losses grouped by receipts with their actual applied totals.
[AppliedDamage](combat_sim/applied_damage.py) records them at the current shared
coordinator's direct/continuous damage commits. It preserves actor, ability,
parent action, projectile/effect/volume and attack-component identities.
Damage, defenses, bleed delivery, contacts and death physics are unchanged.

Each direct receipt shares one actual HP budget. Allocation uses post-defense
nominal HP weights, with a deterministic residual correction. The relative
roundoff allowance is `10^(8-precision)` (1e-42 at precision 50), scaled by at
least 1 HP. A positive actual loss requires positive nominal damage; this budget
cannot create credit from an empty loss. Continuous curve/component agreement
is checked within max(1e-8 HP, nominal HP × 1e-12); actual HP is still the sole
amount allocated. These are numerical validation budgets, not gameplay bonuses.

Receipt writes validate before changing history. Duplicate attack identities
cannot be credited again merely by recomputing damage with different defenses.
Continuous receipt identity includes recipient and physical interval. Queries
and detached snapshots do not consume credit or mutate loss entries, and all
query arithmetic uses the ledger's stored Decimal precision. Queries cannot
forecast beyond observed time. New damage cannot be inserted into an already
observed past. Multiple receipts at the same authoritative time remain allowed.

Bleeding and affine heat retain analytic integrals. Coupled body heat retains
its actual immutable dense dose curve; do not spread interval totals uniformly
or reconstruct a nonlinear curve only from its endpoints. Normalize finite
roundoff/terminal clipping to the HP actually applied, preserving conservation.

For nonlinear heat, immutable piecewise curves copy the original plan's affine
segments or quartic cumulative-HP dense steps. Endpoint coefficients must agree
within Decimal roundoff. Later cooling, defenses, source death or cache
invalidation cannot alter a stored curve. Identical immutable shapes may share
one curve ID without combining sources. The journal caches only the current
thermal plan per target; history retains copied dose descriptions.

Public runs export `applied_hp_history` (precision, observation bound, receipts,
curves and entries) and `damage_credit_totals`. Per actor, totals distinguish
all applied outgoing HP from eligible outgoing HP, eligible damage in the last
10 s, and incoming HP in the last 8 s. The latter is a healing-cap basis, not
an available or consumed healing allowance. Summaries expose the same totals.
Saved JSON can be queried without live actors or simulation state:

```python
from combat_sim.mechanics.damage_ledger import DamageLedger

history = DamageLedger.from_record(run["applied_hp_history"])
credit = history.amount(actor="A", end=21037, window_ms=1000, eligible_only=True)
```

## Verified scope and next work

**1192 tests pass**, including 18 ledger/API and 15 shared-combat checks. Nine
ordinary API/CLI captures and saved-history queries reproduce; prior frozen
replays and all five original engineering-review checks still pass.

Primitive/API checks cover temporal boundaries, overkill, nonlinear prefixes,
eligibility, idempotence, invalid-write isolation, fixed precision and saved
history validation. Shared checks use actual gun/bleed/heat, lethal ties,
friendly/self damage, source/target death, construct damage, paused cooldowns
and nonlinear heat/shield recovery. Analytic bleed windows agree with an
independent formula from real deliveries. A nonlinear window also agrees with
independent shorter HP-prefix runs. [Results](results/applied-hp-credit/REPORT.md).

Numerical accuracy is inherited from the original analytic/dense curves and
their recorded controls. Tests support 1e-8 HP agreement for nonlinear
precision/observation controls; no certified global ODE or cross-platform bitwise
bound is claimed. History segmentation may differ with observations while
integrated windows retain their tested agreement. Fixed-input API/CLI traces
remain deterministic.

The ledger is not a heal payout, an automatically spendable damage bank, or a
life transition. Healing must consume each entitlement once and account for
already-spent healing allowance. Actor life/event generations and restoration
are now integrated, and [actual revival timing/charges/cooldown](REVIVAL.md)
executes. [Consumed healing allowance and continuous passive payout](HEALING.md)
are also integrated: gross actual HP loss remains distinct from recovered HP,
including intervals that remove more HP than existed at their start. Remaining source-only
abilities must still deliver their actual effects through the shared engine.
No complete six-kit/general 5v5 claim is made.
