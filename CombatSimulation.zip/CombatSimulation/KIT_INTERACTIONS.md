# Current six-kit delivery and interaction audit

2026-11-14. All 32 creative source abilities and six additional basic slots have
positive delivery/trigger witnesses on the current canonical shared rules.
Thirty-two complete encounters pass actual delivery contracts, HP/life/resource
accounting, precision80/17ms/reversed-order/ambient28 comparisons and complete
production CLI/hash4511 equality. Largest checked difference is about2.0316e-43
against1e-8. This is delivery evidence and selected interaction coverage, not
proof of every combination or completion of the 5v5 Goal.

[Evidence and limits](results/current-kit-audit/README.md) ·
[Machine-readable inventory](results/current-kit-audit/catalogue.json) ·
[Positive contracts](results/current-kit-audit/contracts.py).

| Character / source slot | Activation path | Actual delivery | Current witness |
|---|---|---|---|
| 1E1 / 1 | action_selection | projectile_delayed_area | [qard](results/current-kit-audit/recipes/qard.json) |
| 1E1 / 2 | action_selection | binding_projectile | [ground_chain](results/current-kit-audit/recipes/ground_chain.json) |
| 1E1 / 3 | action_selection | ballistic_leap | [leap_1e1](results/current-kit-audit/recipes/leap_1e1.json) |
| 1E1 / 4 | action_selection | heat_beam | [beam](results/current-kit-audit/recipes/beam.json) |
| 1E1 / Ultimate | action_selection | weapon_swap, poison_projectile | [launcher](results/current-kit-audit/recipes/launcher.json) |
| 1E2 / 1 | action_selection | slash_projectile | [gun_reload](results/current-kit-audit/recipes/gun_reload.json) |
| 1E2 / 2 | action_selection | cooldown_pause_area | [pause](results/current-kit-audit/recipes/pause.json) |
| 1E2 / 3 | action_selection | hook_projectile | [hook](results/current-kit-audit/recipes/hook.json) |
| 1E2 / 4 | action_selection | direct_projectile | [precision](results/current-kit-audit/recipes/precision.json) |
| 1E2 / 5 | action_selection | contact_field | [fence](results/current-kit-audit/recipes/fence.json) |
| 1E2 / Ultimate | action_selection | impact_area_projectile | [impact_device](results/current-kit-audit/recipes/impact_device.json) |
| 1E3 / 1 | action_selection | marking_projectile | [mark](results/current-kit-audit/recipes/mark.json) |
| 1E3 / 2 | action_selection | impact_binding_area | [ice](results/current-kit-audit/recipes/ice.json) |
| 1E3 / 3 | action_selection | portal_pair | [portals](results/current-kit-audit/recipes/portals.json) |
| 1E3 / 4 | action_selection | construct_projectile | [prison](results/current-kit-audit/recipes/prison.json) |
| 1E3 / Ultimate | action_selection | projectile_duplication_area | [duplication](results/current-kit-audit/recipes/duplication.json) |
| 1E5 / 1 | action_selection | component_melee | [arm_enhancement](results/current-kit-audit/recipes/arm_enhancement.json) |
| 1E5 / 2 | action_selection | grapple_grab | [ground_drag](results/current-kit-audit/recipes/ground_drag.json) |
| 1E5 / 3 | action_selection | ballistic_dash | [dash_1e5](results/current-kit-audit/recipes/dash_1e5.json) |
| 1E5 / 4 | passive | attack_modifier_passive | [arm_enhancement](results/current-kit-audit/recipes/arm_enhancement.json) |
| 1E5 / Ultimate | action_selection | attack_enhancement | [arm_enhancement](results/current-kit-audit/recipes/arm_enhancement.json) |
| 2E4 / 1 | action_selection | venomous_thrust | [venom_enhancements_heal](results/current-kit-audit/recipes/venom_enhancements_heal.json) |
| 2E4 / 2 | automatic trigger | block_counter | [block_counter](results/current-kit-audit/recipes/block_counter.json) |
| 2E4 / 3 | action_selection | ballistic_dash | [dash_2e4](results/current-kit-audit/recipes/dash_2e4.json) |
| 2E4 / 4 | action_selection | attack_enhancement | [venom_enhancements_heal](results/current-kit-audit/recipes/venom_enhancements_heal.json) |
| 2E4 / 5 | automatic trigger | death_revival | [revival](results/current-kit-audit/recipes/revival.json) |
| 2E4 / Ultimate | action_selection | attack_enhancement | [venom_enhancements_heal](results/current-kit-audit/recipes/venom_enhancements_heal.json) |
| 3E5 / 1 | action_selection | conditional_melee | [normal_punches](results/current-kit-audit/recipes/normal_punches.json), [upward_counter](results/current-kit-audit/corrected-recipes/upward_counter.json) |
| 3E5 / 2 | action_selection | binding_projectile | [moving_chain](results/current-kit-audit/recipes/moving_chain.json) |
| 3E5 / 3 | action_selection | ballistic_leap | [leap_kick](results/current-kit-audit/recipes/leap_kick.json) |
| 3E5 / 4 | action_selection | knock_melee | [heavy_punch](results/current-kit-audit/recipes/heavy_punch.json) |
| 3E5 / Ultimate | action_selection | charge_grab | [charge_walls](results/current-kit-audit/corrected-recipes/charge_walls.json) |
| 1E2 / basic_8 | control_script: aim_on/aim_off | aim_toggle | [aim](results/current-kit-audit/recipes/aim.json) |
| 1E2 / basic_9 | reload_when_empty | reload | [gun_reload](results/current-kit-audit/recipes/gun_reload.json) |
| 2E4 / basic_8 | action_selection | block | [block_counter](results/current-kit-audit/recipes/block_counter.json) |
| 2E4 / basic_9 | action_selection | dodge | [dodge](results/current-kit-audit/recipes/dodge.json) |
| 2E4 / basic_10 | passive | damage_fraction_heal | [venom_enhancements_heal](results/current-kit-audit/recipes/venom_enhancements_heal.json) |
| 3E5 / basic_8 | action_selection | block | [block_3e5](results/current-kit-audit/recipes/block_3e5.json) |

1E1 Ultimate resolves to an owned swap; ability1 then fires poison carriers.
1E2 Aim is an owned control command; reload follows empty firearm selection.
2E4 counter/revival are automatic and both healing/1E5 bleeding are passives.
The historical3E5/1b scalar is excluded from mobile selection; ability1 owns
the b/c cycle and conditional a. Six wrong-path constructor probes reject
explicitly. No new source ability or numerical value is introduced.

## Interactions actually witnessed

| Shared responsibility | Current positive evidence | Limit |
|---|---|---|
| Damage, defenses and accounting | All32 conserve HP across lives/healing; real gun shield overflow, both Block profiles and actual2E4 counter | Not all simultaneous multi-target/defense combinations |
| Enhancement and passive composition | Both1E5 arms, actual doubled post-armor wound basis, timed80 piercing;2E4 next20 armor loss,4000 bypass, venom and funded healing | Not every release/expiry/overkill boundary in this matrix |
| Independent releases and payloads | Qard delayed blast, heat, poison cloud, physical prison, actual duplicated damage/marks on both offset targets | Source-death/lineage variants have separate evidence |
| Bindings and material | Three marks consumed, ice lower binding, five fence panels/electrical contact, fixed and moving chains, two real charge wall fractures | Rotating platforms and arbitrary new environmental geometry remain outside scope |
| Common control and life | Aim, actual11-round exhaustion/reload, dip/return charges, two allied portal users, funded revival after real gun death | Nearest/lowest-HP policies are integrated; broad5v5 remains unfinished |
| Native movement and owned contact | Both dashes,1E1 leap/landing,3E5 descending kick, a real dash-triggered upward counter, grab/hold/continuous HP | Other phase/geometry pairings need targeted coverage |
| All-six pose/turn/support/constraints | [Previous verified integration](results/linked-climb/README.md), with identical runtime and mechanical data | Not universal temporal/energy/convergence or speed guarantees |

All six also share walk/run/sprint, special stopping, jump, crouch/stand, climb,
native turning, Break, Get Up and regenerative shields. Their actual implementation
and historical tests are distinguished in [ENGINE_STATUS](ENGINE_STATUS.md).

## Remaining work

[Nearest and lowest-current-HP targeting](TARGET_POLICIES.md) now share the
existing legal action path. Actual all-six-profile electrical contact, shield
exhaustion and overlapping beam delivery are verified after restoring the two
omitted authored resistance entries;18 complete controls and the fresh3379-method
gate are indexed in [the current repair](results/fence-roster/README.md).
Continue the interaction audit through the original full30s mixed encounter and
varied positions, rosters and policies, reporting outcomes/damage/resources with
an explanatory trace. Ability selection alone is insufficient evidence.
Advanced NPC planning, mass simulation and balance automation remain deferred.
Taut solver cost remains explicit; preserve the single reference writer.
