# Continuous electrocution and released rate effects

## Source-resistance import correction — 2026-11-14

The ordinary mixed5v5 exposed missing imported resistance entries for1E1 and
3E5, causing a KeyError when actual fence pressure reached their body/heat
solver. Both values are explicit author facts:1E1.odt paragraph index40
(zero-based text:p extraction) says150;3E5.odt index44 says250. These two entries
are restored in data/characters.json. There is no zero-resistance fallback or
change to the electrical formula, shield allocation or released lifetime.
[Source text, pre-fix ordinary failures and current verification](results/fence-roster/README.md).
The original source files and older frozen results remain unchanged.


Verified 2026-11-09: all 2658 tests pass in 860.075 s, including 40 new
methods. Eighteen labelled shared API/hash/numerical/context cases reproduce;
45 prior complete traces remain exact. [Evidence](results/electrocution-rate/README.md).
This is the shared damage foundation. The subsequent
[actual 1E2 fence](ELECTROCUTION_FENCE.md) now composes segmented materials,
continuous contact and common binding/Break with these same rate/life rules.
Its latest regression and reproduction status is recorded in PROGRESS.md.

`Damage types.odt` p56–60 and embedded `Object 9/content.xml` define
`de2 = (de² - Re²) / de`, where `de` is incoming damage per second and `Re`
is electrocution resistance. Armor does not appear in this formula. As with
other damage families, the implementation floors damage at zero and defines
zero incoming pressure as zero damage, avoiding division by zero. Those domain
extensions are delegated choices. Electrocution has no heat/venom memory,
bleeding or implicit armor reduction.

The existing joint continuous shield/HP solver now accepts this rate family.
Positive personal shield stock absorbs raw pressure. At zero stock, delayed
shield regeneration is allocated proportionally across concurrent pressure
sources before each source's body mitigation is evaluated. For example, an
800/s source against resistance 150 deals 771.875 HP/s without shielding;
400/s regeneration leaves 400/s overflow and 343.75 HP/s. Armor does not
change those rates. These layer rules reuse the delegated common flow model,
rather than treating a continuous rate as repeated point hits.

Released streams share the existing rate registry, immutable dose curves,
shield-loss history, HP death boundaries and damage/healing credit. The old
`controlled_damage` component name remains a compatibility seam. Controlled
constriction keeps its owned-action lifetime and live instability response.
Released electrocution snapshots raw pressure and source attribution, has no
caster effort, survives source action cancellation/death/restoration, and
retains the original source life. Recipient death ends the attachment; a later
recipient life needs a new delivery. Its live electrocution resistance is part
of cache compatibility. Expiry is half open and explicitly scheduled.

A released stream may name an existing material collider as its physical
support. Removal/destruction/expiry of that collider ends the stream on the
common timeline; unrelated colliders do not. Spatial callers must end a stream
on loss of contact, and deliver a new stream on later eligible contact. This
foundation does not infer a radius, attach a binding, or acquire a body action.
Current rules opt in with `released_rate_damage.mode=released_layers_v1`.
Frozen inputs without that mode retain their earlier results and reject the
new shared API rather than silently enabling it.

The actual death/revive interaction also exposed a shared numerical contract
defect. Direct/subclass engine use could run at the caller's Decimal precision
while saved body paths used the declared run precision. A fractional revival
clock then lay just beyond its rounded lease, repeatedly selecting a zero-length
step. The engine's `run()` now owns its declared Decimal context, restores the
caller context on exit, and queue insertion normalizes timestamps to that same
precision. This changes neither the declared precision nor geometry/HP error
tolerances, and adds no time nudge, deadline coalescing or fake progress step.
Complete traces are checked across caller precisions 28, 50 and 80, and an
explicitly overprecise future timestamp has a separate regression.

## Fence source audit and next delivery

`1E2.odt` p13 supplies a six-second electrocution fence, 800 damage/s,
movement prevention and a nine-second cooldown. Its detailed section p175–186
supplies Gathering 140 ms, Active 160 ms, binding value 2, and a 20 m × 1.5 m
fence composed of five independently destructible four-metre parts, each
requiring 1500 non-toxin/non-electrocution damage. The author's clarification
gives summoning no dyspnea cost. Under delegation, the detailed 20 m dimensions
take precedence over the older 15 m overview. None of those primary files is
edited. The subsequent [field delivery](ELECTROCUTION_FENCE.md) supplies actual
placement, contact, independent material lifetimes and common Break/binding.
The foundation checkpoint above remains its earlier verified scope.
