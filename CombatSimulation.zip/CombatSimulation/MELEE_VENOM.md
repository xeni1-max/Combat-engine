# Shared melee, attached venom and replacement blades

**Component extension, 2026-11-01:** [1E5's actual arm attacks](COMPONENT_MELEE.md)
reuse the same frame/contact controller, with fixed per-action components,
separate acting hands and shared release modifiers. 2E4's venom, consumed blade,
replacement summon and owned grab remain specific to its authored thrust.
The unchanged frozen melee encounters still reproduce their complete traces.

Implemented 2026-10-29 in the shared moving combat engine. The current input
opts into `melee: {"mode": "timed_melee_v1"}` alongside declared ownership,
phase effort, actor lives, typed effects and applied-HP history. Frozen inputs
without this mode retain their previous output. This is actual 2E4 ability-1
delivery; the earlier [controlled audit](2E4_ABILITY1_AUDIT.md) remains historical.

## Source rules

Root `2E4.odt` and recorded author clarifications specify:

- Slash thrust: damage 440, piercing 40, 140 ms Gathering, 180 ms Active,
  contact at Active midpoint. Target O/U are 110/110; self O/U are 150/150
  on impact. The new self instability does not reduce that same hit.
- Intrinsic momentary effort; Db=3. Armor and target-status mitigation use
  the shared pre-hit snapshot, including simultaneous attacks.
- The attached blade delivers toxicity 700 for one second, then detaches;
  residual toxin decays for the following second. Later armor changes cannot
  alter the existing wound's delivery ratio. Independent wounds add.
- Summon the next blade after impact; grab begins 600 ms after impact under
  unobstructed base conditions, takes 250 ms Active, then the next Gathering
  can start. The replacement follows its actor before grabbing.
- 2E4's shield provides one toxin resistance per 100 current shield HP.

Current zero-based ODT paragraph references are p50–71 for the thrust,
p74 for replacement, and p198–200 for shield toxin resistance. The earlier
audit's p72 replacement reference describes an older source paragraph layout.
The ODT itself is unchanged by this implementation.

## Delivery and phase order

The shared queue completes due controlled phases first. At the thrust midpoint
it captures immutable intrinsic output `max(0, 440-U/10)` from the phase batch's
instability snapshot, then queues an instantaneous melee contact in the common
incoming-hit batch. It creates no projectile, flight, gravity compensation or
traveled-distance falloff. Simultaneous gun/Qard/melee packets share the normal
shield allocation and pre-hit armor calculation.

Under delegated authority, the initial geometry is a 1 m capsule from the
ability's right-hand start position, with a 0.02 m radius. Aim locks the chosen
torso location at Active start. At impact it queries the actual current bodies
and body-blocking solids, including ground and living teammates, and uses the
first contact. Projectile-only barriers do not block this body/solid query.
Fixed facings and the shared six-cuboid body remain in use. These are reversible
geometry defaults, not additional author-supplied measurements or advanced NPC
tracking. Unsupported aim/blocking settings are rejected.

2E4 receives delegated neutral hand positions: left (-0.2,0.15,-0.1), right
(0.2,0.15,-0.1) in the existing local axes. Thrust and grab use the right hand
and ability-1 weapon resource. Identical start/end grip poses give zero initial
hand Recovery; the timed capsule is the current physical attack proxy.

Under delegation, check and pay thrust Db=3 at Active start. A cancelled
Gathering pays nothing; cancellation after payment or a subsequent miss does
not refund it. A real body/solid impact applies the authored self effects,
spends the blade and begins replacement summoning. A whiff keeps the blade and
does not apply on-impact self effects. Solid damage gives no character HP
credit and creates no organic toxin attachment. A fully shielded body contact
still spends the blade and starts replacement, with zero wound delivery.

## Wounds and continuous toxin

Let `d` be the slash remaining after the shared proportional shield allocation,
and `a` the armor before any simultaneous armor loss. Freeze delivery as
`slash_hp(d,a,p)/d`, with an explicit zero result when d=0. Slash also creates
its normal eight-second bleed from nominal post-armor slash HP damage.

For an attachment of T seconds, q grows from 0 to T, then falls from T to 0.
The rate is:

```text
delivery * max(0, (toxicity² - 10*max(0, live_toxin_resistance-p/5)²)/toxicity) * sqrt(q)
```

Armor/delivery stay frozen per wound. Toxin resistance remains live, including
2E4's current shield-stock bonus. Under delegation, already delivered toxin
and bleeding damage HP directly even if shield reforms around the body. This
preserves wound entry and avoids applying the shield twice. Recipient death
retires both effects for that life; caster death does not remove them.

An attachment records the struck cuboid and normalized contact point. Its
position follows that cuboid during body movement and posture changes. At
detachment or recipient death its final position is frozen. A later life
cannot inherit an old recipient attachment. Damage and replacement summons
retain the original source life for attribution.

Constant resistance uses the existing analytic affine-root dose. The shield
bonus uses a read-only view of the prepared analytic or coupled thermal shield
plan and adaptive dense integration (absolute/relative tolerances 1e-12,
maximum step 20 ms). This is continuous integration, not a damage tick. The
shared coordinator clips at effect/stock/HP boundaries; the same immutable dose
prefix supplies death search and saved rolling HP histories. Dense error
estimates are numerical tolerances, not certified mathematical bounds.

## Independent replacement and controlled grabbing

The spent blade and new blade have distinct item identities. The 600 ms
summoning delay is autonomous, follows the permanent actor, survives source
death and does not occupy a hand or pause with cooldown fields. After it is
available, automatic grabbing uses the ordinary action registry: right hand,
ability-1 weapon, upper-body function, hand Recovery and zero-base Gathering
extended by current/incoming disorientation, then 250 ms Active. There is no
separately authored grab cost, so its delegated cost is explicitly none.

The grab can overlap permitted body actions and constant sprint; sprint still
blocks a new thrust. Restrictions on the upper body cancel the owned grab,
leave the available item intact and allow a fresh attempt after eligibility
returns. Lower-body restrictions do not cancel it. Death invalidates the old
grab phase; restoration may start a new generation-bound grab for the existing
item. It never resumes the old controlled event.

With no interference: first impact 230 ms, blade available/grab 830 ms,
equipped/next Gathering 1080 ms, next impact 1310 ms. Disorientation, hand use,
death and restrictions may legitimately delay this cadence.

## Shared basics and remaining scope

2E4 now uses the common movement/pose/contact implementation with authored
base running speed 8 m/s, upward jump speed 4 m/s, sprint speed 14 m/s, jump
G100/A150 and Db1.2, crouch A150 and Db0.8, walk/run Db0.5 and O/U80/80,
climb G150/A300 and Db2.5, sprint transition Db0.5 and continuous Dd2.
Its basic source self/landing effects are imported in the corresponding data.
Missing timings use explicit delegated shared defaults: walking 2 m/s,
walk/run transition 150 ms, sprint transition 200 ms, stopping 30 ms per m/s,
and existing shared posture/climb geometry. Hand poses are neutral defaults.

[Shared-engine tests](tests/test_melee_venom_combat.py) cover real movement,
misses, interception, shields, simultaneous defense snapshots, gunfire,
restrictions, life transitions, item/attachment motion, continuous lethal
crossings, precision/observations, cooldown areas and live toxin resistance
under ordinary and coupled thermal shield recovery. Property/restoration
injections and altered defensive profiles are labelled engineering probes.
The [ordinary API/CLI captures](results/melee-venom/README.md) use unchanged
character definitions and no injected events or encounter subclasses.

2E4's [actual death-triggered revival](REVIVAL.md) now uses this same world's
HP history and independent effects. [Passive healing](HEALING.md) now uses the
same actual losses and continuous effects. Block-triggered attack, dash,
owner-contact projectile and ultimate remain unimplemented. General melee arcs,
shield/block volumes, limb damage, linked
motion, turning and the other unfinished kits remain separate work. The next
increment is shared Block interception/HP/status layers and rechargeable
charges, before block-triggered attacks. Other kits remain unfinished.
