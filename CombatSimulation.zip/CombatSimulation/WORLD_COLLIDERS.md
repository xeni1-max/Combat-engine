# Fixed world collider lifecycle

Static support witnesses, 2026-11-10: [Static support and departure](SUPPORT_DEPARTURE.md) share body-face contact geometry for actual current boxes and prospective placements. Alternate live collider parts can retain support after another is left or removed; actual loss uses the common flight transition. No moving-platform or outer-floor departure capability is implied.

**1E2 segmented fence, 2026-11-09:** [ability5](ELECTROCUTION_FENCE.md) creates
five separate 1500-HP panels, each with its own collider identity and expiry.
They intercept projectiles, permit body passage, and remain area-transparent.
Electrical movement prevention belongs to contact/binding, rather than solid
impulses. Gaps and removal are immediately visible to the shared contact world.
Per-object optional damage immunities now cover toxin/electrocution for these
panels. Typed damage validates before mutation; direct batches filter each
incoming family before summing HP loss. Other accepted damage families retain
their normal material HP path. Empty immunity metadata is omitted from older
records. Heat still damages each eligible panel, and material damage grants
no character healing/revival credit. Existing collider policies are unchanged.

**2026-11-02 prison delivery:** [1E3 ability4](PRISON.md) now creates a hollow
six-face 4000-HP/12s shared object on actual body contact. Source life/action is
pinned through released flight; formed material outlives caster/occupant lives.
Solid hand reach prevents origins beyond thin cover. Existing movement, heat,
destruction and expiry use this registry. Longer crowded dynamic-support and
force-expiry continuations failed in that checkpoint; [velocity validation](SPATIAL_TRANSITIONS.md)
fixes the latter. [Living-body support](BODY_SUPPORT.md) now also completes the
full2200ms crowded continuation on the common path solver. Historical failed
diagnostics remain in [the prison evidence](results/prison-cast/README.md).

**2026-11-02 wall addition:** the selectable
[wall arena](data/terrain/destructible_arena.json) adds three tagged cuboid
panels, each with the author's 2000-HP pool. Blunt, slash, Qard, heat,
constriction and tear share that pool. Existing direct/heat deliveries use the
same lifecycle; typed object damage prepares the remaining deliveries.
[Rules, layout and verification scope](DESTRUCTIBLE_WALLS.md).

**2026-11-01 integration:** support loss now routes through
[the shared spatial transition](SPATIAL_TRANSITIONS.md), preserving the current
pose and horizontal motion, selecting alternate support or gravity, and
invalidating controlled climb work. The ordinary expiring-platform encounter
and unchanged collider/life/revival replays check this migration. Continuous
moving terrain platforms and grounded ledge departure remain guarded; current
living-body support uses the later shared contact witnesses.

Implementation dated **2026-10-28**; current verification is recorded in
[ENGINE_STATUS.md](ENGINE_STATUS.md). This extends the shared moving engine
with compound, damageable and expiring objects. It does not add character
abilities in that original checkpoint; 1E3's later prison delivery is indexed
above. 3E5's charge remains unfinished.

## Sources and delegated choices

`1E3.odt` p9 specifies a prison cube with 4000 HP, damage blocking in both
directions, and 12 s lifetime. `3E5.odt` p17 describes qualifying charge collisions
destroying walls. Original terrain confirmations keep the existing three cubes
fixed in place, with ordinary blast/beam damage ignoring their cover. The
author delegates detailed engineering/design choices and permits battlefield
changes. Sources remain unchanged.

The following are **delegated implementation decisions**, not additional author
confirmations: compound cuboid parts, explicit blocking channels, zero inherent
armor/resistances for collider HP, nonpiercing simultaneous-hit absorption,
expiry ties, creation/reshape rejection on body penetration, support-loss
response and exclusion of construct damage from character recovery credit.
These choices preserve the unusual prison and wall-destruction requirements
without turning a hollow prison into a solid box intersecting its prisoner.

## Identity, geometry and policy

[ColliderRegistry](combat_sim/world_colliders.py) owns immutable ID, source,
owner/ability/action attribution, optional canonical tags and creation time. A fixed object has one or
more named cuboid parts, one optional HP pool, optional expiry, a climbable flag
and three independent blocking booleans: `projectiles`, `bodies`, `areas`.
Several walls/roof/floor may therefore form one hollow object with shared HP.
Parts can overlap at corners without multiplying one projectile's damage.
The permanent ground retains its existing zero-thickness rectangle; deployed
objects use positive cuboids. There is no continuous platform-motion model.

Existing terrain IDs remain stable. New objects may use explicit scenario IDs
or allocated `collider:N` IDs; IDs cannot collide with actors or be reused after
removal. Original cubes default to indestructible, body/projectile blocking and
area-transparent. Explicit removal remains available for a future qualifying
wall-destruction ability; indestructible HP does not make every cube permanent.
Ground cannot be removed, damaged or reshaped in this scope.
This preserves ordinary scenarios while allowing explicit deployed objects.

Current moving inputs declare `world_colliders.mode=fixed_compound_v2` in
[combat locomotion data](data/movement/combat_locomotion.json), with immutable
`integrated_v2` body physics. Scenario `scope` selects the base engine route;
current world rules resolve the reported result `scope` to compound objects
and per-collider cover. `configuration.scope` preserves the declared input for
replay. Additional scene geometry uses `initial_colliders`:

```json
{
  "id": "barrier",
  "source": "scenario_geometry",
  "parts": [{"part": "panel", "centre_m": [10, -20, 1.5], "size_m": [0.2, 4, 3]}],
  "hp": 500,
  "duration_ms": null,
  "climbable": false,
  "blocking": {"projectiles": true, "bodies": true, "areas": false}
}
```

`null` HP is indestructible; `null` duration has no automatic expiry. A duration
is remaining lifetime from creation, not a wall-clock timestamp. A climbable
object currently requires one solid cuboid, matching the approved climb path.
Compound shells are not silently assigned an undefined climb destination.

The shared composition API is `encounter.collider_system`: `spawn`/
`spawn_definition`, `damage`, `remove`, `reshape` and `set_expiry`. Raw API
expiry is absolute simulation time. Creation/reshaping cannot positively
penetrate a living body; exact touching is allowed. The prison cast must
construct its walls around the body with clearance. Geometry changes are
explicit world boundaries, not animated or continuously moving obstacles.
An optional `tags` list is accepted on terrain and initial deployed objects;
tags are immutable semantic identity, not additional collision policy.

## Lifetime, damage and contact ordering

Objects maintain separate state, collision and expiry revisions. Nonlethal HP
damage updates state while retaining valid geometric contact confirmations.
Geometry, blocking or removal changes collision revision; refreshed lifetime
changes expiry revision. Old expiry events cannot remove a replacement clock,
and a terminal ID cannot be resurrected by a later refresh. Expiry is half-open:
at its exact time the object cannot receive a hit or become climb support.

Existing straight/gravity projectiles query the common active projectile view.
A contact carries collider ID and collision revision. Expiry, destruction or a
policy/geometry change invalidates its prediction, including numerical contact
evidence waiting for a rounded event time. Remaining flights continue on their
original paths and can hit later objects/bodies; no trajectory is restarted.
Creation around an existing flight resolves initial overlap at the creation
boundary. A zero-duration rescan inserts new contacts before later decisions.
Body prediction batches carry a world collision epoch and are likewise rescanned.

All supported incoming projectiles in one event batch hit the pre-batch object.
Their actual-path falloff is retained, raw direct damage is summed against its
single HP pool, and applied loss floors at zero. **All those projectiles stop**;
overkill is not transmitted through the newly destroyed wall. Later independent
shots can pass through the opening. No biological bleeding/status, armor loss
or shield regeneration is invented for construct HP. Logs distinguish incoming,
applied, excess and source packets. Construct damage grants no character healing
or revival credit, preventing damage-farming; the attributed ledger remains A3.

Version 2 also includes live damageable objects in instantaneous area queries:
the existing Qard delayed blast hits each overlapping HP pool once across its
parts, respects other objects' area cover, and shares simultaneous HP clipping
with direct hits. Destroyed/expired objects are excluded when the blast occurs.
Logs distinguish character and collider recipients. Frozen `fixed_compound_v1`
retains its former character-only delayed-blast recipients; earlier complete
captures remain reproducible without rewriting their inputs or evidence.

Expiry/removal at a declared projectile-contact timestamp precedes its incoming
batch. That contact is discarded and the still-live flight is rescanned. This
uses the engine's existing quantized event-time semantics; it does not claim
exact continuous physical ordering below the projectile event quantum.

## Bodies, climbing and support

Bodies, posture clearance and projectiles share one registry but filter their
own channel. A projectile-only wall can be walked through; a body-only wall
stops a character while letting shots through. Stale contacts are rejected
before posture/climb interruption, avoiding fictitious collision penalties.

Complete results expose initial/final collider state and source-attributed
damage/lifecycle events. Summaries include deployed or changed objects' final
HP, status, expiry and policy, without counting construct HP loss as character
damage. The old `projectile_terrain_collision`/`terrain_contacts` names include
fixed deployed colliders; their entity record distinguishes terrain from casts.

Climb selection, Active and completion recheck target availability. Removal
during Gathering releases the unpaid action; removal/reshape during Active
interrupts the path and preserves physical momentum and paid costs/statuses.
An object expiring exactly at completion cannot acquire standing support,
independent of event insertion order.

Removing/reshaping support first checks for another valid support. Otherwise
the character retains horizontal velocity and falls under existing gravity,
without a paid basic jump or fabricated takeoff/landing self effects. Actual
landing still applies ordinary physical-contact penalties. Eligible independent
weapon actions continue. Deployed objects remain independent of owner death.

Compound landing records the contacted object/part and support reference, so
an unrelated first part's height cannot snap the body upward. The integrated
airborne validator now owns support checks; the older geometry-only validator
must not treat falling bodies as standing. This also permits an actual jump
to leave a raised platform and land below. Current [living-body support](BODY_SUPPORT.md)
uses life/part witnesses in the shared path solver, retaining gravity, native
landing, pose withdrawal and support loss. Older inputs keep their explicit
dynamic-support guard. Current [static-face rules](SUPPORT_DEPARTURE.md) handle
ordinary raised-ledge departure; ground-edge departure remains guarded.

## Area cover and current limits

`areas=true` blocks representative line-of-effect queries in both directions.
A sphere uses the closest point on each overlapping body part; a downward
column uses its top-facing witness and a ray from above all scene geometry.
The character receives the attack once if any eligible part has a clear ray.
Positive material penetration blocks; tangency or an outward ray starting on
the same face does not. These deterministic witness rules are an explicit
cover model, not a claim of exact partial visibility or penumbra geometry.

Ordinary cubes remain area-transparent as confirmed by the author. Hollow
shell tests block inward, outward and downward queries, then reopen on removal.
Current typed heat volumes damage collider HP continuously and update body
membership when cover changes or burns away. Each object receives heat once
across its parts, excluding its own geometry from its cover query. Loss on a
continuous interval ending exactly at expiry applies before the expiry; point
hits at that instant remain ineligible. [SPATIAL_EFFECTS.md](SPATIAL_EFFECTS.md)
records these delegated extensions and verification. Current impact areas,
prison/fence materials and actual grenade poison are also delivered. The
instantaneous grenade O/U pulse uses explicit world cover; its separate gas
volume remains unoccluded. Frozen raw-heat scopes retain their earlier limits.

Mutable objects require the current integrated world definition. Historical
fixed-layout/geometry scopes retain their original restrictions and presentation;
their static terrain still uses the registry internally. New metadata is omitted
from frozen traces rather than changing simulation identity or rewriting evidence.

The subsequent [actual prison delivery](PRISON.md) now uses this registry.
Current fence, impact device, duplication, portal and poison delivery reuse
these shared foundations. No extra owner-contact character ability is invented.
General rotating geometry and full cross-kit/5v5 validation remain unfinished.

**Collider checkpoint verification:** 1022 tests passed, including 42 new collider checks. Four ordinary
encounters match complete API and public CLI traces; prior captures and the
review's five checks remain verified. [Results and commands](results/world-colliders/REPORT.md).
The subsequent heat checkpoint passes **1066 tests**, with six further ordinary
API/CLI scenes and two additional registry expiry-boundary checks.
[Current evidence](results/spatial-heat/REPORT.md).

The subsequent [heat/shield coupling](HEAT_SHIELD_COUPLING.md) now supports
ongoing heat and regeneration in the current world, including zero-stock flow
and warm body memory. That checkpoint passed **1129 tests**; prior collider traces still replay.
[Coupling evidence and remaining scope](results/heat-shield-coupling/REPORT.md).

[Pause clocks](COOLDOWN_PAUSES.md) and [applied actor HP history](DAMAGE_LEDGER.md)
are now integrated too. Construct damage remains separately inspectable and
grants no actor healing/revival credit. The [current index](ENGINE_STATUS.md)
tracks later verification and remaining life/recovery work.
