# Turning with active grapples and distance limits

2026-11-13. Delegated engineering integration, preserving the existing abilities,
reference metrics and action ownership. Verified evidence and the remaining
work are in [results/angular-links](results/angular-links/README.md).

## Reference motion and heading

Grapple components retain one common translation from independent weighted
inputs. A turn changes that character's heading and real body geometry. It
does not rotate the recorded world-space reference offset, steer a frozen
charge drive, add angular momentum to the reference, or detach the hold.
The author's summed maximum-HP/current-armor knock resistance remains intact.
Each participant keeps its own mitigation, effort, controlled work and life.

Moving and fixed distance endpoints remain upright actor references or constant
terrain points. Heading does not change their length metric. Existing slack
crossings, exact Bernstein certificates, per-force response and expiry stay on
the saved quadratic reference writer. Angular paths compose against its pieces;
no second translation integrator or invented hand attachment is introduced.

## Resting planes and actual impacts

A horizontal reference-only resting plane assumes a fixed body shape. While
either contacting body turns, that plane is suspended. Native continuous body
queries still see the real obstacle and actual moving body parts. Their actual
impact ends the involved turn and applies the existing angular point-velocity
status calculation and reference-velocity response. The contact wave retains
the suspended-plane policy through turn cancellation and its shared response
snapshot, then invalidates the saved frame before restoring fixed-plane use.
Static vertical reactions remain eligible while their real footprint touches;
living vertical contacts retain BodySupport's separate part/life witnesses.

Cached contact tokens are historical eligibility, not permanent constraints.
Even a slack lease is clipped when its actual angular contact departs. Otherwise
a short turn could open and close a gap inside one lease and resurrect a stale
plane before a later real impact. A normal supplied only by a rotating face
cannot remain a fixed world plane; it is retired. Normals still supplied by a
nonrotating face use full upright SAT/contact-band bounds. Vertical normals use
the existing positive-area underside/top rule. Confirmed departure consumes the
absolute owned-precision clock; it never extrapolates the saved path.

Phase ownership stays explicit: saved-path construction compiles reference
constraints and clips contact/support departures through pure candidate queries.
Prediction and advancement consume that same prefix. Contact revalidation saves
actual feature velocities before heading cancellation. The common contact wave
then snapshots reference motion, applies individual response and transmits the
blocked components. Its finalizer restores plane eligibility and invalidates
the next frame. No angular helper writes a second reference position.

This preserves first-impact incoming motion, normal contact penalties and
blocked movement transmitted to rigid partners. It does not invent penalties
for a partner that never contacts material, turn a distance tether into a rigid
grapple, or drop live constraints to make a solver feasible.

## Evidence and remaining scope

Actual 1E5 holding, 3E5 charge/wall slam and heavy group knock, 3E5 moving chain,
1E1 fixed chain and 1E2 grappling-gun launch are exercised separately from
explicit engineering attachments and imposed-velocity probes. Geometry checks
cover ceiling footprint loss and co-moving/gravitating contact bands. Full
capture controls check HP accounting, link/force identities and lifetimes,
real contact events and saved distance certificates.

The complete hook control exposed a shared recovery defect: roundoff at a
stationary touching wall blocked Get Up at precision 50 but allowed it at 80,
changing paid dyspnea and the final pose. Recovery/stand clearance now supplies
the existing native stationary-face resolution to its continuous sweep. This
changes no contact tolerance or ability cost. Actual inward obstruction remains
blocking, and the hook case now agrees and completes its paid recovery.

The active distance/grapple turn guard is removed through these consumers.
The subsequent [climbing integration](CLIMBING.md) admits compatible linked
routes and retires genuinely redirected controls before consuming their path;
its current verification is in [results/linked-climb](results/linked-climb/README.md).
Final cross-kit coverage and reproducible 5v5 experiments remain unfinished;
advanced NPCs, mass experiments and balancing automation stay deferred. No
character data or creative ability changes are made by these increments.
