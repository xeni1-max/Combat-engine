# Response to the November 10 principal engineering review

2026-11-10. R1, R2 and R3 are implemented and verified. The cover-contract note
is resolved as an explicit behavior-preserving delegated rule. The broader
six-character/5v5 objective remains incomplete.

| Finding | Correction and evidence |
|---|---|
| R1: raised-support departure | Static/body support now share positive-area underside witnesses. Saved paths schedule actual departure, alternate supports are checked, and common support loss preserves velocity, motor/forces and native group/tether/landing rules. All six body scales, ordinary walk/run, midair gunfire, actual heavy knock and owned grab/drag pass. A torso also lands on a narrow post with lower legs beside it. [Mechanics](SUPPORT_DEPARTURE.md). |
| R2: constructor context | Validation and complete initialization use a fresh declared-precision/ROUND_HALF_EVEN context. Direct callers, subclass load hooks and the public runner share the same entry point. Caller context is restored on success/failure. Seven permanent tests and 18 complete direct/subclass/public trace comparisons pass; CLI/hash output matches. |
| R3: stale capabilities | Current ENGINE_STATUS table and roster/roadmap boundaries now include the delivered launcher, portals, leaps and falling kick. Dated earlier checkpoints remain historical. All creative abilities have shared delivery within documented limits; broad encounters are not claimed complete. |
| Grenade cover contract | Explicit world area occlusion applies to the once-only O/U pulse. The independent gas remains unoccluded. Covered/uncovered real collision tests verify different pulse recipients and the same chemical damage. [Contract](LAUNCHER.md). |

All four unchanged November 10 review specifications and all seven November 3
regressions pass. The complete **2976-method suite passes in 886.083 s** in
four isolated processes, exact disjoint once-only coverage and no skips/errors/
failures. All 448 tested files remain unchanged across that run. The 33 new
methods pass in 76.193 s; 75 existing affected methods pass in 8.845 s.

Fifteen complete current cases pass API/CLI or API-subprocess hash controls and
combined precision 80, 17 ms observations, reversed participants and caller
precision 28. Five are ordinary casts, nine use explicitly labelled engineering
initial conditions with real movement/casts, and one supplies a labelled tether
API attachment. The torso/post probe separately passes two precision controls.
Largest checked difference is 2.9582283945787942997783248974514272444658047334E-30, below 1e-8. Eight selected complete
frozen-input older traces remain exact. No old result or primary ODT is replaced.

The initial draft exposed and corrected a real rational-root/Decimal lease-clock
mismatch. Preserved logs also distinguish fixture mistakes: expecting exact
root values instead of enclosures, observing an acceleration after it returned
past the opposite edge, a striker facing away, and a hold observed after its
3210 ms expiry. The source writer and physical semantics were retained. The
current full suite and interaction captures validate the corrected result.

Outer-floor departure, general facing/turning and prescribed linked climbing
remain explicit boundaries. The older optional periodic stack-dump exit 139
remains unresolved; no fix claim is made for it. No broad coordinator rewrite,
new character ability, advanced NPC or balance automation was added.

[Evidence and reproduction](results/principal-fixes-2026-11-10/README.md) ·
[Original review](PRINCIPAL_ENGINEERING_REVIEW_2026-11-10.md).
