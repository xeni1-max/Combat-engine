# 1E3 Ultimate: projectile duplication

Author rules (`1E3.odt` paragraph 11, current revision; paragraphs 119–123):
mark a radius-12-m area for 25 seconds. Entering allied projectiles duplicate
and shift 4 m apart. Cooldown 65 seconds, Active 300 ms, extrinsic momentary
activation. The author's 2026-10-28 clarification specifies no dyspnea value.
The old 8 m / 3 m values are historical, not current rules.

Delegated choices (2026-11-09):

- Use the existing marked-area convention: a fixed vertical cylinder with
  unlimited height, no physical material or area occlusion. Freeze its centre
  when selected, using the enemy's current position or an explicit world/
  surface target. Use zero unlisted base Gathering and self O/U, neutral left
  hand, selection-start cooldown, and deployment at Active end. Common current
  disorientation/Gathering modifiers and physical hand Recovery still apply.
- Projectile sphere overlap with the cylinder is eligibility; its radius
  expands the horizontal disk. A projectile born inside, or already inside
  when the field deploys, encounters it immediately. Caster and allied shots
  qualify; enemy shots do not. Allegiance belongs to the field's deployment
  team. Source death does not remove the released field or projectiles.
- Split symmetrically: original shifts 2 m left, new child 2 m right, relative
  to horizontal flight direction. The horizontal perpendicular is also
  perpendicular to full velocity. Pure vertical flight uses world x as the
  separation axis. Both retain instantaneous velocity, gravity/deceleration,
  traveled path length, original source life/action/ability, released power,
  accuracy sample and utility payload. No reaim, new recoil, resource payment,
  ammunition use or cooldown occurs. Damage/healing credit remains the
  projectile source's, rather than the field owner's.
- The shift is instantaneous, adds no falloff distance, and does not sweep
  lateral intervening material. Each endpoint then uses actual ordinary
  collision. A shifted shot born inside a body or wall can hit it immediately.
  There is no invented clearance relocation, safe endpoint or reaim.
- Each projectile branch remembers the field identities in its ancestry.
  One field cannot repeatedly duplicate that branch or its descendants;
  separate independently deployed fields can each split it. No global
  one-field/one-effect lock is added. The existing released copy API's lineage
  contract supplies this guard.
- Due phases/expiry and physical projectile impacts resolve before field
  entry at the same clock. An impact consumes the carrier, preventing a split.
  Splits resolve before decisions. Endpoint impacts are queued at that same
  clock and invalidate other entry predictions through projectile revisions.
  An actually stopped projectile cannot duplicate, including the gap before a
  rounded stop receipt; an undecelerated ballistic apex remains eligible.

`projectile_volume_entry.py` supplies numerical continuous radial entry using
acceleration-bounded chord enclosures and actual inside witnesses. It can find
an entry/exit between queried endpoints. Like existing gravity contacts, these
are bounds on numerical binary64 paths, not a proof of exact ODE integration
error. Unresolved near tangency fails explicitly. The field controller solves
each fixed-volume/immutable-flight pair once over their common lifetime, so
observation clocks cannot alter root subdivision. Gravity events use current
physics rounding; straight-field events use a 0.000001 ms quantum. Expiry at
the same rounded clock excludes entry. No gameplay time nudge is used.

`SharedProjectiles` shares branch preparation between the existing copy API and
the new atomic symmetric split. Both trajectories are built before mutation.
The original's revised segment begins at the split clock with accumulated path
distance retained; `birth_kinematics` preserves its initial segment for
inspection. Entity/source identities and immutable released power remain
unchanged. Original owner arming is retained; children use the existing copy
birth-clearance policy. Cached predictions include projectile revisions.

[Verification](results/projectile-duplication/README.md) covers the complete
2774-method suite, 20 ordinary cases, six labelled API probes and 113 exact
previous traces. The ordinary `scenarios/1e3_duplication.json` selects the
actual field and marking attack. The overall six-character Goal remains active
and incomplete; the existing portal pair is the next kit delivery.
