# Grab, holding, damage and escape

This extends the verified [linked-motion foundation](LINKED_MOTION.md) toward
actual 1E5 ability 2. Contact, holding, damage and effort now execute in the
shared engine, including common Break/controller response. Current
verification is in [PROGRESS.md](PROGRESS.md) and
[the reproducible encounters](results/authored-grapple/README.md). Primary ODTs are
unchanged. Decisions below are delegated unless identified as source rules.

## Source profile

1E5 ability 2: 100 ms Gathering, 180 ms grab Active, impact at its midpoint;
target O/U150 and self O/U80 at actual impact (the prior author timing
clarification supersedes the source's “on swing”). The grab holds/drags for
3 s and deals 900/s constriction/tear, with 9 s cooldown and listed dyspnea 2.
`Damage types.odt` Object 11 gives
`max(0, dps - 25*armor^2/(4*dps))`; zero input gives zero output.
Armor loss is optional in that damage family and not specified for this drag,
so it must not be invented for this ability. Source instability reduces live
intrinsic sustained output by U/4 per second, before shields/target armor.

## Selected delivery/ownership model

- Reuse the existing hand-capsule contact controller and its first living
  body/solid interception. The initial grab deals no HP/armor damage, but its
  contact/status event still shares pre-hit defense snapshots. A forward Block
  surface intercepts the grab. A personal regenerative shield remains a damage
  layer for the sustained effect; no general shield bypass is added.
- Use the left hand's existing neutral pose, 1 m reach and 2 cm capsule as a
  delegated initial proxy. The right hand remains independently usable where
  pinned component/weapon requirements permit. Do not impose a global lock.
- Preserve the complete 180 ms grab Active. A separate owned holding action
  begins at contact, initially relying on the grab's left-hand ownership and
  requiring that hand/upper-body function. At grab Active end, hand/weapon
  ownership transfers atomically to the holding action. If the hold ends early,
  the original grab still retains its hand until its authored Active finishes.
  Paid phases must remain paid; no hand gap or cost deletion is allowed.
- Hold duration starts at successful contact. The 9 s cooldown starts at grab
  Active start, including misses/interception; death before that start pays no
  cost. Use Db2 at grab Active start and delegated Dd2 during holding. The latter
  makes continued physical holding consume effort; the source does not fully
  anchor its single listed effort value across these two phases.
- Stage attachments after the whole same-time impact batch. Neither a dead
  controller nor a dead recipient can acquire a new hold. Control/action/life
  identities remain distinct from the initial contact frame and later damage.
- A source/target life end, hold expiry, explicit release, function restriction,
  successful Break or controller fatigue ends the controlled hold, its stream
  and effort channels. Already released independent work retains its own rules.
  Initial 1E5 ground-drag entry requires actual supporting footing and excludes
  free flight. The 2026-11-13 delegated correction removes a phase-only rejection
  of supported climb preparation; an already unsupported climber remains
  ineligible, preserving the source ground-drag identity. 3E5 charge-grab already
  permits airborne recipients. Later
  external knock forces still move a held group together under the author rule.

## Shared continuous layers

Extend the existing `RateShape` with nonnegative affine terms; retain old root
records when no affine term exists. Extend its recorded integrals, signed-rate
boundaries and delayed recovery translation so reabsorbed work stays analytic.
Use the existing reflected shield/HP solver for both heat and rate damage.

While shield stock is positive, incoming constriction pressure damages it at
raw DPS. At zero stock, available recovery is divided between simultaneous
sources in proportion to pressure. Apply the constriction formula to each
source's remaining raw DPS, with current target armor. Heat retains its
separate incident/body memory and cooling. Mixed nonlinear HP/allocation uses
the existing conditional dense solver and saved dose curves, not damage ticks.
Recipients' applied HP, healing funding, revival, old-life retirement and
rolling histories must all consume those same curves.

`ControlledDamage` supplies owned streams from actual successful grabs to that layer
solver. Its live source U clock caps affine epochs at real output knots; tiny
clock roundoff uses the existing 1e-24 ms temporal resolution. Current root
rules enable `controlled_layers_v1`, `shared_budget_v1` and `owned_grapple_v1`.
The analytical affine extension preserves both increasing/decreasing zero
crossings, including delayed recovery of an increasing ramp whose value clock
lies later than its integration interval. Reference clocks are values, not
activation timestamps; loss intervals own activation/lifetime boundaries.

## Shared effort and Break

Use one resource writer for concurrent effort: sum `(Dd_i+D/100)^2` for all
sustained inputs, plus explicit fixed filling such as Break's 20/s. Do not let
sprint and holding/Break overwrite one another's D, square the sum of bases,
or turn the specific 20/s filling rule into Dd20. Preserve exact source cases;
mixed cases use one owned conditional dense trajectory and once-only prefixes.
Cap total actual gains at 100, allocate actual gains to sources, stop filling a
full bar and emit the maximum trigger once. Reanchor solo sprint when compound
effort ends. Reservations still recheck point costs at their actual payment
phase; continuous effort never silently pays or refunds an unrelated action.

Common [Break/controller response](GRAPPLE_BREAK.md) now executes on actual
holds. Immediate input uses no separate point cost. A failed comparison opens
the configured half-open response window (default 150 ms); a timely same-hold
response starts fixed 20/s for both participants. The comparison remains live
while pending/filling. Repeating an input cannot extend the window or add rates.

A is both participants' actual capped fixed filling on that link, excluding
holding/sprint and point costs. Every answered-contest ending retains incoming
O/U base 3A for its living matching pair; unrelated graph members are excluded.
Penalties apply after due phases/hits/contacts with individual current defenses,
without a running self multiplier. Source, delegated choices, numeric resolution
and legal controls are detailed in [GRAPPLE_BREAK.md](GRAPPLE_BREAK.md).

## Verification and remaining boundary

Actual action-selection tests and ten complete API/CLI encounters cover hit/
miss, first ally/solid, Block, moving targets, simultaneous lethal hits and
defense/status snapshots. The full grab tail, atomic handoff, independent
right-arm/body/enhancement actions, once-only payment/cooldown, live sustained
output, shield depletion/recovery, real heat and multiple holds, clipped HP,
healing/revival, source/recipient life and teardown are checked. Three hash-seed
controls and six combined precision/observation/participant-order controls pass.
Engineering force/sequence/restriction presets are labelled; they do not claim
authored knock or extra character abilities.

`world.grapple_casts.release(controller, link_id)` ends only that controller's
live hold and its owned damage/effort; repeated/wrong-controller calls do nothing.
It is a controller API, not a newly invented selectable ability. Normal expiry,
fatigue, death and function restriction use the same cleanup. A grab whose hold
ends early retains its original hand until the authored Active finishes.

[Actual common Break evidence](results/grapple-break/README.md) now checks
immediate/pending/answered/unanswered/late outcomes, overlapping contests,
shared caps/sprint, actual-gain penalties, death/revival and safe independent
payment rejection. A real expiry/thrust tie exposed premature Gathering
extension; penalties now follow due phases. An exact rational deadline exposed
caller-precision leakage; script/window clocks now use owned precision and the
same declared clock resolution. Neither fix rewrites old effects or inputs.

Later increments add actual dashes, heavy/upward knocks, bindings, living-body
support, prone/Get Up and [3E5 charge/holding/wall slams](CHARGE_GRAPPLE.md).
The latter reuses this owned holding/Break/damage coordinator. Current knock
timing pins pre-hit groups before the same attack can exhaust control.
Static ledges, portals and native turning are integrated by later increments.
Prescribed linked climbing is verified in [the current work](results/linked-climb/README.md).
Consult [the current index](ENGINE_STATUS.md) for the remaining cross-kit/5v5
work; the overall Goal is incomplete. Earlier evidence retains its historical scope.
