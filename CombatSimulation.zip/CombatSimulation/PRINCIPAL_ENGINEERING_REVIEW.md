**Independent principal engineering review — 2026-10-28**

The shared engine has useful foundations, but it is not yet a reliable base for extending the remaining kits. Five defects are reproducible in currently supported scenarios: an unbounded event loop, future commands changing earlier physics, an unintended speed increase, mixed-command crashes, and a mutable initial-state record. Fix these before treating the current climb work as a verified integration checkpoint. Then remove the specific architectural restrictions below as the existing abilities require them; a wholesale rewrite is unnecessary.

This review changes no implementation, character data, existing scenarios, or existing tests. Recommendations are reviewer proposals under the author's existing delegation, **not new author-specified mechanics**. The review excludes advanced NPC systems, balance optimization, and large experiment batches.

**Evidence and scope**

I inspected the shared coordinator, its action/movement/projectile/effect integrations, geometry and numerical helpers, relevant tests, root mechanics documents, PROGRESS.md, DESIGN_PREFERENCES.md, ROADMAP.md and ROSTER.md. I also extracted the root ODT paragraphs for the existing character features discussed below. The unfinished climb integration was included, while retaining its documented provisional status.

The existing suite passed: **896 tests in 31.297 seconds**. This exceeds the last documented completed 874-test checkpoint; it does not establish that climb or the broader engine is complete. The review's additional five regression specifications fail on the reviewed implementation, including their parameterized cases. They are deliberately outside `tests/`.

```sh
python3 -B -m unittest discover -s tests -v
python3 -B results/principal-review-2026-10-28/reproduce.py
```

The second command should fail until the findings are corrected. It uses original character/rule data, ordinary scenario inputs, and the public runner/CLI. F1 alone subclasses the encounter to stop and report a repeating event cycle after 80 events at one timestamp; it does not alter simulation transitions. Evidence is in [baseline-tests.txt](results/principal-review-2026-10-28/baseline-tests.txt), [review-regressions.txt](results/principal-review-2026-10-28/review-regressions.txt), and [reproduce.py](results/principal-review-2026-10-28/reproduce.py). [source_hashes.json](results/principal-review-2026-10-28/source_hashes.json) identifies the inspected implementation, tests, data and scenario files; this directory has no Git metadata.

P1 means a supported encounter can fail to finish, crash, violate causality, or produce materially incorrect combat behavior. P2 means an inspectability defect or a structural restriction to resolve before integrating the affected ability. No P0 finding is established.

| ID | Priority | Classification | Consequence |
|---|---|---|---|
| F1 | P1 | Reproduced defect | A blocked compound movement command loops forever at one timestamp. |
| F2 | P1 | Reproduced defect | A jump scheduled in the future changes earlier body collision results. |
| F3 | P1 | Reproduced defect / exploit | Airborne self-instability becomes additional permanent running pace on landing. |
| F4 | P1 | Reproduced defect | A no-op movement command followed by another action family raises `KeyError`. |
| F5 | P2 | Reproduced defect | Reported initial hand positions are overwritten by subsequent actions. |
| A1 | P2, prerequisite for affected kits | Verified structural limitation | One controlled-action slot and distributed dispatch cannot express selective restrictions and ownership cleanly. |
| A2 | P2, prerequisite for affected kits | Verified structural limitation | Projectile identity, owner exclusion and static world objects conflict with existing authored abilities. |
| A3 | P2, prerequisite for affected kits | Verified structural limitation | Effects, cooldowns and death lack the lifecycles needed for moving areas, pause fields and revival. |

**F1 — A blocked run request never yields simulation time**

Evidence: [compound movement dispatch](/home/erzen/Projects/CombatSimulation/combat_sim/mobile_combat.py:202) and [contact cancellation/rescheduling](/home/erzen/Projects/CombatSimulation/combat_sim/mobile_combat.py:423).

Reproduction: start A at `(0, 0)`, request `run` at 0 ms, then request `run` again at 1500 ms; horizon 2000 ms, normal arena. The first run stops against cube_1 at x=4.95. At 1500 ms, stand-to-run begins its walk prerequisite while retaining the parent `run` intent. The acceleration points into the touching wall, so contact occurs immediately, cancels the walk and requests another decision at the same time. The unchanged parent intent starts walking again. The diagnostic guard captures repeated `movement_active_started`, `body_contact`, `movement_active_cancelled` and `target_status_applied` events, all at 1500 ms, with zero contact speed. No time or resource boundary can break this cycle.

Correction: represent a compound intent and its prerequisite progress explicitly. When a prerequisite is physically blocked, reject/finish that intent or park it until a relevant contact/occupancy change. Use a contact/state revision to prevent retries against unchanged constraints. Do not add an arbitrary tiny time delay: that would turn the loop into repeated status/resource processing and make timing artificial. A bounded same-timestamp progress assertion is useful as a diagnostic backstop, not the gameplay fix.

Acceptance: the reproduction reaches 2000 ms, records one blocked outcome, and has no repeated zero-speed penalties. Cover direct run and sprint, a pending parent intent after contact, and retry after a moving blocker leaves. Existing contact directions and perpendicular motion must remain intact.

**F2 — Future script contents select the physics of the past**

Evidence: [CLI conditional physics loading](/home/erzen/Projects/CombatSimulation/combat_sim/cli.py:52), [support constraint](/home/erzen/Projects/CombatSimulation/combat_sim/airborne_combat.py:198), and [air contact response](/home/erzen/Projects/CombatSimulation/combat_sim/airborne_combat.py:215).

Reproduction through the actual CLI: A starts at `(0, -20)` with movement direction `(1, 0.2)` and runs at 0 ms; B starts at `(4, -19.5)` and crouches at 0 ms. In a 1600 ms encounter, add only a B jump command at 1500 ms. Compare A at 1000 ms, before that extra command:

| Scenario | A y-position at 1000 ms | A y-velocity |
|---|---:|---:|
| No future jump | -19.1668227129223 m | 0.51440297741163 m/s |
| Jump at 1500 ms | -19.2600000000000 m | 0 m/s |

Both runs contact at approximately 695.361631 ms. The CLI scans the entire script and enables body flight/support rules only if any jump or climb exists. Those rules also govern ordinary collision projection. This is a causality/configuration defect, not random execution or a rounding difference. Selecting different physics explicitly can be legitimate for historical scenarios; silently selecting them from future commands is not.

Correction: resolve an explicit, immutable world ruleset before execution. Current integrated combat must consistently enable body support/gravity even when no actor chooses to jump. Keep jump-action eligibility/cost data separate from world physics. Preserve historical behavior through an explicit historical version or compatibility adapter, rather than command inspection.

Acceptance: identical input prefixes have identical state/event prefixes within the declared numerical tolerance, regardless of commands appended later. Compare CLI and Python API behavior, including ordinary collisions between different postures and incidental lift.

**F3 — Firing during a jump creates an unintended speed bonus**

Evidence: [landing speed reconstruction](/home/erzen/Projects/CombatSimulation/combat_sim/airborne_combat.py:241); the intended rule is recorded in [JUMPING.md](/home/erzen/Projects/CombatSimulation/JUMPING.md:97) and [MOVING_COMBAT.md](/home/erzen/Projects/CombatSimulation/MOVING_COMBAT.md:68).

Reproduction: A runs at 0 ms, requests jump at 300 ms, and begins gun selection at 900 ms. The shot releases at 1025 ms. Landing occurs at approximately 1072.395514781 ms with horizontal velocity 6.4 m/s. Because firing left instability active during flight, landing computes `nominal_speed = physical_horizontal_speed + current_instability / 200`, producing **6.87302242609582 m/s**. At 1450 ms the actual ground speed is already **6.82870265367764 m/s**, above the authored 6.4 m/s running pace. The no-shot control retains 6.4. The defect persists at 50/80-digit precision and with no, 37 ms, and 113 ms observations.

That reconstruction is appropriate only when physical speed has already had the ground instability penalty subtracted. Airborne velocity explicitly has not. The temporary debuff therefore becomes additional nominal propulsion, retained after the debuff expires and potentially carried into subsequent jumps.

Correction: separate requested ground pace from physical velocity and any externally imparted motion. Landing must not derive a new commanded pace by adding airborne instability. Preserve the documented ground pace, apply the selected landing transition, and then apply current ground penalties consistently. Do not impose a universal speed cap: authored dashes, launches, knockback and climbs need distinct physical motion rules.

Acceptance: the reproduction never gains running pace from firing or incoming airborne instability. Cover accumulated statuses, repeated jumps, walking jumps, landing during a weapon phase, and interrupted climb momentum. Existing midair momentum preservation must continue to pass.

**F4 — Consuming a no-op bypasses dispatch for the next action family**

Evidence: [the base intent loop](/home/erzen/Projects/CombatSimulation/combat_sim/mobile_combat.py:202), especially the three-action lookup at line 209 and local `continue` at line 213.

Reproduction: queue `stop` and then `jump` for standing A at 0 ms. Both commands are accepted, but execution raises `KeyError: 'jump'`. Replacing jump with crouch or sprint raises the corresponding error. `stop` followed by walk succeeds, and stand followed by jump succeeds, so validity depends on which implementation consumed the preceding no-op.

The subclass chain chooses an action handler only once. After the ground handler removes `stop`, it continues inside its own walk/run/stop loop instead of returning the next head of the queue to the full dispatcher.

Correction: use one iterative dispatcher that selects a handler for every queue-head change. Have each handler return a small explicit outcome such as consumed, started, rejected or waiting. Avoid recursive redispatch as the general solution; a long list of no-ops should not exhaust the call stack. Include target-bearing climb intents in the same command representation.

Acceptance: all three packaged cases execute their second action. Add mixed no-op prefixes before jump/posture/sprint/climb, including multiple commands at one timestamp, and verify costs and effects occur exactly once. Fix this alongside F1, while keeping their distinct regressions.

**F5 — The initial-state snapshot aliases mutable hand state**

Evidence: [Combatant.record](/home/erzen/Projects/CombatSimulation/combat_sim/battle_models.py:88) returns `hands_m=self.hands`; [SharedEncounter initialization](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:105) retains that object in `self.initial`.

Reproduction: ordinary gunfire starting at 0 ms, horizon 200 ms. The profile and initial curve show left hand `[-0.2, 0.15, -0.1]`; `initial_states` instead reports `[0, 0.3, 0.15]`, the later gun pose. Right-hand coordinates also change. The starting-state report contradicts its own first observation.

Correction: make state serialization a value snapshot, including nested hand/locomotion containers. Snapshot at capture time, not when assembling the final response. Do not merely repair the displayed field after the run.

Acceptance: capture a record, perform hand Recovery/firing/posture changes, and verify the earlier record remains unchanged. `initial_states` must agree with the initial curve. This defect is verified in reporting; it is not evidence that the input profile or damage computation was mutated.

**A1 — Replace universal action occupancy with explicit ownership as kits expand**

Verified structural facts: [Combatant.current](/home/erzen/Projects/CombatSimulation/combat_sim/battle_models.py:58) permits one controlled action; [decide_team](/home/erzen/Projects/CombatSimulation/combat_sim/team_rules.py:58) refuses all new actions while it exists; [SharedEncounter](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:62) combines ten rule classes whose overrides share mutable motion dictionaries. F1/F4 demonstrate the practical fragility of distributed dispatch. The posture handoff already describes the single slot as a temporary boundary.

This is an integration constraint, not proof that arbitrary existing controlled actions are allowed concurrently. Released projectiles, beams, bleeding and airborne motion already coexist successfully; preserve that distinction. Nevertheless, 1E3's upper-body freeze must prohibit attacks independently of its lower-body freeze prohibiting movement (1E3.odt p3/p5). 2E4's attached blade and replacement/grab sequence has distinct ownership and timing (2E4.odt p3/p69/p72). 1E5's additional arms and double attack must remain representable (1E5.odt p15); two simultaneous hits may be emitted by one action and do not inherently require two player actions.

Practical correction: first centralize command dispatch/cancellation and retain the current exclusive behavior as explicit requirements. Then add action instances with declared occupied hands/body functions, phase-specific restrictions and revision-based cancellation. Evaluate actual conflicts instead of `current is not None`. Keep independently deployed effects outside those locks. Acquire/release requirements atomically, recheck eligibility at authoritative phase transitions, and keep each payment tied to its action instance. This can be a small scheduler owned by the current engine; it does not require a new framework or runner.

Acceptance before relevant kits: upper-body freeze leaves permitted locomotion available; lower-body freeze leaves permitted attacks available; cancellation affects only its owned actions; independent effects survive as documented; simultaneous permitted actions cannot double-spend resources or overwrite hand state.

**A2 — Give projectiles and world objects identities independent of actions**

Verified structural facts: [straight flights](/home/erzen/Projects/CombatSimulation/combat_sim/mobile_projectile_rules.py:34) and [gravity flights](/home/erzen/Projects/CombatSimulation/combat_sim/gravity_projectile_rules.py:82) use `action.id` as projectile identity. Collision queries unconditionally exclude the owner ([straight query](/home/erzen/Projects/CombatSimulation/combat_sim/mobile_projectile_rules.py:66), also present in the gravity query). Terrain is a collection of fixed colliders; [area recipients](/home/erzen/Projects/CombatSimulation/combat_sim/body_collisions.py:55) are selected through hard-coded sphere/column queries.

Those assumptions work for the current gun subset but block direct reuse for 1E3's projectile duplication field, 2E4's owner-contact projectile, 1E3's 4000-HP prison and 3E5's wall-destroying charge. These are verified incompatibilities with the current representation, not demonstrations of incorrectly executing those unimplemented abilities. Coupled chains/grabs also need motion constraints between entities rather than merely moving one actor's coordinates.

Practical correction: allocate a distinct projectile/effect entity ID and retain parent action, owner, source ability and creation time separately. Make contact eligibility and response explicit per projectile. Owner re-contact must be supported without causing immediate launch self-collision. Allow independently expiring/damageable colliders with stable identity, state revision and explicit collision/area-blocking behavior. Invalidate predicted contacts when a collider is removed or changes. Reuse existing trajectory/contact mathematics.

Acceptance: a duplicated projectile remains an independent flight with correct attribution and a documented rule preventing uncontrolled repeated duplication; the owner can consume 2E4's projectile; prison/wall removal exposes the correct later trajectory; body/terrain ties stay deterministic. Record portal/chain/contact semantics under delegation when implementing them, rather than reducing these creative features to ordinary damage packets.

**A3 — Model effect exposure, paused clocks and revival as explicit state**

Verified structural facts: [heat deployment](/home/erzen/Projects/CombatSimulation/combat_sim/team_rules.py:152) creates recipient-specific effects from membership at deployment and retains no independent active-volume membership tracker. [Continuous components](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:542) treats every non-bleed effect as heat. Cooldowns are absolute `ready` timestamps. [Death cleanup](/home/erzen/Projects/CombatSimulation/combat_sim/team_rules.py:271) is terminal. Simultaneous damage records total applied HP loss but intentionally leaves per-attacker overkill credit unallocated. These restrictions are mostly acknowledged in current scope documents.

The affected existing features are moving 1E1 heat/poison exposure, 1E2's cooldown-pause area, overlapping freezes/marks, 1E5's source-specific bleeding bonus, and 2E4's healing and ten-second damage-based revival. Disabling current scope guards without changing these representations would silently produce wrong interactions. The current explicit rejection of heat overlapping shield regeneration is safer than claiming that combination works, but it remains required engine work.

Practical correction: keep volume lifetime separate from per-target exposure/residual state, and emit entry/exit boundaries into the common coordinator. Add typed effect instances with explicit source, target, clocks, stacking key and expiry/cancellation behavior. Represent cooldown progress as remaining work plus a set of pause sources; overlapping areas must not resume a clock when only one ends. Resolve death/revival through a lifecycle transition with event generations so old controlled-action events cannot revive with the actor. Add an attributed damage ledger and choose/document simultaneous overkill credit before using it for healing/revival; preserve the confirmed shield exclusion.

Acceptance: entry, exit and re-entry work at exact effect boundaries; overlapping pause fields compose; separate sources expire independently; revival does not duplicate old actions or erase released effects unintentionally; continuous damage credit integrates over the ten-second window independently of observation spacing. Keep each increment bounded to the next actual authored interaction.

**Risks not established as current defects**

- The gravity path uses binary64 integration, while combat/body logic uses Decimal and other helpers retain rational values. Existing numerical diagnostics are explicitly not certified ODE error bounds. This review did not establish cross-platform identical results or a new observation-schedule defect. Retain numerical tolerances and add close-grazing/tied-boundary regressions when changing the trajectory layer; do not replace it just because it uses floats.
- Raised-support departure, finite ground-edge departure, standing on another moving body, turning and moving Get Up remain explicit unsupported cases. They are known scope limits rather than hidden correctness failures. A completed climb can leave an actor unable to walk off its cube; support-loss events and falling need to accompany broader movement support. Do not mark full spatial integration complete while these guards remain.
- Selective cancellation/resource-payment failures under newly concurrent controlled actions are prospective risks. The current stage prevents most such overlaps. A1's acceptance tests are prerequisites for adding concurrency, not claims of already reproduced double charging.

**What to preserve and implement next**

Retain the shared event clock, analytic continuous integrals, explicit numerical controls, per-loss shield history, pre-hit defense snapshots, action revision checks, swept collision queries, and independent released effects. These are useful foundations. The successful baseline and focused cross-precision checks are evidence of care, but they cover individual feature paths more strongly than the cross-feature command/state invariants exposed here.

Recommended implementation order:

1. Fix F1 and F4 with one command dispatcher and explicit blocked-intent outcomes; retain both regressions.
2. Fix F2 by making the world ruleset independent of script contents. Preserve historical rule choices explicitly and rerun CLI/API and prefix-invariance checks.
3. Fix F3 by separating physical motion from commanded pace. Test statuses before/after landing and preserve unusual launch/knockback mechanics.
4. Fix F5, run all existing regressions plus the review script, and compare the compact historical replays. Preserve old result artifacts even where they expose a now-corrected defect.
5. Finish the current climb checkpoint with those foundations, then introduce A1–A3 incrementally for the next existing abilities. Avoid another general runner or another layer of ability-specific overrides.

Update the mechanics documents when accepting these proposals. In particular, COLLISIONS.md still describes response integration as pending while MOVING_COMBAT.md describes its implementation, and the top of PROGRESS.md/ROADMAP.md/ROSTER.md describes the older completed milestone. Label historical sections and maintain one current capability/decision index so a subsequent agent does not mistake superseded boundaries for active rules. This review itself does not change those mechanics or claim the broader engine is complete.
