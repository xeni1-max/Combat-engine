# Continuous angular query paths

Current extension: [initial native turns](NATIVE_TURNING.md) now use these paths
on the shared timeline within a documented scope. The text below describes
the preceding query prerequisite. Its dense-reference handoff was too broad:
the current constraint planner already returns certified quadratic pieces.

2026-11-13. A shared geometry prerequisite for [whole-body turning](TURNING.md).
This supplies anchored constant-rate yaw, moving local poses, point derivatives
and continuous box/projectile queries. This checkpoint itself did not admit
turn actions; the native extension linked above now adds a documented initial
scope. Historical scenarios retain their fixed-heading contracts.
No new character ability, cost, steering rule or interruption rule is introduced.

## Source rule and delegated implementation

The author specifies 90° per `150 + 40v` ms at movement speed v in m/s.
`YawArc.fixed_speed_turn` reuses the existing exact timing helper for an
explicit signed angle and supplied constant speed. Choosing that input does not
establish how a future controller samples changing speed or steers movement.

The following are delegated numerical/architectural decisions:

- An immutable arc owns an absolute seconds interval, exact initial unit frame,
  signed degree rate and declared precision. Queries derive heading from the
  original anchor, independent of observation order. No incremental rotations
  or extrapolation are allowed.
- A `RotatingBoxPath` composes that arc with an existing `BodyPathPiece` and
  quadratic local centre/full-size polynomials. Reference time remains in ms;
  the reference and yaw leases must agree. Local dimensions stay positive
  throughout the interval, including interior extrema. This is a query view,
  not another body-reference writer.
- New degree selection has an explicit rational error enclosure. Existing
  fixed-heading selection and old outputs retain their original path. Each
  selected moving frame is exactly unit length. Machin arctangent bounds,
  outward rational arithmetic and bounded Taylor remainders enclose ideal
  trigonometry; coefficient uncertainty after composition is at most
  `10^-precision`. Cardinal relative rotations are exact.
- Point output includes translation, angular, centripetal and Coriolis terms,
  together with numerical error bounds. Endpoint derivatives are the left
  limit of the supplied arc. The future timeline must select the outgoing
  phase at an endpoint; it must not keep applying an expired angular velocity.

For reference p, local point q, yaw R and constant angular speed ω:

```
position     = p + R q
velocity     = p' + R(q' + ω Jq)
acceleration = p'' + R(q'' + 2ω Jq' - ω² q_xy)
J(x,y,z)     = (-y,x,0)
```

The stored frame and π midpoint select numerical output; the returned errors
bound its difference from ideal constant-rate yaw of the exact initial frame.
They do not certify a caller's separately integrated reference trajectory.
The same point API accepts hand/weapon attachments. It does not recenter the
actor's reference when a part or the overall pose envelope moves.

## Swept bounds and confirmed contacts

Each vertex has a bounded acceleration over a saved interval. Its departure
from its endpoint chord is at most `A × dt² / 8` per coordinate. Bounds include
reference acceleration, changing local centres/sizes, angular/Coriolis terms,
and uncertainty at the endpoints and interior selected frames. Projecting
these vertex bounds encloses the whole continuous sweep along any fixed axis.
Endpoint boxes alone are insufficient, including when multiple full rotations
make both endpoints identical.

`enclosing_interval` returns an oriented enclosure in the interval midpoint's
fixed frame. It tightens to the actual oriented box as the interval shrinks.
A world AABB would retain empty corners even at zero interval width, preventing
the curved-sphere solver from proving ordinary clear misses. Enclosures only
reject candidates; they never confirm a collision.

`box_path_contact` accepts two saved paths or a path and a fixed cuboid. It uses
continuous projection bounds along actual SAT axes to reject intervals and
confirms contact using actual boxes. Chronological adaptive subdivision returns
a first-contact bracket ending at a confirmed closed overlap. This is geometric
contact, including an initial touch; it does not classify an impact or apply
statuses/velocity projection. Near-tangent ranges that remain unresolved at the
chosen tolerance, or an exhausted explicit node budget, raise rather than
silently returning a miss. The search is iterative, without a Python recursion
depth resolution limit.

The existing `moving_curve_contact` now also accepts a saved rotating box path.
Its separate box velocity/acceleration/size drivers must then be zero: the path
already owns those inputs. The original immutable world flight is clipped to
the requested window, never reintegrated or rotated into a fictitious flight.
Actual oriented geometry confirms sphere hits; world contact coordinates and
original traveled-distance brackets are preserved for falloff. The established
binary64 gravity-trajectory uncertainty/refusal contract still applies.
A rational lease that binary64 endpoint conversion would extend is rejected
explicitly; native clock admission has not been implemented by this geometry API.

## Verification and implementation boundary

[Evidence and commands](results/angular-paths/README.md) record tests, frozen
inputs, complete query outputs, hash/precision/order controls and old combat
replays. All six scaled source bodies and the existing prone pose polynomials
compose with the new paths. Tests also cover real attachment-point velocities,
independent polygon contact roots, thin mid-arc contacts, two rotating bodies,
multi-revolution bounds, resizing/acceleration, rounded-corner misses and
explicit numerical refusals. The sampled containment checks are regressions;
the enclosing rule is the acceleration/error bound above, not sampled poses.

Remaining before native turn admission:

1. Own turn lifecycle and speed/steering choices on the existing action queue.
2. Build query views from the common saved translation prefix, including dense
   constrained paths. The current box-path view requires a quadratic reference;
   fitting a dense constrained path to a quadratic would lose its path/bounds
   contract and is not a substitute for that integration.
3. Integrate angular body/projectile prediction, finite support changes, actual
   contact-feature velocities/response and same-time outgoing phase handling.
4. Choose live-frame versus release snapshots for owned contacts/Block, hands,
   grapples and independently deployed effects. Do not reanchor translation on
   every observed facing or add a second body-position writer.

Prescribed linked climbing and final cross-kit/reproducible 5v5 verification
also remain. The overall Goal is active and incomplete.
