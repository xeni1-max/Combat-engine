# 1E2 ability 1: audit and initial scope

The current root `1E2.odt` and author clarifications are authoritative. Paragraph references below use zero-based ODT paragraph indexes. No source document is edited.

| Rule | Source | Status |
|---|---|---|
| Raw projectile damage 437; 11 ammo per magazine | `1E2.odt` p3 | Confirmed; shot damage in initial scope, magazine/reload execution excluded |
| Slash damage | `1E2.odt` p50 | Confirmed; existing tested slash and bleeding formulas apply |
| Base Gathering 0 ms | Author explicitly confirms; current source has no Gathering entry for ability 1 | Confirmed; replaces stale imported 140 ms |
| Active firing 40 ms | `1E2.odt` p61 | Confirmed |
| Readying 360 ms; listed cycle 400 ms | `1E2.odt` p62/p64 | Confirmed; author defines it as automatic weapon cooldown after firing, blocking no other actions |
| Projectile released after firing | `1E2.odt` p72/p74 | Confirmed; release at 40 ms without initial disorientation |
| Initial speed 900 m/s; acceleration −300 m/s² | `1E2.odt` p69 | Confirmed values; existing timing helper interprets acceleration as constant along the travel path |
| Piercing 18 | `1E2.odt` p69 | Confirmed |
| Damage loses 5 per 20 m | `1E2.odt` p69; author reply | Confirmed continuous falloff: `max(0,437-distance/4)`, before shields/armor |
| Target disorientation/instability 110/110 at impact | `1E2.odt` p52/p53; author reply | Confirmed; mitigation uses armor before the shot's armor loss |
| Self disorientation/instability 135/135 on firing | `1E2.odt` p55/p56; prior author overrides | Confirmed; middle of Active (20 ms), bypass mitigation |
| Slash HP and armor equations | `Damage types.odt`, Slash p15/p21; existing author floors/order | Confirmed; HP damage calculated using pre-hit armor, then armor loss |
| Bleed DPS `y*max(0,8-t)/320` | `Damage types.odt`, Slash p13/p17; continuous-payment clarification | Confirmed; full damage `y/10` |
| Initial current disorientation adds Gathering | Collision/Gathering rules and prior author clarification | Confirmed; zero base Gathering does not bypass current disorientation |
| Accuracy radius 2.4 cm per 100 m | `1E2.odt` p69 | Confirmed value; distribution and automatic hit selection missing; scenario supplies hit confirmation |
| Reload 1.8 s; dyspnea value 2 while controlling recoil | `1E2.odt` p69/p70, p235/p236 | Listed values confirmed; ammo/reload/recoil-input resource state excluded |
| Incoming statuses, interruption, repeated fire and transition eligibility | No sufficiently complete general scheduling policy | Ambiguous/missing; excluded |
| Bleeding under shield absorption | Author extension clarification | Confirmed and implemented: only post-shield/post-armor HP damage creates a bleed; shield damage creates none |

## Established first implementation scope

One scenario-authorized shot, stationary actor/target, supplied distance and confirmed hit, one distinct unshielded nonlethal target, no other actions. Execute zero base Gathering with current-disorientation addition, midpoint self effects, accelerated projectile travel, range falloff, slash HP/armor loss, pre-hit target status mitigation, one continuous eight-second bleed, and firing/Readying boundaries. Firing is extrinsic; current instability does not apply the intrinsic damage penalty. No autonomous hit/miss or action choices.

The scenario authorizes a loaded weapon and this one activation. It does not prove cooldown, magazine, reload, dyspnea or hand-transition availability. The author confirms Readying is automatic weapon operation, equivalent to weapon cooldown; it blocks no other actions. The weapon cooldown lasts 360 ms from firing end and is independent of character statuses. The runner records this weapon cycle separately from character state; successive shots and other actions remain outside this single-shot scope. Projectiles may arrive before or after Readying finishes. No conventional rate-of-fire or guessed Gathering is substituted.

This audit and scope precede combat-mechanic implementation. Remaining excluded rules do not require inventing values for this isolated shot.

## Implemented behavior and numerical check

The established scope now executes. At 100 m against unshielded 2E4 (HP 9080, armor 165):

- Range loss is `100/4=25`, leaving raw damage **412**.
- Slash HP damage is `(412²-(165-18)²)/412 = 148135/412` ≈ **359.550971**.
- Full bleed is `y/10 = 29627/824` ≈ **35.955097**.
- Total HP damage is `325897/824` ≈ **395.506068**; final HP is `7156023/824` ≈ **8684.493932**.
- Armor loss is `4573147/576800` ≈ **7.928480**, leaving **157.071520**.
- Self effects occur at **20 ms**; release at **40 ms**; travel rounds up to **114 ms**; impact is **154 ms**.
- Automatic weapon cooldown runs **40→400 ms**, blocks no other actions, and does not wait for character statuses. The full bleed ends at **8154 ms**.

Cooldown timing is executed in a separate weapon-cycle record and start/completion events. General multi-action scheduling is not implemented. Magazine size/reload remain definitions only; the scenario authorizes a loaded weapon and one shot, and no ammo-consumption implementation is claimed.

**254 tests pass**, including independent known-input formulas, timing/range boundaries, status order, full bleed, armor floors, unreachable travel, deterministic replay and explicit unsupported-input rejection. Summary aggregation now discovers actual continuous effect components, so a slash shot reports bleeding without a fictional venom component. Existing venom/heat/projectile/Blunt regressions pass.

## Source revision notes outside this ability

The current 1E2 revision also removes ability 4's former Gathering 180 ms entry. Its previously imported timing profile is explicitly marked historical and requires review before use; ability 4 is not executable. The current 1E1 revision removes an old Ultimate cycle-time sentence; the current executable abilities do not use it. These edits do not alter the established ability-1 scope. Reviewed current hashes/text are preserved in [the result package](results/1e2-ability1-stage/README.md). Historical packages are unchanged.

## Repeated-fire extension: author-confirmed scope before implementation

The author now confirms:

- Repeat the shot when the weapon is ready, outside its automatic cooldown.
- Shields absorb raw bullet damage before armor; only overflow is pre-mitigation slash damage to HP. Fully absorbed hits cause no armor loss and cannot create bleeding. A partial overflow creates bleeding from its actual post-armor slash y, not shield damage.
- Each HP-delivered bullet has an independent eight-second bleed; these damage rates add. Existing bleeds continue damaging HP when a shield later regenerates.
- A magazine holds 11 shots. Empty ammo requires a reload with 1800 ms Active. Reload can overlap the remaining automatic weapon cooldown.

The extension's established scope is one stationary shooter/target and an explicit finite repeat-fire decision rule, supplied distance and hit confirmations, no outside attacks, full effect resolution, and nonlethal returned runs. Weapon state tracks ammo, cooldown and reload separately from character statuses. The repeat policy chooses firing when ready and reloading when empty; this is an action-selection policy, not a new combat rule. Other character abilities, tactical/nonempty reload, interruptions, movement, dyspnea costs and death remain excluded. Shield losses retain their own 20-second eligibility times and share the documented regeneration rate. No shield bleed is created; no existing HP bleed is redirected into shield.

The author subsequently confirms reload follows the general additional-Gathering rule: current O adds before Active, even with base Gathering zero. Previously saved single-shot artifacts remain historical and unchanged. The earlier missing-shielded-bleed entry is resolved by these author clarifications.

## Implemented shield/repeat/ammo stage

The runner now accepts one explicit `repeat_fire` policy with a finite positive `shot_count` and boolean `reload_when_empty`. It enforces magazine capacity/ammo and automatic weapon cooldown. `weapon_initial_state.ammo` can set starting ammo; otherwise the documented full magazine is the explicit default starting condition. Ammo is consumed at projectile release. A policy that declines reload stops on an empty magazine; exhausting the requested shot count does not force a reload. Multiple independently supplied activation lists remain outside this controlled-policy scope.

Shield absorption, overflow slash, no shield bleeding, independent additive HP bleeds, existing HP bleeding through regenerated shields, pre-hit target status armor, and per-hit delayed/shared shield regeneration are executed and logged. No zero-damage bleed instance is created. Each shot samples the target's current armor, while its own bleed retains the resulting y and original expiry.

**285 tests pass.** At 100 m, one shot into shield 50 does 50 shield damage, 302.306630 direct HP and 30.230663 bleeding. Eleven ready-timed shots into shield 4000 exhaust the magazine, destroy the shield, and deal 360.496071 direct HP + 36.049607 bleeding = 396.545678 HP damage. The first nine shots are fully shielded; the tenth has 120 overflow but armor mitigates its HP damage to zero; only the eleventh creates a bleed.

Reload is now executed: base Gathering zero plus current disorientation, then 1800 ms Active; it can overlap automatic weapon cooldown. Empty ammo is restored to the documented magazine capacity at reload completion. Firing waits for both reload and cooldown. The author confirms O adds Gathering to every not-yet-started ability; no additional Gathering is inserted into an already Active ability, including a continuous one. Accuracy reduction remains applicable; scheduling unrelated continuous abilities is outside this firearm test.

[The shield/repeat result package](results/1e2-repeat-fire-stage/README.md) preserves runnable current code, source/data/test hashes and nine exact traces, including twelve shots with a reload and 23 shots with two reloads from an explicitly depleted-armor starting state. The original single-shot package retains its earlier implementation and limits.

## Reload verification and arithmetic scope

In the canonical twelve-shot shielded scenario, shot eleven releases at 4040 ms and leaves current O=115. Reload Gathering runs 4040→4155 ms; Active runs 4155→5955 ms. Automatic weapon cooldown completes at 4400 ms during reload Active. Shot twelve starts at 5955 ms, releases at 5995 ms, and impacts at 6109 ms at 100 m. Final magazine ammo is 10. Total HP damage is approximately **799.096166**, in addition to destroying the initial 4000 shield. All HP bleeds resolve by 14109 ms.

Longer chains of the documented cubic armor equation cause rapidly growing exact rational numerators/denominators. This stage enforces an engineering budget of 12000 bits for exact impact results before serialization. It raises `UnsupportedMechanicError` on larger results and does not replace the armor rule or round the state. This limits some long sequences with repeatedly changing nonzero armor; it is not a game limit. Multiple reloads are also tested from explicit armor=0, where the documented armor floor avoids that expression growth. More scalable exact/numerical state representation is needed before unrestricted long encounters.
