# Consumed healing allowance and continuous passive recovery

Implemented in the shared world, 2026-10-29. Current inputs opt into
`hp_recovery: {"mode": "consumed_healing_v1"}` with actor lives and applied-HP
history. Executable `2E4.passive_effects.basic_10` now delivers the existing
20%-of-damage healing. Attacks, independent effects, healing, death and revival
use the same timeline. Frozen inputs without this mode preserve their earlier
HP trajectories and output.

## Source facts and selected accounting rules

`2E4.odt` p36 specifies healing for 20% of damage dealt. `Details2.odt` p0
excludes damage to shields from damage-based recovery. `Details.odt` p3 caps
healing at 90% of damage received during the preceding eight seconds.
The primary ODT files remain unchanged.

Those sources do not define payment timing, spent allowance, full-HP excess or
cross-life consumption. The following are explicit delegated decisions:

- Use eligible **actual enemy actor HP removed**, after defenses/HP floors and
  proportional simultaneous overkill allocation. Armor, shield and construct
  loss supply no entitlement. Self/friendly outgoing damage remains in the
  damage journal but cannot generate healing, as in the established credit rules.
- Actual incoming actor HP loss funds healing capacity. Each lost HP funds 0.9
  heal HP, expiring eight seconds after that loss. Initial missing HP, shield
  loss and HP supplied by revival do not create capacity. Incoming self/friendly
  HP loss counts as received damage; it still creates no outgoing entitlement.
- Spend the oldest unexpired capacity first. A spent wound never pays again;
  expiry of old funding does not permanently debit new wounds. Multiple heals
  share this consumed allowance rather than each receiving a fresh 90% cap.
- Point-damage entitlements settle after the complete incoming batch. All raw
  damage and defense snapshots resolve before passive payment. A source already
  at zero HP cannot be saved by a later point payout.
- Continuous eligible damage produces continuous healing, constrained jointly
  with incoming HP loss. Healing can keep an actor alive between scheduled
  events; a post-interval refund cannot stand in for this calculation.
- Full-HP, dead and unfunded entitlement is discarded at its occurrence. It is
  not banked for a later wound, observation or life. Capacity itself remains
  available until spent or expired.
- Funding/history belong to the permanent actor across lives. A surviving old
  source effect may heal its restored living actor; the damage keeps its
  original source generation and healing records the actual recipient life.
  Damage dealt while the actor is dead grants no later payout.
- Basic-10 is passive and has no invented effort cost, Gathering, cooldown or
  hand/body ownership. It overlaps otherwise legal actions and persistent effects.

These rules concern HP recovery only. [Revival](REVIVAL.md) retains its separate
death snapshot, charges and cooldown; it does not spend healing capacity. No
general status cleanse, maiming cure or additional ability is inferred.

## FIFO funding coordinates

Let `L(t)` be cumulative actual incoming HP loss, including all recorded lives.
Funding is `F(t)=0.9*L(t)`. The expired funding coordinate is `F(t-8000 ms)`;
negative times contain zero loss. A monotone cursor `C` retires spent or expired
units. Available capacity at a point is:

```text
available(t) = max(0, F(t) - max(C, F(t-8000)))
```

A point payout is the minimum of requested healing, missing HP and available
capacity; advance the cursor by the paid amount from its expired-adjusted base.
Point windows use `(t-8000,t]`, so a loss expires exactly at the old boundary.
Continuous losses expire using their original analytic/dense time distribution.
The cursor includes expired units and is therefore not a total-healed counter.

[HealingAllowance](combat_sim/mechanics/healing_allowance.py) owns quotes and
payment receipts. Reads do not spend. Duplicate, stale or foreign point quotes
fail before mutation; continuous trajectory commits validate requested amounts,
funding bounds and monotone FIFO consumption. Discarded entitlement also gets a
once-only receipt. No observation read can replay a payout.

## Continuous HP and constraints

For one conditional interval before the first new death, incoming HP and
eligible outgoing HP have immutable analytic/dense dose curves. Reuse the
actual curves from [AppliedDamage](DAMAGE_LEDGER.md), including bleeding,
attached venom and coupled body heat. Let incoming rate be `d`, requested heal
rate be `e`, and paid rate be `h`:

- Normally `h=e`.
- At maximum HP, `h` cannot exceed `d`.
- With empty funding, `h` cannot exceed `0.9*d`.
- At zero HP, healing stops for that life.
- Expiry advances the funding cursor over old unused units; it cannot reclaim
  spent units or create new capacity.

[The flow planner](combat_sim/mechanics/healing_flow.py) integrates cumulative
paid healing, remaining capacity, the gap above expired funding, and missing HP.
Active reflected constraints have exactly zero balance derivative. An initial
implementation inferred remaining capacity by subtracting independently
integrated totals; a real heat encounter exposed constraint chatter and hit the
solver work bound. Tracking the balances directly corrected that numerical fault.

Conditional physical epochs are at most 250 ms, clipped by physical events,
area changes, prepared thermal/venom boundaries and point-funding expiry.
Observation times do not select epochs; they consume prefixes. State/geometry
changes invalidate a forecast. Dense Dormand-Prince 5(4) uses maximum 20 ms
adaptive steps, absolute/relative controls 1e-13 and constraint tolerance 1e-12 HP.
These are solver controls, not damage/healing ticks or certified global bounds.
Real observation/precision checks use 1e-8 HP and 1e-8 ms agreement.

Locate the first continuous HP-zero against exact incoming-dose prefixes and
the same prepared healing curve used for payment. Incoming actual HP loss may
exceed HP at interval start when simultaneous healing supplies more HP during
that interval. Commit gross HP removed and healing separately; do not treat a
net HP decrease as damage dealt. All target commits precede life retirement.

## Inspectability and verification

Public results include `healing_rules`, numerical controls, the allowance state
and `healing_history`. Each receipt identifies the passive, recipient life,
actual/unused entitlement, triggering applied-loss IDs, funding coordinates and
its continuous curve when applicable. Summaries expose actual HP healed and
discarded entitlement separately from gross damage received.

[HealingHistory](combat_sim/mechanics/healing_history.py) reloads saved curves
using the stored precision, validates their receipts and supports immutable
prefix, rolling-window and recipient-life queries:

```python
from combat_sim.mechanics.healing_history import HealingHistory

history = HealingHistory.from_run(run)
recent = history.amount(actor="A", end=4000, window_ms=1000)
```

HP conservation is `sum(initial HP supplied to all lives) + actual healing -
final HP = attributed actual HP removed`. Queries cannot forecast beyond the
saved observation bound or spend entitlement.

Tests cover individual funding/flow/history math and real shared gunfire,
slash/bleed/venom, heat, two healers, capped revival, movement, exclusions,
simultaneous lethal hits, expiry, saved histories and observation/precision/order
controls. A labelled defensive-profile variant verifies two healers with live
toxin resistance and actual 20 s shield recovery under heat. The earlier revival
contracts retain an explicit pre-healing fixture; current tests exercise both
systems together. [Current evidence](results/hp-recovery/README.md).

Other healing deliveries and source filters need their own authored controllers.
Complete kits, layered blocks/charge recharge, linked body constraints and
general six-character 5v5 remain unfinished. The next shared increment is the
authored Block family: audit its layers, duration, directional interception,
resources and rechargeable charges before porting the block-triggered attacks.
