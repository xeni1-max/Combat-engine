**Independent principal-engineer review — 2026-11-10**

The engine has a substantially stronger shared foundation than at the previous
review. The November 3 concurrency and climb regressions remain fixed, and the
new abilities use the shared action, projectile, motion and effect systems.
The actionable findings are one acknowledged terrain limitation that still
aborts ordinary encounters, one new determinism defect in direct engine
initialization, and stale capability documentation. The grenade cover contract
and coordinator complexity need separate attention; neither is a proven new
gameplay defect.

This review covers the current launcher checkpoint and the six existing
characters. Implementation, character data, permanent tests and primary sources
were not changed. Evidence is pinned in the
[review package](/home/erzen/Projects/CombatSimulation/results/principal-review-2026-11-10/README.md).
All reviewed implementation files remained unchanged across the pause/resumption.

| Priority | Finding | Evidence classification | Practical consequence |
| --- | --- | --- | --- |
| P1 — engine-completeness blocker | R1: walking after a completed climb can abort the entire run | Reproduced, already documented capability gap | Ordinary terrain traversal cannot yet support unrestricted encounters |
| P2 — correctness defect | R2: direct construction ignores declared precision during initialization | Newly reproduced defect; public wrapper/CLI unaffected | Identical inputs and declared precision produce different shot/contact times and HP |
| P3 — documentation defect | R3: the current capability table still lists delivered abilities as missing | Verified contradiction | Development can follow an obsolete implementation backlog |

P1 here identifies a prerequisite for general terrain scenarios, not an
undisclosed regression or a claim that the existing guarded scope was promised
to support ledges. No new critical defect or additional exploitable violation
was reproduced in the bounded cases examined.

**R1. Complete static-support departure before broad terrain experiments.**

The ordinary
[climb-then-walk scenario](/home/erzen/Projects/CombatSimulation/results/principal-review-2026-11-10/climb-walk-departure.scenario.json)
starts A at x=4.59, issues walk/climb at time zero, then walk at 800 ms after
the climb has completed. A 2,000 ms run raises
`UnsupportedMechanicError: Raised-support departure requires ledge/fall integration`.
Both the public API and CLI fail. Changing observations to 37 ms, or using
precision 80 with 17 ms observations, preserves the failure. Without the second
walk, the climb completes and the body remains at (6, 0, 2.675).

The cause is the full-containment guard in
[airborne_combat.py:375](/home/erzen/Projects/CombatSimulation/combat_sim/airborne_combat.py:375):
a grounded body on raised static support becomes unsupported by the implementation
as soon as any body box extends beyond the selected support part. The simulation
has no scheduled transition for that ordinary departure. Atomic spatial changes
also guard partial raised support in
[spatial_transitions.py:280](/home/erzen/Projects/CombatSimulation/combat_sim/spatial_transitions.py:280).

This matters beyond the minimal climb case. Existing hooks, leaps, portals,
knocks and grapple groups can place or move bodies on raised surfaces. Their
subsequent traversal needs this shared transition. Those broader consequences
are architectural implications; this review reproduced the climb/walk failure,
not every combination. PROGRESS already correctly identifies this as the next
major implementation task.

Recommended correction:

1. Define the supporting contact witness consistently for static surfaces and
   living bodies. Distinguish partial overhang from actual loss of supporting
   overlap; full containment of every body part is not a departure model.
2. Schedule the earliest support-loss boundary through saved body paths. Reuse
   the geometry approach in
   [BodySupport.departure](/home/erzen/Projects/CombatSimulation/combat_sim/body_support.py:184)
   and the existing
   [release_support transition](/home/erzen/Projects/CombatSimulation/combat_sim/spatial_transitions.py:440).
   Static supports need their own witnesses and alternate-support checks, while
   position advancement continues through the existing shared writer.
3. At departure, preserve instantaneous position/velocity, independent motor and
   force components, grapple/tether constraints, and life-bound landing obligations.
   Enter native free flight once, with no new jump cost or fabricated landing.
   Replace the containment guard only when that transition is implemented.

Acceptance criteria: the supplied scenario reaches its horizon; walking/running
and forced displacement leave raised supports at the physical boundary; partial
overlap and alternate supports follow the selected rule; landing uses native
contacts; group/tether constraints and earned landing effects survive. The
boundary and outcomes must agree across observation intervals and participant
order. Exercise pose changes and support removal at the departure clock as well.
Outer-floor departure can remain explicitly scoped until its world-boundary
semantics are selected, rather than being silently conflated with raised ledges.

**R2. Own the Decimal context during construction, not only during run().**

[SharedEncounter.__init__](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:120)
stores `precision` but performs loading and initial world construction under the
caller's context. In particular,
[initial-state parsing](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:277)
calls [decimal_value](/home/erzen/Projects/CombatSimulation/combat_sim/battle_models.py:13),
whose Fraction-to-Decimal division uses ambient precision.
[run()](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:1115)
establishes the requested context after those values and initial structures
have already been created. Queue normalization cannot recover the lost digits.

The
[reproduction](/home/erzen/Projects/CombatSimulation/results/principal-review-2026-11-10/constructor-boundary.scenario.json)
uses declared precision 50 and initial disorientation
`80.0000000000000000000000000001`. This is a valid input well within the declared
precision. Only the caller's context changes:

| Entry point / caller precision | Release | Body contact | Target HP at 500 ms, rounded |
| --- | --- | --- | --- |
| Direct SharedEncounter / 28 | 120 ms | 152.993617 ms | 7747.637804849126 |
| Direct SharedEncounter / 80 | 121 ms | 153.993617 ms | 7747.647110067970 |
| run_shared_scenario / 28 | 121 ms | 153.993617 ms | 7747.647110067970 |

Rounding removes the tiny positive fraction before Gathering is rounded upward
to whole milliseconds. The resulting one-millisecond phase/contact difference
changes bleeding duration and final HP by approximately 0.00930522, exceeding
the project's 1e-8 comparison tolerance. Event-order changes in other encounters
are a plausible consequence, not an additional reproduced result.

Scope is important: the
[public wrapper](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:1320)
already protects initialization, and the CLI's complete result matches that
wrapper. Direct construction and subclass/API extension usage expose this defect.
The current direct-API precision regression in
[test_released_damage_combat.py:316](/home/erzen/Projects/CombatSimulation/tests/test_released_damage_combat.py:316)
covers execution across fractional revival clocks, but its initial values do
not expose constructor rounding.

Recommended correction: validate the requested precision at the common engine
entry point and perform all initialization inside the same fresh
`Context(prec=precision, rounding=ROUND_HALF_EVEN)` used for execution. A small
constructor wrapper around an initialization helper would keep that contract
in one place for direct callers and subclasses. Restore the caller's context
on successful and failed construction. Preserve input precision and existing
clock semantics.

Acceptance criteria: direct construction with caller precisions 28/50/80 and
different caller rounding modes agrees on initial values, release/contact
times and damage for the supplied case. Include a value just above an integer
Gathering boundary, fractional positions, and constructor failure/context
restoration. The public wrapper and CLI remain matching controls. This is a
bounded correction that can be implemented separately from R1.

**R3. Reconcile the current capability table with delivered abilities.**

[ENGINE_STATUS.md:376](/home/erzen/Projects/CombatSimulation/ENGINE_STATUS.md:376)
still lists 3E5 leap delivery as unfinished; the released-knock row calls the
falling kick unfinished, and the binding/six-kit rows still list portals as
unfinished. The same document's opening checkpoints,
[LEAPS.md](/home/erzen/Projects/CombatSimulation/LEAPS.md),
[PORTALS.md](/home/erzen/Projects/CombatSimulation/PORTALS.md), and passing actual
delivery tests establish that these abilities are implemented within stated
boundaries. The overall engine/5v5 goal remaining incomplete is consistent;
the specific missing-ability claims are stale.

Correct the current table and its remaining-work statements, preserving dated
historical checkpoints. List actual boundaries such as static ledges, general
facing/turning and interaction coverage. Acceptance is a current roster/status
mapping that agrees with the selected character data and actual delivery tests;
historical runners and old fixtures remain clearly labelled.

**Design contract to settle: grenade gas and its initial O/U pulse use different cover policies.**

This behavior is verified; its being wrong is not established.
[WeaponModes.expand](/home/erzen/Projects/CombatSimulation/combat_sim/weapon_modes.py:155)
deploys an unoccluded gas volume, then selects status recipients through
[body_area_recipients](/home/erzen/Projects/CombatSimulation/combat_sim/body_collisions.py:80)
with its default `occlusion='world'`. In the saved
[cover scenario](/home/erzen/Projects/CombatSimulation/results/principal-review-2026-11-10/poison-cover.scenario.json),
B is inside the gas radius behind area-blocking cover. The burst at
884.010487 ms lists no O/U recipients, while B immediately acquires poison and
ends at approximately 7446.457249456295 HP at 1,800 ms.

[LAUNCHER.md:49](/home/erzen/Projects/CombatSimulation/LAUNCHER.md:49) describes
an unoccluded cloud and once-only area O/U, while
[POISON_VOLUMES.md](/home/erzen/Projects/CombatSimulation/POISON_VOLUMES.md)
clearly defines gas eligibility but leaves the pulse's separate cover rule
implicit. The pulse and gas can reasonably be separate deliveries under the
delegation; a shared recipient set is another possible reading.

The behavior-preserving correction is to document the current distinction as
a delegated rule, pass the status occlusion policy explicitly, and test covered
and uncovered recipients. If the chosen contract instead requires one recipient
set, pass `occlusion='none'` explicitly for the initial pulse. Retain once-only
statuses and independent persistent clouds. No author clarification is required
unless resolving this changes an established creative preference.

**Architecture assessment and remaining risks.**

Keep the existing shared foundations: resource-based action ownership permits
independent abilities; released entities retain immutable source life and power;
weapon variants are pinned across swaps; duplication preserves lineage; portal
transport validates affected bodies together; shared damage/history resolves
defenses, death and subsequent lives. These mechanisms support the characters'
defining features. The current evidence does not justify replacing them.

The main maintainability risk is the growing coordination surface in
[SharedEncounter._run](/home/erzen/Projects/CombatSimulation/combat_sim/shared_engine.py:1167),
combined with execution-model lists repeated across loading, ownership and phase
dispatch. Correctness depends on each mechanic scheduling, invalidating and
retiring the right state at the right point. No additional ordering failure was
reproduced. Treat this as a risk to contain while implementing R1 and facing:
document phase/lifetime responsibilities, add development checks after complete
same-clock closure, and centralize repeated capability metadata incrementally.
Useful invariants include live controlled owners matching their actor life,
released effects retaining their source identity, and prediction/advancement
using the same valid motion interval. Preserve separate effect lifetimes and
independent action resources during that work.

General facing/turning remains an explicit engine boundary that constrains
future starting-position experiments and directional contact behavior. It is
appropriate shared-engine work after static-support departure, independent of
advanced NPC intelligence. The earlier optional stack-dump diagnostic exit 139
also remains unresolved in project records. This review did not reproduce it
as a normal simulation failure and makes no fix claim.

**Verification and limits.**

- The existing **2,943-method suite passes** in 748.094 seconds across four
  isolated processes with exact disjoint coverage. The suite includes historical
  rule fixtures; its size is not a claim of universal current-rule coverage.
- All **seven unchanged November 3 review regressions pass**. Both previous
  findings remain resolved.
- Twelve additional ordinary runs cover six mixed-kit configurations, comparing
  baseline execution with precision 80, 37 ms observations and reversed participant
  insertion order. Checked final HP/shield/armor/D/O/U/body coordinates agree
  within 1e-8; maximum difference is about 4.713e-41. HP conservation error is at
  most 1e-46. Discrete event counts match after excluding continuous accounting
  fragments. This comparison is not full-trace equivalence or complete interaction
  coverage; configured abilities do not necessarily finish or contact a target.
  In particular, these extra probes did not exercise actual hook launch or portal
  use, although the existing suite has their focused integration cases.
- The new desired-behavior review specifications have **two passing controls,
  one failure for R2 and one error for R1** on this snapshot. They are retained
  separately from the permanent suite. Full API/CLI comparison confirms the
  constructor case's public path passes; both public paths reproduce R1.
- The 549-file starting manifest and final integrity receipt establish that
  reviewed implementation/data/tests/primary files were unchanged. Only review
  artifacts and the PROGRESS continuity entry were written. The pause introduced
  no implementation changes, so the full suite was not needlessly repeated.

The implementation handoff is R1 as the next major engine capability, R2 as a
small independent correctness correction, then the current-status and grenade
contract updates. Retain the source decisions for the 20 m segmented fence,
current Dodge/body proportions, launcher, portals and falling kick. Verification
should cover the actual affected interactions before advancing to general
facing and reproducible 5v5 work.
