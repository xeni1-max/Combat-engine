# General consistency review — 2026-10-24

Reviewed all 13 current root ODT files, the conversation clarifications, character data, mechanics helpers, encounter runner, and tests. Material in `reference_material_non_authoritative/` is optional background, not an authoritative mechanics source or the project being implemented (author clarification, 2026-10-25). Original ODT files were not edited. Symbol reuse alone is not a defect.

Follow-up: C01–C04 are corrected. The author also confirmed state/defense floors, separate venom factor floors, shield effect eligibility and explicit shield bonuses, running/Gathering order, 1E5 on-impact self effects, and midpoint self effects for projectile firing/throwing. Revised primary profiles and the current resolutions are recorded below. The old 80-after-Active chain remains historical only.

The [preceding rule-update checks](results/rule-update-checks/README.md) preserve revised source extracts, input data, numerical checks, and source/code hashes. The earlier [clarification checks](results/clarification-checks/checks.json) and [state-floor run](results/clarification-checks/state-floor-run.json) remain snapshots of their preceding stage.

Self-status rule update: [the self-status exception update](results/self-status-unmitigated/README.md) executes the same controlled 1E1 projectile/blast with **unmitigated self effects** and mitigated target effects. HP, armor, and additional resistance do not reduce self disorientation/instability; running +20% remains. This explicit author override supersedes the preceding self-mitigation clarification. Both hits remain 450 Qard with 110/110 target effects, and Qard armor loss remains zero. The [preceding 1E1 stage](results/1e1-ability1-stage/README.md) is historical.

Latest ability stage: [controlled 2E4 ability 1](results/2e4-ability1-stage/README.md) now executes one unshielded nonlethal slash thrust, armor loss, target/self effects, a single bleed, and venom exposure/non-exposure decay. The [focused audit](2E4_ABILITY1_AUDIT.md) records the author answers and boundaries. **187 tests pass.**

The [source manifest](results/consistency-review/manifest.json), [before-fix probes](results/consistency-review/probes-before-fixes.json), and [after-fix probes](results/consistency-review/probes-after-fixes.json) preserve the evidence. Paragraph locators such as `p82` refer to the zero-based ODT paragraph index in the source extracts, not a printed page number.

## Already resolved; no new answer required

- **2E4 piercing is 40.** It is explicitly present in the current detailed ability 1 (`p63`). The recorded data was stale and has been synchronized.
- **2E4 sprint bonus is +6 m/s.** Both the overview and detailed entry now agree (`p26`, `p178`). The old +4.8 alternative has been removed from current data. 3E5's current sprint entries also agree on +6.
- **Dyspnea recovery** is 30/s while standing/walking, 18/s while running, and zero under any of the confirmed blockers. The former negative sprint-rate issue is resolved.
- **1E5 ability 1 components** alternate left/right, each listed damage 440. Current self-disorientation/instability are **150 each on impact**, verified in the updated source. The previous 80-after-Active example is historical only.
- **HP and armor stop at zero.** Nominal formula outputs and actual losses are now logged separately. Death/overkill-credit policy remains open.
- **Adjusted armor/resistance stop at zero before squaring.** Slash and venom helpers implement these floors. The author separately confirmed that each venom damage factor floors at zero before multiplication, and the helper implements this too.
- **Shield absorption does not suppress effects.** Shields grant only their explicitly stated extra disorientation/instability resistances; shield presence alone gives no automatic bonus.
- **Running modifies base Gathering only.** Base 140 with current O=80 gives 248 ms. Self effects use their full listed value without mitigation, increased by 20% while running: listed 80 becomes 96; with running base 168, Gathering is 264 ms.
- **Straight-line hand repositioning**, 3D coordinates relative to hitbox centre, and ms/m Recovery units are established. Actual poses and multi-hand aggregation are still needed for other transitions.
- **Shield priority, overflow-only HP formulas, no armor loss on fully shielded hits, independent 20-second shield-loss delays, and one shared 400 HP/s regeneration rate** are established.
- **Damage-based healing/revival excludes shield damage**, as specified in `Details2.odt`.
- Reusing `d` for pre-mitigation damage in Blunt and Slash is valid. Renaming symbols supplies no missing mechanics or values.

## Direct source conflicts — resolved by author edits

| ID | Source | Previous inconsistency | Verified current resolution |
|---|---|---|---|
| C01 | `3E5.odt`, ability 1 overview and shared details | Both arm entries had label b, while the sequence called for b/c. | Right arm is **b**, left arm is **c**. |
| C02 | `3E5.odt`, detailed ability 1 b/c | Target status values appeared as both 150 and 110. | **150 disorientation and 150 instability**; the 110 entries were removed. |
| C03 | `3E5.odt`, ability 2 | Binding value appeared as 5 and 6. | **6** in the detailed entry; the conflicting overview value was removed. |
| C04 | `1E3.odt`, ability 2 | Cooldown appeared as 9 s and 1.2 s after Active. | **9 seconds** in the overview; the conflicting detailed line was removed. Its cooldown-start anchor is now unspecified. |

These four questions are closed and the data has been synchronized. The existing `3E5/1b` runner definition still covers its right-arm scalar hit; it does not schedule automatic b/c alternation or statuses.

## Questions that can change combat results

### Q01 — State floors resolved; death and damage credit remain open

The author confirms minimum HP and armor are zero. The engine now clamps the resulting state and records the nominal formula output, actual loss, and excess separately.

The original probe produced HP −200 and armor −6. It now ends at **HP 0, armor 0**. Nominal damage is 300, actual HP lost is 100, and excess is 200. Nominal armor loss is 6, actual armor lost is 0. Initial negative states are rejected.

Still specify when death occurs, what happens to pending actions, and whether damage credit uses nominal damage or actual HP lost. Logging both values does not choose that credit policy. Sources: author clarification, `Damage types.odt`, and `Details2.odt`.

### Q02 — Defense and venom factor floors resolved

Adjusted armor/resistance stop at zero before squaring: `max(0,a-p)` and `max(0,RT-p/5)`. The Slash example `d=100,a=10,p=30` gives **100**.

The author separately confirms each venom damage factor also floors at zero before multiplication. With `d=100,a=200,p=0,Tp=10,RT=10,tT=1,to=0`, raw factors are −3 and −90; each floors to zero and damage is **0 damage/s**, replacing the former 270. Positive cases retain the documented arithmetic. Regression tests cover both-negative, one-negative, zero, positive, and excess-piercing cases. Exposure state and payment rules remain Q06. Sources: `Damage types.odt`, Slash/Venomous, and author clarifications.

### Q03 — Shield effect eligibility and explicit bonuses resolved

Effects still go through shields; absorption alone does not cancel them. Additional disorientation/instability resistance is manually specified for each shield, under its stated condition. There is no universal shield-HP-to-resistance formula or automatic bonus. Without a stated bonus, no extra shield resistance is added to the confirmed baseline R=0. The author's “additional 200” wording was an example, not a value assigned to the existing passive shields. Block retains its documented bonuses.

The status helper accepts explicitly supplied R; choosing active bonuses and scheduling effects remain future engine work. Individual effect prerequisites, toxin/bleed magnitude bases, and shield-layer ordering are separate questions (Q06/Q07/Q12).

### Q04 — Revised self-effect amounts and main attack anchors verified

- `1E5` ability 1: **150 disorientation and 150 instability on impact**, at its 230 ms base midpoint (`p57/p58/p60`). Ability 2's 80/80 “on swing” wording is interpreted as on impact by the author's reply to the ability 1/2 question; its source still uses the older label.
- `2E4` ability 1: **150/150 on impact**, and newly listed dyspnea value **3** (`p58/p59/p65`).
- `3E5`: ability 1a **200/200**, b/c **150/150**, ability 4 **200/200**, Ultimate **150/150**, all explicitly on impact. Ultimate's impact is target contact, replacing its former midpoint anchor.
- For projectile self effects described as **on firing/on throw**, the author confirms **middle of Active**. This is separate from release at the end of Active and subsequent target impact. For example, 1E2 ability 1 self event is at **160 ms**, release at **180 ms**, and impact at **294 ms** for a supplied 100 m path with its acceleration.
- Other revised values, projectile fallback removals, and source locators are preserved in the [update report](results/rule-update-checks/README.md). The earlier 80-after-Active chain is historical only.

`self_effect_time_from_activation` calculates explicit anchors; applying statuses is separate. The author now explicitly exempts self disorientation/instability from all mitigation. The controlled 1E1 model uses the self route, and its maximum-dyspnea helper adds the unmitigated 200 trigger (240 while running). Target effects retain collision mitigation. Jump/landing times and intrinsic same-impact ordering remain separate future rules.

### Q05 — Running/Gathering order resolved; mid-action changes remain open

The author confirms that running scales only base Gathering before current disorientation is added. The timing helper implements this order:

- Base 140, current disorientation 80, running: **168+80=248 ms**.
- A listed self effect of 80 becomes **96** while running, with **no mitigation**, giving **168+96=264 ms** Gathering when supplied as current state. The author's latest exemption supersedes the preceding mitigation-first self rule. Current O is not scaled again during Gathering.

Remaining questions:
- Resolved by author: newly received disorientation extends Gathering already in progress by its mitigated amount. Once Active starts, disorientation does not insert Gathering into that Active.
- If the selected ability changes during additional Gathering, what completed time is preserved or reset? The source says the latest ability has priority but gives no complete transition rule.
- How does 1E2 Ultimate's fixed +250 ms Gathering effect combine with disorientation, running, and another copy of that effect?

Sources: `Details.odt` Gathering/running; `Collision details.odt` additional Gathering; `1E2.odt` Ultimate.

### Q06 — Base 2E4 clocks, payment, and snapshots resolved; shield/overlap remain open

The author confirms venom d is slash damage remaining after shield, before armor mitigation; armor is captured before the thrust/armor loss. Exposure grows with elapsed attachment time. At detachment, accumulated exposure is retained while non-exposure grows until damage reaches zero. Both bleed and venom accumulate continuously.

For the one-second base attachment, toxin continues for one additional second after detachment. Continuous phase integrals and the eight-second bleed are implemented for one stationary, unshielded, nonlethal hit. Target statuses also use pre-hit armor; damage is calculated before adding the new self-instability and before armor loss.

Fully absorbed d=0 venom delivery is now resolved: no toxin damage. Every venomous attack includes a slash component, and the delivery factor is its post-armor/pre-armor ratio using post-shield damage. Before shielded or repeated encounters, define shielded bleed creation/basis, raw toxin/bleed shield handling and continuous regeneration histories, overlapping blades/attackers, and Ultimate interactions. Time-varying toxin resistance and independent interrupt/cancellation policies remain outside this base run. Other damage types do not automatically inherit these venom-specific clock answers.

### Q07 — Bleeding stacks and 1E5's amplification

**Priority: before complete 1E5 damage results.** Slash defines a linearly decreasing 8-second bleed. Under continuous integration, one independent unmodified bleed totals `y/10`; this derivation does not decide stacking or payment cadence.

Do new hits create independent bleeds, refresh one bleed, replace it, or add to its current rate? For 1E5 ability 4, what receives the extra 50%: direct damage, initial bleed magnitude, each tick, or total bleed? Are partial hundreds of existing own bleed DPS counted continuously or only in complete 100-DPS steps? Is the existing bleed sampled before the new hit? Source ownership also matters when several attackers bleed the same target.

For Ultimate, specify which two arms/components attack, their relative impact times, and whether status/dyspnea costs occur per component or per use. Sources: `Damage types.odt`, Slash; `1E5.odt`, abilities 1/4 and Ultimate.

### Q08 — Dyspnea action data, costs, and the cap

The movement-dependent loss rates, blockers, available capacity, formula `Da`, action addition, sprint `Dd=2`, and once-per-crossing maximum trigger are settled.

**Author clarification, 2026-10-28:** effortless extrinsic activation, summoning,
marking, passives and automatic enhancements do not require a dyspnea value.
Eight explicit examples, including revival, are confirmed exemptions in
[DYSPNEA_POLICY.md](DYSPNEA_POLICY.md) and character metadata. An absent number
on such an effect is not a missing-cost blocker or Db=0. Physical effort such
as recoil control retains its own cost. The selected Qard/gun/reload Db values
and payment/cancellation anchors were already confirmed and execute in shared
combat. Sprint exhaustion also executes; see [CROUCH_SPRINT.md](CROUCH_SPRINT.md).
Other kit-specific effort/timing and grapple recovery contexts remain integration
decisions under delegation rather than general questions for the author.

The older running-gain/cap-scheduling questions are superseded for current body
profiles by [MOVING_COMBAT.md](MOVING_COMBAT.md): transition effort, movement
contexts, continuous sprint and exact resource boundaries share the coordinator.
This does not establish full kit integration for every character.

### Q09 — Break progress and the old filling rate

`Binding abilities.odt` still says the old **20/s** emptying turns into filling during Break, while revised general recovery is 0/18/30. Is Break's filling a separate fixed 20/s rule, or should it use another rate?

Does the threshold compare current dyspnea D or cumulative dyspnea added since Break started? What happens when D reaches 100 before sufficient progress? Does progress persist through the disorientation pause or an interrupted Break? With binding value 2 against 1E5's maximum HP 20000, the written threshold is `(40−40)^0.9=0`: does that mean an immediate break? Negative fractional-power inputs for larger HP also need a domain rule.

Sources: `Binding abilities.odt`, `Dyspnea details.odt`, `1E2.odt` ability 5, `1E5.odt` profile.

### Q10 — Cooldowns and Readying; projectile fallbacks resolved

- Define a default cooldown start only where the ability has no explicit anchor. Does cooldown availability gate Gathering or only execution? Do charge cooldowns recharge sequentially or in parallel, and are initial charge counts full?
- 1E2 ability 1 explicitly has 40 ms firing plus 360 ms **Readying** for a 400 ms cycle. Is Gathering only before the first shot of continuous fire, or before every shot? How does Readying relate to Recovery and the dyspnea recovery blockers?
- What does 1E2 ability 2's cooldown-pause field pause: ordinary cooldowns, charge regeneration, or other timers? The shield delay is not silently classified as a cooldown.
- **Resolved by source edits:** the projectile fallback clauses have been removed. All 11 imported projectile profiles now require distance; no pre-release target impact is inferred. Archived snapshots with explicit fallback fields remain reproducible as historical inputs. 3E5 Ultimate also now requires a target contact event.
- Damage falloff with range is stated for 1E2 abilities 1/4 but has no formula.

Sources: the cooldown/Readying/projectile entries in `1E2.odt` and other profiles. Existing explicit after-Active cooldown anchors remain authoritative.

### Q11 — Healing budget and revival state

**Current resolution, 2026-10-29:** [actual HP attribution](DAMAGE_LEDGER.md),
[life transitions](LIFE_CYCLES.md) and [executed 2E4 revival](REVIVAL.md) resolve
the revival gaps below under delegation. The death snapshot, HP cap, zero-credit
gate, finite charge stock, cooldown and occupied-completion policy now execute.
[Consumed healing allowance and continuous passive healing](HEALING.md) now
resolve the healing gaps too, with explicit FIFO expiry, discarded excess and
joint HP/death integration. The questions below preserve the original source audit.

Shield exclusion from damage-dealt credit is settled. The 90%-of-damage-taken-in-8-seconds cap still needs accounting rules. If a character took 100 damage and has already healed 60 within that window, is the remaining allowance 30 or 90? Does shield damage taken contribute to this cap? Does credited damage include armor loss or nominal overkill, or actual HP lost only?

For 2E4 revival, is the 10-second damage window sampled at death or at revival completion 2000 ms later? Is revived HP capped at maximum HP? What happens with zero eligible damage? Define shield/armor/status restoration, charge consumption, and the 65-second cooldown's anchor. Sources: `Details.odt`, `Details2.odt`, `2E4.odt` ability 5/basic 10.

### Q12 — Block layers and charges

General Block provides an 800-damage barrier for 250 ms; holding creates two shields and more resistance, with 350 ms total ability time. Profile Active times of 150 ms can describe a different phase, so those durations alone are not a contradiction.

Which absorbs damage first: Block's barrier or the 4000-HP shield? Does a held Block consume one or two charges? When are its two barriers created and when does each expire? Are 2E4 basic abilities 8 and 9 separate modes/pools, or duplicate entries? What exactly counts as a successful block for its counterattack? Its 500-damage counterattack also lacks a damage type and impact anchor.

Sources: `Details.odt` Block; `2E4.odt` abilities 2/basic 8/basic 9; `3E5.odt` basic 8.

### Q13 — Other Recovery transitions and limb availability

Supply actual poses and a consistent axis convention. For actions requiring multiple hands, define how distances combine. State updates for an unused hand, ability-switch sequence resets, initial components, and hand availability while summoning/grabbing are incomplete. These are not blockers for the already explicit zero-Recovery 1E5 timing example, but matter when leaving or returning to that chain.

For 2E4's replacement blade, does the 600 ms grab delay start at impact? Does ability 1 remain unavailable until the 250 ms grab finishes, and can another ability run in between? Sources: `Details.odt` Recovery; conversation pose clarifications; `2E4.odt` ability 1.

### Q14 — Simultaneous events, interrupts, and sustained effects

**Author clarification, 2026-10-29:** intrinsic/extrinsic and
momentary/sustained describe the character's controlled effort, not the lifetime
of an effect. The beam activation is extrinsic momentary; after deployment it is
independent and caster instability cannot stop it. Recoil can still cost dyspnea
on an extrinsic attack. [ABILITY_EFFORT.md](ABILITY_EFFORT.md) records confirmed
examples, phase metadata and the remaining shared-engine instability work.
Threshold/sampling/continuation choices are delegated engineering work, not
requests for the author to supply technical rules.

The former local after-Active self-effect order is historical. Current on-impact self effects still need their order relative to damage calculation when that could affect the same hit. Multiple characters hitting, dying, changing armor, or completing casts at one timestamp still need a global policy. Are simultaneous hits calculated from one common pre-hit state, or resolved in a specified order? Can a lethal hit cancel another hit at that same time?

For 2E4 the author confirms damage precedes its new self-instability; target statuses and venom use pre-hit armor. Other intrinsic/composite abilities still need their applicable ordering. Instability reduces intrinsic damage and interrupts extrinsic sustained abilities. Specify when its value is sampled, whether damage is reduced before shield absorption and armor formulas, and which abilities are channels versus autonomous deployed effects. No interrupt threshold or complete cancellation rules are specified. Sources: `Collision details.odt`, `Details.odt`, beam/fence/grapple abilities.

## Further character and spatial gaps

These can wait while testing explicit confirmed hits, but must be defined for broader encounter simulation.

| Source | Remaining details |
|---|---|
| `1E1` ability 1 | **Resolved/implemented in controlled scope:** both hits deal 450 Qard and apply 110/110 target effects. Marker stays at initial impact location; scenario supplies blast eligibility. Automated targeting, movement, and repeated-action availability remain future work. |
| `1E1` ability 4 / Ultimate | Beam effect start relative to its 300 ms cast; poison cloud exposure/overlap; grenade ammo/mode lifetime; cooldown anchor for equipping Ultimate. The 300 ms weapon swap should not automatically be charged on every grenade. |
| `1E2` | Accuracy sampling distribution and Aim's benefit; range-damage falloff; grappling-launch movement; fixed +250 ms debuff stacking/refresh; cooldown-pause scope. |
| `1E3` | Ice bomb has a Blunt tag but no damage amount; allowed actions under upper/lower/full freeze; marks from different owners; cube damage model; portal-use cooldown ownership; duplicate projectile placement, repeated entries, damage/status ownership and whether duplicates can duplicate again. |
| `1E5` | Piercing for its slash attack is still absent. Bleed amplification, Ultimate pairing, and sequence reset are open as above. |
| `2E4` | Base ability 1 now has a controlled unshielded single-effect model; its shield/overlap cases remain open. Piercing 40 and sprint +6 are resolved. Owner-contact projectile trajectory, triggered 600-damage attack's impact anchor, knockdown duration/effects, revival behavior, and replacement-blade action availability remain open. |
| `3E5` | C01–C03 are resolved. Leap trajectory/contact and knockdown; chain movement at maximum distance; wall-slam recipient/timing, drag DPS, boost resets, and the 8-second hold clock during Ultimate remain incomplete. |
| `Details.odt` movement | `M(θ)` yields −30 at θ=0 and 0 at θ=90; its output unit needs confirmation, likely percentage but not silently treated as m/s or percent. Floors for negative slide/knockback distance are not stated. Maiming effects and the healing threshold to remove them are missing. |
| `Contextual abilities.odt` | Its first example leaves exactly 10000 current HP between “under” and “above”; future concrete abilities need inclusive boundary rules and a re-evaluation/cancellation policy. |
| General spatial combat | Hitbox dimensions, facing/targeting, area eligibility including self-damage, projectile interception, line of sight, contact geometry, and head locations. These are future spatial rules, not assumptions for existing scenario-confirmed hits. |

## Pairs of numbers that are not automatically conflicts

- 1E1 Ultimate's **1.47 s cycle** is consistent with base Gathering 140 ms + Active 180 ms + cooldown 1150 ms, under the non-overlapping cooldown-before-next-Gathering interpretation. The initial 300 ms weapon swap is a separate stage. No change to 1.15 or 1.47 was made.
- 1E1's **300 ms beam cast** and **3-second beam duration** can be separate activation/effect durations. Likewise 1E2's 160 ms fence cast and 6-second fence lifetime. Their effect start anchors still need definitions.
- Using the same letter in separate formulas is permitted. The legacy secondary 35% critical-hit rule is excluded; current 1E2's **600/1500** values are explicit.
- ODT embedded object display names do not reliably equal their ZIP object directory names. The movement/slide formula links were checked using their actual embedded-object references; no swapped-equation conflict was reported.

## Implementation review and corrections

| ID | Finding | Status |
|---|---|---|
| I01 | Current 2E4 source had piercing 40 and sprint +6 while JSON/audit still described missing/conflicting values. | **Fixed:** synchronized current data and documentation. Prior saved run snapshots remain historical inputs. |
| I02 | The old generic Recovery boolean did not encode alternating components. | **Fixed metadata scope:** right b / left c and the specific alternating exception are now recorded from the corrected source. No component scheduler is claimed. |
| I03 | An initial actor field `disorientation=80` was accepted and discarded; the run still impacted at 230 ms and omitted the status from its initial snapshot. Unsupported action fields could also be ignored. | **Fixed:** unsupported initial state and action-input fields raise `UnsupportedMechanicError`. The legacy Blunt model still rejects these fields; the new controlled 1E1 model explicitly supports and executes initial statuses. Unsupported fields remain errors. |
| I04 | Status output depended on caller Decimal precision: the same input returned `255.8639545` at precision 10 and a longer value at precision 50. Timing could lose a tiny positive fraction before ceiling. | **Fixed:** explicit internal precision/half-even contexts for status, timing, continuous dyspnea, and rational display. Regression checks alter ambient precision and rounding. Gameplay integer event times still use ceiling. |
| I05 | The original engine produced HP −200 and armor −6 in the boundary probe. | **Floors fixed after author clarification:** now HP 0 / armor 0, with nominal/actual/excess recorded separately. Death and damage-credit rules remain open; Q01. |
| I06 | Helpers cover more mechanics than the encounter runner. The legacy model executes one Blunt actor/target/ability family. A second model now executes one stationary 1E1 activation with status evolution and explicit multi-target blast eligibility. Neither establishes general action availability, cooldown enforcement, or full encounter validity. | **Explicit limitation:** passing formula tests does not establish complete 1E5/2E4 combat or 5v5 validity. |
| I07 | Current data has source references but no automatic check that every referenced ODT revision has been incorporated. | **Open engineering improvement:** review snapshots/hash manifest identify this audit's inputs. A future source-drift check would help catch new author edits earlier. |
| I08 | 1E2/1E3/1E5 currently have timing/definition data but lack the defender fields loaded for 1E1/2E4/3E5. Treating a timing-only profile as a defender could raise an incidental missing-key error. | **Fixed validation:** an explicit unsupported/incomplete-defender error now explains the scope. The missing defensive values exist in the sources and can be imported in a later data stage. |
| I09 | Encounter character keys currently double as profile keys, preventing independent copies of one profile from having separate state. | **Open architecture extension:** general encounters should distinguish instance IDs from profile references. This does not require changing damage formulas. |

The original technical review passed 94 tests, and the state-floor clarification stage passed 111. The current rule-update stage adds factor-floor, explicit-resistance, source-revision, required-distance, contact-anchor, and self-effect timing checks; see its saved manifest for the validation result. The preceding 1E1 stage passed **152 tests**, including continuous status-state execution, both blast effects, unchanged Qard armor, overflow, pending timers, explicit area recipients, and per-target summaries. Each prior evidence directory preserves its own inputs and results.

## Suggested clarification order

1. C01–C04, venom factor floors, and explicit shield-bonus policy are closed. Main melee/projectile self-effect anchors above are confirmed.
2. Self mitigation is explicitly bypassed and this is executed for 1E1. Intrinsic same-impact order and precise movement events remain open; extrinsic 1E1 damage does not receive the intrinsic instability penalty.
3. Before venom/slash encounters, resolve exposure/bleeding behavior and 1E5's piercing value.
4. Resolve death/credit, dyspnea/Break, cooldown, healing/revival, and block details for the mechanics being added next.
5. Add spatial and team-event rules incrementally when moving beyond explicit confirmed hits.

You do not need to answer the entire document at once. Supported numerical hit tests can continue within their recorded scope while the next mechanics are clarified.

The latest self-effect exemption passes **154 tests**, including defense-independent self effects, preserved target mitigation, the 200/240 dyspnea self trigger, and the isolated 1E5 150→60→200 ms Gathering regression. The new result directory preserves current runnable code; prior directories retain their own historical code and rules.

The controlled 2E4 stage passes **187 tests**, including exact bleeding/venom integrals, pre-hit snapshots, damage before new self-instability, full lifecycle timing, state floors, unchanged prior abilities, and explicit unsupported-case rejection. See the current focused audit/report; earlier snapshots retain their earlier scope.

Further author clarification resolves fully shielded delivery: every venomous attack contains a slash component; its first factor is post-armor slash damage / post-shield pre-armor slash damage. With d=0 the factor and toxin damage are zero. The shared slash-based ratio, rate, and integral helpers implement this rule; **192 tests pass**. The controlled encounter remains unshielded pending the other shield/continuous-effect rules.

## Controlled 1E1 ability 4: heat

The author confirms Active-start beam timing, growing exposure followed by residual heat, continuous accumulation, unchanged armor, no added self/target statuses, and current armor/heat resistance. These rules now execute for one stationary, unshielded, nonlethal k=2 beam with explicit recipients. Current-defense changes are verified with interval-boundary regression instrumentation; mixed actions are not supported. Exact rational/square-root HP replaces any need to round integrated heat damage. **221 tests pass**. See [the focused heat registry/audit](1E1_ABILITY4_AUDIT.md) and [saved results](results/1e1-ability4-stage/README.md). Shielded heat, overlap/re-entry, interrupts, death and action availability remain outside this stage. Earlier counts and result packages are historical.

## Controlled 1E2 ability 1

The author confirms zero base Gathering, continuous range falloff (5 raw damage per 20 m), and pre-hit armor for target status mitigation. Readying is an automatic weapon cooldown: 360 ms after 40 ms firing, independent of character actions/statuses and blocking no other actions. The controlled model executes one stationary confirmed unshielded nonlethal shot and its full single bleed. It logs a separate weapon cycle; ammo/reload, repeated fire and general action scheduling are not implemented. The stale imported 140 ms Gathering is corrected. Current source changes outside this ability are recorded in [the focused audit](1E2_ABILITY1_AUDIT.md). **254 tests pass**, including prior models; [the result package](results/1e2-ability1-stage/README.md) preserves current source/code/test snapshots and exact traces.

## 1E2 shield/repeat extension

Confirmed and executed: raw shield priority, overflow as slash pre-mitigation d, no shield bleeding, independent additive eight-second HP bleeds, existing bleeding continuing through regenerated shields, finite ready-timed repeat policy, ammo consumption and empty-magazine stopping, and independent per-loss shield regeneration delays sharing one rate. **285 tests pass**. Reload now executes current-O Gathering before 1800 ms Active, overlapping automatic cooldown; it refills the empty magazine and firing waits for both completion conditions. The author confirms no additional Gathering is inserted once an ability is already Active, including continuous abilities; disorientation still reduces accuracy. Exact rational impact results above 12000 bits are explicitly rejected as an engineering limit; no rounding is substituted. See [the focused audit](1E2_ABILITY1_AUDIT.md) and [the latest evidence](results/1e2-repeat-fire-stage/README.md). Earlier packages retain their earlier scope.

## Controlled 1E1 Ultimate: poisonous gas

The current source defines a 300 ms equip, 140 ms Gathering, 180 ms firing, 60 m/s grenade, 1200 toxicity, 5 m radius, 8 s cloud, 10 ammo and 1150 ms cooldown after firing. The author confirms elapsed exposure/residual clocks, gas bypassing shields, unchanged armor, and 110/110 effects once to all explosion recipients. One equip/grenade now executes with explicit single exposure windows, constant resistance, zero initial caster statuses and nonlethal returned runs. Full cloud and residual clocks are preserved when a recipient leaves early. **311 tests pass**; [the source registry and limitations](1E1_ULTIMATE_AUDIT.md) and [saved evidence](results/1e1-ultimate-stage/README.md) cover exact results. Repeated grenades, general geometry/movement, cloud overlap, resistance changes, death, Ultimate cooldown anchor and equip/fire status transitions remain excluded.

## Repeated ten-second comparison

The author selects canonical 1E1/3E5/1E5 targets, repeated use, a ten-second horizon and shielded/unshielded variants. New confirmations: beam cooldown starts at activation; replacement blade grab starts 600 ms after impact, lasts 250 ms, then next thrust Gathering; grenade poison curves are independently additive. 1E5 defender stats are imported from the primary document.

A separate numerical benchmark now executes all six ability families in this passive-target scope, including shielded heat and shielded repeated venom delivery. It uses the same formula helpers with fixed 50-digit numerical arithmetic, rather than expanding exact armor fractions. Thirty-six cases are checked at 80 digits; errors are below 1e-20 in tested metrics. Original exact scoped runners retain their own restrictions. HP depletion is an observation stop, not a death/victory implementation. New losses cannot regenerate in ten seconds. **329 tests pass**; [scope, inputs and complete results](results/repeated-10s-comparison/REPORT.md) describe numerical precision and excluded dyspnea/accuracy/defensive choices.

## 1E1 ability 2: confirmed tether boundary

The author confirms the anchor is the impact position. The ten-metre chain acts as a wall/unavailable region for the chained target's body/hitbox: ordinary movement/dashes cannot cross it, and outside teleport destinations are unavailable. Projectiles and summons are not constrained by the tether. This resolves anchor and boundary policy, not hitbox geometry or failed-action costs. The rule is recorded, not yet an executable movement/binding mechanic; see [the focused tether audit](1E1_ABILITY2_AUDIT.md).

## Shared 1E1 versus 1E2 encounter

Resolved: incoming disorientation during Gathering increases the remaining Gathering; the summoned three-second 1E1 beam operates independently. The shared state/clock now integrates projectile/blast, heat, repeated firearm attacks, additive bleeding and reloads. The saved encounter uses canonical full shields, supplied 10 m paths and a 10-second observation. Dyspnea and hand Recovery eligibility remain excluded; confirmed hits and selected-target area eligibility remain inputs. HP zero ends observation without death/victory inference. Simultaneous coupled state changes remain unresolved and are rejected. See [the stage audit](SHARED_ENCOUNTER_AUDIT.md) and [reproducible results](results/1e1-vs-1e2-shared/REPORT.md).

## Stationary 2v2 integration — 2026-10-25

The later author clarifications now execute in the separate declared stationary
team scope of the same shared engine. [STATIONARY_2V2_SPEC.md](STATIONARY_2V2_SPEC.md)
records the selected abilities, hand poses, overlapping hand Recovery,
phase-specific dyspnea, nearest living targets, inclusive centre-based areas,
simultaneous common defenses/proportional shield allocation, phase/release
precedence at exact ties, original-location attacks after target death, and
death cancelling controlled actions while deployed/released effects persist.
Per-loss shield regeneration includes delayed continuous loss distributions.

The requested 30-second run completes with B_1E1 the sole survivor. **421 tests
pass**; checked final states/death times agree within 1e-20 at 80 digits, alternate
observation spacing and no periodic observations. The earlier duel's complete
trace is unchanged. See [the saved report](results/stationary-2v2/REPORT.md).

Remaining boundaries include returning shield during ongoing heat (explicitly
rejected pending an exposure rule), nearest-target ties in other layouts,
movement/hitboxes/accuracy, broader kits/interrupts, and revival. Historical
questions above retain their stage context; consult the current specification
and PROGRESS.md for the latest scope.

## Approved body collisions — current stage

The six-cuboid standing body, origin and fixed A→+x/B→-x facings are confirmed.
The shared engine now has an explicit body-collision scope using 2 cm spherical
projectiles launched from 1E1's right-hand start and 1E2's left-hand start, aimed
perfectly at torso centre. First-other-living-body hits include friendly fire;
dead bodies stop colliding. Qard marks require actual contacts. Blast spheres
and beam columns apply once to every overlapping body, without limb multipliers.

**461 tests pass**, including 25 geometry and 15 collision-integration tests.
The collision 2v2 preserves its outcome/cadence under numerical checks, while
the complete older point-based 2v2 and 1v1 traces reproduce unchanged. See
[HITBOXES.md](HITBOXES.md) and [the new report](results/stationary-2v2-hitboxes/REPORT.md).
Ground/gravity are the next requested physics stage. Current ground height is
only a placement datum; missed shots have no inferred floor impact or lifetime.


## Terrain extension, 2026-10-25

The earlier body-only stage above remains historical. The current terrain
scope adds author-confirmed finite ground, three fixed 1.8 m cubes and open
sides/top; see [TERRAIN.md](TERRAIN.md) for authoritative conversation
clarifications, dimensions and collision/area rules. Gravity remains
unimplemented. The complete earlier body-only trace is unchanged. The full
suite now passes 479 tests; terrain results are saved separately under
[stationary-2v2-terrain](results/stationary-2v2-terrain/REPORT.md).


## 2026-10-31 shared Block and current author revisions

[Block](BLOCKING.md) now implements attached directional layers, simultaneous
raw sharing, live status bonuses and serial charge recovery; left/right-hand
actions remain independently owned. Released surfaces survive death without
transferring control/bonuses to a later life. Exact expiry/contact, actual area/
heat/venom and pause/life interactions are checked. Nearest-policy exact ties
use stable actor ID under delegation. Both authored 2E4 Block entries/costs
remain visible with one selected family pool. 1502 full-suite tests pass.

[Current 1E5/2E4 author edits](SOURCE_UPDATES_2026-10-31.md) supersede old scaling
bleed/extra-arm/owner-projectile/longer-attachment descriptions; updated metadata
is source-only. Next is the automatic Block reaction and shared timed attack
modifiers. Earlier review entries above retain historical scope.
