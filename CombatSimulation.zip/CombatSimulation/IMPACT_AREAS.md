# Released impact explosions

Author facts: 1E2 Ultimate throws a device that explodes on impact, dealing
900 Qard damage in radius 8 m and adding 250 ms Gathering to everyone hit for
six seconds. Cooldown 65 seconds; Gathering 170 ms, throw Active 200 ms;
projectile initial speed 60 m/s, released after Active; target O/U 500/500;
self O/U 150/190 on throw; Db 1.5; intrinsic momentary throw. Source:
`1E2.odt` overview paragraph 11 and detailed paragraphs 150–172. Author's
existing on-throw convention places self effects at the Active midpoint.

Delegated choices (2026-11-09): reuse the neutral right-hand start/end pose and
2 cm sphere used by other unspecified throws. Common hand Recovery, gravity,
faster-arc aim and swept first-contact collision apply. Check/pay Db and start
the cooldown at throw end; cancelled unpaid throws spend nothing. Preserve
released intrinsic power, including instability reduction, through caster
death, deflection and projectile copies. Carrier contact creates no additional
direct damage: each projectile explodes once, at its actual first body, Block
surface or terrain contact. Empty flight creates no explosion.

The shared instantaneous area path selects each living compound body and each
destructible material HP pool once. Friendly fire and self-hit apply. The
default terrain cubes are area-transparent; explicitly area-blocking material
uses existing witness-cover rules. The explosion uses existing area defense
semantics: personal shields and common simultaneous Qard defenses apply;
handheld Block surfaces trigger the carrier but do not absorb an independent
area packet or receive an invented direct contact hit. Material break in the
same wave does not expose pre-wave excluded recipients. Material damage gives
no character healing credit. Target O/U uses pre-hit defenses.

The modifier is frozen at release and delivered after the entire simultaneous
HP/healing/death wave. A killed recipient gets no effect; a survivor receives
one regardless of personal shield absorption. Its lifetime and repeated-hit
semantics are documented in [TIMED_GATHERING.md](TIMED_GATHERING.md). No dyspnea
or O/U cost is assigned to the released explosion or ongoing modifier.

`combat_sim/impact_areas.py` composes physical projectile contact, current body/
material area queries, immutable released power and the ordinary simultaneous
damage solver. It owns burst deduplication and deferred effect delivery.
`scenarios/1e2_ultimate.json` exercises the actual ability with current defaults.
[Verification](results/1e2-ultimate/README.md) covers the complete 2736-method
suite, 18 ordinary cases, six labelled API probes and 89 exact prior traces.
This completes this ability increment; the six-character Goal remains incomplete.
