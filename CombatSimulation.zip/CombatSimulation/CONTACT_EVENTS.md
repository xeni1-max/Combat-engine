# Committed native contact events

2026-11-02. This shared prerequisite supplies committed physical contact
receipts. The later [3E5 charge](CHARGE_GRAPPLE.md) consumes them for actual
wall-slam delivery; the receipt API itself adds no selectable ability.
Current verification status is in [PROGRESS.md](PROGRESS.md).

## Transaction and authority

The selected optional `body_contact_signals` input declares
`{"mode":"committed_body_contacts_v1"}`. Native contacts already pass the
world's life, surface revision and approaching-reference checks. After that
classification, capture immutable participant lives, actual velocities,
references/body origins, HP/armor/shield/status resistance, bars/statuses and
owned actions. Pin actual grapple groups/links and collider identity, revision,
tags, HP and permanence before collision responses can change control.

The existing native collision, group velocity response and support handlers
still run once. Commit the receipt only after those physical handlers finish.
Its `after` snapshot explicitly means **after native kinematics, before outer
phase settlement**. Later fatigue, interruption and other phase settlement can
still release a hold before a signal handler runs. This is why a handler must
use the committed `before` membership to decide whether an impact occurred
while holding; looking only at a later live group loses that fact.

No subscriber creates no additional queued event or physical knot. An eligible
subscriber queues a same-clock priority 3 signal, after native contacts and before
ordinary decisions. Existing shared batching handles emitted damage in its
causally later wave; the receipt itself applies no damage, costs, movement or
wall removal. Block-counter signals remain their own authored trigger family.

## Observers and committed delivery

An owned observer registers through
`world.contact_signals.watch(id, actor, generation, handler, action_id=...)`.
Its optional `phases` argument defaults to `("active",)`. Registration must
name its current living actor/action. Capture requires an allowed phase and a
contact involving that actor or a member of its actual grapple group. A binding
chain alone does not join that group. Pose-only obstruction is recorded but
does not trigger an impact observer. One callback receives the whole selected
contact wave, preserving simultaneous corners and several participants.

`scope="engineering"` with no action ID explicitly registers an inspection/API
probe. It acquires no resources and invents no character ability. This is not
an alternative legal input for an unimplemented cast. Observer IDs are unique;
dispatch order is canonical, independent of registration order.

Matching at physical contact commits a delivery. Unregistering or losing the
owned action afterward cannot retract the already recorded contact. The
immutable actor/action/life identity does not rebind to a later life. Future
contacts still require a living matching owner/phase. New observers installed
during dispatch begin with later contacts. Mark dispatch before invoking any
handler so a duplicate or reentrant delivery is a no-op.

Handlers still own their real ability profile, legal action/effort phases,
recipient generation checks, shared damage packets and construct mutations.
The dispatcher does not infer an attack from a collision or grant a general
counterattack. Public observer records distinguish owned and engineering scope.
Resolving an already committed impact after its owner dies does not authorize
a new controlled action by that dead character.

## Original 3E5 investigation and subsequent delivery

Source rules remain in `3E5.odt`: 100 ms Gathering, 180 ms grab Active, contact
impact, Db 3, target O/U 400 and self O/U 150, two seconds of +50% movement speed,
first-target grabbing/front holding for eight seconds, 700 blunt wall-slam damage,
conditional wall destruction and 65 s cooldown. Dragging is constriction/tear,
but its DPS and detailed control phases were unspecified in the source.

The linked solver preserves a captured relative reference offset. The actual
charge now uses swept owned hand/grab geometry, including glancing and airborne
targets, without a new position-copy loop or an arbitrary distant link.

An engineering feasibility check shows that an ordinary 12 m/s full-body collision
against a stationary 1E2 gives 3E5 about 649.63 incoming O/U each. That already
reduces the source grapple holding limit to zero, even before listed self
effects. Binding the grab only after that ordinary crash would make a fresh
charge unable to hold. Preserve the general collision/fatigue rules; implement
the ability's actual controlled hand/grab contact geometry ahead of full-body
impact, using the shared swept paths. Wall impacts of an already held pair use
the committed receipts above. [The charge contract](CHARGE_GRAPPLE.md) now records
the delegated grab proxy, movement bonus/expiry, effort and wall-reset rules.
A charge material hook pins qualification and impact power after receipt
preparation, before native response; an absent fractured wall supplies no
intact-wall impulse. The receipt still preserves its pre-fracture identity/HP,
and victim damage dispatches through the normal later causal wave.

[Grapples](GRAPPLE.md) · [Native support](BODY_SUPPORT.md) ·
[Wall identity/durability](DESTRUCTIBLE_WALLS.md) · [Shared motion](BODY_PATHS.md)
