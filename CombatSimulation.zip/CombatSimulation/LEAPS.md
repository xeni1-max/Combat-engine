# Existing leaps and the falling kick

Verified 2026-11-09 through the shared engine. Source facts and delegated
completion choices are distinguished below. The overall Goal is incomplete.
[Evidence and reproduction](results/leaps/README.md).
[Controller](combat_sim/body_leaps.py) · [Native flight](combat_sim/airborne_combat.py).

## Author facts

1E1.odt p7/p99–112 gives initial speed15m/s,9s cooldown,Gathering140ms,
Active jump250ms,Db3.5,intrinsic momentary effort,takeoff selfO/U150/150 and
landing selfO/U170/190. This is distinct from the basic jump.

3E5.odt p13/p122–142 gives initial speed20m/s,2.85s cooldown,G140/A250,
Db3,intrinsic momentary,launch self150/150,landing self180/220. The kick hits
the first target while falling for600 Blunt and targetO800/U1200,knocking it
downward. Author clarification treats knock down as directional displacement,
separate from prone/Get Up. Impact occurs at real falling contact or landing.
Gravity9.81m/s²,friendly fire,source/recipient lives and common defenses apply.

## Delegated launch controls

Speed means the magnitude of supplied takeoff velocity. The simple default
control is forward at45degrees to the horizontal,using body heading at launch.
It requires no enemy. Existing explicit world/surface targets instead select a
frozen desired feet landing point; solve the fastest upward fixed-speed arc at
takeoff. Unreachable/non-upward targets cancel before payment/cooldown. These
are elementary scripted controls,not advanced NPC aiming.

Takeoff at Active start pays the one listed Db,starts cooldown and applies
takeoff statuses. G140/A250 remain unchanged. Own locomotion/lower-body control,
retain hands with no fabricated Recovery,and permit independent upper actions.
The supplied speed replaces current horizontal drive; prior independent ground
pace resumes on landing. Sprint becomes running without an extra exit gesture.
Running applies its existing Gathering/self-status multipliers. Native gravity,
contacts,grapples and tethers determine actual flight,not an authored landing
timestamp. Life-bound landing debt survives cancelled control/transport but
not death/restoration. The motion cause is leap,not dash for the counter rule.

## Controlled falling contact

1E1's control ends after250ms Active; physical flight and landing debt continue.
3E5 retains its lower-body owner after launch Active,waiting for actual physical
descent. It then requires attack function and enables one controlled foot volume.
An earlier short-arc landing does not invent a kick after landing. This phase
has no extra unlisted Db/Gathering or sustained effort. Intrinsic power samples
current instability at contact,not takeoff. Source death or lost control cancels
the unreleased kick while compatible flight/owed landing remain physical.

The reusable owned volume supports a fractional body-part anchor,following the
actual lower leg face as its centre and height deform. The selected kick proxy
is0.1m high inside the feet and spans both standing legs' width/depth. It adds no
body deformation/animation. Continuous relative motion and pose derivatives
locate the first body,Block or material contact,with downward face ordering and
stable identity ties. One contact consumes the kick; friendly/material hits
are possible. A pause/reversal of descent withdraws the volume and rearms only
if descent resumes before contact. There is no horizon-based gameplay expiry.

The ordinary simultaneous damage/HP/shield/armor/status/revival pipeline applies.
The source omits downward knock amount; select15m nominal over500ms,matching
the existing3E5 knock family. Use summed-stat actual grapple resistance and one
shared downward increment,zero elasticity and native contacts. Floor contact
can immediately absorb that motion. Do not add a forced-prone flag: the existing
balance/status system decides falling and Get Up separately. This amount and
duration are delegated choices,not newly attributed author numbers.

## Integration boundaries

The [native angular owned path](TURNING_CONTACTS.md) now follows source/target
turns through the actual descending foot contact. Flight retains its frozen
takeoff intent; body yaw does not introduce air steering. Ordinary missed-kick
ground contact and landing debt remain physical and once-only. The subsequent
[field extension](TURNING_FIELDS.md) integrates field membership and cover;
[angular support](ANGULAR_SUPPORT.md) now integrates departure/landing. Active
linked response and prescribed angular climbing remain guarded.
Scripted target points are landing intent,not a guarantee against moving targets
or intervening geometry. No air steering,new ability,extra fee or arbitrary
global action exclusivity is added. Tests/captures and completed/remaining work
belong in PROGRESS.md and results/leaps; older sealed evidence remains immutable.
