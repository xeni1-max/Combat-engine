# Conditional melee branches, motion causes and the upward counter

Shared-world delivery, 2026-11-01. **3E5 ability 1** is now one selectable
ability with normal b/c punches and conditional upward branch a. No separate
selectable counter or new character ability is added.
[Branch coordinator](combat_sim/conditional_melee.py) ·
[Shared melee](combat_sim/melee_combat.py) ·
[Evidence](results/conditional-melee/README.md).

## Primary definitions

`3E5.odt` p3–p9/p50–p95 defines a against a target dashing or knocked toward
the actor; otherwise alternate b/right and c/left. Normal punches deal 300
blunt, use G140/A180 with midpoint impact, Db1.8, target and self O150/U150.
Consecutive alternating Gathering begins immediately after the previous Active.
The counter deals 600 blunt and knocks 15 m upward, using G180/A220 midpoint
impact, Db3, target O800/U800, self O200/U200 and **4 s cooldown after Active**.
All branches are intrinsic momentary. Source ODTs remain unchanged; the legacy
controlled 1b scalar runner remains a separate preserved historical scope.

`Contextual abilities.odt` supplies examples, including an explicitly specified
alternate c when an execution becomes invalid before impact. It supplies no
universal re-evaluation policy. That example does not add another 3E5 move;
the pinned policy below resolves this concrete kit's unspecified behavior.

## Delegated selection and pinned actions

The current interpretation requires actual **relative closing motion** for
both dash and knock conditions. Query current body velocities and centre-to-
centre direction, including vertical motion. Ordinary walking/running or an
engineering velocity does not become a dash/knock merely because it is fast.
The later [charge](CHARGE_GRAPPLE.md) is a delegated dash-family cause only
while actively controlling its forward search/grab, recorded as `charge`.
Residual speed bonuses and ordinary running do not qualify.
A grapple component shares its currently documented motion causes, just as it
shares its physical movement. This interpretation and normal fallback policy
are engineering choices, not extra author definitions of NPC intelligence.

A real dash's flight carries an internal life/action-bound cause, independently
of its landing obligation. Reference-only relocation preserves that cause;
velocity replacement clears it, while retaining owed landing effects. Actual
landing ends dash flight. Live knock components provide knock cause, including
an upward ballistic flight until support is established. The predicate also
requires actual closing velocity; a cancelled net knock or an away dash does
not trigger the counter. A pending landing obligation alone is not a cause.

When the condition, private cooldown, required functions/hands and current
capacity permit a, prefer it. Otherwise use the next legal normal-cycle branch.
Normal punches remain available during the counter cooldown instead of locking
the entire ability for four seconds. Pin the selected branch when acquiring the
action: hand, damage, cost, timing, self/target effects and knock all follow that
identity through Recovery/Gathering/Active/emission. Later movement, cancellation
of the target's motion or an advancing cycle cannot reselect a pending action.

Normal emission advances b→c→b even on a whiff. Counter emission leaves that
cursor alone. Consecutive normal branches retain the source Recovery exception;
an intervening counter ends that continuation. No authored hand coordinates
exist, so use the existing neutral right/left poses and 1 m/2 cm timed capsule.
Real first body/solid/Block contact decides the hit. Own on-impact instability
is added after release power is captured. Branch-aware definitions also feed
solid damage, status mitigation, payment and owned resource reservations.

## Counter cooldown as committed work

The private `component:1:a` clock is a resource, not another selectable ability.
At successful Active-start payment, commit one deferred 4000 ms cooldown start
at that action's original Active end. Gathering cancellation/payment failure
creates no debt. Cancellation after payment retains the original start boundary,
including a whiff or interruption before midpoint emission; cancelling control
cannot bypass the committed cost/cooldown. This cancellation policy is delegated.

The ordinary cooldown clock begins only when the Active tail has elapsed.
Area pauses affect cooldown work after that boundary; they do not delay Active
itself. The pending commitment prevents a second counter before work starts.
An interrupted action's stale completion event cannot cancel/duplicate the debt.

Existing actor-wide cooldown retention across death also applies here. A debt
can become due while its clock is stopped: commit the work without resuming it.
Revival resumes ordinary remaining work with current area membership. A revival
before the deferred boundary also retains the commitment. This is a resource
receipt, not an old-life controlled action: no attack, hand owner or projectile
is replayed. Existing immediate clock starts still reject an implicit restart
while stopped; the deferred coordinator explicitly authorizes this commitment.

## Upward physics and deflection

The author's [summed-stat grapple rule](KNOCKBACK.md) and existing post-hit/life
ordering apply. Compute resisted height P2 using pre-batch maximum HP/current
armor, then add upward speed `sqrt(2*g*P2)`. This is nominal apex rise from rest;
existing vertical velocity and later collisions can change actual height.
Gravity remains 9.81 m/s². No horizontal 500 ms distance window is copied into
vertical motion, and no later timer subtracts the initial upward impulse.

At impact, the delegated counter response removes the approaching horizontal
component along source→target before lifting, while preserving lateral motion.
This represents the counter's deflection rather than letting the incoming dash
continue through its caster. Project the corresponding older knock components
too, so their later expiry cannot reintroduce cancelled approach velocity.
Deflection is part of the attack, not an extra invented collision/status hit.
It is a documented, reversible choice under the author's delegation.

Apply one physical launch to the current living grapple component without a
second weight division. Each participant keeps a life-bound ballistic receipt;
release of the grapple does not remove momentum. Existing gravity, terrain/body
sweeps and individual contact penalties remain authoritative. A ceiling can
remove upward travel, after which gravity produces the fall. Other active
elasticity still composes under the existing maximum-coefficient rule.

Ballistic receipts close on actual support contact, velocity replacement or
recipient death. Released source death does not erase a survivor's motion.
Basic-jump and dash landing obligations survive the counter and are consumed
once at actual landing; it grants no new jump cost or landing self effects.

## Verification and remaining work

Actual heavy-knock, dash, away-dash, normal run, held-pair, Block, ceiling and
pause-area cases exercise selection and delivery. A normal-right punch followed
by a counter verifies that the right-hand counter stays pinned while the normal
cursor points left. Engineering restriction/restoration controls verify the
deferred debt, and velocity/reference controls distinguish cause from obligation.
The near-apex check uses a legal integer-ms observation against the independent
closed-form gravity path.

Subsequent [chain](CHAIN_CAST.md), [charge/wall slam](CHARGE_GRAPPLE.md),
[living-body support](BODY_SUPPORT.md) and [prone/Get Up](EQUILIBRIUM.md)
increments extend this foundation. Leap/falling kick, broader turning and
static ledge departure remain unfinished. Binding retains its taut-length
behavior; it is not a rigid grapple. Consult [the current index](ENGINE_STATUS.md)
for the six-kit/5v5 boundary. Advanced NPCs and mass experiments stay deferred.
