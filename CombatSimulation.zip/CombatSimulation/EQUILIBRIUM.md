# Equilibrium, prone geometry and Get Up

The source `Collision details.odt` adds loss of equilibrium while disoriented
and unstable, with `tF = 1500 / (1 + (O + U)/400)` ms.
[Source comparison](SOURCE_UPDATES_2026-11-02.md). The source supplies that
formula; the integration choices below are **delegated engineering decisions**.
Current input selects `equilibrium.mode = status_balance_v1`.

## Balance clock

Both O and U must be positive. Progress q integrates `1/tF` with their live
values and existing decay of one unit/ms. Between actual status changes,
using seconds from the interval start:

```text
q(t) = q0 + (400 + O0 + U0)/600 * t - 5/3 * t²
```

Split at the first status reaching zero, a geometry boundary, or q reaching
0/1. Before a completed fall, partial progress recovers at the formula's
zero-status base rate, 1/1500 per ms, when either status is zero. Completed
knockdown requires paid Get Up. Example: O=U=200 gives q=0.2 at 200 ms and
recovers by 500 ms; O=U=1000 first reaches full knockdown at approximately
283.484861 ms. Observation timestamps do not select these intervals.

An explicit `apply_knockdown` effect sets the down flag and forces the remaining
fall at the impact-time 1/tF rate. This is a shared effect API, not an invented
character attack. Natural balance loss uses continuously decaying statuses.

## Shared body geometry

Keep six part identities: head, torso, two arms, two legs. The prone endpoint
exchanges each part's local forward/vertical dimensions, with the head toward
the fixed facing. It is a declared collision proxy, not rigid rotation or an
animation. Full prone height is 0.3 m for the current bodies. Intermediate
proxies can change volume; they are not an articulated-body physics model.

Standing, crouched and prone proxies use convex weights:

```text
prone = q; crouched = min(c, 1-q); standing = 1-q-min(c,1-q)
```

Here c is the existing nominal crouch channel. This retains authored linear
crouch timing and allows balance loss during crouching without cubic geometry,
pose immunity or cancelling a harmless common action at its self-status event.
Shift the combined proxy vertically so its lowest part stays on the translated
reference plane. Part/envelope and weight changes split the geometry polynomial.
The engine's `feet_z_m` remains that lowest support plane, including when prone.

Saved body paths retain sole ownership of translation. Centre and full-size
velocity/acceleration describe the separate pose. Body sweeps, straight/curved
projectiles, whole-owner clearance, Block surfaces and fields consume those
same coefficients. Size enclosures check interior extrema; equal endpoint
sizes alone cannot hide an intermediate bulge or separation.

Canonical authored hand poses remain unchanged. World hand points use the same
floor shift and convex pose law, mapping vertical offsets into the prone height.
Physical hand Recovery measures those mapped positions at the request boundary.
Block follows the upper body; its prone centre retains 0.25 m clearance ahead
of the foremost prone part, with its authored surface dimensions unchanged.

Climb reach still checks the actual body origin once at Active start. The
approved climb path and ongoing attachment follow the saved translation
reference, so its own balance deformation is not external displacement.
Actual imposed motion, obstruction or target removal still interrupts it.

**Handler consistency correction, 2026-11-03:** the contact coordinator's
`pose_only` classification is authoritative for movement intents and climb
interruption as well as physical impulse response. A wall can freeze balance
deformation while the saved reference continues tangentially along a legal
climb. Early handlers must forward the contact to posture freezing without
consuming that intent or cancelling the climb. Genuine closing reference
contacts keep the normal physical interruption path. This fixes review N2
without changing the pose law or contact tolerances; current-input regressions
and 1 ms read-only body-clearance audits cover the affected cases.
[Evidence](results/principal-review-fixes-2026-11-03/README.md).

## Actions, clearance and lives

2026-11-13 correction: Get Up and ordinary stand clearance now pass the current
distance/speed/acceleration resolutions to the existing stationary-face tangency
predicate, as native body contacts already do. A stationary touching face with
sub-resolution roundoff cannot block recovery; real inward motion and genuine
obstruction still use the continuous sweep. An actual turning grappling-gun
landing beside a wall reproduced precision-dependent Get Up/payment before this
correction. [Evidence](ANGULAR_LINKS.md).

At full natural knockdown, cancel controlled actions except the independent
common binding/grapple Break channels. Stop voluntary ground drive; retain
native flight, finite forces and transmitted inertia. Already released
projectiles, bleed, deployed beams, marks and other autonomous effects retain
their own lifetimes. An interrupted controller's owned hold ends normally.
Another actor falling does not arbitrarily cancel that controller's hold.
Actual grapples still use summed stats for knock resistance; tether-only
actors do not join that assessment.

Get Up is the existing ability: Active = 2 × numeric Recovery; Db = 2 × basic
jump Db, then the current action-cost formula. No Gathering/extra hand Recovery.
Derive it from supplied actor and basic-jump definitions, with no filesystem
fallback or independently editable computed copies. Explicit Get Up definitions
remain accepted. The current API requires supplied jump/body/owned-posture/saved
path inputs; the CLI selects those current inputs automatically.

The paid Active linearly reverses current q and nominal crouch to standing.
It counters passive balance loss while controlled, without erasing O/U. Later
balance loss can recur if sufficiently strong statuses remain. Death, new
explicit knockdown or physical obstruction interrupts; paid effort is retained
and another attempt requires the full Active/cost. Get Up occupies locomotion;
it does not invent a global persistent-effect lock.

Before payment, sweep the complete pose against current living bodies and
obstacles. Ordinary crouch-to-stand checks its nominal change at the current
balance pose; live contacts resolve subsequent motion/status changes. Blocked
pose deformation freezes at contact. Static unchanged cover waits for a real
registry/driver change, without resource charges or repeated 5 ms polling.
Moving blockers/own motion use independent 5 ms retries; status expiry can wake
partial balance recovery. No sliding through cover or implicit teleport occurs.

A dead body's physical pose freezes and stops colliding. Restoration retains
that legal pose, starts a fresh life-bound balance clock and cannot complete an
old life's Get Up. A retained down flag prioritizes Get Up even when weapon
policy starts later; initial down states use the same priority.

## Inspection and versioned verification

Results expose `equilibrium_intervals`: actor/life/revision, driver, source O/U,
exact rational progress/velocity/acceleration and planned versus committed
interval ends. Geometry root brackets use progress tolerance 1e-42 at standard
precision; upward clock rounding is below current body-contact resolution.
Existing curved-projectile numerical tolerances remain their own limits.
No universal temporal accuracy, energy conservation or rational-size guarantee
is claimed.

Definitions without `equilibrium` retain their selected prior behavior.
Ten earlier numerical/phase test modules explicitly select the preserved
pre-equilibrium v2 input; current default coverage is separate and explicit.
[Get Up rules](GET_UP.md) · [Evidence and reproduction](results/equilibrium/README.md).
All 4407 prior result files and fourteen current primary ODTs are fingerprinted;
no historical manifest is refreshed and no primary source is edited.
