# Persistent projectile entities and contact policies

**Current extension, 2026-11-09:** [actual 1E3 Ultimate](PROJECTILE_DUPLICATION.md)
now supplies owned casting, continuous cylindrical entry and atomic symmetric
4m splitting. The shared copy/split branch preparation retains original lives,
power, accuracy, utility payload and accumulated travel. Rebased originals keep
`birth_kinematics` for inspection; revisions invalidate old predictions. Actual
endpoint impacts, overlapping fields, death/restoration and injected construction
failure are verified in [the checkpoint](results/projectile-duplication/README.md).
The following 2026-10-28 foundation records retain their historical scope.

Verified **2026-10-28** in shared physical-flight scopes. Projectile identity
now exists independently of the controlled action that released it. This is
the first A2 increment from the
[principal engineering review](PRINCIPAL_ENGINEERING_REVIEW.md), not completion
of dynamic world objects or the affected character kits.

## Sources and delegated choices

Existing guns/Qards retain the author's first-other-living-body collision,
friendly fire, owner exclusion, actual traveled-distance falloff and persistence
after death. Those default behaviors are unchanged. At this 2026-10-28
checkpoint, `2E4.odt` described owner-contact consumption followed by an area
attack. The author's [2026-10-31 revision](SOURCE_UPDATES_2026-10-31.md)
removed that ability identity; its generic contact policy remains an engineering
capability, not a current ability awaiting delivery. `1E3.odt` p11 describes entering allied
projectiles duplicating and separating by3m at that historical checkpoint.
The [current author revision](SOURCE_UPDATES_2026-11-02.md) changes the radius
to12m and separation to4m, implemented above. Paragraph indices are zero-based.

Identity layout, launch immunity, copying ancestry, contact response plumbing
and trace compatibility below are **delegated engineering choices**. They do
not add character abilities. At the original checkpoint the actual field
was unfinished. Its current authored delivery is verified above; the earlier
engineering probes below retain their explicit fixture/profile scope.

## Identity and lifecycle

[ProjectileRegistry](combat_sim/projectile_entities.py) allocates encounter-local
`projectile:N` IDs independently of action IDs. An immutable identity stores
owner, source ability, parent action, creation time, parent projectile and root
projectile. Multiple independent flights can share an action and attribution.
Completing/cancelling that action or killing the owner does not remove them.

Each flight has its own state and revision. Impact/stop/owner-clearance events
carry entity identity and revision; stale predictions are ineligible. Terminal
transitions are idempotent. A parent hit/removal does not end a child flight;
its own contacts and stopping event remain independent. Numerical contact
confirmations are retained across rounding only for the same live revision.
Completed flights no longer appear to have live future stopping events.

Kinematics reuse the existing straight/gravity engines. No new ability-specific
inheritance layer was added: [SharedProjectiles](combat_sim/projectile_world.py)
composes the registry with the shared world. Stationary body flights also get
internal identities; their fixed candidate lists retain the earlier geometry
scope and no-scene-contact pending states. Historical point-based/confirmed-hit
runners still use their earlier event-only representations.

Current moving inputs select `projectile_entities.trace_schema=entity_v1` in
[combat locomotion data](data/movement/combat_locomotion.json). Records expose
`id`, `action_id`, `actor`, `ability`, creation/release times, ancestry, revision,
policy, owner-clearance time and duplication sources. `released_at_ms` preserves
the original release; `trajectory_started_at_ms` locates the current segment.

## Explicit contact policy

Optional `projectile_geometry.contact_policy` has exactly these fields:

| Field | Supported values | Meaning |
|---|---|---|
| `owner` | `ignore`, `impact_after_separation`, `consume_after_separation` | Permanent exclusion, ordinary owner impact, or consumption after launch immunity |
| `other_bodies` | `impact`, `ignore` | First other living body consumes the impact, or is passed through |
| `terrain` | `impact`, `ignore` | Scene terrain consumes the impact, or is passed through |

Absence selects the existing gun/Qard default: owner ignored, other bodies and
terrain hit. Non-default policies require moving combat and are validated before
any action executes. Stable object/part identity breaks equal declared contact
times; a projectile is consumed once. Dead bodies remain excluded.

Owner-enabled shots born outside every owner cuboid are immediately eligible.
Those touching/overlapping the owner remain immune until their sphere leaves
the **union of all six cuboids**, after which owner contact stays armed. A
continuous separation query accounts for body translation/acceleration and
linear posture deformation; it cannot arm merely because an observation occurs
or because the projectile exits one overlapping part.

[projectile_clearance.py](combat_sim/projectile_clearance.py) proves intervals
remain intersecting using trajectory acceleration enclosures and moving/resizing
box bounds, subdividing uncertain intervals to a positive clearance witness.
This finds exit/re-entry even when both query endpoints are inside. Tangency
remains immune. An unresolved numerical boundary fails explicitly.

Owner clearance uses binary64 numerical geometry with 1e-12 s time and 1e-14 m
clearance tolerances in straight mode; gravity uses its supplied contact controls.
Its event rounds up to 1e-6 ms, or the gravity event quantum. Reached confirmation
survives intervening subquantum boundaries and Decimal/binary64 endpoint rounding.
These are numerical diagnostics, not certified exact-ODE error bounds. Ordinary
straight contact mathematics remains rational/Decimal. See [GRAVITY.md](GRAVITY.md).

Consumption records `projectile_owner_consumed`, ends only that entity and
applies no ordinary impact damage. Consumption alone does not emit a secondary
attack. The former 2E4 ability 4 has been superseded; these policies do not
reinstate it or invent an automatic attack.

## Copying without duplicated action costs

The shared API `encounter.projectile_system.copy(entity_id, source=instance_id,
offset_m=(x,y,z))` creates one independent flight at an explicit world boundary.
It preserves owner/ability/action attribution, current momentum, radius,
acceleration/gravity law and **actual distance already traveled**. The offset
creates the new entity at that position and does not count as traveled distance.
It does not re-aim, restart an action, spend ammo/dyspnea or reset damage falloff.
Each new projectile gets its own birth-owner immunity and terminal event.

Each branch records field-instance IDs that already copied it. Both parent and
child inherit the newly consumed source, so exit/re-entry or descendant copying
by that field cannot recurse. Different field instances can each copy branches;
no arbitrary global exclusivity is imposed. Source IDs must identify an effect
instance, not just an ability or character. Copying an already terminal or
numerically inert flight returns no child and consumes no new source. An
undecelerated ballistic apex is still active and can be copied.

The copy API currently creates an explicitly supplied offset. Autonomous field
entry, allied eligibility, exact split direction/placement and area lifetime
belong to the forthcoming authored field/volume implementation. The probes
verify real shared-engine copied contacts without claiming that field exists.

## Historical evidence and verification

Simulation lookups always use entity IDs. Frozen inputs lacking the new trace
declaration select the named `action_linked_v1` **presentation adapter**, which
projects old one-projectile/action identifiers without altering live state.
Copying requires the current entity trace because a legacy action-linked ID
cannot represent multiple flights unambiguously. Historical files are unchanged.

One reporting correction is additional to F1–F5: the old moving-gun duel listed
14 obsolete future stop events for already collided flights. Current pending
events exclude them. The new
[historical comparison](results/projectile-entities/compare_historical.py)
removes only those provably terminal pending stops from the expected snapshot;
all states, actual events, calculations and numeric outcomes still compare.
Earlier strict comparison scripts retain their original checkpoint behavior.

**980 tests pass**, including 37 new checks: 17 entity/geometry, 18 shared combat
and two numerical boundary regressions. Four new complete traces replay exactly,
including ordinary combat through the public CLI. Prior ownership/climb traces
still replay exactly with frozen inputs, and the review's five checks pass
unchanged. [Evidence and commands](results/projectile-entities/REPORT.md).

The subsequent [world collider increment](WORLD_COLLIDERS.md) implements compound
HP/lifetime, blocking policy and contact invalidation (1022-test checkpoint).
The subsequent [typed heat increment](SPATIAL_EFFECTS.md) brings the suite to
1066 tests, with moving exposure and continuous cover damage. Actual duplication,
prison, owner-contact, other moving areas, pause and revival interactions remain
unfinished. Next resolve ongoing heat/shield regeneration. Full kits/general
5v5 remain unfinished; advanced NPCs and mass experiments remain deferred.
