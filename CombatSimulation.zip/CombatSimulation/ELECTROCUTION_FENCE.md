# 1E2 ability 5: segmented electrocution fence

Verified 2026-11-09: all 2701 methods pass in 782.064 s, including 43 new
geometry/field methods. Twenty complete API/CLI/hash/numerical cases and six
labelled API probes reproduce; 63 prior complete traces remain exact.
[Evidence](results/electrocution-fence/README.md) · [Public scenario](scenarios/1e2_fence.json).
The full six-character/5v5 Goal remains incomplete.

Author facts: `1E2.odt` p13/p175–186 gives 800 electrocution damage/s,
six seconds, cooldown nine seconds, Gathering 140 ms, Active 160 ms, binding
value 2, and five independently destructible four-metre parts, total 20 m long
and 1.5 m high. Each part takes 1500 non-toxin/non-electrocution damage.
The detailed 20 m rule supersedes the older 15 m overview under delegation.
The author's clarification gives summoning no dyspnea cost.

Delegated implementation decisions:

- Summon at Active end; commit cooldown at activation selection, like the
  existing marking area. Use the neutral left-hand start/end pose, requiring
  that hand, upper body and attack function during controlled work. The
  activation is extrinsic momentary; the released field has its own lifetime.
- Freeze the selected target's feet location at selection. Explicit world or
  surface point targets specify the fence's lower centre and allow use without
  an enemy. Orientation selects world x or y along the panels; default is
  across the caster's cardinal facing. This version uses the world's existing
  axis-aligned material geometry. Arbitrary rotated material needs its shared
  geometry support, rather than an enlarged damage box.
- Each panel is 4 m × 0.1 m × 1.5 m, has its own HP and expiry, and intercepts
  projectiles. The electrical screen is body-permeable and area-transparent:
  movement prevention comes from its binding, and summoned placement may
  overlap bodies. It adds no ordinary solid-collision impulse or cover bonus.
- Any sustained contact with a living body part conducts, including friends
  and the caster. Multiple parts/panels of one fence apply 800/s once. Separate
  fences remain independent. Actual curved translation and changing posture
  determine contact; observations do not sample damage. An isolated tangency
  with no exposure interval adds no damage or lasting restriction.
- One contact episode applies a lower-body movement binding, B2, and one
  released electrical stream through the common shield/HP solver. Its lifetime
  is bounded by contact and the field. Common Break releases that binding and
  retains escape work. It does not grant damage immunity. Continued contact
  does not instantly rebind; a later exit/re-entry starts a new episode.
- Loss of all contacted panels ends damage and binding. Destroying one panel
  while another still contacts the body preserves the episode and its Break
  progress. External displacement may leave contact; the binding constrains
  voluntary drive, rather than gravity or imposed momentum.
- Source death/action cancellation after deployment preserves panels and field.
  Recipient death retires its episode; restoration inside a surviving field
  receives a fresh one. Neither episode nor source attribution crosses lives
  by reassignment. Material lifetimes and damage-type immunities use the shared
  collider registry. Primary character/source documents remain unchanged.

The binding does not impose an extra disorientation/instability, effort charge,
or unrelated attack restriction. [Electrical damage](ELECTROCUTION.md),
[common Break](BINDINGS.md), [owned actions](ACTION_OWNERSHIP.md) and
[material objects](WORLD_COLLIDERS.md) retain their own rules.

The first public walking/Break test exposed an entry-root issue: a midpoint
approximation could remain infinitesimally outside, then lose contact when the
binding stopped approach velocity. Box-field boundaries now use the isolated
root's upper bracket with upward rounding at the declared precision, including
conversion to the absolute clock. The existing root resolution and strict
geometry guards remain. This selects a certified side of the same boundary;
it adds no gameplay time delay, position snap, or arbitrary tolerance. Existing
column membership retains its previous midpoint policy.

The first full regression also caught an unnecessary global gravity condition
on this box/contact coordinator. That condition disabled the existing straight
projectile Aim scenario even without a selected field. A second test removes
the released-rate rules to verify their explicit API guard; field dependencies
also blocked that unrelated world. The coordinator now validates its mode on
construction and checks paths, bindings, released rates and materials when a
field is selected. Its box contact does not require gravity. Actual field placement/contact is checked in that
existing straight ground world. Projectile targeting retains its own physical
flight requirements. No existing Aim test is rewritten.
