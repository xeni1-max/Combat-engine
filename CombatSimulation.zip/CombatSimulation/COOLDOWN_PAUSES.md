# Cooldown work and pause areas

**After-Active extension, 2026-11-01:** [3E5's conditional counter](CONDITIONAL_MELEE.md)
commits a private 4 s cooldown start at its original Active end after successful
payment. Pending starts are independent resource receipts, so later control
cancellation cannot bypass them. Work begins at that boundary and inherits area
pauses then. A due debt may be committed into a stopped clock without resuming
it; ordinary immediate starts still reject stopped clocks. Death freezes work
and restoration reconciles current membership. Both sides of the deferred
boundary are verified with explicit engineering life controls.

Verified in the shared engine, 2026-10-28. Current definitions opt into
`cooldown_clocks.mode=remaining_work_v1`; frozen inputs retain explicit absolute
readiness. The existing 1E2 ability 2 now deploys its independently active pause
area. **Cooldown checkpoint: 1159 tests passed**; full verification and evidence are in
[the report](results/cooldown-pauses/REPORT.md); this is not full six-kit completion.

## Source and selected engineering rules

`1E2.odt` p5 defines ability 2: mark an 8 m radius area for 4 s, pausing
cooldowns inside, with a 9 s cooldown. The source revision inspected on resume
specifies Active 200 ms at p86 and “extrinsic momentary” activation at p88.
The earlier captured source listed dyspnea 0.5. There is no specified Gathering, hand pose, deployment
anchor, height, cover/team filter or cooldown-start anchor.

Under the author's delegation, use zero base Gathering, a left-hand
marking gesture at the standing rest pose, and deployment at completed 200 ms
Active. Snapshot the selected target's torso location at activation request;
finish at that location even if the target moves/dies. Start the 9 s cooldown
at activation request, consistent with the existing independent summon.
Use an area-transparent vertical cylinder and any living body-part overlap,
once per actor, including allies/caster. A point tangency without an interval
does not acquire a pause; persistent contact does. Lifetime is half-open.

The new author preference exempts effortless area marking from dyspnea. Its
delegated application to this activation preserves the older listed 0.5 as
source history. The subsequent primary-source revision now labels this activation
extrinsic momentary, consistent with that exemption. Preserve the original
capture manifest and record this revision; do not silently replace the old source
hash. The new label does not alter verified timing, cost behavior or geometry.

## Shared architecture

[CooldownClock](combat_sim/mechanics/cooldown.py) stores remaining work, a
reference time, independent pause-source IDs and revision. While unpaused,
`remaining(t)=max(0,remaining(reference)-(t-reference))`; a paused/stopped clock
keeps its work. Ready abilities can activate inside a field; newly started
cooldowns retain its pause sources. One field leaving/expiring cannot resume
work still paused by another. Starting an unfinished cooldown is rejected.
Queries/records do not consume work or mutate revisions. Invalid mutations
fail before altering progress, and state records are detached snapshots.

[CooldownFields](combat_sim/cooldown_fields.py) composes clocks with actual
actions and typed `CooldownPauseArea` instances. Policy readiness consults this
controller; authoritative activation/firing anchors start work once. A paused
unfinished clock has no assumed readiness timestamp: serialized
`ability_ready_at_ms` is null and `cooldown_clocks` records remaining work and
all pause-source IDs. A ready clock can still activate, even while its source
set is nonempty. Current summaries expose volume source/lifetime/membership.

Actual entry/exit/expiry invalidates obsolete policy waits and requests a fresh
decision. Per-source membership is idempotent. Same-timestamp field handoff
cannot grant progress or run a decision between source updates. Current body
geometry, pose/velocity and rational column roots supply exact membership
boundaries at the established 1e-24 ms geometric resolution. Open-cell settling
occurs before decisions and after physical changes, including at the horizon.
It does not advance gameplay time. No polling ticks, synthetic delays or
inspection of future commands is used.

Pause ability and automatic weapon cooldowns. Action Recovery/Gathering/Active,
reload, projectiles, effect lifetimes, status decay and shield-loss delays keep
their existing clocks. Deployed areas survive caster death; dead recipients'
cooldowns stop at death and retain that recorded work. Subsequent field cleanup
cannot resume a dead clock. Current [life transitions](LIFE_CYCLES.md) explicitly
resume remaining work on a new life and reconcile live/expired pause sources;
death alone does not resume a clock. Frozen inputs retain terminal death.

The mark occupies its left hand and its ability resource, requiring upper-body
and attack functions. Permitted body movement can overlap; gun/reload uses the
same left hand and waits. Cancelling the controlled mark before Active completes
creates no area. After deployment, the area holds no hand lock. Other body and
weapon eligibility/cost/phase rules retain their existing authority.

## Verification and limits

Eleven primitive clock tests and nineteen shared-combat tests cover actual
casts, weapon/ability cooldowns, ready activation inside a field, overlapping
sources, exact field handoff, moving entry/exit, reload, cover, jump, full-dyspnea
activation, death and heat/shield recovery. Ordinary API/CLI captures preserve
eight scenarios, without injected operations. Precision, observation and actor
order controls preserve checked outcomes. The original review regressions and
prior frozen captures remain applicable; [the report](results/cooldown-pauses/REPORT.md)
records final commands/results.

Fractional exit resumes fractional remaining work. A later zero-base Gathering
still uses its established phase ceil; that does not round the cooldown itself.
The geometry/Decimal/trajectory error limits remain those of the existing
shared engine; this increment claims no new certified ODE bound or platform-wide
bitwise identity. Multiple clock sources compose exactly within those inputs.

This supports selected existing 1E1/1E2 actions on the common coordinator.
Other kits must route future cooldown/recharge work through these clocks;
adding a clock alone does not implement their delivery. The subsequent
[HP ledger](DAMAGE_LEDGER.md), [actual revival](REVIVAL.md) and
[healing](HEALING.md) now execute on this foundation. Fixed facing and broader
support/Get Up geometry guards remain.

**Rechargeable Block stock, 2026-10-31:** `RechargeableCharges` uses one clock
for serial missing-charge work. Spending appends work without losing partial
progress; each 4500 ms restores one of four Block charges. Full idle stock
banks no work. Available stock remains usable inside pause fields. Remaining
work stops at death and resumes with current membership on restoration. This
does not convert revival's finite three-stock policy into rechargeable stock.
Actual overlapping pause areas and old/new lives are checked in
[Block evidence](results/block-defenses/README.md).

[Automatic counter stock](COMBAT_REACTIONS.md) now uses the same work model
with capacity 1 and 9000 ms refill. It is distinct from the four Block charges.
Ready stock fires in an actual pause field; overlapping fields delay refill
until the last source leaves. Death freezes work and restoration reconciles
membership. Missed/unavailable signals do not create a deferred activation when
stock later becomes ready. Revival's separately authored 65 s clock still
continues while dead.

[2E4's actual enhancements](ATTACK_MODIFIERS.md) use ordinary request-anchored
cooldown work, while grants start at Active completion and expire in world time.
Two real pause fields move Ultimate readiness to 68000 ms; its 10-second grant
still ends at 10400 ms during the second field. Death retires unused grants and
freezes cooldown work; restoration does not restore an expired or retired grant.
