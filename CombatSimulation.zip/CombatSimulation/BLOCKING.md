# Block defenses and rechargeable charges

Primary facts: `Details.odt` p15 gives a forward 800-HP shield, 250 ms
lifetime and +100 disorientation/instability resistance. Holding activates
two shields, adds another +400 resistance, and takes 350 ms. `2E4.odt`
p32/p185–189 lists basic8 Block with four charges,4500 ms per charge,150 ms
Active and Db2. Current p34/p193–197 instead defines basic9 as
[Dodge](DODGING.md), with its own four charges,150 ms Active and Db3.5. `3E5.odt`
p36/p255–259 lists basic 8 with the same stock/timing and Db 2.
The following gap resolutions are delegated technical decisions, not author
clarifications. Original source documents remain intact.

- Current2E4 basic8 and3E5 basic8 use their own Block family stock. Frozen old
  profiles that explicitly supplied two Block aliases retain their shared
  family pool; current2E4 basic9 is a separate physical Dodge. Select the held
  Block form with `held_blocks` in the actor's
  existing priority policy. Db is paid once per cast at Active start; a tap
  spends one charge and a hold spends two. No refund after payment.
- A tap controls its hands for the authored 150 ms; its released shield lasts
  250 ms. A hold controls for the shared 350 ms, deploying at Active start
  and 100 ms later, each shield lasting 250 ms. This preserves both per-shield
  lifetimes and the total held interval. Cancellation prevents the second
  release; already released shields retain their own expiry.
- Each shield is a fixed-size 0.8 m wide, 0.02 m thick, 1.75 m high rectangle
  represented by a cuboid, centred 0.4 m forward of the upright body origin.
  It follows upper-body translation/crouch and fixed facing. It participates
  in projectile and melee queries, without making a character a larger body
  obstacle or changing area eligibility. The initial proxy is configurable
  through this versioned implementation; no animation is involved.
- Raw directed contact damage spends oldest Block layers first, then the
  holder's regenerative shield, then the shared pre-hit armor/HP formulas.
  Each layer splits simultaneous competing damage proportionally. As a
  personal defense volume, overflow transfers to its holder in that same
  hit, including a contact near the rectangle's edge. The incoming projectile
  is consumed once. Area attacks, beam heat and existing intracellular
  bleed/venom bypass this forward interception surface.
- Each unbroken released shield adds +100 status resistance to its living
  source life. A currently controlled hold with a surviving shield adds
  +400 once. Use the pre-batch bonus even when the incoming batch breaks
  every layer. Shield HP supplies no implicit toxin/armor resistance and
  produces no applied-HP credit, healing capacity or regenerative-shield debt.
- Released Block shields survive holder death as fixed short-lived surfaces
  at the last pose. Their original source life, HP and expiry remain; no
  bonus or overflow damage transfers to a later life. A projectile striking
  such an independent surface is consumed as for other world obstacles.
  Pending controlled releases are generation-bound and cancelled by death.
- Recharge is serial: one missing charge per 4500 ms of work. Spending while
  already recharging appends work without resetting current progress. Existing
  independent pause sources and ordinary death/resume clock rules apply.
  Ready stock can be spent inside a pause field. Idle full stock banks no work.
- The neutral left hand at local (-0.2,0.15,-0.1) activates Block; its start/end
  poses coincide. Require upper-body function, with its own `defense:basic_block`
  resource and left hand. A right-hand thrust can overlap when requirements
  permit. Block does not acquire the attack function or a global weapon lock.

The symmetric real-attack checks exposed an old nearest-enemy tie rejection.
Under delegation (2026-10-31), the simple nearest-living policy now breaks exact
distance ties by stable actor instance ID. This changes neither unequal-distance
selection nor attack definitions and supports reproducible symmetric encounters
without adding advanced NPC behavior. Participant insertion/hash order does not
select the target.

**Historical checkpoint, 2026-10-31:** shared Block for the then-imported2E4
basic8/9 and3E5 basic8, including
held selection. 3E5's existing walk/run/sprint/crouch/jump/climb profile is now
ported from its own authored values with the documented common defaults;
actual walking, crouch, jump and climb interactions are checked. Its punch,
chain, special leap, heavy punch and Ultimate remain unfinished shared delivery.
The subsequent [causal reaction controller](COMBAT_REACTIONS.md) now executes
the authored 2E4 ability 2 automatically after successful absorption, with its
own charge stock. This does not add a counter ability to 3E5.

The subsequent [attack enhancements](ATTACK_MODIFIERS.md) carry finite per-packet
shielding-ignore budgets through intercepted Block and personal layers. Skipped
stock stays intact and emits no successful-Block signal; ordinary packets in
the same batch can still consume that stock. The existing status resistance and
old-life receiver boundaries remain.

Released surfaces inherit the projectile's existing owner/friendly-fire policy.
They collide with neither bodies nor terrain as moving bodies; cover still
participates normally in attack contact queries. On break/expiry, freeze the
terminal geometry in the trace instead of reporting the holder's later pose.
No Block loss adds regenerative-shield debt or applied-HP credit.

Verification: **1502 full-suite tests pass in 215.999 s**. New coverage comprises
12 rechargeable-stock, nine pure layer, 31 shared Block interaction checks, and
four revised-author-source checks. The shared cases include proportional
simultaneous break/overflow, pre-hit armor/status snapshots, independent thrust,
both costs, held bonus windows, real beam/Qard/venom, paused recharge, body
collision statuses, friendly fire, exact expiry/contact arbitration, source
death, old/new lives and frozen-surface kinematics. The exact linear expiry
control labels its level-muzzle geometry variant; the ordinary captures use
unchanged current definitions.

Nine ordinary encounters reproduce complete public API/CLI traces, HP/healing
and layer-loss conservation, two complete hash-seed controls and reversed-order,
observation/precision controls. Existing reviews and frozen packages replay
unchanged. [Evidence, inputs and commands](results/block-defenses/README.md).
