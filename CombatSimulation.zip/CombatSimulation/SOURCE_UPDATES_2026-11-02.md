# Primary source revisions detected 2026-11-02

## Collision equilibrium revision

The final wall/ground-chain audit found that root `Collision details.odt`
differs from the previous chain checkpoint. The implementation did not modify
that primary file. Thirteen other root ODTs match the prior checkpoint exactly.
Both collision-source versions and their hashes are preserved in
[the source revision record](results/destructible-walls/source-revision.json).

The revision appends a rule: while disoriented and unstable, characters lose
equilibrium and start falling over a duration `tF`, in milliseconds. The new
embedded formula is:

```text
tF = 1500 / (1 + (O + U) / 400)
```

Existing source paragraphs and all three existing embedded formulas are
unchanged, including intrinsic sustained output loss `U/4`, status mitigation
and knockback resistance. No original file or historical result is overwritten.

**Implementation status: integrated in current selected rules.**
[Equilibrium and prone decisions](EQUILIBRIUM.md) record the live-rate integral,
partial recovery, six-part pose, concurrent crouch, paid Get Up, clearance,
interruption and lifecycle choices. These details are delegated decisions,
separate from the author's appended formula. Tests cover all six Get Up
profiles and real existing-kit interactions; the Block counter supplies an
ordinary source of full balance loss. [Evidence](results/equilibrium/README.md).
No primary source is edited and historical results/manifests remain preserved.
The full six-kit Goal is still incomplete.

## Concurrent 1E2 Aim revision

During the contact-event verification, `1E2.odt` changed from the preceding
body-support source hash. The implementation did not edit that primary file.
The only paragraph differences make basic ability 8 (Aim) a toggle with a
160 ms Active transition, prohibit aiming while running, and add 10 cm radius
per 100 m to ability 1/4 inaccuracy while not aiming.

**Implementation status: verified 2026-11-03.** The original source-observation
increment left perfect aim unchanged. The subsequent [Aim integration](AIMING.md)
now executes the owned toggle and physical release cones with deterministic
shot samples, real movement/interruption/lives and copied release receipts.
[Current evidence](results/aim-toggle-confirmed-entry/README.md) includes the
ordinary prison/ice contact under [confirmed entry](CURVED_CONTACTS.md), fresh
API/CLI/hash/numerical reproduction and source paragraph audits. The previous matching
source copy, new complete ODT, hashes and paragraph diff are pinned in
[the concurrent source record](results/body-contact-signals/concurrent-source-observation.json).
Thirteen other primary ODTs and all earlier result packages remain unchanged.

## Concurrent 1E3 duplication overview revision

The charge investigation also detected an external edit to `1E3.odt`: its
Ultimate's area radius changes from 8 to **12 m**, and the separation of the
duplicated projectiles changes from 3 to **4 m**. The 25 s duration and 65 s
cooldown are unchanged. The original matching source, current full ODT, hashes
and paragraph diff are preserved in
[the charge source record](results/charge-grapple/concurrent-source-observation.json).
The implementation did not edit any primary ODT; thirteen others match the
start of this increment.

**Implementation status: actual field verified 2026-11-09.** The
[existing Ultimate](PROJECTILE_DUPLICATION.md) now has owned activation, actual
continuous entry and symmetric 4m splitting, preserving source values and
independent field/flight lifetimes. [Evidence](results/projectile-duplication/README.md)
covers the full 2774-method suite, 20 ordinary cases, six labelled API probes
and 113 exact prior traces. The earlier copy API was its shared foundation;
other creative kit delivery, including portals, remains unfinished.
