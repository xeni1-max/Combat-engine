# Basic jumping

Current ruleset/correction index: [ENGINE_STATUS.md](ENGINE_STATUS.md). The
2026-10-28 corrections below supersede earlier landing reconstruction and
conditional world-physics selection; historical results retain their evidence.

Author-confirmed rules, 2026-10-25, for the current 1E1/1E2 movement milestone:

- Upward takeoff speed is **half base running speed**. It does not use current
  walking/running speed or a reduced speed from instability.
- Existing horizontal velocity is retained at takeoff. In the isolated flight,
  gravity is the only acceleration, so horizontal velocity stays constant.
- Gravity is **9.81 m/s² downward**, as previously confirmed.
- Takeoff occurs at **Active start**. It is an initial velocity at that instant,
  not acceleration distributed across the 150 ms Active phase.

Both basic jumps in `1E1.odt` and `1E2.odt` have Gathering 100 ms and Active
150 ms. Existing Gathering/disorientation/running modifiers apply through the
shared timing helper. The copied basic-jump source values are in
[data/movement/jump.json](data/movement/jump.json). The special jump in 1E1's
other ability is not substituted for this basic jump.

Both characters' base running speed is 6.4 m/s, giving upward speed **3.2 m/s**.
For an unobstructed flight returning to takeoff height:

| Quantity | Exact value | Approximate value |
|---|---|---|
| Time from takeoff to apex | 320/981 s | 0.326198 s |
| Maximum rise above takeoff | 512/981 m | 0.521916 m |
| Time from takeoff to same height | 640/981 s | 0.652396 s |

Time and height are relative to takeoff. With no initial statuses and starting
stationary, takeoff is 100 ms after action start, Active ends at 250 ms, and
return to takeoff height is about 752.396 ms after action start. Active ending
is not landing. A running start modifies Gathering according to existing rules.

## Earlier isolated implementation

[mechanics/jumping.py](combat_sim/mechanics/jumping.py) implements isolated
flight with exact rational arithmetic and reuses existing timing rules for
Active-start takeoff. Callers explicitly supply launch origin and horizontal
velocity. Same-height return is a geometric marker; it does not itself assert
contact with finite ground, a cube or another body. Queries beyond that marker
are rejected in this bounded helper rather than inventing subsequent movement.

Eleven tests verify base-speed scaling, retained walking/running/oblique
horizontal velocity, exact apex and return, energy conservation, agreement with
the independent ballistic evaluator, takeoff timing, Gathering modifiers and
Active/flight separation. The complete suite passes **551 tests**.

The root basic-jump documents list self disorientation/instability 80/80 on jump,
100/120 on landing and dyspnea value 1.5. The isolated flight helper does not
apply or pay them. Its original 551-test checkpoint did not include body contacts,
landing response, death or combat resources. The later integrations below have
their own explicit scope; historical results retain their original rules.

## Earlier shared-engine geometry integration

Takeoff, apex, Active end and flat-ground landing now run as separate events
on the shared combat event queue. Both stationary and walking/running jumps
are tested; body cuboids translate with horizontal and vertical motion.
The author selected geometry/timing only for this test: jump/landing statuses
and dyspnea payments remain excluded. Same-flat-ground landing sets vertical
velocity to zero while retaining horizontal velocity. This is distinct from
a general airborne body/obstacle collision response, which remains rejected.
See [shared movement results](results/scripted-movement-shared/REPORT.md).

## Shared movement and combat, 2026-10-27

The existing basic jump now runs on the moving-combat coordinator alongside
walking, running, sprinting, stopping and the existing 1E2 gun. Six upright
cuboids follow the full three-dimensional path. Gravity, projectile contact,
resources, statuses and death share the same event clock. This extends the
existing engine; it is not a separate jump runner or the character's special leap.

[combat_jump.json](data/movement/combat_jump.json) enables this integration.
The API accepts it as `jump_definition`; the CLI loads it for moving-combat
scenarios containing a jump command (`--combat-jump` can select another file).
The geometry-only definition and older scenarios remain unchanged. Jump data
covers 1E1 and 1E2; current moving weapon integration remains limited to the
existing 1E2 gun. This does not establish other kits' combat support.

Source audit: `1E1.odt` paragraphs 157–168 and `1E2.odt` paragraphs 173–184
contain the basic jump timing, status and dyspnea values above (zero-based
paragraph indices). Neither specifies basic-jump hand poses. The nearby 1E1
launcher firing pose belongs to a different action and is not used for jumping.

The following choices resolve unspecified timing/interactions under the
author's delegation. They are implementation decisions, not further author
clarifications:

- Check capacity before selecting jump and again at Active start. Treat the
  listed 1.5 as Db, pay `Da = (1.5 + D/100)^2` at Active start, and apply the
  unmitigated self 80 disorientation / 80 instability then. From D=0 the payment
  is 2.25. Death before takeoff pays nothing; later cancellation does not refund
  an already paid cost. Existing maximum-dyspnea triggering still applies.
- Retain both current hand poses without adding a Recovery movement. No hand
  movement is authored for this basic jump. Gathering is 100 ms, modified by
  running and existing/incoming disorientation. Active lasts 150 ms regardless
  of the remaining flight. Running's existing 1.2 factor applies to Gathering
  and self statuses, giving 96/96 at takeoff from running.
- Snapshot actual horizontal velocity before adding the jump's new instability.
  Gravity then changes only vertical velocity until contact. Airborne status
  changes do not retroactively subtract speed or propel the body; the ground
  instability speed rule resumes on landing. This preserves the author's
  retained-horizontal-velocity rule.
- Flight and the controlled action are distinct. The frozen exclusive input
  permits weapons after jump Active; current declared ownership also permits
  eligible gun/reload during Gathering/Active because basic jump owns no hands.
  Ground movement intents wait for landing
  without blocking an otherwise legal weapon action. Sprint-to-jump first
  stages the existing paid sprint-to-run exit. No free airborne steering,
  braking or repeated takeoff is added.
- Airborne dyspnea recovery is explicitly zero. There is no authored airborne
  recovery rate; retaining a ground mode's rate would grant different recovery
  to otherwise identical flights. This choice adds no continuous jump cost.
  Landing wakes waiting policies so capacity can be reconsidered on the ground.
- Landing applies the authored self 100 disorientation / 120 instability and
  the separate general physical-contact penalties. The former bypass defenses
  and use the running modifier when applicable; the latter use impact speed
  and the character's pre-contact defenses. Keeping both preserves the two
  separately specified rules. Sum all contributions before one Gathering
  extension. No extra fall damage or bounce is introduced.
- Contacts project the full 3D velocity using the shared character centre line
  and obstacle surface rules. An additional support-plane constraint prevents
  an already grounded character from being projected through the floor. An
  upward collision response may lift a grounded character without activating
  jump: it pays no jump cost and receives no basic-jump landing self effects.
  Physical contact penalties still apply. Side contact preserves permitted
  vertical motion; landing removes downward velocity. An incidentally lifted
  sprinter retains sprint effort; if it exhausts capacity in air, effort ends
  immediately and the existing special stop waits until landing.
- Death freezes the last body location, cancels its controlled action and flight,
  and removes its collision geometry. Already released shots keep traveling.

The subsequent [ownership rules](ACTION_OWNERSHIP.md) supersede the original
single controlled-action slot in current inputs. Upper restriction leaves a
permitted jump action/flight intact; lower restriction cancels jump control but
preserves existing physical flight and clears voluntary landing drive. Self O
from a parallel action can extend a pending jump Gathering. Source-specific
restrictions, actual concurrent gunfire and empty-magazine reload/jump are
verified in the [ownership checkpoint](results/action-ownership/REPORT.md).

For an undamaged standing jump landing at 3.2 m/s, the raw physical contact
status is `60 × 3.2 = 192` for each status. With HP maximum 8140, armor 150
and zero extra resistance, the resisted amount is approximately 147.863954.
Including landing self effects gives approximately 247.863954 disorientation
and 267.863954 instability. Those totals are added at actual floor contact,
not at Active completion.

## Numerical handling and remaining limits

[airborne_geometry.py](combat_sim/airborne_geometry.py) finds descending plane
contact analytically in Decimal arithmetic. It ignores the initial plane root
when takeoff is upward and uses a rationalized quadratic root for downward
motion to avoid subtractive cancellation. Negative initial heights within
1e-25 m are arithmetic roundoff; deeper penetration is rejected. The coordinator
checks the finite ground footprint separately. Cuboid contacts use the existing
relative-motion detector; projectile contacts retain their own documented
[gravity tolerances](GRAVITY.md).

Velocity components below 1e-24 m/s after projection are cleared, matching the
existing ground collision tolerance. Otherwise a vanishing horizontal remainder
could become nominal travel when instability expires and create a false resting
contact. A regression covers an oblique airborne-body collision, grounded
support and subsequent landing with no repeated contact.

The jump checkpoint preserved the arena, fixed facings and upright hitboxes.
Subsequent [posture integration](CROUCH_SPRINT.md) supports crouched jumping on
the same timeline, with anchored feet and the same landing effects.
Ground-footprint departure, walking off raised support and standing on another
moving body are explicitly unsupported. General ledge/fall handling,
climbing, turning, knockdown/Get Up geometry and moving area effects still need
integration. The 1.8 m cubes cannot be cleared by the ordinary jump's roughly
0.522 m rise. No special leap ability is substituted to clear them.

Focused checks cover exact geometry/timing, resource anchors, running momentum,
landing contributions, airborne gunfire and limb contact, misses, wall contact,
queued commands, incoming Gathering extension, sprint exit, death and released
shots, input validation, and observation/precision/order independence.
[Saved scenarios, complete traces and replay](results/jump-combat/REPORT.md)
provide the integrated demonstrations. See [PROGRESS.md](PROGRESS.md) for the
current complete-suite result and next task.

## Landing drive and world physics correction, 2026-10-28

The principal review reproduced a speed exploit: adding current U/200 back to
ballistic horizontal velocity on landing granted permanent extra nominal pace.
That offset restoration is only appropriate for velocity already reduced by
ground U. Flight now stores the commanded ground-drive vector independently
from its ballistic velocity. Physical contacts project both using the same
constraints. Landing resumes projected ground drive, then applies current
ground penalties normally; airborne self/incoming U cannot become propulsion.
Uncontrolled/path momentum remains distinct and receives no universal pace cap.

Current `integrated_v2` world gravity/support is always enabled independently
of jump-action data or scheduled commands. Loading an optional jump definition
changes legal actions, not earlier physics. Historical rule selection remains
explicit through the compatibility adapter. Nested state snapshots are values.
[Review response and actual corrected jump result](PRINCIPAL_ENGINEERING_REVIEW_RESPONSE.md).
