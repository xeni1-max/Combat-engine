# Confirmed author design preferences

This concise record contains explicit author direction, not inferred preferences
or implementation decisions. Material delegated choices belong in the relevant
mechanics document and PROGRESS.md. Sources: author clarifications of 2026-10-25,
role/responsibility clarification of 2026-10-27, and effort/dyspnea clarification
of 2026-10-28 and effort/interruption clarification of 2026-10-29.

- Preserve the six existing characters (1E1, 1E2, 1E3, 1E5, 2E4, 3E5) and their
  identities. Do not invent new character abilities.
- Primary `Details2.odt`, observed2026-11-09, specifies1E5 as30% taller and60%
  wider/thicker than1E1, and3E5 as5% taller and15% wider/thicker. Preserve these
  relative body identities. Affine placement/crouch/hand handling are separate
  delegated choices in [CHARACTER_GEOMETRY.md](CHARACTER_GEOMETRY.md).
- Author source revisions observed 2026-10-31 replace 1E5's scaling bleeding
  passive/extra-arm Ultimate with double bleeding/80-piercing enhancement, and
  2E4's owner-contact projectile/extended attachment with additional armor loss/
  shielding bypass. Preserve the revised identities; old descriptions are
  historical. [Exact source changes](SOURCE_UPDATES_2026-10-31.md).
- Imaginative, unusual abilities are central. Solve difficult implementation
  problems rather than removing defining creative features for convenience.
- Build an inspectable, internally consistent combat simulation without animations.
  Current priority is one working engine supporting all existing abilities and
  their interactions. Reproducible 5v5 experiments remain a longer-term goal.
- Prefer reusable mechanics. Multiple independently active abilities or persistent
  effects should coexist where their documented rules permit.
- Dyspnea follows the character's physical effort. Effortless extrinsic
  activation, summons, marks, passive effects and automatic enhancements do not
  need dyspnea values. Physical effort such as recoil control retains its own
  cost. The eight explicit no-cost examples, including 2E4 revival, are recorded
  in [DYSPNEA_POLICY.md](DYSPNEA_POLICY.md); an exemption is not Db=0.
- Intrinsic/extrinsic and momentary/sustained classify character effort per
  controlled phase, for instability response. A motor alone does not determine
  the label; a lasting effect does not make its activation sustained. 1E1's beam
  activation is extrinsic momentary; once deployed, the character cannot stop
  the beam and caster instability cannot interrupt it. [Definitions and scope](ABILITY_EFFORT.md).
- The author added `Grapple abilities.odt` as a primary source on 2026-10-29.
  Preserve its fatigue-dependent release, defender Break/controller response,
  escape penalties and weighted shared movement, with each ability's actual
  grab/drag/carry behavior. Source grapple and binding labels remain distinct;
  shared movement alone does not merge their escape rules. [Source rules and
  delegated interpretations](GRAPPLE.md).
- Author clarification, 2026-11-01, reaffirmed 2026-11-02: a knockback/knock-away hit moves everyone
  still joined in that grapple together. Use summed participant stats in the
  knockback resistance formula, including summed maximum HP and current armor.
  Knockback and knock away are synonyms; knock up uses the upward direction,
  and knock down uses the downward direction. [Rules and scope](KNOCKBACK.md).
- Climbing requires continued attachment to its climbable object. Displacement
  that removes the character from the required reach interrupts climbing; an
  already started path must not continue regardless of displacement. Clarified
  2026-10-29; [CLIMBING.md](CLIMBING.md) separates this author rule from the
  technical handling of the approved up/across path and its upright reference.
- Author request, 2026-11-02: add destructible walls with 2000 HP, taking blunt,
  slash, Qard, heat, constriction and tear damage, in preparation for 3E5's
  Ultimate. [Wall rules and delegated layout](DESTRUCTIBLE_WALLS.md).
- Improve imbalance, exploits, inconsistency and unnecessary complexity while
  respecting character identity; favor reversible choices when uncertain.
- The author directs creativity and gives preferences/feedback; the implementation
  agent owns detailed design, mathematics, architecture and implementation. Ask
  only for indispensable input, identity/feature changes or major uninferable
  direction. Document assumptions separately from author specifications.
- Prioritize incremental, verified working results, reliable tests and durable
  handoffs. A helper or separate runner does not establish shared integration.
- Advanced NPC intelligence, learning and large automated experimentation are
  future possibilities, not current priorities. Maintain reasonable compatibility
  without substantial speculative work.
